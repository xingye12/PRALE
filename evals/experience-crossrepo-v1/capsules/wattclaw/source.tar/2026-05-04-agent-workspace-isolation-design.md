# Agent Workspace 隔离改造设计

## 目标

为每个 agent 建立按用户隔离的 workspace 目录，注入文件路径规则到 BOOTSTRAP.md，并将用户上传的文件定向到 agent workspace 的 uploads/ 子目录。

## 1. 统一 workspace 路径格式

### 数字员工（AgentTeamPage.vue handleCreated）

路径格式：`~/.wattclaw/{username}/{agentname-timestamp}`

- `username` = `authStore.currentUser.username`（sanitize 后）
- `agentname` = agent 显示名称（sanitize 后）
- `timestamp` = `YYYYMMDDHHmmss` 格式

当前代码（行 89-98）生成 `~/.openclaw/{username}-{agentname}-{timestamp}`，需改为新格式。去掉 `display_name` 优先级，统一用 `username`。

### 低级 agent（agent.ts addAgent）

路径格式：`~/.wattclaw/agents/workspace-{id}`

当前代码（行 133）默认 `~/.openclaw/workspace-${params.id}`，改为 `~/.wattclaw/agents/workspace-${params.id}`。

## 2. BOOTSTRAP.md 注入 workspace 文件路径规则

### 新增函数（agent-templates.ts）

`generateBootstrapWithWorkspaceRules(bootstrapMd: string, workspacePath: string): string`

- 查找 `<!-- WORKSPACE_RULES -->` 标记替换为规则内容
- 无标记则追加到末尾
- 规则内容包含 workspace 根路径和 8 条文件路径规则（uploads/downloads/tmp 等）

### 29 个 bootstrap 模板文件

每个 `src/bootstrap/*.md` 文件末尾追加 `\n\n<!-- WORKSPACE_RULES -->` 标记。

### AgentTeamPage.vue handleCreated

写入 BOOTSTRAP.md 时，先通过 `generateBootstrapWithWorkspaceRules()` 包装内容，传入实际 workspace 路径。

## 3. 文件上传路径改造

### 后端（server/index.js）

`POST /api/workspace/upload-to-gateway` 路由（行 2568）改造：

1. 从 FormData 读取 `agentId` 字段
2. 调用 `getAgentWorkspace(agentId)` 获取 workspace 路径
3. `expandHomePath()` 展开 `~`，拼接 `/uploads`
4. 构建自定义 `uploadConfig`，将 `GATEWAY_MEDIA_DIR` 设为该路径
5. 传给 `uploadToGateway()` 使用

`uploadToGateway()` 函数签名需支持传入自定义目标目录（覆盖 envConfig 中的 `GATEWAY_MEDIA_DIR`）。

### 前端（ChatInput.vue uploadFile）

`uploadFile()` 函数（行 56-73）改造：

1. 从 `workspaceStore.selectedAgentId` 获取当前 agentId
2. FormData 中追加 `agentId` 字段

## 涉及文件

| 文件 | 改动 |
|------|------|
| `src/views/agent-team/AgentTeamPage.vue` | workspace 路径格式 + bootstrap 注入 |
| `src/stores/agent.ts` | 低级 agent workspace 路径 |
| `src/config/agent-templates.ts` | 新增 `generateBootstrapWithWorkspaceRules()` |
| `src/bootstrap/*.md` (29 files) | 追加 `<!-- WORKSPACE_RULES -->` 标记 |
| `server/index.js` | upload 路由支持 agentId |
| `server/gateway-file-transfer.js` | `uploadToGateway()` 支持自定义目录 |
| `src/views/workspace/ChatInput.vue` | FormData 附带 agentId |

## 技术约束

- `erasableSyntaxOnly: true`，用 interface 不用 enum
- 2 空格缩进、单引号、尾逗号、无分号、无注释
- `<script setup lang="ts">`，Composition API
- 验证：`npx vue-tsc --noEmit`
