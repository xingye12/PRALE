# AGENTS.md — Repository Collaboration Guide

## Project Overview
Vue 3 + TypeScript management dashboard for OpenClaw Gateway. Uses Vite, Pinia, Naive UI, vue-i18n, and a Node.js/Express backend that proxies RPC calls to the Gateway.

## Project Structure
```
src/
  main.ts                 # App entry — registers Pinia, Router, i18n
  App.vue                 # Root component
  api/
    websocket.ts          # WebSocket wrapper over ApiClient
    rpc-client.ts         # High-level typed RPC interface (~1500 lines)
    http-client.ts        # HTTP + SSE transport layer
    types/                # Domain type definitions (barrel export in index.ts)
  components/
    layout/               # Shell layout components (DefaultLayout, etc.)
    common/               # Reusable components (EmptyState, ConnectionStatus)
    office/               # Office-related components
  composables/            # Shared composables (useTheme, useEventStream, useResizable)
  stores/                 # Pinia domain stores (auth, session, channel, websocket, etc.)
  views/                  # Route-level pages, named *Page.vue
  router/
    routes.ts             # Route definitions
    index.ts              # Router creation + auth guard
  i18n/                   # vue-i18n setup; messages/en-US.ts, messages/zh-CN.ts
  utils/                  # Pure utility functions (format, markdown, secret-mask)
  assets/styles/main.css  # Global CSS with custom properties
server/
  index.js                # Express backend (~3500 lines)
  gateway.js              # OpenClaw Gateway connection manager
  database.js             # SQLite (better-sqlite3) persistence
```

## Build, Dev, and Test Commands
```bash
npm install               # Install dependencies
npm run dev               # Start Vite dev server (http://localhost:3001)
npm run dev:server        # Start Express backend only
npm run dev:all           # Start frontend + backend concurrently
npm run build             # Type-check (vue-tsc -b) then Vite production build
npm run preview           # Preview production build locally
```

**Type-checking (no emit):** `npx vue-tsc --noEmit`

**Testing:** No test framework is configured yet. Vitest and @vue/test-utils are listed as devDependencies but no test files or vitest config exist. To run tests once configured:
```bash
npx vitest                        # Run all tests
npx vitest path/to/test.test.ts   # Run a single test file
npx vitest --reporter=verbose     # Verbose output
```

**Linting:** No ESLint or Prettier is configured. Code style is enforced manually per the conventions below.

## Code Style Guidelines

### Formatting
- 2-space indentation, single quotes, trailing commas, no semicolons
- No comments unless explicitly requested
- Max line length: follow existing file patterns (generally unenforced)

### Imports — Ordering (top to bottom)
1. Vue core: `import { ref, computed, onMounted } from 'vue'`
2. Pinia: `import { defineStore } from 'pinia'`
3. Naive UI components: `import { NButton, NCard } from 'naive-ui'`
4. Third-party libraries: `import { useI18n } from 'vue-i18n'`
5. Application code using `@/` alias: `import { useAuthStore } from '@/stores/auth'`

Use `import type { ... }` for type-only imports. Prefer `@/` alias for all `src/` paths.

### TypeScript
- Strict mode enabled; `erasableSyntaxOnly: true` — use `interface` for object types, `type` for unions/intersections
- Explicit generics on refs: `ref<string | null>(null)`, `ref<Session[]>([])`
- Use `shallowRef` for large/complex objects to avoid deep reactivity overhead
- String literal unions for enums; `as const` object pattern for enum-like constants
- Optional fields with `?`; index signatures `[key: string]: unknown` for extensible API shapes
- No classes in type files — purely structural typing

### Vue Components
- Always `<script setup lang="ts">` — never Options API or `<script>` without `setup`
- Props: `defineProps<{ prop: Type }>()` — TypeScript generic syntax, no runtime `PropType`
- Emits: `defineEmits<{ (e: 'event', payload: Type): void }>()`
- Local types (interfaces, type aliases) defined inline within `<script setup>`
- Template refs: `const elRef = ref<HTMLElement | null>(null)`

### Pinia Stores
- Composition API style only: `defineStore('name', () => { ... })`
- State: `ref<T>(...)`, derived: `computed(() => ...)`
- Explicit return object listing all exposed state and functions
- Named export: `export const useXxxStore = defineStore(...)`
- No default exports in store files

### Error Handling
- try/catch with descriptive `console.error` prefix: `console.error('[StoreName] action failed:', error)`
- Graceful fallbacks — never let errors crash the app silently
- `finally` blocks for loading state reset: `loading.value = false`
- Error state tracking: `error.value = e instanceof Error ? e.message : 'Network error'`
- Non-critical failures: `catch { /* ignore */ }`

### Naming Conventions
- Components: `PascalCase.vue`
- Route pages: `*Page.vue` (e.g., `SessionsPage.vue`)
- Store files: lowercase descriptive (e.g., `auth.ts`, `session.ts`)
- Store exports: `useXxxStore`
- Composables: `useXxx.ts`
- Utils: lowercase descriptive (e.g., `format.ts`, `markdown.ts`)
- Type files: domain-named (e.g., `session.ts`, `channel.ts`)

### Styles
- `<style scoped>` on all components; no CSS preprocessors
- Use CSS custom properties: `var(--bg-card)`, `var(--text-*)`, `var(--border-color)`, `var(--primary)`
- Avoid hardcoded colors; if unavoidable, scope selectors tightly
- `:deep()` for overriding Naive UI internals within scoped styles
- For `v-html` injected content, use `:deep(...)` or non-scoped controlled styles
- Spacing: single mechanism per layout (gap OR margin, not both) to avoid first-child inconsistencies

### Internationalization (i18n)
- All user-facing text must use `t('key')` — never hardcode strings in templates
- Destructure: `const { t } = useI18n()`
- Message keys follow `pages.<page>.<section>.<item>` nesting
- Two locales: `zh-CN` and `en-US` (fallback)
- When adding new UI text, add entries to BOTH locale files

### API Layer
- Transport: SSE (`EventSource`) for real-time events; HTTP POST for RPC calls
- RPC method calls through the typed `RPCClient` — never call `fetch('/api/rpc')` directly from components
- Defensive normalization: Gateway responses have unpredictable shapes; use `asRecord()`, `asString()` helper methods
- Multiple candidate field names when normalizing: `row.key || row.sessionKey || row.id`

## Architecture Principles
- **Single source of truth**: One authoritative implementation per capability (no duplicate logic in page + store)
- **Compatibility first**: Adapt to existing Gateway RPC shapes; don't introduce unverified protocol branches
- **Incremental changes**: Ship minimal working change, then iterate on UX
- **Security defaults**: Credentials never displayed in plaintext; never submit credential patches without new values
- **Facts first**: Read existing code before modifying; never guess RPC shapes, types, or page behavior

## Verification Checklist
After any change:
1. `npm run build` must pass with zero errors
2. Verify no TypeScript regressions: `npx vue-tsc --noEmit`
3. Manual smoke-test affected flow (login, WebSocket connection, relevant pages)
4. Connect to Gateway at `ws://127.0.0.1:18789` for integration testing
5. For non-trivial changes, document impact and regression points in PR

## Commit Convention
Use Conventional Commit prefixes: `feat:`, `fix:`, `refactor:`, `docs:`, `chore:`. One topic per commit.

## Environment Variables
Runtime config via `.env.development` / `.env.production`. New `VITE_` variables must be documented in `README.md`. Never commit real tokens or credentials.

## Known Pitfalls
- Naive UI components may have first-child CSS exceptions — check component source before adjusting spacing
- Spacing bugs often involve margin/padding/border stacking — inspect each layer individually
- Dark mode changes must use theme variables with scoped selectors to avoid polluting other pages
- Before changing `v-html` styling, remember scoped CSS cannot target runtime-injected nodes
