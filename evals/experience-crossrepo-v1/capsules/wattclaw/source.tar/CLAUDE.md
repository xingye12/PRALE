# CLAUDE.md

Guidance for Claude Code when working in WattClaw.

## Project Snapshot

WattClaw is a Vue 3 + TypeScript dashboard for OpenClaw Gateway. Frontend state lives in Pinia, backend is Node.js/Express, persistence is SQLite, and Gateway communication is proxied over WebSocket.

## Commands

```bash
./start.sh             # Start frontend + backend
./restart.sh           # Restart all services
npm run dev            # Vite only, port 3000
npm run dev:server     # Express only, port 3001
npm run dev:all        # Frontend + backend
npm run build          # vue-tsc + Vite build
npx vue-tsc --noEmit   # Type check only
npm start              # Production backend
```

No test framework or linter is configured yet.

## Core Data Flow

Frontend pages → Pinia stores → `src/api/rpc-client.ts` or `src/api/http-client.ts` → `server/index.js` → `server/gateway.js` → OpenClaw Gateway.

Realtime events flow Gateway → backend SSE `/api/events` → `useEventStream` → frontend stores/pages.

## High-Value Files

- `server/index.js` — Express routes, auth, RPC proxy, multi-user isolation, SSE forwarding.
- `server/gateway.js` — Gateway WebSocket client, device identity, RPC frames, reconnect, heartbeat.
- `server/database.js` — SQLite schema.
- `server/user-manager.js` — users, JWT, roles, ownership helpers, session/channel CRUD.
- `src/api/rpc-client.ts` — typed Gateway RPC wrapper.
- `src/api/http-client.ts` — REST/SSE client.
- `src/stores/` — Pinia stores, Composition API style.
- `src/mobile/` — current `/m` mobile route implementation.
- `src/i18n/` — `zh-CN` and `en-US` locale files.

## Architecture Rules

- Multi-user isolation is mandatory.
- Non-admin users only see owned sessions, agents, channels, cron items, and usage data.
- After session filtering, usage aggregates must be recomputed from visible sessions.
- Non-admin config APIs must not expose API keys and must reject config mutation.
- Channel-agent binding validates ownership before syncing to Gateway.
- Agent Team (`agent_team`) is local REST data, separate from Gateway agents.
- Keep one authoritative implementation per capability; no duplicate page + store logic.

## Vue / TypeScript Conventions

- Use `<script setup lang="ts">`; never Options API.
- Use `defineProps<{ ... }>()`; avoid runtime `PropType`.
- Use `interface` for object shapes and `type` for unions.
- Use explicit ref generics, e.g. `ref<string | null>(null)`.
- Use `shallowRef` for large or complex objects.
- Use `import type` for type-only imports.
- Components are `PascalCase.vue`; pages end with `*Page.vue`.
- Stores are `useXxxStore`; composables are `useXxx.ts`.

## UI / i18n / Styles

- User-facing text must use `t('key')`; no hardcoded template strings.
- Add locale entries to both `zh-CN.ts` and `en-US.ts`.
- Use `<style scoped>`.
- Use CSS variables such as `var(--bg-card)`, `var(--text-*)`, `var(--border-color)`.
- Dark mode variables live in `src/assets/styles/main.css` under `[data-theme='dark']`.
- Use `:deep()` for Naive UI overrides.

## Defensive Parsing

Gateway response shapes vary. Prefer existing helpers such as `asString()` and `asRecord()`, and support known alternative fields such as `key`, `sessionKey`, and `id`.

## Environment

`.env` is gitignored. Common variables: `PORT`, `OPENCLAW_WS_URL`, `OPENCLAW_AUTH_TOKEN`, `AUTH_USERNAME`, `AUTH_PASSWORD`, `LOG_LEVEL`, `VITE_APP_TITLE`.

## Deployment

Docker Compose builds frontend and production runtime. Volumes mount `data/` and Gateway config. See `Dockerfile` and `docker-compose.yml`.
