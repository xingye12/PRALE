# Docker 构建说明

## 构建状态

**当前状态**: ⚠️ Docker 构建不推荐

## 问题说明

本项目包含需要原生编译的 Node.js 模块：
- `node-pty`: 伪终端支持
- `better-sqlite3`: SQLite 数据库

这些模块在 Docker 容器（特别是 Alpine Linux）中编译较为复杂，容易失败。

## 替代方案

### 推荐方案：本地运行

请参考 [本地运行指南](./LOCAL_RUN_GUIDE.md) 获取详细的安装和运行步骤。

### Docker 方案（高级用户）

如果您熟悉 Docker 和 Node.js 原生模块编译，可以尝试以下方案：

1. **使用完整的基础镜像**：
   ```dockerfile
   FROM node:20-slim  # 而不是 node:20-alpine
   ```

2. **安装完整的构建工具链**：
   ```dockerfile
   RUN apt-get update && apt-get install -y \
       python3 build-essential git \
       && rm -rf /var/lib/apt/lists/*
   ```

3. **使用预编译的二进制文件**：
   - 使用 `npm install --prefer-offline` 尝试使用预编译版本
   - 或手动下载预编译的 `.node` 文件

## 已生成的 Docker 文件

以下文件已生成，但需要进一步调整才能正常工作：

- `Dockerfile`: 多阶段构建配置
- `docker-compose.yml`: 最小化配置
- `docker-compose.full.yml`: 完整配置

## 故障排除

### 构建失败：node-pty

**错误**：`gyp ERR! find Python`

**原因**：Alpine Linux 缺少完整的构建工具链

**解决方案**：使用 `node:20-slim` 基础镜像并安装构建工具

### 构建失败：better-sqlite3

**错误**：`fatal error: node.h: No such file or directory`

**原因**：Node.js 头文件缺失或路径不正确

**解决方案**：确保 Node.js 完整安装并配置正确的头文件路径

## 建议

对于开发和测试环境，强烈建议使用本地运行方式，而不是 Docker 容器化部署。
