# 本地运行指南

## 环境要求

- Node.js >= 18.0.0
- npm >= 9.0.0
- Python 3.x (用于 node-pty 和 better-sqlite3 原生模块编译)
- Make 和 C++ 编译器 (Windows 需要 Visual Studio Build Tools)

## Windows 环境额外要求

由于项目包含需要原生编译的依赖（node-pty、better-sqlite3），Windows 环境需要额外配置：

1. **安装 Visual Studio Build Tools**：
   - 下载 [Visual Studio Build Tools](https://visualstudio.microsoft.com/downloads/)
   - 安装时选择 "Desktop development with C++" 工作负载

2. **安装 Python**：
   - 下载 [Python 3.x](https://www.python.org/downloads/)
   - 安装时勾选 "Add Python to PATH"

## 安装步骤

### 1. 克隆项目

```bash
git clone https://github.com/itq5/OpenClaw-Admin.git
cd OpenClaw-Admin
```

### 2. 安装依赖

```bash
npm install
```

**Windows 环境安装失败处理**：

如果 `npm install` 失败，尝试以下步骤：

```powershell
# 使用管理员权限运行 PowerShell
# 安装 windows-build-tools
npm install --global windows-build-tools

# 或使用 yarn 安装
npm install -g yarn
yarn install
```

### 3. 配置环境变量

复制环境变量示例文件：

```bash
cp .env.example .env
```

编辑 `.env` 文件，配置必要参数：

```env
# 应用配置
VITE_APP_TITLE=盘古·OpenClaw网关可视化管理系统
PORT=3000
DEV_PORT=3001
LOG_LEVEL=INFO

# OpenClaw Gateway 配置
OPENCLAW_WS_URL=ws://localhost:18789
OPENCLAW_AUTH_TOKEN=
OPENCLAW_AUTH_PASSWORD=

# 认证配置
AUTH_USERNAME=admin
AUTH_PASSWORD=admin
```

### 4. 启动开发服务器

#### 同时启动前后端（推荐）：

```bash
npm run dev:all
```

#### 分别启动：

```bash
# 终端 1: 启动前端开发服务器
npm run dev

# 终端 2: 启动后端服务
npm run dev:server
```

### 5. 访问应用

打开浏览器访问：`http://localhost:3001`

## 生产构建

### 1. 构建前端

```bash
npm run build
```

### 2. 启动生产服务

```bash
npm start
```

生产服务将同时托管前端静态文件和后端 API 服务，访问地址：`http://localhost:3000`

## 常见问题

### 1. node-pty 编译失败

**错误信息**：
```
gyp ERR! find Python
```

**解决方案**：
- Windows: 安装 Visual Studio Build Tools 和 Python
- macOS: `xcode-select --install`
- Linux: `sudo apt-get install build-essential python3`

### 2. better-sqlite3 编译失败

**错误信息**：
```
Error: Cannot find module 'better-sqlite3'
```

**解决方案**：
```bash
# 重新构建原生模块
npm rebuild better-sqlite3
```

### 3. 端口占用

**错误信息**：
```
Error: listen EADDRINUSE: address already in use :::3000
```

**解决方案**：
- 修改 `.env` 文件中的 `PORT` 和 `DEV_PORT` 配置
- 或停止占用端口的进程

## Docker 部署（不推荐）

由于项目包含需要原生编译的依赖（node-pty、better-sqlite3），在 Docker 容器中构建较为复杂。如果确实需要 Docker 部署，建议：

1. 使用包含完整构建工具的基础镜像
2. 预编译原生模块
3. 或使用多阶段构建，在构建阶段安装所有依赖

## 开发工具推荐

- **IDE**: VS Code
- **Node.js 管理**: nvm-windows 或 fnm
- **API 测试**: Postman 或 Insomnia
- **数据库管理**: DB Browser for SQLite

## 项目结构

```
OpenClaw-Admin/
├── src/                    # 前端源码
│   ├── api/               # API 通信层
│   ├── components/        # Vue 组件
│   ├── layouts/           # 布局组件
│   ├── stores/            # Pinia 状态管理
│   ├── views/             # 页面视图
│   └── main.ts            # 入口文件
├── server/                # 后端服务
│   ├── index.js           # 服务入口
│   ├── gateway.js         # Gateway 连接
│   └── database.js        # 数据库操作
├── public/                # 静态资源
│   ├── logo.png           # Logo 图片
│   └── favicon.png        # 网站图标
├── .env.example           # 环境变量示例
├── package.json           # 项目配置
└── vite.config.ts         # Vite 配置
```

## 支持与反馈

- **GitHub Issues**: https://github.com/itq5/OpenClaw-Admin/issues
- **开源社区**: http://www.gitvv.com/

## 许可证

MIT License
