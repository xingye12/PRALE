# WattClaw - 多人隔离测试版

本目录用于同一服务器上的多人独立开发测试。不要直接运行旧的 `docker compose up`；每份项目先配置独立的 `.env`，再通过 `npm run deploy:test` 启动。完整说明见 [TEST_DEPLOYMENT.md](./TEST_DEPLOYMENT.md)。

OpenClaw Gateway 的 Web 管理后台，提供智能体、会话、模型、渠道的集中管理与实时监控。

## 架构

```
浏览器
  │ HTTP / SSE / WebSocket
  ▼
Express 后端 (server/)  ←── WebSocket ──→  OpenClaw Gateway (外部服务)
  │                                           默认 ws://localhost:18789
  ├── 认证 (JWT + 角色权限)
  ├── 文件管理 / 终端 / 远程桌面
  └── SQLite (data/wizard.db)
      │
Vue 3 前端 (src/)
  ├── Naive UI 组件库
  ├── Pinia 状态管理
  └── vue-i18n 国际化 (中/英)
```

## 技术栈

| 层 | 技术 |
|---|---|
| 前端 | Vue 3.5 + TypeScript 5.9 + Vite 7 + Naive UI + Pinia 3 |
| 后端 | Node.js + Express 5 + WebSocket (ws 8) |
| 数据库 | SQLite (better-sqlite3) |
| 部署 | Docker + Docker Compose |

## 快速开始

### 环境要求

- Node.js >= 18, npm >= 9
- 可访问的 OpenClaw Gateway 实例

### 安装

```bash
npm install
cp .env.example .env   # 编辑 .env 配置网关地址和 token
```

### 本地运行

```bash
./start.sh             # 一键启动前后端
# 或分别启动
npm run dev:all        # 前后端同时启动
npm run dev:server     # 仅后端
```

- 前端: http://localhost:3000
- 后端: http://localhost:3001
- 默认账号: `admin` / `admin123`（在 `.env` 中配置）

### Docker 隔离测试部署

```bash
cp .env.test.example .env
# 修改 INSTANCE_ID、TEST_APP_PORT、TEST_GATEWAY_PORT_BASE 和测试密码
npm run deploy:test
```

首次部署会自动初始化 `admin`、`test1`、`test2` 三个测试账号；容器、网络、端口和 `runtime/` 数据目录按实例隔离。

## 核心功能

- **智能体管理**: 创建、配置多智能体，支持角色与能力分工
- **会话管理**: 查看会话列表、历史消息、导出与重置
- **模型管理**: 配置模型通道、密钥与默认模型策略
- **渠道管理**: 维护 QQ、飞书、钉钉、企微等接入通道
- **系统监控**: CPU、内存、磁盘等实时指标
- **远程终端**: SSH 终端与文件管理
- **协作场景**: 智能体工坊、虚拟场景编排
- **定时任务**: Cron 任务调度
- **备份恢复**: 系统备份与恢复管理
- **多用户**: 用户管理、角色权限（admin/user）

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `PORT` | 3001 | 后端端口 |
| `OPENCLAW_WS_URL` | ws://localhost:18789 | OpenClaw 网关地址 |
| `OPENCLAW_AUTH_TOKEN` | - | 网关认证 token |
| `AUTH_USERNAME` | - | 管理员用户名 |
| `AUTH_PASSWORD` | - | 管理员密码 |
| `FEISHU_BOT_CREDENTIAL_KEY` | - | 用户级飞书机器人 App Secret 加密密钥，部署后必须保持稳定 |
| `LOG_LEVEL` | INFO | 日志级别 (INFO/DEBUG) |

## 项目结构

```
src/
  api/          # WebSocket、RPC 客户端、HTTP 通信层、类型定义
  views/        # 页面组件 (路由级，命名为 *Page.vue)
  components/   # 通用组件、布局组件、Office 场景组件
  stores/       # Pinia 状态管理 (22 个 store)
  composables/  # 可组合函数 (useTheme, useEventStream, useResizable)
  router/       # 路由配置与认证守卫
  i18n/         # 国际化 (zh-CN / en-US)
  utils/        # 工具函数 (format, markdown, secret-mask)

server/
  index.js      # Express 主服务 (API 路由、认证、文件/终端管理)
  gateway.js    # OpenClaw 网关 WebSocket 客户端 (设备认证、RPC)
  database.js   # SQLite 数据库 Schema 与操作
  user-manager.js  # 用户认证、角色权限、Token 管理

scripts/
  entrypoint.sh # Docker 容器启动脚本
start.sh        # 本地一键启动
restart.sh      # 一键重启
```

## 开发命令

```bash
npm run dev          # Vite 前端开发服务
npm run dev:server   # Express 后端
npm run dev:all      # 前后端同时启动
npm run build        # vue-tsc 类型检查 + Vite 构建
npx vue-tsc --noEmit # 仅类型检查
```

## Git 仓库

http://123.56.242.156:8880/openclaw/wattclaw

## License

MIT
