# 多人独立测试部署

## 一、人员配置表（先看这里）

每个人必须使用自己的独立项目目录，并严格按照自己的行配置 `.env`。

| 人员 | `INSTANCE_ID` | Web 端口 | Gateway 端口 | 管理员密码 | PostgreSQL 密码 |
|---|---|---:|---|---|---|
| 乐 | `le` | `30101` | `31101-31102` | `LeAdmin2026A7q9K2` | `LePostgres2026P8m4X6` |
| 伯 | `bo` | `30102` | `31111-31112` | `BoAdmin2026B7r9L3` | `BoPostgres2026P6n8W4` |
| 帅 | `shuai` | `30103` | `31121-31122` | `ShuaiAdmin2026S9x4M7` | `ShuaiPostgres2026P5v8Q2` |
| 皇 | `huang` | `30104` | `31131-31132` | `HuangAdmin2026H6m9R3` | `HuangPostgres2026P4k7T8` |
| 皓 | `hao` | `30105` | `31141-31142` | `HaoAdmin2026K5p8N4` | `HaoPostgres2026P9c6Y3` |

公共测试账号：

| 账号 | 密码 | 权限 |
|---|---|---|
| `admin` | 使用上表中各自的管理员密码 | 管理员 |
| `test1` | `test123456` | 普通用户 |
| `test2` | `test123456` | 普通用户 |

## 二、每个人的部署步骤

### 1. 准备配置

```bash
cp .env.test.example .env
chmod 600 .env
```

### 2. 按表格修改以下 5 项

```env
INSTANCE_ID=自己的实例ID
TEST_APP_PORT=自己的Web端口
TEST_GATEWAY_PORT_BASE=自己的Gateway端口段第一个端口
AUTH_PASSWORD=自己的管理员密码
TEST_POSTGRES_PASSWORD=自己的PostgreSQL密码
```

以下配置必须保持为空，由脚本根据 `INSTANCE_ID` 自动生成：

```env
COMPOSE_PROJECT_NAME=
OPENCLAW_NETWORK=
OPENCLAW_CONTAINER_PREFIX=
```

不要复制其他人已经生成的 `runtime/` 目录。

### 3. 启动

```bash
npm run deploy:test
```

首次部署会自动初始化数据库，并创建 `admin`、`test1`、`test2` 三个账号。

## 三、常用管理命令

更新代码并保留数据：

```bash
npm run deploy:test
```

清空当前实例并重新创建三个测试账号：

```bash
npm run deploy:test:fresh
```

停止当前实例但保留数据：

```bash
npm run stop:test
```

查看服务器上所有测试实例及实际端口：

```bash
docker ps \
  --filter 'label=wattclaw.instance' \
  --format 'table {{.Label "wattclaw.instance"}}\t{{.Names}}\t{{.Ports}}\t{{.Status}}'
```

## 四、自动隔离内容

部署脚本会根据 `INSTANCE_ID` 自动隔离：

- Compose 项目名：例如 `wattclaw-le`。
- Docker 网络：例如 `wattclaw-le-net`。
- OpenClaw 容器：例如 `openclaw-le-1`、`openclaw-le-2`。
- Web、Gateway 端口和项目内数据目录。
- PostgreSQL 不映射宿主机端口，仅允许当前实例内部访问。

每个实例稳定运行时默认有 4 个容器：Web、PostgreSQL 和两个 OpenClaw 租户容器。

所有持久化数据均保存在各自项目的 `runtime/`：

```text
runtime/
├── app-data/
├── uploads/
├── postgres/
├── gateway/
├── tenants/
├── wattclaw/
├── agents/
└── skills-store/
```

## 五、简要注意事项

- 只能通过 `npm run deploy:test` 部署，不要直接运行旧的 `docker compose up`。
- `INSTANCE_ID`、Web 端口和 Gateway 端口不得与其他人重复。
- `.env`、`runtime/` 和测试密码不要对外公开。
- 默认 Docker Socket 能管理宿主机全部容器；需要安全隔离时，应为每个人使用独立的 Rootless Docker。
- `runtime/` 没有自动磁盘配额，需要时应在服务器上配置用户或项目磁盘配额。
