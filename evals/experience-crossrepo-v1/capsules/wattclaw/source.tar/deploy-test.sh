#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$SCRIPT_DIR"

ACTION="${1:-deploy}"
ENV_FILE="${TEST_ENV_FILE:-.env}"
COMPOSE_FILE="docker-compose.test.yml"

if [ ! -f "$ENV_FILE" ]; then
  echo "缺少 $ENV_FILE，请先执行：cp .env.test.example $ENV_FILE" >&2
  exit 1
fi

read_env() {
  local key="$1"
  local value
  value="$(sed -n "s/^${key}=//p" "$ENV_FILE" | tail -n 1 | tr -d '\r')"
  printf '%s' "$value"
}

INSTANCE_ID="$(read_env INSTANCE_ID)"
if ! printf '%s' "$INSTANCE_ID" | grep -Eq '^[a-z0-9][a-z0-9-]{1,30}$'; then
  echo "INSTANCE_ID 必须为 2-31 位小写字母、数字或连字符" >&2
  exit 1
fi

export PROJECT_ROOT="$SCRIPT_DIR"
configured_project_name="$(read_env COMPOSE_PROJECT_NAME)"
export COMPOSE_PROJECT_NAME="wattclaw-${INSTANCE_ID}"
if [ -n "$configured_project_name" ] && [ "$configured_project_name" != "$COMPOSE_PROJECT_NAME" ]; then
  echo "COMPOSE_PROJECT_NAME 只能使用 $COMPOSE_PROJECT_NAME，或留空由脚本生成" >&2
  exit 1
fi
configured_network="$(read_env OPENCLAW_NETWORK)"
export OPENCLAW_NETWORK="${COMPOSE_PROJECT_NAME}-net"
if [ -n "$configured_network" ] && [ "$configured_network" != "$OPENCLAW_NETWORK" ]; then
  echo "OPENCLAW_NETWORK 只能使用 $OPENCLAW_NETWORK，或留空由脚本生成" >&2
  exit 1
fi
export OPENCLAW_CONTAINER_PREFIX="$(read_env OPENCLAW_CONTAINER_PREFIX)"
export OPENCLAW_CONTAINER_PREFIX="${OPENCLAW_CONTAINER_PREFIX:-openclaw-${INSTANCE_ID}}"
export TEST_ENV_FILE="$ENV_FILE"

docker_socket_path="$(read_env DOCKER_SOCKET_PATH)"
docker_socket_path="${docker_socket_path:-/var/run/docker.sock}"
if [ "$docker_socket_path" != "/var/run/docker.sock" ] && [ -z "${DOCKER_HOST:-}" ]; then
  export DOCKER_HOST="unix://${docker_socket_path}"
fi

case "$OPENCLAW_CONTAINER_PREFIX" in
  "openclaw-${INSTANCE_ID}"|"openclaw-${INSTANCE_ID}-"*) ;;
  *)
    echo "OPENCLAW_CONTAINER_PREFIX 必须以 openclaw-${INSTANCE_ID} 开头" >&2
    exit 1
    ;;
esac

compose() {
  docker compose --env-file "$ENV_FILE" -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" "$@"
}

assert_instance_ownership() {
  local ids container_id owner_root network_root
  ids="$(docker ps -aq --filter "label=wattclaw.instance=${INSTANCE_ID}")"
  for container_id in $ids; do
    owner_root="$(docker inspect --format '{{ index .Config.Labels "wattclaw.project-root" }}' "$container_id")"
    if [ "$owner_root" != "$PROJECT_ROOT" ]; then
      echo "实例 ID $INSTANCE_ID 已被其他项目目录使用：${owner_root:-未知目录}" >&2
      exit 1
    fi
  done

  if docker network inspect "$OPENCLAW_NETWORK" >/dev/null 2>&1; then
    network_root="$(docker network inspect --format '{{ index .Labels "wattclaw.project-root" }}' "$OPENCLAW_NETWORK")"
    if [ "$network_root" != "$PROJECT_ROOT" ]; then
      echo "Docker 网络 $OPENCLAW_NETWORK 已属于其他项目目录：${network_root:-未知目录}" >&2
      exit 1
    fi
  fi
}

assert_port_available() {
  local port="$1"
  local purpose="$2"
  local ids container_id owner_root
  ids="$(docker ps -q --filter "publish=${port}")"
  for container_id in $ids; do
    owner_root="$(docker inspect --format '{{ index .Config.Labels "wattclaw.project-root" }}' "$container_id")"
    if [ "$owner_root" != "$PROJECT_ROOT" ]; then
      echo "$purpose 端口 $port 已被其他 Docker 容器占用" >&2
      exit 1
    fi
  done
  if [ -z "$ids" ] && command -v ss >/dev/null 2>&1 && ss -ltnH "sport = :${port}" | grep -q .; then
    echo "$purpose 端口 $port 已被宿主机其他进程占用" >&2
    exit 1
  fi
}

validate_ports() {
  local app_port gateway_base initial_tenants max_tenants max_users gateway_end port
  app_port="$(read_env TEST_APP_PORT)"
  app_port="${app_port:-3004}"
  gateway_base="$(read_env TEST_GATEWAY_PORT_BASE)"
  gateway_base="${gateway_base:-29789}"
  max_tenants="$(read_env OPENCLAW_MAX_TENANTS)"
  max_tenants="${max_tenants:-2}"
  initial_tenants="$(read_env OPENCLAW_INITIAL_TENANTS)"
  initial_tenants="${initial_tenants:-2}"
  max_users="$(read_env OPENCLAW_MAX_USERS)"
  max_users="${max_users:-2}"

  for port in "$app_port" "$gateway_base" "$initial_tenants" "$max_tenants" "$max_users"; do
    if ! printf '%s' "$port" | grep -Eq '^[0-9]+$'; then
      echo "端口和租户数量必须为正整数" >&2
      exit 1
    fi
  done
  if [ "$initial_tenants" -lt 1 ] || [ "$max_tenants" -lt 1 ] || [ "$max_users" -lt 1 ] || [ "$initial_tenants" -gt "$max_tenants" ]; then
    echo "OPENCLAW_INITIAL_TENANTS、OPENCLAW_MAX_TENANTS 和 OPENCLAW_MAX_USERS 必须为正整数，且初始租户数不能超过最大租户数" >&2
    exit 1
  fi
  gateway_end=$((gateway_base + max_tenants - 1))
  if [ "$app_port" -lt 1 ] || [ "$app_port" -gt 65535 ] || [ "$gateway_base" -lt 1 ] || [ "$gateway_end" -gt 65535 ]; then
    echo "端口必须位于 1-65535，Gateway 端口段不能越界" >&2
    exit 1
  fi
  if [ "$app_port" -ge "$gateway_base" ] && [ "$app_port" -le "$gateway_end" ]; then
    echo "TEST_APP_PORT 不能落在 Gateway 端口段 ${gateway_base}-${gateway_end} 内" >&2
    exit 1
  fi

  assert_port_available "$app_port" "Web"
  for port in $(seq "$gateway_base" "$gateway_end"); do
    assert_port_available "$port" "Gateway"
  done
}

prepare_runtime() {
  mkdir -p \
    runtime/app-data \
    runtime/uploads \
    runtime/postgres \
    runtime/gateway \
    runtime/tenants \
    runtime/wattclaw \
    runtime/agents \
    runtime/skills-store
}

remove_instance_tenants() {
  local ids
  ids="$(docker ps -aq --filter "label=openclaw.gateway.managed=true" --filter "label=wattclaw.instance=${INSTANCE_ID}" --filter "label=wattclaw.project-root=${PROJECT_ROOT}")"
  if [ -n "$ids" ]; then
    docker rm -f $ids
  fi
}

clear_runtime_data() {
  compose run --rm --no-deps --entrypoint sh wattclaw-test -lc '
    for dir in /app/data /app/uploads /home/wattman/.openclaw /app/openclaw-host-data "$OPENCLAW_WATTCLAW_HOST_DIR" "$OPENCLAW_AGENTS_SHARE_HOST_DIR"; do
      find "$dir" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
    done
  '
  compose run --rm --no-deps --user 0:0 --entrypoint sh postgres-test -lc '
    find /var/lib/postgresql/data -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
  '
}

assert_instance_ownership

if [ "$ACTION" = "stop" ]; then
  remove_instance_tenants
  compose down
  echo "已停止实例 $INSTANCE_ID，runtime 数据未删除"
  exit 0
fi

if [ "$ACTION" != "deploy" ] && [ "$ACTION" != "fresh" ]; then
  echo "用法：./deploy-test.sh [deploy|fresh|stop]" >&2
  exit 1
fi

validate_ports
prepare_runtime

if [ "$ACTION" = "deploy" ] && [ ! -f "$PROJECT_ROOT/runtime/app-data/wizard.db" ]; then
  echo "检测到当前实例尚未初始化，首次部署将自动创建干净测试数据"
  ACTION="fresh"
fi

echo "========================================"
echo "  WattClaw 独立测试实例"
echo "  实例 ID: $INSTANCE_ID"
echo "  Compose 项目: $COMPOSE_PROJECT_NAME"
echo "  Docker 网络: $OPENCLAW_NETWORK"
echo "  租户前缀: $OPENCLAW_CONTAINER_PREFIX"
echo "  数据目录: $PROJECT_ROOT/runtime"
echo "========================================"

npm ci
npm run build:test

if [ "$ACTION" = "fresh" ]; then
  remove_instance_tenants
  compose down
  compose build wattclaw-test
  clear_runtime_data
  compose run --rm -e TEST_DATA_RESET=confirm wattclaw-test node server/scripts/reset-test-data.js
  compose up -d
else
  compose up -d --build
fi

container_id="$(compose ps -q wattclaw-test)"
healthy=false
for _ in $(seq 1 15); do
  if [ -n "$container_id" ] && docker exec "$container_id" node -e "require('http').get('http://localhost:3001/api/health', r => process.exit(r.statusCode === 200 ? 0 : 1)).on('error', () => process.exit(1))" 2>/dev/null; then
    echo "Web 健康检查通过"
    healthy=true
    break
  fi
  sleep 2
done

if [ "$healthy" != "true" ]; then
  echo "Web 健康检查尚未通过，请使用 docker compose logs 查看启动日志" >&2
fi

# Web 服务就绪不代表可以登录：租户 Gateway 容器由后端在启动后异步创建，
# 需要拉起 + 安装插件 + 重启，全部 healthy 后登录才能正常进入平台。
# 这里等待预期数量的租户容器全部就绪，让脚本"部署完成"等于真正可用。
expected_tenants="$(read_env OPENCLAW_INITIAL_TENANTS)"
expected_tenants="${expected_tenants:-2}"
tenant_wait_timeout="$(read_env TEST_TENANT_WAIT_TIMEOUT)"
tenant_wait_timeout="${tenant_wait_timeout:-900}"

tenant_status() {
  # 输出：<就绪数> <总数>；就绪定义为 running 且 health 为 healthy 或 none。
  local ids id state health ready=0 total=0
  ids="$(docker ps -aq \
    --filter "label=openclaw.gateway.managed=true" \
    --filter "label=wattclaw.instance=${INSTANCE_ID}" \
    --filter "label=wattclaw.project-root=${PROJECT_ROOT}")"
  for id in $ids; do
    total=$((total + 1))
    state="$(docker inspect --format '{{.State.Status}}' "$id" 2>/dev/null || echo unknown)"
    health="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$id" 2>/dev/null || echo unknown)"
    if [ "$state" = "running" ] && { [ "$health" = "healthy" ] || [ "$health" = "none" ]; }; then
      ready=$((ready + 1))
    fi
  done
  printf '%s %s' "$ready" "$total"
}

echo "等待 ${expected_tenants} 个租户容器就绪（最长 ${tenant_wait_timeout}s）……"
tenants_ready=false
deadline=$(( $(date +%s) + tenant_wait_timeout ))
while [ "$(date +%s)" -lt "$deadline" ]; do
  read -r ready total <<EOF
$(tenant_status)
EOF
  if [ "$total" -ge "$expected_tenants" ] && [ "$ready" -ge "$expected_tenants" ]; then
    echo "租户容器就绪：${ready}/${total}"
    tenants_ready=true
    break
  fi
  echo "  租户就绪进度：${ready}/${total}（期望 ${expected_tenants}），继续等待……"
  sleep 5
done

app_port="$(read_env TEST_APP_PORT)"
app_port="${app_port:-3004}"

if [ "$healthy" != "true" ] || [ "$tenants_ready" != "true" ]; then
  echo "部署尚未完全就绪，暂时无法保证可以登录。" >&2
  echo "请运行 ./status.sh -w 持续监控，或用 docker compose logs 查看启动日志。" >&2
  echo "访问地址：http://服务器地址:${app_port}"
  exit 1
fi

echo "部署完成，全部容器就绪，可以登录：http://服务器地址:${app_port}"
echo "查看状态：PROJECT_ROOT='$PROJECT_ROOT' OPENCLAW_NETWORK='$OPENCLAW_NETWORK' docker compose --env-file '$ENV_FILE' -p '$COMPOSE_PROJECT_NAME' -f '$COMPOSE_FILE' ps"
