# 🏛️ WattClaw 全局静态代码审计报告

> **审计人**: 资深系统架构师 & 源码审计专家
> **审计日期**: 2026-06-03
> **审计范围**: `src/` + `server/` 全量源码（205 个文件）
> **审计维度**: LOC / 圈复杂度 / 状态耦合度 / Token 消耗权重

---

## 🧱 一、项目全局审计综述

### 代码规模

| 维度 | 数值 |
|------|------|
| **项目总 LOC** | **91,221 行** |
| 前端（src/，167 文件） | 80,778 行（88.5%） |
| 后端（server/，38 文件） | 10,443 行（11.5%） |
| **超过 1000 行的大文件** | **23 个** |
| 大文件总 LOC | ~48,100 行 |
| **大文件占项目比例** | **52.7%** |

> ⚠️ 超过一半的代码量集中在 23 个巨型文件中。这是一个极度典型的 **"少数巨石撑起整座大厦"** 的腐化架构。

### 架构腐化定性评估：🔴 深度重度腐化

**诊断结论**：项目已进入**深度架构腐化（Severe Architecture Decay）** 阶段。核心症状：

1. **God Component 泛滥** — 多个 Vue SFC 承担 8-12 个不相关职责，违反 SRP（单一职责原则）
2. **职责倒置** — View 层嵌入了完整的业务逻辑引擎（路径搜索、配置解析、Cron 格式化），本应属于 Utils/Service 层
3. **DRY 全面崩塌** — 消息解析器在 `ChatPage.vue` 和 `AgentChatPanel.vue` 之间几乎原样复制（~550 行），配置解析逻辑在 `ModelsPage.vue` 和 `rpc-client.ts` 中重复实现
4. **Token 消耗灾难** — 排名前 5 的文件合计约 **140,000-150,000 tokens**，意味着 LLM 一次仅能完整读取 2-3 个文件就耗尽上下文

### 全量文件热力图（>500 行）

```
>= 3000 行  ████████████████████████████████  4 个文件（红色警戒）
>= 2000 行  ██████████████████████            5 个文件（橙色警告）
>= 1000 行  ████████████████                  14 个文件（黄色关注）
>= 500 行   ████████                          ~20 个文件
< 500 行    ██████████████████████████████████ ~160 个文件（健康）
```

---

## 📋 二、冗长文件黑榜（Top 5 Worst Files）

> 按重构迫切度从高到低排序。评估维度：LOC × 圈复杂度 × 状态耦合 × Token 权重。

---

### 🎯 NO.1 `src/views/chat/ChatPage.vue`

| 指标 | 数值 |
|------|------|
| **总行数** | **3,606 行** |
| **预估 Token 占用** | **~28,000 - 32,000** |
| **核心函数数量** | **69 个**（48 函数 + 27 computed + 3 watch） |
| **响应式状态数** | **61 个**（25 ref + 1 reactive + 32 computed + 3 watch） |
| **最高圈复杂度** | **CC ≈ 30+**（`parseStructuredMessage`） |
| **混合职责数** | **12+** |

#### 💀 业务杂糅度

这个文件**同时是**：

| # | 职责 | 行数范围 | 应该在哪里 |
|---|------|---------|-----------|
| 1 | Session 管理（选择、持久化、路由解析） | 154-1162 | Composable: `useChatSession()` |
| 2 | Token 用量追踪（获取、展示、格式化） | 187-325 | Composable: `useTokenUsage()` |
| 3 | **消息解析引擎**（10+ 解析函数） | 340-1768 | 纯 TS 模块: `chatMessageParser.ts` |
| 4 | JSON 解析工具库 | 1361-1547 | 工具: `jsonParser.ts` |
| 5 | Markdown 渲染 | 1164-1204 | 工具: 已有 `useMarkdownIt` |
| 6 | 滚动管理（自动跟随、debounce、微任务） | 1206-1298 | Composable: `useAutoScroll()` |
| 7 | 快捷回复 CRUD（localStorage 持久化） | 85-1889 | Composable: `useQuickReplies()` |
| 8 | Agent 状态监控（阶段追踪、工具进度） | 702-854 | Composable: `useAgentStatus()` |
| 9 | 模型配置解析 | 900-1096 | Composable: `useModelConfig()` |
| 10 | 图片处理（预览、路径归一化） | 141-476 | Composable: `useChatImages()` |
| 11 | WebSocket 事件路由 | 1960-1986 | Store/Composable |
| 12 | 类型强转工具函数 | 1315-1359 | 工具: `typeHelpers.ts` |

#### 🔴 核心坏味道

- **纯逻辑寄生在 View 层**：`parseStructuredMessage`（138 行, CC≈30）和 `parseJsonItems`（64 行）是纯 TypeScript 函数，**零 Vue 响应式依赖**，却嵌入在 `<script setup>` 中
- **与 AgentChatPanel.vue 大面积代码克隆**：消息解析器（~550 行）、快捷回复系统（~120 行）、图片处理（~130 行）几乎逐字复制
- **7 个内联 TypeScript 接口**：`StructuredMessageView` 等关键类型定义被锁在组件内，无法跨组件共享
- **内联类型强转工具**：`asRecord`、`asString`、`asText`、`asNumber` 在多处文件重复定义

#### 🔧 重构预后方案

| 拆分模块 | 预估行数 | 说明 |
|----------|---------|------|
| `ChatPage.vue`（本体） | **~400 行** | 仅保留模板 + 组合调用 |
| `chatMessageParser.ts` | ~500 行 | 消息解析引擎（纯函数） |
| `useQuickReplies.ts` | ~150 行 | 快捷回复 Composable |
| `useAutoScroll.ts` | ~80 行 | 滚动管理 |
| `useTokenUsage.ts` | ~120 行 | Token 用量 |
| `useChatSession.ts` | ~100 行 | Session 管理 |

---

### 🎯 NO.2 `src/views/models/ModelsPage.vue`

| 指标 | 数值 |
|------|------|
| **总行数** | **3,353 行** |
| **预估 Token 占用** | **~30,000 - 34,000**（项目最高） |
| **核心函数数量** | **62 个**（37 函数 + 25 computed + 2 watch） |
| **响应式状态数** | **41 个**（10 ref + 4 reactive + 25 computed + 2 watch） |
| **最高圈复杂度** | **CC ≈ 14-16**（`editChangePreview`） |
| **混合职责数** | **8** |

#### 💀 业务杂糅度

| # | 职责 | 行数范围 | 严重程度 |
|---|------|---------|---------|
| 1 | **配置解析引擎**（JSON 遍历、模型引用提取） | 215-575 | 🔴 应为独立 Utils |
| 2 | **Defaults 模型目录同步子系统** | 1280-1735 | 🔴 450 行纯逻辑，零 UI 依赖 |
| 3 | REST API 客户端层 | 43-57, 581-598 | 🟡 admin/non-admin 路径重复 |
| 4 | 快速预设 Provider | 90-170, 2142-2222 | 🟡 内联硬编码 |
| 5 | Provider CRUD 表单管理 | 172-999 | 🟡 双表单（编辑+创建）并行 |
| 6 | 主模型管理 | 1834-1895 | 🟢 可接受 |
| 7 | 数据表格渲染（`h()` 函数） | 1023-1198 | 🟡 列定义 155 行 |
| 8 | 布局与样式 | 3081-3353 | 🟢 |

#### 🔴 核心坏味道

- **配置解析引擎 360 行** + **目录同步子系统 450 行** = **810 行纯逻辑** 完全不需要 Vue，却寄生在一个 View 组件内。这是 Token 浪费的最大源头
- **admin/non-admin 代码路径三重复制**：`handleSaveProvider`、`handleCreateProvider`、`handleDeleteProvider` 各自包含几乎相同的 admin 和 non-admin 分支
- **Token 消耗冠军**：单个文件 ~34K tokens，占一个 200K 上下文窗口的 **17%**

#### 🔧 重构预后方案

| 拆分模块 | 预估行数 | 说明 |
|----------|---------|------|
| `ModelsPage.vue`（本体） | **~600 行** | 模板 + 事件处理 |
| `provider-config-parser.ts` | ~400 行 | 配置解析引擎（纯函数） |
| `defaults-catalog-sync.ts` | ~450 行 | 目录同步子系统（纯函数） |
| `useProviderForm.ts` | ~300 行 | 表单管理 Composable |
| `useProviderCrud.ts` | ~200 行 | CRUD + API 调用（消除 admin 分支重复） |

---

### 🎯 NO.3 `src/views/myworld/MyWorldPage.vue`

| 指标 | 数值 |
|------|------|
| **总行数** | **3,783 行**（项目最大文件） |
| **预估 Token 占用** | **~26,000** |
| **核心函数数量** | **54 个**（35 函数 + 11 computed + 4 watch） |
| **响应式状态数** | **50 个**（35 ref + 11 computed + 4 watch） |
| **最高圈复杂度** | **CC ≈ 12**（`findPathAStar`） |
| **混合职责数** | **9** |

#### 💀 业务杂糅度

| # | 职责 | 行数 | 严重程度 |
|---|------|------|---------|
| 1 | **A\* 路径搜索引擎** | 305-574（270 行） | 🔴 完整游戏引擎逻辑 |
| 2 | **角色动画系统**（行走/空闲/漫游状态机） | 594-722, 1181-1308 | 🔴 200+ 行 |
| 3 | **场景视口管理**（平移/缩放/变换矩阵） | 774-1175 | 🔴 |
| 4 | **CSS 像素艺术设计系统** | 2119-3783（**1,665 行**） | 🔴 **44% 的文件是 CSS** |
| 5 | 办公室平面图定义 | 188-303 | 🟡 |
| 6 | Session CRUD | 838-1078 | 🟡 |
| 7 | Agent 权限管理对话框 | 868-997 | 🟡 |
| 8 | Tooltip / 剪贴板交互 | 1395-1465 | 🟢 |
| 9 | 实时事件订阅 | 1467-1540 | 🟢 |

#### 🔴 核心坏味道

- **CSS 占文件 44%**：1,665 行手写 CSS 定义了桌子、椅子、显示器、角色身体部位（头/发/眼/躯干/四肢）、行走动画、呼吸动画、选中脉冲等，本身就是一套完整的设计系统
- **A\* 寻路引擎寄生在 Vue 组件中**：`findPathAStar`（113 行）是标准的图搜索算法，与 Vue 响应式毫无关系
- **架构最荒谬的文件**：一个 Vue 页面组件 = 游戏引擎 + 动画系统 + CSS 艺术品 + 业务 CRUD

#### 🔧 重构预后方案

| 拆分模块 | 预估行数 | 说明 |
|----------|---------|------|
| `MyWorldPage.vue`（本体） | **~500 行** | 模板 + 组合调用 |
| `office-pathfinding.ts` | ~280 行 | A* + 碰撞检测（纯函数） |
| `office-scene-renderer.ts` | ~300 行 | 视口 + 场景管理 |
| `character-animation.ts` | ~250 行 | 角色状态机 + 动画循环 |
| `myworld-styles.css` | ~1,600 行 | 像素艺术样式（独立 CSS 文件） |
| `MyWorldScene.vue` | ~400 行 | 场景 Canvas 子组件 |

---

### 🎯 NO.4 `src/components/office/AgentChatPanel.vue`

| 指标 | 数值 |
|------|------|
| **总行数** | **3,122 行** |
| **预估 Token 占用** | **~25,000 - 28,000** |
| **核心函数数量** | **63 个**（37 函数 + 24 computed + 2 watch） |
| **响应式状态数** | **44 个**（17 ref + 1 reactive + 24 computed + 2 watch） |
| **最高圈复杂度** | **CC ≈ 20-25**（`parseStructuredMessage`） |
| **混合职责数** | **10** |

#### 💀 业务杂糅度

| # | 职责 | 行数范围 | 严重程度 |
|---|------|---------|---------|
| 1 | **消息解析/结构化视图子系统** | 407-1187（**780 行**） | 🔴 与 ChatPage.vue 近乎克隆 |
| 2 | JSON 工具函数 | 800-986 | 🔴 重复 |
| 3 | 模型配置解析 | 118-246 | 🟡 |
| 4 | 快捷回复 CRUD | 64-405 | 🟡 与 ChatPage.vue 重复 |
| 5 | 滚动管理 | 1446-1556 | 🟡 |
| 6 | Agent 状态展示 | 1235-1371 | 🟡 |
| 7 | Markdown 渲染 | 1389-1436 | 🟡 |
| 8 | **模板重复**：主视图 vs 展开模态框 | 1713-1923 vs 2094-2266 | 🔴 **~550 行近乎相同的模板** |
| 9 | 图片处理 | 604-698 | 🟡 |
| 10 | WebSocket 事件路由 | 1575-1618 | 🟢 |

#### 🔴 核心坏味道

- **与 ChatPage.vue 的代码克隆面积 ~700 行**：消息解析器、快捷回复、图片处理、JSON 工具函数几乎逐字复制
- **模板 DRY 违规**：消息列表渲染在主视图（~210 行）和展开模态框（~170 行）之间重复，仅差一个容器元素
- **780 行消息解析器** 应为独立模块，却被两个组件各自私藏一份

#### 🔧 重构预后方案

| 拆分模块 | 预估行数 | 说明 |
|----------|---------|------|
| `AgentChatPanel.vue`（本体） | **~500 行** | 模板 + 组合调用 |
| `chatMessageParser.ts` | ~500 行 | **共享消息解析引擎**（ChatPage 也引用） |
| `MessageList.vue` | ~250 行 | 消息列表子组件（消除模板重复） |
| `useQuickReplies.ts` | ~150 行 | 共享快捷回复 |
| `useChatScroll.ts` | ~80 行 | 共享滚动管理 |

---

### 🎯 NO.5 `src/stores/workspace.ts`

| 指标 | 数值 |
|------|------|
| **总行数** | **2,640 行** |
| **预估 Token 占用** | **~25,000** |
| **核心函数数量** | **48 个** 导出 + 20 个顶层辅助函数 |
| **响应式状态数** | **31 个**（23 ref + 2 shallowRef + 6 computed） |
| **最高圈复杂度** | **CC ≈ 25-30**（`handleRealtimeEvent`，319 行） |
| **混合职责数** | **8** |

#### 💀 业务杂糅度

| # | 职责 | 状态/函数 |
|---|------|---------|
| 1 | **Agent 管理** | agents, selectedAgentId, expandedAgentId |
| 2 | **Session CRUD & 导航** | activeSessionKey, selectSession, startNewChat |
| 3 | **SSE 流式管道** | handleRealtimeEvent (319行), handleEvent (201行), smartMerge |
| 4 | **消息解析与归一化** | parseHistoryMessages, normalizeRealtimeMessage, extractMessages |
| 5 | **活动追踪** | activeThinkingIds, activeToolIds, finalizeOpenActivities |
| 6 | **通知与未读** | activityTimestamps, unreadMap, sidebarNotified |
| 7 | **历史分页** | historyCursor, historyHasMore, loadOlderMessages |
| 8 | **模型选择与限流** | rateLimitedModels, sessionModelOverrides |

#### 🔴 核心坏味道

- **God Store**：单个 Pinia Store 承担 8 个领域，48 个导出函数远超建议的 5-10 个
- **`handleRealtimeEvent` 319 行**：6 个 `if/else if` 主分支，每个内部再嵌套阶段判断（start/update/result/end），是整个项目最复杂的单个函数
- **`smartMerge` 7 种去重策略**：表明数据流架构是**有机生长**而非设计得出，是最脆弱、最难推理的代码区域
- **顶层 350 行纯函数**（`parseHistoryMessages` 等）在 Store 工厂外部定义，无 Store 状态依赖，应独立为模块

#### 🔧 重构预后方案

| 拆分模块 | 预估行数 | 说明 |
|----------|---------|------|
| `workspace.ts`（本体） | **~600 行** | Agent/Session 基础管理 |
| `message-parser.ts` | ~350 行 | 消息解析（顶层纯函数提取） |
| `useStreamingPipeline.ts` | ~500 行 | SSE 流式处理 Composable |
| `useChatMerge.ts` | ~200 行 | 消息合并/去重逻辑 |
| `useWorkspaceNotifications.ts` | ~150 行 | 未读/通知子系统 |

---

## 🏗️ 三、架构师总体重构路线建议

### 📌 重构优先级排序

```
Phase 1: 提取共享模块（消除代码克隆，ROI 最高）
    ├── chatMessageParser.ts    ← 从 ChatPage + AgentChatPanel 提取 ~780 行共享解析器
    ├── useQuickReplies.ts      ← 从 ChatPage + AgentChatPanel 提取 ~120 行共享快捷回复
    └── typeHelpers.ts          ← 从 3+ 文件提取重复的 asRecord/asString/asText

Phase 2: 拆解 God Component（降低单文件 Token 消耗）
    ├── ChatPage.vue            ← 3606 → ~400 行（12 → 1 职责）
    ├── AgentChatPanel.vue      ← 3122 → ~500 行（提取 MessageList 子组件消除模板重复）
    └── CronPage.vue            ← 2638 → ~600 行（提取 cron-format.ts ~220 行）

Phase 3: 拆解 God Store（降低状态耦合）
    └── workspace.ts            ← 2640 → ~600 行（提取 streaming pipeline + merge + notifications）

Phase 4: 纯逻辑提取（配置引擎、游戏引擎）
    ├── ModelsPage.vue          ← 提取 provider-config-parser.ts + defaults-catalog-sync.ts (~810 行)
    └── MyWorldPage.vue         ← 提取 pathfinding + animation + 独立 CSS (~2400 行)

Phase 5: 微调与巩固
    ├── rpc-client.ts           ← 提取 normalize* 模式为泛型工具，消除 6 类代码重复
    └── ScenarioWizard.vue / FilesPage.vue 等 2000+ 行文件按需拆分
```

### 📌 跨文件公共逻辑提炼清单

| 公共逻辑 | 当前散布位置 | 建议提取为 |
|----------|-------------|-----------|
| 消息解析引擎 | ChatPage.vue, AgentChatPanel.vue | `src/utils/chatMessageParser.ts` |
| 快捷回复 CRUD | ChatPage.vue, AgentChatPanel.vue | `src/composables/useQuickReplies.ts` |
| 类型强转工具 | rpc-client.ts, ChatPage.vue, AgentChatPanel.vue | `src/utils/typeHelpers.ts` |
| JSON 解析工具 | ChatPage.vue, AgentChatPanel.vue | `src/utils/jsonParser.ts` |
| 模型配置解析 | ModelsPage.vue, ChatPage.vue, AgentChatPanel.vue, rpc-client.ts | `src/utils/modelConfigParser.ts` |
| 滚动管理 | ChatPage.vue, AgentChatPanel.vue | `src/composables/useAutoScroll.ts` |
| Agent 状态展示 | ChatPage.vue, AgentChatPanel.vue | `src/composables/useAgentStatus.ts` |

### 📌 预估重构收益

| 指标 | 当前 | 重构后（预估） |
|------|------|---------------|
| >3000 行文件数 | 4 个 | **0 个** |
| >2000 行文件数 | 9 个 | **0-2 个** |
| 跨文件代码克隆 | ~700 行（ChatPage ↔ AgentChatPanel） | **0** |
| Top 5 文件总 Token | ~140K-150K | ~30K-40K |
| LLM 可同时读取文件数 | 1-2 个 | 8-10 个 |
| 单文件最大圈复杂度 | CC ≈ 30 | CC ≈ 10 |

### 📌 风险与注意事项

1. **ChatPage ↔ AgentChatPanel 共享提取需谨慎**：两个组件的消息解析器虽然结构相似，但细节差异（如 `parseStructuredMessage` 的分支处理）需逐行比对，不能简单合并
2. **workspace.ts 拆分需保持 Store 接口兼容**：外部消费者（ChatInput、MessageList、WorkspaceSidebar 等）依赖 workspace store 的导出 API，拆分后应通过 re-export 保持兼容
3. **MyWorldPage.vue 的 CSS 提取影响最小**：CSS 是纯展示层，提取为独立 `.css` 文件无功能风险
4. **rpc-client.ts 的 normalize* 模式泛化**：需要定义清晰的泛型接口，避免过度抽象

---

## 📎 附录：全量 >1000 行文件清单

| # | 文件路径 | 行数 | 审计评级 |
|---|---------|------|---------|
| 1 | `src/views/myworld/MyWorldPage.vue` | 3,783 | 🔴 Phase 4 |
| 2 | `src/views/chat/ChatPage.vue` | 3,606 | 🔴 Phase 1+2 |
| 3 | `src/views/models/ModelsPage.vue` | 3,353 | 🔴 Phase 4 |
| 4 | `src/components/office/AgentChatPanel.vue` | 3,122 | 🔴 Phase 1+2 |
| 5 | `src/i18n/messages/zh-CN.ts` | 3,066 | 🟢 i18n 翻译文件，非架构问题 |
| 6 | `src/api/rpc-client.ts` | 2,955 | 🟡 Phase 5 |
| 7 | `src/stores/workspace.ts` | 2,640 | 🔴 Phase 3 |
| 8 | `src/views/cron/CronPage.vue` | 2,638 | 🟡 Phase 2 |
| 9 | `src/components/office/ScenarioWizard.vue` | 2,537 | 🟡 Phase 5 |
| 10 | `src/views/files/FilesPage.vue` | 2,195 | 🟡 Phase 5 |
| 11 | `src/components/office/ScenarioManagementPanel.vue` | 1,915 | 🟡 |
| 12 | `src/views/monitor/MonitorPage.vue` | 1,800 | 🟡 |
| 13 | `src/views/office/OfficePage.vue` | 1,624 | 🟡 |
| 14 | `src/views/Dashboard.vue` | 1,487 | 🟡 |
| 15 | `src/views/chat/ChatFilePanel.vue` | 1,371 | 🟡 |
| 16 | `src/views/files/FileManagerPage.vue` | 1,240 | 🟡 |
| 17 | `src/views/memory/MemoryPage.vue` | 1,215 | 🟡 |
| 18 | `server/index.js` | 1,157 | 🟢 已完成模块化拆分 |
| 19 | `src/views/agents/AgentsPage.vue` | 1,146 | 🟡 |
| 20 | `server/handlers/backup.js` | 1,092 | 🟡 |
| 21 | `src/stores/chat.ts` | 1,086 | 🟡 |
| 22 | `src/views/agent-team/AgentEditPage.vue` | 1,028 | 🟡 |
| 23 | `src/views/workspace/MessageList.vue` | 1,010 | 🟡 |

---

> **审计结论**：项目架构腐化程度为 **🔴 重度**。Top 5 文件总计 ~16,000 行，占据项目 17.5% 的代码量，却消耗了 LLM 上下文窗口的 **70%+**。最紧迫的行动是 **Phase 1**——提取 `chatMessageParser.ts` 共享模块，一次消除 ~700 行代码克隆，为后续重构扫清障碍。

---

*本报告由静态代码审计工具生成，未修改任何源代码。*
