# Agent 轨迹可视化功能技术文档

> 本文档详细描述基于 OpenClaw 架构的 Agent 轨迹可视化功能的实现原理、技术细节及前端界面信息展示规范。

---

## 目录

1. [概述](#1-概述)
2. [实现原理](#2-实现原理)
3. [技术实现细节](#3-技术实现细节)
4. [前端界面信息展示](#4-前端界面信息展示)
5. [数据安全与隐私](#5-数据安全与隐私)
6. [扩展与定制](#6-扩展与定制)

---

## 1. 概述

Agent 轨迹可视化（Agent Trajectory Visualization）是指在对话界面的每条消息卡片下方提供一个可交互入口，用户点击后可以查看该条消息在生成过程中经历的完整 Agent 运行轨迹。这一功能的核心价值在于：

- **透明性**：让用户理解 AI 回复是如何一步步产生的
- **可调试性**：开发者可以追踪问题出现在哪个环节
- **信任建立**：展示工具的调用逻辑和决策依据
- **性能分析**：帮助分析耗时瓶颈和资源消耗

---

## 2. 实现原理

Agent 轨迹可视化的实现建立在 **三层架构** 之上：数据层（Data Layer）、事件层（Event Layer）和展示层（Presentation Layer）。

### 2.1 数据层（Data Layer）

数据层负责提供 Agent 运行过程中的所有可观测数据。OpenClaw 的 Gateway 在运行过程中自然产生以下数据源：

#### 2.1.1 会话转录（Session Transcript）

每条消息的完整生命周期被持久化到会话转录中，包含：

| 字段 | 说明 |
|------|------|
| `messageId` | 消息唯一标识 |
| `runId` | 本次 Agent Turn 的运行标识 |
| `sessionKey` | 所属会话 |
| `agentId` | 执行 Agent |
| `role` | 角色（user / assistant / system / tool）|
| `content` | 消息内容 |
| `toolCalls` | 工具调用列表 |
| `toolResults` | 工具执行结果 |
| `metadata` | 元数据（模型、token、耗时等）|
| `timestamp` | 时间戳 |
| `provenance` | 来源信息（是否跨会话消息）|

#### 2.1.2 工具事件流（Tool Event Stream）

Agent 执行工具调用时，Gateway 产生结构化的工具事件：

```json
{
  "type": "session.tool",
  "runId": "run_abc123",
  "toolName": "browser",
  "toolParams": { "action": "open", "url": "https://example.com" },
  "status": "started | in_progress | completed | failed",
  "result": { ... },
  "durationMs": 2345,
  "timestamp": "2026-07-29T11:03:00+08:00"
}
```

#### 2.1.3 子 Agent 调用链（Sub-agent Orchestration）

当 Agent 使用 `sessions_spawn` 委派任务时，产生子 Agent 调用链：

| 字段 | 说明 |
|------|------|
| `childSessionKey` | 子会话标识 |
| `parentRunId` | 父运行标识 |
| `taskName` | 任务名称 |
| `status` | 状态（Pending / InProgress / Success / Failed / Block）|
| `outputs` | 子 Agent 产出物 |
| `elapsedTime` | 执行耗时 |

#### 2.1.4 模型诊断信息（Model Diagnostics）

每次模型调用产生的诊断数据：

| 字段 | 说明 |
|------|------|
| `model` | 使用的模型（如 `openai/gpt-4`）|
| `thinking` | 思考级别 |
| `inputTokens` | 输入 token 数 |
| `outputTokens` | 输出 token 数 |
| `cacheTokens` | 缓存 token 数 |
| `latencyMs` | 模型响应延迟 |
| `finishReason` | 完成原因（stop / length / tool_calls）|

#### 2.1.5 追踪上下文（Trace Context）

OpenClaw 支持 OpenTelemetry 兼容的追踪：

| 字段 | 说明 |
|------|------|
| `traceId` | 分布式追踪 ID |
| `spanId` | 当前 span ID |
| `parentSpanId` | 父 span ID |

### 2.2 事件层（Event Layer）

事件层负责将数据层的原始数据转化为前端可消费的事件流。

#### 2.2.1 WebSocket 事件流

Gateway 通过 WebSocket 向客户端推送实时事件：

```
┌─────────────┐     WebSocket      ┌─────────────┐
│   Gateway   │ ◄────────────────► │   Client    │
│             │   chat events      │  (Control   │
│             │   session.tool     │    UI /     │
│             │   system-presence  │   WebChat)  │
└─────────────┘                    └─────────────┘
```

**核心事件类型：**

| 事件类型 | 说明 | 对应数据层 |
|----------|------|-----------|
| `chat.send` ack | 消息发送确认，返回 `runId` | 消息元数据 |
| `chat` streaming | 消息内容流式推送 | 消息 content |
| `session.tool` | 工具调用状态变更 | 工具事件流 |
| `system-presence` | 系统状态更新 | 运行状态 |
| `chat.history` | 历史记录拉取 | 完整会话转录 |

#### 2.2.2 消息与运行的关联

关键关联机制：**每条 assistant 消息都绑定一个 `runId`**

```
User Message → Gateway → Agent Turn → runId: "run_abc123"
                           │
                           ├─ Model Call (thinking, tokens)
                           ├─ Tool Call #1 (browser.open)
                           ├─ Tool Call #2 (web_fetch)
                           ├─ Sub-agent Spawn
                           └─ Final Response
                                    │
                                    ▼
                           Assistant Message
                           (携带 runId: "run_abc123")
```

前端通过 `runId` 将展示层的消息卡片与数据层的完整轨迹关联起来。

#### 2.2.3 实时 vs 历史数据

| 数据类型 | 获取方式 | 适用场景 |
|----------|----------|----------|
| 实时数据 | WebSocket 事件流 | 正在生成的消息，轨迹实时展开 |
| 历史数据 | `sessions_history(includeTools: true)` | 已完成的对话，点击后拉取 |

### 2.3 展示层（Presentation Layer）

展示层负责将事件流数据转化为用户可理解的可视化界面。

#### 2.3.1 组件架构（这只是一个示例，具体实现流程应该不与当前项目冲突，尽可能复用当前项目）

```
ChatMessage
├── MessageHeader
│   ├── Avatar
│   ├── AgentName
│   └── Timestamp
├── MessageContent
│   └── MarkdownRenderer
├── MessageFooter
│   ├── TokenUsageBadge
│   ├── DurationBadge
│   └── TraceButton ◄── 轨迹入口
└── TraceDrawer (条件渲染)
    ├── TraceTimeline
    │   ├── ModelCallNode
    │   ├── ToolCallNode
    │   ├── SubAgentNode
    │   └── FinalResponseNode
    ├── ToolDetailPanel
    ├── SubAgentChainPanel
    └── RawTracePanel
```

#### 2.3.2 交互流程

```
用户点击 TraceButton
        │
        ▼
┌─────────────────┐
│  检查缓存状态    │
└─────────────────┘
        │
   ┌────┴────┐
   ▼         ▼
已缓存     未缓存
   │         │
   │         ▼
   │  ┌─────────────────┐
   │  │ 调用 sessions_history │
   │  │ (includeTools: true)  │
   │  └─────────────────┘
   │         │
   │         ▼
   │  ┌─────────────────┐
   │  │   解析并缓存轨迹数据   │
   │  └─────────────────┘
   │         │
   └────┬────┘
        ▼
┌─────────────────┐
│   展开 TraceDrawer   │
│   渲染时间线视图     │
└─────────────────┘
```

---

## 3. 技术实现细节

### 3.1 前端状态管理

#### 3.1.1 轨迹数据缓存

为了避免重复拉取，前端需要维护轨迹数据缓存：

```typescript
interface TraceCache {
  [runId: string]: {
    data: AgentTrace;
    fetchedAt: number;
    expiresAt: number;  // 可设置 TTL
  };
}

interface AgentTrace {
  runId: string;
  sessionKey: string;
  agentId: string;
  model: string;
  startTime: string;
  endTime: string;
  durationMs: number;
  phases: TracePhase[];
  tokenUsage: TokenUsage;
  subAgents: SubAgentTrace[];
  rawEvents: RawEvent[];
}
```

#### 3.1.2 实时轨迹构建

对于正在生成的消息，前端通过 WebSocket 事件实时构建轨迹：

```typescript
class TraceBuilder {
  private activeTraces: Map<string, AgentTrace> = new Map();

  handleToolEvent(event: ToolEvent) {
    const trace = this.activeTraces.get(event.runId);
    if (trace) {
      trace.phases.push({
        type: 'tool',
        name: event.toolName,
        status: event.status,
        params: event.toolParams,
        result: event.result,
        startTime: event.timestamp,
        durationMs: event.durationMs
      });
    }
  }

  finalizeTrace(runId: string) {
    const trace = this.activeTraces.get(runId);
    if (trace) {
      trace.endTime = new Date().toISOString();
      this.cache.set(runId, trace);
      this.activeTraces.delete(runId);
    }
  }
}
```

### 3.2 消息-轨迹关联实现

#### 3.2.1 关联方式

**方式一：Gateway 端注入**

Gateway 在返回 assistant 消息时，将 `runId` 注入到消息的 metadata 中：

```json
{
  "id": "msg_001",
  "role": "assistant",
  "content": "...",
  "metadata": {
    "runId": "run_abc123",
    "model": "openai/gpt-4",
    "tokenUsage": { "input": 1024, "output": 512 }
  }
}
```

**方式二：前端映射**

前端维护 `runId → messageId` 映射表，通过发送时的 `chat.send` ack 获取 `runId`：

```typescript
// 发送消息时记录映射
const runId = await gateway.chat.send({ message, sessionKey });
messageRunMap.set(runId, { messageId: optimisticId, status: 'running' });

// 收到 assistant 消息时关联
handleChatEvent(event) {
  if (event.role === 'assistant' && event.runId) {
    const mapping = messageRunMap.get(event.runId);
    if (mapping) {
      mapping.messageId = event.id;
      mapping.status = 'completed';
    }
  }
}
```

**推荐采用方式一**，更可靠且不需要前端维护复杂的状态映射。

### 3.3 数据拉取策略

#### 3.3.1 懒加载（Lazy Loading）

轨迹数据在用户点击前不加载：

```typescript
async function loadTrace(runId: string): Promise<AgentTrace> {
  // 1. 检查缓存
  if (traceCache.has(runId)) {
    return traceCache.get(runId)!;
  }

  // 2. 调用 Gateway RPC
  const history = await gateway.sessions_history({
    sessionKey: currentSession,
    includeTools: true,
    limit: 100
  });

  // 3. 解析并过滤出该 runId 相关的事件
  const trace = parseTraceFromHistory(history, runId);

  // 4. 写入缓存
  traceCache.set(runId, trace);

  return trace;
}
```

#### 3.3.2 增量更新

对于已展开的轨迹，如果 Agent 仍在运行，通过 WebSocket 增量更新：

```typescript
useEffect(() => {
  if (!isTraceOpen || !isRunActive) return;

  const unsubscribe = gateway.on('session.tool', (event) => {
    if (event.runId === currentRunId) {
      setTrace(prev => appendPhase(prev, event));
    }
  });

  return unsubscribe;
}, [isTraceOpen, isRunActive, currentRunId]);
```

### 3.4 轨迹解析逻辑

从 `sessions_history(includeTools: true)` 返回的数据中解析轨迹：

```typescript
function parseTraceFromHistory(history: ChatHistory, targetRunId: string): AgentTrace {
  const trace: AgentTrace = {
    runId: targetRunId,
    phases: [],
    subAgents: [],
    tokenUsage: { input: 0, output: 0, cache: 0 }
  };

  for (const entry of history.entries) {
    // 匹配该 runId 的 assistant 消息
    if (entry.role === 'assistant' && entry.metadata?.runId === targetRunId) {
      trace.model = entry.metadata.model;
      trace.tokenUsage = entry.metadata.tokenUsage;
      trace.startTime = entry.metadata.startTime;
      trace.endTime = entry.metadata.endTime;
    }

    // 匹配该 runId 的工具调用
    if (entry.role === 'tool' && entry.runId === targetRunId) {
      trace.phases.push({
        type: 'tool',
        name: entry.toolName,
        params: entry.toolParams,
        result: entry.toolResult,
        status: entry.status,
        durationMs: entry.durationMs
      });
    }

    // 匹配子 Agent 调用
    if (entry.role === 'system' && entry.subAgentContext?.parentRunId === targetRunId) {
      trace.subAgents.push(parseSubAgentTrace(entry));
    }
  }

  return trace;
}
```

### 3.5 性能优化

#### 3.5.1 虚拟化渲染

当轨迹包含大量工具调用时，使用虚拟列表：

```typescript
<VirtualList
  items={trace.phases}
  renderItem={(phase) => <TracePhaseNode phase={phase} />}
  overscan={5}
/>
```

#### 3.5.2 大数据截断

对过长的工具结果进行截断展示：

```typescript
const MAX_RESULT_LENGTH = 10000;

function truncateResult(result: any): string {
  const str = JSON.stringify(result, null, 2);
  if (str.length > MAX_RESULT_LENGTH) {
    return str.slice(0, MAX_RESULT_LENGTH) + '\n\n... (truncated)';
  }
  return str;
}
```

#### 3.5.3 防抖加载

防止用户快速点击导致重复请求：

```typescript
const loadTrace = useCallback(
  debounce(async (runId: string) => {
    const trace = await fetchTrace(runId);
    setTrace(trace);
  }, 300),
  []
);
```

---

## 4. 前端界面信息展示

轨迹可视化界面应尽可能完整地展示 Agent 运行的所有可观测信息。以下是按分类整理的完整信息清单。

### 4.1 概览信息区（Overview）

位于轨迹面板顶部，提供本次 Agent Turn 的宏观信息：

| 信息项 | 说明 | 示例 |
|--------|------|------|
| **运行 ID** | 唯一标识本次运行 | `run_abc123xyz` |
| **执行 Agent** | 执行本次运行的 Agent | `main` / `research` |
| **使用模型** | 调用的 LLM 模型 | `openai/gpt-4` |
| **思考级别** | Thinking 设置 | `medium` |
| **开始时间** | Agent Turn 开始时间 | `2026-07-29 11:03:15` |
| **结束时间** | Agent Turn 结束时间 | `2026-07-29 11:03:42` |
| **总耗时** | 从开始到结束的总时间 | `27.3s` |
| **阶段数** | 包含的阶段数量 | `5 phases` |
| **工具调用数** | 调用的工具总数 | `3 tool calls` |
| **子 Agent 数** | 派生的子 Agent 数 | `1 sub-agent` |

### 4.2 Token 使用详情（Token Usage）

| 信息项 | 说明 | 示例 |
|--------|------|------|
| **输入 Token** | 发送给模型的输入 token 数 | `1,024 tokens` |
| **输出 Token** | 模型生成的输出 token 数 | `512 tokens` |
| **缓存 Token** | 命中缓存的 token 数 | `256 tokens` |
| **总计 Token** | 输入 + 输出 | `1,536 tokens` |
| **上下文 Token** | 当前上下文窗口使用量 | `3,200 / 8,192` |
| **Token 成本** | 估算的 API 成本（如配置）| `$0.0042` |

### 4.3 时间线视图（Timeline View）

时间线是轨迹可视化的核心，按时间顺序展示 Agent 运行的各个阶段。

#### 4.3.1 阶段类型

**1. 模型调用阶段（Model Call）**

| 展示项 | 说明 |
|--------|------|
| 模型名称 | `openai/gpt-4` |
| 调用目的 | 初始推理 / 工具结果后的再推理 |
| 输入摘要 | 发送给模型的输入内容摘要（前 500 字符）|
| 输出摘要 | 模型生成的输出摘要 |
| 耗时 | 模型响应延迟 |
| Token 消耗 | 输入 / 输出 token 数 |
| 完成原因 | `stop` / `length` / `tool_calls` |
| 重试次数 | 如遇重试，展示重试次数 |

**2. 工具调用阶段（Tool Call）**

| 展示项 | 说明 |
|--------|------|
| 工具图标 | 工具的图标标识 |
| 工具名称 | `browser` / `web_fetch` / `exec` / `finance_history` 等 |
| 调用状态 | 🟡 进行中 / 🟢 成功 / 🔴 失败 / ⏸️ 阻塞 |
| 调用参数 | 工具的输入参数（JSON 格式化展示）|
| 执行结果 | 工具的输出结果（JSON 格式化展示）|
| 执行耗时 | 工具执行花费的时间 |
| 错误信息 | 如失败，展示错误详情 |
| 重试信息 | 如重试，展示每次重试的详情 |

**3. 子 Agent 委派阶段（Sub-agent Spawn）**

| 展示项 | 说明 |
|--------|------|
| 子 Agent ID | 被委派的子 Agent |
| 任务名称 | `taskName` 参数 |
| 任务描述 | 委派的具体任务内容 |
| 会话标识 | `childSessionKey` |
| 派生时间 | 委派发起时间 |
| 完成时间 | 子 Agent 完成时间 |
| 执行状态 | Pending / InProgress / Success / Failed / Block |
| 执行结果 | 子 Agent 的产出摘要 |
| 查看详情 | 链接到子 Agent 的完整轨迹 |

**4. 思考阶段（Thinking Phase）**

| 展示项 | 说明 |
|--------|------|
| 思考内容 | 模型的 thinking 输出（如模型支持）|
| 思考耗时 | 思考过程花费的时间 |
| 思考长度 | thinking 内容的字符/ token 数 |

**5. 系统事件阶段（System Event）**

| 展示项 | 说明 |
|--------|------|
| 事件类型 | 注入消息 / 中断 / 恢复 |
| 事件内容 | 系统事件的文本内容 |
| 触发时间 | 事件发生时间 |

#### 4.3.2 时间线交互

| 交互功能 | 说明 |
|----------|------|
| 展开/折叠 | 点击阶段节点展开详情，再次点击折叠 |
| 阶段跳转 | 点击时间线上的节点，内容区滚动到对应位置 |
| 阶段过滤 | 按类型过滤（只看工具调用 / 只看模型调用）|
| 阶段搜索 | 在阶段中搜索关键词 |
| 复制参数 | 一键复制工具调用的参数 JSON |
| 复制结果 | 一键复制工具执行的结果 |

### 4.4 工具详情面板（Tool Detail Panel）

点击时间线上的工具调用节点后展开的详细视图：

#### 4.4.1 请求区（Request）

```json
{
  "toolName": "finance_history",
  "params": {
    "codes": "600036.SH",
    "indicators": ["open", "close", "pct_chg"],
    "startdate": "2025-01-01",
    "enddate": "2025-03-31"
  }
}
```

展示信息：
- 工具名称和描述
- 调用时间戳
- 格式化后的参数（支持 JSON 语法高亮）
- 参数验证信息（如有 schema 校验）

#### 4.4.2 响应区（Response）

```json
{
  "status": "success",
  "data": [
    { "date": "2025-01-02", "open": 32.5, "close": 33.1, "pct_chg": 1.85 }
  ]
}
```

展示信息：
- 响应状态码 / 状态
- 格式化后的结果（支持 JSON 语法高亮）
- 响应大小
- 响应时间
- 如为图片/文件，提供预览

#### 4.4.3 错误区（Error）

如工具调用失败：

```json
{
  "error": "API rate limit exceeded",
  "retryAfter": 60,
  "statusCode": 429
}
```

展示信息：
- 错误类型
- 错误消息
- 堆栈跟踪（如适用）
- 重试策略和结果

### 4.5 子 Agent 调用链面板（Sub-agent Chain Panel）

展示子 Agent 的完整委派链路：

```
Parent Agent (main)
  │──► Sub-agent #1 (research)
  │      │──► Tool: web_search
  │      │──► Tool: web_fetch
  │      └──► Return: 研究报告
  │
  └──► Sub-agent #2 (coder)
         │──► Tool: exec (写文件)
         │──► Tool: exec (运行测试)
         └──► Return: 代码 + 测试结果
```

展示信息：

| 信息项 | 说明 |
|--------|------|
| 层级树 | 父子关系树状图 |
| Agent 名称 | 每个节点的 Agent ID |
| 任务描述 | 每个子 Agent 的任务 |
| 状态颜色 | 绿=成功 / 红=失败 / 黄=进行中 |
| 耗时 | 每个节点的执行耗时 |
| Token 消耗 | 每个节点的 token 使用 |
| 产出物 | 子 Agent 的返回结果摘要 |
| 跳转链接 | 点击查看子 Agent 的完整轨迹 |

### 4.6 模型诊断面板（Model Diagnostics Panel）

展示每次模型调用的诊断信息：

| 信息项 | 说明 | 示例 |
|--------|------|------|
| **模型标识** | 完整模型名称 | `openai/gpt-4-turbo-2024-04-09` |
| **提供商** | 模型提供商 | `openai` / `anthropic` |
| **API 端点** | 调用的 API URL | `https://api.openai.com/v1/chat/completions` |
| **请求 ID** | 提供商返回的请求 ID | `req_abc123` |
| **输入消息** | 发送给模型的完整消息列表 | 可展开查看 |
| **系统提示词** | 使用的 system prompt | 可展开查看（脱敏后）|
| **温度参数** | temperature | `0.7` |
| **最大 Token** | max_tokens | `4096` |
| **Top P** | top_p | `1.0` |
| **频率惩罚** | frequency_penalty | `0` |
| **存在惩罚** | presence_penalty | `0` |
| **完成原因** | finish_reason | `stop` |
| **首 token 延迟** | Time to First Token | `0.8s` |
| **生成速度** | tokens per second | `45 tok/s` |

### 4.7 原始轨迹面板（Raw Trace Panel）

提供未经处理的原始事件数据，面向开发者：

| 信息项 | 说明 |
|--------|------|
| 原始事件列表 | 按时间排序的原始事件 JSON |
| 事件过滤 | 按事件类型过滤 |
| 导出功能 | 导出为 JSON / 复制到剪贴板 |
| 时间戳 | 每个事件的精确时间戳 |
| 事件 ID | 每个事件的唯一标识 |

### 4.8 性能分析面板（Performance Panel）

| 信息项 | 说明 | 示例 |
|--------|------|------|
| **总耗时** | 完整 Agent Turn 耗时 | `27.3s` |
| **模型耗时占比** | 等待模型响应的时间占比 | `68%` |
| **工具耗时占比** | 工具执行的时间占比 | `25%` |
| ** overhead 占比** | Gateway 处理开销占比 | `7%` |
| **耗时分布图** | 甘特图/瀑布图展示各阶段耗时 | 可视化图表 |
| **瓶颈标记** | 自动标记耗时最长的阶段 | 🔴 `web_fetch: 12.5s` |
| **并行度** | 是否并发执行工具 | `3 tools parallel` |

### 4.9 安全与隐私面板（Security Panel）

| 信息项 | 说明 |
|--------|------|
| 敏感信息检测 | 是否检测到密钥、密码等敏感内容 |
| 脱敏记录 | 哪些字段被脱敏处理 |
| 访问权限 | 当前用户是否有权查看此轨迹 |
| 数据保留策略 | 轨迹数据的保留期限 |

---

## 5. 获取完整 System Prompt 的方式

> ⚠️ **重要前提**：OpenClaw 官方**不通过标准客户端 API**（`sessions_history`、`/context` 等）暴露完整的 system prompt。这是有意设计的架构决策。要获取完整的 system prompt、user prompt 和历史消息，**必须通过 OpenClaw Plugin SDK 的 `llm_input` conversation hook 在 Gateway 侧实现**。

### 5.1 为什么 OpenClaw 官方不暴露 System Prompt？

| 原因 | 说明 |
|------|------|
| **安全与隐私** | System prompt 包含 injected workspace files（AGENTS.md、SOUL.md、TOOLS.md 等），可能包含敏感的项目信息 |
| **Prompt 注入防护** | 暴露 system prompt 会降低 prompt injection 的攻击门槛 |
| **OpenClaw-owned** | 文档明确说明 "The prompt is **OpenClaw-owned**"，属于内部实现细节 |
| **Provider 差异** | 不同 provider（如 Codex）对 prompt 的处理方式不同，OpenClaw 发送的是 thread/turn params，不是原始请求 |

### 5.2 官方能提供什么？

| 能力 | 来源 | 限制 |
|------|------|------|
| System prompt 大小和组成 | `/context list` / `/context detail` | 只显示各 section 的字符/ token 数，**不 dump 内容** |
| 消息历史 | `sessions_history(includeTools: true)` | 只含用户/assistant/tool 消息，**不含 system prompt** |
| 模型诊断 | Model-call diagnostics | 只含 `requestPayloadBytes`、延迟等元数据，**不含 prompt 内容** |
| Debug payload | `OPENCLAW_DEBUG_MODEL_PAYLOAD=full-redacted` | 写入日志，**redacted + capped**，非结构化查询 |

### 5.3 唯一官方途径：Plugin SDK `llm_input` Hook

OpenClaw Plugin SDK 向 Gateway 插件暴露 `llm_input` conversation hook，每次模型调用前触发。事件对象包含完整的模型输入。

#### 5.3.1 Hook 事件结构

```typescript
interface PluginHookLlmInputEvent {
  runId: string;                    // 本次 Agent Turn 的运行 ID
  sessionId?: string;               // 会话 ID
  sessionKey?: string;              // 会话 Key
  provider: string;                 // 模型提供商（openai / anthropic）
  model: string;                    // 使用的模型（openai/gpt-4）
  systemPrompt?: string;            // ← 完整的系统提示词文本
  prompt: string;                   // ← 当前用户输入（已处理后）
  historyMessages: Array<{          // ← 历史消息列表
    role: string;
    content: string | any[];
  }>;
  imagesCount?: number;             // 图片数量
  tools?: Array<unknown>;           // 可用工具列表
}
```

#### 5.3.2 获取方式对比

| 方式 | 能否获取完整 system prompt | 能否获取 user prompt | 能否获取 history | 实时性 | 架构位置 |
|------|---------------------------|---------------------|------------------|--------|----------|
| `sessions_history` | ❌ 不能 | ⚠️ 原始用户消息 | ✅ 可以 | 事后 | 客户端工具 |
| `/context detail` | ❌ 不能（只看大小）| ❌ 不能 | ❌ 不能 | 事后 | 客户端命令 |
| `OPENCLAW_DEBUG_MODEL_PAYLOAD` | ⚠️ Redacted + capped | ⚠️ 可能含部分 | ❌ 不能 | 实时（日志）| 环境变量 |
| **Plugin `llm_input` hook** | **✅ 完整文本** | **✅ 完整文本** | **✅ 完整列表** | **实时** | **Gateway 插件** |

### 5.4 插件实现架构

要在 Gateway 侧捕获完整 prompt 并暴露给前端，需要实现一个自定义插件：

```
User 发送消息
    │
    ▼
OpenClaw Gateway 构建完整 prompt
    │
    ▼
llm_input hook 触发 ──► 自定义插件接收 event.systemPrompt / event.prompt / event.historyMessages
    │                      │
    │                      ▼
    │                 SQLite 存储（runId 为 key）
    │                      │
    ▼                      │
模型 Provider 调用         │
    │                      │
    ▼                      │
llm_output hook 触发       │
    │                      │
    ▼                      │
插件存储 assistant 输出 ◄──┘
    │
    ▼
用户点击"查看Agent轨迹"图标
    │
    ▼
前端调用自定义 RPC（arkclawTrace.get）
    │
    ▼
Gateway 插件从 SQLite 读取并返回完整轨迹
```

#### 5.4.1 插件核心代码

**hooks.js —— 捕获逻辑：**

```javascript
export function createHooks(api, config) {
  const storage = new TraceStorage(config);
  const activeRuns = new Map();

  // llm_input: 捕获完整 prompt
  const llmInputHook = async (event, ctx) => {
    const runId = event?.runId ?? ctx?.runId;
    storage.startTrace({
      runId,
      sessionKey: ctx?.sessionKey ?? event?.sessionKey,
      agentId: ctx?.agentId,
      model: event?.model,
      provider: event?.provider,
      systemPrompt: event?.systemPrompt ?? "",     // ← 完整 system prompt
      userPrompt: event?.prompt ?? "",              // ← 当前输入
      historyMessages: event?.historyMessages ?? [], // ← 历史消息
    });
    activeRuns.set(runId, { startTime: Date.now() });
  };

  // before/after_tool_call: 捕获工具调用链
  const afterToolCallHook = async (event, ctx) => {
    const runId = event?.runId ?? ctx?.runId;
    storage.recordToolCall({
      runId,
      toolName: event?.toolName ?? event?.cmd,
      params: event?.params,
      result: event?.result ?? event?.stdout,
      status: event?.error ? "failed" : "completed",
      durationMs: event?.durationMs,
    });
  };

  // llm_output: 捕获模型输出并结束轨迹
  const llmOutputHook = async (event, ctx) => {
    const runId = event?.runId ?? ctx?.runId;
    const state = activeRuns.get(runId);
    storage.finalizeTrace({
      runId,
      assistantOutput: event?.assistantTexts?.join("\n"),
      tokenUsage: ctx?.tokenUsage,
      durationMs: Date.now() - (state?.startTime ?? Date.now()),
      status: "completed",
    });
    activeRuns.delete(runId);
  };

  return { llmInputHook, afterToolCallHook, llmOutputHook, storage };
}
```

**index.js —— 插件入口和 RPC：**

```javascript
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { createHooks } from "./hooks.js";

export default definePluginEntry({
  id: "arkclaw-prompt-capture",
  name: "ArkClaw Prompt Capture",
  register(api) {
    const config = api.config?.["arkclaw-prompt-capture"] ?? {};
    const { llmInputHook, afterToolCallHook, llmOutputHook, storage } = createHooks(api, config);

    // 注册 hooks
    api.on("llm_input", llmInputHook);
    api.on("llm_output", llmOutputHook);
    api.on("before_tool_call", () => {});
    api.on("after_tool_call", afterToolCallHook);

    // 暴露 RPC 供前端查询
    api.registerGatewayMethod("arkclawTrace.get", async (ctx) => {
      const trace = storage.getTrace(ctx.params?.runId);
      if (!trace) {
        ctx.respond(false, undefined, { code: "NOT_FOUND", message: "Trace not found" });
        return;
      }
      ctx.respond(true, { trace });
    });

    api.registerGatewayMethod("arkclawTrace.list", async (ctx) => {
      const traces = storage.listTraces({
        limit: Math.min(parseInt(ctx.params?.limit ?? "20", 10), 100),
        sessionKey: ctx.params?.sessionKey ?? null,
      });
      ctx.respond(true, { traces });
    });
  },
});
```

### 5.5 数据存储设计

使用 SQLite（`better-sqlite3`）按 `runId` 存储：

```sql
CREATE TABLE traces (
  run_id TEXT PRIMARY KEY,
  session_key TEXT NOT NULL,
  agent_id TEXT,
  model TEXT,
  provider TEXT,
  timestamp TEXT,
  system_prompt TEXT,        -- 完整 system prompt（可配置截断上限）
  user_prompt TEXT,          -- 当前用户输入
  history_messages TEXT,     -- JSON 序列化的历史消息
  assistant_output TEXT,     -- 模型最终输出
  tool_calls TEXT,           -- JSON 序列化的工具调用链
  token_usage_input INTEGER,
  token_usage_output INTEGER,
  token_usage_cache INTEGER,
  duration_ms INTEGER,
  status TEXT DEFAULT 'running',
  created_at INTEGER DEFAULT (unixepoch())
);
```

### 5.6 安装和配置

**1. 复制插件到插件目录：**

```bash
mkdir -p ~/.openclaw/plugins/arkclaw-prompt-capture
cp -r arkclaw-prompt-capture-plugin/* ~/.openclaw/plugins/arkclaw-prompt-capture/
cd ~/.openclaw/plugins/arkclaw-prompt-capture
npm install --ignore-scripts --production
```

**2. 在 `openclaw.json` 中启用：**

```json5
{
  plugins: {
    entries: {
      "arkclaw-prompt-capture": {
        enabled: true,
        config: {
          dbPath: "~/.openclaw/state/arkclaw-traces.db",
          maxPromptLength: 1000000,    // 单条 prompt 最大存储字符数
          maxHistoryMessages: 200,     // 最大历史消息数
          retentionDays: 30,           // 数据保留天数
        }
      }
    }
  }
}
```

**3. 重启 Gateway：**

```bash
openclaw gateway
```

**4. 前端调用：**

```typescript
const trace = await gateway.rpc("arkclawTrace.get", { runId: "run_abc123" });
console.log(trace.systemPrompt);    // 完整 system prompt
console.log(trace.userPrompt);      // 当前输入
console.log(trace.historyMessages); // 历史消息
console.log(trace.toolCalls);       // 工具调用链
```

---

## 6. 数据安全与隐私

### 6.1 敏感信息处理

| 场景 | 处理方式 |
|------|----------|
| API Key | 全程脱敏，展示为 `sk-***...abc` |
| 密码/Token | 替换为 `[REDACTED]` |
| 个人身份信息 | 根据配置策略脱敏 |
| 工具结果中的敏感数据 | 根据工具类型选择性脱敏 |

### 5.2 访问控制

| 控制维度 | 说明 |
|----------|------|
| 会话隔离 | 只能查看自己所在会话的轨迹 |
| Agent 权限 | 只能查看自己 Agent 的轨迹 |
| 角色权限 | Admin 可查看全部，User 只能查看自己的 |
| 轨迹导出 | 控制是否允许导出原始轨迹数据 |
| 轨迹数据存储位置 | 本地 SQLite，不上传云端 |
| System prompt 访问权限 | 仅 Admin 可查看完整内容 |

### 6.3 数据保留

| 策略 | 说明 |
|------|------|
| 会话级保留 | 轨迹与会话生命周期绑定 |
| 定期清理 | 插件配置 `retentionDays`，超期自动删除 |
| 审计需求 | 支持导出用于审计的轨迹报告 |
| 大 prompt 截断 | 超过 `maxPromptLength` 自动截断，防止数据库膨胀 |

---

## 7. 扩展与定制

### 7.1 自定义工具展示

不同工具可以注册自定义的展示组件：

```typescript
const toolRenderers: Record<string, ToolRenderer> = {
  'browser': BrowserToolRenderer,
  'finance_history': FinanceToolRenderer,
  'exec': ExecToolRenderer,
  // ...
};

function renderToolResult(toolName: string, result: any) {
  const renderer = toolRenderers[toolName] || DefaultToolRenderer;
  return renderer(result);
}
```

### 7.2 插件化扩展点

| 扩展点 | 说明 |
|--------|------|
| 自定义阶段类型 | 注册新的轨迹阶段类型 |
| 自定义可视化组件 | 为特定工具提供专属 UI |
| 自定义分析规则 | 添加性能瓶颈检测规则 |
| 自定义导出格式 | 支持导出为 HTML / PDF / Markdown |
| 自定义存储后端 | 替换 SQLite 为 PostgreSQL / Redis / S3 |

### 7.3 集成外部系统

| 集成目标 | 方式 |
|----------|------|
| OpenTelemetry | 将 traceId 关联到外部 APM |
| 日志系统 | 将轨迹事件发送到 ELK / Loki |
| 告警系统 | 工具失败时触发告警 |
| 指标系统 | 上报工具调用延迟等指标 |

---

## 附录 A：数据结构参考

### A.1 AgentTrace 完整结构

```typescript
interface AgentTrace {
  // 基础信息
  runId: string;
  sessionKey: string;
  agentId: string;
  userId?: string;

  // 时间信息
  startTime: string;      // ISO 8601
  endTime?: string;
  durationMs?: number;

  // 模型信息
  model: string;
  thinking?: string;
  modelParams?: {
    temperature?: number;
    maxTokens?: number;
    topP?: number;
    frequencyPenalty?: number;
    presencePenalty?: number;
  };

  // Token 使用
  tokenUsage: {
    input: number;
    output: number;
    cache?: number;
    total: number;
  };

  // 运行阶段
  phases: TracePhase[];

  // 子 Agent
  subAgents: SubAgentTrace[];

  // 系统事件
  systemEvents?: SystemEvent[];

  // 追踪上下文
  traceContext?: {
    traceId: string;
    spanId: string;
    parentSpanId?: string;
  };

  // 原始事件
  rawEvents?: RawEvent[];

  // 错误信息
  error?: {
    type: string;
    message: string;
    stack?: string;
  };
}

interface TracePhase {
  id: string;
  type: 'model' | 'tool' | 'thinking' | 'system' | 'subAgent';
  name: string;
  status: 'started' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  startTime: string;
  endTime?: string;
  durationMs?: number;

  // 模型阶段特有
  modelInfo?: {
    model: string;
    inputTokens: number;
    outputTokens: number;
    finishReason: string;
    latencyMs: number;
  };

  // 工具阶段特有
  toolInfo?: {
    toolName: string;
    toolParams: Record<string, any>;
    toolResult?: any;
    error?: string;
    retryCount?: number;
  };

  // 子 Agent 阶段特有
  subAgentInfo?: {
    childSessionKey: string;
    childAgentId: string;
    task: string;
    outputs?: any[];
  };
}
```

### A.2 WebSocket 事件结构

```typescript
interface ToolEvent {
  type: 'session.tool';
  runId: string;
  toolName: string;
  toolParams: Record<string, any>;
  status: 'started' | 'in_progress' | 'completed' | 'failed';
  result?: any;
  error?: string;
  durationMs?: number;
  timestamp: string;
}
```

---

## 附录 B：前端组件接口

```typescript
// 轨迹按钮
interface TraceButtonProps {
  runId: string;
  hasTrace: boolean;      // 是否有可展示的轨迹
  isLoading: boolean;     // 是否正在加载
  onClick: () => void;
}

// 轨迹面板
interface TraceDrawerProps {
  runId: string;
  trace: AgentTrace | null;
  isOpen: boolean;
  onClose: () => void;
  activeTab?: string;     // 默认激活的标签页
}

// 时间线节点
interface TraceTimelineProps {
  phases: TracePhase[];
  onPhaseClick: (phase: TracePhase) => void;
  expandedPhases: Set<string>;
}

// 工具详情
interface ToolDetailProps {
  toolName: string;
  params: Record<string, any>;
  result?: any;
  error?: string;
  durationMs?: number;
}
```

---

---

## 附录 C：arkclaw-prompt-capture 插件完整源码

插件源码位于同目录 `arkclaw-prompt-capture-plugin/` 下，包含：

| 文件 | 说明 |
|------|------|
| `index.js` | 插件入口，注册 hooks 和 RPC |
| `hooks.js` | `llm_input`、`before_tool_call`、`after_tool_call`、`llm_output` hook 实现 |
| `storage.js` | SQLite 存储层（`better-sqlite3`）|
| `package.json` | 插件元数据 |
| `install.sh` | 安装脚本 |
| `README.md` | 使用文档 |

---

*文档版本: 1.1*
*最后更新: 2026-07-29*
*基于 OpenClaw Gateway 架构 + Plugin SDK*
