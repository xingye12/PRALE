# ArkClaw 协作项目飞书群同步实现详解

> **文档性质**：基于项目源码的逆向分析文档  
> **分析对象**：`arkclaw-team` 扩展、`openclaw-lark` 扩展、项目 workspace 配置  
> **分析日期**：2026-07-27  
> **核心结论**：该功能是一个纯平台工程实现，不依赖 Agent 智能能力

---

## 1. 功能开关（Feature Gate）

该功能由 `arkclaw-team` 扩展的 feature gate 控制，配置位于：

```
~/.openclaw/extensions/arkclaw-team/config/feature-gates.json
```

实际配置内容：

```json
{
  "team.project.feishu_group": {
    "enable": true,
    "minPluginVersion": "2026.4.17",
    "minOpenclawVersion": "2026.3.2",
    "editions": ["arkclaw_enterprise", "arkclaw"]
  }
}
```

**说明**：
- `enable: true` 表示功能在当前实例已启用
- `minPluginVersion` 和 `minOpenclawVersion` 定义了最低版本要求
- `editions` 限制该功能仅在企业版和标准版可用

---

## 2. 核心架构：Session 映射模型

### 2.1 飞书群会话的 SessionKey 格式

系统在 `artifact-index` 中维护了飞书群会话的映射关系。从实际数据可见：

```json
// ~/.openclaw/artifact-index/agent:p-mr3c7sef59ohal-manager:feishu:group:oc_4e4da2fd707d21d415281a347f3d0442.json
{
  "sessionKey": "agent:p-mr3c7sef59ohal-manager:feishu:group:oc_4e4da2fd707d21d415281a347f3d0442"
}
```

**SessionKey 结构解析**：

```
agent:{projectId}-manager:feishu:group:{chatId}
│     │                │      │      │
│     │                │      │      └── 飞书群 chat_id（oc_ 开头）
│     │                │      └───────── 频道类型标识
│     │                └──────────────── 飞书渠道
│     └───────────────────────────────── 项目 Agent ID
└─────────────────────────────────────── agent 前缀
```

### 2.2 判断是否为飞书群会话

源码中的判断逻辑（来自 `arkclaw-team/dist/index.js`）：

```javascript
function aH(e) {
  return e.sessionKey?.includes(":feishu:group:");
}
```

这是一个简单的字符串包含检查，用于区分飞书群会话与普通项目会话。

---

## 3. 飞书群创建实现

### 3.1 创建群聊的 API 调用

群聊创建由 `arkclaw-team` 扩展直接调用飞书 OpenAPI 完成，不经过 Agent 层。

**核心代码片段**（来自 `arkclaw-team/dist/index.js` 反编译）：

```javascript
async function createProjectGroup(e) {
  // e 包含: name, description, ownerOpenId, memberOpenIds, uuid
  
  // 1. 获取 tenant_access_token
  const token = await Eb(config);  // 内部调用飞书获取 token 接口
  
  // 2. 调用飞书创建群 API
  const res = await fetch(
    "https://open.feishu.cn/open-apis/im/v1/chats?user_id_type=open_id",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json; charset=utf-8"
      },
      body: JSON.stringify({
        name: e.name,
        description: e.description ?? "",
        owner_id: e.ownerOpenId?.trim() || void 0,
        user_id_list: memberOpenIds.length > 0 ? memberOpenIds : void 0,
        set_bot_manager: false,
        uuid: generateUuid(e.uuid)
      })
    }
  );
  
  // 3. 解析响应
  const body = await res.text();
  const data = JSON.parse(body);
  
  if (data.code && data.code !== 0) {
    throw new Error(`create project group failed: code=${data.code} msg=${data.msg}`);
  }
  
  if (!data.data?.chat_id) {
    throw new Error(`create project group missing chat_id`);
  }
  
  // 4. 返回结果
  return {
    chatId: data.data.chat_id,
    name: data.data.name ?? e.name
  };
}
```

### 3.2 创建参数说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | 群名称（用户可自定义，默认使用项目名称） |
| `description` | string | 群描述 |
| `owner_id` | string | 群主 open_id（项目创建者） |
| `user_id_list` | string[] | 初始成员 open_id 列表（项目成员） |
| `set_bot_manager` | boolean | 是否将机器人设为群管理员（固定为 false） |
| `uuid` | string | 防重放 UUID |

### 3.3 权限检查机制

在创建群之前，系统会检查当前飞书应用是否有创建群聊的权限：

```javascript
async function YH({ isForce = false } = {}) {
  const config = await kc();  // 读取 channel 配置
  
  if (!Tc(config)) {
    return {
      hasFeishuGroupCreatePermission: false,
      errorMsg: "Feishu channel not bound"
    };
  }
  
  // 非强制模式下，先检查缓存
  if (!isForce) {
    const cached = await Sb(config.appId);
    if (cached?.hasFeishuGroupCreatePermission !== undefined) {
      return { hasFeishuGroupCreatePermission: cached.hasFeishuGroupCreatePermission };
    }
  }
  
  // 实际测试：尝试创建一个测试群
  try {
    const token = await Eb(config);
    const res = await fetch(
      "https://open.feishu.cn/open-apis/im/v1/chats?user_id_type=open_id",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json; charset=utf-8"
        },
        body: JSON.stringify({
          name: "权限测试群",
          description: "用于测试创建群权限",
          set_bot_manager: false,
          uuid: generateUuid("permission-check-test")
        })
      }
    );
    
    const data = JSON.parse(await res.text());
    
    if (data.code && data.code !== 0) {
      // 权限不足，缓存结果
      await Oi(config.appId, { hasFeishuGroupCreatePermission: false });
      return {
        hasFeishuGroupCreatePermission: false,
        errorCode: data.code,
        errorMsg: data.msg
      };
    }
    
    // 权限验证通过
    await Oi(config.appId, { hasFeishuGroupCreatePermission: true });
    return { hasFeishuGroupCreatePermission: true };
    
  } catch (err) {
    await Oi(config.appId, { hasFeishuGroupCreatePermission: false });
    return {
      hasFeishuGroupCreatePermission: false,
      errorMsg: err.message
    };
  }
}
```

**关键发现**：
- 权限检查是通过**实际创建一个测试群**来验证的，而非查询权限列表
- 结果会被缓存到 `channel.json` 中（`hasFeishuGroupCreatePermission` 字段）
- 飞书应用需要 `im:chat:create` 权限

### 3.4 权限配置存储

权限状态存储在 `~/.openclaw/.arkclaw-team/channel.json`：

```json
{
  "feishu": {
    "cli_aaa39d50cdb85cc5": {
      "appSecret": "***",
      "owner": "ou_d4b521fbc59ad5caa63fc250df9eaf2d",
      "hasFeishuGroupCreatePermission": true
    }
  }
}
```

---

## 4. 消息双向同步机制

### 4.1 架构概述

消息同步通过 `before_message_write` 事件钩子实现，核心逻辑在 `arkclaw-team/dist/index.js` 中：

```javascript
// 注册事件监听器
e.on("before_message_write", (event, context) => {
  UHe(e, event, context);
});
```

### 4.2 双向同步逻辑

```javascript
async function UHe(pluginApi, event, context) {
  const t = event;
  const n = context;
  
  // 情况 1：消息来自飞书群 → 镜像到项目主会话
  if (n.sessionKey?.includes(":feishu:group:")) {
    const result = await rb({
      agentId: n.agentId,
      sessionKey: n.sessionKey,
      message: t.message
    });
    // ... 镜像逻辑
    return;
  }
  
  // 情况 2：消息来自项目 → 转发到飞书群
  const payload = NN(t, n);  // 构造消息 payload
  const project = await RN(n, payload);  // 获取项目信息
  
  if (project?.feishuChatId) {
    // 转发到飞书群
    const result = await eb({
      agentId: n.agentId,
      sessionKey: n.sessionKey,
      chatId: project.feishuChatId,
      message: t.message
    });
    
    // 记录同步事件
    await CN({ event: t, context: n, project: project, payload: payload });
  }
}
```

### 4.3 飞书群 → 项目（Inbound）

当用户在飞书群发送消息时，`openclaw-lark` 插件接收 webhook 事件，构造 sessionKey 为 `agent:{projectId}-manager:feishu:group:{chatId}` 的会话上下文。

然后 `rb` 函数将该消息**镜像（mirror）**到项目的主会话：

```javascript
async function rb(params) {
  // 检查是否为飞书群会话
  if (!aH(params)) {
    return { ok: false, reason: "not_feishu_group_session" };
  }
  
  // 获取对应的项目主会话
  const mainSessionKey = params.sessionKey.replace(/:feishu:group:[^:]+$/, ":main");
  
  // 将消息写入主会话
  // ... 镜像逻辑
}
```

### 4.4 项目 → 飞书群（Outbound）

当项目内产生消息（Agent 回复、状态更新、任务创建等），`eb` 函数将其转发到飞书群：

```javascript
async function eb(params) {
  const { agentId, sessionKey, chatId, message } = params;
  
  // 通过 openclaw-lark 插件发送消息到飞书群
  // 使用飞书 Bot 的 tenant_access_token
  // ...
}
```

### 4.5 消息防循环机制

系统通过 sessionKey 的区分来防止消息循环：
- 飞书群消息的 sessionKey 包含 `:feishu:group:`
- 项目主会话的 sessionKey 以 `:main` 结尾
- 当检测到消息来自飞书群时，只进行镜像，不再反向转发回飞书群

---

## 5. 群成员管理

### 5.1 添加成员

`openclaw-lark` 扩展提供了群成员管理功能：

```javascript
// ~/.openclaw/extensions/openclaw-lark/src/messaging/outbound/chat-manage.js

async function addChatMembersFeishu(params) {
  const { chatId, memberIds, appId, appSecret } = params;
  
  const client = await getLarkClient({ appId, appSecret });
  
  const res = await client.im.v1.chatMembers.create({
    path: { chat_id: chatId },
    params: { member_id_type: "open_id" },
    data: { id_list: memberIds }
  });
  
  return res.data;
}
```

**调用飞书 API**：`POST /open-apis/im/v1/chats/{chat_id}/members`

### 5.2 移除成员

```javascript
async function removeChatMembersFeishu(params) {
  const { chatId, memberIds, appId, appSecret } = params;
  
  const client = await getLarkClient({ appId, appSecret });
  
  const res = await client.im.v1.chatMembers.delete({
    path: { chat_id: chatId },
    params: { member_id_type: "open_id" },
    data: { id_list: memberIds }
  });
  
  return res.data;
}
```

### 5.3 列出成员

```javascript
async function listChatMembersFeishu(params) {
  const { chatId, appId, appSecret } = params;
  
  const client = await getLarkClient({ appId, appSecret });
  const members = [];
  
  let hasMore = true;
  let pageToken;
  
  while (hasMore) {
    const res = await client.im.v1.chatMembers.get({
      path: { chat_id: chatId },
      params: {
        member_id_type: "open_id",
        page_token: pageToken
      }
    });
    
    members.push(...(res.data?.items || []));
    hasMore = res.data?.has_more ?? false;
    pageToken = res.data?.page_token;
  }
  
  return members;
}
```

### 5.4 更新群信息

```javascript
async function updateChatFeishu(params) {
  const { chatId, name, description, appId, appSecret } = params;
  
  const client = await getLarkClient({ appId, appSecret });
  
  const res = await client.im.v1.chat.patch({
    path: { chat_id: chatId },
    data: {
      name,
      description
    }
  });
  
  return res.data;
}
```

---

## 6. 飞书机器人初始化

### 6.1 Bot 菜单设置

当飞书渠道绑定完成后，系统会自动设置 Bot 菜单：

```javascript
async function f8({ appId, appSecret, openId, tenantBrand }) {
  const menu = {
    bot_menu_items: [
      {
        name: "对话管理",
        i18n_name: { en_us: "Conversation" },
        children: [
          { name: "/new", i18n_name: { en_us: "/new" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/reset", i18n_name: { en_us: "/reset" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/stop", i18n_name: { en_us: "/stop" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/context list", i18n_name: { en_us: "/context list" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/agents", i18n_name: { en_us: "/agents" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/tasks", i18n_name: { en_us: "/tasks" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/compact", i18n_name: { en_us: "/compact" }, behaviors: [{ type: "send_message", is_primary: true }] }
        ]
      },
      {
        name: "我的设置",
        i18n_name: { en_us: "Settings" },
        children: [
          { name: "/model status", i18n_name: { en_us: "/model status" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/help", i18n_name: { en_us: "/help" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/status", i18n_name: { en_us: "/status" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/whoami", i18n_name: { en_us: "/whoami" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/usage cost", i18n_name: { en_us: "/usage cost" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/restart", i18n_name: { en_us: "/restart" }, behaviors: [{ type: "send_message", is_primary: true }] }
        ]
      },
      {
        name: "技能与扩展",
        i18n_name: { en_us: "Skills" },
        children: [
          { name: "/tools", i18n_name: { en_us: "/tools" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "查看定时任务", i18n_name: { en_us: "Scheduled Tasks" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "查看技能列表", i18n_name: { en_us: "Skills" }, behaviors: [{ type: "send_message", is_primary: true }] },
          { name: "/commands", i18n_name: { en_us: "/commands" }, behaviors: [{ type: "send_message", is_primary: true }] }
        ]
      }
    ]
  };
  
  const baseUrl = tenantBrand === "lark" ? "https://open.larksuite.com" : "https://open.feishu.cn";
  const token = await getTenantAccessToken(baseUrl, appId, appSecret);
  
  await fetch(`${baseUrl}/open-apis/bot/v3/bot_menu?user_id_type=open_id`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json; charset=utf-8"
    },
    body: JSON.stringify({
      user_id: openId,
      bot_menu: menu
    })
  });
}
```

### 6.2 群标签页（Chat Tabs）

系统还会为飞书群添加两个标签页：

```javascript
async function d8({ appId, appSecret, chatId, agentId, env, tenantBrand }) {
  const baseUrl = tenantBrand === "lark" ? "https://open.larksuite.com" : "https://open.feishu.cn";
  const token = await getTenantAccessToken(baseUrl, appId, appSecret);
  
  // 构建控制台链接和文档链接
  const consoleUrl = buildConsoleUrl({ agentId, env });
  const docsUrl = buildDocsUrl();
  
  // 获取现有标签页
  const existingTabs = await listChatTabs(baseUrl, token, chatId);
  
  // 定义新标签页
  const tabs = [
    { tab_name: "去控制台", tab_type: "url", tab_content: { url: consoleUrl } },
    { tab_name: "说明文档", tab_type: "url", tab_content: { url: docsUrl } }
  ];
  
  // 更新或创建标签页
  const existingMap = new Map(
    existingTabs
      .filter(t => t.tab_type === "url" && t.tab_name)
      .map(t => [t.tab_name, t])
  );
  
  const toUpdate = [];
  const toCreate = [];
  
  for (const tab of tabs) {
    const existing = existingMap.get(tab.tab_name ?? "");
    if (existing?.tab_id) {
      toUpdate.push({ ...tab, tab_id: existing.tab_id });
    } else {
      toCreate.push(tab);
    }
  }
  
  if (toUpdate.length > 0) {
    await updateChatTabs(baseUrl, token, chatId, { chat_tabs: toUpdate });
  }
  
  if (toCreate.length > 0) {
    await createChatTabs(baseUrl, token, chatId, { chat_tabs: toCreate });
  }
}
```

---

## 7. 配置体系

### 7.1 渠道配置结构

系统配置存储在 OpenClaw 的 gateway config 中，结构如下：

```json
{
  "channels": {
    "feishu": {
      "domain": "feishu",
      "appId": "cli_aaa39d50cdb85cc5",
      "appSecret": "***",
      "streaming": true,
      "dmPolicy": "allowlist",
      "groupPolicy": "open",
      "allowFrom": ["ou_d4b521fbc59ad5caa63fc250df9eaf2d"],
      "groupAllowFrom": ["ou_d4b521fbc59ad5caa63fc250df9eaf2d"],
      "footer": { "elapsed": true, "status": true },
      "accounts": {
        "main": {
          "appId": "cli_aaa39d50cdb85cc5",
          "appSecret": "***",
          "dmPolicy": "allowlist",
          "allowFrom": ["ou_d4b521fbc59ad5caa63fc250df9eaf2d"]
        }
      },
      "bindings": [
        {
          "agentId": "main",
          "match": { "channel": "feishu", "accountId": "main" }
        }
      ]
    }
  }
}
```

### 7.2 配置字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `domain` | string | 域名标识，`feishu` 或 `lark` |
| `appId` | string | 飞书应用 ID |
| `appSecret` | string | 飞书应用密钥 |
| `streaming` | boolean | 是否启用流式响应 |
| `dmPolicy` | string | 单聊策略：`open` 或 `allowlist` |
| `groupPolicy` | string | 群聊策略：`open` 或 `allowlist` |
| `allowFrom` | string[] | 单聊白名单 open_id 列表 |
| `groupAllowFrom` | string[] | 群聊白名单 open_id 列表 |
| `accounts` | object | 多账号配置（按 agent 隔离） |
| `bindings` | array[] | Agent 与渠道的绑定关系 |

### 7.3 权限检查 RPC

系统暴露了 RPC 方法供前端查询权限状态：

```javascript
// arkclaw.team.channel.permission.check
e.registerGatewayMethod("arkclaw.team.channel.permission.check", async ({ respond, params }) => {
  const { isForce } = params;
  
  // 1. 检查飞书渠道是否绑定
  const channelStatus = await zH();
  
  // 2. 检查是否有创建群权限
  const permission = await YH({ isForce });
  
  let feishuAuthUrl;
  if (channelStatus.isFeishuChannelBound && !permission.hasFeishuGroupCreatePermission) {
    // 生成授权 URL，引导用户授权 im:chat:create 权限
    feishuAuthUrl = `https://open.feishu.cn/app/${channelStatus.appId}/auth?q=im:chat:create&op_from=openapi&token_type=tenant`;
  }
  
  respond(true, {
    isFeishuChannelBound: channelStatus.isFeishuChannelBound,
    hasFeishuGroupCreatePermission: permission.hasFeishuGroupCreatePermission,
    feishuAuthUrl
  });
});
```

---

## 8. 项目 Workspace 中的飞书集成

### 8.1 插件安装

每个项目 workspace 中都安装了 `openclaw-lark` 插件：

```
~/.openclaw/.arkclaw-team/projects/{projectId}/workspaces/{projectId}-manager/
  .meta/env/plugins_from_local_install/openclaw-lark/
```

### 8.2 技能注册

项目 Agent 会注册飞书相关的 skills，如：
- `feishu-bitable`
- `feishu-calendar`
- `feishu-channel-rules`
- `feishu-create-doc`
- `feishu-fetch-doc`
- `feishu-im-read`
- `feishu-task`
- `feishu-troubleshoot`
- `feishu-update-doc`

### 8.3 工具限制

在 `lark-cli-pe` 技能中，系统强制要求所有飞书操作通过 `lark-cli` 完成：

```markdown
# 飞书相关功能操作规范

【强制要求 - 无例外】飞书所有操作必须先读 feishu-lark-cli skill，
飞书所有操作都使用 lark-cli，禁用使用 openclaw-lark 这个插件相关的工具和 skills 以及浏览器。
未读 feishu-lark-cli 这个 skill 不得调用任何飞书工具及 skills。
```

---

## 9. 完整的群创建流程示例

### 9.1 前端调用流程

```typescript
// 前端创建项目时，用户勾选「同步到飞书群」
async function createProjectWithFeishuSync(params) {
  // 1. 检查权限
  const permissionCheck = await fetch('/api/v1/arkclaw.team.channel.permission.check', {
    method: 'POST',
    body: JSON.stringify({ isForce: false })
  });
  
  const permission = await permissionCheck.json();
  
  if (!permission.data.isFeishuChannelBound) {
    throw new Error('请先绑定飞书渠道');
  }
  
  if (!permission.data.hasFeishuGroupCreatePermission) {
    // 引导用户去飞书授权
    window.open(permission.data.feishuAuthUrl, '_blank');
    throw new Error('需要授权创建群聊权限');
  }
  
  // 2. 创建项目
  const project = await fetch('/api/v1/arkclaw.team.project.create', {
    method: 'POST',
    body: JSON.stringify({
      name: params.name,
      description: params.description,
      members: params.members,
      syncToFeishu: true,  // 启用同步
      feishuGroupName: params.feishuGroupName  // 可选自定义群名
    })
  });
  
  return project;
}
```

### 9.2 后端创建流程

```javascript
// 后端处理创建请求
async function handleProjectCreate(params) {
  const { syncToFeishu, feishuGroupName, members, ...projectParams } = params;
  
  // 1. 创建项目和 Agent
  const project = await createProject(projectParams);
  
  // 2. 创建 Agent 工作区
  await createAgentWorkspaces(project);
  
  // 3. 如果启用了飞书同步，创建飞书群
  if (syncToFeishu) {
    // 获取成员的飞书 open_id
    const memberOpenIds = await resolveMemberOpenIds(members);
    
    // 获取创建者的 open_id
    const ownerOpenId = await getCreatorOpenId();
    
    // 创建飞书群
    const group = await createProjectGroup({
      name: feishuGroupName || project.name,
      description: project.description,
      ownerOpenId,
      memberOpenIds,
      uuid: project.id
    });
    
    // 保存 project_id ↔ chat_id 映射
    await saveProjectFeishuMapping({
      projectId: project.id,
      feishuChatId: group.chatId,
      feishuGroupName: group.name
    });
    
    // 设置群标签页
    await setupChatTabs({
      chatId: group.chatId,
      agentId: project.leadAgentId,
      env: process.env.NODE_ENV
    });
  }
  
  return project;
}
```

### 9.3 消息同步示例

```javascript
// 项目内消息 → 飞书群
async function forwardToFeishuGroup(projectId, message) {
  const mapping = await getProjectFeishuMapping(projectId);
  if (!mapping?.feishuChatId) return;
  
  const config = await getFeishuConfig();
  const token = await getTenantAccessToken(
    "https://open.feishu.cn",
    config.appId,
    config.appSecret
  );
  
  // 发送文本消息
  await fetch("https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json; charset=utf-8"
    },
    body: JSON.stringify({
      receive_id: mapping.feishuChatId,
      msg_type: "text",
      content: JSON.stringify({ text: message.content })
    })
  });
}

// 飞书群消息 → 项目
async function handleFeishuGroupWebhook(payload) {
  const { chat_id, sender, message } = payload;
  
  // 查找对应的项目
  const mapping = await getProjectByFeishuChatId(chat_id);
  if (!mapping) return;
  
  // 构造项目会话消息
  const sessionKey = `agent:${mapping.projectId}-manager:feishu:group:${chat_id}`;
  
  // 写入项目会话（触发 before_message_write 事件）
  await writeMessageToSession({
    sessionKey,
    message: {
      role: "user",
      content: message.content,
      sender: sender.sender_id.open_id
    }
  });
}
```

---

## 10. 结论：是否需要 Agent 智能能力？

### 10.1 功能分层分析

| 功能模块 | 是否需要 Agent 智能 | 实现方式 |
|---------|------------------|---------|
| 飞书群创建 | ❌ 不需要 | 直接调用 Lark OpenAPI |
| 群成员管理（添加/移除） | ❌ 不需要 | 直接调用 Lark OpenAPI |
| 群信息更新 | ❌ 不需要 | 直接调用 Lark OpenAPI |
| 项目消息 → 飞书群 | ❌ 不需要 | `before_message_write` 事件钩子 |
| 飞书群消息 → 项目 | ❌ 不需要 | Webhook 接收 + Session 映射 |
| 消息格式转换（卡片/文本） | ❌ 不需要 | 预定义模板 |
| Bot 菜单设置 | ❌ 不需要 | 固定菜单配置 |
| 群标签页设置 | ❌ 不需要 | 固定 URL 配置 |
| 权限检查 | ❌ 不需要 | API 调用的成功/失败判断 |
| **@Bot 自然语言交互** | ✅ **需要** | Agent LLM 处理 |
| **任务分配建议** | ✅ **需要** | Agent 智能决策 |
| **消息摘要生成** | ⚠️ 可选 | LLM 辅助 |

### 10.2 核心结论

**"协作项目动态同步到飞书群"功能是一个纯粹的 SaaS 集成工程实现，整个过程不依赖 Agent 的智能能力。**

其技术本质可以概括为：

1. **事件驱动架构**：通过 `before_message_write` 事件钩子实现消息拦截和路由
2. **Session 映射**：通过约定好的 `sessionKey` 格式（`:feishu:group:`）区分飞书群会话
3. **API 桥接**：直接调用飞书 OpenAPI 完成群创建、成员管理、消息发送
4. **配置驱动**：通过 feature gate、channel config 控制功能开关和权限

Agent（智能体）只在以下场景介入：
- 用户在飞书群中 **@Bot 并使用自然语言** 时（如"帮我总结项目进度"）
- 用户要求 Agent 执行**需要推理的任务**时（如"分析当前瓶颈并给出建议"）

对于基础的"消息同步"和"群管理"功能，系统完全通过平台层的**事件路由 + API 调用**完成，Agent 本身并不知道飞书群的存在——它只是在正常的项目会话中收发消息，平台层负责将这些消息"翻译"成飞书消息并发送出去。

---

## 附录：关键源码文件索引

| 文件路径 | 说明 |
|---------|------|
| `~/.openclaw/extensions/arkclaw-team/config/feature-gates.json` | Feature Gate 配置 |
| `~/.openclaw/extensions/arkclaw-team/dist/index.js` | 核心逻辑（群创建、消息同步、权限检查） |
| `~/.openclaw/extensions/openclaw-lark/src/messaging/outbound/chat-manage.js` | 群成员管理 |
| `~/.openclaw/extensions/openclaw-lark/src/tools/oapi/chat/chat.js` | 群搜索/获取工具 |
| `~/.openclaw/.arkclaw-team/channel.json` | 飞书渠道配置和权限缓存 |
| `~/.openclaw/artifact-index/*feishu:group*.json` | 飞书群会话映射索引 |
| `~/.openclaw/.arkclaw-team/notifications/` | 项目通知存储 |

---

*本文档所有内容均基于对项目源码的实际分析，未包含主观臆想或推测性描述。*
