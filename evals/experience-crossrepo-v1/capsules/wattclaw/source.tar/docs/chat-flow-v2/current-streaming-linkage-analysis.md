# 当前对话流式链路梳理文档

## 一、任务目标

深度梳理 WattClaw 系统中【与数字员工的在线对话逻辑】的完整链路，为后续解决"复杂任务断流"问题提供技术文档基础。

## 二、系统架构概览

WattClaw 采用 **四层架构**：

1. **前端 Vue 3 应用** — UI 组件、Pinia Store、API 客户端
2. **Express 后端** (`server/index.js`) — REST 路由、SSE 桥接、会话管理
3. **Gateway WebSocket 代理** (`server/gateway.js`) — 与 OpenClaw Gateway 的持久 WS 连接
4. **ChatStreamProxyService** (`server/services/chat-stream-proxy.ts`) — 直连 Gateway HTTP SSE 的流式代理

## 三、双通道事件架构

系统存在 **两条并行** 的通信通道：

| 通道 | 路径 | 用途 |
|------|------|------|
| **通道 A (状态/监控)** | Browser SSE → Express `/api/events` → Gateway WS | Agent 生命周期、工具调用、状态更新 |
| **通道 B (工作流流式)** | Browser `fetch` + `ReadableStream` → Express `/api/workspace/send` → Gateway HTTP `/v1/chat/completions` | 增量文本流、工具调用增量 |

两条通道同时工作：通道 B 处理增量文本流，通道 A 处理 Agent 状态和工具事件。

## 四、完整对话链路（分阶段）

### Phase A: 用户输入与发送

**WorkspacePage.vue → ChatInput 触发发送**

1. `WorkspacePage.vue` 通过 `wsStore.subscribe('event', ...)` 订阅 SSE 事件，转发给 `workspaceStore.handleEvent()`
2. 用户点击发送 → `workspaceStore.sendMessage(content, displayContent, files, skills)`

**workspace.ts `sendMessage()` 详细流程** (line 1556-1741):

```
1. 确保 sessionKey 存在（不存在则调用 startNewChat() 创建）
2. 设置发送状态 setSessionSending(sessionKey, true)
3. 生成 idempotencyKey: `ws-${Date.now()}-${random}`
4. 创建乐观本地用户消息 → 立即 push 到 sessionMessages
5. 设置 streamState.anchorIndex = nextMsgs.length（锚点）
6. 调用 ensureModelPatched()（HTTP 路径下为空操作）
7. 调用 finalizeOpenActivities() — 清理上一轮未完成的活动
8. POST /api/workspace/send（带 sessionKey, message, model, title）
9. 解析响应为 ReadableStream，逐行解析 SSE data: 行
10. 处理 chunk.choices[0].delta.content → appendStreamingContent()
11. 处理 chunk.choices[0].delta.tool_calls → appendStreamingToolCall()
12. 处理 finish_reason → finalizeStreaming()
```

### Phase B: 后端处理与 Gateway 转发

**`/api/workspace/send` 后端处理** (server/index.js:3884-3928):

```
1. 解析 sessionKey 提取 agentId
2. 调用 chatProxy.connect({ sessionKey, message, model, title, agentId })
3. ChatStreamProxyService.connect():
   - 构建 Gateway URL: /v1/chat/completions
   - 构建请求体: { model: 'openclaw/{agentId}', messages, stream: true }
   - 带 30s connect timeout 的 fetch
4. 返回 ChatStreamHandle
5. 设置 SSE headers，调用 handle.bind(req, res)
6. 绑定后通过 stream.pipeline() 将 Gateway 响应直接 pipe 到浏览器
7. 同时（非阻塞）: trackSessionForUser(), 可选 patch session label
```

**ChatStreamProxyService 生命周期** (chat-stream-proxy.ts):

```
Idle → Streaming → Finalizing → Closed

- 双超时保护: connect timeout (30s) + stream idle timeout (3min)
- 15s keepalive 发送 `:keepalive\n\n`
- 通过 phase gate 保证 finalize 只执行一次
- RAII cleanup registry
- req.once('close') 监听客户端断开
```

**`/api/chat/send` 替代路径** (server/index.js:4222-4297):

用于非工作流页面（如 ChatPage）:
```
1. 验证参数
2. 检查 gateway.isConnected
3. 会话所有权追踪
4. 非阻塞写入用户消息到 PostgreSQL (pending 状态)
5. gateway.call('chat.send', params) 通过 WebSocket
6. 成功: 标记消息 confirmed；失败: 标记 orphaned
```

### Phase C: Gateway 处理与事件回流

**Gateway → 后端 WebSocket 事件** (server/index.js:958-989):

```
gateway.on('event', (event, payload) => {
  1. 提取 sessionKey
  2. 自动追踪会话所有权 (trackSessionForUser)
  3. lifecycle end / chat.final 时:
     - tryAutoTitleForChannelSession(sk)
     - pushTokenUpdate(sk) — 5s cooldown
  4. chat.done / chat.final 时:
     - captureEventMessage(sk, payload) → PostgreSQL
  5. broadcastSSE({ type: 'event', event, payload }, payload)
})
```

**broadcastSSE 所有权过滤** (server/index.js:1120-1152):

```
1. 序列化数据: data: ${JSON.stringify(enriched)}\n\n
2. 遍历 sseClients Map
3. 对 event 类型消息: 检查 sessionKey 是否属于该客户端用户
4. 写入符合条件的客户端 res
```

### Phase D: 前端接收 SSE 事件

**ApiClient (http-client.ts)**:

```
1. 创建 EventSource 到 /api/events?token=...
2. onmessage → handleMessage():
   - type='connected': 存储 clientId
   - type='gatewayState': 更新连接状态
   - type='event': queueMicrotask() 发射到事件总线
   - type='backupProgress': 发射备份进度
3. onerror → handleDisconnect() → scheduleReconnect()
4. 重连: 指数退避 delay = min(3000 * 1.5^attempts, 30000ms), 最多 20 次
```

**OpenClawWebSocket (websocket.ts)**:

```
- 桥接 ApiClient 事件到自身事件系统
- 提供 send() 方法做 RPC 调用（通过 apiClient.rpc）
```

**WebSocketStore (Pinia)**:

```
- 管理 OpenClawWebSocket 实例
- persistentListeners Map: 重连后自动重新绑定监听器
- subscribe(event, handler): 注册持久监听器
```

### Phase E: 工作流 Store 事件处理

**workspace.ts `handleEvent()`** (line 2389-2510):

```
1. 提取 sessionKey（来自 payload 或 fallback 到 activeSessionKey）
2. 调用 handleRealtimeEvent() 处理 agent 活动流:
   - stream='thinking': 创建/更新 thinking 活动
   - stream='tool': 创建/更新 tool 活动 (start/update/result)
   - stream='item': 简化版 tool 事件
   - stream='command_output': 命令输出流
   - stream='assistant': 文本增量（直接覆盖 anchor 内容）
   - stream='compaction': 上下文压缩
   - stream='lifecycle': start/end 标记 Agent 生命周期
3. 非活跃会话的背景处理:
   - 提取消息 → smartMerge → setSessionMessages
   - updateSessionLastActivity()
   - forceStopStreaming()
   - handleNotification()（红点通知）
4. 活跃会话的完成处理 (isFinal || isError || isAgentDone):
   - patchToolResults(filterBootstrapMessages(extractMessages(payload)))
   - 将最后一个消息的 ID 写回 streaming anchor
   - smartMerge(msgs, extracted, anchorIdx, true)
   - forceStopStreaming()
5. 活跃会话的增量处理 (isDelta):
   - 将 deltas 推入 streamState.pendingDeltas
   - 50ms flush timer → flushPendingDeltas()
```

### Phase F: 消息合并与渲染

**smartMerge()** (workspace.ts:627-743):

```
输入: existing[], incoming[], anchorIndex, isStreaming

1. ID 匹配: 如果 incoming 有 id 且 existing 存在相同 id:
   - 内容更长则替换，使用 mergeMessageFields 保留本地 blocks/activities
2. Anchor 匹配: incoming final message 替换 streaming anchor
3. 强去重: incoming 有真实 ID，existing 无 ID，同 role，内容前缀匹配
4. Streaming 紧急守卫: 找最近的无 ID assistant 覆盖
5. Tool message 守卫: 找最近的无 ID tool 覆盖
6. Fingerprint 匹配: role+content 前 120 字符
7. Ultra-emergency: streaming 时覆盖最后一个 assistant（无论 ID）
8. 无匹配则 push 新消息（带 console.warn）
```

**mergeMessageFields()** (workspace.ts:601-625):

```
- 防御性合并: 保留本地构建的 blocks 和 activities
- Richness 比较: 非 text block 权重更高
- 策略: 只有当 incoming 比 existing "更丰富" 时才替换 blocks/activities
```

**parseHistoryMessages()** (workspace.ts:397-573):

```
Layer 1: role 决定 lane (user bubble vs agent pipeline)
Layer 2: assistant 消息遍历 content 数组，每个 block 变为 MessageBlock
         - text → TextBlock
         - toolCall → AgentActivity (type='tool')
         - 相邻 text block 合并
Layer 3: toolResult 不创建新节点，反向查找匹配的 toolCallId 并 patch
```

**MessageList.vue 渲染** (MessageList.vue):

```
1. getRenderBlocks(): 将连续非 text block 分组为 ToolGroupBlock
2. 模板渲染:
   - tool_group → ToolGroupCard（可折叠工具列表）
   - text → MarkdownRenderer（带 :streaming 光标动画）
3. 自动滚动: watch messages 变化，isPinned 时 scrollToBottom()
4. 虚拟滚动: displayCount 初始 10 条，上滑加载更多
```

### Phase G: 历史记录加载

**workspace.ts `selectSession()`** (line 1350-1499):

```
1. 设置 activeSessionKey
2. 清除未读状态
3. 同步 selectedAgentId
4. 取消该会话进行中的历史请求 (AbortController)
5. GET /api/chat/history?sessionKey=...&limit=50
6. 解析响应 → parseHistoryMessages() → filterBootstrapMessages()
7. 处理文件元数据和 skill 命令
8. 与本地 ephemeral 消息合并（保留 streaming anchor 的未完成 activities）
9. setSessionMessages()
```

**后端 `/api/chat/history`** (server/index.js:4413-4541):

```
1. 验证 sessionKey 和所有权
2. PostgreSQL 路径（优先）:
   - countConfirmedMessages() >= limit 或 fullyBackfilled
   - readMessages() 按 seq DESC 读取
   - 返回 raw_content JSONB 原样
3. Gateway fallback:
   - fetch Gateway HTTP /sessions/{key}/history
   - 非阻塞回填到 PG (batchUpsertMessages)
   - 如果 messages.length < limit → 标记 fullyBackfilled
   - 触发 Phase 2 后台回填 (triggerPhase2Backfill)
```

## 五、关键状态机

### Agent 状态机 (chat.ts)

```
idle → sending → waiting → thinking → tool → replying → done/aborted/error
```

- `finalizedRuns` Map: 标记已完成的 runId，5min TTL
- `isRunFinalized()`: 防止已结束 run 的 stale events 改变状态

### Stream 状态机 (workspace.ts)

```
Idle → Streaming → Finalizing → Closed
```

- `streamStates`: Map<sessionKey, StreamState>
- `anchorIndex`: 当前 assistant 消息在数组中的位置
- `pendingDeltas`: 待 flush 的增量消息缓冲

### ChatStreamHandle 状态机 (chat-stream-proxy.ts)

```
Idle → Streaming → Finalizing → Closed
```

- Phase gate 保证 finalize 只执行一次
- 双超时: connect (30s) + idle (3min)
- Keepalive: 15s

## 六、缓冲与流控机制

| 机制 | 位置 | 参数 | 说明 |
|------|------|------|------|
| Stream delta batching | chat.ts | CHUNK_SIZE=8, setTimeout(0) | 流式消息缓冲，避免阻塞主线程 |
| Tool preview throttling | chat.ts | 120ms | 工具更新事件节流 |
| History refresh debounce | chat.ts | 250ms | 历史刷新防抖 |
| Post-send refreshes | chat.ts | 1400ms, 4200ms | 发送后兜底刷新 |
| Token update cooldown | server/index.js | 5000ms | Token 推送冷却 |
| Config queue rate limit | server/index.js | 3 calls/60s | config.patch 限流 |
| Stream flush timer | workspace.ts | 50ms | SSE delta 缓冲 |
| Stream idle timeout | workspace.ts | 60000ms | 无事件 60s 强制停止 |
| Max stream timeout | workspace.ts | 300000ms | 绝对 5min 上限 |

## 七、数据模型

### Session Key 格式

```
agent:{agentId}:{channel}:{type}:{peer}
```

- agentId 提取: `^agent:([^:]+):`
- 用于: 状态隔离、所有权验证、模型解析

### 消息结构 (ChatMessage)

```typescript
interface ChatMessage {
  id?: string
  role: 'user' | 'assistant' | 'tool' | 'system'
  content: string
  timestamp?: string
  activities?: AgentActivity[]    // 实时活动（thinking/tool/command）
  blocks?: MessageBlock[]         // 渲染块（text | thinking | tool | command_output）
  files?: Array<{ name, size }>
  skills?: string[]
  stopReason?: string
}
```

### 双数据库设计

| 数据库 | 用途 | 表 |
|--------|------|-----|
| SQLite | 元数据 | users, user_agents, user_sessions, user_channels, agent_team |
| PostgreSQL | 消息内容 | session_messages (seq, msg_id, role, content, raw_content, model, status) |

## 八、断流风险点分析（为后续修复准备）

### 已知脆弱环节

1. **双通道竞争**: 通道 A (SSE 事件) 和通道 B (HTTP 流式) 同时修改同一条消息，存在竞态
2. **Anchor 漂移**: smartMerge 的 ultra-emergency 路径可能错误覆盖非目标消息
3. **Stale Event 处理**: finalizedRuns 5min TTL 后，旧 run 的事件可能被误判为新 run
4. **Stream 超时**: 60s idle timeout 对长工具调用可能过短
5. **History 覆盖**: fetchHistory 可能覆盖 streaming anchor 的未完成 activities
6. **PG 回填延迟**: Gateway fallback 路径的异步回填可能导致短暂的数据不一致
7. **SSE 重连**: 重连期间（最多 30s）事件丢失，无补偿机制
8. **Tool Result 孤儿**: patchToolResults 找不到匹配 toolCallId 时产生孤儿消息

## 九、关键文件索引

| 文件 | 职责 |
|------|------|
| `src/views/workspace/WorkspacePage.vue` | 工作流页面，事件订阅入口 |
| `src/views/workspace/MessageList.vue` | 消息列表渲染，虚拟滚动 |
| `src/stores/workspace.ts` | 核心工作流状态：消息、流式、活动、历史 |
| `src/stores/chat.ts` | 旧版聊天状态（Agent 状态机、工具进度） |
| `src/stores/websocket.ts` | WebSocket/SSE 连接管理，持久监听器 |
| `src/api/http-client.ts` | SSE EventSource 客户端，重连逻辑 |
| `src/api/websocket.ts` | WebSocket 包装器，事件桥接 |
| `src/api/chat-client.ts` | REST 聊天客户端（send/abort/history） |
| `server/index.js` | Express 服务器：REST 路由、SSE 广播、事件转发 |
| `server/gateway.js` | Gateway WebSocket 客户端 |
| `server/services/chat-stream-proxy.ts` | HTTP SSE 流代理，生命周期管理 |
| `server/message-store.js` | PostgreSQL 消息存储接口 |
| `server/backfill-queue.js` | 后台历史回填队列 |

## 十、后续建议

为排查"复杂任务断流"问题，建议按以下顺序深入：

1. **监控双通道事件时序**: 在 handleEvent 和 appendStreamingContent 添加详细日志，观察通道 A/B 事件的到达顺序
2. **检查 Anchor 稳定性**: 验证 streamState.anchorIndex 在长工具调用期间是否被意外修改
3. **分析 finalizeOpenActivities**: 确认该函数是否过早清除了本应持续的活动
4. **评估超时参数**: 测试 60s idle timeout 对复杂多步任务的影响
5. **审查 smartMerge 日志**: 关注 console.warn 触发的 PUSH new message 情况
