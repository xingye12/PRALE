# HTTP+WS 分离架构分析：复杂任务断流问题根因

> 分析时间：2026-05-30
> 分支：`test/http-ws-separation`
> 问题：复杂任务（多步工具调用）收不到后续数据

---

## 一、问题现象

- **简单对话**（纯文本回复）：✅ 正常
- **复杂任务**（需要工具调用、命令执行）：❌ 丢失中间过程，前端状态不同步

---

## 二、架构对比

### 主分支（纯 WebSocket）

```
前端 ──► gateway.call('chat.send') ──► Gateway WS
  ▲                                         │
  └────────── 完整事件流 ────────────────────┘

事件顺序（严格单一通道）：
lifecycle:start → thinking → text1 → command_output → tool → text2 → lifecycle:end
```

| 优点 | 缺点 |
|------|------|
| 单一通道，天然有序 | 多用户并发时队头阻塞 |
| 完整事件（文本+lifecycle） | 共享一个 WS 连接，RPC 排队等待 |
| 前端逻辑简单 | |

### 当前分支（HTTP SSE + EventSource）

```
发送：前端 fetch ──► /api/workspace/send ──► Gateway HTTP /v1/chat/completions
                                                          │
接收：前端 EventSource ◄── /api/events ◄── 后端 Gateway WS 事件转发
```

| 优点 | 缺点 |
|------|------|
| HTTP 独立连接，不阻塞 | **双通道，无时序保证** |
| 多用户并发性能好 | **丢失 lifecycle 事件** |
| | 前端需处理两个独立数据源 |

---

## 三、根因确认：Gateway HTTP SSE 只返回 OpenAI 格式

通过阅读 OpenClaw Gateway 源码（`src/gateway/openai-http.ts`）确认：

### `/v1/chat/completions` 只输出标准 OpenAI SSE：

```
data: {"choices":[{"delta":{"role":"assistant"}}]}
data: {"choices":[{"delta":{"content":"..."}}]}
data: {"choices":[{"delta":{"tool_calls":[...]}}]}
data: {"choices":[{"delta":{},"finish_reason":"stop"}]}
data: [DONE]
```

### 不输出这些事件：

| 事件类型 | 含义 |
|---------|------|
| `lifecycle:start/end/error` | Agent 生命周期 |
| `thinking` | Agent 思考过程 |
| `tool` | 工具调用 |
| `item` | 中间产物 |
| `command_output` | 命令执行输出 |
| `plan` | 执行计划 |
| `approval` | 等待用户确认 |

**这些事件只在 Gateway 内部 WebSocket 事件总线流转，HTTP SSE 处理器直接忽略。**

---

## 四、为什么"丢失 lifecycle"会导致复杂任务断流

### 举个例子：Agent 执行"部署服务"

**WebSocket 收到的完整事件流：**

```
1. lifecycle:start    → Agent 开始工作
2. thinking           → "我需要先检查当前状态..."
3. command_output     → docker ps 的输出
4. tool               → 调用 Docker 工具
5. item               → 中间结果
6. assistant          → "正在为您部署..."
7. command_output     → docker run 的输出
8. lifecycle:end      → 完成
```

**HTTP SSE 只能看到：**

```
data: {"choices":[{"delta":{"content":"正在为您部署..."}}]}
data: [DONE]
```

中间的 `docker ps` 输出、工具调用过程、思考过程**全部丢失**。

### 前端 `workspace.ts` 的关键逻辑

```typescript
// 当前分支 sendMessage() 只处理文本流
reader.read().then(({value}) => {
  const chunk = parseSse(value);
  if (chunk.choices[0].delta.content) {
    appendStreamingContent(chunk);  // ✅ 有文本
  }
  // ❌ 没有 handleEvent() 处理 lifecycle/thinking/tool
});
```

而主分支的 `handleEvent()` 会处理：

```typescript
if (event.type === 'lifecycle') {
  // 更新 Agent 状态
}
if (event.type === 'thinking') {
  // 显示思考过程
}
if (event.type === 'command_output') {
  // 显示命令输出
}
if (event.type === 'tool') {
  // 显示工具调用
}
```

---

## 五、队头阻塞问题详解

### 阻塞位置

```
用户A 请求 ──► WattClaw 后端 ──► await gateway.call('chat.send') ──► 等待 ◄── 阻塞点
用户B 请求 ──► WattClaw 后端 ──► await gateway.call('chat.send') ──► 等待      （共享单连接）
用户C 请求 ──► WattClaw 后端 ──► await gateway.call('chat.send') ──► 等待
```

**阻塞的是 WattClaw 后端 `server/gateway.js` 的 RPC 调用队列，不是 OpenClaw Gateway。**

### 代码位置

```javascript
// server/gateway.js
call(method, params, timeout = 30000) {
  return new Promise((resolve, reject) => {
    this.ws.send(JSON.stringify({id, method, params}));
    this.pendingCalls.set(id, {resolve, reject, timer});  // ← 等待响应
  });
}
```

所有用户请求经过同一个 `gateway` 单例，共享一个 WebSocket 连接。

---

## 六、方案评估

### 方案 1：回退到纯 WebSocket（主分支方式）

```
前端 WebSocket ──► 后端 gateway.call() ──► Gateway WS
```

| 维度 | 评估 |
|------|------|
| 时序正确性 | ✅ 单一通道，严格有序 |
| 功能完整性 | ✅ 完整事件 |
| 并发性能 | ❌ 队头阻塞 |
| 实现复杂度 | 低 |
| 风险 | 多用户并发时性能下降 |

**适用场景**：用户量小，或能接受串行处理。

---

### 方案 2：后端把 lifecycle 注入 SSE 流

```
前端 fetch ──► 后端 ──► Gateway HTTP（文本）──┐
                                              ├──► 后端合并 ──► 单一 SSE ──► 前端
后端 WS 监听 ──► Gateway WS（lifecycle）──────┘
```

| 维度 | 评估 |
|------|------|
| 时序正确性 | ⚠️ 后端可控制合并顺序 |
| 功能完整性 | ✅ 完整 |
| 并发性能 | ✅ 不阻塞 |
| 实现复杂度 | **高** |
| 风险 | 后端流控复杂，需维护两个 Gateway 连接 |

**技术难点**：
- 后端需要同时维护 HTTP 和 WebSocket 两个连接
- 需要按 `runId` 关联 lifecycle 和文本流
- 流控和错误处理复杂

---

### 方案 3：前端双通道（HTTP + EventSource）

```
前端 fetch ──► /api/workspace/send ──► HTTP SSE（文本）
前端 EventSource ◄── /api/events ◄── Gateway WS（lifecycle）
```

| 维度 | 评估 |
|------|------|
| 时序正确性 | ❌ **无保证，两个独立通道** |
| 功能完整性 | ✅ 理论上完整 |
| 并发性能 | ✅ 不阻塞 |
| 实现复杂度 | 中 |
| 风险 | **消息错乱、状态不一致** |

**具体时序问题**：

```
时间线：
─────────────────────────────────────────────────────►

HTTP SSE:     ──文本1──文本2────文本3────────[DONE]
EventSource:  ────────lifecycle:start────lifecycle:end──

问题 1：lifecycle:end 先到，文本后到
→ 前端以为完成了，但后面还有文本

问题 2：两个用户同时发消息
→ EventSource 广播所有事件，需严格按 runId 过滤

问题 3：HTTP 连接断开，但 lifecycle 没收到
→ 前端不知道 Agent 状态
```

---

### 方案 4：非阻塞 WebSocket（改造 gateway.js）

```javascript
// 改造 gateway.js
gateway.send('chat.send', {...});  // 只发送，不等待
// 响应通过事件异步接收
gateway.on('event', (event) => {
  if (event.runId === runId) {
    // 处理响应
  }
});
```

| 维度 | 评估 |
|------|------|
| 时序正确性 | ✅ 单一通道 |
| 功能完整性 | ✅ 完整 |
| 并发性能 | ✅ 不阻塞（发送后立即返回） |
| 实现复杂度 | **高** |
| 风险 | 需改造前后端事件处理逻辑 |

**本质**：再造一个当前分支的架构，但用 WebSocket 替代 HTTP。

---

## 七、结论与建议

### 核心结论

1. **Gateway HTTP SSE 只返回 OpenAI 格式**，不含 lifecycle/thinking/tool 等事件（源码确认）
2. **当前分支丢失 lifecycle 是设计使然**，不是 Bug
3. **双通道（HTTP + EventSource）存在时序风险**，无法严格保证消息顺序
4. **队头阻塞是 WattClaw 后端问题**，不是 OpenClaw Gateway 限制

### 修复建议

| 优先级 | 方案 | 说明 |
|--------|------|------|
| **推荐** | 回退到 WebSocket RPC | 简单可靠，时序正确。队头阻塞可通过多连接或异步化后续优化 |
| 备选 | 后端合并单流 | 保持 HTTP 不阻塞优势，但实现复杂 |
| 不推荐 | 前端双通道 | 时序无法保证，消息错乱风险高 |

### 如果选择回退 WebSocket

需要修改的文件：
- `src/stores/workspace.ts:sendMessage()` — 从 fetch SSE 改为 `gateway.call('chat.send')`
- `src/stores/workspace.ts:handleEvent()` — 恢复 lifecycle/thinking/tool 处理
- 可选：`server/index.js` — 保留 HTTP 路径作为备选

### 如果选择保持 HTTP

必须解决 lifecycle 注入问题：
- `server/services/chat-stream-proxy.js` — 增加 WebSocket 事件监听和合并逻辑
- `src/stores/workspace.ts` — 修改 SSE 解析器，支持合并后的事件格式
- 需要严格的 `runId` 关联和流控机制

---

## 八、参考源码位置

| 文件 | 职责 |
|------|------|
| `src/stores/workspace.ts:1556-1751` | 当前分支 sendMessage()，fetch SSE 解析 |
| `src/stores/workspace.ts:2389-2510` | handleEvent()，处理 lifecycle/thinking/tool |
| `server/index.js:3889-3984` | `/api/workspace/send` 端点，HTTP SSE 透传 |
| `server/services/chat-stream-proxy.js` | ChatStreamProxyService，只解析 OpenAI SSE |
| `server/gateway.js` | WebSocket 客户端，`call()` 阻塞 RPC |
| OpenClaw `src/gateway/openai-http.ts` | Gateway HTTP SSE 端点实现 |
| OpenClaw `src/infra/agent-events.ts` | Agent 事件类型定义 |
