# 历史记录缓存方案：Response Cache + Event Invalidation

## 定位

方案一（轻量级），在 WattClaw 后端加一层内存 LRU 缓存，缓存 `GET /api/chat/history` 的完整响应。利用已有的 Gateway SSE 事件流做精准失效，不引入任何外部依赖。

## 核心收益

| 场景 | 改造前 | 改造后 |
|------|-------|-------|
| 同一 Agent 内来回切换 | 快（Gateway 内部缓存） | 更快（WattClaw 内存，<5ms） |
| 跨 Agent 切换（首次） | ~10s | ~10s（Cache Miss，无法避免） |
| 跨 Agent 切换（2 次+） | ~10s | <5ms（Cache Hit） |
| 用户发消息后查看历史 | ~10s | 回源后 <5ms（发消息时预失效） |
| 刷新页面后 | ~10s | 首次 ~10s，后续 <5ms |

用户最常见的行为模式（在 2~3 个 Agent 间来回工作）将完全消除卡顿。

---

## 1. 缓存数据结构

```
Key:   history:{sessionKey}:{limit}
Value: { messages: [...], cursor: string|null, hasMore: boolean, cachedAt: number }
```

示例：

```
Key:   history:agent:agent-1778682848359:mp4x8hls-azxk3jsj:50
Value: { messages: [50 条消息], cursor: null, hasMore: false, cachedAt: 1748352000000 }
```

## 2. 缓存容器

LRU Map，设容量上限，自动淘汰最久未访问的条目。

```
容量上限: 2000 条
  └─ 150 用户 × 平均每人活跃 5~10 个会话 × 2（不同 limit 变体）≈ 1500~3000

单条大小: ~50KB（50 条消息 JSON）
总内存: 2000 × 50KB ≈ 100MB，完全可接受
```

---

## 3. 读取时序

改造 `GET /api/chat/history` 端点（`server/index.js:4299`）：

```
用户请求 GET /api/chat/history?sessionKey=X&limit=50
  ↓
① authMiddleware                    — JWT 校验（已有，不变）
② isSessionOwned(X, userId)         — 所有权检查（已有，不变）
  ↓
③ 查缓存 LRU.get("history:X:50")
  ├─ Hit  → 直接返回缓存数据       — <5ms，到此结束
  └─ Miss → 继续 ↓
④ fetch Gateway HTTP                — 走原有链路，耗时 1~10s
  ↓
⑤ 写入缓存 LRU.set("history:X:50", response)
  ↓
⑥ 返回响应
```

所有权检查在缓存查询之前，所以不需要在缓存 key 中加 userId。不同用户请求同一个 session 得到的是相同数据。

---

## 4. 失效机制（三层保障）

### 第一层：事件驱动失效（实时，精度最高）

WattClaw 后端已有 Gateway SSE 事件监听器（`gateway.on('event')`）。在事件处理中加 cache.delete：

| 触发时机 | 事件 | 失效操作 |
|---------|------|---------|
| 聊天完成 | Gateway SSE `chat.done` / `chat.final` | `cache.deleteByPrefix("history:{sessionKey}:")` |
| Agent 运行完成 | Gateway SSE `agent.done` | `cache.deleteByPrefix("history:{sessionKey}:")` |
| 会话生命周期结束 | Gateway SSE lifecycle `phase=end` | `cache.deleteByPrefix("history:{sessionKey}:")` |
| 会话重置 | Gateway SSE session reset 相关事件 | `cache.deleteByPrefix("history:{sessionKey}:")` |

用 `deleteByPrefix` 是因为同一个 sessionKey 可能有多个 limit 变体（`history:X:50`、`history:X:100`），需要全部失效。

### 第二层：用户发消息时预失效（主动）

在 `POST /api/chat/send` 和 `/api/workspace/send` 端点中，消息发送成功后立即失效缓存。**不等 Gateway 事件回来**，因为用户发完消息后最可能立即查看历史。

### 第三层：TTL 兜底（被动）

每条缓存 120s 自动过期。即使事件丢失（网络抖动、Gateway 重连窗口），最多 2 分钟后缓存自动失效，下次请求重新从 Gateway 拉取。

---

## 5. 并发请求去重

同一个 sessionKey 可能同时被多个请求命中 Cache Miss（比如用户快速双击）。加一个 in-flight Map 防止重复请求：

```
用户快速点击会话 A 两次
  ↓
请求 1: Cache Miss → 记录 _inflight.set("history:A:50", promise) → fetch Gateway
请求 2: Cache Miss → 发现 _inflight 已有 → await 同一个 promise
  ↓
Gateway 只收到 1 个请求，两个请求共享同一份结果
```

---

## 6. 与 pushTokenUpdate debounce 的协作

当前已有 `pushTokenUpdate` 5s debounce + History 完成后 flush。加入缓存后：

- **Cache Hit 时**：不触发 `flushPendingTokenUpdate`（因为根本没有 Gateway 请求）
- **Cache Miss 时**：不变，History 完成后仍然 flush

---

## 7. 改动范围

只改一个文件 `server/index.js`，预估 ~60 行：

```
+ const historyCache = new LRUCache({ max: 2000, ttl: 120_000 })
+ const _historyInflight = new Map()

  GET /api/chat/history 路由:
    + 缓存查询（3 行）
    + 并发去重（5 行）
    + 缓存写入（3 行）

  Gateway SSE 事件处理:
    + 失效调用（每处 1 行 × 4 处 = 4 行）

  POST /api/chat/send:
    + 预失效（1 行）
```

---

## 8. 不做的事

- 不引入 Redis 或其他外部缓存服务
- 不预加载（方案二的内容，按需追加）
- 不存储消息到本地数据库（方案三的内容，按需追加）
- 不修改 OpenClaw Gateway 源码
- 不在前端做任何改动

---

## 9. 验证步骤

1. 启动服务，打开聊天页，切换到一个跨 Agent 会话
2. 第一次切换：APM 日志显示 Cache Miss + Gateway 请求（~10s）
3. 切回再切到同一会话：APM 日志显示 Cache Hit（<5ms），无 Gateway 请求
4. 在该会话发一条消息，再查看历史：APM 显示 Cache Miss（预失效生效）→ 回源 → 再次 Cache Hit
5. 等待 120s 后再访问：APM 显示 Cache Miss（TTL 过期）→ 回源 → Cache Hit
6. 多用户并发：不同用户访问各自会话互不干扰

---

*设计日期：2026-05-28*
*前置分析文档：[history-fetch-chain-analysis.md](./history-fetch-chain-analysis.md)*
