# 历史记录获取链路分析

本文档记录点击会话后获取聊天历史的完整链路，以及跨 Agent 切换时 10s+ 卡顿的根因分析。

## 问题现象

- 同一 Agent 内切换会话 → 响应很快（缓存命中）
- 切换到另一个 Agent 的会话 → ~10s 卡顿

示例请求：
```
GET http://192.168.10.12:3002/api/chat/history?sessionKey=agent%3Aagent-1778682848359%3Amp4x8hls-azxk3jsj&limit=50
```

## 完整链路

```
用户点击侧边栏会话
  ↓
ChatPage.handleSessionKeyChange()                    [src/views/chat/ChatPage.vue:1032]
  ↓
ChatPage.loadHistoryForKey(key, { force: true })     [src/views/chat/ChatPage.vue:1007]
  ├─ writeStoredSessionKey(key)                      — 持久化到 localStorage
  ├─ chatStore.setSessionKey(key)                    — 重置 agent 状态、stream 缓冲区
  ↓
chatStore.fetchHistory(key)                          [src/stores/chat.ts:334]
  ├─ loading = true
  ↓
chatClient.history(key, 50)                          [src/api/chat-client.ts:100]
  ↓  HTTP GET /api/chat/history?sessionKey=X&limit=50
  ↓
server/index.js GET /api/chat/history                [server/index.js:4299]
  ├─ authMiddleware                                  — JWT 校验
  ├─ isSessionOwned(key, userId)                     — 所有权检查（本地 SQLite）
  ├─ fetch → Gateway HTTP                            — 直接 HTTP 代理到 Gateway
  ├─ extractMessagesFromHistoryPayload()             — 归一化消息字段
  ├─ flushPendingTokenUpdate(sessionKey)             — History 完成后刷新延迟的 token 更新
  ↓
  ← { ok: true, payload: { messages, cursor, hasMore } }
  ↓
chatStore: messages.value = response.messages
  ↓
nextTick() → scrollToBottom()                        [ChatPage.vue:1021]
```

## WattClaw 后端侧（确认无问题）

WattClaw 后端构造的是**精确的单会话请求**：

```
GET http://192.168.10.12:18789/sessions/agent%3Aagent-xxx%3Ayyy/history?limit=50
Authorization: Bearer <OPENCLAW_AUTH_TOKEN>
```

- 只传了目标 sessionKey，没有 agent 级别的聚合参数
- 没有多余请求（没有并行获取该 agent 的所有会话）
- Gateway 返回后只做 `extractMessagesFromHistoryPayload` 提取消息

## Gateway 侧（瓶颈所在）

Gateway `chat.history` RPC handler 位于 `server-methods/chat.ts:2137`。

### 处理步骤

```
1. loadSessionEntry(sessionKey)                      — 读磁盘 JSON 文件
   ├─ resolveGatewaySessionStoreTarget()             — 按 agentId 确定文件路径
   └─ loadSessionStore(storePath)                    — readFileSync + JSON.parse
                                                       ⚠️ 该文件包含此 agent 下所有会话的元数据

2. readRecentSessionMessagesAsync(sessionId, ...)    — 读取目标 session 的 transcript 文件
   └─ readRecentTranscriptTailLinesAsync()           — 读文件尾部，按 maxMessages 截断

3. projectChatDisplayMessages(messages, ...)         — CPU 密集的消息投影
   ├─ stripEnvelopeFromMessages()
   ├─ mirrorMessageToolVisibleReplies()
   ├─ filterVisibleProjectedHistoryMessages()
   ├─ toProjectedMessages(sanitizeChatHistoryMessages())
   └─ sanitizeChatHistoryMessages(merged, maxChars)

4. capArrayByJsonBytes() + enforceChatHistoryFinalBudget() — 字节预算裁剪
```

### 各步骤耗时分析

| 步骤 | 源码位置 | 粒度 | 耗时原因 |
|------|---------|------|---------|
| `loadSessionStore` | `src/config/sessions/store-load.ts:352` | 按 agent | 磁盘 I/O + JSON.parse，文件含该 agent 所有会话元数据 |
| `readRecentSessionMessagesAsync` | `src/gateway/session-utils.fs.ts:652` | 按 session | 读 transcript 文件尾部 |
| `projectChatDisplayMessages` | `src/gateway/chat-display-projection.ts:1201` | 按 session | CPU 密集：多次遍历、过滤、裁剪 |
| `capArrayByJsonBytes` | 同上 | 按 session | 字节预算裁剪 |

### 为什么同一 Agent 快、换 Agent 慢？

1. **`loadSessionStore` 有内存缓存**（`isSessionStoreCacheEnabled()` + `readSessionStoreCache`）
   - 同一 agent 的多次请求命中缓存 → 直接返回，不走磁盘
   - 切换到新 agent → 缓存 miss → `readFileSync` + `JSON.parse`
   - agent 下会话越多（如 20 个），store 文件越大，解析越慢

2. **`projectChatDisplayMessages` 是纯 CPU 操作**
   - 对消息做多次遍历投影（strip envelope → mirror → filter → project → sanitize）
   - 在 Gateway 单线程 Node.js event loop 上执行，阻塞所有其他请求

3. **`pushTokenUpdate` 竞争**（已在 WattClaw 侧缓解）
   - Gateway 事件（`chat.done`/`agent.done`）触发 `pushTokenUpdate` → `callGatewayUsage`
   - `callGatewayUsage` 底层是 `gateway.call('sessions.usage', ...)`——**WebSocket RPC**，不是 HTTP
   - 之前的实现是立即执行，与 History HTTP 请求竞争 Gateway 单线程 event loop
   - 现已改为 5s debounce + History 完成后 flush

## 结论

WattClaw 侧请求精确无误，瓶颈完全在 OpenClaw Gateway 内部：

1. **Session Store 磁盘 I/O**：按 agent 粒度加载包含所有会话元数据的 JSON 文件
2. **消息投影 CPU 开销**：`projectChatDisplayMessages` 多轮遍历处理
3. **单线程 event loop**：上述 I/O + CPU 在同一进程内串行执行

## WattClaw 侧已实施的缓解措施

1. **pushTokenUpdate debounce**（commit `fd257c1`）：延迟 `callGatewayUsage`（WebSocket RPC `sessions.usage`）调用，避免与 History HTTP 请求竞争 Gateway event loop
2. **deferred usage pattern**：前端 `fillSessionsUsage()` 在 History 完成后非阻塞执行
3. **SSOT 收敛**：消除 ChatPage/AgentChatPanel 中的本地 token usage ref，统一从 sessionStore 读取

## 彻底解决方案（需 OpenClaw 侧改动）

- Gateway 侧为 `loadSessionStore` 实现按 session 的索引查询（避免加载整个 agent store）
- `projectChatDisplayMessages` 改为流式处理或移到 worker thread
- Gateway HTTP endpoint 增加 per-request 性能指标（目前已有的 APM 仅在 WattClaw 侧）

---
*分析日期：2026-05-28*
*基于 OpenClaw 源码 commit 时的 chat.history handler（server-methods/chat.ts:2137）*
