# 本地历史存储架构与链路全景文档

> 版本：v1.0 | 日期：2026-05-28 | 分支：test/http-ws-separation
> 提交范围：`c6be160` ~ `541739f`（11 commits, +722 行）

---

## 一、架构抉择与设计哲学 (Why)

### 1.1 问题根源

WattClaw 的聊天历史完全依赖 OpenClaw Gateway。每次用户切换会话，前端 `GET /api/chat/history` → WattClaw 后端 → HTTP 代理到 Gateway → Gateway 处理 `chat.history` RPC。

Gateway 的处理链路：

```
loadSessionStore(agentId)          ← 按 agent 粒度加载 JSON（含该 agent 所有会话元数据）
  → readFileSync + JSON.parse     ← 磁盘 I/O + CPU 解析
readRecentSessionMessagesAsync()   ← 读取 session transcript 文件尾部
projectChatDisplayMessages()       ← CPU 密集：5 轮遍历（strip → mirror → filter → project → sanitize）
```

Gateway 是单线程 Node.js 进程。同一 agent 内切换快（内存缓存命中），跨 agent 切换触发缓存 miss → 磁盘 I/O + CPU 投影 → **10~12 秒卡顿**。

### 1.2 方案演进

| 阶段 | 方案 | 结论 |
|------|------|------|
| v0 | 直接透传 Gateway | 现状，10s 卡顿 |
| v1 | 内存 LRU 缓存 | 治标不治本：重启丢失、无法持久化、冷启动仍慢 |
| **v2** | **PostgreSQL 本地存储** | **选定方案**：持久化、索引查询 <10ms、可扩展 |

### 1.3 核心设计决策

**决策 1：双库分离（SQLite + PostgreSQL）**

```
SQLite（已有）          → 元数据：users, agents, sessions, channels, backup
PostgreSQL（新增）      → 消息：session_messages 表
```

- SQLite 回答"这是谁的会话？"
- PostgreSQL 回答"这个会话里说了什么？"
- 通过 `session_key` 字符串关联，无外键约束，零耦合

为什么不把消息也放 SQLite？150 用户 × 1000 条/天 = 15 万条/天。SQLite 单写锁在高并发写入时性能劣化。PostgreSQL 的 JSONB 索引 + MVCC 并发写入更适合消息场景。

**决策 2：WattClaw 是只读副本，不是双主**

```
Gateway = 权威数据源（Source of Truth）
WattClaw PG = 读副本（Read Replica）
```

- 写入路径：捕获经过 WattClaw 的每条消息（best-effort），写入失败不阻塞主流程
- 读取路径：PG 优先，不够时从 Gateway 回填
- 不做实时双向同步，不做主动 Gateway 定时拉取

**决策 3：懒回填（Lazy Backfill）**

不做一次性全量迁移。用户首次访问某会话时，Phase 1 从 Gateway 拉取 → 写入 PG → 后续请求直接读 PG。渐进式填充，零启动开销。

**决策 4：零前端改动**

API 契约不变：`{ ok: true, payload: { messages, cursor, hasMore } }`。前端完全无感知。

### 1.4 效果预估

| 场景 | 改造前 | 改造后 |
|------|--------|--------|
| 同 Agent 内切换 | 快 | <10ms（PG） |
| 跨 Agent 首次切换 | ~10s | ~10s（Gateway 回填，一次性） |
| 跨 Agent 二次切换 | ~10s | <10ms（PG） |
| 发消息后查看历史 | ~10s | <10ms（写时已捕获） |
| 服务器重启后 | ~10s | <10ms（PG 持久化，localCount > 0 即命中） |
| 滚动加载更多 | ~10s | <10ms（已回填）或 ~10s（未回填） |

---

## 二、核心数据流与完整链路 (How)

### 2.1 系统全景

```
┌──────────────────────────────────────────────────────────────────────┐
│                           Frontend                                   │
│  ChatPage → chatStore.fetchHistory() → GET /api/chat/history        │
│  ChatPage → chatStore.sendMessage() → POST /api/chat/send           │
│  ChatPage → useEventStream() → GET /api/events (SSE)               │
└──────────┬───────────────────────────────────────┬──────────────────┘
           │ HTTP                                  │ SSE
┌──────────▼───────────────────────────────────────▼──────────────────┐
│                     WattClaw Backend (Express)                       │
│                                                                      │
│  ┌─────────────┐   ┌──────────────┐   ┌────────────────────────┐   │
│  │ GET /history │   │ POST /send   │   │ gateway.on('event')    │   │
│  │             │   │              │   │                        │   │
│  │ ① PG read  │   │ ① PG write   │   │ chat.done / chat.final │   │
│  │ ② GW fall  │   │ ② GW forward │   │ ① PG write (confirmed)│   │
│  │ ③ PG backf │   │ ③ PG confirm │   │ ② SSE broadcast       │   │
│  └──────┬─────┘   └──────┬───────┘   └────────────┬───────────┘   │
│         │                │                         │                 │
│  ┌──────▼────────────────▼─────────────────────────▼─────────────┐  │
│  │               server/message-store.js                         │  │
│  │  PostgreSQL Pool → upsert / read / delete / batchUpsert       │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │               server/backfill-queue.js                       │  │
│  │  Global queue (2 concurrent, 500ms) → preload / phase2       │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
└──────────┬──────────────────────────────────────────────────────────┘
           │ WebSocket                  │ HTTP
┌──────────▼──────────┐    ┌───────────▼──────────────────────────────┐
│  OpenClaw Gateway   │    │  PostgreSQL (wattclaw-postgres)           │
│  (Single-threaded)  │    │                                           │
│  chat.history RPC   │    │  session_messages table                   │
│  chat.send RPC      │    │  ├── session_key + seq (UNIQUE)          │
│  sessions.reset     │    │  ├── role / content / raw_content (JSONB) │
│  sessions.delete    │    │  ├── status (pending/confirmed/orphaned)  │
│                     │    │  └── created_at                          │
└─────────────────────┘    └──────────────────────────────────────────┘
```

### 2.2 写路径 A：用户发消息

```
用户输入 "你好" → POST /api/chat/send { sessionKey, message, idempotencyKey }
  │
  ├─ ① ownership check + auto-track
  │
  ├─ ② getNextSeq(sessionKey)                          ← PG: advisory lock → MAX(seq)+1
  │     → seq = 5
  │
  ├─ ③ upsertMessage({ seq:5, role:'user', status:'pending' })  ← PG: 非阻塞写入
  │     （fire-and-forget，不 await）
  │
  ├─ ④ gateway.call('chat.send', params)               ← Gateway RPC
  │     │
  │     ├─ 成功 → updateMessageStatus(seq:5, 'confirmed')     ← PG: 确认
  │     │          return { ok: true, payload: { runId, status } }
  │     │
  │     └─ 失败 → updateMessageStatus(seq:5, 'orphaned')      ← PG: 废弃
  │                return 502 { error: "Gateway chat.send failed" }
  │
  └─ 前端收到响应后开始接收 SSE 流式事件
```

**关键防御**：`pending` 状态消息不会被读取路径返回。只有 `confirmed` 的消息对用户可见。Gateway 拒绝的消息变成 `orphaned`，用户永远不会看到幽灵消息。

### 2.3 写路径 B：Gateway SSE 事件到达

```
Gateway 处理完成 → emit('event', 'chat.done', payload)
  │
  ├─ payload.sessionKey = "agent:xxx:yyy"
  │
  ├─ ① WattClaw 后端 gateway.on('event') 接收
  │     ├─ auto-track session ownership
  │     ├─ pushTokenUpdate(sk)
  │     └─ captureEventMessage(sk, payload)           ← PG 写入
  │           ├─ 提取 content / role / model
  │           ├─ getNextSeq(sessionKey)
  │           └─ upsertMessage({ status:'confirmed' })
  │
  └─ ② broadcastSSE → 转发给前端 SSE 客户端
```

**关键设计**：事件捕获是 best-effort，`.catch()` 不阻塞 SSE 广播。即使 PG 写入失败，用户仍能通过 SSE 实时看到消息。

### 2.4 读路径：获取历史记录

```
GET /api/chat/history?sessionKey=X&limit=50
  │
  ├─ authMiddleware + isSessionOwned()
  │
  ├─ ── PostgreSQL 读取路径 ──
  │     │
  │     ├─ countConfirmedMessages(X)                    ← PG: SELECT COUNT
  │     │     → localCount = 2
  │     │
  │     ├─ 条件判断：localCount > 0                      ← 只要 PG 有数据就命中
  │     │   Rationale: PG 数据是 confirmed 且可信的。缺失的最新消息会通过 SSE
  │     │   实时捕获写入 PG。唯一需要 Gateway 回退的情况是 PG 完全为空。
  │     │
  │     ├─ [如果命中] readMessages(X, { limit:50 })     ← PG: SELECT seq DESC LIMIT 50
  │     │     ├─ rows.map(r => r.raw_content || {...})  ← JSONB 自动解析为 JS 对象
  │     │     ├─ messages.reverse()                     ← DESC → chronological
  │     │     ├─ cursor = oldestSeq > 1 ? oldestSeq : null
  │     │     └─ return { messages, cursor, hasMore }   ← <10ms
  │     │
  │     └─ [如果未命中] 继续到 Gateway 回退 ↓
  │
  ├─ ── Gateway 回退路径 ──
  │     │
  │     ├─ fetch Gateway HTTP: GET /sessions/{key}/history?limit=50
  │     │     → 等待 1~12s（取决于 agent 缓存是否命中）
  │     │
  │     ├─ extractMessagesFromHistoryPayload(gatewayData)
  │     │
  │     ├─ Phase 1 回填（非阻塞，不 await）：
  │     │   batchUpsertMessages(key, messages.map(seq: i+1))
  │     │     → PG 写入 50 条 confirmed 消息
  │     │
  │     ├─ Phase 2 后台全量回填：
  │     │   triggerPhase2Backfill → enqueueBackfill(limit=1000)
  │     │     → 全局队列（2 并发，500ms 间隔）
  │     │     → fetchHistoryFromGateway(key, 1000)
  │     │     → batchUpsertMessages(key, allMessages)
  │     │
  │     └─ return { messages, cursor, hasMore }         ← 首次 1~12s
  │
  └─ 下次访问同一会话 → PostgreSQL HIT → <10ms
```

### 2.5 loadMore（向上滚动）

```
用户滚动到顶部 → chatStore.loadMoreMessages()
  │
  ├─ GET /api/chat/history?sessionKey=X&limit=50&cursor=oldestSeq
  │
  ├─ PG read path: readMessages(X, { limit:50, beforeSeq:oldestSeq })
  │     → WHERE seq < oldestSeq ORDER BY seq DESC LIMIT 50
  │
  ├─ [有数据] → reverse → return（<10ms）
  └─ [无数据] → Gateway fetch → upsert → return
```

### 2.6 Session 生命周期

```
sessions.reset / sessions.delete / REST DELETE
  │
  ├─ await deleteSessionMessages(sessionKey)            ← PG: DELETE（同步等待）
  ├─ _fullyBackfilledSessions.delete(sessionKey)        ← 清除标记
  ├─ removeSessionForUser / recentlyDeletedSessions     ← SQLite 清理
  └─ gateway.call('sessions.reset/delete')             ← Gateway 清理
```

**关键**：PG 删除是 `await`（同步），不是 fire-and-forget。确保用户重置后不会从 PG 读到旧数据。

### 2.7 SSE 连接时预加载

```
用户打开浏览器 → GET /api/events (SSE)
  │
  ├─ sseClients.set(clientId, { userId, ... })
  │
  ├─ schedulePreloadForUser(userId)                     ← 非阻塞
  │     ├─ getUserSessions(userId) → 按 agent 分组
  │     ├─ 每个 agent 取 top 4 会话（按 updated_at DESC）
  │     ├─ 过滤：已有 PG 数据的跳过（countConfirmedMessages > 0）
  │     └─ enqueueBackfill(sk, { limit:50 })            ← 全局队列
  │
  └─ SSE 连接建立完成

后台静默执行：
  Queue(2 并发, 500ms 间隔)
    → fetchHistoryFromGateway(sk, 50)
    → batchUpsertMessages(sk, messages)
    → 用户下次点击这些会话时直接 PG HIT
```

---

## 三、关键实现细节与防御机制 (Details)

### 3.1 数据库表结构

```sql
CREATE TABLE session_messages (
  id            BIGSERIAL PRIMARY KEY,         -- 自增主键
  session_key   TEXT NOT NULL,                  -- 会话标识（如 agent:ops:main:dm:user1）
  seq           INTEGER NOT NULL,               -- 会话内自增序号
  msg_id        TEXT,                           -- Gateway 消息 ID（去重用）
  role          TEXT NOT NULL,                  -- user / assistant / tool / system
  content       TEXT NOT NULL DEFAULT '',        -- 消息文本（快速显示用）
  raw_content   JSONB,                          -- 完整消息对象（前端解析用）
  model         TEXT,                           -- 使用的模型
  status        TEXT NOT NULL DEFAULT 'confirmed', -- pending / confirmed / orphaned
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(session_key, seq)                      -- 同一会话内 seq 唯一
);

CREATE INDEX idx_msg_session_seq ON session_messages (session_key, seq DESC);
CREATE INDEX idx_msg_session_status ON session_messages (session_key, status);
```

**字段设计考量**：

| 字段 | 为什么这样设计 |
|------|--------------|
| `seq` 而非 `timestamp` | 时间戳不保证唯一性（并发写入），seq 在 advisory lock 保护下单调递增 |
| `raw_content` JSONB | 存 Gateway 返回的原始消息对象，前端解析逻辑完全不变。`pg` 驱动自动 JSONB ↔ JS Object |
| `content` 独立字段 | `raw_content` 中的 `content` 可能是数组（多 part），`content` 字段存纯文本用于快速预览 |
| `status` 三态 | `pending`（用户发出，待确认）→ `confirmed`（Gateway 确认）→ `orphaned`（Gateway 拒绝）|
| `msg_id` | 跨 Phase 1/2/backfill 写入去重，`COALESCE(EXCLUDED.msg_id, session_messages.msg_id)` 保留最早的非空值 |

### 3.2 Upsert 语义：旧数据永不覆盖新数据

```sql
INSERT INTO session_messages (...) VALUES (...)
ON CONFLICT (session_key, seq) DO UPDATE SET
  content = CASE
    WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.content
    ELSE session_messages.content
  END,
  raw_content = CASE
    WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.raw_content
    ELSE session_messages.raw_content
  END,
  status = EXCLUDED.status,
  msg_id = COALESCE(EXCLUDED.msg_id, session_messages.msg_id)
```

**场景：Phase 1 写 50 条 → Phase 2 写 1000 条（有重叠）**

Phase 2 的 `created_at` 比 Phase 1 更晚 → Phase 2 数据覆盖 Phase 1。这是期望行为（Phase 2 拿到的是 Gateway 最新的完整数据）。

但如果用户在 Phase 1 和 Phase 2 之间发了新消息（写入 seq=51），Phase 2 的旧数据 `created_at` < 用户消息的 `created_at` → 用户消息不被覆盖。

### 3.3 Advisory Lock + 显式事务：Seq 分配的并发安全

```js
// message-store.js: getNextSeq()
const client = await pool.connect()
try {
  await client.query('BEGIN')                                    // ① 开启事务
  await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])  // ② 事务级锁
  const { rows } = await client.query(
    'SELECT COALESCE(MAX(seq), 0) + 1 FROM session_messages WHERE session_key = $1',
    [sessionKey]
  )                                                              // ③ 在锁内查 max seq
  await client.query('COMMIT')                                   // ④ 提交 → 锁释放
  return rows[0].next_seq
} catch {
  await client.query('ROLLBACK').catch(() => {})                 // ⑤ 回滚 → 锁释放
} finally {
  client.release()                                               // ⑥ 归还连接
}
```

**为什么用 `pg_advisory_xact_lock` 而不是 `pg_advisory_lock`**：

- `xact_lock` 绑定事务，事务结束（COMMIT/ROLLBACK）自动释放，不会因为异常忘记释放
- `pg_advisory_lock` 需要手动 `pg_advisory_unlock`，异常时可能锁泄漏

**为什么用 `BEGIN`/`COMMIT` 而不依赖 auto-commit**：

pg 默认 auto-commit 模式下，每个 `client.query()` 是独立事务。`pg_advisory_xact_lock` 在 auto-commit 的 query 结束后就释放了。必须显式 `BEGIN` 让锁跨越整个 query 序列。

**`batchUpsertMessages` 中的同构模式**：同一 session 的所有 batch 操作在单个 advisory lock + BEGIN/COMMIT 内完成，保证 seq 连续分配。

### 3.4 消息状态机

```
              POST /api/chat/send
                    │
                    ▼
              ┌──────────┐
              │ pending  │  ← 用户消息写入时的初始状态
              └────┬─────┘
                   │
          gateway.call('chat.send')
                   │
         ┌─────────┴─────────┐
         │ 成功               │ 失败
         ▼                   ▼
  ┌────────────┐      ┌────────────┐
  │ confirmed  │      │ orphaned   │
  └────────────┘      └────────────┘
         │                   │
         │                   └─ 读取路径过滤掉，用户不可见
         └─ 读取路径返回，用户可见

  Gateway SSE 事件 (chat.done/final)
         │
         ▼
  ┌────────────┐
  │ confirmed  │  ← Assistant/Tool 消息直接写入 confirmed
  └────────────┘
```

读取路径的 SQL：`WHERE status = 'confirmed'`。`pending` 和 `orphaned` 对用户不可见。

### 3.5 小会话读取策略（已简化）

**旧方案（已废弃）**：曾使用内存 Set `_fullyBackfilledSessions` 标记"消息数 < limit 但已全量回填"的会话。重启后 Set 丢失，导致小会话永远 Cache MISS。

**当前方案**：直接判断 `localCount > 0`。

```js
if (localCount > 0) {
  // 直接从 PG 返回，不管消息数是否达到 limit
}
```

**Rationale**：
- PG 数据是 `confirmed` 状态，可信
- 如果会话真的只有 2 条消息，返回 2 条是正确的，无需去 Gateway 确认
- 缺失的最新消息会通过 SSE 实时捕获并写入 PG
- 唯一需要 Gateway 回退的情况是 PG 完全为空（首次访问或 session reset 后）

**Session reset/delete 时**：同步 `await deleteSessionMessages(sk)` 清空 PG 数据，下次访问自然走 Gateway 回退路径。

### 3.6 全局回填队列

```
backfill-queue.js 内部状态：

  pendingQueue = [job1, job2, ...]     ← FIFO 队列，max 50
  activeJobs = 0                        ← 当前活跃任务数，max 2
  inFlightSessionKeys = Set { sk1, sk2 } ← 去重：同一 session 不重复入队

  入口：enqueueBackfill(sessionKey, { limit, fetchFn, label })
    ├─ isReady() ?        ← PG 是否可用
    ├─ inFlight ?         ← 是否已在队列/执行中
    ├─ queue full ?       ← pendingQueue.length >= 50
    └─ push + add to inFlight + processQueue()

  processQueue():
    while (activeJobs < 2 && queue not empty) {
      shift job
      activeJobs++
      executeJob(job).finally(() => {
        activeJobs--
        removeFromInFlight(job.sessionKey)
        if (queue not empty) setTimeout(processQueue, 500ms)  ← 间隔控制
      })
    }

  executeJob(job):
    messages = await fetchFn(sessionKey, limit)    ← 从 Gateway 拉取
    written = await batchUpsertMessages(...)       ← 写入 PG
```

**三种触发源**：

| 触发源 | label | limit | 说明 |
|--------|-------|-------|------|
| History Phase 1 后 | phase2 | 1000 | 首次访问后全量回填 |
| SSE 连接预加载 | preload | 50 | 活跃用户的 top sessions |
| 未来扩展 | reconcile | TBD | 定期计数对账 |

### 3.7 优雅降级

整个模块从设计上保证 PG 不可用时不影响现有功能：

```js
// message-store.js 中每个函数的入口守卫
export async function getNextSeq(sessionKey) {
  if (!pool) return null       // ← PG 不可用，返回 null
  ...
}

// server/index.js 中的调用
const seq = await getNextSeq(sessionKey)
if (!userMsgSeq) { ... }       // ← seq 为 null，跳过 PG 写入

// 读路径
if (isMessageStoreReady()) {    // ← PG 不可用，整个 PG 读取块被跳过
  ...                           //     直接走 Gateway fallback
}
```

**降级行为矩阵**：

| 场景 | PG 可用 | PG 不可用 |
|------|---------|----------|
| DATABASE_URL 未设置 | — | 所有函数返回 null/false/[]/0，服务正常 |
| PG 启动失败 | — | 日志 `[MessageStore] Init failed`，服务正常 |
| PG 运行中宕机 | 写入返回 false，读取返回 [] | 回退 Gateway，日志记录错误 |
| PG 恢复 | 需重启服务（pool 不会自动重连） | — |

### 3.8 连接池配置

```js
new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,                    // 最大连接数（150 用户场景足够）
  min: 2,                     // 最小空闲连接
  idleTimeoutMillis: 30000,   // 空闲 30s 回收
  connectionTimeoutMillis: 5000, // 连接超时 5s
})

pool.on('error', (err) => {
  console.error('[MessageStore] Unexpected pool error:', err.message)
})
```

Pool 级别 error 监听防止未捕获异常导致进程崩溃。`_initPromise` 单例保证不会重复初始化。

### 3.9 部署拓扑

```
Docker Host (192.168.10.12)
├── wattclaw-postgres          ← PostgreSQL 15 Alpine
│   network: wattclaw-net
│   port: 5432 (internal)
│   volume: /home/wattman/work/wattclaw-postgres/data
│
├── wattclaw-test              ← WattClaw 测试环境
│   network: wattclaw-net
│   port: 3002 → 3001
│   env: DATABASE_URL=postgresql://wattclaw:wattclaw@wattclaw-postgres:5432/wattclaw
│
└── openclaw                   ← OpenClaw Gateway
    network: wattclaw-net
    port: 18789
```

**容器间通信**：`wattclaw-postgres` 作为 host（不是 `localhost`），因为两个容器在同一 Docker 网络 `wattclaw-net` 中。

**踩坑记录**：
- `docker compose restart` 不会重新读取 `.env`，必须 `up -d --force-recreate`
- `DATABASE_URL` 中的 host 必须是容器名（`wattclaw-postgres`），不是 `localhost`

---

## 附录 A：文件清单

| 文件 | 行数 | 职责 |
|------|------|------|
| `server/message-store.js` | 247 | PG Pool 初始化、表创建、seq 分配（advisory lock）、upsert/read/delete/batchUpsert |
| `server/backfill-queue.js` | 95 | 全局回填队列（2 并发、500ms 间隔）、预加载调度 |
| `server/index.js` (改动) | +179 | imports、startup init、send 写入捕获、SSE 事件捕获、history PG 优先读、生命周期清理、预加载触发 |

## 附录 B：提交历史

```
c6be160 chore: add pg dependency and PostgreSQL configuration for message store
8764f33 feat(message-store): PostgreSQL pool init, table creation, and full CRUD operations
7844042 feat(backfill-queue): global queue processor with preload and phase2 backfill
1c48a3c feat(server): import and initialize message-store on startup
3801100 feat(chat-send): capture user messages to PostgreSQL with pending→confirmed/orphaned lifecycle
7d6b727 feat(events): capture assistant/tool messages from Gateway SSE events to PostgreSQL
de33fa7 feat(history): PostgreSQL-first read path with lazy Gateway backfill
16ed107 feat(lifecycle): cascade message store cleanup on session reset/delete
0614d7e feat(preload): trigger session preload for active users on SSE connect
8dcc103 fix(message-store): three critical fixes from code review
541739f fix(history): serve small sessions from PostgreSQL after first backfill
```

## 附录 C：延后问题

| 编号 | 问题 | 风险 | 触发条件 |
|------|------|------|---------|
| BUG-1 | `getNextSeq` + `upsertMessage` 两步操作理论竞态 | 极低 | 同一 session 毫秒级并发发消息 |
| OPT-3 | Phase 1 backfill `seq: i+1` 可能与已有消息 seq 冲突 | 极低 | 首次访问前已通过 send 写入了消息 |
| OPT-4 | `schedulePreloadForUser` 串行 count 查询 | 低 | 20 sessions = 20 次 SQL（~100ms） |

根治方案详见 [feedback-postgresql-lessons.md](./memory/feedback-postgresql-lessons.md)。

---

*文档版本：v1.0 | 编写日期：2026-05-28*
*前置分析：[history-fetch-chain-analysis.md](./chat-flow/history-fetch-chain-analysis.md)*
*设计文档：[2026-05-28-history-local-store-design.md](./superpowers/specs/2026-05-28-history-local-store-design.md)*
*实施计划：[2026-05-28-history-local-store.md](./superpowers/plans/2026-05-28-history-local-store.md)*
