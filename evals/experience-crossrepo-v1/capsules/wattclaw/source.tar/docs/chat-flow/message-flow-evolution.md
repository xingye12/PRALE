# Chat 消息链路架构演进文档

> **版本**: v2.0 — 从伪 RPC 双轨制到契约驱动的 REST 单向数据流
> **日期**: 2026-05-27
> **影响范围**: Chat 发送/中止/历史加载全链路
> **冻结项**: ChatPage.vue 渲染层、mergeRealtimeMessages 算法、乐观更新体验

---

## 1. 🏛️ 史前架构 (Legacy Architecture)

### 1.1 请求链路全景

```
                           ┌─────────────────────────────────────────────┐
                           │            8 层间接调用                      │
                           └─────────────────────────────────────────────┘

[ChatStore]        [RPCClient]         [OpenClawWebSocket]    [ApiClient]        [Express]         [Gateway]
    │                   │                      │                   │                  │                  │
    │ sendMessage()     │                      │                   │                  │                  │
    ├──────────────────>│                      │                   │                  │                  │
    │                   │ sendChatMessage()    │                   │                  │                  │
    │                   ├──────────────────>X6 │                   │                  │                  │
    │                   │ callWithMethodAnd    │                   │                  │                  │
    │                   │ ParamsFallback()     │                   │                  │                  │
    │                   │ ['chat.send']        │                   │                  │                  │
    │                   │ ├─ params[0]:        │                   │                  │                  │
    │                   │ │  {sessionKey,      │                   │                  │                  │
    │                   │ │   message, ...}    │                   │                  │                  │
    │                   │ ├─ params[1]:        │                   │                  │                  │
    │                   │ │  {sessionKey,      │                   │                  │                  │
    │                   │ │   input, ...}      │                   │                  │                  │
    │                   │ ├─ params[2]:        │                   │                  │                  │
    │                   │ │  {key, message}    │                   │                  │                  │
    │                   │ ├─ params[3]:        │                   │                  │                  │
    │                   │ │  {session, msg}    │                   │                  │                  │
    │                   │ ├─ params[4]:        │                   │                  │                  │
    │                   │ │  {sessionKey,      │                   │                  │                  │
    │                   │ │   text, ...}       │                   │                  │                  │
    │                   │ └─ params[5]:        │                   │                  │                  │
    │                   │    {sessionKey,      │                   │                  │                  │
    │                   │     content, ...}    │                   │                  │                  │
    │                   │       │              │                   │                  │                  │
    │                   │       │ + model 时    │                   │                  │                  │
    │                   │       │ 额外 4 组     │                   │                  │                  │
    │                   │       │ (modelRef/    │                   │                  │                  │
    │                   │       │  modelOverride)│                   │                  │                  │
    │                   │       ▼              │                   │                  │                  │
    │                   │ call('chat.send')    │                   │                  │                  │
    │                   ├─────────────────────>│                   │                  │                  │
    │                   │                      │ ws.send(frame)    │                  │                  │
    │                   │                      ├──────────────────>│                  │                  │
    │                   │                      │                   │ fetch POST       │                  │
    │                   │                      │                   │ /api/rpc         │                  │
    │                   │                      │                   ├─────────────────>│                  │
    │                   │                      │                   │                  │ gateway.call()   │
    │                   │                      │                   │                  ├─────────────────>│
    │                   │                      │                   │                  │  WebSocket frame │
    │                   │                      │                   │                  │  to Gateway      │
    │                   │                      │                   │                  │                  │
    │                   │<───── HTTP 200 ◄─────┤◄──────────────────┤◄─────────────────┤◄─────────────────┤
    │<──────────────────┤                      │                   │                  │                  │
```

### 1.2 返回路径（SSE 事件流）

```
[Gateway]     [Express]           [ApiClient]          [OpenClawWebSocket]  [ChatStore]
    │              │                    │                       │                  │
    │ WS event     │                    │                       │                  │
    ├─────────────>│                    │                       │                  │
    │              │ broadcastSSE()     │                       │                  │
    │              │ ownership filter   │                       │                  │
    │              ├───────────────────>│                       │                  │
    │              │                    │ EventSource.onmessage │                  │
    │              │                    ├──────────────────────>│                  │
    │              │                    │                       │ emit('event')    │
    │              │                    │                       ├─────────────────>│
    │              │                    │                       │  handleAgent     │
    │              │                    │                       │  StatusEvent()   │
    │              │                    │                       │  handleRealtime  │
    │              │                    │                       │  Event()         │
```

### 1.3 暴力参数猜测逻辑

旧版 `RPCClient.sendChatMessage()` 的参数构造策略：

```
第 1 轮尝试 chat.send:
  ├─ {sessionKey, message, idempotencyKey}    ← 正确答案，但不知道
  ├─ {sessionKey, input, idempotencyKey}      ← 猜测
  ├─ {key, message, idempotencyKey}           ← 猜测
  ├─ {session, message, idempotencyKey}       ← 猜测
  ├─ {sessionKey, text, idempotencyKey}       ← 猜测
  └─ {sessionKey, content, idempotencyKey}    ← 猜测

  如果有 model 参数，上面每组再 ×4（modelRef / modelOverride / model / input+modelOverride）
  → 最多 10 组候选参数

第 1 轮全部失败 → 第 2 轮降级到 agent 方法:
  ├─ {sessionKey, input, modelOverride}
  ├─ {sessionKey, message, modelOverride}
  ├─ {key, input, modelOverride}
  ├─ {key, message, modelOverride}
  ├─ {input, modelOverride}
  └─ {message, modelOverride}

  → 最多 16 组候选参数，全部逐一尝试
```

**代价**：每组候选触发一次 HTTP POST → Express → gateway.call() → Gateway WebSocket 往返。
最坏情况 = **16 次网络往返** 才能发一条消息。

---

## 2. 💣 核心痛点与技术债诊断 (Pain Points & Tech Debt)

### 2.1 协议层面的双轨制撕裂

旧架构的 **控制面**（发送命令）和 **数据面**（接收事件）走完全不同的语义通道：

| 维度 | 控制面 (发送) | 数据面 (接收) |
|------|-------------|-------------|
| 传输 | HTTP POST `/api/rpc` | SSE `/api/events` |
| 语义 | 请求-响应 (Request-Response) | 单向推送 (Server Push) |
| 关联 | idempotencyKey | runId |
| 延迟 | 同步等待 HTTP 响应 | 异步事件流 |

**致命问题**：`sendMessage()` 在 HTTP 响应到达后将 agent phase 设为 `waiting`，但 SSE 事件可能在 HTTP 响应 **之前** 就到达。这造成了隐式竞态：

```
Timeline A (正常):
  HTTP POST ────────> HTTP 200 OK ──> phase = 'waiting'
  SSE event (lifecycle:start) ──────────────> phase = 'thinking'

Timeline B (竞态):
  HTTP POST ────────> [Gateway 处理中...]
  SSE event (lifecycle:start) ──────────────> phase = 'thinking'
  HTTP 200 OK ──────────────────────────────> phase = 'waiting'  ← 覆盖！状态倒退！
```

ChatStore 中通过 `runId` 比对做了部分防御，但这只是 **补丁**，不是 **设计**。

### 2.2 状态管理的易失性

**ChatStore** 同时承载了两个正交的职责：

1. **消息 CRUD**：fetchHistory / mergeRealtimeMessages / 乐观插入
2. **Agent 状态机**：idle → sending → waiting → thinking → tool → replying → done

状态机的驱动源 **分散** 在两个地方：
- `sendMessage()` 内部手动设置 `sending` → `waiting`（**命令式**）
- `handleAgentStatusEvent()` 根据事件名解析 phase（**响应式**）

两套驱动逻辑之间存在 **隐式耦合**：`sendMessage` 必须知道状态机的合法转移路径，否则会破坏 `handleAgentStatusEvent` 的 `runId` 防重入逻辑。

### 2.3 类型契约的缺失与防御性冗余

`RPCClient` 中 `sendChatMessage` 的类型签名：

```typescript
sendChatMessage(params: ChatSendParams): Promise<unknown>
//                                                     ^^^^^^^
//                                              返回值是 unknown！
```

**下游连锁反应**：

- `ChatStore.sendMessage()` 得到 `Promise<unknown>` → 无法对响应做任何类型安全操作
- `normalizeChatMessageItem()` 对 Gateway 返回的每条消息做 15+ 个字段的 `asString()` / `asRecord()` 防御
- `handleAgentStatusEvent()` 中 400+ 行的 `if/else if` 链 — 本质是对 `unknown` payload 的手动类型收窄
- `asRecord()` / `asString()` / `asText()` 等辅助函数反复定义在 `chat.ts` 和 `rpc-client.ts` 中

**根因**：没有从 Gateway 源码提取类型契约，所有代码都在 **运行时** 猜测数据形状。

---

## 3. 🧠 架构演进决策 (Architectural Decision & Rationale)

### 3.1 源码驱动契约发现 (Source-Driven Contract Discovery)

重构的第一步不是写代码，而是 **深入 OpenClaw 源码** 进行契约考古。

**关键发现**：

| Gateway RPC 方法 | 期望的参数名 | 稳定性 |
|-----------------|------------|--------|
| `chat.send` | `sessionKey`, `message`, `idempotencyKey` | **完全稳定** |
| `chat.abort` | `sessionKey`, `runId?` | **完全稳定** |
| `chat.history` | `sessionKey`, `limit?` | **完全稳定** |

**结论**：Gateway 的 `chat.*` 接口字段名从第一天起就是固定的。`RPCClient` 中的 6~16 组候选参数 **全部是冗余的**，是对未知的恐惧导致的过度防御。

### 3.2 为什么选择 REST 端点而非全双工 WebSocket

评估了三种方案：

| 方案 | 优点 | 缺点 |
|------|------|------|
| A. 前端直连 Gateway WebSocket | 最短链路 | 破坏多租户隔离、绕过后端权限层、前端需实现 Ed25519 设备认证 |
| **B. 专用 REST 端点** (选用) | **类型安全、权限隔离、语义清晰** | **HTTP 非全双工**（但 chat.send 本身就是请求-响应语义） |
| C. 保留通用 RPC 代理 | 最小改动 | 不解决根本问题（类型缺失、参数猜测） |

**决策依据**：

1. **chat.send 的语义天然是请求-响应**：发送消息 → 立即得到 `{runId, status}`。这是 HTTP POST 的本职工作，不需要 WebSocket 全双工能力。
2. **SSE 已经承担了数据面**：流式回复（delta/final/error）通过 SSE `/api/events` 推送，这条链路运转良好且与控制面解耦。
3. **后端必须留在中间层**：多租户的 ownership 过滤（`isSessionOwned` / `broadcastSSE` 权限过滤）不可绕过。
4. **REST 端点提供天然的类型边界**：请求体和响应体可以被 TypeScript 接口精确描述，`fetch` 的泛型可以直接标注。

### 3.3 单一数据源与单向数据流

重构后的 **数据流法则**：

```
                    ┌─────────────────────────────────────┐
                    │         Single Source of Truth       │
                    │                                     │
                    │   Gateway WebSocket Events          │
                    │   → backend SSE broadcast           │
                    │   → frontend EventSource            │
                    │   → ChatStore state machine         │
                    └──────────────┬──────────────────────┘
                                   │
                    ┌──────────────▼──────────────────────┐
                    │     Command (副作用, 不产生状态)      │
                    │                                     │
                    │   ChatClient.send() → HTTP POST      │
                    │   ChatClient.abort() → HTTP POST     │
                    │   ChatClient.history() → HTTP GET    │
                    │                                     │
                    │   返回值仅用于：                       │
                    │   1. 乐观更新的回滚标记                 │
                    │   2. 错误处理                         │
                    │   3. 不驱动任何 agent phase 变更       │
                    └─────────────────────────────────────┘
```

**核心原则**：**Command 不生产状态，只触发副作用。所有 agent phase 变更由 SSE 事件驱动。**

---

## 4. 🚀 现代架构蓝图 (Modern Architecture Blueprint)

### 4.1 重构后请求链路

```
┌──────────────────────────────────────────────────────────────────────┐
│                        3 层直接调用                                    │
└──────────────────────────────────────────────────────────────────────┘

[ChatStore]              [ChatClient]               [Express]            [Gateway]
    │                         │                          │                    │
    │ sendMessage()           │                          │                    │
    ├────────────────────────>│                          │                    │
    │                         │ POST /api/chat/send      │                    │
    │                         │ {sessionKey, message,    │                    │
    │                         │  idempotencyKey, model?} │                    │
    │                         ├─────────────────────────>│                    │
    │                         │                          │ validate           │
    │                         │                          │ ownership track    │
    │                         │                          │                    │
    │                         │                          │ gateway.call(      │
    │                         │                          │   'chat.send',     │
    │                         │                          │   exactParams)     │
    │                         │                          ├───────────────────>│
    │                         │                          │                    │
    │<──── {runId, status} ◄──┤<─── {ok, payload} ◄─────┤<───────────────────┤
    │                         │                          │                    │
    │ phase = 'waiting'       │                          │                    │
    │ (仅当 phase 仍为 sending)│                          │                    │
```

### 4.2 类型契约全链路覆盖

```
┌──────────────────────────────────────────────────────────────┐
│              TypeScript Type Safety Chain                      │
│                                                                │
│  chat-contract.ts                                              │
│  ┌──────────────────────┐    ┌──────────────────────────┐     │
│  │ ChatSendRequest      │    │ ChatSendResponse         │     │
│  │ ├ sessionKey: string │    │ ├ runId: string          │     │
│  │ ├ message: string    │    │ └ status: 'started' |   │     │
│  │ ├ idempotencyKey:    │    │           'in_flight'    │     │
│  │ │  string            │    └──────────────────────────┘     │
│  │ ├ model?: string     │                                      │
│  │ ├ thinking?: string  │    ┌──────────────────────────┐     │
│  │ └ ...                │    │ ChatAbortResponse        │     │
│  └──────────────────────┘    │ ├ ok: boolean            │     │
│                               │ ├ aborted: boolean       │     │
│  ┌──────────────────────┐    │ └ runIds: string[]       │     │
│  │ ChatAbortRequest     │    └──────────────────────────┘     │
│  │ ├ sessionKey: string │                                      │
│  │ └ runId?: string     │    ┌──────────────────────────┐     │
│  └──────────────────────┘    │ ChatHistoryResponse      │     │
│                               │ ├ messages: ChatMessage[]│     │
│  ┌──────────────────────┐    │ ├ cursor?: string | null │     │
│  │ ChatEventPayload     │    │ └ hasMore?: boolean      │     │
│  │ ├ state: 'delta' |   │    └──────────────────────────┘     │
│  │ │  'final' | ...     │                                      │
│  │ ├ runId: string      │    ┌──────────────────────────┐     │
│  │ └ sessionKey: string │    │ AgentEventPayload        │     │
│  └──────────────────────┘    │ ├ stream: 'lifecycle' |  │     │
│                               │ │  'assistant' | 'tool' |  │     │
│                               │ ├ data: Record<...>      │     │
│                               │ └ runId: string          │     │
│                               └──────────────────────────┘     │
│                                                                │
│  ChatClient.send(): Promise<ChatSendResponse>                 │
│  ChatClient.abort(): Promise<ChatAbortResponse>               │
│  ChatClient.history(): Promise<ChatHistoryResponse>           │
│                                                                │
│  → 零 unknown，零 any，零运行时类型猜测                          │
└──────────────────────────────────────────────────────────────┘
```

### 4.3 ChatStore 状态收敛点

重构后 ChatStore 的 **agent phase 状态机** 有两个且仅有两个驱动源：

```
┌────────────────────────────────────────────────────────────┐
│                   Agent Phase State Machine                 │
│                                                              │
│  驱动源 1: Command 层（仅启动）                                │
│  ─────────────────────────                                   │
│  sendMessage() → phase = 'sending'                           │
│  HTTP 成功     → phase = 'waiting'（防御性：仅当仍为 sending） │
│  HTTP 失败     → phase = 'error' + 回滚乐观消息               │
│                                                              │
│  驱动源 2: SSE Event 层（完整生命周期）                        │
│  ─────────────────────────────────                           │
│  agent stream=lifecycle phase=start  → 'thinking'            │
│  agent stream=assistant              → 'replying'            │
│  agent stream=tool phase=start       → 'tool'                │
│  agent stream=tool phase=result      → 'thinking'            │
│  agent stream=lifecycle phase=end    → 'done'                │
│  chat state=delta                    → 'replying'            │
│  chat state=final                    → 'done'                │
│  chat state=error                    → 'error'               │
│  chat state=aborted                  → 'aborted'             │
│                                                              │
│  ┌─────┐  send  ┌─────────┐  HTTP OK  ┌─────────┐           │
│  │idle │───────>│ sending │──────────>│ waiting │             │
│  └──┬──┘        └────┬────┘           └────┬────┘           │
│     ^                │ error               │ SSE events      │
│     │                v                     v                 │
│  ┌──┴──┐     ┌───────┴──┐         ┌──────────┐              │
│  │done │<────│  error   │         │ thinking │<──┐           │
│  └─────┘     └──────────┘         └────┬─────┘   │           │
│     ^                                  │          │           │
│     │          ┌──────────┐    ┌───────┴───┐     │           │
│     └──────────│ replying │<───│   tool    │─────┘           │
│                └──────────┘    └───────────┘                  │
└──────────────────────────────────────────────────────────────┘
```

### 4.4 文件职责矩阵

| 文件 | 职责 | 变更性质 |
|------|------|---------|
| `src/api/types/chat-contract.ts` | **契约层** — Gateway 接口的 1:1 TypeScript 映射 | **新增** |
| `src/api/chat-client.ts` | **传输层** — 类型安全的 HTTP 客户端 | **新增** |
| `server/index.js` | **端点层** — REST 路由 + 权限 + Gateway 代理 | **新增端点** |
| `src/stores/chat.ts` | **状态层** — 消息 CRUD + agent 状态机 | **内部重构** |
| `src/api/rpc-client.ts` | **遗留层** — 非 chat 操作仍使用通用 RPC | **裁剪** |
| `src/views/chat/ChatPage.vue` | **UI 层** — 渲染 + 事件分发 | **冻结** |

### 4.5 重构量化指标

| 指标 | 重构前 | 重构后 | 改善 |
|------|-------|--------|------|
| 消息发送调用层级 | 8 层 | 3 层 | **-62.5%** |
| 候选参数组数 | 6~16 组 | **1 组** (精确) | **-93.7%** |
| 返回值类型安全 | `Promise<unknown>` | `Promise<ChatSendResponse>` | **100% 覆盖** |
| 新增类型定义 | 0 | 10+ 接口/类型 | **契约完备** |
| 删除代码行数 | — | ~150 行 (参数猜测) | **净减** |
| SSE 事件链路变更 | — | 0 行 | **零风险** |

---

## 附录：迁移兼容性

| 遗留接口 | 状态 | 说明 |
|---------|------|------|
| `POST /api/rpc` (chat.send 分支) | **保留** | 旧端点不删除，注释 `DEPRECATED`，供未迁移的调用方使用 |
| `POST /api/chat/cancel` | **保留** | Workspace stream proxy 使用，非本次重构范围 |
| `GET /api/chat/history` | **保留** | 已是 REST 端点，ChatClient.history() 调用同一端点 |
| `RPCClient.sendChatMessage()` | **已删除** | 无外部调用方，安全移除 |
| `RPCClient.abortChat()` | **已删除** | 无外部调用方，安全移除 |
| `RPCClient.listChatHistory()` | **已删除** | ChatStore 已使用 ChatClient.history() 替代 |
| `ChatSendParams` (types/index.ts) | **保留** | 定义仍在，无消费方，后续可清理 |
