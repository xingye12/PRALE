# 在线对话消息完整链路

本文档描述从用户在聊天界面发送消息到 Agent 回复的完整调用链路。

## 架构概览

```
用户输入 → ChatPage → ChatStore → RPCClient → HTTP POST /api/rpc
                                                    ↓
                                              后端 Express
                                                    ↓
                                          gateway.call() (WebSocket)
                                                    ↓
                                          OpenClaw Gateway
                                                    ↓
                                          LLM 流式生成回复
                                                    ↓
                                          Gateway WebSocket 事件推送
                                                    ↓
                                          后端 broadcastSSE()
                                                    ↓
                                          前端 EventSource 接收
                                                    ↓
                                          ChatStore 状态机 + 消息合并
                                                    ↓
                                          UI 响应式更新
```

## 关键数据结构

### SessionKey 格式

```
agent:<agentId>:<uniqueSuffix>
```

所有 session 归属、权限过滤、事件路由都依赖从 sessionKey 中提取 agentId。

### Agent Phase 状态机

```
idle → sending → waiting → thinking → tool → replying → done
                 ↓            ↓          ↓
               error        error      error
                                        ↓
                                     aborted
```

---

## 第一层：前端 UI → Chat Store

### 1.1 用户按 Enter

`src/views/chat/ChatPage.vue` → `handleSend()`

```
handleSend()
  ├ 校验 draft 非空
  ├ 校验 agent 非 busy (agentBusy)
  ├ chatStore.setSessionKey(key)
  ├ chatStore.sendMessage(content)      ← 进入 chat store
  ├ fetchSessionTokenUsage(key)
  ├ 清空输入框 draft.value = ''
  └ requestScrollToBottom({ force: true })
```

源码位置：`src/views/chat/ChatPage.vue:~2024`

---

## 第二层：Chat Store → RPC Client

### 2.1 ChatStore.sendMessage()

`src/stores/chat.ts:941-990`

```
sendMessage(content, model?)
  ├ 从 sessionKey 提取 agentId（正则 /^agent:([^:]+):/）
  ├ 生成幂等 key: `web-${Date.now()}-${random}`
  ├ resetAgentProgress(agentId)          // 重置进度条
  ├ setAgentStatusPhase(agentId, 'sending')
  ├ 乐观更新：将本地用户消息 append 到 messages[]
  │   localMessage = { id, role:'user', content, timestamp }
  │   messages.value = [...messages.value, localMessage]
  │
  ├ 调用 wsStore.rpc.sendChatMessage({
  │     sessionKey,
  │     message: text,
  │     model: model?.trim() || undefined,
  │     idempotencyKey,
  │   })
  │
  ├ 成功 → setAgentStatusPhase(agentId, 'waiting')
  └ 失败 → 移除乐观消息 + setAgentStatusPhase(agentId, 'error')
```

**核心设计**：
- 乐观更新（Optimistic Update）：用户消息立即显示，不等后端确认
- 幂等 key：防止网络重试导致重复发送

---

## 第三层：RPC Client → HTTP API

### 3.1 RPCClient.sendChatMessage()

`src/api/rpc-client.ts:2844-2957`

Gateway 字段名不稳定，所以构造多组候选参数逐一尝试：

```
sendChatMessage(params)
  │
  ├ 构造候选参数列表（6 组基础 + 4 组带 model）：
  │   {sessionKey, message, idempotencyKey}
  │   {sessionKey, input, idempotencyKey}
  │   {key, message, idempotencyKey}
  │   {session, message, idempotencyKey}
  │   {sessionKey, text, idempotencyKey}
  │   {sessionKey, content, idempotencyKey}
  │   + 带 model 时额外插入: modelRef / modelOverride / model 版本
  │
  ├ 第一次尝试（120s 超时）：
  │   callWithMethodAndParamsFallback(['chat.send'], 候选参数[])
  │     └ 对每组参数 → callWithFallback(['chat.send'], params)
  │         └ this.call('chat.send', params, 120s)
  │
  └ 如果 chat.send 全部失败且错误可降级：
      第二次尝试（120s 超时）：
      callWithMethodAndParamsFallback(['agent'], 降级参数[])
        └ 旧版 Gateway 用 'agent' 方法代替 'chat.send'
```

### 3.2 callWithMethodAndParamsFallback()

`src/api/rpc-client.ts:2047-2065`

```
callWithMethodAndParamsFallback(methods, paramsList, timeout)
  └ for each params in paramsList:
      try callWithFallback(methods, params, timeout)
      catch → if shouldFallbackOnError → try next params
```

### 3.3 callWithFallback()

`src/api/rpc-client.ts:2028-2045`

```
callWithFallback(methods, params, timeout)
  └ for each method in methods:
      try this.call(method, params, timeout)
      catch → if shouldFallbackOnError → try next method
```

### 3.4 call() — 底层 RPC 调用

`src/api/rpc-client.ts:2105-2138`

```
call(method, params, timeout)
  ├ 生成 RPC ID
  ├ 注册一次性监听器: ws.on(`rpc:${id}`, handler)
  ├ 设置超时定时器
  └ ws.send({ type: 'req', id, method, params })
```

---

## 第四层：WebSocket 适配层

### 4.1 OpenClawWebSocket.send()

`src/api/websocket.ts:99-124`

前端不直接用 WebSocket 帧，而是通过 HTTP POST 模拟 RPC：

```
send({type:'req', id, method, params})
  ├ data.type !== 'req' → 忽略
  └ 否则:
      this.apiClient.rpc(method, params)
        → HTTP POST /api/rpc
        → 收到 HTTP 响应后 emit('rpc:${id}', response)
```

### 4.2 ApiClient.rpc()

`src/api/http-client.ts:210-238`

```
rpc(method, params)
  ├ const url = baseUrl + '/api/rpc'
  ├ headers = { Authorization: Bearer token }
  ├ fetch(url, { method:'POST', body: JSON.stringify({method, params}) })
  ├ 解析响应 { ok, payload, error }
  ├ !result.ok → throw Error
  └ return result.payload
```

---

## 第五层：后端 Express → Gateway WebSocket

### 5.1 POST /api/rpc

`server/index.js:3263`

```
POST /api/rpc (authMiddleware)
  ├ 校验 method 非空
  ├ 校验 gateway.isConnected
  ├ 规范化 method 名（agent.→agents., session.→sessions.）
  ├ 懒加载权限集合: getOwnedKeysSet(), getOwnedAgentsSet()
  │
  ├ if normMethod === 'chat.send':
  │   ├ trackSessionForUser(userId, sessionKey, agentId)  // 自动归属
  │   ├ trackAgentForUser(userId, agentId, agentId)
  │   └ gateway.call('chat.send', params)
  │       → 返回 { ok: true, payload: result }
  │
  ├ if normMethod === 'session.send' || 'sessions.send':
  │   ├ 同上 trackSession + trackAgent
  │   └ gateway.call(method, params)
  │
  └ if normMethod === 'agent':
      ├ trackSession + trackAgent
      └ gateway.call(method, params)
```

### 5.2 Gateway.call()

`server/gateway.js:428-446`

```
call(method, params, timeout=160s)
  ├ 校验 WebSocket readyState === OPEN
  ├ 生成 ID: `rpc-${uuid()}`
  ├ 构造帧: { type: 'req', id, method, params }
  ├ pendingCalls.set(id, { resolve, reject, timer })
  ├ ws.send(JSON.stringify(frame))       ← 发送到 OpenClaw Gateway
  └ Promise 等待 Gateway 回复
```

---

## 第六层：OpenClaw Gateway 处理

Gateway 是外部系统（不在本项目代码中），核心行为：

```
Gateway 收到 chat.send:
  ├ 创建或定位 session
  ├ 将用户消息加入会话上下文
  ├ 调用 LLM（model provider）
  ├ 流式生成回复
  └ 通过 WebSocket 事件推送实时状态
```

### Gateway 推送的事件类型

| 事件名 | payload.stream | payload.data.phase | 含义 |
|--------|---------------|-------------------|------|
| `agent` | `lifecycle` | `start` | Agent 开始思考 |
| `agent` | `lifecycle` | `end` | Agent 本轮完成 |
| `agent` | `lifecycle` | `error` | Agent 出错 |
| `agent` | `assistant` | - | 流式文本输出（delta） |
| `agent` | `tool` | `start` | 开始调用工具 |
| `agent` | `tool` | `update` | 工具执行中间结果 |
| `agent` | `tool` | `result` | 工具执行完成 |
| `agent` | `compaction` | `start` | 上下文压缩开始 |
| `agent` | `compaction` | `end` | 上下文压缩完成 |
| `chat.delta` | - | - | 流式文本 |
| `chat.final` / `chat.done` | - | - | 回复完成 |
| `chat.aborted` | - | - | 回复被中止 |
| `chat.error` | - | - | 回复出错 |

---

## 第七层：Gateway 事件 → 后端 SSE

### 7.1 gateway.js 事件接收

`server/gateway.js` + `server/index.js:~910-941`

```
gateway.on('event', (event, payload) => {
  ├ 从 payload 提取 sessionKey
  ├ 自动追踪归属:
  │   提取 agentId → getUserIdsByAgentId(agentId)
  │   └ trackSessionForUser(uid, sk, agentId)
  │
  ├ lifecycle end / chat.done:
  │   ├ tryAutoTitleForChannelSession(sk)   // 自动生成会话标题
  │   └ pushTokenUpdate(sk)                 // 推送 token 用量
  │
  └ broadcastSSE({ type:'event', event, payload }, payload)
})
```

### 7.2 pushTokenUpdate()

`server/index.js:951-982`

```
pushTokenUpdate(sessionKey)
  ├ 防重入: _tokenUpdateInFlight Set
  ├ gateway.call('sessions.usage', { key: sessionKey })
  ├ 从结果中提取 inputTokens / outputTokens
  └ broadcastSSE({ type:'event', event:'token_update', payload: {sessionKey, tokenUsage} })
```

### 7.3 broadcastSSE()

`server/index.js:1053-1085`

```
broadcastSSE(data, rawPayload)
  ├ 如果 payload 有 sessionKey → 查 streamIdMap 附加 streamId
  ├ 构造 SSE message: `data: ${JSON.stringify(enriched)}\n\n`
  │
  └ 遍历 sseClients:
      ├ 如果 data.type === 'event' 且有 rawPayload:
      │   ├ 提取 sessionKey
      │   ├ getUserOwnedSessionKeys(client.userId)   ← 权限过滤
      │   └ 只有 sessionKey 属于该用户的消息才 write()
      │
      └ 否则直接 write(message)                       ← 系统级事件
```

### 7.4 SSE 端点

`server/index.js:4232`

```
GET /api/events (authMiddleware)
  ├ 设置 SSE 响应头
  ├ 注册到 sseClients: { res, userId, isAdmin, subscriptions }
  ├ req.on('close') → 清理
  └ 心跳保活（定时发送注释行）
```

---

## 第八层：前端 SSE 接收

### 8.1 ApiClient EventSource

`src/api/http-client.ts:60-148`

```
EventSource(baseUrl + '/api/events?token=xxx')
  │
  ├ onopen → 重置 reconnectAttempts
  │
  ├ onmessage → handleMessage(data):
  │   JSON.parse(data)
  │   │
  │   ├ case 'gatewayState':
  │   │   ├ 'connected' → emit('connected', {version, updateAvailable})
  │   │   └ 'disconnected' → emit('stateChange', RECONNECTING)
  │   │
  │   ├ case 'event':
  │   │   emit('event', { type:'event', event, payload })
  │   │   emit(`event:${eventName}`, payload)
  │   │
  │   └ case 'backupProgress':
  │       emit('backupProgress', message)
  │
  └ onerror → handleDisconnect()
      ├ 关闭当前 EventSource
      ├ emit('disconnected')
      └ scheduleReconnect() (指数退避, 最大 30s, 最多 20 次)
```

### 8.2 OpenClawWebSocket 转发

`src/api/websocket.ts:46-76`

```
this.apiClient.on('event', (evt) => {
  ├ this.emit('event', evt)                    ← 全局事件
  └ this.emit(`event:${evt.event}`, evt.payload) ← 按事件名
})
```

---

## 第九层：前端事件分发 → UI 更新

### 9.1 ChatPage 事件订阅

`src/views/chat/ChatPage.vue:1953-1978`

```
wsStore.subscribe('event', (evt) => {
  ├ 过滤事件名: chat.* / agent / agent.* / tool.* / model.*
  ├ 判断是否 streaming 事件:
  │   eventName 含 stream/delta/chunk/partial
  │   或 payload 看起来像流式数据
  │
  ├ chatStore.handleAgentStatusEvent(eventName, payload)  → 更新 agent 状态机
  └ chatStore.handleRealtimeEvent(payload, {
      refreshHistory: false,    // 不主动回拉历史
      streaming: isStreamingEvent,
    })
})
```

### 9.2 handleAgentStatusEvent()

`src/stores/chat.ts:661-939`

根据事件类型更新 agent 的 phase 状态机：

| 事件 | 条件 | phase 变化 |
|------|------|-----------|
| `agent` stream=`lifecycle` phase=`start` | 当前非活跃 | → `thinking` |
| `agent` stream=`lifecycle` phase=`end` | - | → `done` / `aborted` |
| `agent` stream=`lifecycle` phase=`error` | - | → `error` |
| `agent` stream=`assistant` | 当前非 replying | → `replying` |
| `agent` stream=`tool` phase=`start` | - | → `tool` |
| `agent` stream=`tool` phase=`update` | 节流 120ms | 更新 toolProgress |
| `agent` stream=`tool` phase=`result` | 当前是 tool | → `thinking` |
| `agent` stream=`compaction` phase=`start` | - | → `thinking`（上下文压缩中） |
| `chat.delta` | - | → `replying` |
| `chat.final` / `chat.done` | - | → `done` |
| `chat.aborted` | - | → `aborted` |
| `chat.error` | - | → `error` |

防重入机制：`finalizedRuns` Map 记录已完成的 runId，避免过期事件干扰新一轮对话。

### 9.3 handleRealtimeEvent()

`src/stores/chat.ts:601-659`

```
handleRealtimeEvent(payload, { streaming })
  ├ 提取 sessionKey → 校验匹配当前会话
  ├ extractRealtimeMessages(payload)
  │   └ 从 payload 中提取消息数组（支持多种嵌套格式）
  │
  ├ 如果是 streaming:
  │   ├ 推入 pendingStreamMessages[]
  │   └ setTimeout(0) 批量处理:
  │       ├ ≤8 条 → 直接 mergeRealtimeMessages(batch, {streaming:true})
  │       └ >8 条 → requestAnimationFrame 分块处理（每块 8 条）
  │
  └ 如果非 streaming:
      直接 mergeRealtimeMessages(messages, {streaming:false})
```

### 9.4 mergeRealtimeMessages()

`src/stores/chat.ts:540-599`

```
mergeRealtimeMessages(nextMessages, { streaming })
  │
  ├ 对每条 nextMessage:
  │   ├ 有 id → 找同 id 消息 → content 更长者胜出
  │   ├ 流式模式 + 同 role:
  │   │   ├ 新 content 以旧 content 开头 → 替换（增长）
  │   │   ├ 旧 content 以新 content 结尾 → 跳过（重复）
  │   │   └ 否则 → 拼接 content
  │   │
  │   └ 无匹配 → push 新消息
  │
  └ messages.value = list    ← 触发 Vue 响应式更新
```

---

## 完整时序图

```
[用户]          [ChatPage]      [ChatStore]     [RPCClient]     [ApiClient]     [后端]         [Gateway]
   │                │               │               │               │               │               │
   │  按 Enter      │               │               │               │               │               │
   ├───────────────>│               │               │               │               │               │
   │                │ sendMessage() │               │               │               │               │
   │                ├──────────────>│               │               │               │               │
   │                │               │ 乐观插入消息   │               │               │               │
   │                │               │ phase=sending │               │               │               │
   │                │               │               │               │               │               │
   │                │               │ sendChatMessage()             │               │               │
   │                │               ├──────────────>│               │               │               │
   │                │               │               │ rpc('chat.send')              │               │
   │                │               │               ├──────────────>│               │               │
   │                │               │               │               │ POST /api/rpc │               │
   │                │               │               │               ├──────────────>│               │
   │                │               │               │               │               │ gateway.call() │
   │                │               │               │               │               ├──────────────>│
   │                │               │               │               │               │               │
   │                │               │               │               │               │         [LLM 处理]
   │                │               │               │               │               │               │
   │   ←──────────────────────────────────────────────────────── HTTP 200 OK ──────┤               │
   │                │               │ phase=waiting │               │               │               │
   │                │               │<──────────────┤               │               │               │
   │                │               │               │               │               │               │
   │                │               │               │               │     [Gateway 推送事件]           │
   │                │               │               │               │               │<──────────────┤
   │                │               │               │               │               │               │
   │                │               │               │               │               │ broadcastSSE() │
   │                │               │               │               │  SSE: event   │               │
   │                │               │               │               │<──────────────┤               │
   │                │               │               │  EventSource  │               │               │
   │                │               │               │<──────────────┤               │               │
   │                │               │  emit('event')│               │               │               │
   │                │               │<──────────────┤               │               │               │
   │                │               │               │               │               │               │
   │  ← UI 更新 ───┤               │               │               │               │               │
   │  thinking...   │               │               │               │               │               │
   │  tool: xxx     │               │               │               │               │               │
   │  replying...   │               │               │               │               │               │
   │  done          │               │               │               │               │               │
```

---

## 关键设计决策

### 双通道架构

- **控制面**：HTTP POST `/api/rpc` — 用于发送命令（chat.send, config.patch 等），请求-响应模式
- **数据面**：SSE `/api/events` — 用于接收实时事件（agent 状态、流式文本、工具进度），单向推送

### 乐观更新

用户消息在 `sendMessage()` 中立即 append 到 `messages[]`，不等后端确认。失败时回滚移除。

### 防御性参数探测

Gateway API 字段名不稳定（sessionKey/key/session, message/input/text/content），RPCClient 构造多组候选参数逐一尝试，直到成功。

### SSE 权限隔离

`broadcastSSE()` 对每个 SSE 客户端做权限过滤，只有 session 所属用户才能收到对应事件。

### 流式消息合并

`mergeRealtimeMessages()` 使用增量合并策略（content 前缀匹配），避免高频 SSE 事件导致消息闪烁或重复。

### runId 防重入

`finalizedRuns` Map 记录已完成的 runId，防止过期事件（如延迟到达的 delta）干扰新一轮对话。

---

## 相关源码文件索引

| 文件 | 职责 |
|------|------|
| `src/views/chat/ChatPage.vue` | 聊天页面 UI + 事件订阅入口 |
| `src/stores/chat.ts` | ChatStore：消息管理、agent 状态机、流式合并 |
| `src/stores/websocket.ts` | WebSocketStore：连接管理、事件总线 |
| `src/stores/workspace.ts` | WorkspaceStore：会话标题生成 |
| `src/api/rpc-client.ts` | RPCClient：Gateway RPC 封装、防御性参数探测 |
| `src/api/http-client.ts` | ApiClient：SSE 连接 + HTTP RPC 调用 |
| `src/api/websocket.ts` | OpenClawWebSocket：适配层（HTTP RPC ↔ 事件转发） |
| `src/composables/useEventStream.ts` | SSE 事件订阅 composable |
| `server/index.js` | Express 后端：REST 端点、RPC 代理、SSE 广播、权限过滤 |
| `server/gateway.js` | Gateway WebSocket 客户端：RPC 帧协议、事件接收 |
