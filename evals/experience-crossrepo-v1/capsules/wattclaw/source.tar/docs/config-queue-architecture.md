# ConfigQueue 架构文档

> 统一管理所有 Gateway config 修改操作的队列系统，解决 OCC 冲突和 rate limit 问题。

## 一、背景问题

OpenClaw Gateway 的 config 修改有三个约束：

1. **OCC 冲突**：`config.patch` 需要 `baseHash` 做乐观并发校验，多个调用方同时读取同一 hash 后修改，只有一个成功，其余报 `config changed since last load`
2. **Rate limit**：`config.patch` 限制 3 次/60s，超出后报 `rate limit exceeded; retry after Xs`
3. **多调用方竞争**：6+ 处代码都执行 `config.get → config.patch → config.apply` 流程，无任何协调

## 二、解决方案

### ConfigQueue 类

统一队列，所有 config 修改操作通过 `configQueueExecute()` 进入队列，串行执行。

核心设计：

- **FIFO 串行**：同一时间只有一个操作在执行，避免 OCC 冲突
- **主动限流**：滑动窗口限流器，在执行前判断是否接近 rate limit，主动等待
- **被动重试**：作为兜底，OCC 和 rate limit 错误仍会捕获并重试
- **Transform 模式**：调用方只提供"怎么改"的函数，队列负责"何时读、何时写、何时 apply"

### 代码位置

`server/index.js`，`configGetPolling` 定义之后。

## 三、队列架构

```
调用方（6 处）
    │
    ▼
configQueueExecute(transformFn, label, method?)
    │  检查 gateway.isConnected
    ▼
configQueue.enqueue(transformFn, label, method)
    │  包装成 Promise，push 到 _queue[]
    │  调用 _process()（如果已在运行则直接返回）
    ▼
ConfigQueue._process()
    │  _running 守卫 → 防止并发处理
    │  while 循环逐个取出队列项
    ▼
ConfigQueue._execute(item)  ← 核心执行逻辑
```

## 四、单次执行流程（`_execute`）

```
步骤 1. config.get（fresh，不用缓存）
       │  拿到 sourceConfig + baseHash
       ▼
步骤 2. transformFn(sourceConfig)
       │  调用方提供的变换函数，返回修改后的 config
       │  返回 null → 跳过，resolve(null)
       ▼
步骤 3. _waitForSlot()  ← 主动限流
       │  清理 60s 前的时间戳
       │  窗口内已有 3 次？→ 等到最早的那次滑出窗口 + 200ms 余量
       ▼
步骤 4. config.patch（或 config.set）
       │  发送到 Gateway，携带 baseHash（OCC 校验）
       │  成功后 _recordPatch() 记录时间戳
       ▼
步骤 5. config.get（再次 fresh）
       │  拿到 apply 所需的最新 hash
       ▼
步骤 6. config.apply
       │  激活变更
       ▼
步骤 7. configGetPolling.refresh()
       │  刷新 15s 缓存
       ▼
步骤 8. resolve / reject 返回给调用方
```

## 五、限流机制

### 滑动窗口限流器（主动）

```
_patchTimestamps = []     // 记录每次 config.patch 的调用时间戳
_MAX_PATCHES = 3          // 60s 窗口内最多 3 次
_WINDOW_MS = 60_000       // 窗口大小 60s
```

执行前调用 `_waitForSlot()`：

1. `_cleanWindow()` — 移除 60s 前的过期时间戳
2. 如果窗口内 < 3 次 → 直接放行
3. 如果窗口内 ≥ 3 次 → 计算 `waitMs = 最早时间戳 + 60s - 当前时间 + 200ms`，sleep 等待

### 时间线示例

```
T=0s    请求1 → 窗口[0]       → 执行 ✓
T=1s    请求2 → 窗口[0,1]     → 执行 ✓
T=2s    请求3 → 窗口[0,1,2]   → 执行 ✓
T=3s    请求4 → 窗口[0,1,2] 已满 → 等 60.2s
T=63.2s → 清理 T=0 → 窗口[1,2,63.2] → 执行 ✓
T=64s   请求5 → 窗口[1,2,63.2,64] 已满 → 等到 T=61.2s 清理 T=1...
```

### 被动重试（兜底）

正常情况下主动限流不会触发 Gateway 的 rate limit，但作为兜底：

```javascript
catch (err) {
  ├─ OCC 冲突（"config changed since last load"）
  │   → 等 (attempt+1) × 2s，重新 config.get → 重试
  │
  ├─ Rate limit（"rate limit"）
  │   → 等 retryAfterMs（≤65s），重新 config.get → 重试
  │
  ├─ 其他错误
  │   → 直接 reject，不重试
  │
  └─ 最多重试 3 次
}
```

## 六、调用方一览

| 调用方 | method | transformFn 做什么 |
|---|---|---|
| agent 删除残余清理 | **set** | 删除 `channels.feishu.accounts[agentId]` + 过滤 bindings |
| provider 创建 | patch | 往 `models.providers` 写入新 provider |
| provider 更新 | patch | 替换 `models.providers[providerId]` |
| provider 删除 | **set** | 删除 provider + 清理 `agents.defaults.models` 引用 |
| channel 同步 | patch | 写入 account + 添加/更新 binding |
| channel 删除 | **set** | 删除 account + 过滤 binding |
| 前端 proxy（patch） | patch | `{ ...sourceConfig, ...rawConfig }` 合并 |
| 前端 proxy（set） | **set** | `rawConfig` 整体替换 |

### Transform 函数规范

```javascript
(sourceConfig) => {
  // sourceConfig 是 Gateway 返回的当前完整配置（fresh）
  // 返回修改后的完整配置对象 → 队列执行 patch/apply
  // 返回 null → 表示无需修改，跳过
  return { ...sourceConfig, /* 修改部分 */ }
}
```

注意事项：

- **不可变更新**：必须用 spread 创建新对象，不能直接修改 sourceConfig
- **嵌套对象也要复制**：删除嵌套属性时先 spread 复制再 delete
- **返回 null = no-op**：队列 resolve(null)，调用方可据此判断是否实际执行了修改

## 七、`config.patch` vs `config.set`

| 特性 | config.patch | config.set |
|---|---|---|
| 语义 | 合并（merge） | 替换（replace） |
| 删除 key | 不支持，patch 只合并 | 支持，整体替换 |
| 使用场景 | 增加/修改配置项 | 删除配置项（如 provider） |
| 队列中 | `method = 'config.patch'`（默认） | `method = 'config.set'` |

当前使用 `config.set` 的场景：provider 删除、channel 删除、agent 删除残余清理 — 所有需要从 config 中**移除 key** 的操作。

## 八、前端 Proxy 处理

前端通过 `/api/rpc` 代理发送 `config.patch` / `config.set` 请求：

```javascript
// config.patch: 合并语义
configQueueExecute(
  (sourceConfig) => ({ ...sourceConfig, ...rawConfig }),
  'proxy-config.patch'
)

// config.set: 替换语义
configQueueExecute(
  () => rawConfig,
  'proxy-config.set',
  'config.set'
)
```

`params.raw` 缺失时直接返回 400，不会 fallthrough 绕过队列。

## 九、错误处理策略

| 错误类型 | 处理方式 | 最大重试 |
|---|---|---|
| OCC 冲突 | 等 (attempt+1) × 2s，重新 config.get | 3 次 |
| Rate limit | 等 retryAfterMs（≤65s） | 3 次 |
| Gateway 未连接 | 直接 throw（在 configQueueExecute 中检查） | 不重试 |
| 其他错误 | 直接 reject | 不重试 |
| transformFn 返回 null | resolve(null)，不执行 patch | N/A |

## 十、与 configGetPolling 缓存的关系

- **configGetPolling**：15s 轮询缓存，用于 `config.get` 的读取优化
- **ConfigQueue**：每次执行都用 `gateway.call('config.get')` 拿 fresh 数据，不用缓存
- **执行后刷新**：queue 执行成功后调用 `configGetPolling.refresh()` 更新缓存
- **前端 proxy**：执行后也调用 `configGetPolling.refresh()`

两者独立工作，互不干扰。缓存用于读，队列用于写。
