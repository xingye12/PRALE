# TTFT 超时与 CQRS 分离方案深度架构评估

> **文档性质**：架构设计评审（Architecture RFC Review）
> **范围**：WattClaw 后端 `POST /api/workspace/send` 的流式对话接口
> **日期**：2026-05-25
> **结论**：拒绝 CQRS 拆分，推荐 SSE 心跳保活方案

---

## 1. 调研背景

在 `POST /api/workspace/send` 的流式代理重构（Phase 1~3）完成后，引出新的架构议题：

- 当 Agent 执行耗时任务（长工具链、深度推理）时，前端可能在数十秒内收不到任何 SSE 数据
- 这导致两个表象问题：
  1. **代理/负载均衡空闲超时** — Nginx/ALB 可能在 30~60s 无数据后切断 TCP 连接
  2. **前端感知挂死** — 用户发送消息后长时间看不到任何反馈

为应对此问题，提出 **CQRS 分离架构**：
- `POST /send` 立即返回 `{ taskId }`
- `GET /stream/:taskId` 通过 SSE 订阅结果流

本报告基于对 OpenClaw Gateway 源码、`ChatStreamProxyService` 实现、WattClaw 前端流式处理的完整代码路径追踪，对该提案进行批判性评估。

---

## 2. OpenClaw Agent 消息回推协议

OpenClaw 内部采用**基于 `runId` 的内存事件总线**（`infra/agent-events.js`）实现 Agent → Gateway 的异步回推。

### 2.1 核心机制

- Agent 执行过程中调用 `emitAgentEvent({ runId, stream, data })` 向总线投递事件
- Gateway HTTP 处理器通过 `onAgentEvent((evt) => { if (evt.runId !== runId) return })` 按 `runId` 过滤订阅
- Gateway 将接收到的事件翻译为 OpenAI 兼容 SSE chunk，写入 HTTP Response

### 2.2 事件类型

| 事件类型 | 说明 | Gateway HTTP 层处理 |
|---------|------|-------------------|
| `stream: "assistant"` | LLM token 增量 | 翻译为 `chat.completion.chunk` SSE |
| `stream: "lifecycle"` | 阶段变更（`end` / `error`） | 触发 SSE 流收尾（`[DONE]`） |
| `stream: "thinking"` | 推理/思考过程 | **主动丢弃**，不暴露给客户端 |
| `stream: "tool"` | 工具调用状态 | **主动丢弃**，不暴露给客户端 |

### 2.3 关键结论

Agent 与 Gateway 之间**并非直连 HTTP Response**，而是解耦的内存事件总线。这解释了 TTFT 可能很长的根本原因：在 `agentCommandFromIngress()` 执行期间，如果 Agent 处于工具调用链或长推理阶段，`assistant` 事件可能数十秒甚至数分钟都不会产生。

---

## 3. WattClaw 当前协议链路

当前架构为**双层 SSE 透传**：

```
Frontend (ReadableStream)
    ↑ SSE
WattClaw Backend (/api/workspace/send)
    ↑ SSE (fetch + pipeline)
Gateway HTTP (/v1/chat/completions)
    ↑ onAgentEvent 订阅
Agent 执行 (agentCommandFromIngress)
```

### 3.1 前端（`src/stores/workspace.ts`）

- 使用 `fetch()` POST `/api/workspace/send`
- 获取 `response.body` 后通过 `getReader()` + `TextDecoder` 手动解析 SSE 行
- 目前只解析 `choices[0].delta.content` 和 `finish_reason`
- 已设置 5 分钟最大流超时（`maxStreamTimeout = setTimeout(..., 300_000)`）

### 3.2 后端（`server/services/chat-stream-proxy.ts`）

- `ChatStreamProxyService.connect()` 向 Gateway 发起 `fetch()` POST `/v1/chat/completions`（`stream: true`）
- 通过 `stream.pipeline()` 将 Gateway 的 SSE 流直接透传至 Express `res`
- 具备双重超时盾：连接超时（30s）+ 流空闲超时（60s）
- 具备 Phase Gate 的 exactly-once finalize 保证

---

## 4. Gateway 是否暴露原生 SSE？

**是。Gateway 的 `/v1/chat/completions` 原生支持 SSE。**

证据来源（`openclaw/src/gateway/openai-http.ts`）：

1. 显式调用 `setSseHeaders(res)` 设置 `Content-Type: text/event-stream`
2. 使用 `res.write('data: {...}\n\n')` 实现标准 SSE 帧格式
3. **流式路径在调用 `agentCommandFromIngress` 之前就已经向客户端写入 `role: assistant` 的初始 chunk**（第 1136-1137 行）
4. 已内置客户端断开检测（`watchClientDisconnect`）和 `AbortController` 传播

**结论**：WattClaw 已经在消费 Gateway 的原生 SSE 流，无需额外封装。

---

## 5. CQRS 分离方案评估

### 5.1 方案概述

- `POST /send` → 校验参数、启动 Gateway 连接、立即返回 `{ taskId }`，不挂起 HTTP 连接
- `GET /stream/:taskId` → 通过 SSE 订阅该任务的结果流

### 5.2 是否真正解决 TTFT 问题？

**技术层面：不能降低 TTFT。**

TTFT（Time To First Token）的瓶颈在 `agentCommandFromIngress` 内部 —— Agent 的工具执行、推理、上下文构建。这些完全发生在 Gateway 侧，与 WattClaw 的 HTTP 接口形态无关。

无论 POST 是否立即返回，前端拿到 `taskId` 后调用 `GET /stream/:taskId`，该 GET 请求仍然要等待 Gateway 产生第一个 `assistant` 事件。**接口拆分不改变底层等待时间。**

**CQRS 在以下两个场景有合理价值，但均非 TTFT 的技术根治：**

1. **代理/负载均衡空闲超时**：如果中间件对 HTTP 连接有 30s 空闲超时，而 TTFT 达到 45s，当前架构下 `fetch()` 连接会被切断。CQRS 的 POST 快速返回避免了这一点，但 `GET /stream` 仍然面临**相同的空闲超时风险** —— 只要第一个 token 未到达，GET 连接仍然是无数据的"空闲"连接。

2. **UX 即时反馈**：前端可以在 POST 后立即显示"任务已提交 / Agent 思考中"状态。这改善的是**感知性能**，不是实际 TTFT。

### 5.3 关键缺陷与风险

#### 风险一：内存泄漏与孤儿流（致命）

CQRS 要求 WattClaw 后端维护一个**任务级流注册表**（`taskId → active stream handle`）。这会引入以下致命问题：

- **客户端弃用**：用户 POST 后关闭浏览器、刷新页面或 App 被系统回收，GET 请求永不发起 → 流在注册表中永驻，无法触发 finalize
- **僵尸 taskId**：GET 请求因网络抖动失败，客户端放弃重试 → 后端持有死流，占用 `ChatStreamHandleImpl`、Node.js Readable、TCP socket
- **无自然 TTL**：当前 `ChatStreamHandleImpl` 的生命周期绑定于 `pipeline(res)` 的 `close`/`end`/`error` 事件。若从未调用 `bind(req, res)`，则没有任何机制触发 finalize

**必须引入 TTL + 定期清扫（sweeper）**，这会显著增加状态管理复杂度，与当前 "RAII Cleanup Registry + Phase Gate" 的简洁生命周期模型背道而驰。

#### 风险二：竞态条件

- **过早 GET**：客户端 POST 拿到 taskId 后立即 GET，但此时 Gateway 的 `fetch()` 可能尚未 resolve（`connect()` 仍在 DNS/TLS/HTTP 握手阶段）→ 注册表中无此 taskId
- **过晚 GET**：客户端 GET 时流已结束（Gateway 超快返回）→ 需要处理"流已关闭"的优雅降级，或保持流在注册表中缓存一段时间供重放
- **多实例部署**：POST 打到实例 A，GET 打到实例 B → 注册表必须是分布式（Redis）或需要会话亲和性（sticky session）。当前 WattClaw 是无状态的，此改动引入部署耦合。

#### 风险三：错误传播路径断裂

当前架构的错误传播是同步且线性的：

```
Gateway 连接失败
  → ChatProxyError(502/504)
  → res.status(502).json({ ok: false, error })
  → 前端 fetch catch
```

CQRS 架构下错误变为异步且分裂的：

```
POST 阶段：Gateway 连接失败 → 可以返回 500 JSON（尚好）
GET 阶段：Gateway 连接在 GET 发起后失败 → SSE 流已开启，
          只能通过 SSE error 事件传播，前端状态机复杂度翻倍
```

前端需要同时处理：
- POST 的同步 JSON 错误
- GET 的 SSE `error` 事件帧错误
- GET 的 EventSource `onerror` 网络错误

#### 风险四：SSE 重连悖论

如果 `GET /stream/:taskId` 因网络中断断开，前端 EventSource 或 fetch reader 会尝试重连/重读。但 SSE 是**有状态的** —— 已发送的 chunk 不会重发。

CQRS 方案要么：
- 接受消息丢失（导致前端显示不完整对话）
- 在服务端实现 chunk 缓存/回放（等同于重新发明消息队列）

### 5.4 总体评价

该方案在架构上**属于过度设计**。它用显著增加的复杂度（注册表、TTL、竞态处理、分布式状态）换取了有限的 UX 收益，且**没有解决 TTFT 的根本瓶颈**。

如果真实痛点是"代理超时切断长连接"，CQRS 的 GET 端同样会超时。
如果真实痛点是"前端长时间无反馈"，这可以通过现有 SSE 流的增强实现，无需拆分接口。

---

## 6. 更轻量的替代方案

推荐以下三种按优先级排序的替代策略，均可在现有架构上增量实现，无需引入状态注册表。

### 方案 A：SSE 心跳保活 + 状态事件注入（首选，成本最低）

在 `ChatStreamHandleImpl` 的 `bind()` 中，除了现有的 `idleTimeoutMs`（流不活动超时），增加一个**心跳发送机制**：

**机制**：
- 当 `upstream` 在 N 秒（建议 15~20s，低于常见代理的 30s 空闲超时）内未产生 `data` 事件时，向 `res` 写入 SSE comment 行（`:keepalive\n\n`）或自定义状态事件（`event: status\ndata: {"phase":"thinking"}\n\n`）
- 每次收到 upstream `data` 事件时重置心跳计时器

**效果**：
- 保持 TCP 连接活跃，穿透 Nginx/ALB/Cloudflare 的 30s/60s/100s 空闲超时
- 前端可以监听 `status` 事件，渲染"Agent 思考中..."的 UI 占位符
- 零状态管理开销，无注册表，无孤儿流
- Gateway 侧无需任何改动

**复杂度**：极小。在现有 `armIdleTimer` / `disarmIdleTimer` 机制旁增加一个 `heartbeatTimer` 即可。

### 方案 B：暴露 Gateway 非 assistant 事件（中等成本）

OpenClaw Agent 在执行期间会 emit `thinking` 和 `tool` 事件，但 Gateway 的 `openai-http.ts` 为了兼容 OpenAI 格式而主动丢弃了它们。

WattClaw 作为非 OpenAI 兼容的私有客户端，**不需要遵守 OpenAI 的 SSE 格式限制**。可以在 `ChatStreamProxyService` 中：

- 不直接 `pipeline(upstream, destination)` 透传 Gateway 原始 SSE
- 改为逐帧解析 Gateway SSE，识别并转发非 assistant 事件为 WattClaw 自定义事件帧
- 前端相应增加对这些自定义事件的解析和 UI 渲染

**效果**：前端可以看到 Agent 的实时思考过程和工具调用状态，极大缓解"长时间无反馈"的焦虑。

**复杂度**：中等。需要替换 `pipeline` 为手动 parser，增加 SSE 帧解析逻辑。

### 方案 C：前端感知优化（零后端改动）

前端 `workspace.ts` 的 `fetch()` 调用后，在 `reader.read()` 等待第一个 chunk 期间，主动渲染"等待 Agent 响应"的 skeleton/loading UI。

当前代码的问题：
- `fetch()` resolve 很快（因为 Gateway 立即返回 HTTP headers）
- 但 `reader.read()` 的第一次迭代可能阻塞数十秒
- 前端只在收到 `content` 后才开始更新 UI（`appendStreamingContent`）

**优化**：
- `fetch()` resolve 后立即设置 `isAgentThinking = true`，渲染 thinking UI
- 第一次 `content` 到达后取消 thinking 状态，切换到流式文本渲染

**复杂度**：极低，纯前端改动。

**局限**：只能解决 UX 感知问题，不能解决代理空闲超时问题。

### 方案 D：降低实际 TTFT（根因解决，OpenClaw 侧）

如果 TTFT 长达数十秒，应当分析 OpenClaw Agent 的具体执行路径：

- 是否工具调用链过长？（例如连续调用 3-4 个工具后才生成回复）
- 是否模型本身的推理延迟高？（大模型推理的 prefill 阶段）
- 是否上下文窗口过大导致 prompt processing 耗时？
- 是否可以在 Agent prompt 中增加"先给出简要回复，再执行工具"的指令？

这些属于 OpenClaw Agent 侧优化，不在 WattClaw 工程范围内，但是 TTFT 问题的**真正根因所在**。

---

## 7. 结论与建议

### 7.1 方案对比矩阵

| 维度 | CQRS 拆分提案 | 方案 A（SSE 心跳） | 方案 B（非 assistant 事件） | 方案 C（前端优化） |
|------|--------------|-------------------|--------------------------|-----------------|
| 解决代理超时 | 部分（POST 免超时，GET 仍超时） | **完全** | 部分（数据量增大） | 不能 |
| 解决 UX 无反馈 | 是 | 是（status 事件） | **是**（thinking 内容） | 是（loading UI） |
| 引入状态注册表 | **必须** | 不需要 | 不需要 | 不需要 |
| 孤儿流风险 | **高** | 无 | 无 | 无 |
| 多实例部署 | 需要分布式状态 | 无状态 | 无状态 | 无状态 |
| 前端改动量 | 大（拆分 POST/GET + 状态机） | 小 | 中 | 极小 |
| 后端改动量 | 大（注册表 + TTL + 竞态处理） | **极小** | 中 | 零 |
| 降低实际 TTFT | 不能 | 不能 | 不能 | 不能 |

### 7.2 最终决策

**拒绝 CQRS 拆分方案。**

当前 `ChatStreamProxyService` 的架构已经具备生产级的流生命周期管理（Phase Gate、RAII Cleanup、Dual Timeout）。在此之上增加 CQRS 注册表是**架构倒退** —— 它将无状态代理变为有状态服务，引入了分布式系统中最难处理的"孤儿资源"问题。

**推荐采用方案 A（SSE 心跳/状态事件注入）作为 Phase 4 的演进方向**，在现有 `ChatStreamHandleImpl` 中增加一个低频率的"无数据时发送 keepalive/status"机制。这用不到 30 行逻辑即可解决代理超时和前端感知两个问题，且不会引入任何新的状态管理面。

**方案 C（前端 thinking UI）可以作为同批次的零成本并行优化**，与方案 A 组合使用。

**方案 B（非 assistant 事件暴露）建议作为中长期体验优化**，在方案 A 落地后评估收益成本比。

### 7.3 架构原则重申

> HTTP 热路径应保持无状态。状态只应存在于：
> 1. 客户端（前端 Store）
> 2. 权威数据源（Gateway / 数据库）
> 3. 临时流句柄（已绑定到具体 TCP 连接的生命周期对象）
>
> 在 WattClaw 后端引入"跨请求的任务注册表"违反了这一原则。

---

## 8. 后续行动

- [ ] 方案 A 设计细化：心跳间隔、状态事件 schema、前端解析逻辑
- [ ] 方案 C 前端实现：`isAgentThinking` 状态 + Thinking UI 组件
- [ ] 与 OpenClaw 团队同步：评估 Agent 侧 TTFT 优化空间（工具链并行化、推理模型选型）
- [ ] 文档归档：将本评估结论纳入 `docs/decisions.md`

---

## 9. 双层 SSE 透传是否合理？

**结论：不合理。这是架构反模式。**

当前架构的问题是 WattClaw Backend 扮演了一个**"无增值透明代理"（Dumb Proxy）**的角色：

```
Frontend  ← 透传  ←  WattClaw Backend  ← 透传  ←  Gateway SSE
```

这带来了三个根本性缺陷：

### 9.1 延迟叠加

Frontend 到 Gateway 有两跳网络往返。每次 `reader.read()` 的数据都要经过 WattClaw Backend 的 `pipeline()`，增加了 buffering 和 event loop 调度延迟。在流式场景中，**每一毫秒的延迟都会被用户感知为"卡顿"**。

### 9.2 错误传播模糊

Gateway 的 SSE 流中如果混入错误帧（非标准 OpenAI 格式），`pipeline()` 会原样透传，Frontend 的 SSE parser 可能解析失败。错误在哪一层发生变得不可观测。

当 Gateway 连接在流中途断开时：
- 当前架构：`pipeline()` 抛出 `ERR_STREAM_PREMATURE_CLOSE`，WattClaw Backend 调用 `finalize('abort')`，Frontend 看到 TCP 断开
- 用户看到的效果是：对话突然停止，没有错误提示

### 9.3 格式绑架

WattClaw 的 Frontend 被迫解析 OpenAI 兼容的 `choices[0].delta.content` 格式。这意味着 WattClaw 的产品语义被 Gateway 的协议绑架了 —— **WattClaw 不是 OpenAI 客户端，它是一个独立的管理平台。**

中间层存在的唯一正当理由，是它提供了客户端和上游都无法独立完成的价值：鉴权、RBAC、协议翻译、事件增强、心跳注入。纯字节搬运不是。

---

## 10. 最合理的 Gateway 接入方案

> 完全抛开现有代码逻辑，从第一性原理推导。

最合理的架构不是"选一个协议从头用到尾"，而是**分层接入（Layered Access）**，让每一层走最适合的通道。

### 10.1 前提假设

- Gateway 同时暴露 **HTTP SSE**（`/v1/chat/completions`）和 **WebSocket RPC**
- WattClaw 是独立产品，Frontend 是浏览器环境
- Gateway 位于内网，Frontend 不能直接暴露 Gateway 的 shared-secret token
- WattClaw 有多用户隔离和 RBAC 需求

### 10.2 推荐架构：三层接入模型

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │ 控制面 REST  │  │ 数据面 SSE  │  │    事件面 SSE        │ │
│  │ (管理操作)   │  │ (对话流)    │  │   (/api/events)     │ │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘ │
└─────────┼────────────────┼────────────────────┼────────────┘
          │                │                    │
          │ ① REST API     │ ② Smart Proxy SSE  │ ③ Filtered SSE
          ▼                ▼                    ▼
┌─────────────────────────────────────────────────────────────┐
│                  WattClaw Backend (Express)                  │
│  ┌─────────────────┐  ┌────────────────────────────────────┐│
│  │ 鉴权 + RBAC      │  │ Protocol Translator               ││
│  │ Session 管理     │  │ (OpenAI SSE → WattClaw Semantic)  ││
│  │ 用户隔离         │  │ 注入心跳、thinking、tool 状态      ││
│  └─────────────────┘  └────────────────────────────────────┘│
│           │                           │                     │
│           │ WS RPC                    │ HTTP SSE fetch      │
│           ▼                           ▼                     │
│  ┌─────────────────┐         ┌─────────────────────────┐   │
│  │ Gateway WS RPC   │         │ Gateway /v1/chat/       │   │
│  │ (控制面代理)      │         │ completions             │   │
│  │ sessions.list    │         │ (数据面直连 Backend)      │   │
│  │ config.patch     │         │                         │   │
│  │ chat.history     │         │                         │   │
│  └─────────────────┘         └─────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

#### 第一层：控制面（Control Plane）— REST API → Gateway WS RPC

**用途**：管理操作（sessions.list、config.patch、agents CRUD、用户管理）

**为什么走 WS RPC 且必须经 Backend**：
- 管理操作需要权限过滤（普通用户只能看自己的 session，admin 看全部）
- Gateway 的 WS RPC 需要 device identity + shared secret，不能暴露给浏览器
- Backend 是控制面的权威，负责将用户的 JWT 转换为 Gateway 的 operator 权限

**协议**：WattClaw REST API（WattClaw 自己定义的 JSON 契约）

#### 第二层：数据面（Data Plane）— Smart Proxy SSE

**用途**：对话流（chat stream）

**为什么不是双层透传**：
Backend 消费 Gateway 的 OpenAI SSE，但**不是 pipeline 透传**。Backend 逐帧解析 Gateway SSE，翻译为 **WattClaw 语义化 SSE 协议**，再推送给 Frontend。

**WattClaw SSE 协议示例**：

```
event: status
data: {"phase":"thinking","agent":"devops"}

event: text
data: {"content":"正在","index":0}

event: tool
data: {"name":"docker_ps","status":"start","toolCallId":"call_123"}

event: text
data: {"content":"分析","index":0}

event: done
data: {"finishReason":"stop"}
```

**Backend 在此层提供的增值**：
- **协议翻译**：OpenAI `choices[0].delta.content` → WattClaw 语义化事件
- **心跳注入**：15s 无数据时自动发送 `:keepalive` 或 `event: ping`，解决代理超时
- **事件增强**：将 Gateway 丢弃的 `thinking`、`tool` 事件重新注入流中
- **错误包装**：Gateway 连接失败时，在 SSE 流内发送 `event: error`，而非粗暴断开 TCP
- **Session 绑定**：一个 SSE 连接可以复用于多个 session 的推送

**Frontend 消费方式**：

```javascript
const eventSource = new EventSource('/api/workspace/stream')
eventSource.addEventListener('text', (e) => appendContent(JSON.parse(e.data)))
eventSource.addEventListener('thinking', (e) => showThinkingIndicator(JSON.parse(e.data)))
eventSource.addEventListener('tool', (e) => updateToolCard(JSON.parse(e.data)))
```

#### 第三层：事件面（Event Plane）— 过滤聚合 SSE

**用途**：Gateway 生命周期事件（session created/updated/deleted、token usage、cron 触发）

**为什么需要独立通道**：
对话流 SSE 是**请求-响应式**的（一个 POST 对应一个 SSE 流）。但生命周期事件是**广播式**的（Gateway 随时可能推送），不能混在同一个流中。

**Backend 的职责**：
- 通过 WS RPC 订阅 Gateway 的全局事件
- 根据用户的 session 所有权过滤事件
- 通过 `/api/events` SSE 长连接推送给 Frontend

**这个通道可以保留现有实现**，因为它已经在正确的事情上做了正确的事。

### 10.3 为什么不推荐 Frontend 直连 Gateway？

有人可能会问：既然 Gateway 已经有 HTTP SSE 了，为什么不直接让浏览器 `fetch()` Gateway？

**阻碍条件**：

1. **认证模型不匹配**：Gateway 使用 shared-secret bearer token + Ed25519 device identity。这不是浏览器可以持有的凭证。
2. **CORS 缺失**：Gateway 是内部基础设施，通常不会配置跨域。
3. **多用户隔离缺失**：Gateway 的 HTTP 端点没有"用户"概念，只有 operator scope。WattClaw 的 RBAC 无法直接映射到 Gateway。
4. **网络拓扑**：在生产环境中，Gateway 可能位于内网或私有子网，浏览器不可达。

除非 WattClaw 团队愿意在 Gateway 层增加 OAuth/JWT 支持、CORS 配置、以及用户-设备映射，否则 Frontend 直连在工程上不现实。

### 10.4 关键设计决策

| 决策点 | 选择 | 理由 |
|-------|------|------|
| 对话流是否透传 Gateway SSE？ | **否** | Backend 必须作为协议翻译层 |
| 对话流是否使用 WS RPC？ | **否** | WS 队头阻塞问题已证实；HTTP SSE 更适合单向流 |
| 心跳由谁注入？ | **WattClaw Backend** | Gateway 不感知代理层的空闲超时 |
| thinking/tool 事件是否暴露？ | **是** | 这是 WattClaw 产品的差异化体验 |
| 生命周期事件是否与对话流共用通道？ | **否** | 广播事件和请求-响应流必须分离 |
| 错误如何传播？ | **SSE error 事件帧** | 保持连接优雅降级，而非 TCP 断开 |

### 10.5 一句话总结

> **WattClaw Backend 不应该是一个透明代理，而应该是一个"协议翻译与增强层"。控制面走 WS RPC（因为需要权限代理），数据面走 HTTP SSE（因为需要单向流式推送），但数据面的 SSE 必须是 WattClaw 自己的语义化协议 —— 不是 OpenAI 格式的透传。**
