# feature/mobile-workspace 分支完整变更记录

> 本文档自动同步自 `feature/mobile-workspace` 分支，记录了相对于 `main` 分支的全部改动。
> 生成时间：2026-05-18T03:37:30Z

## 一、提交历史

2805dbd fix: 底部留白收敛至 Gemini 标准——24px 紧凑间隙
37be9c3 feat: 移动端基础设施骨架层——Tokens、SafeArea、ThemeOverrides、Layout、路由守卫
840a5c0 feat: 移动端工作台业务填充——高性能聊天视图、CSS 性能防护、路由分流
9a504b1 feat: 移动端 Phase 3 高性能交互组件全量交付
1344294 feat: 6维分布式边界防御层终局加固

## 二、文件变更清单

| 状态 | 文件路径 |
|------|----------|
| A | `src/assets/styles/mobile-safe-area.css` |
| A | `src/assets/styles/mobile-tokens.css` |
| A | `src/composables/useLongPress.ts` |
| A | `src/config/mobile-theme.ts` |
| A | `src/router/guards/mobile-guard.ts` |
| M | `src/router/index.ts` |
| A | `src/router/mobile-routes.ts` |
| M | `src/stores/workspace.ts` |
| A | `src/views/mobile/components/MobileFilePicker.vue` |
| A | `src/views/mobile/components/MobileMessageContextMenu.vue` |
| A | `src/views/mobile/components/MobileToolGroupCard.vue` |
| A | `src/views/mobile/layout/MobileBottomBar.vue` |
| A | `src/views/mobile/layout/MobileHeader.vue` |
| A | `src/views/mobile/layout/MobileLayout.vue` |
| A | `src/views/mobile/pages/MobileAgentTeamPage.vue` |
| A | `src/views/mobile/pages/MobileChatView.vue` |
| A | `src/views/mobile/pages/MobileDashboardPage.vue` |
| A | `src/views/mobile/pages/MobileFallbackPage.vue` |
| A | `src/views/mobile/pages/MobileProfilePage.vue` |
| A | `src/views/mobile/pages/MobileWorkspacePage.vue` |
| M | `src/views/workspace/MessageList.vue` |

## 三、完整 Diff

以下是从 `main` 到 `feature/mobile-workspace` 的完整 diff：

\`\`\`diff
diff --git a/src/assets/styles/mobile-safe-area.css b/src/assets/styles/mobile-safe-area.css
new file mode 100644
index 0000000..d046140
--- /dev/null
+++ b/src/assets/styles/mobile-safe-area.css
@@ -0,0 +1,49 @@
+/**
+ * 安全区域原子工具类
+ * 仅用于移动端 Layout 骨架注入，不污染 Web 端
+ * 所有类必须在 .mobile-scope 内部使用
+ */
+
+.mobile-scope .safe-inset-top {
+  padding-top: max(var(--safe-top), var(--space-md)) !important;
+}
+
+.mobile-scope .safe-inset-bottom {
+  padding-bottom: max(var(--safe-bottom), var(--space-md)) !important;
+}
+
+.mobile-scope .safe-inset-x {
+  padding-left: max(var(--safe-left), var(--space-md)) !important;
+  padding-right: max(var(--safe-right), var(--space-md)) !important;
+}
+
+.mobile-scope .safe-area-screen {
+  min-height: 100vh;
+  min-height: 100dvh;
+  padding-top: max(var(--safe-top), var(--space-md));
+  padding-bottom: max(var(--safe-bottom), var(--space-md));
+  padding-left: max(var(--safe-left), var(--space-md));
+  padding-right: max(var(--safe-right), var(--space-md));
+  box-sizing: border-box;
+}
+
+/* 底部导航栏专用（固定在安全区之上） */
+.mobile-scope .mobile-bottom-bar {
+  height: calc(var(--mobile-bottom-bar-height) + var(--safe-bottom));
+  padding-bottom: var(--safe-bottom);
+}
+
+/* 顶部导航栏专用（高度含安全区） */
+.mobile-scope .mobile-header {
+  height: calc(var(--mobile-header-height) + var(--safe-top));
+  padding-top: var(--safe-top);
+}
+
+/* 内容区弹性高度（扣除 Header + BottomBar） */
+.mobile-scope .mobile-content-area {
+  flex: 1;
+  min-height: 0;
+  overflow-y: auto;
+  overflow-x: hidden;
+  -webkit-overflow-scrolling: touch;
+}
diff --git a/src/assets/styles/mobile-tokens.css b/src/assets/styles/mobile-tokens.css
new file mode 100644
index 0000000..4078caf
--- /dev/null
+++ b/src/assets/styles/mobile-tokens.css
@@ -0,0 +1,77 @@
+/**
+ * 移动端专属设计令牌 (Mobile Design Tokens)
+ * 规则：
+ * 1. 根 font-size 固定 16px，此处不动态调整
+ * 2. 间距使用 rem 变量，通过 --mobile-space-unit 做全局杠杆
+ * 3. 字体使用 CSS Locks clamp()，独立控制无级变速
+ * 4. 安全区变量原子化，供工具类引用
+ * 5. 所有变量仅在 .mobile-scope 作用域内生效，严禁泄漏到全局
+ */
+
+.mobile-scope {
+  /* ── 间距基准杠杆 ── */
+  --mobile-space-unit: 0.875rem;
+
+  /* 原子间距令牌 */
+  --space-3xs: calc(0.125 * var(--mobile-space-unit));
+  --space-2xs: calc(0.25 * var(--mobile-space-unit));
+  --space-xs: calc(0.5 * var(--mobile-space-unit));
+  --space-sm: calc(0.75 * var(--mobile-space-unit));
+  --space-md: var(--mobile-space-unit);
+  --space-lg: calc(1.25 * var(--mobile-space-unit));
+  --space-xl: calc(1.5 * var(--mobile-space-unit));
+  --space-2xl: calc(2 * var(--mobile-space-unit));
+  --space-3xl: calc(2.5 * var(--mobile-space-unit));
+  --space-4xl: calc(3 * var(--mobile-space-unit));
+
+  /* ── 安全区环境变量（硬件隔离层）── */
+  --safe-top: env(safe-area-inset-top, 0px);
+  --safe-bottom: env(safe-area-inset-bottom, 0px);
+  --safe-left: env(safe-area-inset-left, 0px);
+  --safe-right: env(safe-area-inset-right, 0px);
+
+  /* ── 导航骨架尺寸 ── */
+  --mobile-header-height: 52px;
+  --mobile-bottom-bar-height: 56px;
+  --mobile-max-content-width: 100%;
+
+  /* ── 物理交互规范 ── */
+  --min-hit-target: 44px;
+  --hit-target-lg: 48px;
+
+  /* ── CSS Locks 排版层（320px-480px 无级变速）── */
+  --text-2xs: clamp(10px, 2.5vw, 11px);
+  --text-xs: clamp(11px, 2.9vw, 12px);
+  --text-sm: clamp(12px, 3.4vw, 14px);
+  --text-base: clamp(14px, 3.8vw, 16px);
+  --text-md: clamp(15px, 4.2vw, 17px);
+  --text-lg: clamp(16px, 4.8vw, 18px);
+  --text-xl: clamp(18px, 5.4vw, 20px);
+  --text-2xl: clamp(20px, 6.2vw, 24px);
+  --text-3xl: clamp(24px, 7.5vw, 28px);
+
+  /* 行高令牌 */
+  --leading-tight: 1.25;
+  --leading-normal: 1.5;
+  --leading-relaxed: 1.75;
+
+  /* 圆角令牌（移动端略大于桌面，提升触控感知） */
+  --radius-sm: 8px;
+  --radius-md: 12px;
+  --radius-lg: 16px;
+  --radius-xl: 20px;
+  --radius-full: 9999px;
+
+  /* 阴影（移动端简化，减少渲染开销） */
+  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.06);
+  --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.08);
+  --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.1);
+
+  /* Z-Index 层级 */
+  --z-base: 1;
+  --z-sticky: 10;
+  --z-header: 100;
+  --z-bottom-bar: 100;
+  --z-modal: 200;
+  --z-toast: 300;
+}
diff --git a/src/composables/useLongPress.ts b/src/composables/useLongPress.ts
new file mode 100644
index 0000000..19e1354
--- /dev/null
+++ b/src/composables/useLongPress.ts
@@ -0,0 +1,79 @@
+import { ref, readonly } from 'vue'
+
+export type LongPressState = 'idle' | 'pressing' | 'scrolling' | 'long-pressed'
+
+const PRESS_THRESHOLD_MS = 400
+const MOVE_THRESHOLD_PX = 10
+
+export function useLongPress(
+  onLongPress: (e: TouchEvent) => void,
+  options: { thresholdMs?: number; moveThresholdPx?: number } = {}
+) {
+  const thresholdMs = options.thresholdMs ?? PRESS_THRESHOLD_MS
+  const moveThresholdPx = options.moveThresholdPx ?? MOVE_THRESHOLD_PX
+
+  const state = ref<LongPressState>('idle')
+  let _timer: ReturnType<typeof setTimeout> | null = null
+  let _startX = 0
+  let _startY = 0
+
+  function reset() {
+    if (_timer) {
+      clearTimeout(_timer)
+      _timer = null
+    }
+    state.value = 'idle'
+  }
+
+  function handleTouchStart(e: TouchEvent) {
+    if (e.touches.length !== 1) return
+    const touch = e.touches[0]!
+    _startX = touch.clientX
+    _startY = touch.clientY
+    state.value = 'pressing'
+
+    _timer = setTimeout(() => {
+      if (state.value === 'pressing') {
+        state.value = 'long-pressed'
+        onLongPress(e)
+      }
+    }, thresholdMs)
+  }
+
+  function handleTouchMove(e: TouchEvent) {
+    if (state.value !== 'pressing') return
+    if (e.touches.length !== 1) {
+      reset()
+      return
+    }
+    const touch = e.touches[0]!
+    const dx = Math.abs(touch.clientX - _startX)
+    const dy = Math.abs(touch.clientY - _startY)
+    if (dx > moveThresholdPx || dy > moveThresholdPx) {
+      state.value = 'scrolling'
+      if (_timer) {
+        clearTimeout(_timer)
+        _timer = null
+      }
+    }
+  }
+
+  function handleTouchEnd() {
+    reset()
+  }
+
+  function handleTouchCancel() {
+    reset()
+  }
+
+  return {
+    state: readonly(state),
+    handlers: {
+      onTouchStart: handleTouchStart,
+      onTouchMove: handleTouchMove,
+      onTouchEnd: handleTouchEnd,
+      onTouchCancel: handleTouchCancel,
+    },
+    reset,
+  }
+}
diff --git a/src/config/mobile-theme.ts b/src/config/mobile-theme.ts
new file mode 100644
index 0000000..e6e111b
--- /dev/null
+++ b/src/config/mobile-theme.ts
@@ -0,0 +1,102 @@
+import type { GlobalThemeOverrides } from 'naive-ui'
+
+/**
+ * 移动端 Naive UI 全局主题覆盖
+ * 目标：将所有基础交互组件的物理热区拉高至 >= 44px
+ * 注入点：MobileLayout.vue 的 <n-config-provider>
+ *
+ * 注意：此配置仅影响被 <n-config-provider> 包裹的组件树，
+ * 不会泄漏到 Web 端布局。
+ */
+export const mobileThemeOverrides: GlobalThemeOverrides = {
+  Button: {
+    heightTiny: '32px',
+    heightSmall: '38px',
+    heightMedium: '44px',
+    heightLarge: '48px',
+    borderRadiusTiny: '8px',
+    borderRadiusSmall: '10px',
+    borderRadiusMedium: '12px',
+    borderRadiusLarge: '14px',
+    paddingTiny: '0 10px',
+    paddingSmall: '0 14px',
+    paddingMedium: '0 20px',
+    paddingLarge: '0 24px',
+    fontSizeMedium: 'var(--text-base)',
+  },
+
+  Input: {
+    heightSmall: '38px',
+    heightMedium: '44px',
+    heightLarge: '48px',
+    borderRadius: '12px',
+    fontSizeMedium: 'var(--text-base)',
+    paddingMedium: '0 14px',
+  },
+
+  Select: {
+    heightMedium: '44px',
+  },
+
+  InternalSelection: {
+    heightMedium: '44px',
+  },
+
+  InternalSelectMenu: {
+    height: '44px',
+    paddingTiny: '6px',
+    paddingSmall: '8px',
+  },
+
+  Card: {
+    borderRadius: '16px',
+    paddingMedium: 'var(--space-lg)',
+  },
+
+  Menu: {
+    itemHeight: '44px',
+    itemIconWidth: '24px',
+    itemIconMargin: '0 12px 0 0',
+    fontSize: 'var(--text-base)',
+  },
+
+  Tabs: {
+    tabHeightMedium: '44px',
+    tabHeightLarge: '48px',
+    tabPaddingMediumSegment: '0 16px',
+    tabFontSizeMedium: 'var(--text-base)',
+  },
+
+  Switch: {
+    heightMedium: '28px',
+    widthMedium: '48px',
+  },
+
+  Checkbox: {
+    fontSizeMedium: 'var(--text-base)',
+  },
+
+  Radio: {
+    fontSizeMedium: 'var(--text-base)',
+  },
+
+  Dialog: {
+    borderRadius: '20px',
+    padding: 'var(--space-xl)',
+  },
+
+  Modal: {
+    borderRadius: '20px',
+  },
+
+  Pagination: {
+    itemSizeMedium: '40px',
+    itemMarginMedium: '6px',
+  },
+
+  Tooltip: {
+    padding: '10px 14px',
+    borderRadius: '10px',
+    fontSize: 'var(--text-sm)',
+  },
+}
diff --git a/src/router/guards/mobile-guard.ts b/src/router/guards/mobile-guard.ts
new file mode 100644
index 0000000..88b72c5
--- /dev/null
+++ b/src/router/guards/mobile-guard.ts
@@ -0,0 +1,94 @@
+import type { NavigationGuardNext, RouteLocationNormalized } from 'vue-router'
+
+/**
+ * 移动端设备检测函数
+ * 基于 User-Agent 与视口宽度做双重判定
+ * 注意：此检测在应用启动时执行一次，绝不监听 resize
+ */
+function detectMobile(): boolean {
+  const ua = navigator.userAgent.toLowerCase()
+  const isMobileUA = /iphone|ipad|ipod|android|webos| blackberry|iemobile|opera mini|mobile/.test(ua)
+  const isSmallScreen = window.innerWidth <= 768
+  return isMobileUA || isSmallScreen
+}
+
+/** 移动端环境判定结果（应用生命周期内恒定） */
+const IS_MOBILE = detectMobile()
+
+/**
+ * Web 端路由 → 移动端路由 映射表
+ * 仅包含已完成移动端适配的路由
+ */
+const MOBILE_ROUTE_MAP: Record<string, string> = {
+  '/': '/mobile/workspace',
+  '/workspace': '/mobile/workspace',
+  '/agent-team': '/mobile/agent-team',
+  '/agent-team/market': '/mobile/agent-team',
+  '/agent-team/management': '/mobile/agent-team',
+  '/dashboard': '/mobile/dashboard',
+}
+
+/**
+ * 移动端路由 → Web 端路由 反向映射表
+ * 用于桌面端设备访问 /mobile/* 时的物理重定向
+ */
+const WEB_ROUTE_MAP: Record<string, string> = {
+  '/mobile': '/',
+  '/mobile/workspace': '/workspace',
+  '/mobile/workspace/chat': '/workspace',
+  '/mobile/agent-team': '/agent-team',
+  '/mobile/dashboard': '/dashboard',
+  '/mobile/profile': '/',
+  '/mobile/fallback': '/',
+}
+
+/**
+ * 创建移动端路由守卫
+ * 注入到 router.beforeEach 链中，在 authGuard 之后执行
+ *
+ * 竞态防护：
+ * 1. 使用 replace: true 避免历史栈污染
+ * 2. 已处于 /mobile 路径时直接短路放行
+ * 3. 未适配路由统一降级到 /mobile/fallback
+ */
+export function createMobileGuard() {
+  return (
+    to: RouteLocationNormalized,
+    _from: RouteLocationNormalized,
+    next: NavigationGuardNext
+  ) => {
+    // ── 反向守卫：桌面端设备禁止进入 /mobile 域 ──
+    if (to.path.startsWith('/mobile') && !IS_MOBILE) {
+      const webPath = WEB_ROUTE_MAP[to.path]
+      if (webPath) {
+        next({ path: webPath, replace: true })
+        return
+      }
+      // 未映射的移动端路径 → 回首页
+      next({ path: '/', replace: true })
+      return
+    }
+
+    // 已处于移动端路由域且是移动端设备，直接放行
+    if (to.path.startsWith('/mobile')) {
+      next()
+      return
+    }
+
+    // 非移动端设备，放行 Web 端路由
+    if (!IS_MOBILE) {
+      next()
+      return
+    }
+
+    // 移动端设备：查找映射表
+    const mobilePath = MOBILE_ROUTE_MAP[to.path]
+    if (mobilePath) {
+      next({ path: mobilePath, replace: true })
+      return
+    }
+
+    // 未适配路由：优雅降级到 Fallback 容器
+    next({ path: '/mobile/fallback', query: { from: to.fullPath }, replace: true })
+  }
+}
diff --git a/src/router/index.ts b/src/router/index.ts
index 4c831da..c386521 100644
--- a/src/router/index.ts
+++ b/src/router/index.ts
@@ -1,12 +1,15 @@
 import { createRouter, createWebHistory } from 'vue-router'
 import { routes } from './routes'
+import { mobileRoutes } from './mobile-routes'
 import { useAuthStore } from '@/stores/auth'
+import { createMobileGuard } from './guards/mobile-guard'
 
 const router = createRouter({
   history: createWebHistory(import.meta.env.BASE_URL),
-  routes,
+  routes: [...routes, ...mobileRoutes],
 })
 
+// 认证守卫
 router.beforeEach(async (to, _from, next) => {
   const authStore = useAuthStore()
 
@@ -42,4 +45,7 @@ router.beforeEach(async (to, _from, next) => {
   next()
 })
 
+// 移动端分流守卫（在认证守卫之后执行）
+router.beforeEach(createMobileGuard())
+
 export default router
diff --git a/src/router/mobile-routes.ts b/src/router/mobile-routes.ts
new file mode 100644
index 0000000..6b7d28a
--- /dev/null
+++ b/src/router/mobile-routes.ts
@@ -0,0 +1,56 @@
+import type { RouteRecordRaw } from 'vue-router'
+import MobileLayout from '@/views/mobile/layout/MobileLayout.vue'
+
+/**
+ * 移动端专属路由表
+ * 所有路径以 /mobile 为前缀，与 Web 端物理隔离
+ */
+export const mobileRoutes: RouteRecordRaw[] = [
+  {
+    path: '/mobile',
+    component: MobileLayout,
+    meta: { public: true },
+    children: [
+      {
+        path: '',
+        redirect: '/mobile/workspace',
+      },
+      {
+        path: 'workspace',
+        name: 'MobileWorkspace',
+        component: () => import('@/views/mobile/pages/MobileWorkspacePage.vue'),
+        meta: { title: '工作台', showBack: false },
+      },
+      {
+        path: 'workspace/chat',
+        name: 'MobileWorkspaceChat',
+        component: () => import('@/views/mobile/pages/MobileChatView.vue'),
+        meta: { title: '对话', showBack: true, hideBottomBar: true, chatMode: true },
+      },
+      {
+        path: 'agent-team',
+        name: 'MobileAgentTeam',
+        component: () => import('@/views/mobile/pages/MobileAgentTeamPage.vue'),
+        meta: { title: '数字员工', showBack: false },
+      },
+      {
+        path: 'dashboard',
+        name: 'MobileDashboard',
+        component: () => import('@/views/mobile/pages/MobileDashboardPage.vue'),
+        meta: { title: '数据看板', showBack: false },
+      },
+      {
+        path: 'profile',
+        name: 'MobileProfile',
+        component: () => import('@/views/mobile/pages/MobileProfilePage.vue'),
+        meta: { title: '我的', showBack: false },
+      },
+      {
+        path: 'fallback',
+        name: 'MobileFallback',
+        component: () => import('@/views/mobile/pages/MobileFallbackPage.vue'),
+        meta: { title: '页面适配中', hideBottomBar: true },
+      },
+    ],
+  },
+]
diff --git a/src/stores/workspace.ts b/src/stores/workspace.ts
index 22aaa07..61e8e76 100644
--- a/src/stores/workspace.ts
+++ b/src/stores/workspace.ts
@@ -1217,6 +1217,18 @@ export const useWorkspaceStore = defineStore('workspace', () => {
   }
 
   async function selectSession(sessionKey: string) {
+    // ── 存在性前置校验：阻断幽灵会话污染 activeSessionKey ──
+    if (sessionKey !== '') {
+      const exists = agents.value.some((a) => a.sessions.some((s) => s.key === sessionKey))
+      if (!exists) {
+        lastError.value = '会话已失效或已被删除'
+        if (activeSessionKey.value === sessionKey) {
+          activeSessionKey.value = ''
+        }
+        return
+      }
+    }
+
     activeSessionKey.value = sessionKey
     // 清除该会话的未读状态
     const newUnread = new Map(unreadMap.value)
@@ -1340,7 +1352,13 @@ export const useWorkspaceStore = defineStore('workspace', () => {
       }
     } catch (error) {
       if (!controller.signal.aborted) {
-        lastError.value = error instanceof Error ? error.message : String(error)
+        const errMsg = error instanceof Error ? error.message : String(error)
+        lastError.value = errMsg
+        // 幽灵会话熔断：若服务端返回会话不存在，强制归零状态
+        if (errMsg.includes('not found') || errMsg.includes('不存在') || errMsg.includes('No such session')) {
+          activeSessionKey.value = ''
+          setSessionMessages(sessionKey, [])
+        }
       }
     } finally {
       abortControllers.delete(sessionKey)
@@ -1431,13 +1449,20 @@ export const useWorkspaceStore = defineStore('workspace', () => {
     const text = content.trim()
     if (!text) return
 
-    sending.value = true
-
+    // ── 发送前幂等锁：校验当前会话是否存在，若不存在自动降级为新会话 ──
     if (!activeSessionKey.value) {
       const agentId = selectedAgentId.value || 'main'
       startNewChat(agentId)
+    } else {
+      const exists = agents.value.some((a) => a.sessions.some((s) => s.key === activeSessionKey.value))
+      if (!exists) {
+        const agentId = selectedAgentId.value || 'main'
+        startNewChat(agentId)
+      }
     }
 
+    sending.value = true
+
     const sessionKey = activeSessionKey.value!
     const nowIso = new Date().toISOString()
     const nowMs = Date.now()
@@ -2077,6 +2102,29 @@ export const useWorkspaceStore = defineStore('workspace', () => {
     const payloadStopReason = payloadRow?.stopReason as string | undefined
     const hasPayloadStop = payloadStopReason === 'stop' || payloadStopReason === 'endTurn' || payloadStopReason === 'end_turn'
 
+    // ── Session lifecycle: remote delete cascade purge ──
+    if (normalizedEvent === 'session.delete' || normalizedEvent === 'sessions.delete') {
+      const deletedKey = keyInEvent || (payloadRow?.key as string | undefined) || (payloadRow?.sessionKey as string | undefined)
+      if (deletedKey) {
+        if (activeSessionKey.value === deletedKey) {
+          activeSessionKey.value = ''
+          sending.value = false
+          activeStreamId.value = null
+        }
+        const controller = abortControllers.get(deletedKey)
+        if (controller) {
+          controller.abort()
+          abortControllers.delete(deletedKey)
+        }
+        streamStates.delete(deletedKey)
+        activeThinkingIds.delete(deletedKey)
+        activeToolIds.delete(deletedKey)
+        activeCmdIds.delete(deletedKey)
+        setSessionMessages(deletedKey, [])
+      }
+      return
+    }
+
     // ── Agent events (activity streams + lifecycle) ──
     let isAgentDone = false
     const { isAgentDone: rtAgentDone, shouldContinue } = handleRealtimeEvent(normalizedEvent, payloadRow, targetKey)
diff --git a/src/views/mobile/components/MobileFilePicker.vue b/src/views/mobile/components/MobileFilePicker.vue
new file mode 100644
index 0000000..bea79bf
--- /dev/null
+++ b/src/views/mobile/components/MobileFilePicker.vue
@@ -0,0 +1,173 @@
+<script setup lang="ts">
+import { ref } from 'vue'
+
+export interface PickedFile {
+  name: string
+  size: number
+  blobUrl: string
+}
+
+const props = defineProps<{
+  modelValue?: PickedFile[]
+}>()
+
+const emit = defineEmits<{
+  (e: 'update:modelValue', files: PickedFile[]): void
+}>()
+
+const inputRef = ref<HTMLInputElement | null>(null)
+
+function handleClick() {
+  inputRef.value?.click()
+}
+
+function handleFileChange(e: Event) {
+  const target = e.target as HTMLInputElement
+  const fileList = target.files
+  if (!fileList || fileList.length === 0) return
+
+  const existing = props.modelValue ?? []
+  const added: PickedFile[] = []
+
+  for (const file of Array.from(fileList)) {
+    added.push({
+      name: file.name,
+      size: file.size,
+      blobUrl: URL.createObjectURL(file),
+    })
+  }
+
+  emit('update:modelValue', [...existing, ...added])
+  target.value = ''
+}
+
+function removeFile(index: number) {
+  const next = [...(props.modelValue ?? [])]
+  const removed = next.splice(index, 1)
+  if (removed[0]?.blobUrl) {
+    URL.revokeObjectURL(removed[0].blobUrl)
+  }
+  emit('update:modelValue', next)
+}
+</script>
+
+<template>
+  <div class="mobile-file-picker">
+    <button
+      class="attach-btn"
+      type="button"
+      aria-label="选择附件"
+      @click="handleClick"
+    >
+      <span class="material-symbols-outlined">attach_file</span>
+    </button>
+
+    <input
+      ref="inputRef"
+      type="file"
+      multiple
+      class="file-input-hidden"
+      @change="handleFileChange"
+    />
+
+    <div v-if="modelValue?.length" class="file-chip-list">
+      <div
+        v-for="(file, idx) in modelValue"
+        :key="file.blobUrl + idx"
+        class="file-chip"
+      >
+        <span class="file-chip-name">{{ file.name }}</span>
+        <button
+          class="file-chip-remove"
+          type="button"
+          aria-label="移除附件"
+          @click.stop="removeFile(idx)"
+        >
+          <span class="material-symbols-outlined">close</span>
+        </button>
+      </div>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.mobile-file-picker {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-xs);
+}
+
+.attach-btn {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  width: 44px;
+  height: 44px;
+  border: none;
+  background: transparent;
+  color: var(--text-muted);
+  cursor: pointer;
+  border-radius: var(--radius-md);
+  flex-shrink: 0;
+}
+
+.attach-btn:active {
+  background-color: var(--bg-hover);
+}
+
+.attach-btn .material-symbols-outlined {
+  font-size: var(--text-xl);
+}
+
+.file-input-hidden {
+  position: absolute;
+  width: 1px;
+  height: 1px;
+  opacity: 0;
+  pointer-events: none;
+}
+
+.file-chip-list {
+  display: flex;
+  flex-wrap: wrap;
+  gap: var(--space-xs);
+}
+
+.file-chip {
+  display: inline-flex;
+  align-items: center;
+  gap: var(--space-3xs);
+  padding: 4px 8px;
+  background: var(--bg-surface, #fafafa);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-md);
+  font-size: var(--text-xs);
+  color: var(--text);
+  max-width: 100%;
+}
+
+.file-chip-name {
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+  max-width: 120px;
+}
+
+.file-chip-remove {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  width: 20px;
+  height: 20px;
+  border: none;
+  background: transparent;
+  color: var(--text-muted);
+  cursor: pointer;
+  border-radius: var(--radius-sm);
+  padding: 0;
+}
+
+.file-chip-remove .material-symbols-outlined {
+  font-size: var(--text-xs);
+}
+</style>
diff --git a/src/views/mobile/components/MobileMessageContextMenu.vue b/src/views/mobile/components/MobileMessageContextMenu.vue
new file mode 100644
index 0000000..9bcc82e
--- /dev/null
+++ b/src/views/mobile/components/MobileMessageContextMenu.vue
@@ -0,0 +1,134 @@
+<script setup lang="ts">
+import { computed } from 'vue'
+
+export interface MenuOption {
+  label: string
+  value: string
+  icon?: string
+}
+
+const props = defineProps<{
+  show: boolean
+  x: number
+  y: number
+  options: MenuOption[]
+}>()
+
+const emit = defineEmits<{
+  (e: 'select', value: string): void
+  (e: 'update:show', value: boolean): void
+  (e: 'close'): void
+}>()
+
+function closeMenu() {
+  emit('update:show', false)
+  emit('close')
+}
+
+function handleSelect(value: string) {
+  emit('select', value)
+  closeMenu()
+}
+
+function handleOverlayClick() {
+  closeMenu()
+}
+
+const adjustedStyle = computed(() => {
+  // Keep menu within safe bounds (assume viewport at least 320x480)
+  const menuWidth = 160
+  const menuHeight = props.options.length * 48 + 16
+  let left = props.x
+  let top = props.y
+  if (typeof window !== 'undefined') {
+    left = Math.min(left, window.innerWidth - menuWidth - 16)
+    top = Math.min(top, window.innerHeight - menuHeight - 16)
+  }
+  return {
+    left: `${left}px`,
+    top: `${top}px`,
+  }
+})
+</script>
+
+<template>
+  <teleport to="body">
+    <!-- Overlay: captures clicks to dismiss -->
+    <div
+      v-if="show"
+      class="menu-overlay"
+      @click="handleOverlayClick"
+    />
+    <!-- Menu panel -->
+    <div
+      v-if="show"
+      class="menu-panel"
+      :style="adjustedStyle"
+    >
+      <button
+        v-for="opt in options"
+        :key="opt.value"
+        class="menu-item"
+        @click.stop="handleSelect(opt.value)"
+      >
+        <span v-if="opt.icon" class="material-symbols-outlined menu-icon">{{ opt.icon }}</span>
+        <span class="menu-label">{{ opt.label }}</span>
+      </button>
+    </div>
+  </teleport>
+</template>
+
+<style scoped>
+.menu-overlay {
+  position: fixed;
+  inset: 0;
+  z-index: 900;
+  background: rgba(0, 0, 0, 0.25);
+  pointer-events: auto;
+}
+
+.menu-panel {
+  position: fixed;
+  z-index: 901;
+  min-width: 160px;
+  background: var(--bg-card, #fff);
+  border-radius: var(--radius-lg);
+  box-shadow: var(--shadow-lg);
+  padding: var(--space-xs) 0;
+  display: flex;
+  flex-direction: column;
+  overflow: hidden;
+}
+
+.menu-item {
+  display: flex;
+  align-items: center;
+  gap: var(--space-sm);
+  padding: 0 var(--space-md);
+  min-height: 44px;
+  border: none;
+  background: transparent;
+  color: var(--text);
+  font-size: var(--text-base);
+  text-align: left;
+  cursor: pointer;
+  transition: background-color 0.12s ease;
+}
+
+.menu-item:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.menu-icon {
+  font-size: var(--text-lg);
+  color: var(--text-muted);
+  flex-shrink: 0;
+}
+
+.menu-label {
+  flex: 1;
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+}
+</style>
diff --git a/src/views/mobile/components/MobileToolGroupCard.vue b/src/views/mobile/components/MobileToolGroupCard.vue
new file mode 100644
index 0000000..5a62c56
--- /dev/null
+++ b/src/views/mobile/components/MobileToolGroupCard.vue
@@ -0,0 +1,303 @@
+<script setup lang="ts">
+import { ref, computed } from 'vue'
+import type { AgentActivity } from '@/api/types'
+import { useI18n } from 'vue-i18n'
+
+const { t } = useI18n()
+
+const props = defineProps<{
+  tools: AgentActivity[]
+  isActive: boolean
+}>()
+
+const expanded = ref(false)
+
+const toolCount = computed(() => props.tools.length)
+
+const hasTool = computed(() => props.tools.some((t) => t.type === 'tool'))
+const hasCommand = computed(() => props.tools.some((t) => t.type === 'command_output'))
+
+const groupTitle = computed(() => {
+  if (hasCommand.value && !hasTool.value) return '命令输出'
+  return t('pages.workspace.chat.toolGroupTitle')
+})
+
+const statusText = computed(() => {
+  if (props.isActive) return t('pages.workspace.chat.toolGroupRunning')
+  return t('pages.workspace.chat.toolGroupDone')
+})
+
+const expandedTools = ref(new Set<string>())
+
+function toggleTool(id: string) {
+  const s = new Set(expandedTools.value)
+  if (s.has(id)) s.delete(id)
+  else s.add(id)
+  expandedTools.value = s
+}
+
+function truncateJson(raw: string | null | undefined, max = 300): string {
+  if (!raw) return ''
+  return raw.length > max ? raw.slice(0, max) + '...' : raw
+}
+</script>
+
+<template>
+  <div
+    class="tool-group-card"
+    :class="{ 'is-active': isActive }"
+  >
+    <!-- Header: fixed 60px height, no dynamic JS sizing -->
+    <div
+      class="tool-group-header"
+      @click="expanded = !expanded"
+    >
+      <span class="tool-group-arrow">{{ expanded ? '▼' : '▶' }}</span>
+      <span class="tool-group-icon">🔧</span>
+      <span class="tool-group-title">{{ groupTitle }}</span>
+      <span class="tool-group-count">{{ toolCount }}</span>
+      <span v-if="isActive" class="streaming-pulse" />
+      <span class="tool-group-status" :class="{ active: isActive }">
+        {{ statusText }}
+      </span>
+    </div>
+
+    <!-- Body: fully removed from DOM when collapsed -->
+    <div v-if="expanded" class="tool-group-body">
+      <template v-if="tools.length">
+        <div
+          v-for="tool in tools"
+          :key="tool.id"
+          class="tool-group-item"
+        >
+          <template v-if="tool.type === 'tool'">
+            <div class="tool-item-header" @click.stop="toggleTool(tool.id)">
+              <span class="tool-item-icon">🔧</span>
+              <span class="tool-item-name">{{ tool.toolName || 'tool' }}</span>
+              <span v-if="tool.done" class="tool-item-done">✓</span>
+              <span v-else class="streaming-pulse" />
+              <span class="tool-item-toggle">
+                {{ expandedTools.has(tool.id) ? '▼' : '▶' }}
+              </span>
+            </div>
+            <div v-if="expandedTools.has(tool.id)" class="tool-item-detail">
+              <div v-if="tool.toolArgs" class="activity-section">
+                <div class="activity-section-label">
+                  ▸ {{ t('pages.workspace.chat.arguments') }}
+                </div>
+                <pre class="activity-pre">{{ truncateJson(tool.toolArgs) }}</pre>
+              </div>
+              <div v-if="tool.toolPartial" class="activity-section">
+                <div class="activity-section-label">▸ Partial</div>
+                <pre class="activity-pre">{{ truncateJson(tool.toolPartial) }}</pre>
+              </div>
+              <div
+                v-if="tool.toolResult"
+                class="activity-section"
+                :class="{ 'is-error': tool.toolIsError }"
+              >
+                <div class="activity-section-label">
+                  ▸ {{ t('pages.workspace.chat.result') }}
+                </div>
+                <pre class="activity-pre">{{ truncateJson(tool.toolResult) }}</pre>
+              </div>
+            </div>
+          </template>
+
+          <template v-else-if="tool.type === 'command_output'">
+            <div class="tool-item-header" @click.stop="toggleTool(tool.id)">
+              <span class="tool-item-icon">⬛</span>
+              <span class="tool-item-name">stdout/stderr</span>
+              <span v-if="tool.done" class="tool-item-done">✓</span>
+              <span v-else class="streaming-pulse" />
+              <span class="tool-item-toggle">
+                {{ expandedTools.has(tool.id) ? '▼' : '▶' }}
+              </span>
+            </div>
+            <div v-if="expandedTools.has(tool.id) && tool.output" class="tool-item-detail">
+              <pre class="activity-pre">{{ tool.output }}</pre>
+            </div>
+          </template>
+        </div>
+      </template>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.tool-group-card {
+  border: 1px solid var(--border-color, rgba(0, 0, 0, 0.08));
+  border-radius: var(--radius-lg);
+  overflow: hidden;
+  background: var(--bg-surface, #fafafa);
+
+  /* Reflow isolation: paint + layout + style containment */
+  contain: layout style paint;
+  /* Skip off-screen rendering */
+  content-visibility: auto;
+  contain-intrinsic-size: 0 60px;
+}
+
+[data-theme='dark'] .tool-group-card {
+  border-color: rgba(255, 255, 255, 0.08);
+}
+
+.tool-group-card.is-active {
+  border-color: var(--accent-bg-strong, rgba(91, 124, 250, 0.25));
+  background: var(--accent-bg, rgba(91, 124, 250, 0.06));
+}
+
+.tool-group-header {
+  display: flex;
+  align-items: center;
+  gap: var(--space-sm);
+  padding: 0 var(--space-md);
+  min-height: 60px;
+  max-height: 60px;
+  cursor: pointer;
+  user-select: none;
+  font-size: var(--text-sm);
+  background: var(--bg-surface, #f5f5f5);
+  transition: background 0.15s;
+}
+
+.tool-group-card.is-active .tool-group-header {
+  background: var(--accent-bg, rgba(91, 124, 250, 0.08));
+}
+
+.tool-group-arrow {
+  font-size: var(--text-xs);
+  color: var(--text-muted);
+  transition: transform 0.2s;
+}
+
+.tool-group-icon {
+  font-size: var(--text-sm);
+}
+
+.tool-group-title {
+  font-weight: 500;
+  color: var(--text);
+}
+
+.tool-group-count {
+  background: var(--border-color, rgba(0, 0, 0, 0.08));
+  color: var(--text-muted);
+  font-size: var(--text-2xs);
+  padding: 2px 8px;
+  border-radius: 10px;
+  font-weight: 500;
+}
+
+.tool-group-status {
+  font-size: var(--text-2xs);
+  color: var(--text-muted);
+  margin-left: auto;
+}
+
+.tool-group-status.active {
+  color: var(--accent, #5b7cfa);
+}
+
+.tool-group-body {
+  border-top: 1px solid var(--border-color, rgba(0, 0, 0, 0.06));
+  padding: 2px 0;
+}
+
+[data-theme='dark'] .tool-group-body {
+  border-top-color: rgba(255, 255, 255, 0.06);
+}
+
+.tool-group-item + .tool-group-item {
+  border-top: 1px dashed var(--border-color, rgba(0, 0, 0, 0.04));
+}
+
+.tool-item-header {
+  display: flex;
+  align-items: center;
+  gap: 6px;
+  padding: 8px var(--space-md);
+  font-size: var(--text-xs);
+  cursor: pointer;
+  transition: background 0.1s;
+}
+
+.tool-item-header:active {
+  background: var(--bg-hover, rgba(0, 0, 0, 0.03));
+}
+
+.tool-item-icon {
+  font-size: var(--text-xs);
+  flex-shrink: 0;
+}
+
+.tool-item-name {
+  font-family: 'SF Mono', ui-monospace, monospace;
+  color: var(--text);
+  flex: 1;
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+}
+
+.tool-item-done {
+  color: #22c55e;
+  font-size: var(--text-xs);
+}
+
+.tool-item-toggle {
+  font-size: var(--text-2xs);
+  color: var(--text-muted);
+  margin-left: auto;
+}
+
+.tool-item-detail {
+  padding: 0 var(--space-md) var(--space-sm);
+}
+
+.activity-section {
+  margin-top: var(--space-xs);
+}
+
+.activity-section.is-error .activity-section-label {
+  color: #ef4444;
+}
+
+.activity-section-label {
+  font-size: var(--text-2xs);
+  color: var(--text-muted);
+  margin-bottom: 2px;
+}
+
+.activity-pre {
+  margin: 0;
+  padding: var(--space-sm);
+  background: var(--bg-code, #f3f4f6);
+  border-radius: var(--radius-sm);
+  font-size: var(--text-2xs);
+  line-height: var(--leading-snug);
+  overflow-x: auto;
+  white-space: pre-wrap;
+  word-break: break-word;
+}
+
+@keyframes pulse-dot {
+  0%, 80%, 100% {
+    opacity: 0.3;
+    transform: scale(0.6);
+  }
+  40% {
+    opacity: 1;
+    transform: scale(1);
+  }
+}
+
+.streaming-pulse {
+  display: inline-block;
+  width: 6px;
+  height: 6px;
+  border-radius: 50%;
+  background-color: var(--accent, #5b7cfa);
+  animation: pulse-dot 1.4s infinite ease-in-out both;
+}
+</style>
diff --git a/src/views/mobile/layout/MobileBottomBar.vue b/src/views/mobile/layout/MobileBottomBar.vue
new file mode 100644
index 0000000..36a88a1
--- /dev/null
+++ b/src/views/mobile/layout/MobileBottomBar.vue
@@ -0,0 +1,107 @@
+<script setup lang="ts">
+import { computed } from 'vue'
+import { useRoute, useRouter } from 'vue-router'
+
+interface NavItem {
+  name: string
+  path: string
+  icon: string
+  label: string
+}
+
+const route = useRoute()
+const router = useRouter()
+
+const navItems = computed<NavItem[]>(() => [
+  { name: 'MobileWorkspace', path: '/mobile/workspace', icon: 'chat_bubble', label: '工作台' },
+  { name: 'MobileAgentTeam', path: '/mobile/agent-team', icon: 'smart_toy', label: '员工' },
+  { name: 'MobileDashboard', path: '/mobile/dashboard', icon: 'insights', label: '数据' },
+  { name: 'MobileProfile', path: '/mobile/profile', icon: 'person', label: '我的' },
+])
+
+const activeKey = computed(() => {
+  const matched = navItems.value.find((item) => route.path.startsWith(item.path))
+  return matched?.name || ''
+})
+
+function handleNav(item: NavItem) {
+  if (route.path !== item.path) {
+    router.replace({ path: item.path })
+  }
+}
+</script>
+
+<template>
+  <nav class="mobile-bottom-nav safe-inset-x">
+    <button
+      v-for="item in navItems"
+      :key="item.name"
+      class="bottom-nav-item"
+      :class="{ active: activeKey === item.name }"
+      :aria-label="item.label"
+      @click="handleNav(item)"
+    >
+      <span
+        class="material-symbols-outlined nav-icon"
+        :class="{ active: activeKey === item.name }"
+      >
+        {{ item.icon }}
+      </span>
+      <span class="nav-label">{{ item.label }}</span>
+    </button>
+  </nav>
+</template>
+
+<style scoped>
+.mobile-bottom-nav {
+  position: fixed;
+  bottom: 0;
+  left: 0;
+  right: 0;
+  z-index: var(--z-bottom-bar, 100);
+  display: flex;
+  align-items: stretch;
+  justify-content: space-around;
+  height: calc(var(--mobile-bottom-bar-height) + var(--safe-bottom));
+  padding-bottom: var(--safe-bottom);
+  background-color: var(--bg-card, #fff);
+  border-top: 1px solid var(--border, #e0e0e0);
+  box-sizing: border-box;
+}
+
+.bottom-nav-item {
+  display: flex;
+  flex-direction: column;
+  align-items: center;
+  justify-content: center;
+  flex: 1;
+  min-width: 0;
+  gap: var(--space-3xs);
+  border: none;
+  background: transparent;
+  color: var(--text-muted, #5a6065);
+  cursor: pointer;
+  padding: var(--space-2xs) 0;
+  transition: color 0.15s ease;
+}
+
+.bottom-nav-item.active {
+  color: var(--accent, #435ba8);
+}
+
+.nav-icon {
+  font-size: var(--text-xl);
+  line-height: 1;
+  transition: color 0.15s ease;
+}
+
+.nav-icon.active {
+  font-variation-settings: 'FILL' 1;
+}
+
+.nav-label {
+  font-size: var(--text-2xs);
+  line-height: var(--leading-tight);
+  white-space: nowrap;
+}
+</style>
diff --git a/src/views/mobile/layout/MobileHeader.vue b/src/views/mobile/layout/MobileHeader.vue
new file mode 100644
index 0000000..82b1c6a
--- /dev/null
+++ b/src/views/mobile/layout/MobileHeader.vue
@@ -0,0 +1,114 @@
+<script setup lang="ts">
+import { useRouter } from 'vue-router'
+
+interface Props {
+  title: string
+  showBack?: boolean
+}
+
+withDefaults(defineProps<Props>(), {
+  showBack: true,
+})
+
+const router = useRouter()
+
+function handleBack() {
+  if (window.history.length > 1) {
+    router.back()
+  } else {
+    router.replace({ path: '/mobile/workspace' })
+  }
+}
+</script>
+
+<template>
+  <header class="mobile-header-bar">
+    <div class="mobile-header-inner safe-inset-x">
+      <button
+        v-if="showBack"
+        class="header-action-btn"
+        aria-label="返回"
+        @click="handleBack"
+      >
+        <span class="material-symbols-outlined">arrow_back</span>
+      </button>
+
+      <div class="header-title-wrapper">
+        <h1 class="header-title">{{ title }}</h1>
+      </div>
+
+      <!-- 右侧占位，保持标题居中 -->
+      <div v-if="showBack" class="header-spacer" />
+    </div>
+  </header>
+</template>
+
+<style scoped>
+.mobile-header-bar {
+  position: fixed;
+  top: 0;
+  left: 0;
+  right: 0;
+  z-index: var(--z-header, 100);
+  height: calc(var(--mobile-header-height) + var(--safe-top));
+  padding-top: var(--safe-top);
+  background-color: var(--bg-card, #fff);
+  border-bottom: 1px solid var(--border, #e0e0e0);
+  box-sizing: border-box;
+}
+
+.mobile-header-inner {
+  display: flex;
+  align-items: center;
+  justify-content: space-between;
+  height: var(--mobile-header-height);
+  padding: 0 var(--space-md);
+}
+
+.header-action-btn {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  width: var(--min-hit-target);
+  height: var(--min-hit-target);
+  border: none;
+  background: transparent;
+  color: var(--text, #2d3338);
+  cursor: pointer;
+  border-radius: var(--radius-md);
+  flex-shrink: 0;
+}
+
+.header-action-btn:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.header-action-btn .material-symbols-outlined {
+  font-size: var(--text-lg);
+}
+
+.header-title-wrapper {
+  flex: 1;
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  min-width: 0;
+  padding: 0 var(--space-sm);
+}
+
+.header-title {
+  margin: 0;
+  font-size: var(--text-lg);
+  font-weight: 600;
+  color: var(--text, #2d3338);
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+  line-height: var(--leading-tight);
+}
+
+.header-spacer {
+  width: var(--min-hit-target);
+  flex-shrink: 0;
+}
+</style>
diff --git a/src/views/mobile/layout/MobileLayout.vue b/src/views/mobile/layout/MobileLayout.vue
new file mode 100644
index 0000000..3e84114
--- /dev/null
+++ b/src/views/mobile/layout/MobileLayout.vue
@@ -0,0 +1,92 @@
+<script setup lang="ts">
+import { computed } from 'vue'
+import { useRoute } from 'vue-router'
+import { NConfigProvider } from 'naive-ui'
+import { mobileThemeOverrides } from '@/config/mobile-theme'
+import MobileHeader from './MobileHeader.vue'
+import MobileBottomBar from './MobileBottomBar.vue'
+
+import '@/assets/styles/mobile-tokens.css'
+import '@/assets/styles/mobile-safe-area.css'
+
+const route = useRoute()
+
+const pageTitle = computed(() => {
+  const titleKey = route.meta.titleKey as string | undefined
+  return titleKey || route.meta.title as string || ''
+})
+
+const showHeader = computed(() => route.meta.hideHeader !== true)
+const showBottomBar = computed(() => route.meta.hideBottomBar !== true)
+const isChatMode = computed(() => route.meta.chatMode === true)
+</script>
+
+<template>
+  <NConfigProvider :theme-overrides="mobileThemeOverrides">
+    <div class="mobile-layout-root">
+      <MobileHeader
+        v-if="showHeader"
+        :title="pageTitle"
+        :show-back="route.meta.showBack !== false"
+      />
+
+      <main
+        class="mobile-scope"
+        :class="{
+          'safe-area-screen': !isChatMode,
+          'chat-mode-screen': isChatMode,
+          'has-header': showHeader,
+          'has-bottom-bar': showBottomBar,
+        }"
+      >
+        <div class="mobile-content-area">
+          <RouterView />
+        </div>
+      </main>
+
+      <MobileBottomBar v-if="showBottomBar" />
+    </div>
+  </NConfigProvider>
+</template>
+
+<style scoped>
+.mobile-layout-root {
+  display: flex;
+  flex-direction: column;
+  width: 100%;
+  height: 100vh;
+  height: 100dvh;
+  background-color: var(--bg, #fff);
+  color: var(--text, #2d3338);
+  overflow: hidden;
+}
+
+.mobile-layout-root :deep(.mobile-scope) {
+  flex: 1;
+  display: flex;
+  flex-direction: column;
+  min-height: 0;
+}
+
+.mobile-layout-root :deep(.mobile-scope.has-header) {
+  padding-top: calc(var(--mobile-header-height) + var(--safe-top));
+}
+
+.mobile-layout-root :deep(.mobile-scope.has-bottom-bar) {
+  padding-bottom: calc(var(--mobile-bottom-bar-height) + var(--safe-bottom));
+}
+
+/* 聊天模式：去除垂直安全区 padding，交由内部组件自治 */
+.mobile-layout-root :deep(.mobile-scope.chat-mode-screen) {
+  padding-top: calc(var(--mobile-header-height) + var(--safe-top));
+  padding-bottom: 0;
+}
+
+.mobile-layout-root :deep(.mobile-content-area) {
+  flex: 1;
+  min-height: 0;
+  overflow-y: auto;
+  overflow-x: hidden;
+  -webkit-overflow-scrolling: touch;
+}
+</style>
diff --git a/src/views/mobile/pages/MobileAgentTeamPage.vue b/src/views/mobile/pages/MobileAgentTeamPage.vue
new file mode 100644
index 0000000..6b8b423
--- /dev/null
+++ b/src/views/mobile/pages/MobileAgentTeamPage.vue
@@ -0,0 +1,63 @@
+<script setup lang="ts">
+// TODO: 接入 agentTeamStore 的无头逻辑
+</script>
+
+<template>
+  <div class="mobile-agent-team">
+    <div class="page-header">
+      <h1 class="page-title">数字员工</h1>
+      <p class="page-desc">管理和调用您的 AI 员工</p>
+    </div>
+    <div class="placeholder-card">
+      <span class="material-symbols-outlined placeholder-icon">smart_toy</span>
+      <p class="placeholder-text">员工列表适配中...</p>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.mobile-agent-team {
+  padding: var(--space-md);
+}
+
+.page-header {
+  margin-bottom: var(--space-xl);
+  padding: var(--space-lg) 0;
+}
+
+.page-title {
+  font-size: var(--text-2xl);
+  font-weight: 700;
+  color: var(--text);
+  margin: 0 0 var(--space-xs);
+}
+
+.page-desc {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  margin: 0;
+}
+
+.placeholder-card {
+  display: flex;
+  flex-direction: column;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-md);
+  padding: var(--space-4xl) var(--space-xl);
+  background: var(--bg-card, #fff);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-lg);
+}
+
+.placeholder-icon {
+  font-size: var(--text-3xl);
+  color: var(--text-muted);
+}
+
+.placeholder-text {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  margin: 0;
+}
+</style>
diff --git a/src/views/mobile/pages/MobileChatView.vue b/src/views/mobile/pages/MobileChatView.vue
new file mode 100644
index 0000000..99968dd
--- /dev/null
+++ b/src/views/mobile/pages/MobileChatView.vue
@@ -0,0 +1,585 @@
+<script setup lang="ts">
+import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
+import { useRoute, useRouter } from 'vue-router'
+import { NInput, NButton } from 'naive-ui'
+import { useWorkspaceStore } from '@/stores/workspace'
+import { useLongPress } from '@/composables/useLongPress'
+import MarkdownRenderer from '@/views/workspace/components/MarkdownRenderer.vue'
+import MobileMessageContextMenu from '@/views/mobile/components/MobileMessageContextMenu.vue'
+import MobileToolGroupCard from '@/views/mobile/components/MobileToolGroupCard.vue'
+import MobileFilePicker from '@/views/mobile/components/MobileFilePicker.vue'
+import type { ChatMessage, MessageBlock, AgentActivity, TextBlock } from '@/api/types'
+
+const workspaceStore = useWorkspaceStore()
+const route = useRoute()
+const router = useRouter()
+
+/* ── 从路由 query 获取 sessionKey 并激活会话 ── */
+onMounted(() => {
+  const sessionKey = route.query.key as string | undefined
+  if (sessionKey && sessionKey !== workspaceStore.activeSessionKey) {
+    workspaceStore.selectSession(sessionKey)
+  }
+})
+
+/* ── 组件卸载：确定性级联清理 ── */
+onUnmounted(() => {
+  // 1. 100% 显式销毁未提交的 Blob URL，杜绝内存泄漏
+  for (const f of attachedFiles.value) {
+    URL.revokeObjectURL(f.blobUrl)
+  }
+  attachedFiles.value = []
+
+  // 2. 若存在正在进行的请求，强制熔断
+  if (workspaceStore.sending) {
+    workspaceStore.cancelCurrentRequest()
+  }
+
+  // 3. 重置移动端局部状态
+  displayCount.value = INITIAL_COUNT
+  menuShow.value = false
+  menuTargetMsg.value = null
+
+  // 4. 兜底：清空全局会话选择（防止直接关闭标签页或刷新导致的幽灵残留）
+  workspaceStore.selectSession('')
+})
+
+const listRef = ref<HTMLElement | null>(null)
+const inputText = ref('')
+const inputRef = ref<InstanceType<typeof NInput> | null>(null)
+
+/* ── 附件文件 ── */
+const attachedFiles = ref<Array<{ name: string; size: number; blobUrl: string }>>([])
+
+/* ── 长按菜单状态 ── */
+const menuShow = ref(false)
+const menuX = ref(0)
+const menuY = ref(0)
+const menuTargetMsg = ref<ChatMessage | null>(null)
+
+const menuOptions = computed(() => {
+  const opts = [{ label: '复制文本', value: 'copy', icon: 'content_copy' }]
+  if (menuTargetMsg.value?.role === 'user') {
+    opts.push({ label: '重新发送', value: 'retry', icon: 'refresh' })
+  }
+  return opts
+})
+
+function handleMenuSelect(value: string) {
+  const msg = menuTargetMsg.value
+  if (!msg) return
+  if (value === 'copy') {
+    const text = msg.content || ''
+    if (text && navigator.clipboard) {
+      navigator.clipboard.writeText(text).catch(() => {})
+    }
+  } else if (value === 'retry') {
+    workspaceStore.retryLastMessage()
+  }
+}
+
+/* ── 渐进式渲染防护（移动端降频） ── */
+const INITIAL_COUNT = 6
+const LOAD_MORE_COUNT = 3
+const displayCount = ref(INITIAL_COUNT)
+
+const allMessages = computed(() => workspaceStore.messages)
+
+const displayedMessages = computed(() => {
+  const msgs = allMessages.value
+  const start = Math.max(0, msgs.length - displayCount.value)
+  return msgs.slice(start)
+})
+
+const hasMore = computed(() => displayCount.value < allMessages.value.length)
+
+/* ── 滚动到底部（RAF 节流，无 setTimeout） ── */
+function scrollToBottom() {
+  if (!listRef.value) return
+  requestAnimationFrame(() => {
+    if (listRef.value) {
+      listRef.value.scrollTop = listRef.value.scrollHeight
+    }
+  })
+}
+
+/* ── 加载更多历史（节流 + 强制布局保护） ── */
+let _loadMoreLock = false
+
+function loadMore() {
+  if (_loadMoreLock || !hasMore.value || !listRef.value) return
+  _loadMoreLock = true
+
+  const el = listRef.value
+  const prevScrollTop = el.scrollTop
+
+  displayCount.value = Math.min(
+    displayCount.value + LOAD_MORE_COUNT,
+    allMessages.value.length
+  )
+
+  nextTick(() => {
+    requestAnimationFrame(() => {
+      if (el) {
+        el.scrollTop = prevScrollTop
+      }
+      _loadMoreLock = false
+    })
+  })
+}
+
+function handleScroll() {
+  if (!listRef.value) return
+  if (listRef.value.scrollTop <= 20) {
+    loadMore()
+  }
+}
+
+/* ── 发送消息 ── */
+const canSend = computed(() =>
+  inputText.value.trim().length > 0 && !workspaceStore.sending
+)
+
+async function handleSend() {
+  if (!canSend.value) return
+  const text = inputText.value.trim()
+  inputText.value = ''
+
+  const files = attachedFiles.value.map((f) => ({ name: f.name, size: f.size }))
+  // revoke blob URLs after sending
+  for (const f of attachedFiles.value) {
+    URL.revokeObjectURL(f.blobUrl)
+  }
+  attachedFiles.value = []
+
+  await workspaceStore.sendMessage(text, undefined, files)
+
+  nextTick(() => {
+    scrollToBottom()
+  })
+}
+
+/* ── 聚焦时滚动到底部（软键盘自愈） ── */
+function handleInputFocus() {
+  nextTick(() => {
+    scrollToBottom()
+  })
+}
+
+/* ── 返回会话列表 ── */
+function handleBack() {
+  workspaceStore.selectSession('')
+  router.replace({ path: '/mobile/workspace' })
+}
+
+/* ── 会话切换时重置渲染计数 ── */
+watch(
+  () => workspaceStore.activeSessionKey,
+  () => {
+    displayCount.value = INITIAL_COUNT
+    for (const f of attachedFiles.value) {
+      URL.revokeObjectURL(f.blobUrl)
+    }
+    attachedFiles.value = []
+    nextTick(() => {
+      scrollToBottom()
+    })
+  }
+)
+
+/* ── 新消息到达时自动滚动 ── */
+watch(
+  () => allMessages.value.length,
+  () => {
+    nextTick(() => {
+      scrollToBottom()
+    })
+  }
+)
+
+/* ── 消息角色判断 ── */
+function isUserMessage(msg: ChatMessage): boolean {
+  return msg.role === 'user'
+}
+
+/* ── 长按菜单 ── */
+function createLongPressHandlers(msg: ChatMessage) {
+  return useLongPress(
+    (e: TouchEvent) => {
+      const touch = e.touches[0] || e.changedTouches[0]
+      if (touch) {
+        menuX.value = touch.clientX
+        menuY.value = touch.clientY
+      }
+      menuTargetMsg.value = msg
+      menuShow.value = true
+    },
+    { thresholdMs: 400, moveThresholdPx: 10 }
+  )
+}
+
+/* ── Block 渲染（对齐桌面端 Ordered Blocks 架构） ── */
+function getMessageBlocks(msg: ChatMessage): MessageBlock[] {
+  const blocks = msg.blocks ?? []
+  return blocks.filter((b) => b.type !== 'text' || (b as TextBlock).content.trim().length > 0)
+}
+
+interface ToolGroupBlock {
+  type: 'tool_group'
+  tools: AgentActivity[]
+}
+
+type RenderBlock = MessageBlock | ToolGroupBlock
+
+function getRenderBlocks(msg: ChatMessage): RenderBlock[] {
+  const blocks = getMessageBlocks(msg)
+  const out: RenderBlock[] = []
+  let currentGroup: AgentActivity[] = []
+  for (const block of blocks) {
+    if (block.type === 'text') {
+      if (currentGroup.length > 0) {
+        out.push({ type: 'tool_group', tools: currentGroup })
+        currentGroup = []
+      }
+      out.push(block)
+    } else {
+      currentGroup.push(block as AgentActivity)
+    }
+  }
+  if (currentGroup.length > 0) {
+    out.push({ type: 'tool_group', tools: currentGroup })
+  }
+  return out
+}
+
+function blockKey(block: RenderBlock, idx: number): string {
+  if (block.type === 'text') return `text-${idx}`
+  if (block.type === 'tool_group') {
+    return block.tools[0]?.groupId || block.tools[0]?.id || `tg-${idx}`
+  }
+  return `block-${idx}`
+}
+
+function isLastAssistant(msg: ChatMessage): boolean {
+  const msgs = allMessages.value
+  if (msgs.length === 0) return false
+  const last = msgs[msgs.length - 1]
+  return last?.role === 'assistant' && last?.id === msg.id
+}
+</script>
+
+<template>
+  <div class="mobile-chat-view" :class="{ 'menu-active': menuShow }">
+    <!-- 会话标题栏 -->
+    <div class="chat-header-bar safe-inset-x">
+      <button class="chat-back-btn" @click="handleBack">
+        <span class="material-symbols-outlined">arrow_back</span>
+      </button>
+      <span class="chat-session-title">
+        {{ workspaceStore.activeSession?.label || '新会话' }}
+      </span>
+      <div class="chat-header-spacer" />
+    </div>
+
+    <!-- 消息列表（性能防护全量注入） -->
+    <div
+      ref="listRef"
+      class="message-list"
+      @scroll="handleScroll"
+    >
+      <div v-if="hasMore" class="load-more-hint">
+        <span class="load-more-text">上滑加载更多</span>
+      </div>
+
+      <div
+        v-for="(msg, idx) in displayedMessages"
+        :key="msg.id || msg.timestamp || idx"
+        class="message-bubble-wrapper"
+        :class="{ 'is-user': isUserMessage(msg) }"
+        v-bind="createLongPressHandlers(msg).handlers"
+      >
+        <div
+          class="message-bubble"
+          :class="{ 'is-user': isUserMessage(msg) }"
+        >
+          <!-- User message -->
+          <span v-if="isUserMessage(msg)" class="user-text">{{ msg.content }}</span>
+
+          <!-- Assistant message with ordered blocks -->
+          <template v-else-if="msg.blocks && msg.blocks.length > 0">
+            <template v-for="(block, bIdx) in getRenderBlocks(msg)" :key="blockKey(block, bIdx)">
+              <MobileToolGroupCard
+                v-if="block.type === 'tool_group'"
+                :tools="block.tools"
+                :is-active="block.tools.some((a) => !a.done)"
+              />
+              <MarkdownRenderer
+                v-else-if="block.type === 'text'"
+                :content="(block as TextBlock).content"
+                :streaming="isLastAssistant(msg)"
+              />
+            </template>
+          </template>
+
+          <!-- Fallback: plain markdown -->
+          <MarkdownRenderer
+            v-else
+            :content="msg.content || ''"
+            :streaming="isLastAssistant(msg)"
+          />
+        </div>
+      </div>
+
+      <!-- 思考中 / 发送中指示器 -->
+      <div v-if="workspaceStore.sending" class="typing-indicator">
+        <span class="dot" />
+        <span class="dot" />
+        <span class="dot" />
+      </div>
+    </div>
+
+    <!-- 底部输入区（Flex 轨道末尾，软键盘上推） -->
+    <div class="chat-input-area safe-inset-x">
+      <MobileFilePicker v-model="attachedFiles" />
+      <div class="chat-input-inner">
+        <NInput
+          ref="inputRef"
+          v-model:value="inputText"
+          type="textarea"
+          :autosize="{ minRows: 1, maxRows: 4 }"
+          placeholder="输入消息..."
+          class="chat-textarea"
+          @focus="handleInputFocus"
+          @keyup.enter.prevent="handleSend"
+        />
+        <NButton
+          type="primary"
+          circle
+          class="chat-send-btn"
+          :disabled="!canSend"
+          @click="handleSend"
+        >
+          <span class="material-symbols-outlined">send</span>
+        </NButton>
+      </div>
+    </div>
+
+    <!-- 长按上下文菜单 -->
+    <MobileMessageContextMenu
+      v-model:show="menuShow"
+      :x="menuX"
+      :y="menuY"
+      :options="menuOptions"
+      @select="handleMenuSelect"
+    />
+  </div>
+</template>
+
+<style scoped>
+/* ── 聊天视图根容器 ── */
+.mobile-chat-view {
+  display: flex;
+  flex-direction: column;
+  height: 100%;
+  min-height: 0;
+  background-color: var(--bg, #fff);
+}
+
+/* 菜单激活时阻断背景交互 */
+.mobile-chat-view.menu-active .message-list,
+.mobile-chat-view.menu-active .chat-input-area,
+.mobile-chat-view.menu-active .chat-header-bar {
+  pointer-events: none;
+}
+
+/* ── 会话标题栏 ── */
+.chat-header-bar {
+  display: flex;
+  align-items: center;
+  justify-content: space-between;
+  height: 48px;
+  padding: 0 var(--space-md);
+  border-bottom: 1px solid var(--border, #e0e0e0);
+  background-color: var(--bg-card, #fff);
+  flex-shrink: 0;
+}
+
+.chat-back-btn {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  width: var(--min-hit-target);
+  height: var(--min-hit-target);
+  border: none;
+  background: transparent;
+  color: var(--text);
+  cursor: pointer;
+  border-radius: var(--radius-md);
+}
+
+.chat-back-btn:active {
+  background-color: var(--bg-hover);
+}
+
+.chat-session-title {
+  font-size: var(--text-base);
+  font-weight: 600;
+  color: var(--text);
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+  max-width: 60vw;
+}
+
+.chat-header-spacer {
+  width: var(--min-hit-target);
+}
+
+/* ── 消息列表（性能防护层） ── */
+.message-list {
+  flex: 1;
+  min-height: 0;
+  overflow-y: auto;
+  overflow-x: hidden;
+  -webkit-overflow-scrolling: touch;
+
+  /* 阻断 iOS 橡皮筋回弹导致的布局拉扯 */
+  overscroll-behavior-y: contain;
+
+  padding: var(--space-md);
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-md);
+}
+
+/* ── 加载更多提示 ── */
+.load-more-hint {
+  text-align: center;
+  padding: var(--space-sm) 0;
+}
+
+.load-more-text {
+  font-size: var(--text-xs);
+  color: var(--text-muted);
+}
+
+/* ── 消息气泡包装器 ── */
+.message-bubble-wrapper {
+  display: flex;
+  width: 100%;
+  content-visibility: auto;
+  contain-intrinsic-size: 0 80px;
+}
+
+.message-bubble-wrapper.is-user {
+  justify-content: flex-end;
+}
+
+/* ── 消息气泡本体 ── */
+.message-bubble {
+  max-width: 85%;
+  padding: var(--space-sm) var(--space-md);
+  border-radius: var(--radius-lg);
+  background-color: var(--bg-surface, #fafafa);
+  color: var(--text);
+  font-size: var(--text-base);
+  line-height: var(--leading-normal);
+  word-break: break-word;
+
+  /* 提升为独立合成层，滚动仅发生在合成器线程 */
+  will-change: transform;
+}
+
+.message-bubble.is-user {
+  background-color: var(--accent, #435ba8);
+  color: #fff;
+  border-bottom-right-radius: var(--radius-sm);
+}
+
+.message-bubble:not(.is-user) {
+  border-bottom-left-radius: var(--radius-sm);
+}
+
+.user-text {
+  white-space: pre-wrap;
+  word-break: break-word;
+}
+
+/* ── 打字指示器 ── */
+.typing-indicator {
+  display: flex;
+  align-items: center;
+  gap: 4px;
+  padding: var(--space-sm) var(--space-md);
+  width: fit-content;
+}
+
+.dot {
+  width: 6px;
+  height: 6px;
+  border-radius: 50%;
+  background-color: var(--text-muted);
+  animation: pulse 1.4s infinite ease-in-out both;
+}
+
+.dot:nth-child(1) {
+  animation-delay: -0.32s;
+}
+
+.dot:nth-child(2) {
+  animation-delay: -0.16s;
+}
+
+@keyframes pulse {
+  0%, 80%, 100% {
+    transform: scale(0);
+    opacity: 0.5;
+  }
+  40% {
+    transform: scale(1);
+    opacity: 1;
+  }
+}
+
+/* ── 底部输入区 ── */
+.chat-input-area {
+  flex-shrink: 0;
+  padding: var(--space-sm) var(--space-md);
+  padding-bottom: max(var(--safe-bottom), var(--space-sm));
+  background-color: var(--bg-card, #fff);
+  border-top: 1px solid var(--border, #e0e0e0);
+}
+
+.chat-input-inner {
+  display: flex;
+  align-items: flex-end;
+  gap: var(--space-sm);
+}
+
+.chat-textarea {
+  flex: 1;
+}
+
+.chat-textarea :deep(.n-input__textarea-el) {
+  font-size: var(--text-base) !important;
+  line-height: var(--leading-normal);
+  min-height: 44px;
+  max-height: 120px;
+}
+
+.chat-send-btn {
+  width: 44px;
+  height: 44px;
+  flex-shrink: 0;
+}
+
+.chat-send-btn :deep(.n-button__content) {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+}
+
+.chat-send-btn .material-symbols-outlined {
+  font-size: var(--text-lg);
+}
+</style>
diff --git a/src/views/mobile/pages/MobileDashboardPage.vue b/src/views/mobile/pages/MobileDashboardPage.vue
new file mode 100644
index 0000000..abc26fb
--- /dev/null
+++ b/src/views/mobile/pages/MobileDashboardPage.vue
@@ -0,0 +1,181 @@
+<script setup lang="ts">
+import { ref, computed, onMounted } from 'vue'
+import { useWebSocketStore } from '@/stores/websocket'
+import { useSessionStore } from '@/stores/session'
+import { useWorkspaceStore } from '@/stores/workspace'
+import type { SessionsUsageResult } from '@/api/types'
+
+const wsStore = useWebSocketStore()
+const sessionStore = useSessionStore()
+const workspaceStore = useWorkspaceStore()
+
+const usageResult = ref<SessionsUsageResult | null>(null)
+const loading = ref(false)
+
+const todayTokens = computed(() => {
+  if (usageResult.value?.totals) {
+    return usageResult.value.totals.totalTokens
+  }
+  // Fallback: sum from local session store
+  return sessionStore.sessions.reduce(
+    (sum, s) => sum + (s.tokenUsage?.totalInput || 0) + (s.tokenUsage?.totalOutput || 0),
+    0
+  )
+})
+
+const sessionCount = computed(() => {
+  if (usageResult.value?.sessions) {
+    return usageResult.value.sessions.length
+  }
+  return sessionStore.sessions.length
+})
+
+const activeAgentCount = computed(() => workspaceStore.agents.length)
+
+const toolCallCount = computed(() => {
+  if (usageResult.value?.aggregates?.tools) {
+    return usageResult.value.aggregates.tools.totalCalls
+  }
+  return 0
+})
+
+function formatNumber(n: number): string {
+  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
+  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K'
+  return String(n)
+}
+
+async function loadUsage() {
+  if (!wsStore.rpc || !wsStore.connected) return
+  loading.value = true
+  try {
+    const result = await wsStore.rpc.getSessionsUsage({})
+    if (result && typeof result === 'object' && 'sessions' in result) {
+      usageResult.value = result as SessionsUsageResult
+    }
+  } catch {
+    usageResult.value = null
+  } finally {
+    loading.value = false
+  }
+}
+
+onMounted(() => {
+  if (sessionStore.sessions.length === 0) {
+    sessionStore.fetchSessions().then(loadUsage).catch(() => {})
+  } else {
+    loadUsage()
+  }
+})
+</script>
+
+<template>
+  <div class="mobile-dashboard">
+    <div class="page-header">
+      <h1 class="page-title">数据看板</h1>
+      <p class="page-desc">实时用量与统计概览</p>
+    </div>
+
+    <div class="stats-grid">
+      <div class="stat-card">
+        <span class="stat-label">今日 Token</span>
+        <span class="stat-value">{{ formatNumber(todayTokens) }}</span>
+      </div>
+      <div class="stat-card">
+        <span class="stat-label">会话数</span>
+        <span class="stat-value">{{ formatNumber(sessionCount) }}</span>
+      </div>
+      <div class="stat-card">
+        <span class="stat-label">活跃 Agent</span>
+        <span class="stat-value">{{ formatNumber(activeAgentCount) }}</span>
+      </div>
+      <div class="stat-card">
+        <span class="stat-label">工具调用</span>
+        <span class="stat-value">{{ formatNumber(toolCallCount) }}</span>
+      </div>
+    </div>
+
+    <div v-if="loading" class="loading-hint">
+      <span class="material-symbols-outlined spinning">progress_activity</span>
+      <span>加载中...</span>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.mobile-dashboard {
+  padding: var(--space-md);
+}
+
+.page-header {
+  margin-bottom: var(--space-xl);
+  padding: var(--space-lg) 0;
+}
+
+.page-title {
+  font-size: var(--text-2xl);
+  font-weight: 700;
+  color: var(--text);
+  margin: 0 0 var(--space-xs);
+  line-height: var(--leading-tight);
+}
+
+.page-desc {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  margin: 0;
+}
+
+.stats-grid {
+  display: grid;
+  grid-template-columns: repeat(2, 1fr);
+  gap: var(--space-md);
+}
+
+.stat-card {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-sm);
+  padding: var(--space-lg);
+  background: var(--bg-card, #fff);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-lg);
+
+  /* Performance containment */
+  contain: layout style paint;
+}
+
+.stat-label {
+  font-size: var(--text-sm);
+  color: var(--text-muted);
+}
+
+.stat-value {
+  font-size: var(--text-xl);
+  font-weight: 700;
+  color: var(--text);
+}
+
+.loading-hint {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-sm);
+  margin-top: var(--space-xl);
+  color: var(--text-muted);
+  font-size: var(--text-sm);
+}
+
+.spinning {
+  animation: spin 1s linear infinite;
+}
+
+@keyframes spin {
+  from {
+    transform: rotate(0deg);
+  }
+  to {
+    transform: rotate(360deg);
+  }
+}
+</style>
diff --git a/src/views/mobile/pages/MobileFallbackPage.vue b/src/views/mobile/pages/MobileFallbackPage.vue
new file mode 100644
index 0000000..6ac90d0
--- /dev/null
+++ b/src/views/mobile/pages/MobileFallbackPage.vue
@@ -0,0 +1,225 @@
+<script setup lang="ts">
+import { computed } from 'vue'
+import { useRoute, useRouter } from 'vue-router'
+
+const route = useRoute()
+const router = useRouter()
+
+const fromPath = route.query.from as string || ''
+
+const fullUrl = computed(() => {
+  if (typeof window === 'undefined') return ''
+  return window.location.origin + fromPath
+})
+
+const isDesktopUA = computed(() => {
+  if (typeof navigator === 'undefined') return false
+  const ua = navigator.userAgent.toLowerCase()
+  return !/iphone|ipad|ipod|android|webos|blackberry|iemobile|opera mini|mobile/.test(ua)
+})
+
+function goHome() {
+  router.replace({ path: '/mobile/workspace' })
+}
+
+async function copyLink() {
+  if (!fullUrl.value) return
+  try {
+    await navigator.clipboard.writeText(fullUrl.value)
+  } catch {
+    // Fallback for environments without clipboard API
+    const textarea = document.createElement('textarea')
+    textarea.value = fullUrl.value
+    textarea.style.position = 'fixed'
+    textarea.style.opacity = '0'
+    document.body.appendChild(textarea)
+    textarea.select()
+    document.execCommand('copy')
+    document.body.removeChild(textarea)
+  }
+}
+
+function openInDesktop() {
+  if (fromPath) {
+    window.location.href = fromPath
+  } else {
+    window.location.href = '/'
+  }
+}
+</script>
+
+<template>
+  <div class="fallback-page">
+    <div class="fallback-content">
+      <span class="material-symbols-outlined fallback-icon">construction</span>
+      <h2 class="fallback-title">页面适配中</h2>
+      <p class="fallback-desc">
+        该页面包含高密度数据组件（如工业信号表单或 3D 渲染画布），正在针对移动端进行优化适配。
+      </p>
+
+      <div v-if="fromPath" class="fallback-link-card">
+        <span class="fallback-link-label">来源链接</span>
+        <span class="fallback-link-url">{{ fromPath }}</span>
+        <button class="fallback-link-copy" @click="copyLink">
+          <span class="material-symbols-outlined">content_copy</span>
+          <span>复制链接</span>
+        </button>
+      </div>
+
+      <div class="fallback-actions">
+        <button class="fallback-btn primary" @click="goHome">
+          <span class="material-symbols-outlined">home</span>
+          <span>返回工作台</span>
+        </button>
+
+        <button
+          v-if="isDesktopUA && fromPath"
+          class="fallback-btn secondary"
+          @click="openInDesktop"
+        >
+          <span class="material-symbols-outlined">open_in_new</span>
+          <span>在桌面端打开</span>
+        </button>
+      </div>
+
+      <p v-if="isDesktopUA" class="fallback-hint">
+        检测到桌面端环境，建议直接访问完整版页面以获得最佳体验。
+      </p>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.fallback-page {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  min-height: 100%;
+  padding: var(--space-xl) var(--space-md);
+}
+
+.fallback-content {
+  display: flex;
+  flex-direction: column;
+  align-items: center;
+  text-align: center;
+  gap: var(--space-lg);
+  width: 100%;
+  max-width: 360px;
+}
+
+.fallback-icon {
+  font-size: var(--text-3xl);
+  color: var(--accent);
+  margin-bottom: var(--space-xs);
+}
+
+.fallback-title {
+  font-size: var(--text-xl);
+  font-weight: 700;
+  color: var(--text);
+  margin: 0;
+}
+
+.fallback-desc {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  line-height: var(--leading-relaxed);
+  margin: 0;
+}
+
+.fallback-link-card {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-xs);
+  width: 100%;
+  padding: var(--space-md);
+  background: var(--bg-surface, #fafafa);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-lg);
+  text-align: left;
+}
+
+.fallback-link-label {
+  font-size: var(--text-xs);
+  color: var(--text-muted);
+  font-weight: 500;
+}
+
+.fallback-link-url {
+  font-size: var(--text-sm);
+  color: var(--text);
+  word-break: break-all;
+  line-height: var(--leading-snug);
+}
+
+.fallback-link-copy {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-xs);
+  margin-top: var(--space-xs);
+  padding: var(--space-sm) var(--space-md);
+  min-height: 44px;
+  border: 1px dashed var(--border, #e0e0e0);
+  border-radius: var(--radius-md);
+  background: transparent;
+  color: var(--accent, #435ba8);
+  font-size: var(--text-sm);
+  font-weight: 500;
+  cursor: pointer;
+  transition: background-color 0.15s ease;
+}
+
+.fallback-link-copy:active {
+  background-color: var(--accent-bg, rgba(67, 91, 168, 0.08));
+}
+
+.fallback-actions {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-sm);
+  width: 100%;
+}
+
+.fallback-btn {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-sm);
+  width: 100%;
+  min-height: var(--min-hit-target);
+  border: none;
+  border-radius: var(--radius-md);
+  font-size: var(--text-base);
+  font-weight: 600;
+  cursor: pointer;
+  transition: opacity 0.15s ease, background-color 0.15s ease;
+}
+
+.fallback-btn.primary {
+  background: var(--accent);
+  color: #fff;
+}
+
+.fallback-btn.primary:active {
+  opacity: 0.9;
+}
+
+.fallback-btn.secondary {
+  background: var(--bg-surface, #fafafa);
+  color: var(--text);
+  border: 1px solid var(--border, #e0e0e0);
+}
+
+.fallback-btn.secondary:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.fallback-hint {
+  font-size: var(--text-xs);
+  color: var(--text-muted);
+  margin: 0;
+  text-align: center;
+}
+</style>
diff --git a/src/views/mobile/pages/MobileProfilePage.vue b/src/views/mobile/pages/MobileProfilePage.vue
new file mode 100644
index 0000000..1b4ee93
--- /dev/null
+++ b/src/views/mobile/pages/MobileProfilePage.vue
@@ -0,0 +1,135 @@
+<script setup lang="ts">
+import { useAuthStore } from '@/stores/auth'
+import { useRouter } from 'vue-router'
+
+const authStore = useAuthStore()
+const router = useRouter()
+
+function handleLogout() {
+  authStore.logout().then(() => {
+    router.replace({ name: 'Login' })
+  })
+}
+</script>
+
+<template>
+  <div class="mobile-profile">
+    <div class="profile-header">
+      <div class="profile-avatar">
+        <span class="material-symbols-outlined">account_circle</span>
+      </div>
+      <div class="profile-info">
+        <span class="profile-name">{{ authStore.currentUser?.display_name || authStore.currentUser?.username || '用户' }}</span>
+        <span class="profile-role">{{ authStore.isAdmin ? '管理员' : '普通用户' }}</span>
+      </div>
+    </div>
+
+    <div class="menu-list">
+      <div class="menu-item">
+        <span class="material-symbols-outlined menu-icon">dark_mode</span>
+        <span class="menu-label">深色模式</span>
+        <span class="material-symbols-outlined menu-arrow">chevron_right</span>
+      </div>
+      <div class="menu-item">
+        <span class="material-symbols-outlined menu-icon">settings</span>
+        <span class="menu-label">系统设置</span>
+        <span class="material-symbols-outlined menu-arrow">chevron_right</span>
+      </div>
+      <div class="menu-item menu-item-danger" @click="handleLogout">
+        <span class="material-symbols-outlined menu-icon">logout</span>
+        <span class="menu-label">退出登录</span>
+      </div>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.mobile-profile {
+  padding: var(--space-md);
+}
+
+.profile-header {
+  display: flex;
+  align-items: center;
+  gap: var(--space-md);
+  padding: var(--space-xl) 0;
+  margin-bottom: var(--space-xl);
+}
+
+.profile-avatar {
+  width: 56px;
+  height: 56px;
+  border-radius: var(--radius-full);
+  background: var(--accent-bg, rgba(67, 91, 168, 0.08));
+  color: var(--accent, #435ba8);
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  flex-shrink: 0;
+}
+
+.profile-avatar .material-symbols-outlined {
+  font-size: var(--text-2xl);
+}
+
+.profile-info {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-3xs);
+}
+
+.profile-name {
+  font-size: var(--text-lg);
+  font-weight: 600;
+  color: var(--text);
+}
+
+.profile-role {
+  font-size: var(--text-sm);
+  color: var(--text-muted);
+}
+
+.menu-list {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-sm);
+}
+
+.menu-item {
+  display: flex;
+  align-items: center;
+  gap: var(--space-md);
+  padding: var(--space-md);
+  background: var(--bg-card, #fff);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-lg);
+  min-height: var(--min-hit-target);
+  cursor: pointer;
+  transition: background-color 0.15s ease;
+}
+
+.menu-item:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.menu-icon {
+  font-size: var(--text-xl);
+  color: var(--text-muted);
+}
+
+.menu-label {
+  flex: 1;
+  font-size: var(--text-base);
+  color: var(--text);
+}
+
+.menu-arrow {
+  color: var(--text-muted);
+  font-size: var(--text-lg);
+}
+
+.menu-item-danger .menu-icon,
+.menu-item-danger .menu-label {
+  color: var(--error, #a83836);
+}
+</style>
diff --git a/src/views/mobile/pages/MobileWorkspacePage.vue b/src/views/mobile/pages/MobileWorkspacePage.vue
new file mode 100644
index 0000000..0d2d0b4
--- /dev/null
+++ b/src/views/mobile/pages/MobileWorkspacePage.vue
@@ -0,0 +1,302 @@
+<script setup lang="ts">
+import { computed, onMounted } from 'vue'
+import { useRouter } from 'vue-router'
+import { useWorkspaceStore } from '@/stores/workspace'
+import type { AgentWithSessions } from '@/api/types'
+
+const workspaceStore = useWorkspaceStore()
+const router = useRouter()
+
+const agents = computed(() => workspaceStore.agents)
+const activeAgent = computed(() => workspaceStore.selectedAgent)
+
+async function handleSelectSession(sessionKey: string) {
+  await workspaceStore.selectSession(sessionKey)
+  router.push({ path: '/mobile/workspace/chat', query: { key: sessionKey } })
+}
+
+async function handleSelectAgent(agent: AgentWithSessions) {
+  if (activeAgent.value?.agentId === agent.agentId) {
+    return
+  }
+  await workspaceStore.selectAgent(agent.agentId)
+}
+
+async function handleNewChat(agentId: string) {
+  await workspaceStore.selectAgent(agentId)
+  const sessionKey = await workspaceStore.startNewChat(agentId)
+  if (sessionKey) {
+    router.push({ path: '/mobile/workspace/chat', query: { key: sessionKey } })
+  }
+}
+
+onMounted(() => {
+  if (agents.value.length === 0) {
+    workspaceStore.loadAgents()
+  }
+})
+</script>
+
+<template>
+  <div class="mobile-workspace">
+    <div class="workspace-header safe-inset-x">
+      <h1 class="workspace-title">AI 工作台</h1>
+      <p class="workspace-subtitle">选择会话开始对话</p>
+    </div>
+
+    <div class="session-list">
+      <div
+        v-for="agent in agents"
+        :key="agent.agentId"
+        class="agent-group"
+      >
+        <button
+          class="agent-header"
+          @click="handleSelectAgent(agent)"
+        >
+          <div class="agent-header-avatar">
+            <span class="material-symbols-outlined">smart_toy</span>
+          </div>
+          <span class="agent-header-name">{{ agent.name }}</span>
+          <span class="material-symbols-outlined agent-header-arrow">chevron_right</span>
+        </button>
+
+        <div
+          v-if="agent.sessions?.length"
+          class="session-group"
+        >
+          <button
+            v-for="session in agent.sessions.slice(0, 5)"
+            :key="session.key"
+            class="session-card"
+            @click="handleSelectSession(session.key)"
+          >
+            <span class="material-symbols-outlined session-icon">chat_bubble</span>
+            <div class="session-info">
+              <span class="session-label">{{ session.label || session.key.slice(-8) }}</span>
+              <span class="session-meta">{{ session.model?.split('/').pop() || '默认模型' }}</span>
+            </div>
+            <span class="material-symbols-outlined session-arrow">chevron_right</span>
+          </button>
+        </div>
+
+        <button
+          class="new-chat-btn"
+          @click="handleNewChat(agent.agentId)"
+        >
+          <span class="material-symbols-outlined">add</span>
+          <span>新建会话</span>
+        </button>
+      </div>
+
+      <div
+        v-if="agents.length === 0"
+        class="empty-state"
+      >
+        <span class="material-symbols-outlined empty-icon">inbox</span>
+        <p class="empty-text">暂无数字员工</p>
+      </div>
+    </div>
+  </div>
+</template>
+
+<style scoped>
+.mobile-workspace {
+  display: flex;
+  flex-direction: column;
+  height: 100%;
+  min-height: 0;
+}
+
+.workspace-header {
+  flex-shrink: 0;
+  padding: var(--space-xl) var(--space-md);
+  padding-top: max(var(--safe-top), var(--space-xl));
+}
+
+.workspace-title {
+  font-size: var(--text-2xl);
+  font-weight: 700;
+  color: var(--text);
+  margin: 0 0 var(--space-xs);
+  line-height: var(--leading-tight);
+}
+
+.workspace-subtitle {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  margin: 0;
+}
+
+.session-list {
+  flex: 1;
+  min-height: 0;
+  overflow-y: auto;
+  overflow-x: hidden;
+  -webkit-overflow-scrolling: touch;
+  overscroll-behavior-y: contain;
+  padding: 0 var(--space-md) var(--space-xl);
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-xl);
+}
+
+.agent-group {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-sm);
+}
+
+.agent-header {
+  display: flex;
+  align-items: center;
+  gap: var(--space-sm);
+  padding: var(--space-sm) var(--space-md);
+  background: var(--bg-card, #fff);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-lg);
+  min-height: var(--min-hit-target);
+  cursor: pointer;
+  border: none;
+  text-align: left;
+  width: 100%;
+  transition: background-color 0.15s ease;
+}
+
+.agent-header:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.agent-header-avatar {
+  width: 36px;
+  height: 36px;
+  border-radius: var(--radius-md);
+  background: var(--accent-bg, rgba(67, 91, 168, 0.08));
+  color: var(--accent, #435ba8);
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  flex-shrink: 0;
+}
+
+.agent-header-avatar .material-symbols-outlined {
+  font-size: var(--text-lg);
+}
+
+.agent-header-name {
+  flex: 1;
+  font-size: var(--text-base);
+  font-weight: 600;
+  color: var(--text);
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+}
+
+.agent-header-arrow {
+  color: var(--text-muted);
+  font-size: var(--text-lg);
+}
+
+.session-group {
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-xs);
+  padding-left: var(--space-lg);
+}
+
+.session-card {
+  display: flex;
+  align-items: center;
+  gap: var(--space-sm);
+  padding: var(--space-sm) var(--space-md);
+  background: var(--bg-surface, #fafafa);
+  border: 1px solid var(--border, #e0e0e0);
+  border-radius: var(--radius-md);
+  min-height: var(--min-hit-target);
+  cursor: pointer;
+  border: none;
+  text-align: left;
+  width: 100%;
+  transition: background-color 0.15s ease;
+}
+
+.session-card:active {
+  background-color: var(--bg-hover, rgba(0, 0, 0, 0.05));
+}
+
+.session-icon {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  flex-shrink: 0;
+}
+
+.session-info {
+  flex: 1;
+  display: flex;
+  flex-direction: column;
+  gap: var(--space-3xs);
+  min-width: 0;
+}
+
+.session-label {
+  font-size: var(--text-sm);
+  font-weight: 500;
+  color: var(--text);
+  white-space: nowrap;
+  overflow: hidden;
+  text-overflow: ellipsis;
+}
+
+.session-meta {
+  font-size: var(--text-2xs);
+  color: var(--text-muted);
+}
+
+.session-arrow {
+  color: var(--text-muted);
+  font-size: var(--text-base);
+}
+
+.new-chat-btn {
+  display: flex;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-xs);
+  padding: var(--space-sm) var(--space-md);
+  margin-left: var(--space-lg);
+  min-height: var(--min-hit-target);
+  border: 1px dashed var(--border, #e0e0e0);
+  border-radius: var(--radius-md);
+  background: transparent;
+  color: var(--accent, #435ba8);
+  font-size: var(--text-sm);
+  font-weight: 500;
+  cursor: pointer;
+  transition: background-color 0.15s ease;
+}
+
+.new-chat-btn:active {
+  background-color: var(--accent-bg, rgba(67, 91, 168, 0.08));
+}
+
+.empty-state {
+  display: flex;
+  flex-direction: column;
+  align-items: center;
+  justify-content: center;
+  gap: var(--space-md);
+  padding: var(--space-4xl) var(--space-xl);
+}
+
+.empty-icon {
+  font-size: var(--text-3xl);
+  color: var(--text-muted);
+}
+
+.empty-text {
+  font-size: var(--text-base);
+  color: var(--text-muted);
+  margin: 0;
+}
+</style>
diff --git a/src/views/workspace/MessageList.vue b/src/views/workspace/MessageList.vue
index 9c4c437..dec287b 100644
--- a/src/views/workspace/MessageList.vue
+++ b/src/views/workspace/MessageList.vue
@@ -344,7 +344,7 @@ function handleRetry(msg: ChatMessage) {
   bottom: 0;
   left: 0;
   right: 0;
-  height: 72px;
+  height: 32px;
   background: linear-gradient(to bottom, transparent 0%, var(--bg) 85%);
   pointer-events: none;
   z-index: 5;
@@ -354,7 +354,7 @@ function handleRetry(msg: ChatMessage) {
   flex: 1;
   min-height: 0;
   overflow: auto;
-  padding: 0 24px 80px;
+  padding: 0 24px 24px;
 }
 
 .load-more-hint {

\`\`\`
