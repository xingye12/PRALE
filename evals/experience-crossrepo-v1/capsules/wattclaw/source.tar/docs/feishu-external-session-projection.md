# 飞书外部消息 Session Projection 根治逻辑说明

## 背景

WattClaw 的飞书/Lark 外部消息来自 OpenClaw Gateway 推送。消息进入 WattClaw 后，需要同时完成两件事：

1. 把消息写入 PostgreSQL 的 `session_messages`，作为聊天历史的事实源。
2. 把会话投影到 SQLite 的 `user_sessions`，作为会话列表、标题、归属和最后活跃时间的读取源。

之前的问题集中在第二步：外部消息虽然可能已经进入消息存储，但本地 `user_sessions` 没有稳定、可信的标题投影逻辑，导致前端会话列表只能回退显示 `新对话`。

---

## 之前的问题

### 1. 外部消息没有专门的会话标题投影主链路

飞书消息进入系统后，主要路径是 `session.message` 事件写入 PG 消息表。

但是会话列表读取的是 SQLite `user_sessions`。

旧逻辑缺少一个明确的桥接层：

```txt
Gateway session.message
→ PostgreSQL session_messages
→ SQLite user_sessions.display_title
```

结果是：

- PG 里可能已经有飞书用户消息；
- SQLite 的 `user_sessions.display_title` 仍为空；
- 前端读取会话列表时只能显示默认文案 `新对话`。

### 2. 标题来源不稳定

旧逻辑中，标题可能来自：

- Gateway metadata；
- `label`；
- `derivedTitle`；
- 临时 auto-title fallback；
- 前端兜底。

这些来源没有统一规则，导致标题语义不稳定。

本次明确为：

```txt
外部会话标题 = 首条有效用户消息生成的 display_title
```

并且生成标题只写入 `display_title`，不再污染 `label`。

### 3. `新对话`、peerId、空标题无法稳定修复

部分历史会话已经写入了无意义标题，例如：

- `新对话`
- peerId
- 空字符串
- 其他可回填标题

旧逻辑通常只在字段为空时写入，不能可靠覆盖这些“看起来有值但语义无效”的标题。

### 4. 外部 session key 格式兼容不足

实际系统中存在两类外部 session key：

```txt
agent:<agentId>:<channel>:<kind>:<peer>
agent:<agentId>:<channel>:<peer>
```

旧判断容易只识别其中一种格式。

如果旧格式被误判为内部会话，会出现两个后果：

1. 外部用户消息被当作内部用户消息跳过；
2. 飞书标题 projection 不触发。

### 5. projection 与 PG 写入顺序存在乱序风险

旧实现过程中曾出现过一个边界问题：

```txt
session.message 到达
→ 先 projection 写 display_title
→ 再 saveMessage 写 PG
```

如果 Gateway 推送乱序，例如：

```txt
seq=2 先到
seq=1 后到
```

就可能先用第二条消息写标题。后续真正第一条消息到达时，如果已有标题被视为有效，标题就不一定能纠正。

这不符合“首条有效用户消息作为标题”的设计目标。

---

## 现在的修改

### 1. 增加外部 Session Projection 服务

新增文件：

```txt
server/services/external-session-projection.js
```

这个服务成为外部会话标题投影的唯一主链路。

核心职责：

1. 判断 session key 是否属于外部渠道；
2. 解析 agentId、channel、kind、peer；
3. 从 PG 读取首条有效用户消息；
4. 生成稳定标题；
5. 写入 SQLite `user_sessions.display_title`；
6. 启动时对历史无效标题做本地 backfill。

核心数据流：

```txt
Gateway session.message
→ message-sync 保存消息到 PG
→ external-session-projection 查询 earliest user message
→ user-manager 写入 user_sessions.display_title
→ /api/sessions 返回标题
→ 前端会话列表展示
```

### 2. 增加 PG earliest user message 读取 API

修改文件：

```txt
server/message-store.js
```

新增两个读取函数：

```js
readEarliestEffectiveUserMessage(sessionKey)
readEarliestEffectiveUserMessages(sessionKeys)
```

查询条件是：

```sql
status = 'confirmed'
role = 'user'
content 非空
```

排序规则是：

```sql
ORDER BY COALESCE(msg_timestamp, created_at) ASC, seq ASC
```

原因：标题必须来自“最早的有效用户消息”，不能来自最新消息，也不能来自 assistant 或空消息。

### 3. 新增专用 SQLite upsert

修改文件：

```txt
server/user-manager.js
```

新增：

```js
upsertExternalSessionProjection(...)
```

这个函数专门服务外部会话 projection。

它和普通 `trackSessionForUser` 的区别是：

- 只写 `display_title`；
- 不写生成标题到 `label`；
- 会保留已有有效标题；
- 会用 `shouldBackfillDisplayTitle` 判断是否可以覆盖无效标题；
- 会维护 `agent_id`、`channel`、`peer_id`、`last_message_at`。

覆盖规则：

```txt
已有标题有效 → 保留
已有标题无效 → 用首条有效用户消息生成的标题覆盖
无标题 → 写入生成标题
```

### 4. 修复 `trackSessionsBatch` 回归

在 `server/user-manager.js` 中恢复：

```js
_batchTrackStmts
```

否则 `trackSessionsBatch` 会在运行时访问未定义变量，导致批量会话归属注册崩溃。

### 5. 兼容新旧外部 session key

修改文件：

```txt
server/services/external-session-projection.js
```

现在支持：

```txt
agent:<agentId>:<channel>:<kind>:<peer>
agent:<agentId>:<channel>:<peer>
```

旧格式默认：

```txt
kind = private
```

并且 peer 内部的冒号会保留。

例如：

```txt
agent:agent-a:feishu:private:ou:abc
```

会解析为：

```txt
agentId = agent-a
channel = feishu
kind = private
peer = ou:abc
```

旧格式：

```txt
agent:agent-a:feishu:ou:abc
```

会解析为：

```txt
agentId = agent-a
channel = feishu
kind = private
peer = ou:abc
```

### 6. 调整 `session.message` 处理顺序

修改文件：

```txt
server/core/message-sync.js
```

现在外部用户消息处理顺序是：

```txt
收到 session.message
→ 提取消息字段
→ 内部用户消息跳过，避免重复写入
→ 外部用户消息先 saveMessage 写 PG
→ 写入成功后 advanceSessionLastMessageAt
→ 再执行 externalSessionProjection
```

这样 projection 读取 PG earliest message 时，可以看到当前消息已经入库后的真实状态。

如果 PG 写入失败，则不会继续 projection，避免 SQLite 标题和 PG 消息事实源不一致。

### 7. 启动时执行本地 backfill

修改文件：

```txt
server/index.js
```

启动链路中，在 MessageStore ready 和历史 session repair 之后，执行：

```js
backfillExternalSessionTitles()
```

它只使用本地数据：

- SQLite `user_sessions`
- PostgreSQL `session_messages`

不会启动时扫描 Gateway 历史，避免引入外部 RPC 阻塞或队头阻塞。

### 8. legacy auto-title fallback 改走新 upsert

修改文件：

```txt
server/index.js
```

旧的 auto-title fallback 原来直接：

```txt
trackSessionForUser
+ 手写 UPDATE user_sessions
```

现在改为统一调用：

```js
upsertExternalSessionProjection(...)
```

这样标题写入策略统一，不再有第二套规则。

### 9. 增加测试脚本与 projection 测试

修改文件：

```txt
package.json
server/services/external-session-projection.test.js
```

新增 `test:server`：

```bash
npm run test:server
```

新增测试覆盖：

- peer 中冒号不丢失；
- 旧 4 段 session key 兼容；
- Feishu/Lark 外部渠道识别；
- string/content blocks 内容提取；
- 标题使用 earliest user message；
- assistant 消息跳过；
- 空内容跳过；
- projection 不写生成标题到 label；
- 乱序场景下使用 PG earliest message 作为标题来源。

---

## 为什么这样修改

### 1. 让 PostgreSQL 成为消息事实源

消息内容已经写在 PG `session_messages` 中。

标题应该基于 PG 中的真实消息生成，而不是基于 Gateway metadata、前端兜底或临时变量。

因此设计为：

```txt
PG session_messages → 计算首条有效用户消息 → SQLite user_sessions.display_title
```

### 2. 让 SQLite 成为会话列表读取源

前端会话列表不应该实时扫 PG 消息表，也不应该依赖 Gateway 实时历史。

SQLite `user_sessions` 是会话列表 projection，适合存储：

- 归属用户；
- agentId；
- channel；
- peerId；
- displayTitle；
- lastMessageAt。

所以标题最终写入 `user_sessions.display_title`。

### 3. 避免污染 `label`

`label` 是外部系统或 Gateway metadata 的兼容字段，不应该被 WattClaw 生成标题覆盖。

生成标题只写入：

```txt
display_title
```

这样可以保持字段语义清晰：

```txt
label         = 外部/兼容原始标签
display_title = WattClaw 展示标题
```

### 4. 用专用 projection 服务消除散落逻辑

之前标题相关逻辑散落在：

- message sync；
- startup repair；
- auto-title fallback；
- user session tracking；
- 前端 fallback。

现在把外部会话标题生成集中到：

```txt
server/services/external-session-projection.js
```

这样符合 Single Source of Truth：

```txt
外部消息标题投影只有一个主实现
```

### 5. 先写 PG 再投影，解决乱序和一致性问题

projection 依赖 PG earliest message。

因此必须先让当前消息进入 PG，再执行 projection。

否则 projection 可能看不到当前消息，或者乱序时使用错误标题。

新顺序保证：

```txt
projection 读取的是保存后的事实状态
```

### 6. 本地 backfill 避免启动期 Gateway 依赖

历史修复只依赖本地数据库，不启动 Gateway 历史扫描。

原因：

- 启动不能被 Gateway RPC 阻塞；
- 外部 RPC 可能慢或失败；
- 本地 PG 已经是消息事实源；
- repair 应该轻量、可重复、低风险。

---

## 最终效果

修复后，飞书外部消息会话标题链路为：

```txt
飞书用户发消息
→ OpenClaw Gateway 推送 session.message
→ WattClaw message-sync 接收
→ 外部用户消息写入 PG session_messages
→ projection 读取首条有效用户消息
→ 生成标题，如：飞书 · 帮我查一下库存
→ 写入 SQLite user_sessions.display_title
→ /api/sessions 返回 displayTitle
→ 前端展示稳定标题
```

历史已有 `新对话` 的会话，在服务启动时会被 backfill：

```txt
SQLite user_sessions 找到无效标题
→ PG 查首条有效用户消息
→ 生成 display_title
→ 覆盖无效标题
```

---

## 验证结果

已执行：

```bash
npm run test:server
```

结果：

```txt
server/core/session-sync.test.js: 7 passed
server/handlers/cron.test.js: 2 passed
server/services/external-session-projection.test.js: 8 passed
```

已执行：

```bash
npm run build
```

结果：

```txt
vue-tsc -b passed
vite build passed
```

构建仅有 chunk size warning，不是失败。

---

## 涉及文件

核心实现：

```txt
server/services/external-session-projection.js
server/message-store.js
server/user-manager.js
server/core/message-sync.js
server/index.js
```

测试与脚本：

```txt
server/services/external-session-projection.test.js
package.json
```

相关安全修复确认：

```txt
src/mobile/views/chat/MessageBubble.vue
```

---

## 当前结论

本次修改把飞书/Lark 外部消息会话标题从“前端兜底/散落 fallback”收敛为后端明确的 Session Projection：

```txt
PG 消息事实源
→ 外部 Session Projection
→ SQLite 会话列表 projection
→ 前端展示
```

它解决了原来的 `新对话` 问题，同时兼容历史数据、旧 session key、乱序消息和无效标题 backfill。
