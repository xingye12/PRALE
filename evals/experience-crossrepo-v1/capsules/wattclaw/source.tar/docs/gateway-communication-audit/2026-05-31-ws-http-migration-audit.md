# Gateway 通信审计报告

> 分支: `test/http-ws-separation`
> 更新日期: 2026-05-31
> 背景: WS RPC → HTTP 迁移后的全量调用点审计

---

## 一、HTTP POST（gatewayAdminRpc）— 22 处

| 方法 | 调用位置 | 缓存 |
|------|---------|------|
| `config.get` | 启动回填、ConfigQueue、sync-from-gateway | ✅ 19s 轮询缓存 |
| `config.patch` / `config.set` | ConfigQueue 写入 | 无（带重试） |
| `config.apply` | ConfigQueue 确认 | 无（带重试） |
| `cron.list` | 全局轮询 | ✅ 11s 轮询缓存 |
| `models.list` | 全局轮询 | ✅ 13s 轮询缓存 |
| `agents.list` | migrate-bootstrap、agent-team/files、workspace | ✅ 60s TTL |
| `channels.logout` | 渠道登出 | 无 |
| `health` | 系统指标 | ✅ 30s TTL |
| `status` | /api/status | 无 |
| 白名单透传 | /api/rpc 路由（admin+非admin） | 无 |

---

## 二、HTTP GET（gatewayHttpGet）— 3 处

| 路径 | 调用位置 | 缓存 |
|------|---------|------|
| `/sessions/:key/history` | 历史回填工具函数（fetchHistoryFromGateway） | 无 |
| `/sessions/:key/history` | 自动标题（事件触发，tryAutoTitleForChannelSession） | 去重锁 |
| `/sessions/:key/history` | Agent 统计（/api/agent-team/:id/stats） | 无 |

---

## 三、WS RPC（gateway.call）— 25 处

| 方法 | 调用位置 | 缓存 |
|------|---------|------|
| `sessions.list` {} | 全局轮询（allSessionsPolling） | ✅ 9s 轮询缓存 |
| `sessions.list` {agentId} | 批量获取（fetchAllAgentSessions） | ✅ 15s TTL |
| `sessions.usage` | 用量查询（callGatewayUsage） | 无 |
| `sessions.patch` | 标题同步（/api/workspace/send fire-and-forget） | 无 |
| `skills.status` | 全局轮询（skillsStatusPolling） | ✅ 17s 轮询缓存 |
| `system-presence` | 系统指标在线状态（/api/system/metrics） | 无 |
| `agents.files.get` | USER.md、BOOTSTRAP.md 读取（3处） | 无 |
| `agents.files.set` | USER.md 写入 | 无 |
| `chat.send` | 聊天发送（/api/chat/send、/api/workspace/send、/api/rpc） | 无 |
| `chat.abort` | 聊天取消（/api/chat/abort、/api/chat/cancel） | 无 |
| `session.spawn` / `sessions.spawn` | 会话创建（/api/rpc） | 无 |
| `session.send` / `sessions.send` | 会话发送（/api/rpc） | 无 |
| `sessions.reset` / `session.reset` | 重置会话（/api/rpc） | 无 |
| `sessions.delete` / `session.delete` | 删除会话（/api/rpc） | 无 |
| `sessions.get` / `session.get` | 获取会话详情（/api/rpc） | 无 |
| `sessions.export` / `session.export` | 导出会话（/api/rpc） | 无 |
| `agent` | Agent 方法透传（/api/rpc） | 无 |
| WS fallback | /api/rpc 白名单外方法（admin+非admin） | 无 |
| `health`（心跳） | gateway.js 心跳保活（30s interval） | 无 |

> **注:** `health` 心跳必须走 WS — 目的是检测 WebSocket 连接存活，走 HTTP 无意义。

---

## 四、后台轮询缓存（5 个）

通过 `createPollingCache()` 实现，后台按 TTL 间隔自动刷新，不依赖 `setInterval`/`setTimeout`。

| 缓存名 | TTL | 协议 | 刷新方法 | 用途 |
|--------|-----|------|---------|------|
| `allSessionsPolling` | 9s | **WS** | `sessions.list` | 会话列表全局缓存 |
| `cronListPolling` | 11s | HTTP | `cron.list` | 定时任务列表缓存 |
| `modelsListPolling` | 13s | HTTP | `models.list` | 模型列表缓存 |
| `skillsStatusPolling` | 17s | **WS** | `skills.status` | 技能状态缓存 |
| `configGetPolling` | 19s | HTTP | `config.get` | Gateway 配置缓存 |

---

## 五、请求级 TTL 缓存（3 个）

按请求触发，命中缓存则跳过 Gateway 调用。

| 缓存变量 | TTL | 协议 | 所在路由/函数 | 刷新方法 |
|----------|-----|------|-------------|---------|
| `_gatewayHealthCache` | 30s | HTTP | `GET /api/system/metrics` | `health` |
| `_agentSessionsCache` | 15s | WS | `fetchAllAgentSessions()` | `sessions.list {agentId}` |
| `agentWorkspaceCache` | 60s | HTTP | `getAgentWorkspace()` | `agents.list` |

---

## 六、汇总统计

| 通信方式 | 调用点数量 | 唯一 Gateway 方法数 |
|---------|-----------|-------------------|
| HTTP POST (gatewayAdminRpc) | ~22 | config.get/patch/set/apply, cron.list, models.list, agents.list, channels.logout, health, status + 白名单透传 |
| HTTP GET (gatewayHttpGet) | 3 | `/sessions/:key/history`（3 处） |
| WS RPC (gateway.call) | 25 | sessions.list/usage/patch, skills.status, system-presence, agents.files.get/set, chat.send/abort, session.spawn/send, sessions.reset/delete/get/export, agent + WS fallback + health 心跳 |
| **总计** | **~50** | |

---

## 七、HTTP 白名单（HTTP_RPC_METHODS）

以下 49 个方法通过 `/api/v1/admin/rpc` 走 HTTP：

```
config.get, config.patch, config.set, config.apply,
config.schema, config.schema.lookup,
cron.list, cron.status, cron.get, cron.add, cron.update, cron.remove, cron.run, cron.runs,
models.list, models.authStatus,
agents.list, agents.create, agents.update, agents.delete,
channels.status, channels.start, channels.stop, channels.logout,
health, status,
node.list, node.describe, node.pair.list, node.pair.approve, node.pair.reject, node.pair.remove, node.rename,
tasks.list, tasks.get, tasks.cancel,
usage.status, usage.cost,
exec.approvals.get, exec.approvals.set, exec.approvals.node.get, exec.approvals.node.set,
logs.tail, gateway.restart.request,
device.pair.list, device.pair.approve, device.pair.reject, device.pair.remove,
doctor.memory.status, update.status
```

---

## 八、WS 原因分析

以下方法只能走 WS，原因分类：

| 原因 | 方法 | 说明 |
|------|------|------|
| Gateway 插件不支持 | `sessions.list/usage/patch/get/reset/delete/export` | admin-http-rpc 白名单不含 |
| Gateway 插件不支持 | `skills.status` | 白名单不含 |
| Gateway 插件不支持 | `agents.files.get/set` | 白名单不含 |
| Gateway 插件不支持 | `system-presence` | 白名单不含 |
| 流式响应需要 WS | `chat.send` | Agent 回复通过 WS 事件流式推送 |
| 流式响应需要 WS | `chat.abort` | 中断正在进行的 Agent 回复 |
| WS 连接保活 | `health`（心跳） | gateway.js 内置 30s 心跳 |
| Gateway 插件不支持 | `session.spawn/send`, `agent` | 白名单不含 |

---

## 九、潜在优化方向

| 优先级 | 优化项 | 方案 | 预期收益 |
|--------|-------|------|---------|
| P1 | `sessions.list` 轮询迁 HTTP | 向 OpenClaw 贡献 admin-http-rpc 插件白名单 | 消除最大 WS 阻塞源 |
| P2 | `skills.status` 轮询迁 HTTP | 同上 | 消除第二个 WS 阻塞源 |
| P3 | `system-presence` 加缓存 | 30s TTL 缓存 | 减少 /api/system/metrics 的 WS 调用 |
| P4 | `sessions.usage` 加缓存 | 60s TTL 缓存 | 减少高频用量查询的 WS 调用 |
