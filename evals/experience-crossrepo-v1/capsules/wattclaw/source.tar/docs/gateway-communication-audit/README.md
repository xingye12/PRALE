# OpenClaw Gateway 通信方式全量审计报告

> 分支：`test/http-ws-separation` | 日期：2026-05-31
> 审计范围：后端 (`server/`) 所有与 OpenClaw Gateway 的通信调用

---

## 执行摘要

| 通信方式 | 调用次数 | 占比 | 说明 |
|---------|---------|------|------|
| **WebSocket RPC** (`gateway.call`) | ~48 处 | **~95%** | 绝对主力，所有管理/控制/查询操作 |
| **HTTP REST** (`fetch` → Gateway) | **2 处** | **~5%** | 仅 `chat.history` 相关 |
| **HTTP REST** (外部 npm registry) | 1 处 | - | `registry.npmjs.org`（非 Gateway） |

**核心问题**：WS RPC 是**阻塞式**的——单条 WebSocket 连接上，Gateway 的同步 prompt 构建会阻塞后续请求，导致多用户场景下的**队头阻塞**（Head-of-Line Blocking）。

**目标**：将非聊天模块的 WS RPC 调用迁移到 HTTP REST（如果 Gateway 支持），或构建 WattClaw 侧 REST 代理层。

---

## 一、WebSocket RPC 调用清单 (`gateway.call()`)

### 1.1 后台轮询缓存（Polling Cache）

这些请求在到达时直接返回缓存数据，不触发实时 WS 调用（除非缓存为空时 fallback）。

| 缓存实例 | 间隔 | Gateway RPC 方法 | 触发场景 |
|---------|------|-----------------|---------|
| `allSessionsPolling` | 9s | `sessions.list` | `GET /api/sessions` |
| `cronListPolling` | 11s | `cron.list` | `GET /api/rpc cron.list` / 定时任务管理 |
| `modelsListPolling` | 13s | `models.list` | `GET /api/rpc models.list` / 模型管理 |
| `skillsStatusPolling` | 17s | `skills.status` | `GET /api/rpc skills.status` / 技能商店 |
| `configGetPolling` | 19s | `config.get` | `GET /api/rpc config.get` / 配置管理 |

### 1.2 REST 端点中的直接 WS RPC 调用

| 后端端点 | 代码位置 | Gateway RPC 方法 | 模式 | 说明 |
|---------|---------|-----------------|------|------|
| `POST /api/chat/send` | ~4274 | `chat.send` | **await** | 聊天发送（含 PG 本地写入） |
| `POST /api/chat/abort` | ~4309 | `chat.abort` | **fire-and-forget** | 取消生成 |
| `POST /api/workspace/send` | ~3898 | `chat.send` | **fire-and-forget** | 工作台发送 |
| `POST /api/workspace/send` | ~3916 | `sessions.patch` | **fire-and-forget** | 标题同步到 Gateway |
| `PATCH /api/config` | ~4389 | `config.patch` + `config.apply` | **await** (ConfigQueue 串行) | 配置修改 |
| `GET /api/agents/workspace` | ~2849 | `agents.list` | **await** | 获取 Agent workspace 路径 |
| `GET /api/system/metrics` | ~2741 | `system-presence` | **await** | 在线用户列表 |
| `GET /api/system/metrics` | ~2753 | `health` | **await** | Gateway 健康状态 |
| `POST /api/user/channels` | ~2208 | `config.get` + `config.patch` + `config.apply` | **await** (ConfigQueue) | 创建频道同步到 Gateway |
| `PUT /api/user/channels/:id` | ~2277 | `config.get` + `config.patch` + `config.apply` | **await** (ConfigQueue) | 更新频道同步到 Gateway |
| `DELETE /api/user/channels/:id` | ~2285 | `config.patch` + `config.apply` | **await** (ConfigQueue) | 从 Gateway 移除频道 |
| `POST /api/user/channels/sync-from-gateway` | ~2437 | `config.get` | **await** (缓存优先) | 从 Gateway 同步频道配置 |
| `POST /api/agent-team/migrate-bootstrap` | ~1646 | `agents.list` | **await** | 列出 Agent |
| `POST /api/agent-team/migrate-bootstrap` | ~1661 | `agents.files.get` | **await** | 读取 BOOTSTRAP.md |
| `POST /api/agent-team/migrate-bootstrap` | ~1670 | `agents.files.get` | **await** | 读取 USER.md |
| `POST /api/agent-team/migrate-bootstrap` | ~1682 | `agents.files.set` | **await** | 写入 USER.md |
| `POST /api/agent-team/complete-bootstrap` | ~1749 | `agents.list` | **await** | 列出 Agent |
| `GET /api/agent-team/:id/files` | ~1834 | `agents.files.get` × N | **await** (并发) | 读取 Agent 文件列表 |
| `POST /api/agent-team/repair-bootstrap` | ~1749 | `agents.list` | **await** | 列出 Agent |

### 1.3 通用 RPC 代理 `POST /api/rpc` — WS RPC 透传

所有通过 `/api/rpc` 到达后端的请求，最终都通过 `gateway.call()` 转发到 Gateway。

**按功能模块分类：**

#### Agent 管理
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `agents.list` / `agent.list` | 非管理员过滤可见 Agent | 列出 Agent |
| `agents.create` | - | 创建 Agent |
| `agents.update` | - | 更新 Agent |
| `agents.delete` | - | 删除 Agent |

#### Agent 文件
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `agents.files.list` | - | 列出 Agent workspace 文件 |
| `agents.files.get` | - | 读取 Agent 文件内容 |
| `agents.files.set` | - | 写入 Agent 文件 |

#### Session 管理
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `session.spawn` / `sessions.spawn` | 自动跟踪所有权 | 创建会话 |
| `session.send` / `sessions.send` | 自动跟踪所有权 | 发送消息到会话 |
| `sessions.reset` / `session.reset` | 所有权校验 | 重置会话 |
| `sessions.delete` / `session.delete` | 所有权校验 | 删除会话 |
| `sessions.get` / `session.get` | 所有权校验 | 获取会话详情 |
| `sessions.patch` / `session.patch` | 所有权校验 | 更新会话属性 |
| `sessions.history` / `session.history` | 所有权校验 | 获取会话历史 |
| `sessions.export` / `session.export` | 所有权校验 | 导出会话 |

#### Chat（聊天模块 — 本次不迁移）
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `chat.send` | 自动跟踪所有权 | 发送聊天消息 |
| `chat.abort` | 所有权校验 | 中止聊天 |
| `chat.history` | **已迁移到 HTTP** | 返回 410，指引使用 `GET /api/chat/history` |

#### Config 配置
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `config.get` | 非管理员脱敏 API Key | 获取完整配置 |
| `config.patch` / `config.set` | **已迁移** | 返回 410，指引使用 `PATCH /api/config` |
| `config.apply` | 管理员权限 | 应用配置变更 |

#### Cron 定时任务
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `cron.list` / `crons.list` | 按 Agent 所有权过滤 | 列出定时任务 |
| `cron.runs` / `cron.history` | 按 Agent 所有权过滤 | 查看运行记录 |
| `cron.add` / `cron.create` | Agent 所有权校验 | 创建定时任务 |
| `cron.update` / `cron.delete` / `cron.run` | Agent 所有权校验 | 更新/删除/触发 |

#### Usage 统计
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `sessions.usage` / `usage.sessions` | 非管理员过滤+重建统计 | 会话使用量 |
| `usage.cost` / `cost.usage` | 非管理员过滤+重建统计 | 费用统计 |

#### System 系统
| Gateway RPC 方法 | 权限处理 | 说明 |
|-----------------|---------|------|
| `status` | 非管理员过滤 sessions | Gateway 状态 |
| `system-presence` | - | 在线用户列表 |
| `health` | - | Gateway 健康检查 |
| `models.list` / `models.get` | 缓存返回 | 模型列表 |
| `skills.status` | 缓存返回 | 技能状态 |

#### 其他透传方法
| 场景 | 说明 |
|-----|------|
| `agent` | Agent 通用方法调用 |
| 任何未列出的方法 | **管理员直接透传**（admin passthrough） |

### 1.4 后台辅助函数中的 WS RPC

| 函数 | 文件位置 | Gateway RPC 方法 | 说明 |
|-----|---------|-----------------|------|
| `autoTitle()` | ~1081 | `chat.history` / `sessions.history` | 自动生成会话标题 |
| `syncChannelToGateway()` | ~2208 | `config.get` + `config.patch` + `config.apply` | 频道同步到 Gateway |
| `removeChannelFromGateway()` | ~2277 | `config.patch` + `config.apply` | 从 Gateway 移除频道 |
| `getAgentWorkspace()` | ~2835 | `agents.list` | 获取 Agent workspace 路径 |
| `fetchAllAgentSessions()` | ~892 | `sessions.list` (per agentId) | 并发获取多 Agent 会话 |

---

## 二、HTTP REST 调用清单 (`fetch()` → Gateway)

### 2.1 Gateway HTTP 端点调用

| 后端位置 | Gateway HTTP 端点 | 方法 | 说明 |
|---------|------------------|------|------|
| `fetchHistoryFromGateway()` ~356 | `/sessions/:sessionKey/history?limit=N` | `GET` | 后台回填（Phase 1/2 preload） |
| `GET /api/chat/history` ~4456 | `/sessions/:sessionKey/history?limit=N&cursor=X` | `GET` | 聊天历史（PG MISS 时 fallback） |

### 2.2 外部 HTTP 调用（非 Gateway）

| 后端位置 | 目标 | 方法 | 说明 |
|---------|------|------|------|
| `npmVersionsPolling` ~867 | `https://registry.npmjs.org/openclaw` | `GET` | 检查 Gateway 版本更新 |

---

## 三、通信方式对比总结

```
┌─────────────────────────────────────────────────────────────────┐
│                        通信方式分布                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  WebSocket RPC (gateway.call)  ████████████████████████████ 95% │
│  HTTP REST (fetch → Gateway)   ██                           5%  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 3.1 按功能模块的通信方式分布

| 功能模块 | WS RPC | HTTP REST | 备注 |
|---------|--------|-----------|------|
| **聊天发送/取消** | ✅ `chat.send`, `chat.abort` | ❌ | **本次不迁移** |
| **聊天历史** | ❌ (已废弃) | ✅ `GET /sessions/:key/history` | 已迁移 |
| **会话列表** | ✅ `sessions.list` | ❌ | 轮询缓存 |
| **会话管理** | ✅ `sessions.get/reset/delete/patch` | ❌ | |
| **Agent 管理** | ✅ `agents.list/create/update/delete` | ❌ | |
| **Agent 文件** | ✅ `agents.files.get/set/list` | ❌ | |
| **配置管理** | ✅ `config.get/patch/apply` | ❌ | `config.patch` 已废弃 |
| **定时任务** | ✅ `cron.list/runs/add/update/delete` | ❌ | 轮询缓存 |
| **模型/技能** | ✅ `models.list`, `skills.status` | ❌ | 轮询缓存 |
| **系统状态** | ✅ `status`, `system-presence`, `health` | ❌ | |
| **使用量统计** | ✅ `sessions.usage`, `usage.cost` | ❌ | |
| **频道同步** | ✅ `config.get/patch/apply` | ❌ | ConfigQueue 串行 |

---

## 四、阻塞风险分析

### 4.1 高阻塞风险调用（await 模式，用户等待）

这些调用会**阻塞用户请求**，直到 Gateway 返回结果：

| 调用 | 场景 | 阻塞时长 | 风险等级 |
|-----|------|---------|---------|
| `chat.send` | 发送消息 | ~1-30s | 🔴 **高**（但本次不迁移） |
| `config.patch` + `config.apply` | 修改配置 | ~1-5s | 🟡 中（ConfigQueue 已串行化） |
| `agents.files.get` | 读取 Agent 文件 | ~100ms-2s | 🟡 中 |
| `agents.files.set` | 写入 Agent 文件 | ~100ms-2s | 🟡 中 |
| `sessions.get` | 获取会话详情 | ~50ms-1s | 🟢 低 |
| `sessions.patch` | 更新会话 | ~50ms-1s | 🟢 低 |
| `agents.list` | 列出 Agent | ~50ms-500ms | 🟢 低（有缓存） |

### 4.2 低阻塞风险调用（fire-and-forget 或后台）

| 调用 | 模式 | 说明 |
|-----|------|------|
| `chat.send` (workspace) | fire-and-forget | 前端通过 SSE 接收结果 |
| `chat.abort` | fire-and-forget | 立即返回，不等待 |
| `sessions.patch` (title sync) | fire-and-forget | 标题同步，非关键 |
| 所有轮询缓存 | 后台定时 | 用户请求直接返回缓存 |

---

## 五、迁移可行性评估

### 5.1 前提条件

**Gateway HTTP API 现状**：
- ✅ `GET /sessions/:key/history` — 已确认存在，已使用
- ✅ `POST /v1/chat/completions` — 已确认存在（蓝图文档），但 WattClaw 未使用
- ❓ `GET /agents` / `GET /config` / `GET /sessions` 等 — **未确认存在**

### 5.2 迁移策略矩阵

| 策略 | 描述 | 可行性 | 工作量 |
|-----|------|--------|--------|
| **A. Gateway 原生 HTTP** | 如果 Gateway 暴露 HTTP REST 端点，直接迁移 | 依赖 Gateway | 中 |
| **B. WattClaw REST 代理** | 保持 WS RPC，但前端全部走 REST，后端代理 | ✅ 可行 | 高 |
| **C. 连接池化** | 建立多条 WS 连接，分散负载 | ✅ 可行 | 中 |
| **D. 保持现状** | 继续使用 WS RPC + 轮询缓存 | ✅ 当前状态 | - |

### 5.3 推荐迁移优先级

如果 Gateway 支持对应 HTTP 端点：

| 优先级 | 目标 | 预期收益 |
|-------|------|---------|
| P0 | `sessions.list` → `GET /sessions` | 高频调用，缓存 MISS 时阻塞 |
| P1 | `agents.list` → `GET /agents` | 中频调用，文件管理前必查 |
| P2 | `config.get` → `GET /config` | 高频调用，但有 19s 轮询缓存 |
| P3 | `agents.files.get/set` → `PUT/GET /agents/:id/files` | 中频调用，文件操作时阻塞 |
| P4 | `cron.list` → `GET /crons` | 低频调用，已有轮询缓存 |

---

## 六、相关文件

| 文件 | 说明 |
|-----|------|
| `server/index.js` | 主 Express 服务器，所有 REST 端点和 RPC 代理 |
| `server/gateway.js` | WebSocket 客户端，封装 `gateway.call()` |
| `server/utils.js` | `createPollingCache` 轮询缓存工具 |
| `docs/gateway-rpc-api.md` | Gateway 183 个 RPC 方法全量参考 |
| `docs/http-ws-separation-blueprint.md` | HTTP+WS 分离重构蓝图 |

---

## 七、下一步行动

1. **确认 Gateway HTTP API 能力**：检查 Gateway 是否暴露了 `/agents`、`/config`、`/sessions` 等 HTTP REST 端点
2. **如果 Gateway 支持**：按优先级逐步迁移 WS RPC → HTTP REST
3. **如果 Gateway 不支持**：考虑策略 B（WattClaw REST 代理层）或策略 C（WS 连接池化）
