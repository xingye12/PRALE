# 分支回退分析：HTTP 接口为什么只剩 2 个

> 日期：2026-05-31 | 分支：`test/http-ws-separation` | 91 个提交

---

## 时间线

```
05-23  最初实现（16 commits）─────────────────── HTTP 代理完整
  │    8b36a97 proxy workspace chat → Gateway HTTP SSE
  │    cb98753 workspace.ts SSE fetch
  │    494a84f session.ts + ScenarioWizard → HTTP SSE
  │    366b9cf migrate sessions.list, config.patch, chat.history to REST
  │    104b5f0 complete frontend RPC migration
  │
05-24~05-25  修 bug（10 commits）─────────────── 持续 HTTP 路径
  │    39b10ab resolve model id for Gateway HTTP
  │    72592dd fallback /api/chat/history to WS RPC
  │    8fa318e remove WS RPC fallback from /api/chat/history
  │
05-26~05-27  重构优化（8 commits）─────────────── 仍保持 HTTP
  │    67bb7da replace RPC fallback with typed REST endpoints
  │    5a0b495 create GET /api/sessions/usage BFF proxy
  │
05-28  PG 消息存储（8 commits）──────────────── 新增能力，不改路径
  │    c6be160 add pg dependency
  │    de33fa7 PostgreSQL-first read path
  │
05-29  Gateway 流解耦（10 commits）───────────── 仍保持 HTTP
  │    305c25b decouple Gateway upstream from frontend HTTP connection
  │    42c3ac7 persist assistant response to PG on stream end
  │    9da7e11 persist user message to PG
  │
05-30  ══ 关键转折：全部回退 ══════════════════ HTTP 路径被撤回
  │    fc68c6c refactor(workspace): revert sendMessage to httpPost + EventSource
  │    4687c1c refactor(backend): revert /api/workspace/send to WS RPC trigger
  │    1eec9fe chore: remove unused chat-stream-proxy service  ← 删除了 366 行
  │    24acf0e fix(backend): revert /api/workspace/send to match main branch
  │
05-31  历史分页修复（5 commits）───────────────── 与 HTTP/WS 无关
       d00d8c0 ~ 80784a8 全部修 history pagination
```

---

## 回退了什么

### 1. `/api/workspace/send` — 从 HTTP SSE 代理回退到 WS RPC

**之前（8b36a97）**：后端通过 `proxyChatToGatewayHttp()` 将聊天消息 POST 到 Gateway HTTP `/v1/chat/completions`，然后将 SSE 流 pipe 回前端。

**之后（4687c1c + 24acf0e）**：后端使用 `gateway.call('chat.send', ...)` 通过 WS RPC 触发，fire-and-forget 模式，前端通过 EventSource 接收事件。

### 2. 前端 `workspace.ts` — 从 SSE fetch 回退到 httpPost + EventSource

**之前（cb98753）**：前端直接 `fetch()` 后端 SSE 流，解析 Server-Sent Events 获取 assistant 响应。涉及 229 行改动。

**之后（fc68c6c）**：前端用 `httpPost('/api/workspace/send')` 发消息，通过独立 EventSource `/api/events` 接收事件。删掉了 217 行 SSE 解析代码。

### 3. `chat-stream-proxy.js` — 被整个删除

**之前（d6867f1 创建）**：独立的 TypeScript 服务，负责代理 Gateway HTTP SSE 流，带超时控制。366 行。

**之后（1eec9fe）**：整个文件删除。

### 4. 前端 session.ts / ScenarioWizard — 部分回退

**之前（494a84f）**：`session.ts` 和 `ScenarioWizard.vue` 也走 HTTP SSE 聊天路径。

**之后**：这些场景的聊天发送也回到 WS RPC 通道。

---

## 保留了什么

以下改动**没有被回退**，仍然在分支上：

| 改动 | 说明 | 提交 |
|------|------|------|
| **PostgreSQL 消息存储** | `message-store.js` + `backfill-queue.js` | c6be160 ~ 0614d7e |
| **控制面 REST 端点** | `GET /api/sessions`、`PATCH /api/config`、`GET /api/chat/history` | 366b9cf |
| **轮询缓存优化** | `createPollingCache` 惰性刷新 | d99294f ~ 5820930 |
| **Gateway 流与前端解耦** | 前端断开不终止 Agent | 305c25b |
| **Usage REST 端点** | `GET /api/sessions/usage` BFF 代理 | 5a0b495 |
| **RPC 方法废弃** | `sessions.list` → 410、`config.patch` → 410、`chat.history` → 410 | 104b5f0 |

---

## 为什么回退

从提交历史和记忆文件推断：

1. **Gateway HTTP SSE 单 turn 限制**：Gateway 的 `/v1/chat/completions` 在复杂任务（多 turn、工具调用）中表现不稳定，可能在中途断流
2. **前端 SSE 解析复杂度高**：需要自己处理 SSE chunk 解析、重连、事件分发，增加了 229 行复杂代码
3. **`chat-stream-proxy.js` 的存在本身就说明问题**：需要一个独立服务来处理超时、连接管理等边界情况
4. **最终决策**：保留 HTTP 用于非聊天操作（`GET /api/chat/history`、`GET /api/sessions`），聊天发送回退到 WS RPC（简单可靠）

---

## 当前状态

| 层 | 通信方式 | 说明 |
|----|---------|------|
| 前端 → 后端 | **HTTP REST** | 绝大部分已迁移为 REST 端点 |
| 后端 → Gateway（聊天） | **WS RPC** | fire-and-forget，经 SSE 转发 |
| 后端 → Gateway（历史） | **HTTP fetch** | `GET /sessions/:key/history` |
| 后端 → Gateway（其他） | **WS RPC** | 通过轮询缓存 + ConfigQueue |

**所以回答原始问题**：不是「大部分接口变成了 HTTP 后又只剩 2 个」。而是：

- **前端 → 后端**的接口大部分已转为 HTTP REST ✅（这个没回退）
- **后端 → Gateway**的 HTTP 代理（`/v1/chat/completions`）被回退了 ❌
- 保留的是 Gateway 原生 HTTP 端点 `GET /sessions/:key/history`
