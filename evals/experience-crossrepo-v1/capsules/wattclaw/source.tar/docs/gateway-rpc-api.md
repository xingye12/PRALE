# OpenClaw Gateway RPC API 参考

> 基于 OpenClaw v2026.4.21，从 `server.impl-DLF59fRo.js` 源码提取。
> 包含约 183 个 RPC 方法，按功能模块分类整理。

---

## 1. Agent 管理

创建、更新、删除和查询 Agent。

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `agents.create` | 创建 Agent。支持 `name`、`workspace`、`model`、`emoji`、`avatar` 参数，内部原子写入 config | ✅ |
| `agents.update` | 更新 Agent 属性。支持 `agentId`、`name`、`model`、`emoji`、`avatar`、`workspace`、`subagents`、`tools`（顶层参数，非嵌套 identity） | ✅ |
| `agents.delete` | 删除 Agent。参数 `{ agentId }`，返回 `{ agentId, removedBindings }` | ✅ |
| `agents.list` | 列出所有 Agent | ✅ |
| `agents.defaults.heartbeat` | 获取/设置 Agent 默认心跳间隔 | |
| `agents.defaults.model` | 获取/设置 Agent 默认模型 | |
| `agents.defaults.models` | 获取/设置 Agent 默认模型（复数形式） | |

## 2. Agent 文件

读写 Agent workspace 中的文件。

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `agents.files.list` | 列出 Agent workspace 文件 | ✅ |
| `agents.files.get` | 读取 Agent workspace 文件内容 | ✅ |
| `agents.files.set` | 写入 Agent workspace 文件 | ✅ |

## 3. Agent 运行时

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `agent.heartbeat` | Agent 心跳 | |
| `agent.identity.get` | 获取 Agent identity 信息 | |
| `agent.wait` | 等待 Agent 就绪 | |

## 4. Session / 对话管理

管理对话会话。

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `sessions.create` | 创建会话 | |
| `sessions.list` | 列出所有会话 | ✅ |
| `sessions.get` | 获取单个会话详情 | ✅ |
| `sessions.delete` | 删除会话 | ✅ |
| `sessions.reset` | 重置会话 | ✅ |
| `sessions.send` | 发送消息到会话 | |
| `sessions.patch` | 更新会话属性 | ✅ |
| `sessions.abort` | 中止当前会话操作 | ✅ |
| `sessions.resolve` | 解析会话引用 | |
| `sessions.steer` | 引导/控制会话方向 | |
| `sessions.subscribe` | 订阅会话事件 | |
| `sessions.unsubscribe` | 取消订阅会话事件 | |
| `sessions.changed` | 会话变更通知 | |
| `sessions.usage` | 获取会话使用量 | ✅ |
| `sessions.usage.logs` | 获取会话使用日志 | |
| `sessions.usage.timeseries` | 获取会话使用时序数据 | |
| `sessions.preview` | 预览会话 | |
| `session.tool` | 会话工具调用 | |
| `session.message` | 会话消息事件 | |

### Session 压缩 (Compaction)

| 方法 | 说明 |
|------|------|
| `sessions.compact` | 压缩会话上下文 |
| `sessions.compaction.list` | 列出压缩记录 |
| `sessions.compaction.get` | 获取压缩详情 |
| `sessions.compaction.branch` | 压缩分支操作 |
| `sessions.compaction.restore` | 恢复压缩状态 |

### Session 消息订阅

| 方法 | 说明 |
|------|------|
| `sessions.messages.subscribe` | 订阅会话消息流 |
| `sessions.messages.unsubscribe` | 取消订阅会话消息流 |

## 5. Chat

直接对话接口（不绑定 session）。

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `chat.send` | 发送聊天消息 | ✅ |
| `chat.history` | 获取聊天历史 | ✅ |
| `chat.abort` | 中止聊天 | ✅ |

## 6. Config 配置管理

读写 Gateway 配置（openclaw.json）。

| 方法 | 说明 | WattClaw 使用 | 备注 |
|------|------|:---:|------|
| `config.get` | 获取完整配置 | ✅ | 返回全量 openclaw.json + hash |
| `config.patch` | 增量修改配置（RFC 7396 Merge Patch） | ✅ | 需要 baseHash 做 OCC |
| `config.set` | 全量覆盖配置 | ✅ | 有 100KB body 限制，不建议使用 |
| `config.apply` | 应用配置变更 | ✅ | |
| `config.schema` | 获取配置 schema | | |
| `config.schema.lookup` | 查询特定路径的 schema | | |
| `config.snapshot` | 获取配置快照 | | |
| `config.auth` | 配置鉴权信息 | | |

## 7. Cron 定时任务

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `cron.add` | 添加定时任务 | ✅ |
| `cron.list` | 列出定时任务 | ✅ |
| `cron.update` | 更新定时任务 | ✅ |
| `cron.remove` | 删除定时任务 | ✅ |
| `cron.run` | 手动触发定时任务 | ✅ |
| `cron.runs` | 获取定时任务执行记录 | ✅ |
| `cron.status` | 获取定时任务状态 | |

## 8. Models 模型

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `models.list` | 列出可用模型（含 provider、context window、capabilities） | ✅ |

## 9. Tools 工具

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `tools.catalog` | 获取工具目录 | |
| `tools.effective` | 获取生效的工具列表 | |

## 10. Node 节点管理

管理连接到 Gateway 的节点（设备）。

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `node.list` | 列出节点 | |
| `node.describe` | 获取节点描述 | |
| `node.invoke` | 在节点上调用方法 | |
| `node.invoke.request` | 节点调用请求 | |
| `node.invoke.result` | 节点调用结果 | |
| `node.event` | 节点事件 | |
| `node.rename` | 重命名节点 | |
| `node.canvas.capability.refresh` | 刷新节点画布能力 | |

### Node 配对

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `node.pair.request` | 请求配对 | ✅ |
| `node.pair.approve` | 批准配对 | ✅ |
| `node.pair.reject` | 拒绝配对 | |
| `node.pair.verify` | 验证配对 | |
| `node.pair.list` | 列出配对请求 | |
| `node.pair.requested` | 配对请求事件 | |
| `node.pair.resolved` | 配对结果事件 | |

### Node 待处理消息

| 方法 | 说明 |
|------|------|
| `node.pending` | 获取待处理消息 |
| `node.pending.ack` | 确认待处理消息 |
| `node.pending.drain` | 排空待处理消息 |
| `node.pending.enqueue` | 入队待处理消息 |
| `node.pending.pull` | 拉取待处理消息 |

## 11. Device 设备

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `device.pair.requested` | 设备配对请求事件 | |
| `device.pair.resolved` | 设备配对结果事件 | |
| `device.pair.approve` | 批准设备配对 | |
| `device.pair.list` | 列出设备配对 | |
| `device.pair.reject` | 拒绝设备配对 | |
| `device.pair.remove` | 移除设备配对 | |
| `device.token.revoke` | 撤销设备令牌 | |
| `device.token.rotate` | 轮换设备令牌 | |

## 12. Gateway 网关

| 方法 | 说明 |
|------|------|
| `gateway.identity.get` | 获取 Gateway identity |
| `gateway.reload` | 重载 Gateway |
| `gateway.remote` | 远程 Gateway 操作 |

## 13. Status 状态

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `status.request` | 请求系统状态 | ✅ |

## 14. Usage 用量

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `usage.cost` | 获取用量成本 | ✅ |
| `usage.status` | 获取用量状态 | |

## 15. Secrets 密钥

| 方法 | 说明 |
|------|------|
| `secrets.resolve` | 解析密钥 |
| `secrets.reload` | 重载密钥 |

## 16. Skills 技能

| 方法 | 说明 |
|------|------|
| `skills.status` | 技能状态 |
| `skills.search` | 搜索技能 |
| `skills.install` | 安装技能 |
| `skills.update` | 更新技能 |
| `skills.detail` | 技能详情 |
| `skills.bins` | 技能可执行文件 |

## 17. 执行审批

| 方法 | 说明 |
|------|------|
| `exec.approval.request` | 请求执行审批 |
| `exec.approval.resolve` | 处理执行审批 |
| `exec.approval.get` | 获取执行审批 |
| `exec.approval.list` | 列出执行审批 |
| `exec.approval.requested` | 执行审批请求事件 |
| `exec.approval.resolved` | 执行审批结果事件 |
| `exec.approvals.get` | 获取审批配置 |
| `exec.approvals.set` | 设置审批配置 |
| `exec.approvals.node.get` | 获取节点审批配置 |
| `exec.approvals.node.set` | 设置节点审批配置 |

## 18. Plugin 插件

| 方法 | 说明 |
|------|------|
| `plugins.bootstrap` | 插件引导 |
| `plugin.approval.request` | 请求插件审批 |
| `plugin.approval.resolve` | 处理插件审批 |
| `plugin.approval.list` | 列出插件审批 |
| `plugin.approval.requested` | 插件审批请求事件 |
| `plugin.approval.resolved` | 插件审批结果事件 |

## 19. TTS 语音合成

| 方法 | 说明 |
|------|------|
| `tts.convert` | 文本转语音 |
| `tts.enable` | 启用 TTS |
| `tts.disable` | 禁用 TTS |
| `tts.status` | TTS 状态 |
| `tts.providers` | TTS 提供者列表 |

## 20. Talk 语音对话

| 方法 | 说明 |
|------|------|
| `talk.config` | 语音对话配置 |
| `talk.mode` | 语音对话模式 |
| `talk.speak` | 语音播报 |

## 21. Sidecar 侧车进程

| 方法 | 说明 |
|------|------|
| `sidecars.channels` | 侧车通道 |
| `sidecars.memory` | 侧车内存 |
| `sidecars.ready` | 侧车就绪状态 |
| `sidecars.total` | 侧车总数 |

## 22. Session 压缩相关

| 方法 | 说明 |
|------|------|
| `sessions.compaction.branch` | 压缩分支 |
| `sessions.compaction.get` | 获取压缩详情 |
| `sessions.compaction.list` | 压缩列表 |
| `sessions.compaction.restore` | 恢复压缩 |

## 23. 运维 / 系统

| 方法 | 说明 |
|------|------|
| `system.run` | 执行系统命令 |
| `runtime.config` | 运行时配置 |
| `runtime.early` | 运行时早期初始化 |
| `runtime.state` | 运行时状态 |
| `logs.tail` | 实时日志 |
| `doctor.memory.status` | 内存诊断 |
| `update.available` | 检查更新 |
| `update.run` | 执行更新 |
| `gateway.reload` | 重载 Gateway |

## 24. 浏览器 / 画布

| 方法 | 说明 |
|------|------|
| `browser.proxy` | 浏览器代理 |
| `canvas.navigate` | 画布导航 |
| `canvas.present` | 画布展示 |

## 25. Channel 频道

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `channels.start` | 启动频道 | |
| `channels.logout` | 频道登出 | |
| `channels.status` | 频道状态 | |

## 26. 连接 / 认证

| 方法 | 说明 | WattClaw 使用 |
|------|------|:---:|
| `connect.challenge` | 连接挑战（Ed25519 认证） | ✅ |
| `web.login.start` | Web 登录开始 | |
| `web.login.wait` | Web 登录等待 | |

## 27. Operator 运维操作

| 方法 | 说明 |
|------|------|
| `operator.admin` | 管理员操作 |
| `operator.read` | 读取操作 |
| `operator.write` | 写入操作 |
| `operator.approvals` | 审批操作 |
| `operator.talk.secrets` | 语音密钥 |

## 28. Wizard 向导

| 方法 | 说明 |
|------|------|
| `wizard.start` | 启动向导 |
| `wizard.next` | 向导下一步 |
| `wizard.cancel` | 取消向导 |
| `wizard.status` | 向导状态 |

## 29. 其他

| 方法 | 说明 |
|------|------|
| `commands.list` | 列出可用命令 |
| `approval.native` | 原生审批 |
| `delivery.channel` | 消息投递通道 |
| `hooks.gmail` | Gmail 钩子 |
| `http.bound` | HTTP 绑定 |
| `message.action` | 消息动作 |
| `push.test` | 推送测试 |
| `dreams.md` | Dreams Markdown |
| `voicewake.get` | 语音唤醒获取 |
| `voicewake.set` | 语音唤醒设置 |
| `voicewake.json` | 语音唤醒 JSON |
| `voicewake.changed` | 语音唤醒变更 |
| `hw.model` | 硬件型号 |
| `tls.runtime` | TLS 运行时 |

## 30. Demo

| 方法 | 说明 |
|------|------|
| `demo.hello` | Hello World |
| `demo.time` | 当前时间 |
| `demo.dalek` | Dalek Demo |
| `demo.photo` | 照片 Demo |

---

## 关键设计模式

### agents.create 参数

```json
{
  "name": "agent-1234567890",
  "workspace": "~/.wattclaw/user-folder/agent-workspace",
  "model": "minimax/MiniMax-M2.7",
  "emoji": "🤖",
  "avatar": "https://example.com/avatar.png"
}
```

Gateway 内部通过 `applyAgentConfig()` 原子写入 agents.list，无需客户端做 config.get/patch。

### agents.update 参数

```json
{
  "agentId": "agent-1234567890",
  "name": "显示名称",
  "model": "openai/gpt-5.4",
  "emoji": "🤖",
  "avatar": "https://example.com/avatar.png",
  "workspace": "~/.new/workspace",
  "subagents": { "allowAgents": [], "denyAgents": [] },
  "tools": { "allow": [], "deny": [] }
}
```

注意：`emoji`、`avatar` 是顶层参数，不是嵌套在 `identity` 里。

### config.patch 语义

使用 RFC 7396 JSON Merge Patch 格式，需要 `baseHash` 做乐观并发控制（OCC）。多用户并发时容易冲突，建议优先使用原子接口（如 `agents.create`/`agents.update`）。

### 方法名复数/单数约定

Gateway 同时支持单数和复数形式（如 `session.list` / `sessions.list`），WattClaw 后端有归一化逻辑。
