# Hermes 引擎开关 — 完整实现规格说明书

> **版本**: 1.0  
> **适用版本**: OpenClaw 2026.5.28+, openclaw-plugin-hermes 2.0.1  
> **基于源码**: `harness.js`, `index.js`, `runtime-client.js`, `context-assembler.js`, `acp-client.js`, `harness-hook.js`, `config.js`, `types.js`, `execenv-builder.js`  
> **最后更新**: 2026-08-04

---

## 目录

1. [概述：开关到底做了什么](#1-概述开关到底做了什么)
2. [架构全景图](#2-架构全景图)
3. [阶段 0：系统启动 — 插件注册](#3-阶段-0系统启动--插件注册)
4. [阶段 1：用户打开开关 — 模型切换](#4-阶段-1用户打开开关--模型切换)
5. [阶段 2：用户发送消息 — 运行时全流程](#5-阶段-2用户发送消息--运行时全流程)
6. [阶段 3：技能分类与投影策略](#6-阶段-3技能分类与投影策略)
7. [阶段 4：ACP 通信协议](#7-阶段-4acp-通信协议)
8. [阶段 5：结果回收与钩子](#8-阶段-5结果回收与钩子)
9. [数据模型](#9-数据模型)
10. [配置参考](#10-配置参考)
11. [故障排查](#11-故障排查)

---

## 1. 概述：开关到底做了什么

当用户打开"使用 Hermes 执行任务"开关后，**并不是把 OpenClaw 进程替换成 Hermes**，而是做了两件事：

### 1.1 模型层切换

```json
// 开关关闭 → 用 OpenClaw 内置引擎
"model": { "primary": "agent_plan/默认模型" }

// 开关打开 → 切换到 Hermes provider
"model": { "primary": "hermes/default" }
```

### 1.2 运行时层切换

`hermes/default` 模型在配置中声明了 `agentRuntime: { id: "hermes" }`，这会触发 OpenClaw 的 runtime 选择逻辑使用 `openclaw-plugin-hermes` 注册的 **Agent Harness**，把整个 agent 回环（思考 → 工具调用 → 生成回复）交给 Hermes 容器执行。

### 1.3 关键区别

| | 开关关闭 | 开关打开 |
|---|---|---|
| 模型回环拥有者 | OpenClaw 内置引擎 | Hermes 容器（通过 ACP） |
| 模型调用 | agent_plan provider | Hermes 内部模型（默认模型） |
| 工具执行 | OpenClaw 进程内 | Hermes 容器内 |
| 技能加载 | 系统 prompt 注入 + 按需 read | 投影到 Hermes 临时目录 |
| OpenClaw 进程 | 运行中 | **仍然运行中**（做桥接/路由） |

---

## 2. 架构全景图

```
┌──────────────────────────────────────────────────────────────────────┐
│                        OpenClaw 进程 (始终运行)                         │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │  Gateway (消息路由层)                                          │     │
│  │  • 接收用户消息                                                │     │
│  │  • 检查 session 模型 → hermes/default                          │     │
│  │  • 触发 agentRuntime 选择逻辑                                   │     │
│  └──────────────────────────┬──────────────────────────────────┘     │
│                             │                                         │
│  ┌──────────────────────────▼──────────────────────────────────┐     │
│  │  Agent Harness 框架                                            │     │
│  │  • 遍历所有已注册的 harness                                    │     │
│  │  • 调用 supports({ provider: "hermes" })                       │     │
│  │  • hermes harness → { supported: true, priority: 100 }         │     │
│  └──────────────────────────┬──────────────────────────────────┘     │
│                             │                                         │
│  ┌──────────────────────────▼──────────────────────────────────┐     │
│  │  openclaw-plugin-hermes                                       │     │
│  │                                                               │     │
│  │  ┌─────────────┐  ┌──────────────┐  ┌───────────────────┐   │     │
│  │  │ Provider    │  │ Harness      │  │ Tools (4个)        │   │     │
│  │  │ 注册 hermes │  │ runAttempt() │  │ hermes_dispatch   │   │     │
│  │  │ 模型源      │  │ 是整个引擎   │  │ hermes_status     │   │     │
│  │  │            │  │ 切换的入口    │  │ hermes_strategy   │   │     │
│  │  └─────────────┘  └──────┬───────┘  │ hermes_cancel     │   │     │
│  │                          │          └───────────────────┘   │     │
│  │                          ▼                                   │     │
│  │  ┌───────────────────────────────────────────────────┐      │     │
│  │  │  Runtime Client (runtime-client.js)                │      │     │
│  │  │                                                    │      │     │
│  │  │  prepareProjectedExecutionEnv()                     │      │     │
│  │  │  ├─ assembleProjectedContext()   组装上下文          │      │     │
│  │  │  ├─ resolveSkillsFromSnapshot()  技能分类           │      │     │
│  │  │  ├─ buildExecEnv()              创建临时目录        │      │     │
│  │  │  └─ serializeProjectedContextForPrompt() 生成提示词  │      │     │
│  │  └───────────────────────┬───────────────────────────┘      │     │
│  │                          │                                   │     │
│  │                          ▼                                   │     │
│  │  ┌───────────────────────────────────────────────────┐      │     │
│  │  │  ACP Client (acp-client.js)                        │      │     │
│  │  │  • TCP 连接 127.0.0.1:3100                         │      │     │
│  │  │  • JSON-RPC 2.0 over NDJSON                        │      │     │
│  │  │  • session/new → session/prompt → 流式事件           │      │     │
│  │  └───────────────────────┬───────────────────────────┘      │     │
│  └──────────────────────────┼──────────────────────────────────┘     │
│                             │ ACP (TCP)                              │
└─────────────────────────────┼──────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Docker 容器: hermes-agent                                             │
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐    │
│  │  Hermes Agent                                                  │    │
│  │                                                                │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐    │    │
│  │  │ Terminal     │  │ Browser      │  │ Code Execution  │    │    │
│  │  │ (shell 命令) │  │ (Playwright) │  │ (沙箱化执行)     │    │    │
│  │  └──────────────┘  └──────────────┘  └──────────────────┘    │    │
│  │                                                                │    │
│  │  ┌──────────────────────────────────────────────────────┐    │    │
│  │  │ 投影执行环境 (/tmp/openclaw-hermes-execenv/<hash>/)     │    │    │
│  │  │                                                       │    │    │
│  │  │  projection.json          ← 投影元数据                  │    │    │
│  │  │  workspace/               ← 投影的上下文文件            │    │    │
│  │  │  ├── SOUL.md                                          │    │    │
│  │  │  ├── USER.md                                          │    │    │
│  │  │  ├── AGENTS.md                                        │    │    │
│  │  │  ├── MEMORY.md                                        │    │    │
│  │  │  └── skills/              ← 投影的技能 (projectable)    │    │    │
│  │  │      ├── grammar/SKILL.md                              │    │    │
│  │  │      ├── humanizer/SKILL.md                            │    │    │
│  │  │      └── ...                                          │    │    │
│  │  └──────────────────────────────────────────────────────┘    │    │
│  └──────────────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 3. 阶段 0：系统启动 — 插件注册

### 3.1 插件入口 (`index.js`)

OpenClaw 启动时加载 `openclaw-plugin-hermes`，调用 `register(api)`：

```typescript
const plugin = {
  id: "openclaw-plugin-hermes",
  name: "Hermes Agent",
  register(api) {
    // ① 注册模型 Provider —— 让 OpenClaw 知道 "hermes" 这个模型源
    api.registerProvider(buildHermesProvider({ pluginConfig }));

    // ② 注册 Agent Harness —— 声明"hermes 的模型由我来驱动"
    //    ★ 这是引擎切换的核心
    api.registerAgentHarness(createHermesAgentHarness({ pluginConfig }));

    // ③ 注册 4 个工具
    api.registerTool({ name: "hermes_dispatch", ... });  // 任务委派
    api.registerTool({ name: "hermes_status", ... });    // 健康检查
    api.registerTool({ name: "hermes_strategy", ... });  // 策略预览
    api.registerTool({ name: "hermes_cancel", ... });    // 取消任务

    // ④ 注册信号处理（SIGINT/SIGTERM 时取消所有活跃任务）
    process.once("SIGINT", cleanupHandler);
    process.once("SIGTERM", cleanupHandler);
  }
};
```

### 3.2 Agent Harness 注册 (`harness.js`)

```typescript
export function createHermesAgentHarness(options) {
  const providerIds = new Set(["hermes"]);  // 只认 "hermes" 这个 provider

  return {
    id: "hermes",
    label: "Hermes agent harness",

    // ★ 运行时选择逻辑：OpenClaw 每次发消息前会调用
    supports: (ctx) => {
      if (providerIds.has(ctx.provider.trim().toLowerCase())) {
        return { supported: true, priority: 100 };
      }
      return { supported: false, reason: "provider is not hermes" };
    },

    // ★ 核心入口：OpenClaw 把整个 agent attempt 交给这里
    runAttempt: async (params) => {
      // 创建 Hermes runtime 客户端
      const client = createHermesRuntimeClient({ config });
      // 把整个 attempt 发给 Hermes 容器
      const response = await client.runAttempt(params);
      // 把 Hermes 的响应转成 OpenClaw 的标准格式
      return buildHermesAttemptResult(params, response);
    },

    // 重置会话绑定（清理）
    reset: async (params) => {
      if (params.sessionFile) {
        await clearHermesHarnessBinding(params.sessionFile);
      }
    },
  };
}
```

---

## 4. 阶段 1：用户打开开关 — 模型切换

### 4.1 配置变更

开关打开时，session 的模型从 `agent_plan/原来的模型` 切换为 `hermes/default`。

### 4.2 模型解析

`hermes/default` 在 `openclaw.json` 中的配置：

```json
{
  "models": {
    "providers": {
      "hermes": {
        "baseUrl": "http://127.0.0.1/hermes-runtime",
        "apiKey": "***",
        "api": "openai-responses",
        "agentRuntime": { "id": "hermes" }     // ← 指定 runtime
      }
    }
  },
  "agents": {
    "defaults": {
      "models": {
        "hermes/default": {
          "alias": "hermes",
          "agentRuntime": { "id": "hermes" }   // ← 模型级 runtime
        }
      }
    }
  }
}
```

### 4.3 插件配置

```json
{
  "plugins": {
    "entries": {
      "openclaw-plugin-hermes": {
        "enabled": true,
        "config": {
          "hermesContainerName": "hermes-agent",
          "defaultModel": "某个默认模型",
          "defaultContextLevel": "L3",
          "runtimeMinContextLevel": "L3",
          "runtimeProjectWorkspaceSkills": true,
          "transport": "tcp",
          "tcpHost": "127.0.0.1",
          "tcpPort": 3100,
          "timeout": 1800,
          "enableLayeredProtocol": true,
          "autoStrategy": true,
          "skillProjection": {
            "hostBackedDenylist": ["browser", "browser-use", "feishu"],
            "hostBackedSkillNames": [
              "browser", "browser-use", "feishu",
              "lark-doc", "lark-calendar", "lark-im", "lark-sheets",
              "lark-base", "lark-drive", "lark-task", "lark-mail",
              "arkdrive-netdisk", "workspace-netdrive"
            ],
            "containerEnvSkillNames": [],
            "alwaysExposeSkillNames": [
              "browser-use", "computer-use",
              "byted-web-search", "byted-seedream-image-generate",
              "byted-seedance-video-generate", "opencli",
              "arkdrive-netdisk", "web_search"
            ]
          },
          "mcpBridge": { "enabled": true }
        }
      }
    }
  }
}
```

---

## 5. 阶段 2：用户发送消息 — 运行时全流程

这是整个系统的核心。当用户发送一条消息，且 session 模型为 `hermes/default` 时：

```
用户消息 "帮我写一个 Python 脚本，分析 CSV 数据"
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 1: Runtime 选择                                              │
│ ────────────────                                                  │
│ OpenClaw Gateway 检查 session 模型 → hermes/default               │
│ 解析 agentRuntime → { id: "hermes" }                              │
│ 遍历所有 harness → 调用 supports({ provider: "hermes" })           │
│ → hermes harness: { supported: true, priority: 100 }              │
│ → 选择 hermes harness                                             │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 2: 准备投影执行环境 (prepareProjectedExecutionEnv)             │
│ ────────────────────────────────────────────────────              │
│                                                                   │
│ 2a. 组装上下文 (assembleProjectedContext)                          │
│     L3 级别包含:                                                   │
│     • SOUL.md, USER.md, AGENTS.md    (身份/工作区指令)              │
│     • MEMORY.md + memory/YYYY-MM-DD.md (记忆)                      │
│     • 任务描述 ("帮我写一个 Python 脚本...")                        │
│     • command allowlist (exec-approvals.json)                     │
│     • 技能列表 (skills manifest)                                   │
│                                                                   │
│ 2b. 技能分类 (resolveSkillsFromSnapshot)                           │
│     遍历所有技能，调用 classifySkill() 分为四类:                     │
│     • projectable-local → 复制 SKILL.md 到 Hermes 容器             │
│     • host-backed      → 不投影，给 MCP 工具提示                    │
│     • container-env    → 投影但要检查环境变量                       │
│     • unsupported      → 跳过                                      │
│                                                                   │
│ 2c. 创建执行环境 (buildExecEnv)                                    │
│     在 /tmp/openclaw-hermes-execenv/<hash>/ 创建目录结构:           │
│     ├── projection.json         (投影元数据)                        │
│     └── workspace/                                               │
│         ├── SOUL.md                                               │
│         ├── USER.md                                               │
│         ├── AGENTS.md                                             │
│         ├── MEMORY.md                                             │
│         └── skills/                                               │
│             ├── grammar/SKILL.md                                  │
│             ├── humanizer/SKILL.md                                │
│             └── ... (projectable-local 技能)                       │
│                                                                   │
│ 2d. 生成 bootstrap prompt (serializeProjectedContextForPrompt)     │
│     把所有上下文 + 技能列表 + MCP 工具提示 + 对话历史 + 运行时契约    │
│     组装成一个完整的 prompt 文本                                    │
│                                                                   │
│ 2e. 计算 session binding hash                                      │
│     基于 workspace + skills + mcp config + credential scope        │
│     的 SHA256 哈希，用于 session 复用                               │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 3: ACP 通信 (acp-client.js)                                   │
│ ─────────────────────────────                                      │
│                                                                   │
│ 3a. TCP 连接                                                       │
│     → 连接 127.0.0.1:3100 (Hermes 容器内的 ACP bridge)              │
│                                                                   │
│ 3b. ACP 初始化                                                     │
│     → initialize({ protocol_version: 1, client_info: {...} })      │
│                                                                   │
│ 3c. 创建/复用 session                                             │
│     → 检查 session binding: 相同 hash 复用已有 session              │
│     → 否则 session/new → 获取 sessionId                           │
│                                                                   │
│ 3d. 发送 prompt                                                    │
│     → session/prompt({ sessionId, prompt: bootstrapPrompt })       │
│                                                                   │
│ 3e. 流式接收事件 (NDJSON)                                          │
│     → text        : LLM 生成的文本块                                │
│     → thinking    : 思考过程                                       │
│     → tool_progress : 工具调用开始                                  │
│     → tool_result : 工具执行结果                                    │
│     → done        : 任务完成                                       │
│     → error       : 错误                                          │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 4: Hermes 容器内执行                                          │
│ ────────────────────────                                           │
│                                                                   │
│ Hermes 拿到 bootstrap prompt 后:                                   │
│                                                                   │
│ 4a. LLM 推理                                                       │
│     → 使用配置的模型理解任务                    │
│                                                                   │
│ 4b. 工具调用                                                       │
│     → 需要执行 shell → 调用 Hermes 原生 terminal                    │
│     → 需要浏览器   → 调用 Hermes 原生 Playwright                    │
│     → 需要读 SKILL  → 读投影目录中的 SKILL.md                       │
│     → 需要飞书操作 → 调用 MCP 工具 (mcp_openclaw_feishu_*)          │
│     → 需要网盘操作 → 调用 MCP 工具 (mcp_openclaw_arkdrive_*)        │
│                                                                   │
│ 4c. 工具结果回传                                                   │
│     → 每次工具调用结果通过 ACP 流式返回                               │
│     → 触发 OpenClaw 侧的 before/after_tool_call 钩子                │
│                                                                   │
│ 4d. 循环直到完成                                                   │
│     → LLM 推理 → 工具调用 → 结果 → 再推理 → ... → 最终回复           │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 5: 结果回收 (buildHermesAttemptResult)                        │
│ ──────────────────────────────────────────                         │
│                                                                   │
│ 5a. 提取 Hermes 响应                                               │
│     • assistantTexts : 回复文本                                    │
│     • toolMetas      : 工具调用元数据                               │
│     • usage          : token 消耗统计                              │
│     • lastAssistant  : 最后一条 assistant 消息                      │
│     • messagesSnapshot : 完整消息快照                               │
│                                                                   │
│ 5b. 转换为 OpenClaw 标准格式                                       │
│     → 填充到 AttemptResult 结构中                                   │
│     → 标记 replaySafe / hadPotentialSideEffects                    │
│     → 返回给 OpenClaw Gateway                                      │
│                                                                   │
│ 5c. Gateway 发送回复给用户                                          │
│     → 通过当前 channel (webchat) 返回                               │
│                                                                   │
│ 5d. 持久化 session binding                                        │
│     → 写入 ~/.openclaw/hermes/session-bindings.json                │
│     → 下次相同 hash 的消息可复用 session                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. 阶段 3：技能分类与投影策略

### 6.1 分类逻辑 (`runtime-client.js`)

```typescript
function classifySkill(params) {
  const normalized = normalizeSkillName(params.name);

  // ① host-backed: 依赖 OpenClaw 进程状态
  if (hostBackedNames.has(normalized) || isFeishuOrLarkSkillName(normalized)) {
    return {
      classification: "host-backed",
      placement: "host-backed",
      mcpTool: "mcp_openclaw_browser",  // 具体 MCP 工具名
      mcpToolHint: "Use the OpenClaw MCP ...",
    };
  }

  // ② container-env-required: 需要特定环境变量
  if (containerEnvNames.has(normalized)) {
    return {
      classification: "container-env-required",
      placement: "container-env-required",
      requiredEnv: ["WEB_SEARCH_API_KEY", "VOLCENGINE_ACCESS_KEY", ...],
    };
  }

  // ③ projectable-local: 纯指令型技能，可投影
  if (params.sourcePath?.endsWith("/SKILL.md")) {
    return {
      classification: "projectable-local",
      placement: "projected-local",
    };
  }

  // ④ unsupported
  return {
    classification: "unsupported",
    placement: "unsupported",
    diagnostics: [`${params.name}: missing readable SKILL.md path`],
  };
}
```

### 6.2 分类结果示例

| 技能 | 分类 | 投影方式 | Hermes 如何用 |
|---|---|---|---|
| Grammar | projectable-local | 复制 SKILL.md 到容器 | 读 SKILL.md，用 Hermes 自己的工具执行 |
| humanizer | projectable-local | 复制 SKILL.md 到容器 | 同上 |
| copywriter | projectable-local | 复制 SKILL.md 到容器 | 同上 |
| browser-use | host-backed | 不投影 | 调用 `mcp_openclaw_browser` |
| feishu-lark-cli | host-backed | 不投影 | 调用 `mcp_openclaw_feishu_*` |
| computer-use | host-backed | 不投影 | 调用 `mcp_openclaw_computer_use` |
| byted-web-search | host-backed | 不投影 | 调用 `mcp_openclaw_byted_web_search` |
| arkdrive-netdisk | host-backed | 不投影 | 调用 `mcp_openclaw_arkdrive_netdisk` |
| 未知技能 (无 SKILL.md) | unsupported | 跳过 | 不可用 |

### 6.3 Bootstrap Prompt 中的运行时契约

```markdown
# Runtime Contract
Projected runtime cwd: /tmp/openclaw-hermes-execenv/abc123/workspace
Projected manifest path: /tmp/openclaw-hermes-execenv/abc123/projection.json

Only use the skills listed under # Available OpenClaw Skills as
OpenClaw-provided capabilities.

When a projected-local or container-env-required skill matches the task,
read its runtime SKILL.md first and resolve relative references against
that skill directory.

When a host-backed skill matches the task, call the listed concrete
OpenClaw MCP tool or tool family instead of running host-specific CLIs
inside the container.

Do not call `openclaw.skill.invoke`; Hermes must use the actual MCP
tools exposed by tools/list.
```

---

## 7. 阶段 4：ACP 通信协议

### 7.1 协议栈

```
┌──────────────────────────────────┐
│  JSON-RPC 2.0                    │  ← 方法调用格式
├──────────────────────────────────┤
│  NDJSON (Newline-Delimited JSON)  │  ← 每行一个 JSON 对象
├──────────────────────────────────┤
│  TCP (127.0.0.1:3100)            │  ← 传输层
└──────────────────────────────────┘
```

### 7.2 方法定义

| 方法 | 方向 | 说明 |
|---|---|---|
| `initialize` | 客户端 → Hermes | 建立连接，协商协议版本 |
| `session/new` | 客户端 → Hermes | 创建新会话 |
| `session/prompt` | 客户端 → Hermes | 发送任务，流式返回结果 |
| `session/cancel` | 客户端 → Hermes | 取消运行中的任务 |
| `session/close` | 客户端 → Hermes | 关闭会话 |

### 7.3 事件类型（Hermes → 客户端）

| 事件 | 说明 |
|---|---|
| `text` | LLM 生成的文本块 (流式) |
| `thinking` | 思考过程 |
| `tool_progress` | 工具调用开始，包含 `toolName` + `arguments` |
| `tool_result` | 工具执行结果 |
| `done` | 任务完成，包含最终 usage 统计 |
| `error` | 错误信息 |

### 7.4 Session 复用机制

```typescript
// 基于 workspace + skills + mcp config + credential scope 的 SHA256
const sessionBindingHash = computeSessionBindingHash({
  workspaceDir,
  runtimeExecEnvPath,
  projectionVersion,
  skillNames,
  skillsHash,
  mcpConfigHash,
  credentialScopeHash,
  sessionEnvHash,
  extraPromptHash,
  agentId,
  sessionAnchor,
});

// 相同 hash → 复用已有 ACP session
const existing = readSessionBinding(sessionBindingHash);
if (existing) {
  // 复用 session，避免重新创建执行环境
  return await client.sessionPrompt(existing.sessionId, prompt);
}

// 不同 hash → 创建新 session
const newSession = await client.sessionNew();
writeSessionBinding(sessionBindingHash, { sessionId: newSession.id, ... });
```

持久化位置：`~/.openclaw/hermes/session-bindings.json`

---

## 8. 阶段 5：结果回收与钩子

### 8.1 结果转换 (`harness.js`)

```typescript
function buildHermesAttemptResult(params, response) {
  return {
    // 核心回复
    assistantTexts: response.assistantTexts || [response.assistantText],

    // 工具调用记录
    toolMetas: response.toolMetas,

    // Token 消耗
    attemptUsage: response.usage,

    // 会话信息
    sessionIdUsed: response.sessionId,

    // 状态标记
    aborted: response.aborted,
    timedOut: response.timedOut,
    promptError: response.promptError,

    // 安全性
    replayMetadata: {
      hadPotentialSideEffects: response.hadPotentialSideEffects,
      replaySafe: response.replaySafe ?? !response.hadPotentialSideEffects,
    },

    // 消息快照（用于对话历史）
    messagesSnapshot: response.messagesSnapshot,
    lastAssistant: response.lastAssistant,
  };
}
```

### 8.2 工具钩子 (`harness-hook.js`)

当 Hermes 调用工具时，OpenClaw 侧的钩子被触发：

```typescript
// before_tool_call: 工具调用前
export async function runHermesBeforeToolCallHook(args) {
  const wrappedTool = module.wrapToolWithBeforeToolCallHook(syntheticTool, ctx);
  await wrappedTool.execute(args.toolCallId, args.startArgs, args.params.abortSignal);
}

// after_tool_call: 工具调用后
export async function runHermesAfterToolCallHook(args) {
  await module.runAgentHarnessAfterToolCallHook({
    toolName: args.toolName,
    toolCallId: args.toolCallId,
    startArgs: args.startArgs,
    result: args.result,
    error: args.error,
    startedAt: args.startedAt,
  });
}

// llm_input: LLM 输入前
export async function runHermesLlmInputHook(args) {
  module.runAgentHarnessLlmInputHook({
    event: { prompt: args.prompt, historyMessages: args.historyMessages, ... },
    ctx: buildHermesHookContext(args.params),
  });
}

// llm_output: LLM 输出后
export async function runHermesLlmOutputHook(args) {
  module.runAgentHarnessLlmOutputHook({
    event: { assistantTexts: args.assistantTexts, usage: args.usage, ... },
    ctx: buildHermesHookContext(args.params),
  });
}

// agent_end: Agent 回环结束
export async function runHermesAgentEndHook(args) {
  module.runAgentHarnessAgentEndHook({
    event: { messages: args.messages, success: args.success, durationMs: ... },
    ctx: buildHermesHookContext(args.params),
  });
}
```

---

## 9. 数据模型

### 9.1 HermesSource（投影源）

```typescript
interface HermesSource {
  root: string;                    // workspace 根目录
  configPath?: string;             // config.yaml
  envPath?: string;                // .env
  soulPath?: string;               // SOUL.md
  agentsPath?: string;             // AGENTS.md
  memoryPath?: string;             // MEMORY.md
  userPath?: string;               // USER.md
  skillsDir?: string;              // workspace/skills/
  archivePaths: ArchivePath[];     // 归档数据
}
```

### 9.2 ProjectedExecutionEnv（投影环境）

```typescript
interface ProjectedExecutionEnv {
  execEnv: {
    runtimeExecEnvPath: string;    // 容器内路径
    projectedSkills: ProjectedSkill[];
    workspaceFiles: string[];
  };
  projectedContext: {
    files: { soul, user, agent, task };
    memory: { longTerm, daily, summary };
    commandAllowlist: string[];
    discoveredSkills: Skill[];
    skillsPrompt: string;
  };
  bootstrapPrompt: string;         // 发给 Hermes 的完整 prompt
  sessionBindingHash: string;      // session 复用哈希
  sessionAnchor: string;           // session 锚点
  exposedSkills: ExposedSkill[];   // 暴露给 Hermes 的技能列表
}
```

### 9.3 AttemptResult（OpenClaw 标准格式）

```typescript
interface AttemptResult {
  aborted: boolean;
  timedOut: boolean;
  assistantTexts: string[];
  toolMetas: ToolMeta[];
  attemptUsage: Usage;
  messagesSnapshot: Message[];
  lastAssistant: Message;
  replayMetadata: {
    hadPotentialSideEffects: boolean;
    replaySafe: boolean;
  };
  sessionIdUsed: string;
}
```

---

## 10. 配置参考

### 10.1 完整配置项

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `hermesContainerName` | `hermes-agent` | Docker 容器名 |
| `transport` | `tcp` | ACP 传输模式 (tcp/stdio) |
| `tcpHost` | `127.0.0.1` | ACP bridge 地址 |
| `tcpPort` | `3100` | ACP bridge 端口 |
| `defaultModel` | — | Hermes 使用的上游模型 |
| `defaultContextLevel` | `L1` | 默认上下文级别 |
| `runtimeMinContextLevel` | `L2` | 引擎模式最小上下文级别 |
| `runtimeProjectWorkspaceSkills` | `true` | 是否投影技能 |
| `defaultCredentialScope` | `none` | 默认凭据范围 |
| `defaultWriteback` | `W1` | 默认写回级别 |
| `timeout` | `1800` | 任务超时 (秒) |
| `autoStrategy` | `true` | 自动策略推断 |
| `enableLayeredProtocol` | `true` | 启用分层协议 |
| `projectionVersion` | `c1c2-v1` | 投影 schema 版本 |
| `runtimeExecEnvRootDir` | `/tmp/openclaw-hermes-execenv` | 执行环境根目录 |
| `mirrorExecEnvToContainer` | `true` | 在容器内镜像执行环境 |

### 10.2 技能投影配置

| 配置项 | 说明 |
|---|---|
| `skillProjection.hostBackedDenylist` | 强制标记为 host-backed 的技能（黑名单） |
| `skillProjection.hostBackedSkillNames` | 标记为 host-backed 的技能 |
| `skillProjection.containerEnvSkillNames` | 标记为需要环境变量的技能 |
| `skillProjection.alwaysExposeSkillNames` | 始终暴露给 Hermes 的技能 |

---

## 11. 故障排查

### 11.1 诊断命令

```bash
# 检查 Hermes 容器状态
hermes_status

# 预览策略（不执行）
hermes_strategy task="帮我写个脚本"

# 检查 ACP 连接
docker exec hermes-agent acp status

# 查看 session bindings
cat ~/.openclaw/hermes/session-bindings.json | python3 -m json.tool

# 查看投影环境
ls -la /tmp/openclaw-hermes-execenv/
```

### 11.2 常见问题

| 问题 | 可能原因 | 排查 |
|---|---|---|
| 开关无效 | 插件未启用 | 检查 `plugins.entries.openclaw-plugin-hermes.enabled` |
| 任务超时 | Hermes 容器无响应 | `hermes_status` 检查，增加 `timeout` |
| 技能不可用 | 分类为 host-backed/unsupported | 检查 `skillProjection` 配置 |
| ACP 连接失败 | 端口不通 | `nc -z 127.0.0.1 3100` |
| Session 不复用 | bindings 哈希不匹配 | 检查 workspace 或 skills 是否有变化 |

---

> **文档维护**: 基于 `openclaw-plugin-hermes` 2.0.1 源码分析，覆盖 harness.js、index.js、runtime-client.js、context-assembler.js、acp-client.js、harness-hook.js、config.js、types.js、execenv-builder.js 全部核心模块。