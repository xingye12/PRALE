# Hermes 接入与 Agent 轨迹兼容实现说明

> 文档基线：2026-08-07 当前工作区  
> 适用范围：WattClaw 多租户部署、`hermes/default` Agent Harness 模式、Agent 轨迹采集与查看  
> 说明：本文描述当前代码的实际行为。它补充并更新 `hermes-engine-switch-spec.md`、`hermes-wattclaw-integration-changelog.md` 和 `wattclaw-agent-trajectory-visualization.md` 中与 Hermes 相关的内容。

## 1. 结论概览

当前系统并没有把 Hermes 当作一个普通的 OpenAI 兼容 HTTP 模型服务直接接入，而是采用了以下架构：

1. 每个 OpenClaw 租户容器对应一个独立的 Hermes 容器。
2. Hermes 容器运行官方 Hermes Agent，并由项目提供的 Python 适配层把 Hermes ACP 暴露为 Docker 内网 TCP 服务。
3. OpenClaw 容器内安装 `openclaw-plugin-hermes`，插件注册 `hermes/default` 静态模型和 Agent Harness。
4. 用户选择 Hermes 后，服务端先把会话模型切换为 `hermes/default`，后续 Agent attempt 由 Harness 接管。
5. Harness 通过 ACP JSON-RPC over TCP 驱动 Hermes，而不是请求 OpenClaw 配置中声明的占位 HTTP `baseUrl`。
6. Hermes 内部实际调用上游模型时，使用 Hermes `oneapi` Provider 和 OpenAI Chat Completions 协议。
7. Hermes 模式下真实的模型循环和工具循环发生在外部 Hermes 容器，项目通过 ACP 可观测性扩展、Harness Hook 适配和 prompt-capture 插件，把这些外部事件重新映射为 OpenClaw 原生轨迹事件。
8. 轨迹最终仍存储在每个 OpenClaw 租户自己的 SQLite 数据库中，前端继续通过 `wattclawTrace.*` RPC 查询，不引入第二套轨迹数据库或第二套 UI。

因此，Hermes 轨迹兼容的核心不是“前端特殊解析 Hermes 日志”，而是：

```text
Hermes 内部事件
  -> ACP session/update
  -> openclaw-plugin-hermes 规范化
  -> OpenClaw 原生 Agent Hook
  -> wattclaw-prompt-capture-plugin
  -> tenant-local SQLite
  -> wattclawTrace.get/list RPC
  -> AgentTrajectoryDrawer
```

## 2. 总体架构

```mermaid
flowchart LR
  UI[Vue 管理端] -->|HTTP /api/workspace/send| WEB[WattClaw Express]
  UI -->|HTTP /api/rpc| RPC[RPC 代理]
  WEB -->|WebSocket RPC| OCG[租户 OpenClaw Gateway]
  RPC -->|按 sessionKey 路由| OCG

  OCG --> HPLUG[openclaw-plugin-hermes]
  HPLUG -->|ACP JSON-RPC 2.0\nNDJSON over TCP| HACP[Hermes ACP TCP Bridge]
  HACP --> HA[Hermes Agent]
  HA -->|OpenAI Chat Completions| MODEL[One-API / 上游模型]

  HPLUG -->|原生 Agent Hook| CAP[wattclaw-prompt-capture-plugin]
  CAP --> DB[(租户 wattclaw-traces.db)]
  OCG -->|Gateway 事件| WEB
  WEB -->|SSE / 前端事件流| UI
```

### 2.1 租户隔离关系

每个租户拥有一组配对容器：

```text
tenant N
├── OpenClaw 容器 N
│   ├── openclaw-plugin-hermes
│   ├── wattclaw-prompt-capture-plugin
│   └── ~/.openclaw/state/wattclaw-traces.db
└── Hermes 容器 N
    ├── /opt/data/.env
    ├── /opt/data/config.yaml
    ├── /opt/data/execenv
    └── /opt/data/skills
```

OpenClaw 和 Hermes 容器加入同一个 Docker 网络。Hermes ACP 端口不发布到宿主机，OpenClaw 使用 Hermes 容器名作为 Docker DNS 主机名连接。

### 2.2 两种 Hermes 使用方式必须区分

`openclaw-plugin-hermes` 同时提供两类能力：

| 方式 | 入口 | 含义 | 轨迹行为 |
| --- | --- | --- | --- |
| Hermes 引擎模式 | 会话模型为 `hermes/default` | 整个 OpenClaw Agent attempt 交给 Hermes Harness | 本文重点；内部 LLM 和工具事件会桥接到 OpenClaw 轨迹系统 |
| Hermes 委派工具 | 普通 OpenClaw Agent 调用 `hermes_dispatch` | 仅把某个任务委派给 Hermes | 是工具级委派，不等价于完整的 `hermes/default` Harness 轨迹 |

不能把两者混为一谈。前端的 Hermes 开关切换的是第一种模式。

## 3. Hermes 容器的构建与编排

主要实现位于 [server/core/multi-tenant-gateway.js](../server/core/multi-tenant-gateway.js)。

### 3.1 一租户一 Hermes 容器

`hermesContainerNameFor(tenantId)` 根据租户编号生成 Hermes 容器名。租户 OpenClaw 容器和 Hermes 容器保持一一对应，避免会话、执行目录、技能和凭据跨租户共享。

`ensureHermesContainer()` 负责：

- 检查 `OPENCLAW_HERMES_ENABLED` 和 Hermes 镜像配置。
- 创建租户 Hermes 数据目录。
- 创建 `execenv` 和 `skills` 子目录。
- 确保运行时镜像存在。
- 检查已有容器的镜像、挂载、环境变量、启动命令、实例标签和项目标签是否漂移。
- 配置变化时重建由 WattClaw 管理的 Hermes 容器。
- 配置内存、CPU、重启策略和租户标签。

Hermes 容器的宿主机数据目录整体挂载到 `/opt/data`。这是 Hermes 的私有运行数据根目录。

### 3.2 OpenClaw 只共享必要目录

OpenClaw 容器不会挂载完整的 Hermes `/opt/data`，只共享：

| 宿主机目录 | OpenClaw 容器目录 | 权限 | 用途 |
| --- | --- | --- | --- |
| `<tenant>/hermes/execenv` | `/home/node/hermes-data/execenv` | 读写 | Harness 构建执行环境，Hermes 从 `/opt/data/execenv` 读取 |
| `<tenant>/hermes/skills` | `/home/node/hermes-data/skills` | 只读 | 向 Hermes 投影允许使用的技能 |

同一宿主目录在 Hermes 容器中分别表现为 `/opt/data/execenv` 和 `/opt/data/skills`。这种共享挂载让 OpenClaw 能准备任务环境，同时不暴露 Hermes 的 `.env`、`config.yaml` 和其他私有状态。

### 3.3 运行时镜像

[server/hermes-acp/Dockerfile](../server/hermes-acp/Dockerfile) 基于配置的官方 Hermes 镜像生成 WattClaw 运行时镜像，并加入：

- [server/hermes-acp/acp-tcp-server.py](../server/hermes-acp/acp-tcp-server.py)：把 Hermes ACP 适配器暴露为 TCP 服务。
- [server/hermes-acp/entrypoint-acp.sh](../server/hermes-acp/entrypoint-acp.sh)：初始化 Hermes 配置并启动 Gateway 和 ACP Bridge。

`ensureHermesImage()` 通过 Docker Engine API 检查或拉取基础镜像，再使用 `server/hermes-acp` 构建上下文生成实例级运行时镜像。默认运行时镜像名包含 WattClaw 实例 ID，防止多个实例误用彼此的派生镜像。

### 3.4 启动时的 Hermes Provider 配置

`entrypoint-acp.sh` 以 `/opt/data` 作为 `HERMES_HOME`，每次启动时生成或更新：

- `/opt/data/.env`
- `/opt/data/config.yaml`

配置把 `OPENAI_BASE_URL`、`OPENAI_API_KEY` 和默认模型写入 Hermes 的命名 Provider `oneapi`，并使用 `chat_completions` API 模式。

这里有两个容易混淆的模型层次：

| 层次 | 模型标识 | 作用 |
| --- | --- | --- |
| OpenClaw 路由模型 | `hermes/default` | 触发 Hermes Agent Harness |
| Hermes 上游模型 | `HERMES_DEFAULT_MODEL` | Hermes 实际通过 One-API 请求的模型，例如部署环境配置的具体模型 |

`hermes/default` 是 OpenClaw 内的合成路由模型，不是 One-API 中必须存在的真实模型 ID。

### 3.5 容器准备的失败语义

租户 OpenClaw 容器创建时会尽力准备配对 Hermes 容器，并安装 Hermes 插件和轨迹插件。Hermes 准备失败不会阻止普通 OpenClaw 租户启动，但此时选择 `hermes/default` 会在连接 ACP 时失败。

这是一种“主服务可用优先”的降级策略，不代表 Hermes 能力在容器准备失败后仍然可用。

## 4. OpenClaw 中的 Hermes 配置注入

主要实现位于 [server/openclaw-config-sync.js](../server/openclaw-config-sync.js) 的 `injectHermesConfig()`。

数据库配置同步到 `openclaw.json` 时，系统会幂等注入以下内容。

### 4.1 插件配置

`plugins.entries['openclaw-plugin-hermes']` 包含：

- `transport: 'tcp'`
- `tcpHost`: 当前租户的 Hermes 容器名
- `tcpPort`: Hermes ACP 端口，默认 `3100`
- `hermesContainerName`
- `hermesDataDir`: OpenClaw 内共享数据根目录
- `runtimeExecEnvRootDir: '/opt/data/execenv'`
- `mirrorExecEnvToContainer: true`
- 可选 `defaultModel`

当前部署实际只启用 TCP transport。早期文档或包描述中出现的 stdio 不能视为当前部署路径。

### 4.2 静态模型声明

配置同步使用 `models.mode = 'replace'`。OpenClaw 的 `sessions.patch` 会先校验目标模型是否存在于静态配置中，因此必须注入：

- Provider `hermes`
- Model `hermes/default`
- Agent alias `hermes`
- `agentRuntime.id = 'hermes'`

Provider 中的 `baseUrl` 是本地占位地址，认证值也是合成值。实际推理请求不会发送到这个地址，因为 Agent Harness 会在模型请求前接管 attempt，并改走 ACP/TCP。

## 5. 前端模型切换与消息发送

### 5.1 Hermes 开关

[src/views/workspace/ChatInput.vue](../src/views/workspace/ChatInput.vue) 定义 `HERMES_MODEL = 'hermes/default'`。

用户打开 Hermes：

1. 记录切换前的模型。
2. 调用 `workspaceStore.previewModelChange()` 更新当前会话或新会话的本地模型选择。
3. 发送消息时把 `model: 'hermes/default'` 一并提交到后端。

关闭 Hermes 时恢复之前的模型。模型选择由 [src/stores/workspace.ts](../src/stores/workspace.ts) 按会话保存，并写入本地存储。

### 5.2 为什么先 `sessions.patch` 再 `chat.send`

前端调用：

```text
POST /api/workspace/send
{
  sessionKey,
  message,
  model: "hermes/default"
}
```

[server/handlers/chat.js](../server/handlers/chat.js) 收到请求后，会发起：

```text
Gateway RPC sessions.patch({ key: sessionKey, model })
Gateway RPC chat.send({ sessionKey, ... })
```

原因是 `chat.send` 本身不接受模型字段，模型属于会话配置。

当前实现按上述顺序发起两个 Gateway RPC，但不会等待 `sessions.patch` 的响应再发送 `chat.send`；patch 结果异步写入缓存，失败会记录日志。这依赖同一 Gateway 通道的请求派发顺序，是实现中的一个时序边界。

### 5.3 返回通道

消息提交使用 HTTP。Agent 运行期间的 Gateway 事件由后端事件流转发到前端，前端通过 SSE 相关封装消费增量消息、生命周期状态和最终消息。

## 6. Agent Harness 执行链路

插件入口位于 [plugins/openclaw-plugin-hermes/src/index.ts](../plugins/openclaw-plugin-hermes/src/index.ts)。它同时注册 Hermes Provider、Agent Harness 和委派工具。

[plugins/openclaw-plugin-hermes/src/harness.ts](../plugins/openclaw-plugin-hermes/src/harness.ts) 的 Harness 对 `hermes` Provider 声明支持，并在 `runAttempt()` 中调用 [harness-runtime.ts](../plugins/openclaw-plugin-hermes/src/harness-runtime.ts)。

### 6.1 一次 Harness attempt 的主要步骤

```mermaid
sequenceDiagram
  participant OC as OpenClaw
  participant HR as Hermes Harness
  participant FS as Shared ExecEnv
  participant ACP as Hermes ACP Bridge
  participant HM as Hermes Agent

  OC->>HR: runAttempt(session, prompt, tools, history)
  HR->>HR: 计算 session anchor 和投影级别
  HR->>FS: 创建或更新 execenv
  HR->>ACP: TCP connect + initialize
  HR->>ACP: session/load 或 session/new
  HR->>ACP: session/prompt(bootstrap prompt)
  ACP->>HM: 驱动 Hermes Agent
  HM-->>ACP: text/thinking/tool/llm updates
  ACP-->>HR: session/update NDJSON
  HR-->>OC: Agent event + Hook event
  HR->>FS: 回收允许写回的文件
  HR-->>OC: AgentHarnessAttemptResult
```

### 6.2 稳定会话绑定

Harness 根据 session key、session file、session id 和 agent id 计算稳定的 session anchor。

ACP session 绑定持久化到：

```text
~/.openclaw/hermes-plugin/session-bindings.json
```

绑定哈希覆盖工作目录、运行目录、投影内容、技能、MCP、凭据环境、额外提示词、agent 和 session anchor。上下文发生实质变化时不会错误复用旧 Hermes session。

### 6.3 执行环境投影

[execenv-builder.ts](../plugins/openclaw-plugin-hermes/src/execenv-builder.ts) 为每个稳定 anchor 构建隔离执行目录，内容包括：

- `SOUL.md`
- `USER.md`
- `AGENT.md` 或 `AGENTS.md`
- `TASK.md`
- `runtime-config.json`
- `projection.json`
- 允许投影的 skills
- 提示词明确引用的工作区文件

默认上下文策略定义在 [types.ts](../plugins/openclaw-plugin-hermes/src/types.ts)：

| 维度 | 含义 |
| --- | --- |
| L0-L3 | 从任务和模型信息逐步扩展到工具、身份记忆、技能、MCP 和定时任务 |
| C0-C2 | 从不投影凭据到指定凭据、全部允许凭据 |
| W0-W3 | 从不写回到结果、记忆、技能/定时任务/配置写回 |

默认运行时最低上下文为 L2，确保 Hermes 至少获得任务、工具、身份与必要记忆。凭据默认 C0，写回默认 W1。

系统不会默认镜像整个工作区，只投影提示词引用的路径和允许的技能；执行结束后也只回收策略允许的结果和显式创建内容。

由于 OpenClaw 和 Hermes 的 execenv 实际是同一宿主目录的两个容器挂载视图，`execenv-builder.ts` 会识别共享挂载身份并跳过额外的 Docker copy。非共享挂载部署仍保留复制兼容路径。

### 6.4 可选 MCP Bridge

当配置启用 MCP Bridge 时，Harness 会把只能在 OpenClaw 侧访问的插件工具转换为 Hermes 容器可访问的 OpenClaw MCP loopback，并注入受限 token、session 和 agent 环境。

该能力默认关闭，不能把它视为 Hermes 基础通信的必要组成。基础通信始终是 ACP/TCP。

## 7. ACP/TCP 通信协议

客户端实现位于 [plugins/openclaw-plugin-hermes/src/acp-client.ts](../plugins/openclaw-plugin-hermes/src/acp-client.ts)，服务端适配位于 [server/hermes-acp/acp-tcp-server.py](../server/hermes-acp/acp-tcp-server.py)。

### 7.1 传输格式

- 网络：Docker 内网 TCP。
- 默认端口：`3100`。
- 帧格式：每行一个 JSON 对象，即 NDJSON。
- RPC：JSON-RPC 2.0。
- ACP protocol version：`1`。
- 连接超时：客户端默认 10 秒。

主要方法：

| 方法 | 用途 |
| --- | --- |
| `initialize` | 协议握手与能力确认 |
| `session/new` | 创建 Hermes ACP session |
| `session/load` | 加载已有 session |
| `session/resume` | 恢复 session |
| `session/prompt` | 发送任务并接收流式更新 |
| `session/cancel` | 取消当前运行 |
| `session/close` | 关闭 session |

服务端通过 `asyncio.start_server` 接受 TCP 连接，每个连接创建独立 `HermesACPAgent` 和 ACP `AgentSideConnection`。

### 7.2 流式事件规范化

客户端把 Hermes ACP 更新规范化为 Harness 内部事件：

| ACP 更新 | Harness 事件 |
| --- | --- |
| `agent_message_text` / message chunk | `text` |
| `agent_thought` / thinking | `thinking` |
| `agent_llm_call` | `llm_call` |
| `tool_call_begin` | `tool_progress` |
| `tool_call_end` / update | `tool_result` |
| terminal update | `done` / `error` |

`session/prompt` 会累积文本、按 `callId` 合并模型调用、聚合 usage，并读取最终结果中的 `_meta.openclaw.llmCalls` 和 `_meta.openclaw.systemPrompt`。

部分 Hermes/ACP 版本可能已经返回 prompt ACK 或结果，但没有明确 terminal update。客户端提供 2.5 秒空闲完成兜底，避免请求永久挂起；总任务仍受 Harness timeout 和取消信号约束。

## 8. Hermes 模式下轨迹为什么需要专门适配

普通 OpenClaw 模式下，模型调用、工具调用和 Agent 生命周期都发生在 OpenClaw 自己的执行循环中，因此原生 Hook 可以直接观察：

- `llm_input`
- `model_call_started`
- `model_call_ended`
- `before_tool_call`
- `after_tool_call`
- `llm_output`
- `agent_end`

Hermes 模式改变了执行边界：真实模型请求和工具执行发生在另一个容器中的 Hermes Agent 内部。OpenClaw 只看到一个外部 Harness attempt。如果不做桥接，轨迹中会缺失或不准确地记录：

- 真实 provider 和 model。
- 多次 LLM call。
- system prompt。
- input/output/cache token。
- finish reason 和模型错误。
- 工具参数、开始/结束时间、状态、错误和耗时。

修复方案不是新增一套 Hermes 专用轨迹格式，而是把 Hermes 可观测信息转换回 OpenClaw 既有 Hook 合约。

## 9. 轨迹兼容实现

### 9.1 ACP 服务端可观测性增强

[acp-tcp-server.py](../server/hermes-acp/acp-tcp-server.py) 中的 OpenClaw 可观测性桥会检查发往客户端的 ACP NDJSON 帧，并补充 OpenClaw 轨迹需要的信息。

工具调用增强包括：

- 统一 `toolCallId`。
- 在工具开始事件中补充原始工具名和 arguments。
- 统一 `completed`、`failed`、`cancelled` 状态。
- 补充 error。
- 在 `_meta.openclaw` 中补充 `startedAt`、`finishedAt` 和 `durationMs`。
- 对敏感键名递归脱敏，并对字符串使用 Hermes 的脱敏器。

模型调用增强包括：

- 优先使用 Hermes 原生 `agent_llm_call`。
- 原生事件不可用时，解析 Hermes API call 日志中的 model、provider、输入输出 token、cache 和 latency。
- 只有在能够唯一关联当前桥实例时才使用日志回退，避免并发 session 之间串线。
- 把模型调用以 `session/update` 的 `agent_llm_call` 形式发送。
- 在最终 prompt result 中附加 `llmCalls` 和 `systemPrompt`。
- 如果只能获得总 usage 而没有逐次调用，则生成一个 `llm-final` 兜底记录。

服务端还会从 Hermes session agent 快照读取当前 model、provider 和 system prompt。system prompt 在发出前进行脱敏。

### 9.2 ACP 客户端聚合

[acp-client.ts](../plugins/openclaw-plugin-hermes/src/acp-client.ts) 负责：

- 解析 `llm_call`、tool progress 和 tool result。
- 按 `callId` upsert，避免同一次模型调用的开始、更新、结束被计成多次。
- 优先使用 `_meta.openclaw` 和 `rawInput` 中的工具信息。
- 聚合 token usage、finish reason、system prompt 和错误。
- 将协议差异收敛为稳定的 TypeScript 结构。

### 9.3 Harness Hook 适配

[plugins/openclaw-plugin-hermes/src/harness-hook.ts](../plugins/openclaw-plugin-hermes/src/harness-hook.ts) 动态解析当前 OpenClaw 安装中的 Agent Harness Runtime，并调用原生 Hook Runner。

映射关系如下：

| Hermes/Harness 数据 | OpenClaw Hook |
| --- | --- |
| attempt 开始、用户 prompt、history | `llm_input` |
| ACP `llm_call` 开始 | `model_call_started` |
| ACP `llm_call` 结束、usage、finishReason、error | `model_call_ended` |
| tool progress | `before_tool_call` |
| tool result、状态、错误、耗时 | `after_tool_call` |
| 最终 assistant output | `llm_output` |
| attempt 完成或失败 | `agent_end` |

模型 Hook 会携带 `runId`、`sessionKey`、`callId`、provider、model、`api: 'hermes-acp'`、`transport: 'acp'`、时间戳、usage、finishReason 和 error。

工具 Hook 通过包装后的合成工具调用触发 `before_tool_call`，再用规范化结果触发 `after_tool_call`，从而兼容只认识 OpenClaw 工具生命周期的消费者。

OpenClaw 内部运行时文件位置会随版本变化，因此该层使用多个候选模块路径动态加载。这是兼容当前 OpenClaw 分发结构的适配层，也是升级 OpenClaw 时需要重点回归的部分。

### 9.4 复用 prompt-capture 存储

轨迹消费者仍然是 [plugins/wattclaw-prompt-capture-plugin](../plugins/wattclaw-prompt-capture-plugin)。Hermes Hook 事件进入该插件后，与普通 OpenClaw Agent 使用相同的数据模型。

主要增强点：

- Hook 接收并保存 `systemPrompt`、prompt、history、toolCount 和 startedAt。
- 模型结束时保存 token usage 和 finishReason。
- assistant 消息中的 usage 可用于轨迹重建。
- 从消息重建模型调用时保留已有 telemetry。
- 读取轨迹时可从原生 `.trajectory.jsonl` 补全或校正缺失的模型调用和 finishReason。

每个租户的数据库默认位于：

```text
~/.openclaw/state/wattclaw-traces.db
```

SQLite 使用 WAL。核心表以 `run_id` 为主键，保存：

- session key、agent id。
- 开始和结束时间。
- user prompt 和 assistant output。
- model calls JSON。
- tool calls JSON。
- input/output/cache token。
- duration、status、createdAt。

默认保留期为 30 天。数据库按 session 和创建时间建立索引。

### 9.5 轨迹查询 RPC

prompt-capture 插件注册：

| RPC | 用途 |
| --- | --- |
| `wattclawTrace.get` | 按 `runId` 读取单条完整轨迹 |
| `wattclawTrace.list` | 按 session 等条件列出轨迹摘要 |
| `wattclawTrace.stats` | 查询轨迹统计信息 |

Hermes 和普通 OpenClaw 运行共享这些 RPC，不需要前端根据引擎切换查询协议。

## 10. 实时消息和实时轨迹事件

[agent-event-bridge.ts](../plugins/openclaw-plugin-hermes/src/agent-event-bridge.ts) 把 Harness 事件发送给：

1. 当前 attempt 的 `onAgentEvent` 回调。
2. OpenClaw 原生 `emitAgentEvent`，如果能够从当前分发包中解析到。

[harness-runtime.ts](../plugins/openclaw-plugin-hermes/src/harness-runtime.ts) 把 ACP 的 text、thinking、tool 和 lifecycle 更新转换成 OpenClaw Agent event。

如果当前 OpenClaw 版本无法解析原生 event emitter，[webui-event-bridge.ts](../plugins/openclaw-plugin-hermes/src/webui-event-bridge.ts) 会动态查找 Gateway 请求上下文，通过 session 广播提供 Web UI 兜底。

为避免重复或过密事件：

- 优先使用原生 partial reply 和 Agent event emitter。
- assistant text delta 会节流和合并。
- thinking 保持为 Agent event，不拼接进最终 assistant 正文。

实时事件链路解决“运行过程中能看到输出和状态”，持久化轨迹链路解决“运行结束后可以重新打开轨迹”。两者相互补充，但不是同一条通道。

## 11. 多租户轨迹路由

Express 的 `/api/rpc` 代理位于 [server/index.js](../server/index.js)。轨迹数据实际位于对应租户 OpenClaw 容器，因此不能始终发送到默认 Gateway。

### 11.1 带 `sessionKey` 的查询

对于 `wattclawTrace.get` 和 `wattclawTrace.list`：

1. 非管理员必须提供 `sessionKey`。
2. 后端校验当前用户是否拥有该 session。
3. [server/user-manager.js](../server/user-manager.js) 的 `resolveTenantIdForSession()` 解析 session 所属 tenant。
4. 优先使用 `user_sessions.tenant_id`，必要时使用用户分配和 agent 信息回退并回填 tenant id。
5. 调用 `callGatewayForTenant()` 把 RPC 发送到正确的租户 Gateway。

`wattclawTrace.get` 的插件合约只需要 `runId`，因此后端使用 `sessionKey` 完成鉴权和路由后，会从转发参数中移除它。

### 11.2 管理员只持有 `runId` 的查询

当前工作区中的 [server/index.js](../server/index.js) 进一步处理管理员只有 `runId`、没有 `sessionKey` 的场景：

1. 通过 `callGatewayForAllTenants()` 并行查询所有租户 Gateway。
2. 使用 `Promise.allSettled()` 隔离单个租户失败。
3. 返回第一个成功找到轨迹的结果。
4. 没有匹配结果时回退到默认 Gateway 的原有行为。

这解决了管理员从缺少 session 上下文的入口查看其他容器轨迹时，被错误路由到默认租户的问题。

该无 `sessionKey` 的 fan-out 是当前工作区中尚未提交的后续增强；已提交的 `bc108f52` 已完成基于 `sessionKey` 的租户路由和前端参数透传。

### 11.3 路由边界

- 当前特殊路由只覆盖 `wattclawTrace.get` 和 `wattclawTrace.list`。
- 管理员无 session 上下文时的 fan-out 成本随租户数量线性增长，但请求并行执行。
- “第一个成功结果”依赖 `runId` 在租户间实际唯一。正常情况下 runId 应满足这一前提。

## 12. 前端轨迹查看和刷新后恢复

### 12.1 轨迹抽屉

[src/api/rpc-client.ts](../src/api/rpc-client.ts) 提供：

- `getAgentTrace(runId, sessionKey?)`
- 轨迹列表查询和防御性响应规范化。

[src/views/workspace/components/MessageActions.vue](../src/views/workspace/components/MessageActions.vue) 仅在以下条件显示轨迹按钮：

- 当前用户是管理员。
- 消息是 assistant 消息。
- 消息存在 `runId`。

打开 [src/views/workspace/components/AgentTrajectoryDrawer.vue](../src/views/workspace/components/AgentTrajectoryDrawer.vue) 时，同时传入 `runId` 和 `sessionKey`。抽屉展示统计信息、按时间交错排列的模型/工具 Gantt 轨迹以及调用详情。

### 12.2 实时消息的 runId

运行完成事件中携带的 `runId` 会写入前端 assistant message，因此刚完成的消息可以直接显示轨迹按钮。

### 12.3 页面刷新后的 runId 恢复

Gateway 历史消息不一定包含 prompt-capture 的 `runId`。只依赖实时事件会导致页面刷新后轨迹按钮消失。

[src/stores/workspace.ts](../src/stores/workspace.ts) 的 `enrichRunIds(sessionKey)` 在首次历史加载后：

1. 查询该 session 最近最多 64 条轨迹。
2. 规范化 assistant 消息正文和轨迹中的 `assistantOutput` 空白。
3. 使用最长公共前缀进行内容匹配。
4. 比较长度最多取 120 个字符，最低可信匹配长度为 12。
5. 只对高置信度匹配回填 `runId`。
6. 无法可靠匹配的轨迹保持未绑定，避免把错误轨迹挂到消息上。

因此，刷新后的轨迹可用性由两部分共同保证：

```text
轨迹列表中的 assistantOutput  <->  历史 assistant message 内容匹配
                                   +
getAgentTrace(runId, sessionKey) 的租户感知路由
```

## 13. 完整时序

```mermaid
sequenceDiagram
  participant UI as Vue UI
  participant API as Express
  participant GW as Tenant OpenClaw
  participant HP as Hermes Plugin
  participant HC as Hermes Container
  participant PC as Prompt Capture
  participant DB as Trace SQLite

  UI->>API: POST /api/workspace/send(model=hermes/default)
  API->>GW: sessions.patch(model=hermes/default)
  API->>GW: chat.send
  GW->>HP: runAttempt
  HP->>HC: ACP initialize/session/prompt over TCP
  HC-->>HP: text/thinking/llm/tool updates
  HP-->>GW: partial reply + agent events
  HP->>GW: native model/tool/agent hooks
  GW->>PC: hook events
  PC->>DB: upsert run/model_calls/tool_calls
  GW-->>API: Gateway events
  API-->>UI: SSE events + final runId

  UI->>API: /api/rpc wattclawTrace.get(runId, sessionKey)
  API->>API: ownership check + tenant resolution
  API->>GW: tenant-routed RPC
  GW->>PC: wattclawTrace.get
  PC->>DB: select by runId
  DB-->>UI: trace -> RPC response -> drawer
```

## 14. 通信方式汇总

| 起点 | 终点 | 通信方式 | 主要用途 |
| --- | --- | --- | --- |
| Vue | Express | HTTP POST | 发送消息、调用 `/api/rpc` |
| Vue | Express | SSE 事件流 | 接收 Gateway 实时事件和消息增量 |
| Express | OpenClaw Gateway | WebSocket RPC | `sessions.patch`、`chat.send`、`wattclawTrace.*` |
| OpenClaw Hermes Plugin | Hermes ACP Bridge | Docker 内网 TCP + NDJSON JSON-RPC 2.0 | session 生命周期、prompt、流式 Agent 事件 |
| Hermes Agent | One-API | OpenAI Chat Completions over HTTP(S) | 实际上游模型推理 |
| Hermes Harness | OpenClaw Runtime | 进程内 Hook/Event API | 恢复原生模型、工具、Agent 生命周期 |
| Prompt Capture | SQLite | `better-sqlite3` | 每租户轨迹持久化 |

## 15. 主要代码改动

### 15.1 Hermes 基础接入

提交 `4a3a19b0`：`feat:新增wattclaw接入hermes功能`

| 文件或目录 | 改动职责 |
| --- | --- |
| `plugins/openclaw-plugin-hermes/` | Provider、Harness、ACP client、执行环境投影、会话绑定、事件桥和 Hermes 委派工具 |
| `server/hermes-acp/` | Hermes 派生镜像、启动脚本、ACP TCP Server |
| `server/core/multi-tenant-gateway.js` | 每租户 Hermes 容器、镜像构建、挂载、网络、插件安装和生命周期管理 |
| `server/openclaw-config-sync.js` | 注入 Hermes 插件配置、静态 Provider/Model 和 alias |
| `server/handlers/chat.js` | 消息发送前按前端选择 patch 会话模型 |
| `src/views/workspace/ChatInput.vue` | Hermes UI 开关和模型恢复 |
| `src/stores/workspace.ts` | 会话级模型预览、持久化和发送参数 |
| `docker-compose*.yml` | 向管理服务挂载 Hermes 和 prompt-capture 插件源码 |
| `.env.test.example` | Hermes 镜像、端口、模型、资源和安装参数示例 |

### 15.2 Hermes 轨迹修复

提交 `64705c5f`：`fix:修复hermes模式下agent轨迹显示异常问题`

| 文件 | 改动职责 |
| --- | --- |
| `server/hermes-acp/acp-tcp-server.py` | 补充 LLM、tool、system prompt、usage 和时间信息，输出 OpenClaw 可观测元数据 |
| `plugins/openclaw-plugin-hermes/src/acp-client.ts` | 解析和聚合 LLM/tool telemetry |
| `plugins/openclaw-plugin-hermes/src/harness-hook.ts` | 把 Hermes telemetry 映射到 OpenClaw 原生 Hook |
| `plugins/openclaw-plugin-hermes/src/harness-runtime.ts` | 串联事件、Hook、最终结果和错误生命周期 |
| `plugins/openclaw-plugin-hermes/src/types.ts` | 扩展轨迹相关类型 |
| `plugins/wattclaw-prompt-capture-plugin/hooks.js` | 接收增强后的 Hermes Hook 字段 |
| `plugins/wattclaw-prompt-capture-plugin/storage.js` | 持久化 model/tool telemetry、usage 和 finish reason |
| `plugins/wattclaw-prompt-capture-plugin/trace-reconstruction.js` | 从消息和原生 trajectory 重建、校正轨迹 |
| `server/core/multi-tenant-gateway.js` | 加固 prompt-capture 的 `better-sqlite3` 原生依赖安装和校验 |
| prompt-capture 相关测试 | 覆盖 Hook、存储和轨迹重建 |

### 15.3 跨容器轨迹查询

提交 `bc108f52`：`fix:修复admin账号查看其他容器轨迹的功能`

| 文件 | 改动职责 |
| --- | --- |
| `server/index.js` | 使用 sessionKey 解析 tenant，并把轨迹 RPC 路由到对应 Gateway |
| `src/api/rpc-client.ts` | `getAgentTrace()` 支持传入 sessionKey |
| `src/views/workspace/components/AgentTrajectoryDrawer.vue` | 查询完整轨迹时透传当前 sessionKey |

当前未提交工作区改动：

| 文件 | 改动职责 |
| --- | --- |
| `server/index.js` | 管理员只有 runId 时并行 fan-out 所有租户 Gateway，返回首个成功轨迹；同时在转发 `get` 前剥离仅用于路由的 sessionKey |

## 16. 关键环境变量

| 环境变量 | 作用 |
| --- | --- |
| `OPENCLAW_HERMES_ENABLED` | 是否启用 Hermes 容器和配置注入 |
| `HERMES_IMAGE` | 官方或上游 Hermes 基础镜像 |
| `HERMES_RUNTIME_IMAGE` | WattClaw 派生运行时镜像名 |
| `OPENCLAW_HERMES_BUILD_CONTEXT_DIR` | ACP 派生镜像构建上下文 |
| `OPENCLAW_HERMES_CONTAINER_PREFIX` | 每租户 Hermes 容器名前缀 |
| `OPENCLAW_HERMES_ACP_PORT` | ACP TCP 端口，默认 `3100` |
| `HERMES_DEFAULT_MODEL` | Hermes 实际请求的上游模型 |
| `OPENCLAW_HERMES_DATA_DIR` | OpenClaw 容器内 Hermes 共享数据根目录 |
| `OPENCLAW_HERMES_MEMORY_MB` | Hermes 容器内存限制 |
| `OPENCLAW_HERMES_CPUS` | Hermes 容器 CPU 限制 |
| `HERMES_ACP_CMD` | Hermes 容器启动命令覆盖 |
| `OPENAI_BASE_URL` | Hermes One-API Provider 地址 |
| `OPENAI_API_KEY` | Hermes 上游模型凭据 |

完整示例以 [.env.test.example](../.env.test.example) 为准。

## 17. 安全与数据边界

### 17.1 凭据

- 凭据通过容器环境传入 Hermes。
- 启动脚本会把 `OPENAI_API_KEY` 和相关 Provider 配置写入 Hermes 私有数据卷中的 `.env` 和 `config.yaml`。
- OpenClaw 不挂载完整 Hermes 数据根目录，因此默认无法直接读取这两个文件。
- ACP 工具参数和 system prompt 的可观测元数据会做脱敏。
- 执行环境凭据投影默认是 C0，即不向任务 execenv 投影凭据。

因此，正确表述是“凭据会持久化在隔离的 Hermes 私有数据目录中”，不能表述为“凭据绝不落盘”。

### 17.2 轨迹数据

prompt-capture 的设计目标是完整审计，数据库可能包含：

- 用户 prompt 和历史。
- system prompt。
- assistant 输出。
- 工具参数和结果。
- 模型标识、usage、错误和耗时。

这些数据具有高敏感性。当前 UI 仅向管理员显示轨迹操作；后端对非管理员执行 session 所有权校验，并把查询路由到正确租户。

Hermes ACP 层的脱敏不能替代轨迹数据库本身的访问控制、备份保护和保留期管理。

## 18. 可靠性与兼容性边界

1. Hermes 容器按租户准备是 best-effort。普通 OpenClaw 可以在 Hermes 失败时继续运行，但 Hermes 模式不可用。
2. `sessions.patch` 和 `chat.send` 依次发起但不等待 patch 响应，模型切换依赖 Gateway 请求派发顺序。
3. Hermes Hook Bridge 动态加载 OpenClaw 内部分发模块。升级 OpenClaw 后必须回归 Hook 路径和事件字段。
4. Hook 或原生 event emitter 解析失败时会记录错误并尽量保持主任务运行；这意味着“任务可完成”优先于“所有 telemetry 必然完整”。
5. 持久轨迹依赖 prompt-capture 插件成功安装，并且 `better-sqlite3` 原生 binding 与容器 Node ABI 匹配。
6. 刷新后的 runId 使用 assistant 文本启发式匹配。相同或过短输出可能无法恢复，系统选择不匹配而不是误匹配。
7. 管理员无 sessionKey 的跨租户 fan-out 随租户数量增长，适合兜底查询，不适合作为高频批量扫描接口。
8. 轨迹默认保留 30 天，超过保留期后 UI 无法再次读取是预期行为。
9. `hermes_dispatch` 是工具级委派，不能假设它与 `hermes/default` Harness 具有完全相同的内层轨迹粒度。

## 19. 建议回归点

### 19.1 Hermes 基础链路

1. 新建租户后确认 OpenClaw/Hermes 配对容器均存在且在同一网络。
2. 确认 Hermes 容器无宿主机端口暴露，OpenClaw 可用容器名连接 `3100`。
3. 切换 `hermes/default`，确认 `sessions.patch` 成功且消息由 Hermes 返回。
4. 确认普通模型与 Hermes 来回切换后，会话模型恢复正确。

### 19.2 轨迹链路

1. 运行至少包含一次模型调用和一次工具调用的 Hermes 任务。
2. 确认轨迹中 provider、model、system prompt、token、finish reason 均存在或有明确兜底值。
3. 确认工具名、参数、状态、开始/结束时间、耗时和错误展示正确。
4. 刷新页面后确认 assistant 消息重新获得 runId，轨迹按钮仍存在。
5. 管理员查看非默认租户 session 的轨迹，确认后端路由到正确 Gateway。
6. 从只持有 runId 的管理员入口查询，确认 fan-out 能找到其他租户轨迹。
7. 模拟一个租户 Gateway 失败，确认 `Promise.allSettled()` 不影响其他租户结果。

### 19.3 安全和失败场景

1. 非管理员查询不属于自己的 session 应返回 403。
2. 非管理员缺少 sessionKey 的轨迹查询应返回 400。
3. 工具参数中包含 token/password/secret 等字段时确认轨迹元数据已脱敏。
4. Hermes ACP 不可达时，确认任务失败信息可见且普通 OpenClaw 模式不受影响。
5. prompt-capture SQLite binding 加载失败时，确认安装日志能定位 ABI 或 binding 问题。

## 20. 设计评价

当前实现的关键优点是保持了 OpenClaw 生态兼容性：Hermes 负责外部 Agent 执行，WattClaw 只在执行边界进行协议和可观测性适配；轨迹存储、RPC、权限和 UI 仍沿用原有系统。

这避免了 Hermes 模式形成独立的消息协议、独立轨迹数据库和独立页面，也让普通 OpenClaw 与 Hermes 可以共享同一套管理体验。

代价是兼容层较深：它同时依赖 Hermes ACP 事件、Hermes 日志回退、OpenClaw Harness 内部模块、prompt-capture Hook 合约以及多租户 Gateway 路由。后续升级 Hermes 或 OpenClaw 时，应优先验证第 19 节列出的端到端回归点，而不能只验证“能够返回一条聊天消息”。
