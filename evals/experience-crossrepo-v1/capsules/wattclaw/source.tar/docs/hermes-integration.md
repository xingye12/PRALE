# Hermes 接入 WattClaw 技术文档

## 1. 概述

Hermes 是一个通用 AI Agent 运行时，基于上游镜像 `nousresearch/hermes-agent` 构建。WattClaw 通过**派生镜像 + ACP TCP 桥接 + OpenClaw 插件**三层架构将 Hermes 集成到多租户 Gateway 体系中，使用户可以在工作区中一键切换至 Hermes 引擎执行任务。

### 1.1 核心通信链路

```
前端 ChatInput (Hermes 开关)
  → workspaceStore.previewModelChange('hermes/default')
  → 会话模型通过 WebSocket RPC 发送到 OpenClaw Gateway
  → OpenClaw 插件 harness: supports(provider=hermes) → true
  → 插件 ACP 客户端通过 TCP 连接 hermes-le-N:3100 (NDJSON JSON-RPC)
  → acp-tcp-server.py (Hermes 容器内) 桥接到 HermesACPAgent
  → Hermes 执行 (terminal, browser, code, sub-agents)
  → ACP session/update 帧流式返回
  → 插件 agent-event-bridge.ts 通过 emitAgentEvent 发布到 OpenClaw 事件总线
  → OpenClaw server-chat 通过 WebSocket 广播 delta
  → WattClaw 后端 SSE 转发到前端
```

### 1.2 涉及的关键目录和文件

| 路径 | 作用 |
|------|------|
| `server/core/multi-tenant-gateway.js` | 容器生命周期管理、镜像构建、配置解析 |
| `server/openclaw-config-sync.js` | 向租户 openclaw.json 注入 Hermes 配置 |
| `server/index.js` | loadEnvConfig: Hermes 环境变量白名单 |
| `server/hermes-acp/Dockerfile` | 派生镜像构建定义 |
| `server/hermes-acp/entrypoint-acp.sh` | 容器入口点：配置物化 + 启动网关 + ACP 桥 |
| `server/hermes-acp/acp-tcp-server.py` | ACP TCP 服务器：桥接 TCP ↔ HermesACPAgent |
| `plugins/openclaw-plugin-hermes/src/index.ts` | 插件注册：provider + harness + 4 个 tools |
| `plugins/openclaw-plugin-hermes/src/harness.ts` | Agent Harness 实现：supports() + runAttempt() |
| `plugins/openclaw-plugin-hermes/src/agent-event-bridge.ts` | 事件桥接：将 Hermes 事件发布到 OpenClaw 事件总线（流式修复关键） |
| `plugins/openclaw-plugin-hermes/openclaw.plugin.json` | 插件清单：providers、contracts、configSchema |
| `src/views/workspace/ChatInput.vue` | 前端 Hermes 开关按钮 |

---

## 2. 架构设计

### 2.1 派生镜像架构

上游镜像 `nousresearch/hermes-agent` **不原生支持 ACP/TCP 协议**，仅暴露 OpenAI API (端口 8642) 与内部 messaging gateway。我们通过构建**派生镜像**来包装上游镜像，使其支持 ACP over TCP。

#### Dockerfile (`server/hermes-acp/Dockerfile`)

```dockerfile
ARG HERMES_BASE_IMAGE=nousresearch/hermes-agent:latest
FROM ${HERMES_BASE_IMAGE}

COPY acp-tcp-server.py /opt/hermes/acp-tcp-server.py
COPY entrypoint-acp.sh /opt/hermes/entrypoint-acp.sh

USER root
RUN chmod +x /opt/hermes/entrypoint-acp.sh /opt/hermes/acp-tcp-server.py

ENV ACP_TCP_PORT=3100
ENV ACP_TCP_HOST=0.0.0.0
EXPOSE 3100

ENTRYPOINT []    # 绕过基础镜像的 s6-overlay init 系统
CMD ["/opt/hermes/entrypoint-acp.sh"]
```

关键设计决策：

- **`ENTRYPOINT []`**：必须绕过基础镜像的 s6-overlay 入口点，因为我们需要自定义启动流程
- **仅 COPY 两个文件**：`acp-tcp-server.py` 和 `entrypoint-acp.sh`。基础镜像已包含所有 Python 依赖（`.venv`、`acp_adapter`、`HermesACPAgent`）
- 派生镜像名为 `wattclaw-hermes-acp-<instanceId>:latest`，其中 `instanceId` 用于区分并行部署

#### 构建流程 (`ensureHermesImage`)

位于 `server/core/multi-tenant-gateway.js`:

1. **快速路径**：若 `hermesImageReady` 标志已设置，直接返回
2. **检查存在**：通过 Docker API `GET /images/<runtimeImage>/json` 检查派生镜像是否已存在；若存在则设置标志并返回
3. **拉取基础镜像**：调用 `ensureHermesBaseImage()` → `GET /images/<base>/json`，若 404 则 `POST /images/create?fromImage=<base>` 拉取
4. **构建派生镜像**：`POST /build?t=<runtimeImage>&dockerfile=Dockerfile&buildargs={"HERMES_BASE_IMAGE":"<base>"}`，body 为 `server/hermes-acp/` 目录的 tar 包（排除 node_modules），Content-Type: `application/x-tar`，stream 模式
5. **确认构建成功**：再次 `GET /images/<runtimeImage>/json` 确认（Docker `/build` 返回 200 不代表构建成功）
6. 设置 `hermesImageReady = true`

**注意**：`npm run deploy:test` 不会自动重建派生镜像。`ensureHermesImage()` 仅检查镜像是否存在，不检查源文件新鲜度。**修改 `entrypoint-acp.sh` 或 `acp-tcp-server.py` 后，必须手动重新构建镜像**：

```bash
cd server/hermes-acp
docker build --build-arg HERMES_BASE_IMAGE=nousresearch/hermes-agent:latest \
  -t wattclaw-hermes-acp-le:latest -f Dockerfile .
```

并删除并重建 Hermes 容器（`docker restart` 只会重新运行旧的 baked entrypoint）。

### 2.2 ACP TCP 桥接 (`acp-tcp-server.py`)

这是运行在 Hermes 容器内的核心桥接组件。它是一个 asyncio TCP 服务器，每个 TCP 连接的处理流程：

1. 从 `acp_adapter.server` 导入 `HermesACPAgent`
2. 应用两个 monkey-patch：
   - `_patch_hermes_acp_model_routing()`：使 Hermes 从 `session/new` 和 `session/resume` RPC 调用以及 `cwd/runtime-config.json`（OpenClaw 投影的模型配置）中接受 `model` 参数
   - `_patch_hermes_observability()`：注入 `_OpenClawObservabilityBridge`
3. 为每个连接创建新的 `HermesACPAgent()` 实例
4. 创建 `acp.AgentSideConnection(agent, use_unstable_protocol=True)`
5. 调用 `conn.listen()` —— 连接的事件循环在此阻塞

#### 可观测性桥接 (`_OpenClawObservabilityBridge`)

解析 Hermes 内部的 API 调用日志，将其转换为结构化的 ACP 通知：

- **LLM 调用跟踪**：将 `API call #N: model=... provider=... in=... out=...` 日志解析为 `agent_llm_call` ACP 更新，包含 token 用量、耗时、模型信息
- **工具事件标准化**：添加 `toolCallId`、推断 `status` (completed/failed/cancelled)、用计时信息丰富 `_meta.openclaw`
- **会话状态快照**：跟踪模型、provider 和系统提示词

### 2.3 OpenClaw 插件 (`plugins/openclaw-plugin-hermes/`)

这是加载到每个租户 OpenClaw 容器中的插件。插件通过自注册 provider + harness 运行，**不需要**在 `openclaw.json` 的 `models.providers` 中预先注册 provider 定义。

#### 注册 (`index.ts`)

```typescript
api.registerProvider(buildHermesProvider({ pluginConfig }))     // 注册 hermes 模型 provider
api.registerAgentHarness(createHermesAgentHarness({ pluginConfig }))  // 注册 agent harness
```

注册 4 个 Tool：
- **`hermes_dispatch`**：委托任务给 Hermes；支持 L/C/W 策略（Context 级别 L0-L3、Credential 范围 C0-C2、Writeback 级别 W0-W3）
- **`hermes_status`**：Hermes 容器健康检查
- **`hermes_strategy`**：预检 L/C/W 策略推断（不实际执行）
- **`hermes_cancel`**：通过 dispatchId 或全部取消正在运行的任务

#### Harness (`harness.ts`)

```typescript
supports(ctx) {
  // 检查 ctx.provider === "hermes"（大小写不敏感）
  // 匹配时返回 { supported: true, priority: 100 }
}

runAttempt(params) {
  // 从插件配置创建 HermesRuntimeClient
  // 调用 client.runAttempt(params)
  // 映射 ACP 响应字段到 OpenClaw 的 AgentHarnessAttemptResult
}
```

#### 事件桥接 (`agent-event-bridge.ts`) — 流式修复

这是**流式推送工作**的关键。插件需要找到 OpenClaw 原生的 `emitAgentEvent` 函数，以便将流式的 assistant 事件（chat delta）发布到 OpenClaw 的事件总线。

**搜索路径**（按优先级排序）：

1. `require.resolve("openclaw/plugin-sdk/agent-harness")`
2. **`join(process.cwd(), "dist")`** → `/app/dist`（关键修复 — OpenClaw 在此目录下部署）
3. `/usr/lib/node_modules/openclaw/dist`
4. `/usr/local/lib/node_modules/openclaw/dist`

在每个 root 中搜索：
- `dist/plugin-sdk/agent-harness.js`
- `dist/infra/agent-events.js`
- `dist/plugin-sdk/src/infra/agent-events.js`
- 打包的文件：`/^agent-events-[\w-]+\.js$/`

**修复前**：只搜索了 `/usr/lib/` 和 `/usr/local/lib/`（均不存在于容器中），因此 `emitAgentEvent` 返回 `undefined`，导致**所有 assistant 流式帧被静默丢弃**。只有 `stream=lifecycle` 事件出现，因为它们由 OpenClaw 原生的 embedded-agent runner 发出。

**修复后**：添加了 `join(process.cwd(), "dist")`（即 `/app/dist`）→ 找到哈希化的 agent-events 打包文件 → 流式开始工作。

### 2.4 插件安装流程

在 `_provisionTenantContainer` 中（每个租户容器启动/重建时运行）：

1. **规划** (`planHermesPluginInstall`):
   - 如果 `hermesPluginAutoInstall` 为 false 或 `hermesEnabled` 为 false，则跳过
   - 获取 `getHermesPluginSourceState()` → `{ sourceHash, pluginVersion }`
   - 对比 `hermesPluginInstalled` 映射、`hermesPluginRetryAfter` 冷却、容器内标记文件
2. **安装**（如果需要）:
   - 通过 Docker archive API 将插件源 tar 包复制到 `/tmp/openclaw-plugin-hermes`
   - 运行 `openclaw plugins install /tmp/openclaw-plugin-hermes --force`
   - 安装到 `$HOME/.openclaw/extensions/openclaw-plugin-hermes`
   - 运行 `npm install --omit=dev --no-audit --no-fund --loglevel=error`（安装 `@opentelemetry/api` 等运行时依赖）
3. **标记**：写入 `/home/node/.openclaw/.openclaw-plugin-hermes-install.json`，内容为 `{ schemaVersion: 1, sourceHash, pluginVersion }`
4. **容器重启时**：从已安装的路径重新导入插件模块（JS 为启动时一次性导入）

### 2.5 模型路由

Hermes 在每次容器启动时，通过 `entrypoint-acp.sh` 将模型解析逻辑物化到 `$HERMES_HOME/config.yaml` 中：

```yaml
model:
  provider: oneapi
  default: gpt-5.6-luna

providers:
  oneapi:
    name: oneapi
    base_url: <OPENAI_BASE_URL>
    api_key: <OPENAI_API_KEY>
    default_model: gpt-5.6-luna
    api_mode: chat_completions
```

使用**命名自定义 provider** (`oneapi`) 而非裸 `provider: custom`，因为基础镜像中的裸自定义 provider 仅对 `openai.com`/`openrouter.ai` 主机进行基于主机的 env-key 回退（参见 Hermes 源码中的 `host-authoritative gating`）。命名 provider 会携带内联的 `base_url`、`api_key`、`default_model` 和 `api_mode: chat_completions`。

模型参数从 `acp-tcp-server.py` 的 monkey-patch 传播，该补丁：
1. 从 `session/new` 和 `session/resume` ACP RPC 调用中读取 `model`
2. 回退到 `cwd/runtime-config.json`（OpenClaw 在运行目录中投影的配置）
3. 在创建的 `AIAgent` 实例上强制设置 `agent.model`

### 2.6 流式链路（端到端）

完整的流式传播路径：

```
Hermes LLM (chat_completions + stream=True)
  → agent.stream_delta_callback → make_message_cb
  → session/update (agent_message_chunk/agent_message_text) ACP 帧
  → acp-tcp-server.py → TCP NDJSON 帧
  → openclaw-plugin-hermes ACP 客户端 (acp-client.js)
  → parseSessionEvent → { type: "text" }
  → harness-runtime.js handleHarnessEvent → onPartialReply({ text })
  → publishHermesHarnessAgentEvent(stream: "assistant")
  → agent-event-bridge.ts → emitAgentEvent({ runId, stream, data })
  → OpenClaw server-chat → broadcastChatDelta
  → WebSocket "chat state=delta" 广播
  → WattClaw 后端 SSE → 前端 extractMessages → 实时文本渲染
```

`chat delta` 负载形状：`{ runId, sessionKey, seq, state: "delta", message: { role: "assistant", content: [{ type: "text", text: "..." }] }, tenantId }`。Delta 是**累积的**（seq3="春"，seq5="春风"，...），而非增量 token。

---

## 3. Dedicated 模式 vs Shared 模式

WattClaw 支持两种 Hermes 部署模式，通过环境变量 `OPENCLAW_HERMES_MODE` 控制（默认 `dedicated`）。

### 3.1 对比总览

| 方面 | Dedicated（默认） | Shared |
|------|-------------------|--------|
| **容器与租户的关系** | 1:1（每个租户一个独立的 Hermes 容器） | 多:1（所有租户共享一个 Hermes 容器） |
| **容器命名** | `hermes-le-1`、`hermes-le-2` | `hermes-le-shared` |
| **宿主机数据目录** | `runtime/tenants/tenant-N/hermes/` | `runtime/tenants/hermes-shared/` |
| **execenv 路径** | `.../execenv/<taskHash>` (扁平) | `.../execenv/<tenantId>/<taskHash>` (租户范围) |
| **容器级隔离** | 完整（CPU/内存 cgroup、PID/挂载命名空间） | 租户之间无隔离 |
| **任务隔离** | 按 session-anchor 哈希隔离 | 按 session-anchor 哈希 + 租户前缀隔离 |

### 3.2 实现细节

#### 容器命名 (`hermesContainerNameFor`)

```javascript
// multi-tenant-gateway.js
hermesContainerNameFor(tenantId) {
  if (this.hermesMode === 'shared') {
    return `${prefix}-shared`   // e.g. hermes-le-shared
  }
  return `${prefix}-${id}`      // e.g. hermes-le-1 (id = tenantId 去掉 'tenant-' 前缀后的部分)
}
```

#### 数据目录 (`hermesSharedHostDir`)

```javascript
hermesSharedHostDir(dataSource) {
  if (this.hermesMode === 'shared') {
    // 所有租户解析为同一个目录
    return path.join(dirname(dataSource), 'hermes-shared')
  }
  // 每个租户有自己独立的目录
  return joinDockerHostPath(dataSource, 'hermes')
}
```

#### execenv 隔离 (`injectHermesConfig`)

**Shared 模式**下，配置注入为每个租户写入**租户范围内的 execenv 路径**：

```javascript
// openclaw-config-sync.js, injectHermesConfig()
if (cfg.hermesMode === 'shared') {
  execEnvRootDir = `${hermesDataDir}/execenv/${sanitizedTenantId}`
  runtimeExecEnvRootDir = `/opt/data/execenv/${sanitizedTenantId}`
} else {
  execEnvRootDir = `${hermesDataDir}/execenv`        // 扁平路径
  runtimeExecEnvRootDir = `/opt/data/execenv`
}
```

其中 `sanitizedTenantId` = `tenantId.replace(/[^A-Za-z0-9._-]/g, '_')`。这确保了同一台宿主机上的不同租户在共享的 Hermes 容器中不会互相覆盖对方的 task execenv。

任务隔离本身仍然基于 `sha256(sessionId || sessionFile || sessionKey || agentId)` 的 session-anchor 哈希，所以即使没有租户前缀，不同用户由于 sessionKey 不同也会得到不同的子目录。Shared 模式额外加了一层租户前缀。

#### 竞态保护

在 Shared 模式下，bootstrap 阶段通过 `Promise.all` 并行供应多个租户，可能导致对同一容器名的多个并发 `ensureHermesContainer` 调用。修复方案：

```javascript
// multi-tenant-gateway.js
ensureHermesContainer(tenant) {
  // ... 守卫检查 ...

  if (this.hermesMode === 'shared') {
    if (this.hermesContainerReady.has('__shared__')) return   // 已存在
    if (this.hermesSharedInflight) return this.hermesSharedInflight  // 合并在飞请求
    this.hermesSharedInflight = this._ensureHermesContainer(tenant)
      .finally(() => { this.hermesSharedInflight = null })
    return this.hermesSharedInflight
  }
  return this._ensureHermesContainer(tenant)
}
```

#### OpenClaw 绑定挂载

两种模式中，`buildBinds` 都会将 Hermes 数据目录挂载到 OpenClaw 容器中：

```javascript
// 可读写：execenv（任务执行环境）
`${hermesSharedHostDir}/execenv:${hermesDataDir}/execenv`
// 只读：skills（技能投影）
`${hermesSharedHostDir}/skills:${hermesDataDir}/skills:ro`
```

在 Shared 模式下，所有 OpenClaw 租户容器都挂载同一个 `hermes-shared/execenv` 根目录，但每个租户的 `execEnvRootDir` 被配置为以租户 ID 为前缀，因此任务 execenv 仍然是隔离的。

### 3.3 隔离性分析

**Dedicated 模式**：
- ✅ 容器级隔离（CPU/内存 cgroups、PID/mount ns）
- ✅ 网络隔离（每个租户独立容器，DNS 不同）
- ✅ 每个租户独立的 config.yaml / .env

**Shared 模式**：
- ❌ 无容器级隔离（CPU/内存 cgroups 共享）
- ❌ 无网络隔离（租户之间不隔离）
- ⚠️ execenv 子目录隔离（通过租户 ID 前缀）
- ⚠️ 每个租户独立的 ACP session（连接时为每个租户创建新的 `HermesACPAgent`）
- ℹ️ 实际上两种模式的任务级隔离是一致的：task execenv 由 `sha256(sessionId||sessionFile||sessionKey||agentId)` 隔离，不同用户 → 不同 sessionKey → 不同 execenv 哈希。**Shared 模式不会减弱单租户多用户之间的隔离**；失去的只是租户之间的容器级隔离。

---

## 4. 容器生命周期管理

### 4.1 配置解析 (`resolveConfig`)

所有 Hermes 配置在 `multi-tenant-gateway.js` 的 `resolveConfig()` 中解析：

| 配置键 | 环境变量 | 默认值 |
|--------|---------|--------|
| `hermesEnabled` | `OPENCLAW_HERMES_ENABLED` | `true` |
| `hermesMode` | `OPENCLAW_HERMES_MODE` | `'dedicated'` |
| `hermesBaseImage` | `HERMES_IMAGE` | `''`（空 = 跳过） |
| `hermesRuntimeImage` | `HERMES_RUNTIME_IMAGE` | `wattclaw-hermes-acp-<instanceId>:latest` |
| `hermesBuildContextDir` | `OPENCLAW_HERMES_BUILD_CONTEXT_DIR` | `server/hermes-acp` |
| `hermesContainerPrefix` | `OPENCLAW_HERMES_CONTAINER_PREFIX` | containerPrefix 替换 openclaw→hermes |
| `hermesAcpPort` | `OPENCLAW_HERMES_ACP_PORT` | `3100` |
| `hermesModel` | `HERMES_DEFAULT_MODEL` | `''` |
| `hermesDataDir` | `OPENCLAW_HERMES_DATA_DIR` | `/home/node/hermes-data` |
| `hermesContainerMemoryMb` | `OPENCLAW_HERMES_CONTAINER_MEMORY_MB` | `4096` |
| `hermesContainerCpus` | `OPENCLAW_HERMES_CONTAINER_CPUS` | `2` |
| `hermesAcpCmd` | `HERMES_ACP_CMD` | `''` |
| `hermesPluginDir` | `OPENCLAW_HERMES_PLUGIN_DIR` | `/app/plugins/openclaw-plugin-hermes` |
| `hermesPluginAutoInstall` | `OPENCLAW_HERMES_PLUGIN_AUTO_INSTALL` | `true` |
| `hermesPluginFailOnError` | `OPENCLAW_HERMES_PLUGIN_FAIL_ON_ERROR` | `false` |
| `hermesPluginInstallTimeoutMs` | `OPENCLAW_HERMES_PLUGIN_INSTALL_TIMEOUT_MS` | `600000` (10分钟) |
| `hermesPluginRetryCooldownMs` | `OPENCLAW_HERMES_PLUGIN_RETRY_COOLDOWN_MS` | `300000` (5分钟) |

**关键**：`server/index.js` 中的 `loadEnvConfig()` 使用**显式白名单**。每个环境变量必须单独在 `defaults` 块和 `return` 对象中列出（优先级：`process.env.X || fileConfig.X || defaults.X`）。如果添加了新的 Hermes 环境变量，必须同时在这两个地方添加。

### 4.2 容器创建流程

在 `ensureHermesContainer(tenant)` 内：

1. 守卫检查：`manageContainers`、`hermesEnabled`、`hermesBaseImage`（为空则 warn 并跳过）
2. **Shared 模式竞态合并**：如果在飞 → 等待同一 promise；如果已 ready → 返回
3. 调用 `_ensureHermesContainer(tenant)`：
   - 计算 `containerName`（`hermesContainerNameFor`）
   - 调用 `prepareHermesSharedDir` 创建 execenv/skills 子目录，权限 0777
   - 构建 binds：宿主机 Hermes 目录 → `/opt/data`
   - 构建 env：`OPENAI_API_KEY`、`OPENAI_BASE_URL`、`TZ`、`ACP_TCP_PORT`、`ACP_TCP_HOST`、`HERMES_DEFAULT_MODEL`
   - 检查已有容器：`shouldRecreateHermesContainer` → 如果存在偏差则删除并重新创建
   - 如果未运行则启动
   - 通过 Docker API `POST /containers/create` 创建容器，指定：
     - 镜像：`hermesRuntimeImage`（派生镜像）
     - 网络：与 OpenClaw 容器相同（`multi-openclaw-net`）
     - 内存/CPU 限制
     - 标签：`openclaw.gateway.role=hermes`、租户 ID、实例 ID
     - 重启策略：`unless-stopped`
4. 容器名作为网络 DNS 别名（同一 Docker 网络上的容器到容器 DNS 解析 —— 插件使用 `tcpHost`（即 containerName）连接）

### 4.3 偏差检测 (`shouldRecreateHermesContainer`)

比较以下各项以决定是否需要重建：
- 实例标签、项目根标签
- 镜像标签（检测派生镜像更新）
- Binds（挂载点变化）
- 环境变量（配置变化）
- Cmd（entrypoint/cmd 覆盖）

### 4.4 容器环境变量 (`buildHermesEnv`)

注入到 Hermes 容器的环境变量：

```
OPENAI_API_KEY=<来自 providerEnv>
OPENAI_BASE_URL=<来自 providerEnv>
TZ=<来自配置时区>
ACP_TCP_PORT=<hermesAcpPort>      # 默认 3100
ACP_TCP_HOST=0.0.0.0
HERMES_DEFAULT_MODEL=<hermesModel>  # 如 gpt-5.6-luna
```

### 4.5 跨容器权限（关键）

Host 目录 `runtime/tenants/tenant-N/hermes`（或 `runtime/tenants/hermes-shared`）通过 bind mount 在两个容器之间共享：

- **Hermes 容器**：以 **root** 运行，挂载到 `/opt/data`
- **OpenClaw 容器**：以 **node（uid 1000）** 运行，挂载到 `/home/node/hermes-data`

Hermes 最初创建 `HERMES_HOME` 时使用 `0700 root:root` 权限，这会阻止 uid 1000 访问。`entrypoint-acp.sh` 通过以下方式修复：

```bash
mkdir -p $HERMES_HOME/execenv
chmod 0777 $HERMES_HOME
chmod 0777 $HERMES_HOME/execenv
```

启动时**后台循环重新断言**是必要的，因为 `hermes gateway run` 在异步启动期间（约 20 秒）将 `$HERMES_HOME` 重新 chmod 为 0700。

---

## 5. 配置注入流程

### 5.1 同步时机

`injectHermesConfig(config, tenant)` 在每次调用 `syncTenantOpenClawConfigFromDB()` 时执行（同步周期 + 状态变化触发），具体在 DB 模型和 agent 默认值写入**之后**，确保 Hermes 的补充配置追加到已合并的配置中。

### 5.2 注入内容

对于每个租户的 `openclaw.json`，函数注入三个部分：

#### a) 插件配置 (`plugins.entries['openclaw-plugin-hermes']`)

```json
{
  "enabled": true,
  "config": {
    "transport": "tcp",
    "tcpHost": "<hermes-le-N 或 hermes-le-shared>",
    "tcpPort": 3100,
    "hermesContainerName": "<containerName>",
    "hermesDataDir": "/home/node/hermes-data",
    "execEnvRootDir": "/home/node/hermes-data/execenv[/<tenantId>]",
    "runtimeExecEnvRootDir": "/opt/data/execenv[/<tenantId>]",
    "mirrorExecEnvToContainer": true,
    "defaultModel": "gpt-5.6-luna"
  }
}
```

#### b) 模型 Provider (`models.providers.hermes`)

这是**必需的**：虽然插件在运行时通过 `api.registerProvider` 自注册 provider，但 OpenClaw 的 `sessions.patch` 模型验证是针对 `openclaw.json` 中的**静态列表**进行校验的。如果没有此项，`hermes/default` 会被拒绝，提示 "model not allowed"。

```json
{
  "hermes": {
    "baseUrl": "http://127.0.0.1/hermes-runtime",
    "apiKey": "hermes-runtime",
    "auth": "token",
    "api": "openai-responses",
    "agentRuntime": { "id": "hermes" },
    "models": [{
      "id": "default",
      "name": "default",
      "api": "openai-responses",
      "reasoning": true,
      "input": ["text", "image"],
      "contextWindow": 200000,
      "maxTokens": 32000,
      "cost": { "input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0 },
      "compat": { "supportsReasoningEffort": true, "supportsUsageInStreaming": true }
    }]
  }
}
```

#### c) Agent 默认别名 (`agents.defaults.models['hermes/default']`)

```json
{
  "hermes/default": {
    "alias": "hermes",
    "agentRuntime": { "id": "hermes" }
  }
}
```

这在前端启用 `hermes` 模型快捷方式。

### 5.3 免 exec 捷径

OpenClaw 插件包含一个 execenv 捷径：当 OpenClaw 的 `hostExecEnvPath`（替换了 `hermesDataDir`）与 Hermes 的 `runtimeExecEnvPath` 匹配时，跳过 execenv 构建步骤（参见 `execenv-builder.ts:456`）。Shared 模式下的租户范围路径（如 `/opt/data/execenv/tenant-1`）仍然匹配此捷径。

---

## 6. Docker 通信

所有容器操作通过 Docker Unix socket API (`/var/run/docker.sock`) 的 HTTP 客户端（`dockerRequest` 方法）完成：

```
POST /containers/create    - 创建容器
POST /containers/<id>/start   - 启动容器
DELETE /containers/<id>?force=true  - 强制删除
GET /containers/<id>/json    - 检查容器
POST /images/create?fromImage=<image>  - 拉取镜像
GET /images/<image>/json    - 检查镜像是否存在
POST /build?t=<tag>&dockerfile=<df>   - 构建镜像
PUT /containers/<id>/archive?path=<path>  - 向容器复制文件
```

`dockerRequest` 在流模式（pull/build）下会排空并解析整个响应；在非流模式下会收集 body 并 JSON 解析（2xx 时），或拒绝并返回 statusCode（错误时）。

---

## 7. 前端集成

### 7.1 Hermes 开关 (`ChatInput.vue`)

位于模型选择器前的药丸形切换按钮：

```typescript
const HERMES_MODEL = 'hermes/default'
const modelBeforeHermes = ref<string>('')
const hermesActive = computed(() => selectedModel.value === HERMES_MODEL)

function toggleHermesEngine() {
  if (props.collaborationMode) return
  if (hermesActive.value) {
    // 关闭：恢复之前的模型
    const restore = modelBeforeHermes.value || workspaceStore.availableModels[0] || ''
    if (restore && restore !== HERMES_MODEL) workspaceStore.previewModelChange(restore)
    modelBeforeHermes.value = ''
  } else {
    // 开启：保存当前模型，切换到 hermes
    modelBeforeHermes.value = selectedModel.value
    workspaceStore.previewModelChange(HERMES_MODEL)
  }
}
```

按钮在协作模式下隐藏。切换时保存/恢复上一个模型选择，以便在 Hermes 和非 Hermes 模式之间无缝切换。

---

## 8. 环境变量参考

### 8.1 必填

| 变量 | 说明 |
|------|------|
| `HERMES_IMAGE` | 上游基础镜像。**空 = 跳过所有 Hermes 容器创建** |

### 8.2 可选（含默认值）

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `OPENCLAW_HERMES_ENABLED` | `true` | 启用/禁用 Hermes 集成 |
| `OPENCLAW_HERMES_MODE` | `dedicated` | `dedicated` 或 `shared` |
| `HERMES_RUNTIME_IMAGE` | `wattclaw-hermes-acp-<instanceId>:latest` | 派生镜像名称 |
| `OPENCLAW_HERMES_CONTAINER_PREFIX` | containerPrefix 替换 openclaw→hermes | 容器名前缀 |
| `OPENCLAW_HERMES_ACP_PORT` | `3100` | ACP TCP 端口 |
| `HERMES_DEFAULT_MODEL` | `''` | 默认 LLM 模型（如 `gpt-5.6-luna`） |
| `OPENCLAW_HERMES_DATA_DIR` | `/home/node/hermes-data` | Hermes 在 OpenClaw 容器中的数据目录 |
| `OPENCLAW_HERMES_CONTAINER_MEMORY_MB` | `4096` | 每容器内存限制（MB） |
| `OPENCLAW_HERMES_CONTAINER_CPUS` | `2` | 每容器 CPU 限制 |
| `HERMES_ACP_CMD` | `''` | 覆盖容器的 CMD |
| `OPENCLAW_HERMES_BUILD_CONTEXT_DIR` | `server/hermes-acp` | 派生镜像构建上下文 |
| `OPENCLAW_HERMES_PLUGIN_DIR` | `/app/plugins/openclaw-plugin-hermes` | 插件源目录（ro 挂载） |
| `OPENCLAW_HERMES_PLUGIN_AUTO_INSTALL` | `true` | 自动安装插件到租户 |
| `OPENCLAW_HERMES_PLUGIN_FAIL_ON_ERROR` | `false` | 插件安装失败时是否中止 |
| `OPENCLAW_HERMES_PLUGIN_INSTALL_TIMEOUT_MS` | `600000` | 插件安装超时（毫秒） |
| `OPENCLAW_HERMES_PLUGIN_RETRY_COOLDOWN_MS` | `300000` | 安装失败重试冷却（毫秒） |

### 8.3 继承自 provider 配置

| 变量 | 说明 |
|------|------|
| `OPENAI_API_KEY` | LLM API 密钥（注入到 Hermes 容器环境） |
| `OPENAI_BASE_URL` | LLM API 基础 URL |

---

## 9. 常见问题排查

### 9.1 新服务器部署检查清单

1. **`.env` 文件** — gitignored，必须在服务器 `.env` 中手动添加 Hermes 块
   - 症状：`[Hermes] HERMES_IMAGE not set — skipping Hermes container creation`
2. **插件 dist/** — gitignored（`.gitignore:5 dist/`），复制到 `plugins/openclaw-plugin-hermes/dist/`
   - 症状：`[Hermes] Failed to install Hermes plugin ... plugin not found`
3. **入口点修改** — 需要手动重建派生镜像 + 删除/重新创建容器

### 9.2 流式不工作

1. 检查 `agent-event-bridge.ts` 是否包含 `/app/dist` 修复
2. 插件 dist/ 需要重新编译：`cd plugins/openclaw-plugin-hermes && npx tsc`
3. 重新编译的 dist 必须复制到**已安装的路径**（`$HOME/.openclaw/extensions/openclaw-plugin-hermes/dist/`），而非 ro 挂载
4. OpenClaw 容器需要**完整重启**（`docker restart`），而不仅仅是 `daemon restart`（后者不会重新导入 JS 模块）

### 9.3 模型被拒绝："model not allowed: hermes/default"

表示 `injectHermesConfig` 未将 `hermes` 添加到 `config.models.providers`。使用 `docker exec openclaw-le-N node openclaw.mjs config get models.providers` 检查。验证 `openclaw-config-sync.js` 是最新的（已烘焙到应用镜像中）。

### 9.4 EACCES execenv 错误

宿主机的 Hermes 数据目录权限不对。在宿主机上运行：
```bash
chmod -R 0777 runtime/tenants/<tenant-N>/hermes/execenv/
```

或通过 `docker exec hermes-le-N chmod 0777 /opt/data/execenv`（在容器重启前有效）。

### 9.5 Shared 模式：容器未创建

检查 `OPENCLAW_HERMES_MODE=shared` 是否同时出现在：
1. 服务器 `.env`
2. `loadEnvConfig` 默认值和返回值（`OPENCLAW_HERMES_MODE: 'dedicated'` → 需在 .env 中覆盖）
