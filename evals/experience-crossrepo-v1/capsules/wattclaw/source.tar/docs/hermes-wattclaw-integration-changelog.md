# Hermes 引擎接入 WattClaw — 改动实录

> **日期**: 2026-08-05
> **分支**: `lyh-multiagent`
> **目标**: 在 WattClaw 中实现「Hermes 引擎开关」——用户在对话框点一下开关，即可让一个容器化的 Hermes Agent 执行任务。每个 OpenClaw 租户容器（`openclaw-le-N`）1:1 配套一个 Hermes 容器（`hermes-le-N`），同处 `multi-openclaw-net` 网络。

本文档只记录**为接入 Hermes 而做的代码/配置改动与新增文件**。完整的运行时协议规格见 `docs/hermes-engine-switch-spec.md`。

---

## 1. 总览

接入分两条主线：

1. **前端开关**：`ChatInput.vue` 增加一个 Hermes 药丸按钮，本质是把会话模型切换到 `hermes/default`。
2. **后端编排**：每个租户容器旁自动拉起一个配套的 Hermes 容器，并向 OpenClaw 注入 `openclaw-plugin-hermes` 配置，让插件通过 ACP/TCP 与 Hermes 对话。

关键技术难点与结论：

- **协议不匹配**：`openclaw-plugin-hermes` 走的是 **ACP（Agent Client Protocol）over 裸 TCP**（NDJSON JSON-RPC，方法 `initialize` / `session/new` / `session/prompt`，默认端口 3100）。而官方基础镜像 `nousresearch/hermes-agent` 只暴露 OpenAI 兼容 HTTP（8642）+ 消息网关，**不说 ACP/TCP**。
- **解决方案：派生镜像**。基础镜像的 `/opt/hermes` 里其实带了 ACP 适配器（`acp_adapter.server.HermesACPAgent`），只是没通过 TCP 暴露。我们用一层薄薄的 TCP 包装（`acp-tcp-server.py`）把它暴露在 3100，再用 `entrypoint-acp.sh` 同时拉起 Hermes gateway + TCP 桥，构建成派生镜像 `wattclaw-hermes-acp-<实例>:latest`。
- **模型路由**：Hermes 从 `$HERMES_HOME/config.yaml` 的 `model.provider` 解析上游，**不看环境变量**。裸的 `provider: custom` 只对 `openai.com` / `openrouter.ai` 这类权威主机回落 `OPENAI_API_KEY`（安全门控 #28660），所以 `one-api.wattman.cn` 会被判成 `no-key-required` 丢 key。**修复=命名 custom provider**（见 §4）。

---

## 2. 新增文件

### 2.1 `server/hermes-acp/`（派生镜像构建上下文，随 app 镜像烤入）

`Dockerfile.wattclaw` 里有 `COPY server ./server`，所以这个目录会被烤进 WattClaw app 镜像，后端在运行时用它构建 Hermes 派生镜像。

| 文件 | 作用 |
|------|------|
| `Dockerfile` | 以 `nousresearch/hermes-agent` 为 base，`COPY` 两个脚本进 `/opt/hermes`，`ENTRYPOINT []` 绕过 base 的 s6 `/init`，`CMD entrypoint-acp.sh`，`EXPOSE 3100`。 |
| `acp-tcp-server.py` | asyncio TCP 服务，把 base 镜像里的 `HermesACPAgent` 通过裸 TCP 暴露（读 `ACP_TCP_PORT` / `ACP_TCP_HOST`）。从用户提供的 `src/utils/` 版本拷入。 |
| `entrypoint-acp.sh` | 双进程 entrypoint：后台 `hermes gateway run &` + 前台 `exec python3 acp-tcp-server.py`；并在每次启动时从容器环境变量物化 `.env` 与命名 provider 的 `config.yaml`。 |

**`Dockerfile` 关键点**：

```dockerfile
ARG HERMES_BASE_IMAGE=nousresearch/hermes-agent:latest
FROM ${HERMES_BASE_IMAGE}
COPY acp-tcp-server.py /opt/hermes/acp-tcp-server.py
COPY entrypoint-acp.sh /opt/hermes/entrypoint-acp.sh
USER root
RUN chmod +x /opt/hermes/entrypoint-acp.sh /opt/hermes/acp-tcp-server.py
ENV ACP_TCP_PORT=3100
ENV ACP_TCP_HOST=0.0.0.0
EXPOSE 3100
ENTRYPOINT []
CMD ["/opt/hermes/entrypoint-acp.sh"]
```

**`entrypoint-acp.sh` 关键点**（相较用户参考版的修正）：

1. **删掉了会崩的 `cp $INSTALL_DIR/.env.example`**：该文件在 base 镜像里**根本不存在**，`set -e` 下会直接让脚本挂掉。改为从注入的容器环境变量物化 `.env`（`OPENAI_BASE_URL` / `OPENAI_API_KEY` / `TZ`）。
2. **物化命名 provider 的 `config.yaml`**（见 §4），用 `python3` + PyYAML（镜像自带 6.0.3），带手写 YAML 回落。每次启动都重写 → 凭据轮换能生效。
3. **`export HERMES_ALLOW_ROOT_GATEWAY=1`**：容器以 root 运行（base `USER=root`），gateway 默认拒绝 root 会留一个僵死后台进程。ACP 桥才是唯一关键路径，但这行让 gateway 也能干净启动。

### 2.2 `src/utils/`（用户提供的参考原件）

这几个是用户放置的参考文件，`entrypoint-acp.sh` 与 `acp-tcp-server.py` 已同步到 `server/hermes-acp/`：

- `src/utils/acp-tcp-server.py`
- `src/utils/entrypoint-acp.sh`（与 `server/hermes-acp/` 副本保持一致）
- `src/utils/docker-compose.yml`（base 镜像的默认 compose 参考，未使用）

### 2.3 `plugins/openclaw-plugin-hermes/`

Hermes 插件 v2.0.1 完整解包（含随包提交的 `dist/` 与 `node_modules/`）。插件在 OpenClaw 启动时同时注册 provider 与 agent-harness，因此无需向 `openclaw.json` 注入 `models.providers.hermes`。

### 2.4 `docs/hermes-engine-switch-spec.md`

完整运行时协议规格（阶段 0~5、ACP 通信、execenv 投影、数据模型等）。

---

## 3. 修改的文件

### 3.1 `server/core/multi-tenant-gateway.js`（+420 行）

后端编排的核心。主要增量：

- **`resolveConfig`**：解析 Hermes 相关配置字段。派生镜像架构下拆成三个镜像概念：
  - `hermesBaseImage` = `HERMES_IMAGE`（需 pull 的上游 base）
  - `hermesRuntimeImage` = `HERMES_RUNTIME_IMAGE` 或默认 `wattclaw-hermes-acp-<instanceId>:latest`（构建产物）
  - `hermesBuildContextDir` = `OPENCLAW_HERMES_BUILD_CONTEXT_DIR` 或 `path.join(moduleDir, 'hermes-acp')`
  - 因是 ESM，额外定义了 `moduleDir = path.dirname(fileURLToPath(import.meta.url))` 和 `instanceId`。
- **`ensureHermesImage()`**：若派生镜像已存在则跳过；否则先 `ensureHermesBaseImage()`（GET base，404 则 pull），再 `POST /build?t=<derived>&dockerfile=Dockerfile&buildargs=...`（body 为 `createDirTarFlat(ctxDir)`）。因 **`/build` 即使失败也返回 200**，构建后再 `GET /images/<derived>/json` 确认存在才置 `hermesImageReady=true`。
- **`createDirTarFlat(dir)`**：新助手，把文件放在 tar **根部**（docker build 上下文要求 Dockerfile 在根，不能有包裹目录），排除 `node_modules`。
- **`ensureHermesContainer` / `buildHermesEnv` / `hermesContainerNameFor` / `hermesSharedHostDir` / `shouldRecreateHermesContainer`**：容器生命周期管理。
  - `buildHermesEnv` 注入 `OPENAI_API_KEY` / `OPENAI_BASE_URL`（来自 `providerEnv`）+ `TZ` + `ACP_TCP_PORT` + `ACP_TCP_HOST=0.0.0.0` + `HERMES_DEFAULT_MODEL`。
  - 容器创建时 `Image=hermesRuntimeImage`；漂移检测比对 `actualImage !== hermesRuntimeImage`。
- **`buildBinds`**：把 `${sharedHostDir}:${hermesDataDir}` 挂进 OpenClaw 容器；Hermes 容器把同一 host 目录挂在 `/opt/data`（execenv 免-exec 捷径）。
- **在 `_provisionTenantContainer` 里 best-effort 调用**：让 `deploy:test` 触发的租户 provisioning 路径顺带构建/拉起 Hermes（无需改 `deploy-test.sh`）。
- **插件安装计划**：为 hermes 插件生成 install/marker（镜像 prompt-capture 那套），`npm install --omit=dev`。**在 `hashDirectory`（plugin-fingerprint.js）和 `createDirTar` 里都排除了 `node_modules`**——hermes 带 70M node_modules，容器内 npm install 会重生。

### 3.2 `server/openclaw-config-sync.js`

- 新增 **`injectHermesConfig(config, tenant)`**：向 `plugins.entries['openclaw-plugin-hermes']` 写入 `{enabled:true, config:{transport:'tcp', tcpHost:<hermes-le-N>, tcpPort, hermesContainerName, hermesDataDir, runtimeExecEnvRootDir:'/opt/data/execenv', mirrorExecEnvToContainer:true, defaultModel}}`。
- `tcpHost` **必须**是该租户的 Hermes 容器名（不能是默认 127.0.0.1），才能在 `multi-openclaw-net` 上按容器 DNS 互通。
- `syncTenantOpenClawConfigFromDB(filePath, tenant=null)` 扩展了可选 `tenant` 参数；每次 sync 都跑，对 model-health-monitor 的再同步是幂等的。
- 门控从 `hermesImage` 改为 `hermesBaseImage`。

### 3.3 `server/core/plugin-fingerprint.js`

- `hashDirectory` 遍历时 `if (name === 'node_modules') continue`——避免把 hermes 的 70M node_modules 计入指纹（容器内会重新 npm install）。

### 3.4 `src/views/workspace/ChatInput.vue`（前端开关）

- 常量 `HERMES_MODEL = 'hermes/default'`；`hermesActive = computed(() => selectedModel === HERMES_MODEL)`。
- `toggleHermesEngine()`：开启时存下 `modelBeforeHermes` 再 `previewModelChange('hermes/default')`；关闭时恢复原模型。
- 在 ModelDropdown 前面加了 `.hermes-btn` 药丸按钮，带 `.hermes-active` 高亮态。

### 3.5 `src/i18n/messages/zh-CN.ts`

- 新增 `pages.workspace.chat.hermes.{label, enable, disable}`。（项目实际只有 `zh-CN.ts`，无 `en-US`。）

### 3.6 `docker-compose.test.yml` / `docker-compose.wattclaw.yml`

- 两个 compose 都加了：`- ./plugins/openclaw-plugin-hermes:/app/plugins/openclaw-plugin-hermes:ro`

### 3.7 `.env.test.example`

新增 Hermes 相关变量：

| 变量 | 说明 |
|------|------|
| `OPENCLAW_HERMES_ENABLED` | 是否启用（false 关闭全部 Hermes 容器与插件注入） |
| `HERMES_IMAGE` | 上游 base 镜像（=`nousresearch/hermes-agent:latest`），后端叠加 ACP 层构建派生镜像 |
| `OPENCLAW_HERMES_CONTAINER_PREFIX` | Hermes 容器名前缀（留空由 OpenClaw 前缀派生） |
| `OPENCLAW_HERMES_ACP_PORT` | ACP 端口（默认 3100，容器间访问，不对外发布） |
| `HERMES_DEFAULT_MODEL` | `hermes/default` 映射的上游模型 id（=`gpt-5.6-luna`） |
| `OPENCLAW_HERMES_DATA_DIR` | OpenClaw 容器内共享 execenv 投影目录挂载路径 |
| `OPENCLAW_HERMES_CONTAINER_MEMORY_MB` / `_CPUS` | 资源上限 |
| `HERMES_ACP_CMD` | 若镜像不自启 ACP 的备用启动命令 |

---

## 4. 模型路由（关键坑，已解决）

**根因**：`hermes_cli.runtime_provider.resolve_runtime_provider(requested=None)` 从 `$HERMES_HOME/config.yaml` 的 `model.provider` 读取上游，**不看环境变量**。而裸的 `provider: custom` + `base_url` 只对 `openai.com` / `openrouter.ai` 这类权威主机才回落 `OPENAI_API_KEY`（#28660 host-authoritative 门控），`one-api.wattman.cn` 会被判成 `api_key="no-key-required"` → key 丢失。

（早先误以为 "auto→openrouter" 是 bug，实际是测试时手动传了 `requested='auto'` 覆盖了 config；真实路径传 `None`，`resolve_requested_provider` 会回落到 config 的 `model.provider`。）

**修复 = 命名 custom provider**。`entrypoint-acp.sh` 每次启动物化如下 `config.yaml`：

```yaml
model:
  provider: oneapi
  default: gpt-5.6-luna
providers:
  oneapi:
    name: oneapi
    base_url: http://one-api.wattman.cn:805/v1
    api_key: <注入的 OPENAI_API_KEY>
    default_model: gpt-5.6-luna
    api_mode: chat_completions
```

解析结果：`provider=custom, base_url=one-api, model=gpt-5.6-luna, api_key=<真实 key>, source=pool:custom:oneapi`——inline key 和模型都带上了。

---

## 5. 本地验证（已通过）

- 派生镜像构建成功（3.95GB）。
- ACP TCP 桥监听 `0.0.0.0:3100`。
- `initialize` 返回 `hermes-agent 0.20.0`，`authMethods` 含 `custom`。
- `session/new` 返回 sessionId。
- 两进程都存活（ACP=PID1，gateway=PID12），无 root 拒绝。
- `config.yaml` 正确物化为命名 provider。

**尚未做**：真实 key 跑一次 prompt→one-api 往返；生产部署（server 代码烤进镜像，需 `npm run deploy:test` 重建）。

镜像拉取：本机 Docker Hub 直连被墙，用镜像前缀 `docker pull docker.m.daocloud.io/nousresearch/hermes-agent:latest`。

---

## 6. 部署方式

`npm run deploy:test` 即可让功能生效：

- app 镜像重建会把 `server/hermes-acp/`（构建上下文）与后端编排代码烤进去。
- 租户 provisioning 时后端 best-effort：pull base 镜像 → 构建派生镜像 → 拉起 Hermes 容器 → 向 `openclaw.json` 注入插件配置。
- 无需改 `deploy-test.sh`。
