# 历史记录解析 Bug 复盘

## 问题概述

历史聊天记录（History API）加载后，thinking 过程、toolCall 调用、toolResult 结果被错误地渲染为普通文本气泡，而不是折叠在可展开的工具面板（ToolGroupCard）中。

---

## 时间线与每次修改

### Phase 1: 表面症状修复（5 月 12 日）

**Commit: `266c5b9`** — 识别 mixed thinking+toolCall content

- **症状**: assistant 消息包含 thinking + toolCall，但 `isToolCallOnlyMsg` 没有识别 thinking，导致这些消息被当作普通文本渲染。
- **修改**: 在 `MessageList.vue` 的 `isToolCallOnlyMsg` 中增加对 `thinking` 类型的判断。
- **遗留问题**: 只是让工具调用消息被过滤掉，但没有真正提取和渲染 thinking/toolCall 内容。内容仍然丢失或错误渲染。

---

### Phase 2: 内容丢失与合并错误（5 月 13 日）

**Commit: `5676954`** — 修复历史记录加载时内容丢失问题

- **症状**: 加载历史记录后，多条 assistant 消息只剩下最后一条（"复读机"/"气泡克隆"）。
- **根因 1**: `normalizeHistoryMessage` 没有从 `responseId` / `__openclaw.id` 中提取消息 ID，导致所有 assistant 消息的 `id` 为 `undefined`。
- **根因 2**: `smartMerge` 的 emergency guard 在没有 ID 时，会把后面的 assistant 消息覆盖到前面的消息上。
- **修改**:
  - 提取 `responseId` / `__openclaw.id` 作为消息 ID
  - `smartMerge` 增加 `isStreaming` 参数，emergency/ultra-emergency 覆盖逻辑仅在 `isStreaming=true` 时生效
- **遗留问题**: thinking 和 toolCall 仍然被嵌入 content 字符串中，当成正文渲染。

**Commit: `59283f9`** — 大规模修复（ID + smartMerge + 过滤 + content 污染）

- **症状**: 消息丢失、Thinking 错误渲染为正文、工具调用不折叠。
- **根因**:
  1. ID 缺失（同上）
  2. `smartMerge` 的 ultra-emergency 对流式和历史记录不加区分
  3. `isToolCallOnlyMsg` 过滤掉仅含 thinking+toolCall 的 assistant 消息，导致中间轮次消失
  4. `normalizeHistoryMessage` 把 toolCall JSON 塞进 content 字符串
- **修改**:
  - `normalizeHistoryMessage` 提取 ID，assistant content 中排除 toolCall JSON
  - `smartMerge` 区分流式/历史加载
  - `MessageList` 移除 `isToolCallOnlyMsg` 过滤
- **遗留问题**: 只是排除了 toolCall JSON，但没有把 thinking/toolCall 提取到 activities 中。内容仍然以某种形式丢失。

---

### Phase 3: 内容分流架构（5 月 13 日深夜）

**Commit: `5ab167d`** — 历史记录内容分流：text 正文 vs thinking/tool 折叠面板

- **核心思路**: 把 assistant content 数组拆开：
  - `text` 块 → 普通 message
  - `thinking` / `toolCall` 块 → AgentActivity
- **修改**:
  - `normalizeHistoryMessage` 只保留 `type === 'text'` 的块到 content
  - 新增 `extractHistoryActivities`：遍历 `rawContent`，将 thinking/toolCall 重建为 `AgentActivity`
  - `_msgCount = msgIdx + 1` 确保 activities 插入到对应消息之后
  - `selectSession` 合并历史消息后调用 `extractHistoryActivities`
  - `MessageList.getThinkingContent` 移除 rawContent 回退逻辑
- **遗留问题**: `extractHistoryActivities` 的 `_msgCount` 计算不准确，activities 和消息的顺序错乱；没有处理同一 assistant 的多个 text 块；toolResult 无法关联到对应的 toolCall。

**Commits: `8f9a7ef`, `8b591ae`** — 迭代修复混合内容解析

- 修复了部分边缘情况，但核心架构问题（`_msgCount` 不准确、分组边界不清）仍然存在。

---

### Phase 4: Sequential Chunking 重构（5 月 14 日凌晨）

**Commit: `fca9236`** — 历史记录解析改为顺序分组截断

- **核心思路**: 用户提出了 "Sequential Chunking" 算法——按 content 数组原始顺序遍历，text 截断并关闭前一个 tool group。
- **修改**:
  - 废弃 `normalizeHistoryMessage` + `extractHistoryActivities`
  - 新增 `parseHistoryMessages`：按 content 数组顺序遍历
    - `thinking` / `toolCall` 积攒到 `currentToolGroup`
    - 遇到 `text` 立即 `flushToolGroup` 并截断
    - 文本分配子 ID（`-part1`）防止重复 key
  - `AgentActivity` 新增 `groupId`，用于区分不同 assistant 的工具分组
  - `processedMessages` 构建 `callGroupMap`，为 toolResult 消息打上 `_groupId`
  - `groupedTimeline` 按 `groupId` 分隔不同 assistant 的工具分组
  - `ToolGroupCard` 支持 `thinking` 类型渲染
- **引入的新 Bug 1**: `parseHistoryMessages` 创建的 text 子消息没有保留 `rawContent`，导致 `processedMessages` 中的 `callMap`/`callGroupMap` 无法构建。
- **引入的新 Bug 2**: toolResult 消息没有 `_groupId`，`groupedTimeline` 无法将其归入对应的 tool-group。

**Commit: `c4849b6`** — 修复 tool 结果消息无法归入工具分组

- **修改**:
  - `parseHistoryMessages` 新增 `toolCallRegistry`，在解析时注册 `toolCallId → {name, args, groupId}`
  - tool 角色消息直接附加 `_groupId` 和 `_toolCallArgs`
  - 文本子消息保留 `rawContent`
  - `processedMessages` 优先使用已存在的 `_groupId`/`_toolCallArgs`
  - 修复 groupId 提取时未去掉 `-part` 后缀
- **遗留问题**: 同一个 assistant 的 thinking 和 toolCall 被 text 拆成了两个独立的 activity 组。

**Commit: `0305187`** — 修复 thinking 和 toolCall 被 text 拆成多个 tool-group

- **症状**: assistant content = `[thinking, text, toolCall]` 时，thinking 和 toolCall 被渲染为两个独立的 collapsible panel。
- **根因**: `parseHistoryMessages` 在遇到 text 时调用了 `flushToolGroup`，把前面积攒的 thinking flush 掉了。后面剩余的 toolCall 在循环结束时又被 flush 一次。
- **修改**: 不再在 text 处 flush，而是收集所有非 text block（thinking + toolCall），在循环结束后一次性 flush。
- **遗留问题**: **完全没有 tool-group 显示了**。

---

### Phase 5: 终极根因（5 月 14 日）

**Commit: `9124b59`** — parseHistoryMessages 未使用 rawContent

- **症状**: 完全没有 tool-group 显示，跟修改前一样。
- **终极根因**: `rpc-client.ts` 中的 `normalizeChatMessageItem` 在返回前，已经把 assistant 的 `content` 数组**转换成了纯文本字符串**，原始数组被保存在了 `rawContent` 字段中。

```typescript
// rpc-client.ts normalizeChatMessageItem
if (Array.isArray(rawContent)) {
  rawContentArray = rawContent.map(...)  // 保存原始数组
  contentText = rawContent.map(...).join('\n')  // 转成字符串
}
return {
  content: contentText,      // ← 已经是字符串
  rawContent: rawContentArray, // ← 原始数组在这里
}
```

`parseHistoryMessages` 检查的是 `Array.isArray(row.content)`，但此时 `content` 已经是字符串，**永远为 `false`**。整个 assistant 分支直接跳过，thinking/toolCall 完全没有被提取。

- **修改**: `parseHistoryMessages` 优先使用 `row.rawContent`（如果存在且是数组），否则回退到 `row.content`。

```typescript
const rawBlocks = Array.isArray(row.rawContent)
  ? row.rawContent
  : Array.isArray(row.content)
    ? row.content
    : null
if (role === 'assistant' && rawBlocks) {
  for (const block of rawBlocks) { ... }
}
```

---

## 为什么会出这么多次错误

### 1. 对数据流的理解不完整

最大的问题是：**我在写 `parseHistoryMessages` 时，不知道 `normalizeChatMessageItem` 已经把 `content` 数组转成了字符串。**

`rpc-client.ts` 的 `normalizeChatMessageItem` 是一个已有的数据规范化层。所有从 Gateway 获取的数据都会经过它。我在 `workspace.ts` 中基于"`row.content` 仍然是数组"的假设写了 `parseHistoryMessages`，但这个假设在真实数据流中是错误的。

### 2. 修复范围过大，引入了级联 Bug

从 `5ab167d` 开始，每次修复都是"大规模重构"，一次性修改解析逻辑、合并逻辑、渲染逻辑。这导致：
- 新代码未经充分测试就提交
- 一个修复引入多个新 Bug
- 难以定位哪个修改导致了新问题

### 3. 缺乏对真实 API 数据的验证

在 `9124b59` 之前，所有修复都是基于代码逻辑推导，没有使用真实的 `a.json` 数据做端到端验证。直到用户要求"写一个单元测试专门解析 a.json"，才通过测试脚本发现了根本问题。

### 4. 复杂度过高

历史记录解析涉及多个层：
- `rpc-client.ts` — 数据规范化
- `workspace.ts` — store 逻辑、smartMerge、activities 管理
- `MessageList.vue` — 消息渲染、timeline 计算、分组逻辑

任何一层的问题都会导致最终渲染错误。由于这些层之间的数据契约没有被文档化，调试时需要在多层之间来回跳跃。

---

## 正确的最终方案

### 数据流

```
Gateway API 返回 raw JSON
    ↓
rpc-client.ts normalizeChatMessageItem
  - content → 纯文本字符串
  - rawContent → 原始 content 数组（ChatMessageContent[]）
    ↓
workspace.ts parseHistoryMessages
  - 使用 row.rawContent 遍历原始数组
  - text 块 → ChatMessage（role=assistant, content=text）
  - thinking/toolCall 块 → AgentActivity（groupId = assistant ID）
  - tool 结果 → ChatMessage（_groupId 从 toolCallRegistry 获取）
    ↓
workspace.ts smartMerge（历史加载时 isStreaming=false）
    ↓
MessageList.vue processedMessages
  - 为 tool 消息附加 _groupId / _toolCallArgs
    ↓
MessageList.vue unifiedTimeline
  - messages 和 activities 按 _msgCount 交错排列
    ↓
MessageList.vue groupedTimeline
  - 相同 groupId 的 activities + tool messages 合并为 tool-group
  - 其他 messages 正常渲染
```

### 核心原则

1. **同一 assistant 的所有非 text 块（thinking + toolCall）合并为一个 activity 组**
   - 即使 content 数组是 `[thinking, text, toolCall]`，thinking 和 toolCall 仍然在同一个 group
   - 不在 text 处 flush，只在循环结束后一次性 flush

2. **tool 结果消息通过 `_groupId` 关联到对应的 tool-group**
   - `toolCallRegistry` 在解析时记录 `toolCallId → groupId`
   - tool 消息直接附加 `_groupId`

3. **优先使用 `rawContent` 解析原始数组**
   - `normalizeChatMessageItem` 已经把 `content` 转成字符串
   - `rawContent` 是唯一的原始数组来源

---

## 经验教训

1. **修改前必须理解完整数据流**：`parseHistoryMessages` 的输入不是 Gateway 原始 JSON，而是经过 `normalizeChatMessageItem` 处理后的 `ChatMessage[]`。
2. **大重构必须配合端到端测试**：用真实 API 响应（如 `a.json`）跑完整流程，验证每个中间状态。
3. **小步迭代优于大爆炸重构**：每次只改一个问题，验证通过后再改下一个。
4. **状态缓存（_processedCache）会隐藏问题**：如果 computed 的 cacheKey 设计不当，修改了消息内部属性但 cacheKey 不变，会导致旧缓存被返回。
