# WattClaw 网关接入层重构：从混合 RPC 到三层分离架构

> 分支：`test/http-ws-separation`
> 涉及文件：后端路由、前端 Store、SSE 流代理服务

---

## 一、重构前的架构（Before）

### 1.1 整体数据流

```
┌─────────────┐      HTTP POST        ┌──────────────┐      WebSocket RPC      ┌──────────┐
│  Vue 前端   │  ───────────────────► │ WattClaw后端  │  ─────────────────────► │  Gateway │
│             │  /api/rpc {method}    │  server/     │  gateway.call(method)   │  WS RPC  │
└─────────────┘                       └──────────────┘                         └──────────┘
                                                                             │
                                                                             ▼
                                                                      ┌──────────────┐
                                                                      │ Gateway HTTP │
                                                                      │ /v1/chat/... │
                                                                      └──────────────┘
```

### 1.2 三个平面的状态

| 平面 | 端点 | 协议 | 问题 |
|------|------|------|------|
| **控制面** | `POST /api/rpc` | HTTP → WS RPC 代理 | 所有请求串行走同一条 WS 连接，队头阻塞 |
| **数据面** | `POST /api/workspace/send` | HTTP → WS RPC → SSE 透传 | 双层 SSE 代理，无 keepalive，代理 60s 超时 |
| **事件面** | `GET /api/events` | WS → SSE 转发 | 基本可用，但和控制面共享 WS 连接 |

### 1.3 具体痛点

#### 痛点 1：单条 WebSocket 队头阻塞

前端所有操作（`sessions.list`、`config.patch`、`chat.history`）都通过 `POST /api/rpc` 打到后端，后端通过**单一** WebSocket 连接代理到 Gateway。

```javascript
// 前端：所有方法走同一个端点
wsStore.rpc.listSessions()   → POST /api/rpc {method: 'sessions.list'}
wsStore.rpc.patchConfig(...) → POST /api/rpc {method: 'config.patch'}
wsStore.rpc.getHistory(...)  → POST /api/rpc {method: 'chat.history'}
```

WebSocket 是**串行**协议，一个请求在途时，后续请求必须排队。如果 `sessions.list` 因为 Gateway 繁忙耗时 5 秒，那这期间 `chat.history` 和 `config.patch` 全部被阻塞。

#### 痛点 2：Config 修改的 OCC 冲突

`config.patch` 需要前端先 `getConfig` 获取当前 snapshot，计算 `baseHash`，构建 `raw` 字符串，再发送给后端。后端通过 `ConfigQueue` 做乐观并发控制。

```javascript
// 前端：需要完整获取 snapshot、算 hash、拼 raw
const config = await wsStore.rpc.getConfig()
const baseHash = computeHash(config)
const raw = JSON.stringify(mergePatch(config, patches))
await wsStore.rpc.patchConfig({ baseHash, raw })
```

问题在于：
- 前端需要理解 Gateway 的内部 hash 机制
- 并发修改时（如同时改 agent 主题和 channel 配置），hash 冲突频繁
- 前端要写复杂的 retry 逻辑

#### 痛点 3：历史记录无分页，大数据量卡顿

`chat.history` 通过 WS RPC 获取，Gateway 返回完整 transcript。后端只是简单截断尾部：

```javascript
result.transcript = result.transcript.slice(-messageLimit)
```

对于长会话（上千条消息），每次切换会话都要传输全部数据，前端渲染卡顿（实测 20ms ~ 10s）。

#### 痛点 4：SSE 流没有保活，代理超时

聊天流 `POST /api/workspace/send` 的链路：

```
Gateway SSE ──► WattClaw 后端 SSE ──► 前端 EventSource
```

双层透传，没有任何心跳。当模型推理时间较长（如 DeepSeek-R1、o1 需要 30s~2min 才出第一个 token）时，Nginx 或 Cloudflare 会在 60s 无数据时强制断开连接，用户看到"连接已断开"。

---

## 二、重构后的架构（After）

### 2.1 整体数据流

```
┌─────────────┐                    ┌──────────────┐
│  Vue 前端   │ ──REST /api/sessions│              │
│             │ ──REST /api/config  │              │     WebSocket RPC     ┌──────────┐
│  (控制面)   │ ──REST /api/chat/...│ WattClaw后端  │ ◄───────────────────► │ Gateway  │
│             │                     │  server/     │  (仅保留未迁移方法)    │ WS RPC   │
│             │ ──HTTP POST /api/   │              │                       └──────────┘
│  (数据面)   │    workspace/send   │              │     HTTP POST         ┌──────────────┐
│             │ ──SSE /api/events   │              │ ────────────────────► │ Gateway HTTP │
│  (事件面)   │                     │              │  /v1/chat/completions │ SSE Stream   │
└─────────────┘                    └──────────────┘                       └──────────────┘
```

### 2.2 三层分离模型

| 平面 | 端点 | 协议 | 职责 |
|------|------|------|------|
| **控制面 REST** | `GET /api/sessions`<br>`PATCH /api/config`<br>`GET /api/chat/history` | HTTP | 管理操作：会话列表、配置修改、历史查询 |
| **数据面 SSE** | `POST /api/workspace/send` | HTTP SSE | 聊天流：直连 Gateway HTTP SSE，15s keepalive |
| **事件面 SSE** | `GET /api/events` | SSE | 实时事件：Gateway WS → 后端 SSE → 前端 |

### 2.3 控制面 REST 详细设计

#### `GET /api/sessions`

```javascript
// 之前
await wsStore.rpc.listSessions()  → POST /api/rpc {method: 'sessions.list'}

// 之后
await fetch('/api/sessions')      → 独立 HTTP GET
```

后端逻辑：
- Admin：返回 `allSessionsPolling` 缓存全部 sessions + SQLite title 合并
- 普通用户：缓存过滤 `filterOwnedSessions` + 本地 title 合并

#### `PATCH /api/config`

```javascript
// 之前：前端算 hash、拼 raw
const config = await wsStore.rpc.getConfig()
const raw = JSON.stringify(mergePatch(config, patches))
await wsStore.rpc.patchConfig({ baseHash, raw })

// 之后：只传结构化 patches
await fetch('/api/config', {
  method: 'PATCH',
  body: JSON.stringify({ patches: [{ path: 'agents.list', value: ... }] })
})
```

后端逻辑：
- 接收 `{ patches: ConfigPatch[] }`
- 后端调用 `gateway.call('config.get', {})` 获取当前 snapshot
- 计算 baseHash，构建 raw
- 通过 `ConfigQueue` 序列化执行 `config.patch` + `config.apply`
- **前端不再需要理解 hash 机制**

#### `GET /api/chat/history?sessionKey=xxx&limit=50&cursor=xxx`

```javascript
// 之前：无分页，返回完整 transcript
await wsStore.rpc.listChatHistory(sessionKey)  → POST /api/rpc {method: 'chat.history'}

// 之后：cursor 分页
await fetch(`/api/chat/history?sessionKey=${key}&limit=50`)
```

后端逻辑：
- 检查 `isSessionOwned(sessionKey)`
- 调用 Gateway HTTP `GET /sessions/{key}/history?limit=N&cursor=xxx`
- 返回 `{ messages, cursor, hasMore }`
- 支持前端按需加载更多历史

### 2.4 数据面 SSE 优化

```typescript
// ChatStreamProxyService 双定时器设计
const KEEPALIVE_INTERVAL_MS = 15000   // 15s 心跳，防代理断开
const IDLE_TIMEOUT_MS = 180000        // 3min 硬上限，防真死锁
```

| 场景 | 行为 |
|------|------|
| 正常流式 | 数据到来 → 重置 keepalive + idle 两个定时器 |
| 模型思考中（无数据）| 每 15s 发送 `:keepalive\n\n`，连接保持 |
| 真卡死/断网 | 180s 无数据 → `finalize('timeout')` |

---

## 三、为什么要改成这种架构

### 3.1 根本原因：WebSocket 不适合做控制面

WebSocket 的设计目标：**双向低延迟推送**。但 WattClaw 的控制面操作（拉列表、改配置、查历史）是典型的**请求-响应**模式，HTTP 完全胜任。

把控制面绑在 WebSocket 上带来的问题：
- **串行瓶颈**：一个慢请求阻塞所有后续请求
- **无缓存语义**：HTTP 可以走 CDN/缓存，WS 不行
- **调试困难**：所有请求都是 `POST /api/rpc` + body，DevTools 里看不出调了什么
- **Gateway 耦合**：WattClaw 后端变成了"透明代理"，没有增值空间

### 3.2 分层是工程上的最优解

| 平面 | 适合的协议 | 理由 |
|------|-----------|------|
| 控制面 | HTTP REST | 无状态、可缓存、并行、语义清晰 |
| 数据面 | HTTP SSE | 单向流、浏览器原生支持、可 keepalive |
| 事件面 | WebSocket | 双向推送、低延迟、Server→Client 主动发 |

**让正确的协议做正确的事**。

### 3.3 具体收益

#### 收益 1：消除队头阻塞

三个 REST 端点独立并行，互不干扰：
- `GET /api/sessions` 慢不影响 `PATCH /api/config`
- `GET /api/chat/history` 可以和其他请求同时发起

#### 收益 2：ConfigQueue OCC 后端化

前端从"理解 hash + 拼 raw + retry"的复杂逻辑，简化为"传 patches 数组"。

```javascript
// 前端代码量大幅减少
await configStore.patchConfig([
  { path: 'agents.list', value: currentList }
])
```

并发冲突由后端 `ConfigQueue` 统一处理，前端不需要 retry。

#### 收益 3：分页解决大数据卡顿

Gateway HTTP 原生支持 `limit + cursor` 分页：
- 首次加载只取最近 50 条
- 滚动加载再取下一页
- 切换会话时不再卡顿

#### 收益 4：代理兼容性

15s keepalive 心跳让 Nginx/Cloudflare 认为连接是活跃的，不会因为模型思考时间长（30s~2min）而断开。

180s 的 idle timeout 作为安全网，防止真死锁流一直占用资源。

#### 收益 5：代码可维护性

| 指标 | 之前 | 之后 |
|------|------|------|
| 控制面入口 | 1 个 `/api/rpc` | 3 个语义化端点 |
| 后端路由处理 | 巨型 switch/case (~200 行) | 独立 route handler |
| 前端调用方式 | `wsStore.rpc.xxx()` | `fetch()` / store 方法 |
| 类型安全 | RPC params 无类型 | REST 路径 + query 明确 |

---

## 四、迁移清单

### 后端新增端点

| 端点 | 方法 | 替换的 RPC |
|------|------|-----------|
| `/api/sessions` | GET | `sessions.list` |
| `/api/config` | PATCH | `config.patch` / `config.set` |
| `/api/chat/history` | GET | `chat.history` |

### 前端迁移

| Store | 方法 | 变更 |
|-------|------|------|
| `session.ts` | `fetchSessions()` | `wsStore.rpc.listSessions()` → `fetch GET /api/sessions` |
| `workspace.ts` | `fetchAllSessionsCached()` | `wsStore.rpc.listSessions()` → `fetch GET /api/sessions` |
| `workspace.ts` | `selectSession()` | `wsStore.rpc.listChatHistory()` → `fetch GET /api/chat/history` |
| `chat.ts` | `fetchHistory()` | `wsStore.rpc.listChatHistory()` → `fetch GET /api/chat/history` |
| `config.ts` | `patchConfig()` | `wsStore.rpc.patchConfig()` → `fetch PATCH /api/config` |
| `agent.ts` | theme/tools 更新 | `wsStore.rpc.patchConfig()` → `configStore.patchConfig()` |
| `channel-management.ts` | `saveChannels()` | `wsStore.rpc.patchConfig()` → `configStore.patchConfig()` |
| `Dashboard.vue` | `refreshDashboard()` | `wsStore.rpc.listSessions()` → `fetch GET /api/sessions` |

### 后端安全防护

旧 RPC 端点不再处理以下方法，返回 `410 Gone`：
- `sessions.list` → `Use GET /api/sessions`
- `config.patch` / `config.set` → `Use PATCH /api/config`
- `chat.history` → `Use GET /api/chat/history`

防止遗留代码或外部客户端意外走旧路径。

---

## 五、未迁移的 RPC（继续保持 WS）

以下方法仍通过 `/api/rpc` → Gateway WS 调用，因为它们是实时操作或Gateway原生能力：

| 方法 | 理由 |
|------|------|
| `chat.send` / `chat.abort` | 已迁移到 HTTP SSE，不再走 WS |
| `sessions.get` / `sessions.history` | 带完整 transcript 的会话详情，暂未分页 |
| `sessions.reset` / `sessions.delete` | 管理操作，低频 |
| `sessions.usage` | 聚合统计，依赖 Gateway 缓存 |
| `cron.list` / `cron.update` / `cron.run` | 定时任务管理，低频 |
| `models.list` | 模型列表，有独立 polling 缓存 |
| `skills.status` | 技能状态，有独立 polling 缓存 |
| `agent.create` / `agent.update` / `agent.delete` | Agent CRUD，低频 |
| `channel.auth` / `channel.pair` | 频道认证，低频 |

---

## 六、经验与踩坑记录

### 6.1 Gateway HTTP 分页字段

Gateway 返回 `nextCursor`，不是 `cursor`。一开始读错字段导致分页失效。

### 6.2 模块级 helper 提取

`isSessionOwned` 和 `filterOwnedSessions` 原来定义在 `/api/rpc` handler 的闭包里，提取到模块级别时需要注意：
- 闭包版本捕获了 `userId`，模块版本需要显式传参
- 两处定义并存时，闭包内会 shadow 模块级定义

### 6.3 HTTP 热路径中 await WS RPC

在实现 `/api/workspace/send` 时，曾错误地在 HTTP handler 中 `await wsStore.rpc.listModels()`，导致 HTTP 聊天路径被 WS RPC 阻塞。结论是：**HTTP 热路径中严禁 await WS RPC**。

### 6.4 前端类型推断

`fetchSessions()` 中 `await resp.json()` 返回 `any`，导致 `list.some((item) => ...)` 的 `item` 被推断为 `any`。需要显式标注 `const list: Session[] = result.sessions`。

---

> 文档维护者：若后续继续迁移更多 RPC 方法到 REST，请更新此文档的"迁移清单"和"未迁移的 RPC"章节。
