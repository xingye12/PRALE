# WattClaw HTTP+WS 协议分离重构蓝图

> 版本：v1.0 (Final)  
> 日期：2026-05-23  
> 状态：待实施  
> 关联诊断报告：`docs/OPENCLAW-WATTCLAW-ANALYSIS-v2.html`

---

## 1. 背景与目标

### 1.1 核心瓶颈

WattClaw 后端 (`server/index.js`) 通过**单条 WebSocket** 连接向 OpenClaw Gateway 发起所有 RPC 调用。Gateway 运行在 Node.js 单线程事件循环中，`agentCommandFromIngress()` 的**同步 prompt 构建**会阻塞后续请求，导致多用户对话时出现严重的**队头阻塞**（Head-of-Line Blocking）。

### 1.2 最终目标

实施**方案C：HTTP 对话 + WS 管理混合架构**。

- **剥离**：高频对话/推理流量（`chat.send`）改为走 Gateway HTTP `/v1/chat/completions`
- **保留**：状态管理、低频轮询、配置操作继续走 WS RPC
- **优化**：将无意义的后端轮询改为按需刷新，消除稳态 RPC 浪费

---

## 2. 架构现状确认（关键发现）

### 2.1 前端通信架构（重要纠正）

前端到 WattClaw 后端**没有原生 WebSocket**，全部为 HTTP：

```
Frontend (Browser)
  ├── RPC 调用  →  fetch POST /api/rpc  →  server/index.js  →  gateway.call()  →  Gateway WS
  ├── 事件接收  →  EventSource /api/events  ←  broadcastSSE  ←  Gateway WS event 帧
  └── REST 调用 →  fetch POST /api/workspace/send  →  server/index.js  →  gateway.call()
```

### 2.2 后端 WS 连接架构

```
WattClaw Express (server/index.js)
  └── OpenClawGateway (gateway.js) ──单条 WS──▶ Gateway:18789
        └── 所有 RPC (48 处) 共享同一条 WS
```

### 2.3 前端对话入口（4 个）

| 入口 | 文件 | 调用方式 | 用途 | 迁移策略 |
|---|---|---|---|---|
| 主工作区 | `src/stores/workspace.ts:1638` | `httpPost('/api/workspace/send')` | ChatPage 主对话 | **P0 迁移为 SSE fetch** |
| 会话创建 | `src/stores/session.ts:231` | `wsStore.rpc.sendChatMessage({message:'/new'})` | 新建会话初始化 | **P0 迁移为 `/api/workspace/send`** |
| Office/Agent Chat | `src/stores/chat.ts:960` | `wsStore.rpc.sendChatMessage()` | Office 场景、Agent 面板 | **P1 保留 WS 路径** |
| 场景向导 | `src/components/office/ScenarioWizard.vue:231` | `wsStore.rpc.sendChatMessage()` | Wizard 流程中对话 | **P0 迁移为 `/api/workspace/send`** |

**关键决策：`chat.ts` 暂不迁移。**

`chat.ts` 维护了一套复杂的状态机（`agentStatus`、`agentSteps`、`toolProgress`），依赖 Gateway 的 `agent` 生命周期事件（`lifecycle`/`tool`/`compaction`）。HTTP `/v1/chat/completions` 仅返回 `assistant` token 流，不覆盖这些事件。强行迁移会破坏状态机。

---

## 3. 靶点清单

### 3.1 Backend

| 优先级 | 文件 | 位置 | 当前行为 | 目标行为 |
|---|---|---|---|---|
| P0-1 | `server/utils.js` | `createPollingCache` | 无条件 `setInterval` 定时轮询 | **惰性刷新：只在 `getData()` 被调用时检查** |
| P0-2 | `server/index.js` | `/api/workspace/send` (~3659) | `gateway.call('chat.send')` → JSON `{streamId}` | **HTTP POST Gateway `/v1/chat/completions` → SSE pipe 回前端** |
| P0-3 | `server/index.js` | `/api/chat/cancel` (~3959) | `gateway.call('chat.abort')` | **保持 WS RPC**（取消频率极低，不构成瓶颈；Gateway HTTP kill 端点未确认存在） |
| P0-4 | `server/index.js` | `/api/rpc` `chat.send` 代理 (~3224) | `gateway.call('chat.send')` | **保留 WS 兼容层**，标记 deprecated，仅供 `chat.ts` 使用 |

### 3.2 Frontend

| 优先级 | 文件 | 位置 | 当前行为 | 目标行为 |
|---|---|---|---|---|
| P0-5 | `src/stores/workspace.ts` | `sendMessage` (~1638) | `httpPost('/api/workspace/send')` → 获取 `streamId` | **`fetch('/api/workspace/send')` + SSE ReadableStream 解析** |
| P0-6 | `src/stores/session.ts` | `spawnSession` (~231) | `wsStore.rpc.sendChatMessage({message:'/new'})` | **调用 `/api/workspace/send`** |
| P0-7 | `src/components/office/ScenarioWizard.vue` | ~231 | `wsStore.rpc.sendChatMessage()` | **调用 `/api/workspace/send`** |
| P1-8 | `src/stores/chat.ts` | `sendChatMessage` (~960) | `wsStore.rpc.sendChatMessage()` | **保留 WS 路径** |

---

## 4. 对接策略

### 4.1 后端核心函数：`proxyChatToGatewayHttp`

新增内部辅助函数，封装 HTTP POST Gateway 和 SSE pipe：

```javascript
async function proxyChatToGatewayHttp(params, res, req) {
  const { sessionKey, message, model, title, agentId } = params

  // 安全构造 Gateway HTTP URL（使用 URL 解析，避免字符串替换错误）
  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL)
  const gatewayHttpUrl = new URL(
    '/v1/chat/completions',
    `${wsUrl.protocol === 'wss:' ? 'https' : 'http'}://${wsUrl.host}`
  ).toString()

  const abortController = new AbortController()
  const onClose = () => abortController.abort()
  req.once('close', onClose)

  try {
    const gatewayRes = await fetch(gatewayHttpUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model || 'openclaw',
        messages: [{ role: 'user', content: message }],
        stream: true,
        user: sessionKey,
      }),
      signal: abortController.signal,
    })

    if (!gatewayRes.ok) {
      const errorText = await gatewayRes.text().catch(() => 'Gateway HTTP error')
      req.removeListener('close', onClose)
      return res.status(gatewayRes.status).json({ ok: false, error: errorText })
    }

    // SSE headers → frontend
    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.setHeader('X-Accel-Buffering', 'no')
    res.flushHeaders()

    // Pipe Web ReadableStream → Node ServerResponse
    const { Readable } = await import('stream')
    const upstream = Readable.fromWeb(gatewayRes.body)
    upstream.pipe(res)

    upstream.on('error', (err) => {
      if (abortController.signal.aborted) return
      console.error('[ChatHTTP] upstream error:', err.message)
      if (!res.writableEnded) res.end()
    })

    res.on('finish', () => {
      req.removeListener('close', onClose)
      upstream.destroy()
    })

    // sessions.patch label（fire-and-forget，低频管理操作，仍走 WS）
    if (title && sessionKey) {
      const safeTitle = generateSafeTitle(title)
      const gatewayLabel = `${safeTitle}-${Date.now()}`
      gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
    }

    // 本地 session 跟踪
    trackSessionForUser(req.currentUser.id, sessionKey, agentId, title, null)

  } catch (err) {
    req.removeListener('close', onClose)
    if (abortController.signal.aborted) return
    console.error('[ChatHTTP] fetch error:', err.message)
    if (!res.headersSent) {
      res.status(502).json({ ok: false, error: err.message })
    } else if (!res.writableEnded) {
      res.end()
    }
  }
}
```

### 4.2 `/api/workspace/send` 改造

```javascript
app.post('/api/workspace/send', authMiddleware, async (req, res) => {
  const { sessionKey, message, idempotencyKey, title, model } = req.body
  if (!sessionKey || !message) {
    return res.status(400).json({ ok: false, error: 'sessionKey and message required' })
  }

  const parts = sessionKey.split(':')
  const agentId = parts.length >= 2 ? parts[1] : null

  // 直接走 HTTP SSE，不再返回 JSON streamId
  await proxyChatToGatewayHttp({
    sessionKey, message, model, title, agentId,
  }, res, req)
})
```

**关键变化**：响应从 `Content-Type: application/json` 变为 `text/event-stream`。

### 4.3 `/api/chat/cancel` 保持现状

```javascript
// 保持当前实现，继续走 WS RPC
// 取消频率极低，不构成并发瓶颈
// Gateway HTTP kill 端点未在当前版本源码中确认存在
```

### 4.4 前端 `workspace.ts` `sendMessage` 改造

```typescript
async function sendMessage(text: string, options?: { files?: File[]; title?: string }) {
  // ... 前置逻辑不变 ...

  const sessionKey = activeSessionKey.value
  if (!sessionKey) return

  const idempotencyKey = `web-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
  const titleToSend = options?.title || presetPrompt.value || null
  const model = getActiveSessionModel()

  await ensureModelPatched()
  finalizeOpenActivities()
  lastError.value = null
  isRateLimited.value = false
  setSessionStreaming(sessionKey, true)

  const abortController = new AbortController()
  activeAbortController.value = abortController

  try {
    const response = await fetch('/api/workspace/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionKey,
        message: text,
        model,
        idempotencyKey,
        ...(titleToSend ? { title: titleToSend } : {}),
      }),
      signal: abortController.signal,
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({ error: 'Send failed' }))
      throw new Error(err.error || 'Send failed')
    }

    // 解析 SSE 流
    const reader = response.body!.getReader()
    const decoder = new TextDecoder()
    let buffer = ''

    resetStreamTimeout()
    if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
    maxStreamTimeout = setTimeout(() => forceStopStreaming(sessionKey), 300_000)

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() || ''

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue
        const data = line.slice(6)
        if (data === '[DONE]') continue

        try {
          const chunk = JSON.parse(data)
          const content = chunk.choices?.[0]?.delta?.content
          const finishReason = chunk.choices?.[0]?.finish_reason

          if (content) {
            appendStreamingContent(sessionKey, content)
          }
          if (finishReason) {
            finalizeStreaming(sessionKey, finishReason)
          }
        } catch {
          // ignore malformed chunk
        }
      }
    }

    finalizeStreaming(sessionKey, 'stop')
  } catch (err: unknown) {
    if (abortController.signal.aborted) {
      forceStopStreaming(sessionKey)
      return
    }
    // ... 错误处理 ...
  } finally {
    activeAbortController.value = null
  }
}
```

### 4.5 前端取消逻辑

`cancelCurrentRequest` 保持调用 `/api/chat/cancel`，同时 abort fetch：

```typescript
async function cancelCurrentRequest() {
  const key = activeSessionKey.value
  if (!key || (!activeStreamId.value && !sending.value)) return

  // Abort 前端 fetch
  if (activeAbortController.value) {
    activeAbortController.value.abort()
  }

  // 通知后端取消 Gateway 推理
  try {
    await httpPost('/api/chat/cancel', {
      streamId: activeStreamId.value,
      sessionKey: key,
    })
  } catch {
    // best-effort
  }

  forceStopStreaming(key)
}
```

---

## 5. 数据流处理

### 5.1 完整数据流图

```
【用户A 发送消息】
  Frontend (Browser)
    fetch('/api/workspace/send', {body: {sessionKey, message, model}})
      ──POST──▶ WattClaw Express (/api/workspace/send)
                  │
                  ├── 鉴权 (authMiddleware)
                  │
                  ├── 构造 HTTP POST
                  │     http://gateway:18789/v1/chat/completions
                  │     Authorization: Bearer <OPENCLAW_AUTH_TOKEN>
                  │     Body: {model, messages, stream:true, user:sessionKey}
                  │
                  ├── fetch(gatewayHttpUrl) ──▶ OpenClaw Gateway
                  │                               │
                  │                               ├── 不经过 WS 协议层
                  │                               ├── agentCommandFromIngress()
                  │                               ├── runEmbeddedPi()
                  │                               └── SSE 流返回 (OpenAI 格式)
                  │
                  ├── Gateway SSE ──pipe──▶ Frontend SSE
                  │     (每个用户独立 TCP 连接, 天然并发)
                  │
                  └── 用户A 的 token 直接流回浏览器

【用户B 同时发送消息】
  完全独立路径，不经过单条 WS，Gateway 事件循环并行处理
```

### 5.2 Node.js 流式处理关键技术点

| 技术点 | 实现 | 目的 |
|---|---|---|
| **AbortController** | `req.once('close', () => abortController.abort())` | 客户端断开时立即中断 Gateway 推理 |
| **Web → Node Stream** | `Readable.fromWeb(gatewayRes.body).pipe(res)` | 将 Web ReadableStream 转为 Node Stream 并 pipe |
| **背压处理** | `upstream.pipe(res)` 自动处理 | 防止内存积压 |
| **资源清理** | `res.on('finish', () => upstream.destroy())` | 防止内存泄漏 |
| **错误边界** | `upstream.on('error')` + `res.headersSent` 检查 | headers 已发送后只能 `res.end()`，不能返回 JSON |
| **URL 安全构造** | `new URL('/v1/chat/completions', 'http://host:port')` | 避免字符串替换导致的 path 错误 |

---

## 6. 轮询系统优化

### 6.1 核心改造：`createPollingCache` 改为惰性刷新

```javascript
export function createPollingCache(interval, fetcher) {
  let data = null
  let lastRefresh = 0
  let refreshing = false

  async function refresh() {
    if (refreshing) return
    refreshing = true
    try {
      const newData = await fetcher()
      if (newData) {
        data = newData
        lastRefresh = Date.now()
      }
    } catch (err) {
      console.error('[PollingCache] refresh failed:', err.message)
    } finally {
      refreshing = false
    }
  }

  return {
    getData() {
      // 惰性刷新：只在被调用时检查
      if (!data) {
        refresh() // 首次触发（fire-and-forget）
      } else if (Date.now() - lastRefresh > interval) {
        refresh() // 过期触发（fire-and-forget，返回 stale 数据）
      }
      return data
    },
    async getFreshData() {
      if (!data || Date.now() - lastRefresh > interval) {
        await refresh()
      }
      return data
    },
    refresh,
    removeItem(predicate) {
      if (Array.isArray(data)) {
        data = data.filter(item => !predicate(item))
      }
    },
  }
}
```

### 6.2 关键变化

1. **去掉 `setTimeout(refresh, initialDelay)`** — 启动时不自动查询
2. **去掉 `setInterval(refresh, interval)`** — 不再定时查询
3. **`getData()` 增加惰性刷新** — 只在被调用时检查是否需要刷新
4. **新增 `getFreshData()`** — 需要保证新鲜数据时使用

### 6.3 为什么零风险

- 所有现有 `polling.getData()` 调用**不需要改代码**
- 所有现有 `polling.refresh()` 调用**不需要改代码**
- 调用方已有 `|| null` / `|| await gateway.call(...)` 的 fallback 处理

### 6.4 改造后效果

| 轮询器 | 改造前/分钟 | 改造后 | 节省 |
|---|---|---|---|
| `allSessionsPolling` (9s, 扇出 N+1) | ~73 次 RPC | **0**（无请求时不查） | 100% |
| `modelsListPolling` (13s) | ~5 次 | **0** | 100% |
| `cronListPolling` (11s) | ~5 次 | **0** | 100% |
| `skillsStatusPolling` (17s) | ~4 次 | **0** | 100% |
| `configGetPolling` (19s) | ~3 次 | **按需** | ~100% |
| `usagePolling` (60s) | ~1 次 | **按需** | ~100% |
| **合计** | **~91 次/分钟** | **~0 次/分钟（空闲时）** | **~100%** |

> 注：91 次是按 10 个 extra agent 估算的 `allSessionsPolling` 扇出成本（`fetchAllAgentSessions` 每 9s 发起 N 次 `sessions.list`）。

---

## 7. 防御圈划定（绝对不碰）

### 7.1 核心保留模块

| 模块 | 位置 | 保留理由 |
|---|---|---|
| **Batch Stats** | `server/index.js:1283` | 零 RPC 计算 agent 统计，已优化 |
| **ConfigQueue** | `server/index.js:588-690` | OCC 重试 + 限速，已优化 |
| **Token 缓存** | `server/user-manager.js:93-137` | 30s TTL JWT 缓存，已优化 |
| **Session 所有权隔离** | `isSessionOwned`, `filterOwnedSessions` | 多用户安全核心 |
| **Gateway WS 连接** | `gateway.js` | 继续服务保留的 RPC |
| **`/api/events` 非对话事件** | `server/index.js:3989` | `chat.ts` 等依赖 `agent` 生命周期事件 |
| **`/api/rpc` 非 chat 方法** | `server/index.js:3189+` | 所有管理操作代理 |

### 7.2 前端保留模块

| 模块 | 保留理由 |
|---|---|
| `chat.ts` `sendChatMessage` | 复杂状态机依赖 `agent` 生命周期事件 |
| `useEventStream` | Monitor 页面事件流，与对话无关 |
| `agent.ts` `startAutoRefresh` | P0 不碰，P1 处理 |

---

## 8. 实施路线图

| 阶段 | 内容 | 预估工作量 | 验证方式 |
|---|---|---|---|
| **Phase 0** | `createPollingCache` 改为惰性刷新 | 1h | 重启后观察日志，确认无自动轮询触发 |
| **Phase 1** | 后端 `/api/workspace/send` → SSE + HTTP Gateway | 4-6h | curl 测试 SSE 流正常返回 token |
| **Phase 2** | 前端 `workspace.ts` → SSE fetch + 解析 | 4-6h | ChatPage 主对话正常收发 |
| **Phase 3** | 前端 `session.ts` / `ScenarioWizard.vue` → 统一 HTTP 入口 | 2h | 新建会话 / Wizard 正常 |
| **Phase 4** | 端到端并发测试 + 回归测试 | 3-4h | 多用户同时对话无卡顿 |

**总计：约 1.5 天**

---

## 9. 风险与缓解

| 风险 | 影响 | 缓解措施 |
|---|---|---|
| `chat.ts` 未迁移，部分流量仍走 WS | 中 | 接受。`chat.ts` 的 Office/Agent Chat 是低频场景。P0 优先解决主工作区并发瓶颈。 |
| `model` 参数缺失导致 Gateway 400 | 高 | 前端发送时必传 `model`（`getActiveSessionModel()`）；后端兜底默认 `'openclaw'`。 |
| Gateway HTTP 端口/路径不可达 | 高 | 使用 `new URL()` 安全构造 URL，避免字符串替换错误。 |
| 前端 SSE 解析错误 | 中 | 防御性解析：malformed chunk 直接忽略，不影响后续 token。 |
| 轮询惰性刷新后首次请求变慢 | 低 | `getData()` 返回 stale/null 的同时触发 `refresh()`，调用方已有 fallback 到直接 RPC。 |
| 多用户并发下 `fetch` 连接数激增 | 中 | 每个用户独立 HTTP 连接，由操作系统 TCP 栈管理；WattClaw Express 和 Gateway 均为事件驱动，可承受高并发连接。 |

---

## 10. 附录

### 10.1 Gateway `/v1/chat/completions` 端点规范

| 项 | 规范 |
|---|---|
| Method | `POST` |
| Path | `/v1/chat/completions` |
| 鉴权 Header | `Authorization: Bearer <OPENCLAW_AUTH_TOKEN>` |
| Content-Type | `application/json` |
| Body | `model`, `messages` (array of `{role, content}`), `stream` (boolean), `user` (string=sessionKey), `max_tokens`/`max_completion_tokens`, `temperature`, `top_p`, `tools`, `tool_choice`, `response_format` |
| 响应 (stream=true) | `Content-Type: text/event-stream`，OpenAI 兼容 `chat.completion.chunk` |
| 底层路径 | 直接调用 `agentCommandFromIngress()` → `runEmbeddedPi()`，**不经过 WebSocket 协议层** |

### 10.2 SSE 数据格式示例

```
data: {"id":"chatcmpl_xxx","object":"chat.completion.chunk","created":1234567890,"model":"gpt-4","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}]}

data: {"id":"chatcmpl_xxx","object":"chat.completion.chunk","created":1234567890,"model":"gpt-4","choices":[{"index":0,"delta":{"content":"Hello"},"finish_reason":null}]}

data: {"id":"chatcmpl_xxx","object":"chat.completion.chunk","created":1234567890,"model":"gpt-4","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}

data: [DONE]
```

### 10.3 变更摘要

| 文件 | 变更类型 | 说明 |
|---|---|---|
| `server/utils.js` | 修改 | `createPollingCache` 去掉 `setInterval`，改为惰性刷新 |
| `server/index.js` | 修改 | `/api/workspace/send` 改为 SSE + HTTP Gateway；新增 `proxyChatToGatewayHttp` 辅助函数 |
| `src/stores/workspace.ts` | 修改 | `sendMessage` 改为 `fetch` + SSE 解析；`cancelCurrentRequest` 增加 `AbortController.abort()` |
| `src/stores/session.ts` | 修改 | `spawnSession` 改为调用 `/api/workspace/send` |
| `src/components/office/ScenarioWizard.vue` | 修改 | 改为调用 `/api/workspace/send` |

### 10.4 历史记录接口 `/api/chat/history` 性能根因分析

> 记录日期：2026-05-25  
> 状态：`/api/chat/history` 已迁移为独立 HTTP REST 端点，WS RPC fallback 已移除

#### 现象

迁移完成后，单用户快速切换会话时，`/api/chat/history` 仍然出现明显卡顿（数秒甚至 10s+）。监控显示 node 进程 CPU 占用在快速切换期间飙升至 100%。

#### 已排除的假设

| 假设 | 验证结果 | 结论 |
|---|---|---|
| 仍走 WS RPC fallback | 日志确认无 fallback；代码已彻底移除 fallback | ❌ 不是 |
| HTTP 协议本身有队头阻塞 | HTTP 是独立 TCP 连接，天然并行 | ❌ 不是 |
| 网络连通问题 | 宿主机直接 curl Gateway HTTP 响应正常 | ❌ 不是 |
| 磁盘 IO 瓶颈 | `readRecentTranscriptTailLinesAsync` 只读文件尾部 | ❌ 不是主因 |

#### 根因：Gateway HTTP handler 是 CPU 密集型的

OpenClaw Gateway 的 `/sessions/{key}/history` HTTP handler（`handleSessionHistoryHttpRequest`）内部逻辑：

```
handleSessionHistoryHttpRequest
  ├── resolveGatewaySessionStoreTarget
  ├── loadSessionStore
  ├── resolveFreshestSessionEntryFromStoreKeys
  ├── readRecentSessionMessagesWithStatsAsync
  │     ├── readSessionMessageCountAsync
  │     │     └── readSessionTranscriptIndex(filePath)  ← 解析索引文件，CPU 密集型
  │     └── readRecentSessionMessagesAsync
  │           └── readRecentTranscriptTailLinesAsync      ← 磁盘 IO，通常很快
  └── buildSessionHistorySnapshot
        ├── projectChatDisplayMessages(rawMessages, {maxChars})  ← CPU 密集型
        └── paginateSessionMessages(...)                        ← 遍历 + 计算
```

**CPU 瓶颈点**：

1. **`projectChatDisplayMessages`** —— 对每条消息的 content 做文本裁剪、过滤、token 估算。session 消息越多（几百条），CPU 耗时越长。
2. **`readSessionTranscriptIndex`** —— 读取并解析整个 transcript 索引文件。首次无缓存时，大文件的 JSON/文本解析会阻塞事件循环。

**为什么一个人用也卡**：Node.js 是单线程事件循环。一个请求处理几百条消息的文本裁剪时，后续并发的 HTTP 请求只能在事件循环中排队。快速切换触发 3-5 个并发请求，CPU 直接 100%，所有请求都变慢。

#### 优化方向

| 层级 | 方案 | 难度 | 效果 |
|---|---|---|---|
| **前端** | `selectSession` 加 150ms debounce，快速连续切换只处理最后一次 | 低 | ⭐⭐⭐ 立竿见影 |
| **前端** | 已加载的 session 历史缓存到内存，再次切换时直接读缓存 | 低 | ⭐⭐⭐ 避免重复请求 |
| **WattClaw 后端** | 同一 `sessionKey` 的并发请求合并，只发一次 Gateway 请求 | 中 | ⭐⭐ 减少 Gateway 负载 |
| **WattClaw 后端** | 对 `/api/chat/history` 结果加短期缓存（如 5s） | 低 | ⭐⭐ 减少重复计算 |
| **Gateway** | `projectChatDisplayMessages` 改为流式/惰性计算 | 高 | ⭐⭐⭐ 根本解决，但不在我们控制范围 |

> **当前结论**：HTTP 传输层的队头阻塞已经解决。卡顿的瓶颈转移到了 **Gateway HTTP handler 内部的 CPU 密集型消息处理**。短期最优解是**前端防抖 + 缓存**，减少无意义的并发重复请求。

---

*本蓝图基于 `docs/OPENCLAW-WATTCLAW-ANALYSIS-v2.html` 的诊断结论，经过对 OpenClaw Gateway 源码和 WattClaw 全量代码的深度逆向分析后制定。*
