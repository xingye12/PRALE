# OpenClaw 扩展性分析与多租户方案

> 日期：2026-05-09
> 状态：调研中，待讨论

---

## 一、当前状况

### 1.1 服务器资源

| 项目 | 值 |
|------|-----|
| CPU | 11th Gen Intel Core i9-11900K @ 3.50GHz，16 核 |
| 内存 | 32GB（当前使用 4.2GB） |
| 磁盘 | 92GB NVMe（当前使用 1.9GB） |
| Gateway 进程 | 占用 1.1GB RAM，69% CPU |

### 1.2 OpenClaw 配置现状

| 项目 | 值 |
|------|-----|
| OpenClaw 版本 | 2026.4.21（最新可用 2026.5.7） |
| Gateway 模式 | `local`（单实例） |
| 端口 | 18789 |
| Agent 总数 | **216 个** |
| 配置文件大小 | **340KB**（9,860 行） |
| Agent 配置占比 | 221KB（占配置文件的 91%） |
| Agent workspace 目录 | 314 个 |
| 模型 Provider | 8 个（minimax、xiaomi、ollama、deepseek、gpt、claude、gemini、zai） |

### 1.3 Agent 分布

| 类别 | 数量 |
|------|------|
| 有命名的 Agent（如"任鸣的代码助手"） | 95 |
| 自动命名的 Agent（如 "agent-1778221067189"） | 121 |
| 使用 minimax/MiniMax-M2.7 模型 | 138 |
| 未配置模型（使用默认） | 77 |
| 配置了 tools 的 Agent | 164 |
| 未配置 tools 的 Agent | 52 |

### 1.4 已发现的问题

**问题 1：配置文件过大**

216 个 Agent 的配置全部存储在一个 `openclaw.json` 文件中。每次通过 `config.patch` / `config.apply` 修改配置，都需要读写整个 340KB 文件。多用户并发操作时容易产生写入冲突。

历史记录显示配置文件已被 **clobber（覆盖损坏）7 次**：

```
openclaw.json.clobbered.2026-04-23T10-08-37-356Z    (389B - 几乎清空)
openclaw.json.clobbered.2026-04-23T10-25-17-454Z    (676B - 几乎清空)
openclaw.json.clobbered.2026-05-08T06-05-47-983Z    (88KB - 丢失部分配置)
openclaw.json.clobbered.2026-05-08T09-22-51-609Z    (324KB)
openclaw.json.clobbered.2026-05-08T09-22-51-648Z    (324KB)
openclaw.json.clobbered.2026-05-08T09-47-26-689Z    (325KB)
openclaw.json.clobbered.2026-05-08T09-47-26-732Z    (325KB)
```

**问题 2：复杂任务导致 Gateway 无响应**

单个 Node.js Gateway 进程处理所有 Agent 的所有会话。当某个用户执行复杂任务（如调用模型生成长文本）时，事件循环被阻塞，导致其他所有用户的请求都无法响应。

**问题 3：无资源隔离**

一个用户的 Agent 跑复杂任务，其他所有用户的 Agent 都受影响。没有进程级或容器级的隔离机制。

### 1.5 Gateway 容量实测分析

**实测数据**（2026-05-09 采集）：

| 指标 | 值 |
|------|-----|
| Agent 总数 | 216 个（配置中）/ 315 个（目录） |
| 活跃 WebSocket 连接 | 35 个 |
| **正在执行的 LLM 调用** | **仅 4 个** |
| Gateway CPU | **109%**（已打满 1 核） |
| Gateway RAM | **2.6GB** |
| Gateway 线程数 | 27 |
| HTTP 响应延迟 | 63ms（正常） |
| 配置文件大小 | 323KB |

**关键发现**：216 个 Agent 注册在同一个 Gateway，同时只有 4 个在执行 LLM 调用，CPU 就已经 109%。说明 Gateway 的开销大头不是来自 LLM 调用本身，而是来自**管理大量 Agent 的常驻开销**（配置解析、事件循环维护、WebSocket 心跳等）。

**OpenClaw 并发模型**（来自官方文档）：

```json5
{
  agents: {
    defaults: {
      maxConcurrent: 4,        // 全 Gateway 同时最多 4 个 Agent 运行
      subagents: { maxConcurrent: 8 },  // 子 Agent 最多 8 个并发
    },
  },
}
```

`maxConcurrent: 4` 意味着不管注册了多少 Agent，同一时刻最多只有 4 个 Agent 在执行。每个 session 内部是串行的。所以问题不是"100 个 Agent 同时跑"，而是"100 个 Agent 注册在那，同时有 N 个用户在活跃对话"。

**单 Gateway 承载 100 个 Agent 的资源预估**：

| 场景 | 活跃对话数 | 预估 RAM | 预估 CPU | 是否可承受 |
|------|-----------|---------|---------|-----------|
| 日常（少量用户在线） | 5 | ~2GB | ~50% | 完全没问题 |
| 中等负载 | 15 | ~3GB | ~80% | 可以，开始吃紧 |
| 高峰 | 30 | ~4GB | ~120% | 接近瓶颈 |
| 极端 | 50+ | ~5GB+ | 打满 | 会卡 |

**瓶颈来源**：
1. **Event Loop 阻塞**：Node.js 单线程，工具调用（文件读写、Shell 执行）会阻塞事件循环，其他用户的请求排队等待
2. **配置文件**：100 个 Agent 的 config 约 150-200KB，每次 `config.patch` 读写整个文件
3. **内存**：每个 Agent 的 workspace、session 上下文都占内存

**结论**：100 个 Agent 注册在同一个 Gateway，日常使用没问题。关键是**同时有多少用户在活跃对话**——高峰时 20-30% 用户同时在线（20-30 个并发对话）时，单个 Gateway 能撑住但余量不大。

---

## 二、OpenClaw 架构特性

### 2.1 OpenClaw 的定位

OpenClaw 官方定位是 **Personal AI Assistant（个人 AI 助手）**——设计为一个用户一台设备的场景。

官方 README 开头：
> "OpenClaw is a personal AI assistant you run on your own devices."

但我们当前的使用场景是：**100+ 用户的企业级多租户平台**。

### 2.2 Multi-Agent Routing

OpenClaw 支持在一个 Gateway 内运行多个 Agent，通过 bindings 将消息路由到不同 Agent：

```json5
{
  agents: {
    list: [
      { id: "home", default: true, workspace: "~/.openclaw/workspace-home" },
      { id: "work", workspace: "~/.openclaw/workspace-work" },
    ],
  },
  bindings: [
    { agentId: "home", match: { channel: "whatsapp", accountId: "personal" } },
    { agentId: "work", match: { channel: "whatsapp", accountId: "biz" } },
  ],
}
```

但这仍然是**单进程内的多 Agent**，没有解决资源隔离问题。

### 2.3 Multiple Gateways（多 Gateway 实例）

OpenClaw 官方支持在同一台机器上运行多个独立的 Gateway 实例。

**官方文档**：https://docs.openclaw.ai/gateway/multiple-gateways

启动方式：

```bash
# 实例 A
OPENCLAW_CONFIG_PATH=~/.openclaw/a.json \
OPENCLAW_STATE_DIR=~/.openclaw-a \
openclaw gateway --port 19001

# 实例 B
OPENCLAW_CONFIG_PATH=~/.openclaw/b.json \
OPENCLAW_STATE_DIR=~/.openclaw-b \
openclaw gateway --port 19002
```

也可以用 `--profile` 简化管理：

```bash
openclaw --profile group1 gateway --port 18789
openclaw --profile group2 gateway --port 18790
```

**隔离检查清单**（每个实例必须独立）：
- `OPENCLAW_CONFIG_PATH` — 配置文件路径
- `OPENCLAW_STATE_DIR` — 状态目录（sessions、credentials、caches）
- `agents.defaults.workspace` — Agent 工作空间
- `gateway.port` — 端口
- 衍生的 browser/canvas/CDP 端口

**注意**：端口之间至少间隔 20，因为 browser control port = base + 2，CDP 端口从 base + 11 到 base + 110。

### 2.4 Gateway 配置热重载

Agent、模型、渠道等配置变更支持热重载，无需重启 Gateway。只有 Gateway 服务器配置（端口、认证等）需要重启。

| 类别 | 是否需要重启 |
|------|-------------|
| 渠道配置 `channels.*` | 否 |
| Agent 和模型 `agents`, `models` | 否 |
| 自动化 `hooks`, `cron` | 否 |
| 工具和媒体 `tools`, `skills` | 否 |
| Gateway 服务器 `gateway.*`（端口、认证） | **是** |
| 插件 `plugins` | **是** |

---

## 三、方案对比

### 方案 A：多 Gateway 分片（推荐）

利用 OpenClaw 原生的 Multiple Gateways 能力，按用户组分片到不同 Gateway 实例。

**核心原则：按 Agent 总数分，不按用户数分。** 基于实测数据（见 1.5 节），单个 Gateway 承载 50 个 Agent 以内最安全，上限约 80 个。100 个用户如果每人创建 2-3 个 Agent（共 200-300 个），建议直接上 5 个 Gateway。

**经验值**（基于实测更新）：

| Agent 总数 | 建议 Gateway 数量 | 每 GW Agent 数 | 示例场景 |
|-----------|------------------|---------------|---------|
| 100-200 | 2 个 | 50-100 | 50 用户，每人 2-3 个 Agent |
| 200-300 | 5 个 | 40-60 | 100 用户，每人 2-3 个 Agent |
| 300-500 | 5-7 个 | 43-71 | 200 用户，每人 2-3 个 Agent |
| 500-1000 | 8-12 个 | 42-83 | 300-500 用户 |
| 1000+ | 15-20 个 | 50-67 | 500-1000 用户 |

> 实测数据：1 个 Gateway 跑 216 个 Agent，仅 4 个活跃 LLM 调用就占 109% CPU、2.6GB RAM。拆分到 5 个 Gateway 后，每个约 43 个 Agent，基线 CPU 降至 ~25%，高峰时 30 人同时在线每个 GW 仅处理 6 个并发，非常轻松。

```
示例：100 个用户，约 250 个 Agent，拆成 5 个 Gateway

WattClaw 前端
    ↓
WattClaw 后端（路由层）
    ↓         ↓         ↓         ↓         ↓
GW-1        GW-2        GW-3        GW-4        GW-5
(~20用户)   (~20用户)   (~20用户)   (~20用户)   (~20用户)
(~50agent)  (~50agent)  (~50agent)  (~50agent)  (~50agent)
端口 18789  端口 18809  端口 18829  端口 18849  端口 18869
```

**优点**：
- 利用 OpenClaw 原生能力，不需要改 OpenClaw 代码
- 每个 Gateway 独立进程，互相不干扰
- 配置文件分开，不再有并发写入冲突
- 某个 Gateway 挂了只影响 20% 用户（5 个 GW 时）
- WattClaw 后端只需维护多个 WebSocket 连接
- 当前服务器 32GB RAM 跑 5 个 Gateway 约用 7.5-10GB，余量充足
- 可渐进式实施：先分 5 个 Gateway，验证后再扩

**缺点**：
- 需要改 WattClaw 后端，支持多 Gateway 连接和路由
- 跨 Gateway 的 Agent 协作需要额外处理
- 运维复杂度增加（多实例管理、升级、监控）
- 本质上还是个人工具拼出来的多租户，不是原生设计
- 到 1000+ 用户时可能需要 10-20 个 Gateway 实例

**改动范围**：
- WattClaw 后端：`server/index.js` 的 RPC 路由层，从单 Gateway 连接改为多连接 + 路由
- WattClaw 后端：用户创建 Agent 时，分配到合适的 Gateway
- 运维：部署多个 OpenClaw 实例
- 前端：基本不需要改动

**分片策略选择**：

| 策略 | 优点 | 缺点 |
|------|------|------|
| 按用户 ID 哈希 | 均匀分布 | 同部门用户可能在不同 Gateway |
| 按部门/组织 | 同部门在一起 | 可能不均匀 |
| 按注册顺序轮询 | 最简单 | 不均匀 |

**分片粒度的关键决策**：是按"用户"分还是按"Agent"分？详见下方"方案 A 补充"第 8 节。

**扩展性评估**：到 1000+ 用户可以分 10-20 个 Gateway 实例，如果单台服务器不够可以多台服务器部署。

---

### 方案 A 补充：多 Gateway 分片详细设计

#### 1. 部署架构

在当前服务器上启动 5 个独立的 OpenClaw Gateway 进程：

```bash
# ===== 实例 1 - 用户组 A（端口 18789） =====
OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g1/openclaw.json \
OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g1 \
openclaw gateway --port 18789

# ===== 实例 2 - 用户组 B（端口 18809） =====
OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g2/openclaw.json \
OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g2 \
openclaw gateway --port 18809

# ===== 实例 3 - 用户组 C（端口 18829） =====
OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g3/openclaw.json \
OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g3 \
openclaw gateway --port 18829

# ===== 实例 4 - 用户组 D（端口 18849） =====
OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g4/openclaw.json \
OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g4 \
openclaw gateway --port 18849

# ===== 实例 5 - 用户组 E（端口 18869） =====
OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g5/openclaw.json \
OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g5 \
openclaw gateway --port 18869
```

**为什么端口间隔 20？**

OpenClaw 会从 Gateway 基础端口派生其他端口：
- Browser control port = base + 2
- CDP 端口范围 = base + 11 到 base + 110

所以端口间隔必须 ≥ 20，避免实例之间的端口冲突。

**每个实例的目录结构**：

```
/home/wattman/
├── .openclaw-g1/              # 实例 1 的完整状态
│   ├── openclaw.json          # 只包含用户组 A 的 agent 配置
│   ├── agents/                # 用户组 A 的 agent 目录
│   ├── workspace/             # 用户组 A 的 workspace
│   ├── credentials/           # 实例 1 的凭证
│   └── sessions/              # 实例 1 的会话数据
├── .openclaw-g2/              # 实例 2（同上结构）
├── .openclaw-g3/              # 实例 3（同上结构）
├── .openclaw-g4/              # 实例 4（同上结构）
├── .openclaw-g5/              # 实例 5（同上结构）
└── .openclaw/                 # 原始实例（迁移完成后可归档）
```

#### 2. 数据迁移

将现有的 216 个 Agent 按用户拆分到不同实例。

**步骤**：

1. 导出当前所有 Agent 配置
2. 根据用户归属，将 Agent 分配到不同 Gateway
3. 为每个 Gateway 生成独立的 `openclaw.json`
4. 复制对应的 workspace 目录到新实例
5. 启动新实例并验证

**分配规则示例**（按用户 ID 取模）：

```
用户 ID % 3 == 0 → Gateway-1
用户 ID % 3 == 1 → Gateway-2
用户 ID % 3 == 2 → Gateway-3
```

**每个 Gateway 的 openclaw.json 结构相同**，只是 `agents.list` 只包含分配给自己的 Agent：

```json5
// Gateway-1 的 openclaw.json（只包含 ~72 个 agent）
{
  gateway: { port: 18789, /* ... */ },
  models: { /* 8 个 provider 不变 */ },
  agents: {
    defaults: { /* 相同的默认配置 */ },
    list: [
      // 只有分配给 Gateway-1 的 agent
      { id: "agent-xxx", name: "任鸣的代码助手", ... },
      { id: "agent-yyy", name: "李文文的标书撰写", ... },
      // ...
    ]
  },
  // bindings、channels 等按需调整
}
```

#### 3. WattClaw 后端改动

**现在的架构**：

```
前端 → WattClaw 后端 → 单个 WebSocket 连接 → Gateway (端口 18789)
```

**改造后的架构**：

```
前端 → WattClaw 后端 → 根据用户查表 → 对应 Gateway 的 WebSocket 连接
                          ↓
                    ┌─────────────────────────┐
                    │  gateway-routing-map     │
                    │  ─────────────────────   │
                    │  用户1 → Gateway-1:18789 │
                    │  用户2 → Gateway-2:18809 │
                    │  用户3 → Gateway-3:18829 │
                    │  用户4 → Gateway-1:18789 │
                    │  ...                     │
                    └─────────────────────────┘
```

**后端核心改动点**：

1. **多 Gateway 连接管理**
   - `server/gateway.js` 从单个 WebSocket 连接改为维护多个连接池
   - 每个 Gateway 实例一个 WebSocket 连接
   - 连接状态监控、自动重连

2. **路由层**
   - 在 `server/index.js` 中增加路由逻辑
   - 每个用户绑定到一个固定的 Gateway（存储在 SQLite 的 user 表中）
   - RPC 调用时根据用户 ID 找到对应 Gateway 发送请求

3. **Agent 创建流程**
   - 用户创建 Agent 时，分配到所属的 Gateway
   - 通过对应 Gateway 的 `config.patch` 写入 Agent 配置

4. **SSE 事件转发**
   - 每个 Gateway 都有自己的 SSE 事件流
   - 后端合并所有 Gateway 的事件，根据用户过滤后转发给前端

5. **SQLite 新增字段**
   ```sql
   ALTER TABLE users ADD COLUMN gateway_id TEXT DEFAULT 'g1';
   ALTER TABLE user_agents ADD COLUMN gateway_id TEXT DEFAULT 'g1';
   ```

**前端改动**：基本不需要。前端只跟 WattClaw 后端交互，不直接连 Gateway。

#### 4. 用户感知

用户侧完全无感知：

- 前端界面不变
- 创建 Agent、对话、分享等功能不变
- 只是后端把请求路由到了不同的 Gateway

#### 5. 运维管理

**进程管理**（使用 systemd）：

```ini
# /etc/systemd/system/openclaw-g1.service
[Service]
User=wattman
Environment=OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g1/openclaw.json
Environment=OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g1
ExecStart=/home/wattman/.npm-global/bin/openclaw gateway --port 18789

# /etc/systemd/system/openclaw-g2.service
[Service]
User=wattman
Environment=OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g2/openclaw.json
Environment=OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g2
ExecStart=/home/wattman/.npm-global/bin/openclaw gateway --port 18809

# /etc/systemd/system/openclaw-g3.service
[Service]
User=wattman
Environment=OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g3/openclaw.json
Environment=OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g3
ExecStart=/home/wattman/.npm-global/bin/openclaw gateway --port 18829

# /etc/systemd/system/openclaw-g4.service
[Service]
User=wattman
Environment=OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g4/openclaw.json
Environment=OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g4
ExecStart=/home/wattman/.npm-global/bin/openclaw gateway --port 18849

# /etc/systemd/system/openclaw-g5.service
[Service]
User=wattman
Environment=OPENCLAW_CONFIG_PATH=/home/wattman/.openclaw-g5/openclaw.json
Environment=OPENCLAW_STATE_DIR=/home/wattman/.openclaw-g5
ExecStart=/home/wattman/.npm-global/bin/openclaw gateway --port 18869
```

**日常运维命令**：

```bash
# 查看所有实例状态
for i in 1 2 3 4 5; do
  openclaw --profile g$i gateway status --deep
done

# 升级所有实例（OpenClaw 代码是共享的，升级一次即可）
npm update -g openclaw
systemctl restart openclaw-g1 openclaw-g2 openclaw-g3 openclaw-g4 openclaw-g5

# 备份
tar czf openclaw-backup-$(date +%Y%m%d).tar.gz \
  /home/wattman/.openclaw-g1 \
  /home/wattman/.openclaw-g2 \
  /home/wattman/.openclaw-g3 \
  /home/wattman/.openclaw-g4 \
  /home/wattman/.openclaw-g5
```

**监控**：

```bash
# 快速健康检查
for p in 18789 18809 18829 18849 18869; do
  echo "Gateway on port $p: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:$p/health)"
done

# 资源监控（CPU + RAM）
ps -p $(pgrep -f 'openclaw-gateway' | tr '\n' ',') -o pid,pcpu,pmem,rss,comm
```

#### 6. 扩容路径

> 基准：每个 Gateway 承载 40-60 个 Agent 时性能最优（基线 CPU ~25%，RAM ~1.5GB）。上限约 80 个 Agent/GW。当前服务器 32GB RAM 可跑 ~10-14 个 Gateway。

| 用户规模 | 预估 Agent 总数 | Gateway 实例数 | 每 GW Agent 数 | 服务器需求 | 预估总 RAM |
|----------|----------------|---------------|---------------|-----------|-----------|
| 100 用户 | ~250 个 | **5 个** | ~50 个 | 当前服务器 | ~7.5GB |
| 200 用户 | ~500 个 | 8 个 | ~63 个 | 当前服务器 | ~12GB |
| 500 用户 | ~1200 个 | 12-15 个 | ~80 个 | 当前服务器（约 18-22GB） | ~18-22GB |
| 1000 用户 | ~2500 个 | 20-25 个 | ~100 个 | 需要加服务器 | 分布式部署 |

**单服务器容量上限**：32GB RAM，除去系统和其他服务约 10GB，可用 22GB。每个 GW 约 1.5-2.5GB，最多可跑 **10-14 个 Gateway**。超过此范围需要多服务器部署。

#### 7. 实施步骤（预估 1-2 周）

```
第 1 天：准备
├── 在服务器上创建 4 个新的 OpenClaw 实例目录（g2-g5）
├── 生成每个实例的 openclaw.json（共享 models 配置，拆分 agents）
└── 验证新实例能正常启动

第 2-3 天：后端改造
├── gateway.js 改造为多连接模式
├── index.js 增加路由层（用户 → Gateway 映射）
├── SSE 事件合并和过滤
└── 用户/Agent 表增加 gateway_id 字段

第 4-5 天：数据迁移
├── 导出现有 216 个 Agent 配置
├── 按用户分配到不同 Gateway
├── 迁移 workspace 目录
└── 迁移会话历史

第 6-7 天：测试验证
├── 功能测试：创建 Agent、对话、分享
├── 并发测试：多用户同时操作
├── 故障测试：停掉一个 Gateway，验证其他用户不受影响
└── 配置写入测试：多用户同时创建 Agent，验证不再 clobber

第 8-10 天：灰度上线
├── 先迁移 10% 的用户到新架构
├── 观察 1-2 天
├── 逐步迁移到 50%、100%
└── 归档旧的单一 Gateway
```

#### 8. 分片策略：怎么拆分才合理？

**核心问题**：用户 A 创建了 2 个 Agent，用户 B 创建了 20 个 Agent，怎么分配才不会导致某个 Gateway 过载？

##### 方案 8.1：按用户绑定（推荐）

**规则**：一个用户的所有 Agent 都在同一个 Gateway 上。

```
用户 A（2 个 Agent）  → Gateway-1
用户 B（20 个 Agent） → Gateway-1
用户 C（5 个 Agent）  → Gateway-2
用户 D（15 个 Agent） → Gateway-2
用户 E（8 个 Agent）  → Gateway-3
用户 F（3 个 Agent）  → Gateway-3
```

**优点**：
- 用户的会话、Agent、数据都在一个 Gateway，查询简单
- 不需要跨 Gateway 查询会话历史
- 数据隔离天然生效
- 迁移时可以整个用户搬走

**缺点**：
- 可能不均匀（用户 B 的 20 个 Agent 全在 Gateway-1）

**如何缓解不均匀？**

用**最少 Agent 数优先**策略分配新用户：

```
用户注册时：
1. 统计每个 Gateway 当前有多少个 Agent
2. 把新用户分配到 Agent 数最少的 Gateway
```

```
初始状态：
  Gateway-1: 0 个 Agent
  Gateway-2: 0 个 Agent
  Gateway-3: 0 个 Agent

用户 A（创建 2 个 Agent） → 分配到 Gateway-1（0 < 0 = 0，选第一个）
  Gateway-1: 2 个 Agent
  Gateway-2: 0 个 Agent
  Gateway-3: 0 个 Agent

用户 B（创建 20 个 Agent）→ 分配到 Gateway-2（0 < 2）
  Gateway-1: 2 个 Agent
  Gateway-2: 20 个 Agent
  Gateway-3: 0 个 Agent

用户 C（创建 5 个 Agent） → 分配到 Gateway-3（0 < 2 < 20）
  Gateway-1: 2 个 Agent
  Gateway-2: 20 个 Agent
  Gateway-3: 5 个 Agent

用户 D（创建 10 个 Agent）→ 分配到 Gateway-1（2 < 5 < 20）
  Gateway-1: 12 个 Agent
  Gateway-2: 20 个 Agent
  Gateway-3: 5 个 Agent

用户 E（创建 8 个 Agent） → 分配到 Gateway-3（5 < 12 < 20）
  Gateway-1: 12 个 Agent
  Gateway-2: 20 个 Agent
  Gateway-3: 13 个 Agent
```

**阈值告警 + 动态再平衡**：

即使初始分配均匀，随着用户持续创建 Agent，某些 Gateway 可能变得过重。需要监控和再平衡：

```
每个 Gateway 的 Agent 容量上限 = 总容量 / Gateway 数量 × 1.5（弹性系数）

例如 5 个 Gateway，每个建议不超过 80 个 Agent（实测安全上限）：
- Gateway-1: 55 个 Agent ✅
- Gateway-2: 90 个 Agent ⚠️ 超过 80，触发告警
- Gateway-3: 40 个 Agent ✅
- Gateway-4: 35 个 Agent ✅
- Gateway-5: 30 个 Agent ✅

再平衡操作：
1. 从 Gateway-2 中选择 Agent 数量最多的用户
2. 将该用户及其所有 Agent 迁移到 Gateway-3（最轻的）
3. 迁移 workspace 目录和会话历史
4. 更新 SQLite 中的 gateway_id 映射
```

**关于"重度用户聚集"的边界情况**：

> 问题：如果 ABC 三个用户都创建了非常多的 Agent，被分到了同一个 Gateway 怎么办？

实际上，使用"最少 Agent 数优先"策略时，这种情况**几乎不会发生**。

原因：贪心分配是**动态决策**——每次新用户注册时，都选当前 Agent 最少的 Gateway。所以三个重度用户会被自然分散到三个不同的 Gateway：

```
重度用户 A（20 个 Agent）→ 注册时 GW-1 最少（0 个）→ 分到 GW-1
重度用户 B（15 个 Agent）→ 注册时 GW-2 最少（0 个）→ 分到 GW-2
重度用户 C（18 个 Agent）→ 注册时 GW-3 最少（0 个）→ 分到 GW-3
```

**真正的极端情况**是：所有 Gateway 已经各 80 个 Agent，某个用户突然批量创建 50 个 Agent（比如导入模板）。这时确实会打破平衡。

**第一版应对方案**（简单有效）：

1. **软上限告警**：单个 Gateway 达到 80 个 Agent 时，前端提示管理员"建议增加 Gateway"
2. **手动再平衡**：管理员把最重 Gateway 上的某个用户整体迁移到最轻的 Gateway
3. **扩容**：最直接的方式——加一个新的 Gateway 实例

**后期再做**（1000+ 用户阶段）：自动再平衡——Gateway Controller 监控负载，自动迁移用户。

> 当前建议：第一版只做贪心分配 + 超限告警，够用了。100 个用户约 250 个 Agent，分 5 个 Gateway 每个约 50 个，离上限（80）还有充足空间。即使出现不均匀，手动迁移一个用户就能解决。

**后端实现伪代码**：

```javascript
// 分配新用户到 Gateway
function assignGateway(user) {
  const counts = gateways.map(gw => ({
    id: gw.id,
    agentCount: countAgentsOnGateway(gw.id)
  }));
  // 选 Agent 数最少的
  counts.sort((a, b) => a.agentCount - b.agentCount);
  const selected = counts[0].id;

  // 写入数据库
  db.prepare('UPDATE users SET gateway_id = ? WHERE id = ?')
    .run(selected, user.id);

  return selected;
}

// 用户创建 Agent 时，直接写入所属 Gateway
function createAgent(user, agentConfig) {
  const gatewayId = getUserGateway(user.id);
  const gateway = gateways.find(gw => gw.id === gatewayId);
  return gateway.rpc('config.patch', { agents: { list: [agentConfig] } });
}

// 查询用户会话时，只查所属 Gateway
function getSession(user, sessionKey) {
  const gatewayId = getUserGateway(user.id);
  return gateways.find(gw => gw.id === gatewayId).rpc('sessions.get', { key: sessionKey });
}
```

##### 方案 8.2：按 Agent 单独分配（不推荐）

**规则**：每个 Agent 可以独立分配到不同 Gateway。

```
用户 A:
  Agent-1 → Gateway-1
  Agent-2 → Gateway-2

用户 B:
  Agent-1 → Gateway-1
  Agent-2 → Gateway-3
  Agent-3 → Gateway-1
  ...
```

**优点**：
- 负载绝对均匀

**缺点**：
- 一个用户的会话可能分散在多个 Gateway
- 查询"我的所有会话"需要跨 Gateway 聚合
- 用户管理复杂度大幅增加
- 迁移时需要逐个 Agent 处理

**结论**：不推荐。增加的复杂度远大于负载均衡的收益。

##### 方案 8.3：动态弹性分片（长期方案）

如果未来发展到 1000+ 用户，可以考虑更高级的策略：

```
                    ┌──────────────────────┐
                    │   Gateway Controller  │
                    │   (管理进程)           │
                    │                      │
                    │  - 监控每个 GW 负载    │
                    │  - 动态创建新 GW 实例  │
                    │  - 自动迁移用户        │
                    │  - 健康检查            │
                    └──────┬───────────────┘
                           │
            ┌──────────────┼──────────────┐
            ↓              ↓              ↓
        Gateway-1      Gateway-2      Gateway-N
        (自动伸缩)      (自动伸缩)      (按需创建)
```

这个可以作为 1000+ 用户阶段的演进方向，初期不需要实现。

##### 总结对比

| 维度 | 按用户绑定（推荐） | 按 Agent 分配 | 动态弹性 |
|------|-------------------|--------------|---------|
| 实现复杂度 | 低 | 高 | 很高 |
| 负载均衡 | 较好（最少 Agent 数优先） | 完美 | 完美 |
| 查询复杂度 | 低（单 Gateway） | 高（跨 Gateway） | 低（Controller 屏蔽） |
| 迁移成本 | 低（按用户整体迁移） | 高（逐个 Agent） | 自动化 |
| 适用阶段 | 现在 → 500 用户 | 不推荐 | 1000+ 用户 |

---

### 方案 B：Gateway + 消息队列

在 WattClaw 后端和 Gateway 之间加消息队列层，控制并发。

```
用户请求 → WattClaw 后端 → 消息队列 → Gateway（受限并发）
```

**优点**：
- 改动最小，主要在后端加队列控制
- 保护 Gateway 不被并发压垮

**缺点**：
- 没有解决根因——单进程瓶颈依然存在
- 增加延迟（请求排队等待）
- 配置文件并发写入问题依然存在
- 扩展性差，到 1000 用户时队列本身就成为瓶颈

**结论**：可以作为方案 A 的补充手段，但不能单独解决问题。

---

### 方案 C：引入 Dify 替代 OpenClaw

Dify 是目前最成熟的开源 AI Agent 平台，GitHub 90k+ Stars，原生多租户设计。

**Dify 关键信息**：

| 项目 | 值 |
|------|-----|
| GitHub Stars | 90k+ |
| 开源协议 | Dify License（基于 Apache 2.0，非完全自由商用） |
| 技术栈 | Python (Flask) + Celery + PostgreSQL + Redis |
| 部署方式 | Docker Compose / Kubernetes |
| 多租户 | 原生支持，每个团队独立空间 |
| 模型支持 | 数百家 LLM Provider |
| 已服务 | 1M+ 应用，5M+ 团队 |
| 企业客户 | 沃尔沃、理光等 |

**优点**：
- 架构设计就是为企业多用户场景做的
- 原生多租户、权限隔离、API 管理
- 支持 K8s 水平扩展
- 可视化工作流编辑器
- 内置 RAG 管道、50+ 内置工具
- 完善的日志和可观测性

**缺点**：
- 跟 OpenClaw 生态不兼容，迁移成本大
- 现有的飞书 Channel、MCP Tools 等需要重新对接
- WattClaw 前端需要较大改造
- 工程量大（预估 1-3 个月）
- 开源协议有商业使用限制

---

### 方案对比总结

| 维度 | 方案 A：多 Gateway 分片 | 方案 B：消息队列 | 方案 C：Dify 替代 |
|------|------------------------|-----------------|-------------------|
| 改动量 | 中等（后端路由层） | 小（后端队列） | 大（整体架构） |
| 解决根因 | 是（进程隔离） | 否（只是缓冲） | 是（原生多租户） |
| 解决配置问题 | 是（分开配置） | 否 | 是（数据库存储） |
| 保留现有投资 | 是 | 是 | 否 |
| 扩展到 1000+ | 可以 | 不行 | 可以 |
| 实施周期 | 1-2 周 | 2-3 天 | 1-3 个月 |
| 风险 | 低 | 低 | 高 |

---

## 四、其他可选方案

| 项目 | 定位 | 多租户 | 适合度 | 备注 |
|------|------|--------|--------|------|
| **Dify** | 企业级 AI Agent 平台 | 原生支持 | 高 | 最成熟的开源方案 |
| **Coze（扣子）** | 字节跳动 AI Agent 平台 | 原生支持 | 中 | 商业 SaaS，私有化需联系商务 |
| **FastGPT** | 知识库 + AI 对话 | 有团队隔离 | 中 | 偏知识库场景 |
| **MaxKB** | 知识库问答 | 有 | 低 | 只是问答，功能有限 |
| **RAGFlow** | RAG 引擎 | 无 | 低 | 只做 RAG |
| **LobeChat** | AI 聊天 UI | 有多用户版本 | 低 | 偏 UI 层，后端能力弱 |

---

## 五、建议路线

### 推荐策略：渐进式演进

**第一阶段（1-2 周）：多 Gateway 分片**
- 先在当前服务器上部署 5 个 OpenClaw Gateway 实例
- 修改 WattClaw 后端支持多连接路由
- 按 Agent 数量均分用户到不同 Gateway
- 验证"停止响应"和"配置冲突"问题是否解决

**第二阶段（按需评估）：长期架构**
- 并行评估 Dify 自部署方案
- 如果 OpenClaw 多 Gateway 方案能持续支撑到 500 用户，可以暂不迁移
- 如果瓶颈明显，启动 Dify 迁移计划

---

## 六、参考资料

- [OpenClaw Multiple Gateways 官方文档](https://docs.openclaw.ai/gateway/multiple-gateways)
- [OpenClaw Gateway 配置](https://docs.openclaw.ai/gateway/configuration)
- [OpenClaw 架构概览](https://docs.openclaw.ai/concepts/architecture)
- [OpenClaw Agent 概念](https://docs.openclaw.ai/concepts/agent)
- [OpenClaw Multi-Agent Routing](https://docs.openclaw.ai/concepts/multi-agent)
- [OpenClaw FAQ](https://docs.openclaw.ai/help/faq)
- [Dify GitHub](https://github.com/langgenius/dify)
- [Dify 官网](https://dify.ai)
- [Coze 官网](https://www.coze.com)
