# 工作区加载瀑布阻塞性能诊断

**日期**: 2026-06-04 | **状态**: 设计中 | **严重程度**: 高

## 问题描述

进入在线对话工作区并加载文件管理时，发生严重的延迟与卡顿。根因为前端组件挂载阶段的瀑布式串行请求 + Gateway WebSocket RPC 阻塞 + 文件面板自动加载。

## 1. 当前请求链路拓扑

```mermaid
sequenceDiagram
    participant UI as WorkspacePage
    participant Store as Pinia Store
    participant BE as Backend HTTP
    participant SQLite as SQLite
    participant PG as PostgreSQL
    participant GW as Gateway WebSocket

    Note over UI: onMounted()

    rect rgb(230,240,255)
        Note over UI,SQLite: ① loadAgents()
        UI->>Store: await loadAgents()
        Store->>BE: GET /api/agent-team/list
        BE->>SQLite: SELECT user_agents LEFT JOIN user_sessions
        SQLite-->>BE: agent rows + last_active_at
        BE-->>Store: agent[]
        Store->>BE: GET /api/sessions
        BE->>SQLite: SELECT user_sessions WHERE user_id=?
        SQLite-->>BE: session meta rows
        BE-->>Store: sessions[]
    end

    rect rgb(255,240,220)
        Note over UI,GW: ② loadModels() [await AFTER ①]
        UI->>Store: await loadModels()
        Store->>BE: WebSocket RPC: models.list
        BE->>GW: WebSocket 转发
        GW-->>BE: 全量 ModelInfo[]
        BE-->>Store: models[]
    end

    rect rgb(240,255,240)
        Note over UI,SQLite: ③ selectAgent(agentId)
        UI->>Store: await selectAgent(agentId)
        Store->>Store: filePanelAutoOpen = true 🔥
        Store->>BE: GET /api/sessions
        BE-->>Store: sessions[]
        Note over Store: 🔥 触发 ChatFilePanel watch
    end

    rect rgb(255,255,230)
        Note over UI,PG: ④ selectSession(sessionKey)
        UI->>Store: await selectSession(sessionKey)
        Store->>BE: GET /api/chat/history?sessionKey=...&limit=50
        BE->>PG: SELECT messages ORDER BY msg_timestamp
        PG-->>BE: history rows
        BE-->>Store: history[]
        Note over UI: ✅ 对话可用
    end

    rect rgb(255,220,220)
        Note over UI,GW: ⑤ ChatFilePanel 自动加载
        Store-->>UI: filePanelAutoOpen watch 触发
        UI->>BE: GET /api/agents/workspace?agentId=...
        BE->>GW: gatewayAdminRpc('agents.list') 🔴 全量拉取
        GW-->>BE: 所有 Agent
        BE-->>UI: workspace path
        UI->>BE: GET /api/files/list?workspace=...
        BE->>BE: spawn('find ...') 🔴 本地文件系统
        BE-->>UI: 文件树
        Note over UI: 文件面板可用
    end
```

## 2. 请求明细表

| # | 端点 | 传输 | 数据源 | 查询内容 | 用途 |
|---|------|------|--------|----------|------|
| ① | `GET /api/agent-team/list` | HTTP | SQLite | `user_agents` LEFT JOIN `user_sessions` → agent 列表 + `COALESCE(MAX(us.updated_at))` | 左侧 Agent 列表 |
| ① | `GET /api/sessions` | HTTP | SQLite | `user_sessions` WHERE `user_id=?` → 全量 session 元数据 (token_*, msg_*, tool_usage_json) | 右侧 Session 列表 |
| ② | `models.list` | **WebSocket RPC** | Gateway 转发 | Gateway 全量 ModelInfo → 后端代理转发 | 模型选择下拉框 |
| ③ | `GET /api/sessions` | HTTP | SQLite (store 缓存) | 同①，从 Pinia store 缓存取出，不用再请求 | 按 agentId 过滤 Session |
| ④ | `GET /api/chat/history` | HTTP | PG → Gateway fallback | `messages` WHERE `session_key=?` ORDER BY `msg_timestamp` LIMIT 50; PG miss → Gateway HTTP fallback | **对话消息** |
| ⑤ | `GET /api/agents/workspace` | HTTP | **Gateway RPC** | `gatewayAdminRpc('agents.list')` → 全量 Agent → 提取 `.workspace` 字段 | 文件面板根路径 |
| ⑤ | `GET /api/files/list` | HTTP | **本地 `find`** | `spawn('find "${dirPath}" -mindepth 1 -maxdepth 1 -printf "%y|%f|%s\\n"')` | 文件树 |

## 3. 根因分析：三层瓶颈

### 瓶颈 1：瀑布式串行阻塞 (Waterfall Block)

`WorkspacePage.vue:83-85`：

```js
await workspaceStore.loadAgents()   // ①
await workspaceStore.loadModels()   // ② — 与 ① 无依赖
```

`loadAgents()` 和 `loadModels()` 相互独立，却被 `await` 强制串行。①-④ 全部顺序执行。

### 瓶颈 2：Gateway RPC 全量拉取

`/api/agents/workspace?agentId=X` → `gatewayAdminRpc('agents.list')` 拉取**所有 Gateway Agent**，仅为了取一个 workspace 字段。

```js
// server/handlers/user-agents.js:10-18
async function getAgentWorkspace(agentId) {
  const rpcResult = await gatewayAdminRpc('agents.list')  // 全量拉取
  const allAgents = listResult?.agents || listResult || []
  const agent = allAgents.find(a => (a.id || a.agentId) === agentId)
  return agent.workspace || null
}
```

**根因**: `user_agents` 表缺少 `workspace` 列，workspace 路径只能从 Gateway 获取，每次打开文件面板都重复全量拉取。

### 瓶颈 3：文件面板自动加载阻塞关键路径

`workspace.ts` `selectAgent()` 中 `filePanelAutoOpen = true` 无条件触发 ChatFilePanel 加载，导致 ⑤ 的两个慢请求跟在关键路径后面排队。

### 耗时估算

| 端点 | 估算耗时 | 瓶颈类型 | 是否关键路径 |
|------|----------|----------|-------------|
| `GET /api/files/list` | 200-2000ms | 本地 `find` I/O | 否（文件面板） |
| `GET /api/agents/workspace` | 100-500ms | Gateway RPC 全量拉取 | 否（文件面板） |
| `GET /api/chat/history` | 50-200ms | PG 查询 | **是** |
| `models.list` (WebSocket RPC) | 20-100ms | Gateway RPC | **是** |
| `GET /api/agent-team/list` | 5-20ms | SQLite JOIN | **是** |
| `GET /api/sessions` | 5-10ms | SQLite | **是** |

**当前串行最坏总耗时**: ~30 + ~100 + ~10 + ~200 + ~2500 = **~2.8s**

## 4. 重构目标架构

```mermaid
sequenceDiagram
    participant UI as WorkspacePage
    participant Store as Pinia Store
    participant BE as Backend
    participant SQLite as SQLite
    participant PG as PostgreSQL

    Note over UI: onMounted()

    rect rgb(200,255,200)
        Note over UI,SQLite: 关键路径: Promise.all 并行
        par
            UI->>BE: GET /api/agent-team/list
            BE->>SQLite: SELECT user_agents
        and
            UI->>BE: GET /api/sessions
            BE->>SQLite: SELECT user_sessions
        and
            UI->>BE: WebSocket RPC: models.list
        end
        BE-->>UI: 全部就绪 (~100ms)
    end

    rect rgb(200,255,200)
        Note over UI,PG: 选会话
        UI->>BE: GET /api/chat/history?sessionKey=...&limit=50
        BE->>PG: SELECT messages
        PG-->>BE: history
        Note over UI: ✅ 对话可用 (~200ms)
    end

    rect rgb(200,200,255)
        Note over UI: 非关键路径: 用户手动触发文件面板
        UI-->>UI: 点击文件面板按钮
        UI->>BE: GET /api/files/list?workspace=... (workspace 已在 /api/sessions 响应中)
    end
```

### 关键变更

| # | 变更 | 预期收益 |
|---|------|----------|
| 1 | `loadAgents()` + `loadModels()` → `Promise.all` 并行 | 节省 ~100ms |
| 2 | `selectAgent()` 移除 `filePanelAutoOpen = true` | 文件面板不再排队阻塞对话加载 |
| 3 | `user_agents` 表新增 `workspace` 列，Agent 创建时写入 | 消除 Gateway RPC 全量拉取 |
| 4 | `/api/sessions` 响应中内嵌 `workspace` 字段 | 一次 HTTP 请求同时拿到 session + workspace |
| 5 | 文件面板纯懒加载 | 只在用户点击时发起请求 |

## 5. 实现方案

### 方案 A：最小改动（推荐，<100行改动）

**前端**:
- `WorkspacePage.vue`: `loadAgents()` + `loadModels()` → `Promise.all` 并行
- `workspace.ts`: `selectAgent()` 移除 `filePanelAutoOpen = true`

**后端**:
- 无需改动

**收益**: 对话可用时间从 ~2.8s → ~300ms

### 方案 B：深度优化

在方案 A 基础上增加：
- `user_agents` 表新增 `workspace TEXT` 列
- Agent 创建/同步时写入 workspace 路径
- `/api/agent-team/list` 响应中内嵌 `workspace` 字段
- `getAgentWorkspace()` 改为从 SQLite 读取，不再调用 Gateway RPC
- 删除 `filePanelAutoOpen` 相关逻辑

**收益**: 彻底消除 Gateway RPC 全量拉取，文件面板加载从 ~2.5s → ~500ms

## 6. 验证标准

- [ ] 对话工作区首次渲染 < 500ms（不含文件面板）
- [ ] 文件面板独立加载，不阻塞对话交互
- [ ] `filePanelAutoOpen` 逻辑保留但不再在 selectAgent 中无条件触发
- [ ] 不破坏现有 WebSocket 连接和消息收发机制
- [ ] 不修改 `agent_team`、`user_sessions` 表结构（方案 A）
- [ ] 方案 B: `user_agents` 新增 `workspace` 列向后兼容

## 7. 数据库操作全景分析

### 7.1 核心表结构

```
SQLite (wizard.db):
├── users              — 用户账号
├── user_agents        — 用户拥有的 Agent (gateway_agent_id 关联 Gateway)
│   ⚠️ 缺少 workspace 列 — 路径只能从 Gateway RPC 获取
├── user_sessions      — 用户拥有的 Session (session_key 关联 Gateway)
├── user_channels      — 渠道绑定 (飞书等)
├── agent_team         — 数字员工模板/配置 (soul_md, agents_md 等)
└── skill_store_*      — 技能商店

PostgreSQL (message_store):
└── messages           — 会话消息历史 (session_key + seq + role + content + raw_content)
```

### 7.2 Agent 创建与同步

```
创建数字员工:
  前端 → POST /api/agent-team/create → agent_team 表 (SQLite)
  前端 → Gateway RPC agents.create → OpenClaw Gateway
  Gateway 返回 agentId → 写入 user_agents 表 (SQLite)
  ⚠️ Gateway 返回的 workspace 路径未写入 user_agents

Gateway 事件同步 (server/index.js:389-428):
  Gateway SSE event 到达
    → 提取 sessionKey → agentId
    → getUserIdsByAgentId(agentId) 查 user_agents 表
    → trackSessionForUser(uid, sessionKey, agentId) 写入 user_sessions
```

**关键**: 飞书等外部渠道的 Session 不在本地创建，而是通过 Gateway 事件反向同步到 `user_sessions` 表。

### 7.3 在线对话数据获取路径

| 步骤 | 端点 | 传输 | 数据源 | 说明 |
|------|------|------|--------|------|
| Agent 列表 | `GET /api/agent-team/list` | HTTP | SQLite `user_agents` | 带 last_active_at |
| Session 列表 | `GET /api/sessions` | HTTP | SQLite `user_sessions` | 含 token usage 元数据 |
| 模型列表 | `models.list` | WebSocket RPC | Gateway 转发 | 全量 ModelInfo |
| 对话历史 | `GET /api/chat/history` | HTTP | PG `messages` | 先查 PG，miss 则 fallback Gateway HTTP |
| Workspace 路径 | `GET /api/agents/workspace` | HTTP | Gateway RPC `agents.list` | 🔴 全量拉取，仅取一个字段 |
| 文件列表 | `GET /api/files/list` | HTTP | 本地 `find` | `spawn('find ...')` 本地文件系统 |

### 7.4 飞书会话同步问题

飞书渠道的 Session 生命周期：

```
用户 A 绑定飞书渠道 → Agent (gateway_agent_id)
飞书用户发消息 → Gateway 创建 Session → Gateway SSE 事件
  → server/index.js gateway.on('event')
  → trackSessionForUser(uid, sessionKey, agentId)
  → user_sessions 表写入记录
```

**当前状态**:
- `GET /api/sessions` 已改为纯 SQLite 查询（`b2d3072`），不再轮询 Gateway
- `syncSessionsFromGateway()` 已被清空为空函数
- 飞书等外部 Session 完全依赖 Gateway SSE 事件来同步到 `user_sessions`
- 如果在 Gateway 连接建立**之前**创建的飞书 Session，将不会被同步

**缺失的同步**: `GET /api/chat/history` 在 PG miss 时会 fallback 到 Gateway HTTP，但 `GET /api/sessions` 没有类似的 fallback 机制。

### 7.5 Workspace 数据缺失

`user_agents` 表存储了 Agent 元数据（name, model, category 等），但**不存储 workspace 路径**。Workspace 路径只能从 Gateway RPC `agents.list` 获取，每次打开文件面板都重复全量拉取。这是文件面板加载的核心瓶颈之一。

## 8. 相关文件

| 文件 | 角色 |
|------|------|
| `src/views/workspace/WorkspacePage.vue:83-99` | onMounted 瀑布入口 |
| `src/stores/workspace.ts:432-467` | loadAgents / selectAgent |
| `src/stores/workspace.ts:1723-1729` | loadModels → modelStore.fetchModels() |
| `src/stores/model.ts:13-24` | fetchModels → wsStore.rpc.listModels() (WebSocket RPC) |
| `src/views/chat/ChatFilePanel.vue:206-220` | loadWorkspace / refreshTree |
| `server/handlers/agent-team.js:17-22` | GET /api/agent-team/list → getDigitalEmployees() |
| `server/user-manager.js:423-441` | getDigitalEmployees SQL: user_agents LEFT JOIN user_sessions |
| `server/handlers/sessions.js:84-112` | GET /api/sessions → 纯 SQLite |
| `server/handlers/chat.js:193-292` | GET /api/chat/history → PG → Gateway fallback |
| `server/handlers/user-agents.js:10-18` | getAgentWorkspace → gatewayAdminRpc('agents.list') 🔴 |
| `server/handlers/files.js:111-136` | GET /api/files/list → spawn('find ...') 本地文件系统 |
| `server/core/system.js:111-152` | gatewayExec = localExec = spawn(cmd, {shell: true}) |
| `server/database.js:167-263` | DB schema: users, user_agents (无 workspace 列), user_sessions |
| `server/index.js:210-216` | syncSessionsFromGateway (已清空) |
| `server/index.js:389-428` | Gateway event → trackSessionForUser 同步 |
