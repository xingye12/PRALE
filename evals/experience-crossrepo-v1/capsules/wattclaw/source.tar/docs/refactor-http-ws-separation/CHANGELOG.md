# HTTP+WS 协议分离重构 — 变更日志

> **分支**: `worktree-http-ws-separation`  
> **基线**: `main` (`01cc661`)  
> **目标**: 解决单条 WebSocket 队头阻塞（Head-of-Line Blocking）  
> **方案**: HTTP 对话 + WS 管理混合架构（方案C）

---

## 1. 概述

### 1.1 核心瓶颈

WattClaw 后端通过**单条 WebSocket** 向 OpenClaw Gateway 发起所有 RPC 调用。Gateway 运行在 Node.js 单线程事件循环中，`agentCommandFromIngress()` 的同步 prompt 构建会阻塞后续请求，导致多用户对话时出现严重的**队头阻塞**。

### 1.2 改造目标

- **剥离**：高频对话/推理流量（`chat.send`）改为走 Gateway HTTP `/v1/chat/completions`
- **保留**：状态管理、低频轮询、配置操作继续走 WS RPC
- **优化**：将无意义的后端轮询改为按需刷新，消除稳态 RPC 浪费

---

## 2. 文件变更清单

| 优先级 | 文件 | 变更类型 | 说明 |
|--------|------|----------|------|
| P0 | `server/utils.js` | 修改 | `createPollingCache` 改为惰性刷新 |
| P0 | `server/index.js` | 修改 | 新增 `proxyChatToGatewayHttp`，`/api/workspace/send` 改为 SSE |
| P0 | `src/stores/workspace.ts` | 修改 | `sendMessage` 改为 SSE fetch 解析，`cancelCurrentRequest` 增加 abort |
| P0 | `src/stores/session.ts` | 修改 | `createSession` 改为 HTTP 入口，新增 `sendHttpChatMessage` helper |
| P0 | `src/components/office/ScenarioWizard.vue` | 修改 | 去掉轮询，改为直接解析 SSE 流 |

---

## 3. Phase 0: 轮询系统优化

### 3.1 `server/utils.js` — `createPollingCache` 惰性刷新

**改造前**：
```javascript
export function createPollingCache(interval, fetcher) {
  // ...
  const initialDelay = 2000 + Math.floor(Math.random() * 5000)
  setTimeout(refresh, initialDelay)
  setInterval(refresh, interval)
  return { getData: () => data, refresh, removeItem }
}
```

**改造后**：
```javascript
export function createPollingCache(interval, fetcher) {
  // ...
  function shouldRefresh() {
    return !refreshing && (data === null || Date.now() - lastRefresh > interval)
  }
  return {
    getData() {
      if (shouldRefresh()) refresh() // fire-and-forget
      return data
    },
    async getFreshData() {
      if (refreshPromise || shouldRefresh()) await (refreshPromise || refresh())
      return data
    },
    refresh,
    removeItem,
  }
}
```

**关键变化**：
1. 移除 `setTimeout(initialDelay)` — 启动时不自动查询
2. 移除 `setInterval(refresh, interval)` — 不再定时查询
3. `getData()` 增加惰性刷新：首次调用触发 refresh，过期调用触发 refresh（返回 stale 数据）
4. 新增 `getFreshData()`：需要保证新鲜数据时同步等待 refresh
5. 新增 `refreshPromise` 机制：并发调用者共享同一个 in-flight fetch，避免重复请求

**效果**：

| 轮询器 | 改造前/分钟 | 改造后 | 节省 |
|--------|------------|--------|------|
| `allSessionsPolling` (9s, N+1 扇出) | ~73 次 RPC | **0**（无请求时不查） | 100% |
| `modelsListPolling` (13s) | ~5 次 | **0** | 100% |
| `cronListPolling` (11s) | ~5 次 | **0** | 100% |
| `skillsStatusPolling` (17s) | ~4 次 | **0** | 100% |
| `configGetPolling` (19s) | ~3 次 | **按需** | ~100% |
| `usagePolling` (60s) | ~1 次 | **按需** | ~100% |
| **合计** | **~91 次/分钟** | **~0 次/分钟（空闲时）** | **~100%** |

---

## 4. Phase 1: 后端 SSE + HTTP Gateway

### 4.1 `server/index.js` — 新增 `proxyChatToGatewayHttp`

新增内部辅助函数，封装 HTTP POST Gateway 和 SSE pipe：

```javascript
async function proxyChatToGatewayHttp(params, res, req) {
  const { sessionKey, message, model, title, agentId } = params

  // 安全构造 Gateway HTTP URL
  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL)
  const gatewayHttpUrl = new URL(
    '/v1/chat/completions',
    `${wsUrl.protocol === 'wss:' ? 'https' : 'http'}://${wsUrl.host}`
  ).toString()

  const abortController = new AbortController()
  const onClose = () => abortController.abort()
  req.once('close', onClose)

  try {
    const gatewayRes = await fetch(gatewayHttpUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model || 'openclaw',
        messages: [{ role: 'user', content: message }],
        stream: true,
        user: sessionKey,
      }),
      signal: abortController.signal,
    })

    if (!gatewayRes.ok) {
      const errorText = await gatewayRes.text().catch(() => 'Gateway HTTP error')
      req.removeListener('close', onClose)
      return res.status(gatewayRes.status).json({ ok: false, error: errorText })
    }

    // SSE headers → frontend
    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.setHeader('X-Accel-Buffering', 'no')
    res.flushHeaders()

    // Pipe Web ReadableStream → Node ServerResponse
    const upstream = Readable.fromWeb(gatewayRes.body)
    upstream.pipe(res)

    upstream.on('error', (err) => {
      if (abortController.signal.aborted) return
      console.error('[ChatHTTP] upstream error:', err.message)
      if (!res.writableEnded) res.end()
    })

    res.on('finish', () => {
      req.removeListener('close', onClose)
      upstream.destroy()
    })

    res.on('close', () => {
      req.removeListener('close', onClose)
      if (upstream && !upstream.destroyed) upstream.destroy()
    })

    // sessions.patch label（fire-and-forget，仍走 WS）
    const safeTitle = title ? generateSafeTitle(title) : ''
    if (safeTitle && sessionKey) {
      const gatewayLabel = `${safeTitle}-${Date.now()}`
      gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
    }

    // 本地 session 跟踪
    trackSessionForUser(req.currentUser.id, sessionKey, agentId, safeTitle, null)

  } catch (err) {
    req.removeListener('close', onClose)
    if (abortController.signal.aborted) return
    console.error('[ChatHTTP] fetch error:', err.message)
    if (!res.headersSent) {
      res.status(502).json({ ok: false, error: err.message })
    } else if (!res.writableEnded) {
      res.end()
    }
  }
}
```

### 4.2 `/api/workspace/send` 改造

**改造前**（返回 JSON `{streamId}`）：
```javascript
app.post('/api/workspace/send', authMiddleware, async (req, res) => {
  // ...
  const streamId = randomUUID()
  streamIdMap.set(streamId, { sessionKey, startTime: Date.now() })
  await gateway.call('chat.send', { sessionKey, message, idempotencyKey })
  res.json({ ok: true, streamId })
})
```

**改造后**（返回 SSE stream）：
```javascript
app.post('/api/workspace/send', authMiddleware, async (req, res) => {
  const { sessionKey, message, title, model } = req.body
  if (!sessionKey || !message) {
    return res.status(400).json({ ok: false, error: 'sessionKey and message required' })
  }
  const parts = sessionKey.split(':')
  const agentId = parts.length >= 2 ? parts[1] : null
  await proxyChatToGatewayHttp({ sessionKey, message, model, title, agentId }, res, req)
})
```

**保留模块**（未修改）：
- `/api/chat/cancel` — 继续走 WS RPC `gateway.call('chat.abort')`
- `/api/rpc` `chat.send` — 保留 WS 兼容层，仅供 `chat.ts` 使用

---

## 5. Phase 2: 前端 workspace.ts SSE fetch

### 5.1 `sendMessage` 改造

**改造前**（`httpPost` 获取 `streamId`）：
```typescript
const result = await httpPost('/api/workspace/send', {
  sessionKey, message, idempotencyKey, ...(titleToSend ? { title: titleToSend } : {}),
})
const sid = (result.streamId as string) || null
streamState.streamId = sid
activeStreamId.value = sid
```

**改造后**（`fetch` + SSE ReadableStream 解析）：
```typescript
const abortController = new AbortController()
activeAbortController.value = abortController

const response = await fetch(apiPath('/api/workspace/send'), {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ sessionKey, message, model: getActiveSessionModel(), ...(titleToSend ? { title: titleToSend } : {}) }),
  signal: abortController.signal,
})

// 解析 SSE 流
const reader = response.body!.getReader()
try {
  const decoder = new TextDecoder()
  let buffer = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const data = line.slice(6)
      if (data === '[DONE]') continue
      try {
        const chunk = JSON.parse(data)
        const content = chunk.choices?.[0]?.delta?.content
        const finishReason = chunk.choices?.[0]?.finish_reason
        if (content) appendStreamingContent(sessionKey, content)
        if (finishReason) finalizeStreaming(sessionKey, finishReason)
      } catch { /* ignore malformed chunk */ }
    }
  }
  finalizeStreaming(sessionKey, 'stop')
} finally {
  reader.releaseLock()
  activeAbortController.value = null
}
```

### 5.2 新增 `appendStreamingContent` / `finalizeStreaming`

```typescript
function appendStreamingContent(sessionKey: string, content: string) {
  const msgs = getSessionMessages(sessionKey)
  const streamState = streamStates.get(sessionKey)
  if (!streamState) return
  resetStreamTimeout()
  // 4 级 fallback: anchor by index → anchor by length → ID-less assistant → last assistant
  // ...（与 flushPendingDeltas 类似的增量更新逻辑）
}

function finalizeStreaming(sessionKey: string, _reason?: string) {
  forceStopStreaming(sessionKey)
}
```

### 5.3 `cancelCurrentRequest` 改造

```typescript
async function cancelCurrentRequest() {
  const key = activeSessionKey.value
  if (!key || (!activeStreamId.value && !sending.value)) return
  // 新增：Abort 前端 fetch
  if (activeAbortController.value) {
    activeAbortController.value.abort()
  }
  // 通知后端取消 Gateway 推理（去掉已废弃的 streamId）
  try {
    await httpPost('/api/chat/cancel', { sessionKey: key })
  } catch { /* best-effort */ }
  forceStopStreaming(key)
}
```

---

## 6. Phase 3a: session.ts 统一 HTTP 入口

### 6.1 新增 `sendHttpChatMessage` helper

```typescript
async function sendHttpChatMessage(payload: {
  sessionKey: string
  message: string
  model?: string
  title?: string
}): Promise<void> {
  const resp = await fetch(apiPath('/api/workspace/send'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({ error: 'Send failed' }))
    throw new Error(err.error || 'Send failed')
  }
  // Consume SSE body so the request completes
  const reader = resp.body!.getReader()
  try {
    while (true) {
      const { done } = await reader.read()
      if (done) break
    }
  } finally {
    reader.releaseLock()
  }
}
```

### 6.2 `createSession` 改造

```typescript
async function createSession(params: { agentId?: string; channel?: string; peer?: string; label?: string }): Promise<string> {
  // ... 构造 sessionKey ...
  await sendHttpChatMessage({ sessionKey, message: '/new' })
  // ... patchSession + fetchSessions ...
}
```

---

## 7. Phase 3b: ScenarioWizard.vue 统一 HTTP 入口

### 7.1 去掉轮询，改为 SSE 流解析

**改造前**：
```typescript
await wsStore.rpc.sendChatMessage({ sessionKey, message: userMessage, idempotencyKey })
// 轮询 60 次，每秒查询 listChatHistory
while (attempts < maxAttempts) {
  await new Promise(resolve => setTimeout(resolve, pollInterval))
  const history = await wsStore.rpc.listChatHistory(sessionKey)
  // 检查 lastMessage.role === 'assistant'
}
```

**改造后**：
```typescript
const resp = await fetch(apiPath('/api/workspace/send'), {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ sessionKey, message: userMessage }),
})

// 直接解析 SSE 流累积响应
const reader = resp.body!.getReader()
const decoder = new TextDecoder()
let buffer = ''
try {
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    // ... 解析 data: 行，提取 delta.content 追加到 lastMessageContent ...
  }
} finally {
  reader.releaseLock()
}
```

---

## 8. 防御边界（未触碰的模块）

| 模块 | 保留理由 |
|------|----------|
| `chat.ts` `sendChatMessage` | 复杂状态机依赖 `agent` 生命周期事件，HTTP `/v1/chat/completions` 不返回这些事件 |
| `/api/events` 非对话事件 | `chat.ts` 等依赖 `agent` 生命周期事件 |
| `/api/rpc` 非 chat 方法 | 所有管理操作代理 |
| `/api/chat/cancel` | 取消频率极低，不构成瓶颈；继续走 WS RPC |
| `streamIdMap` | 仍被 `/api/chat/cancel` 使用（虽然不再写入，但按 sessionKey 取消仍可工作） |
| Gateway WS 连接 (`gateway.js`) | 继续服务保留的 RPC |

---

## 9. 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| `chat.ts` 未迁移，部分流量仍走 WS | 中 | `chat.ts` 的 Office/Agent Chat 是低频场景。P0 优先解决主工作区并发瓶颈。 |
| Gateway HTTP 端口/路径不可达 | 高 | 使用 `new URL()` 安全构造 URL，避免字符串替换错误。 |
| 前端 SSE 解析错误 | 中 | 防御性解析：malformed chunk 直接忽略，不影响后续 token。 |
| 多用户并发下 `fetch` 连接数激增 | 中 | 每个用户独立 HTTP 连接，由操作系统 TCP 栈管理；WattClaw Express 和 Gateway 均为事件驱动，可承受高并发连接。 |

---

## 10. 部署建议

1. **先部署后端**（`server/utils.js` + `server/index.js`）
   - 验证 `/api/workspace/send` SSE 流正常
   - 验证空闲时无自动轮询 RPC

2. **再部署前端**（`src/stores/workspace.ts` + `src/stores/session.ts` + `ScenarioWizard.vue`）
   - 验证 ChatPage 主对话正常收发
   - 验证新建会话 / Wizard 正常

3. **监控指标**
   - Gateway WS RPC 调用频率（应下降）
   - Gateway HTTP 请求频率（应上升）
   - 多用户并发时对话延迟（应改善）

---

*本变更基于 `docs/OPENCLAW-WATTCLAW-ANALYSIS-v2.html` 的诊断结论，经过对 OpenClaw Gateway 源码和 WattClaw 全量代码的深度逆向分析后制定。*
