# HTTP+WS 分离重构 — 进度总览

## P0 已完成（已提交到 test/http-ws-separation）

### 1. 轮询系统优化
| 文件 | 改动 |
|------|------|
| `server/utils.js` | `createPollingCache` 去掉 `setInterval`/`setTimeout`，改为惰性刷新 |

**效果**：空闲时 RPC 从 ~91 次/分钟 → **0 次**。

### 2. 后端 SSE 透传
| 文件 | 改动 |
|------|------|
| `server/index.js` | 新增 `proxyChatToGatewayHttp`，`/api/workspace/send` 改为 SSE 透传 Gateway HTTP `/v1/chat/completions` |

### 3. 前端主对话 SSE 解析
| 文件 | 改动 |
|------|------|
| `src/stores/workspace.ts` | `sendMessage` 改 `fetch` + SSE `getReader()` 解析；新增 `appendStreamingContent`/`finalizeStreaming`；`cancelCurrentRequest` 增加 `AbortController.abort()` |

### 4. 新建会话走 HTTP
| 文件 | 改动 |
|------|------|
| `src/stores/session.ts` | `createSession` 改 `sendHttpChatMessage`（POST `/api/workspace/send`） |

### 5. Wizard 去掉轮询
| 文件 | 改动 |
|------|------|
| `src/components/office/ScenarioWizard.vue` | 去掉 60 秒轮询 `listChatHistory`，直接解析 SSE 流 |

### 6. 认证修复
| 文件 | 改动 |
|------|------|
| `src/stores/workspace.ts` | `fetch` 请求添加 `Authorization: Bearer <token>` |
| `src/stores/session.ts` | 同上 |
| `src/components/office/ScenarioWizard.vue` | 同上 |

### 7. 测试容器网络修复
| 文件 | 改动 |
|------|------|
| `docker-compose.test.yml` | 去掉自定义网络 `wattclaw-test-net`（172.29.x.x 隔离），改用默认 Docker bridge |

### 8. 模型冗余 RPC 去除
| 文件 | 改动 |
|------|------|
| `src/stores/workspace.ts` | `ensureModelPatched()` / `previewModelChange()` 清空，不再发 `sessions.patch` model RPC |

### 9. 测试部署配置
| 文件 | 改动 |
|------|------|
| `docker-compose.test.yml` | healthcheck 改用 `node` 内置 `http`（`node:24-slim` 无 `wget`） |
| `deploy-test.sh` | 新增一键测试部署脚本 |

---

## 测试验证清单

### 阻塞性问题（必须先通过）
- [ ] 浏览器清除缓存后，登录正常
- [ ] 发送消息走 `POST /api/workspace/send`（Network 面板确认）
- [ ] 发送后 SSE 流正常返回，消息逐字显示
- [ ] 取消按钮点击后，请求终止（AbortController）
- [ ] 新建会话正常（`session.ts` 走 HTTP）
- [ ] ScenarioWizard 正常生成 Agent
- [ ] 模型切换后发送，请求 body 带 `model` 字段
- [ ] 无 `sessions.patch` model RPC（Network 面板确认没有多余的 `/api/rpc`）

### 性能指标
- [ ] 空闲时 Gateway WS RPC 调用频率接近 0
- [ ] 多用户并发时对话延迟改善

### 边界情况
- [ ] 后端 `/api/chat/cancel` 仍正常（走 WS RPC）
- [ ] 获取聊天历史仍正常（`chat.history` 保留 WS）
- [ ] 获取会话列表仍正常（`sessions.list` 保留 WS）

---

## 待修改内容（Phase 2+）

### 高优先级

| 模块 | 现状 | 方案 | 工作量 |
|------|------|------|--------|
| `chat.history` HTTP 化 | 走 `/api/rpc` WS | Gateway 原生支持 `GET /sessions/{key}/history?limit=&cursor=`，后端新增代理端点，前端分页 | 中 |

**调研结论**：Gateway HTTP `/sessions/{key}/history` 完整支持分页（`limit` + `cursor` 游标），返回 `{messages, hasMore, nextCursor}`。和 `chat.send` 一样走 WattClaw 后端代理模式。

### 中优先级

| 模块 | 现状 | 方案 | 工作量 |
|------|------|------|--------|
| `chat.ts` `sendChatMessage` | 走 `/api/rpc` WS | 依赖 agent lifecycle 事件（tool/compaction），HTTP `/v1/chat/completions` 不返回这些事件。**暂不迁移**，或等 Gateway HTTP 支持 lifecycle 事件后再评估 | 大 |

### 低优先级（不构成瓶颈，保留 WS）

| 模块 | 说明 |
|------|------|
| `sessions.list` | 低频查询，惰性刷新后只在需要时触发 |
| `config.get` | 低频查询，配置变更不频繁 |
| `models.list` | 低频查询 |
| `cron.list` | 低频查询 |
| `skills.status` | 低频查询 |
| `usage.get` | 低频查询 |
| `/api/chat/cancel` | 低频操作，取消瞬间完成 |

---

## 下一步建议

1. **当前**：先把 P0 在测试环境跑通，验证清单全部勾选
2. **下一步**：评估是否推进 `chat.history` HTTP 化（Phase 2）
3. **最后**：`chat.ts` 的迁移需要等 Gateway HTTP 支持 lifecycle 事件，或评估是否有其他 workaround
