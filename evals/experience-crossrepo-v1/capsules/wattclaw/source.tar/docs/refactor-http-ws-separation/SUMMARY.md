# HTTP+WS 分离重构 — 改动摘要

## 一、改动范围

本次重构共修改 **5 个文件**，**+349 行 / -102 行**，零新增文件。

| 文件 | 变更 |
|------|------|
| `server/utils.js` | 轮询器改为按需刷新 |
| `server/index.js` | 后端 workspace send 改为 SSE 透传 Gateway HTTP |
| `src/stores/workspace.ts` | 前端主对话改为 SSE fetch 解析 |
| `src/stores/session.ts` | 新建会话改为 HTTP 入口 |
| `src/components/office/ScenarioWizard.vue` | Wizard 去掉轮询，直接解析 SSE |

---

## 二、Phase 0: 轮询系统优化

**问题**：后端 6 个轮询器在空闲时每分钟发起约 91 次 RPC，全部是无效请求。

**解决**：`createPollingCache` 从定时刷新改为惰性刷新。

- 移除 `setTimeout` + `setInterval`
- `getData()` 首次/过期时触发后台刷新，返回缓存数据
- 新增 `getFreshData()` 等待刷新完成再返回
- `refreshPromise` 机制避免并发重复请求

**效果**：空闲时 RPC 从 ~91 次/分钟 → **0 次**。

---

## 三、Phase 1: 后端 SSE + HTTP Gateway

**问题**：`/api/workspace/send` 通过 WS RPC `gateway.call('chat.send')` 发送，Gateway 单线程阻塞。

**解决**：新增 `proxyChatToGatewayHttp` 辅助函数，直接 POST Gateway HTTP `/v1/chat/completions`，将 SSE 流透传给前端。

**关键代码路径**：

```
Frontend fetch POST /api/workspace/send
    → Express proxyChatToGatewayHttp
        → fetch POST Gateway:18789/v1/chat/completions (stream: true)
            ← Gateway 返回 SSE stream
        ← Readable.fromWeb(gatewayRes.body).pipe(res)
    ← Frontend 解析 SSE stream
```

**AbortController 清理链**：
- 前端断开 → `req.on('close')` → `abortController.abort()` → Gateway fetch 取消
- 正常结束 → `res.on('finish')` → `upstream.destroy()`
- 异常关闭 → `res.on('close')` → `upstream.destroy()`

---

## 四、Phase 2: 前端 workspace.ts SSE 解析

**问题**：前端 `sendMessage` 原来通过 `httpPost` 获取 `streamId`，再等待 SSE 事件流，多了一步握手。

**解决**：`sendMessage` 直接使用 `fetch` + `AbortController`，通过 `response.body.getReader()` 解析 SSE。

**SSE 解析逻辑**：
1. `TextDecoder` 解码二进制流
2. 按 `\n` 分割，保留未完整行到 `buffer`
3. 匹配 `data: ` 前缀行
4. `JSON.parse` 提取 `choices[0].delta.content`
5. 通过 `appendStreamingContent` 追加到消息列表

**四级 fallback 锚点策略**（`appendStreamingContent`）：
1. `streamState.anchorIndex` 存在且有效 → 更新该索引消息
2. `anchorIndex` 超出长度 → push 新 assistant 消息
3. 无锚点 → 倒序查找无 `id` 的 assistant 消息更新
4. 终极 fallback → 更新最后一条 assistant 消息

**取消机制**：
- 前端 `activeAbortController.abort()` 终止 fetch
- 后端 `/api/chat/cancel` 仍走 WS RPC 通知 Gateway 停止推理

---

## 五、Phase 3a: session.ts 新建会话走 HTTP

**问题**：`createSession` 原来调用 `wsStore.rpc.sendChatMessage({message: '/new'})` 走 WS。

**解决**：新增 `sendHttpChatMessage` helper，统一走 `/api/workspace/send` HTTP 入口。

```typescript
async function createSession(params) {
  const sessionKey = `agent:${agentId}:${channel}:dm:${peer}`
  await sendHttpChatMessage({ sessionKey, message: '/new' })
  // ...
}
```

该 helper 会消费完整的 SSE body，确保请求正常结束。

---

## 六、Phase 3b: ScenarioWizard.vue 去掉轮询

**问题**：Wizard 发送消息后轮询 60 次 `listChatHistory`（每秒 1 次），总共 60 秒等待。

**解决**：直接解析 SSE 流，实时累积 `lastMessageContent`。

```typescript
// 改造前: WS send + 60 次轮询
await wsStore.rpc.sendChatMessage({...})
while (attempts < 60) {
  await sleep(1000)
  const history = await wsStore.rpc.listChatHistory(sessionKey)
  if (lastMessage.role === 'assistant') break
}

// 改造后: HTTP SSE 直接解析
const resp = await fetch(apiPath('/api/workspace/send'), {...})
// ... 解析 SSE 流，实时获得 content
```

---

## 七、未修改的模块（防御边界）

| 模块 | 保留理由 |
|------|----------|
| `chat.ts` | 依赖 agent lifecycle 事件（tool/compaction），HTTP 不返回 |
| `/api/chat/cancel` | 低频操作，继续 WS RPC |
| `/api/rpc` 非 chat 方法 | 管理操作代理 |
| Gateway WS 连接 | 继续服务保留的 RPC |

---

## 八、Commit 历史

```
370bdf8 fix(review): address critical + important issues from final review
494a84f refactor(frontend): session.ts + ScenarioWizard to HTTP SSE chat path
cb98753 refactor(frontend): workspace.ts SSE fetch for HTTP chat path
90eb3c7 fix(backend): pass safeTitle to trackSessionForUser
b0981db fix(backend): add res.on('close') cleanup and remove dynamic import
8b36a97 refactor(backend): proxy workspace chat to Gateway HTTP SSE
5820930 refactor(polling): getFreshData awaits in-flight refresh promise
0364d85 refactor(polling): deduplicate concurrent refreshes in createPollingCache
d99294f refactor(polling): make createPollingCache lazy refresh
```

---

## 九、验证清单（部署前）

- [ ] 后端 `/api/workspace/send` 返回 `text/event-stream`
- [ ] Gateway HTTP 请求正常返回 SSE
- [ ] 空闲时无自动轮询 RPC
- [ ] ChatPage 主对话正常收发
- [ ] 新建会话正常
- [ ] ScenarioWizard 正常生成 Agent
- [ ] 取消按钮正常终止推理
- [ ] 多用户并发对话延迟改善
