# Sessions.usage 数据残缺问题 — 诊断报告与 Adapter 方案

> 状态：待实施  
> 日期：2026-05-22  
> 范围：WattClaw 前端（`src/api/rpc-client.ts`）  
> 约束：OpenClaw 目录为只读参考区，绝对禁止修改

---

## 一、Bug 现象

仪表盘接口 `sessions.usage` 返回的 JSON 数据中：

| 字段 | 状态 | 说明 |
|------|------|------|
| `totals` | ❌ 全为 0 | input、output、totalTokens、totalCost 等全部为 0 |
| `aggregates.daily` | ❌ 空数组 | 趋势图无数据 |
| `aggregates.modelDaily` | ✅ 有数据 | 按日期+模型细粒度聚合，包含数千万有效 Token |
| `aggregates.byAgent` | ✅ 有数据 | 按 Agent 聚合，包含有效消耗数据 |

---

## 二、后端成因分析（OpenClaw Gateway — 只读参考）

### 2.1 核心结论

OpenClaw Gateway 的 `sessions.usage` RPC 响应实现了 **"细粒度聚合完备，顶层汇总缺失"** 的数据形态。

即 Gateway 在计算 usage 时：
- ✅ 完成了细粒度聚合：`aggregates.modelDaily`（按日期+模型）、`aggregates.byAgent`（按 Agent）有完整数据
- ❌ **未计算顶层汇总**：`totals` 全字段为 0，`aggregates.daily` 为空数组

这是 Gateway 内部 `sessions.usage` handler 的实现缺陷（或有意为之的半成品聚合策略）。Gateway 把聚合工作下放到消费方，只提供原始砖块（modelDaily、byAgent），不提供成品房子（totals、daily）。

### 2.2 无法定位具体源码文件的原因

OpenClaw 源码目录（`/Users/renming/Desktop/wattman/openclaw/openclaw/src`）存在大量带 ` 2.ts` 后缀的重复/备份文件，常规 grep 无法稳定匹配到权威的 handler 实现文件。但从 WattClaw 前后端的消费逻辑可以 100% 反推出 Gateway 的输出特征。

---

## 三、WattClaw 后端的防御现状

WattClaw 后端**已经意识到了这个问题**，并在 `server/index.js` 中编写了完整的重建引擎：

| 函数 | 位置 | 作用 |
|------|------|------|
| `detectGatewayUsageFormat()` | `index.js:344` | 检测数据格式，`precomputed` vs `session-based` |
| `rebuildTotalsFromByAgent()` | `index.js:373` | 从 `byAgent[].totals` reduce 反算顶层 `totals` |
| `rebuildDailyFromModelDaily()` | `index.js:395` | 从 `modelDaily[]` 按日期分组反算 `daily` |
| `rebuildByModelFromModelDaily()` | `index.js:417` | 从 `modelDaily[]` 反算 `byModel` / `byProvider` |
| `rebuildMessagesAndTools()` | `index.js:450` | 从 `modelDaily[]` 反算 `messages` / `tools` |

**但这些重建函数只在以下三个 REST API 路由中被调用**：
1. `/api/usage-totals` (`index.js:1115`)
2. `/api/gateway/proxy` 中的 `sessions.usage` RPC 代理 (`index.js:3365`)
3. `/api/gateway/proxy` 中的 `usage.cost` / `cost.usage` 代理 (`index.js:3388`, `3597`)

---

## 四、前端链路分析 — 病灶定位

### 4.1 核心问题：前端直连 Gateway，绕过重建引擎

Dashboard.vue 的 usage 数据来自**两条并行的独立链路**：

#### Phase 1（轻量级，快速渲染）
```javascript
// Dashboard.vue:495
fetch('/api/usage-totals', ...)
```
→ 走 REST API → 经过后端重建引擎 → 返回的数据是**健康的**

但这只用于一个备用值 `cachedTokenTotal`（`Dashboard.vue:48`），**不是主显示数据**。

#### Phase 2（重量级，详细数据）
```javascript
// Dashboard.vue:519
wsStore.rpc.getSessionsUsage({ startDate, endDate, limit: 1000 })
```
→ 走 WebSocket RPC → **直连 OpenClaw Gateway** → 返回原始残缺数据

### 4.2 数据绑定链路

**`sessionsUsageResult`** 被直接绑定到所有 UI 计算属性：

```javascript
// Dashboard.vue:108
const usageTotals = computed(() =>
  sessionsUsageResult.value?.totals || ZERO_USAGE_TOTALS
)

// Dashboard.vue:142
const dailyUsage = computed(() => {
  const fromSessions = sessionsUsageResult.value?.aggregates?.daily || []
  return fromSessions
})
```

**因此**：前端 Dashboard 的 totals、daily、segments、trend、kpi 等所有核心指标，全部直接消费了 Gateway 的残缺原始数据，完全绕过了 WattClaw 后端的重建引擎。

### 4.3 前端 normalize 层的问题

`rpc-client.ts:1491` 的 `normalizeSessionsUsageResult()` 是 RPC 数据的唯一入口。它只做字段映射和类型转换：

```javascript
totals: this.normalizeUsageTotals(row.totals),  // ← 直接透传 Gateway 的 0 值
aggregates: {
  ...
  daily,  // ← 直接透传 Gateway 的空数组
}
```

**没有做任何降级反算。**

---

## 五、其他受害链路

`getSessionsUsage()` 还在以下两处被调用，同样暴露于残缺数据：

1. **`src/stores/session.ts:152`** — `fetchSessions()` 中懒加载 Token usage，影响 Session 列表的 usage 显示
2. **`src/stores/workspace.ts:1106`** — 单个 session 的 usage 查询，影响 Chat Header 的 Token 显示

---

## 六、Adapter 防腐层方案

### 6.1 目标文件

**`src/api/rpc-client.ts`** — 在 `normalizeSessionsUsageResult()` 方法内部实施

### 6.2 选择该文件的原因

- 这是所有 `sessions.usage` 调用的**统一收口**
- 数据已进入前端，但尚未扩散到 Store 和 UI
- 与现有的 `normalizeUsageTotals()` 等规范化逻辑天然同层
- **一次修改，Dashboard + Session Store + Workspace Store 全部受益**

### 6.3 规约逻辑

在 `normalizeSessionsUsageResult()` 返回前，增加 `rebuildFromPrecomputed()` 私有方法调用：

```typescript
private rebuildFromPrecomputed(result: SessionsUsageResult): SessionsUsageResult {
  // 仅当 totals 明显残缺且存在可反算的源数据时触发
  const hasValidByAgent = result.aggregates.byAgent.length > 0
    && result.aggregates.byAgent.some(a => a.totals.totalTokens > 0)
  const hasValidModelDaily = result.aggregates.modelDaily.length > 0

  if (result.totals.totalTokens === 0 && hasValidByAgent) {
    // 从 byAgent 反算 totals
    result.totals = result.aggregates.byAgent.reduce(...)
  }

  if (result.aggregates.daily.length === 0 && hasValidModelDaily) {
    // 从 modelDaily 按日期分组反算 daily
    result.aggregates.daily = ...
  }

  if (result.aggregates.byModel.length === 0 && hasValidModelDaily) {
    // 从 modelDaily 反算 byModel / byProvider
    ...
  }

  // messages / tools 同理
  return result
}
```

### 6.4 防御性设计

- **幂等性**：如果 Gateway 未来修复了 totals，反算逻辑不会破坏正确数据（因为只在 `totalTokens === 0` 时触发）
- **无副作用**：不修改入参，返回新对象
- **零 UI 侵入**：Dashboard.vue、Session Store、Workspace Store 完全无感知
- **不破坏样式**：所有脏活收敛在数据解析层，UI 组件保持纯净

---

## 七、实施 checklist

- [ ] 在 `rpc-client.ts` 中新增 `rebuildFromPrecomputed()` 私有方法
- [ ] 在 `normalizeSessionsUsageResult()` 返回前调用该方法
- [ ] 确保 `totals` 从 `byAgent` 反算（字段对齐 `SessionsUsageTotals`）
- [ ] 确保 `daily` 从 `modelDaily` 反算（字段对齐 `SessionsUsageDailyItem`）
- [ ] 确保 `byModel` / `byProvider` 从 `modelDaily` 反算
- [ ] 确保 `messages` / `tools` 从 `modelDaily` 反算
- [ ] 验证 Dashboard  totals、segments、trend、kpi 全部恢复
- [ ] 验证 Session Store 的 usage 懒加载正常
- [ ] 不修改 OpenClaw 目录下的任何文件
- [ ] 不在 UI 组件内写 `if (data.totals === 0)` 补丁
