# 技能商店模块完整技术文档

> 本文档用于 Agent 完整复现技能商店（Skill Store）和数字员工技能管理模块。

---

## 目录

1. [架构总览](#1-架构总览)
2. [数据库 Schema](#2-数据库-schema)
3. [后端 API 端点](#3-后端-api-端点)
4. [SSH 工具函数](#4-ssh-工具函数)
5. [前端类型定义](#5-前端类型定义)
6. [前端 Store（Pinia）](#6-前端-store-pinia)
7. [技能商店页面（SkillStorePage.vue）](#7-技能商店页面-skillstorepagevue)
8. [数字员工编辑页技能 Tab（AgentEditPage.vue）](#8-数字员工编辑页技能-tab-agenteditpagevue)
9. [路由配置](#9-路由配置)
10. [国际化（i18n）](#10-国际化-i18n)
11. [数据流与关键逻辑](#11-数据流与关键逻辑)
12. [Agent 删除时的关联清理](#12-agent-删除时的关联清理)

---

## 1. 架构总览

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (Vue 3)                     │
│                                                             │
│  ┌──────────────────┐    ┌───────────────────────────────┐  │
│  │ SkillStorePage   │    │ AgentEditPage                 │  │
│  │  ├─ Store Tab     │    │  └─ Skills Tab                │  │
│  │  ├─ Manage Tab    │    │     ├─ installed skills       │  │
│  │  ├─ Detail Modal  │    │     └─ global (built-in)      │  │
│  │  └─ Agent Select  │    └───────────────────────────────┘  │
│  └──────────────────┘                                        │
│           │                                                  │
│  ┌──────────────────┐                                        │
│  │ useSkillStoreStore│ ← Pinia store                        │
│  └──────────────────┘                                        │
└─────────┬───────────────────────────────────────────────────┘
          │ HTTP REST (fetch)
          ▼
┌─────────────────────────────────────────────────────────────┐
│                    Backend (Express.js)                      │
│                                                             │
│  /api/skill-store/*                                         │
│    ├─ GET    /catalog        → getAllSkillsWithAgents()      │
│    ├─ GET    /installed      → getAllSkillsWithAgents()      │
│    ├─ GET    /skills/:id     → single skill                  │
│    ├─ POST   /skills/:id/install  → install to agents        │
│    ├─ PATCH  /skills/:id/toggle   → enable/disable           │
│    ├─ DELETE /skills/:id          → delete skill              │
│    ├─ GET    /agents              → agents with skills        │
│    ├─ POST   /scan                → SSH scan skill-store      │
│    └─ GET    /agent/:agentId/skills → agent's skills          │
│                                                             │
│  SQLite (better-sqlite3)  ←──→  SSH → Gateway Machine       │
│  data/wizard.db                   /home/wattman/skills-store │
└─────────────────────────────────────────────────────────────┘
```

### 技能来源分类（source 字段）

| source 值 | 含义 | 页面展示 |
|-----------|------|---------|
| `store` | 来自 Gateway 机器 `/home/wattman/skills-store` 目录，由扫描创建 | 技能商店主区域 |
| `gateway`（默认） | 其他来源（bundled、managed、安装端点创建等） | 「已全局内置」折叠区 |

---

## 2. 数据库 Schema

文件：`server/database.js`

### skill_store_skill 表

```sql
CREATE TABLE IF NOT EXISTS skill_store_skill (
  id TEXT PRIMARY KEY,                    -- UUID
  name TEXT NOT NULL,                     -- 技能名称
  description TEXT NOT NULL DEFAULT '',   -- 技能描述
  icon TEXT NOT NULL DEFAULT '',          -- emoji 图标
  icon_color TEXT NOT NULL DEFAULT '#6366f1',
  category TEXT NOT NULL DEFAULT 'general',
  usage TEXT NOT NULL DEFAULT '',         -- 使用说明
  version TEXT NOT NULL DEFAULT '1.0.0',
  type TEXT NOT NULL DEFAULT 'builtin',   -- 'builtin' | 'private'
  installed INTEGER NOT NULL DEFAULT 0,   -- 是否已安装
  gateway_name TEXT,                      -- Gateway 上的目录名
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
```

### skill_store_agent_skill 表（关联表）

```sql
CREATE TABLE IF NOT EXISTS skill_store_agent_skill (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL REFERENCES skill_store_skill(id) ON DELETE CASCADE,
  agent_id TEXT NOT NULL,                 -- 对应 user_agents.gateway_agent_id
  enabled INTEGER NOT NULL DEFAULT 1,     -- 1=启用, 0=禁用
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(skill_id, agent_id)             -- 同一技能对同一 agent 只有一条记录
);
```

### 迁移列

```sql
-- 通过 ALTER TABLE 追加的列：
ALTER TABLE skill_store_skill ADD COLUMN readme TEXT DEFAULT '';
ALTER TABLE skill_store_skill ADD COLUMN source TEXT DEFAULT 'gateway';
```

- `readme`：SKILL.md 文件的原始内容
- `source`：`'store'`（来自 skill-store 扫描）或 `'gateway'`（其他来源，默认值）

---

## 3. 后端 API 端点

文件：`server/index.js`

### 3.1 GET /api/skill-store/catalog

获取技能目录（带可选过滤）。

```javascript
app.get('/api/skill-store/catalog', authMiddleware, (req, res) => {
  let skills = getAllSkillsWithAgents()
  const { category, search } = req.query
  if (category) skills = skills.filter(s => s.category === category)
  if (search) {
    const q = search.toLowerCase()
    skills = skills.filter(s =>
      s.name.toLowerCase().includes(q) ||
      (s.description || '').toLowerCase().includes(q)
    )
  }
  res.json({ ok: true, skills })
})
```

### 3.2 GET /api/skill-store/installed

获取所有技能及其 agent 关联（同 `getAllSkillsWithAgents()`）。

```javascript
app.get('/api/skill-store/installed', authMiddleware, (req, res) => {
  const all = getAllSkillsWithAgents()
  res.json({ ok: true, skills: all })
})
```

### 3.3 GET /api/skill-store/skills/:id

获取单个技能详情。

### 3.4 POST /api/skill-store/skills/:id/install

安装技能到指定 agent。

**逻辑流程：**
1. 查找技能记录。如果 `id` 以 `gw-` 开头且数据库无记录，自动创建一条（`source` 默认 `'gateway'`）
2. 对每个 `agentId`：
   - 在 `skill_store_agent_skill` 中插入关联记录（`enabled=1`）
   - SSH 复制技能目录到 agent workspace
3. 更新 `skill_store_skill.installed = 1`

```javascript
// 安装时自动创建记录（source 默认 'gateway'，不会出现在商店主区域）
db.prepare(
  `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
).run(newId, gwName, '', iconPool[idx], colorPool[idx], 'general', '', '1.0.0', 'builtin', gwName)
```

### 3.5 PATCH /api/skill-store/skills/:id/toggle

启用/禁用技能对某个 agent 的关联。

**逻辑流程：**
1. 更新 `skill_store_agent_skill.enabled`
2. 如果启用 → SSH 复制技能目录到 agent workspace
3. 如果禁用 → SSH 删除 agent workspace 下的技能目录

```javascript
db.prepare('UPDATE skill_store_agent_skill SET enabled = ? WHERE skill_id = ? AND agent_id = ?')
  .run(enabled ? 1 : 0, req.params.id, agentId)

if (enabled) await sshCopySkillToAgent(gatewayName, agentId)
else await sshRemoveSkillFromAgent(gatewayName, agentId)
```

### 3.6 DELETE /api/skill-store/skills/:id

删除技能。

**逻辑流程：**
1. SSH 删除所有关联 agent workspace 下的技能目录
2. 删除 `skill_store_agent_skill` 关联记录
3. 删除 `skill_store_skill` 记录

### 3.7 GET /api/skill-store/agents

获取所有 agent 及其已安装的技能列表。

```javascript
// 查询关联表，JOIN user_agents 获取 agent 名称
const skillRows = db.prepare(
  `SELECT sas.agent_id, ss.id AS skill_id, ss.name AS skill_name, ...
   FROM skill_store_agent_skill sas
   JOIN skill_store_skill ss ON sas.skill_id = ss.id
   WHERE sas.agent_id IN (...)`
).all(...agentIds)
```

### 3.8 POST /api/skill-store/scan

**核心端点：扫描 Gateway 机器的 `/home/wattman/skills-store` 目录。**

**完整逻辑流程：**

```
1. SSH 执行 find 命令，列出 skill-store 下所有子目录名
2. 清理：删除 source='store' 但不在目录列表中的记录（含关联）
3. 遍历每个目录：
   a. SSH 读取 SKILL.md（优先大写）或 skill.md
   b. 解析 YAML frontmatter 提取 description
   c. 如无 YAML，解析 `- **Description**: xxx` 格式
   d. INSERT 或 UPDATE 记录，设置 source='store'
```

**关键代码：**

```javascript
// 步骤1：列出目录
const output = await sshExec(
  `find "${skillsPath}" -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' 2>/dev/null`
)
const dirNames = output.trim().split('\n').filter(Boolean)

// 步骤2：清理不在目录中的旧 store 记录
db.prepare(`DELETE FROM skill_store_agent_skill WHERE skill_id IN (
  SELECT id FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})
)`).run(...dirNames)
db.prepare(`DELETE FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})`)
  .run(...dirNames)

// 步骤3：遍历目录，创建/更新记录
for (const gwName of dirNames) {
  // 读取 SKILL.md
  let readme = await sshExec(
    `cat "${skillsPath}/${gwName}/SKILL.md" 2>/dev/null || cat "${skillsPath}/${gwName}/skill.md" 2>/dev/null`
  )

  // 解析 description（两种格式）
  let description = ''
  const fmMatch = readme.match(/^---\s*\n([\s\S]*?)\n---/)
  if (fmMatch) {
    const descMatch = fmMatch[1].match(/^description:\s*(.+)$/m)
    if (descMatch) description = descMatch[1].trim()
  }
  if (!description) {
    const bulletMatch = readme.match(/[-*]\s*\*\*[Dd]escription\*\*:\s*(.+)/)
    if (bulletMatch) description = bulletMatch[1].trim()
  }

  // INSERT 或 UPDATE，source='store'
  const existing = db.prepare('SELECT id FROM skill_store_skill WHERE gateway_name = ?').get(gwName)
  if (existing) {
    db.prepare(`UPDATE skill_store_skill SET description=?, readme=?, source='store', updated_at=datetime('now') WHERE gateway_name=?`)
      .run(description, readme, gwName)
  } else {
    db.prepare(`INSERT INTO skill_store_skill (..., source) VALUES (..., 'store')`)
      .run(...)
  }
}
```

**SKILL.md description 解析支持两种格式：**

格式 1 — YAML frontmatter：
```yaml
---
name: my-skill
description: 技能描述内容
---
```

格式 2 — Identity 节点：
```markdown
## Identity
- **Description**: 技能描述内容
```

### 3.9 GET /api/skill-store/agent/:agentId/skills

获取某个 agent 的所有技能（已安装 + 全局）。

### 3.10 内部函数：getAllSkillsWithAgents()

所有查询端点的底层函数。

```javascript
function getAllSkillsWithAgents() {
  const skills = db.prepare('SELECT * FROM skill_store_skill ORDER BY created_at DESC').all()
  const agentRows = db.prepare(
    `SELECT sas.skill_id, sas.agent_id, sas.enabled, ua.name AS agent_name, ua.avatar AS agent_avatar
     FROM skill_store_agent_skill sas
     LEFT JOIN user_agents ua ON sas.agent_id = ua.gateway_agent_id
     WHERE sas.skill_id IN (...)`
  ).all(...skillIds)

  // 按 skill_id 分组 agent 关联
  const agentMap = {}
  for (const row of agentRows) {
    if (!agentMap[row.skill_id]) agentMap[row.skill_id] = []
    agentMap[row.skill_id].push({
      agent_id: row.agent_id,
      agent_name: row.agent_name,
      agent_avatar: row.agent_avatar,
      enabled: Boolean(row.enabled),
    })
  }

  return skills.map(skill => ({
    ...skill,
    installed: Boolean(skill.installed),
    agents: agentMap[skill.id] || [],
  }))
}
```

---

## 4. SSH 工具函数

文件：`server/index.js`

### sshExec(cmd)

通过 SSH 在 Gateway 机器上执行命令，返回 stdout。

```javascript
async function sshExec(cmd) {
  return new Promise((resolve, reject) => {
    const conn = new SSHClient()
    let stdout = ''
    conn.on('ready', () => {
      conn.exec(cmd, (err, stream) => {
        if (err) { conn.end(); return reject(err) }
        stream.on('close', () => { conn.end(); resolve(stdout) })
        stream.on('data', (data) => { stdout += data.toString() })
      })
    })
    conn.on('error', (err) => reject(err))
    conn.connect(SSH_CONFIG)
  })
}
```

### sshCopySkillToAgent(gatewayName, agentId)

复制技能目录到 agent workspace，并自动将 `skill.md` 重命名为 `SKILL.md`。

```javascript
async function sshCopySkillToAgent(gatewayName, agentId) {
  const workspace = await getAgentWorkspace(agentId)
  if (!workspace) throw new Error(`无法获取 Agent ${agentId} 的 workspace 路径`)
  const srcDir = `${envConfig.GATEWAY_SKILLS_STORE_PATH}/${gatewayName}`
  const destDir = `${workspace}/skills/${gatewayName}`
  await sshExec(`mkdir -p "$(dirname "${destDir}")" && cp -r "${srcDir}" "${destDir}"`)
  // 自动处理大小写：skill.md → SKILL.md
  await sshExec(`if [ -f "${destDir}/skill.md" ] && [ ! -f "${destDir}/SKILL.md" ]; then mv "${destDir}/skill.md" "${destDir}/SKILL.md"; fi`)
}
```

**为什么需要重命名：** OpenClaw Gateway 的 skill loader 和 watcher 都硬编码识别 `SKILL.md`（大写），`skill.md`（小写）会被忽略。

### sshRemoveSkillFromAgent(gatewayName, agentId)

删除 agent workspace 下的技能目录。

```javascript
async function sshRemoveSkillFromAgent(gatewayName, agentId) {
  const workspace = await getAgentWorkspace(agentId)
  if (!workspace) return
  const destDir = `${workspace}/skills/${gatewayName}`
  await sshExec(`rm -rf "${destDir}"`)
}
```

### SSH 配置

```javascript
const SSH_CONFIG = {
  host: process.env.GATEWAY_SSH_HOST || '192.168.10.12',
  port: Number(process.env.GATEWAY_SSH_PORT || '22'),
  username: process.env.GATEWAY_SSH_USER || 'wattman',
  password: process.env.GATEWAY_SSH_PASSWORD || 'wattman2020',
}
```

### Gateway Skills Store 路径

```javascript
// envConfig 中定义
GATEWAY_SKILLS_STORE_PATH: '/home/wattman/skills-store'
```

---

## 5. 前端类型定义

文件：`src/api/types/skill-store.ts`

```typescript
export interface SkillStoreSkill {
  id: string
  name: string
  description: string
  icon: string
  iconColor: string
  category: string
  usage: string
  version: string
  type: string                    // 'builtin' | 'private'
  installed: boolean
  gateway_name?: string
  agents: SkillStoreAgentSkill[]
  created_at: string
  updated_at: string
}

export interface SkillStoreAgentSkill {
  id: string
  skillId: string
  agentId: string
  enabled: boolean
  agent?: {
    id: string
    name: string
    avatar: string
    avatarColor: string
  }
}

export interface SkillStoreAgent {
  id: string
  name: string
  avatar: string
  avatarColor: string
  skills: SkillStoreAgentSkillDetail[]
}

export type SkillStoreCategory = 'all' | 'featured' | 'general' | 'creative'
```

文件：`src/api/types/index.ts` 中的 Gateway Skill 类型

```typescript
export interface Skill {
  name: string
  description?: string
  version?: string
  source: 'bundled' | 'managed' | 'workspace' | 'extra'
  installed: boolean
  eligible?: boolean
  disabled?: boolean
  bundled?: boolean
  skillKey?: string
  hasUpdate?: boolean
}
```

---

## 6. 前端 Store（Pinia）

文件：`src/stores/skill-store.ts`

### State

```typescript
const skills = ref<SkillStoreSkill[]>([])          // 目录技能（GET /catalog）
const installedSkills = ref<SkillStoreSkill[]>([])  // 已安装技能（GET /installed）
const agents = ref<SkillStoreAgent[]>([])           // Agent 列表（GET /agents）
const activeTab = ref<'store' | 'manage'>('store')
const category = ref<SkillStoreCategory>('all')
const search = ref('')
const selectedSkill = ref<SkillStoreSkill | null>(null)
const detailOpen = ref(false)
const agentSelectOpen = ref(false)
const loading = ref(false)
const scanning = ref(false)
```

### 关键方法

```typescript
// API 调用封装（自动附加 JWT token）
async function apiCall(path: string, options?: RequestInit) {
  const token = useAuthStore().getToken()
  const res = await fetch(`/api/skill-store${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...options?.headers },
  })
  const data = await res.json()
  if (!data.ok) throw new Error(data.error || 'Request failed')
  return data
}

// 扫描并刷新所有数据
async function scanGateway() {
  scanning.value = true
  try {
    await apiCall('/scan', { method: 'POST' })
    await refreshAll()  // fetchSkills + fetchInstalled + fetchAgents
  } finally { scanning.value = false }
}

// 安装技能到 agent
async function installSkill(skillId: string, agentIds: string[]) {
  await apiCall(`/skills/${skillId}/install`, { method: 'POST', body: JSON.stringify({ agentIds }) })
  await Promise.all([fetchSkills(), fetchInstalled(), fetchAgents()])
}

// 启用/禁用技能
async function toggleSkill(skillId: string, agentId: string, enabled: boolean) {
  await apiCall(`/skills/${skillId}/toggle`, { method: 'PATCH', body: JSON.stringify({ agentId, enabled }) })
  await refreshAll()
}

// 刷新全部
async function refreshAll() {
  await Promise.all([fetchSkills(), fetchInstalled(), fetchAgents()])
}
```

---

## 7. 技能商店页面（SkillStorePage.vue）

文件：`src/views/skill-store/SkillStorePage.vue`

### 7.1 数据加载（onMounted）

```typescript
onMounted(async () => {
  // 1. 从 Gateway RPC 获取所有网关技能（bundled/managed/workspace/extra）
  gatewaySkills.value = await wsStore.rpc.listSkills()
  // 2. 从后端数据库获取目录和关联数据
  await store.refreshAll()
  // 3. 后台扫描 skill-store 目录，同步最新数据
  store.scanGateway()
})
```

### 7.2 技能分类计算（allSkills）

**核心逻辑：区分「技能商店技能」和「全局内置技能」。**

```typescript
const allSkills = computed(() => {
  const dbSkills = store.skills              // 从 GET /catalog 获取
  const gwMap = new Map(gatewaySkills.value.map(s => [s.name, s]))

  // 数据库中的技能 → source === 'store' 的为主区域，其余为全局
  const normalizedDb = dbSkills.map((s: any) => ({
    id: s.id,
    name: s.name,
    description: s.description || gwMap.get(s.gateway_name)?.description || '',
    // ... 其他字段
    isGlobal: s.source !== 'store',  // 关键：source 决定展示区域
  }))

  // 网关中存在但数据库中没有的技能 → 全局内置
  const dbNames = new Set(dbSkills.map((s: any) => s.name))
  const dbGatewayNames = new Set(dbSkills.filter((s: any) => s.gateway_name).map((s: any) => s.gateway_name))
  const gwExtra = gatewaySkills.value
    .filter(s => !dbNames.has(s.name) && !dbGatewayNames.has(s.name))
    .map(s => ({
      id: `gw-${s.name}`,
      name: s.name,
      // ... 其他字段
      isGlobal: true,
    }))

  return [...normalizedDb, ...gwExtra]
})
```

### 7.3 展示过滤

```typescript
// 商店主区域：只显示 source === 'store' 的技能
const storeDisplaySkills = computed(() => {
  let list = allSkills.value.filter(s => !s.isGlobal)
  if (store.category && store.category !== 'all') list = list.filter(s => s.category === store.category)
  if (store.search) {
    const q = store.search.toLowerCase()
    list = list.filter(s => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q))
  }
  return list
})

// 全局内置区：显示其余所有技能
const globalDisplaySkills = computed(() => {
  let list = allSkills.value.filter(s => s.isGlobal)
  if (store.search) {
    const q = store.search.toLowerCase()
    list = list.filter(s => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q))
  }
  return list
})

const globalSkillsExpanded = ref(true)  // 默认展开
```

### 7.4 模板结构（Store Tab）

```html
<div v-if="store.activeTab === 'store'" class="store-tab">
  <!-- 分类栏 + 搜索框 + 扫描按钮 -->

  <!-- 主区域：技能商店技能 -->
  <div class="skill-grid">
    <div v-for="skill in storeDisplaySkills" @click="openDetail(skill)">...</div>
  </div>

  <!-- 折叠区：已全局内置 -->
  <div v-if="globalDisplaySkills.length > 0" class="global-section">
    <div class="global-header" @click="globalSkillsExpanded = !globalSkillsExpanded">
      <span>已全局内置</span>
      <span class="global-count">{{ globalDisplaySkills.length }}</span>
    </div>
    <div v-if="globalSkillsExpanded" class="skill-grid global-grid">
      <div v-for="skill in globalDisplaySkills" @click="openDetail(skill)">...</div>
    </div>
  </div>

  <!-- 空状态 -->
</div>
```

### 7.5 详情弹窗

- **技能商店技能**（`!isGlobal`）：显示「删除」和「添加到智能体」按钮
- **全局内置技能**（`isGlobal`）：只显示「已全局内置」标签，隐藏操作按钮

```html
<NButton v-if="!store.selectedSkill.isGlobal" type="error" @click="handleDelete">删除</NButton>
<NButton v-if="!store.selectedSkill.isGlobal" type="primary" @click="openAgentSelect">添加到智能体</NButton>
<NTag v-if="store.selectedSkill.isGlobal">已全局内置</NTag>
```

### 7.6 Agent 选择弹窗

```typescript
// 已安装的 agent ID 列表（只包含 enabled=true 的）
const installedAgentIds = computed(() => {
  if (!store.selectedSkill) return []
  const skill = store.installedSkills.find(s =>
    s.id === store.selectedSkill!.id || s.gateway_name === store.selectedSkill!.gateway_name
  )
  if (!skill) return []
  return skill.agents.filter(a => a.enabled).map(a => a.agentId)
})

// 确认安装
async function confirmInstall() {
  const newAgentIds = selectedAgentIds.value.filter(id => !installedAgentIds.value.includes(id))
  await store.installSkill(store.selectedSkill.id, newAgentIds)
  // 安装后 closeAgentSelect + closeDetail
}
```

**关键：`installedAgentIds` 通过 `id` 或 `gateway_name` 匹配，因为安装后 ID 可能从 `gw-xxx` 变为 UUID。**

### 7.7 技能管理 Tab（Manage）

```typescript
const skillsWithAgents = computed(() =>
  store.installedSkills.filter(s => s.agents && s.agents.some(a => a.enabled))
)
```

表格显示：
- 技能名称 + 图标
- 类型标签（内置/私有）
- 版本
- 使用该技能的 agent 列表（带启用/禁用开关）
- 状态（已启动/已关闭）
- 操作下拉菜单（删除）

---

## 8. 数字员工编辑页技能 Tab（AgentEditPage.vue）

文件：`src/views/agent-team/AgentEditPage.vue`

### 8.1 技能加载

```typescript
async function loadAgentSkills() {
  // 1. 从后端获取技能目录
  const dbSkills = skillStore.skills  // fetchSkills() → GET /catalog
  // 2. 从 Gateway RPC 获取所有网关技能
  const gwList = await wsStore.rpc.listSkills()

  // 3. 确定哪些技能已安装到当前 agent
  const agentAssocSkills = new Set<string>()
  for (const sk of dbSkills) {
    for (const a of sk.agents || []) {
      if (a.agentId === agentId.value) agentAssocSkills.add(sk.name)
    }
  }

  // 4. 构建技能列表
  for (const s of dbSkills) {
    const isAgent = agentAssocSkills.has(s.name)
    result.push({
      id: s.id,
      name: s.name,
      description: s.description || '',
      enabled: isAgent ? (s.agents?.find(a => a.agentId === agentId.value)?.enabled ?? true) : true,
      skillSource: isAgent ? 'agent' : 'global',  // 关键：区分来源
    })
  }

  // 5. 网关中存在但数据库中没有的 → 全局
  for (const s of gwList) {
    if (s.source === 'bundled' || allNames.has(s.name)) continue
    result.push({ ..., skillSource: 'global' })
  }
}
```

### 8.2 展示过滤

```typescript
// 已安装的技能（通过技能商店安装到此 agent 的）
const installedFilteredSkills = computed(() => {
  const list = currentAgentSkills.value.filter(s => s.skillSource === 'agent')
  // 应用搜索过滤
  return list
})

// 全局内置技能
const globalFilteredSkills = computed(() => {
  const list = currentAgentSkills.value.filter(s => s.skillSource !== 'agent')
  // 应用搜索过滤
  return list
})

const globalSkillsExpanded = ref(true)  // 默认展开
```

### 8.3 模板结构

```html
<!-- 已安装技能网格 -->
<div v-if="installedFilteredSkills.length > 0" class="skills-grid">
  <div v-for="skill in installedFilteredSkills" @click="openSkillDetail(skill)">
    <!-- 图标 + 名称 + 状态徽章 + 专属标签 -->
  </div>
</div>

<!-- 全局内置折叠区 -->
<div v-if="globalFilteredSkills.length > 0" class="agent-global-section">
  <div class="agent-global-header" @click="globalSkillsExpanded = !globalSkillsExpanded">
    已全局内置 ({{ globalFilteredSkills.length }})
  </div>
  <div v-if="globalSkillsExpanded" class="skills-grid">
    <div v-for="skill in globalFilteredSkills" @click="openSkillDetail(skill)">
      <!-- 图标 + 名称 + 全局标签 -->
    </div>
  </div>
</div>
```

### 8.4 详情弹窗

```html
<!-- 已安装技能：显示开关 -->
<div v-if="selectedSkill.skillSource === 'agent'" class="skill-detail-toggle">
  <NSwitch :value="selectedSkill.enabled"
    @update:value="(v) => toggleSkillEnabled(selectedSkill, v)" />
</div>

<!-- 全局技能：只显示标签，无开关 -->
<div v-else class="skill-detail-toggle">
  <span>已全局内置</span>
</div>
```

---

## 9. 路由配置

文件：`src/router/routes.ts`

```typescript
{
  path: 'skills',
  name: 'Skills',
  component: () => import('@/views/skills/SkillsPage.vue'),
  meta: { titleKey: 'routes.skills', icon: 'ExtensionPuzzleOutline', requiresAdmin: true },
},
{
  path: 'skill-store',
  name: 'SkillStore',
  component: () => import('@/views/skill-store/SkillStorePage.vue'),
  meta: { titleKey: 'routes.skillStore', icon: 'StorefrontOutline' },
},
```

---

## 10. 国际化（i18n）

### 技能商店（pages.skillStore）

| Key | zh-CN | en-US |
|-----|-------|-------|
| `title` | 技能商店 | Skill Store |
| `tabs.store` | 技能商店 | Skill Store |
| `tabs.manage` | 技能管理 | Skill Management |
| `globalInstall` | 已全局内置 | Built-in |
| `selectAgent.title` | 选择数字员工 | Select Digital Employee |
| `selectAgent.installed` | 已安装 | Installed |
| `manage.statusEnabled` | 已启动 | Enabled |
| `manage.statusDisabled` | 已关闭 | Disabled |
| `toast.scanSuccess` | 已扫描 {count} 个技能 | Scanned {count} skills |

### 数字员工编辑（pages.agentTeam.edit）

| Key | zh-CN | en-US |
|-----|-------|-------|
| `skillSourceGlobal` | 全局 | Global |
| `skillSourceAgent` | 专属 | Assigned |
| `globalInstall` | 已全局内置 | Built-in |

---

## 11. 数据流与关键逻辑

### 11.1 扫描流程

```
用户点击扫描按钮
  → handleScan()
  → store.scanGateway()
  → POST /api/skill-store/scan
  → SSH: find /home/wattman/skills-store -mindepth 1 -maxdepth 1 -type d
  → 清理旧 store 记录（DELETE）
  → 遍历目录：读取 SKILL.md → 解析 description → INSERT/UPDATE source='store'
  → 前端 refreshAll()
  → allSkills 重新计算
  → storeDisplaySkills（source=store）显示在主区域
  → globalDisplaySkills（其他）显示在已全局内置区
```

### 11.2 安装流程

```
用户点击「添加到智能体」
  → openAgentSelect()
  → 用户选择 agent → confirmInstall()
  → store.installSkill(skillId, agentIds)
  → POST /api/skill-store/skills/:id/install
  → INSERT skill_store_agent_skill（enabled=1）
  → SSH: cp -r /home/wattman/skills-store/<name> → <workspace>/skills/<name>
  → SSH: skill.md → SKILL.md（如需要）
  → 前端 refreshAll()
  → installedAgentIds 更新 → agent 显示「已安装」
```

### 11.3 关闭/启用流程

```
用户切换开关
  → toggleSkillEnabled(skill, enabled)
  → store.toggleSkill(skillId, agentId, enabled)
  → PATCH /api/skill-store/skills/:id/toggle
  → UPDATE skill_store_agent_skill SET enabled=0/1
  → enabled=false: SSH rm -rf <workspace>/skills/<name>
  → enabled=true:  SSH cp -r skill-store/<name> → <workspace>/skills/<name>
  → 前端 refreshAll()
```

### 11.4 ID 匹配机制

**问题：** Gateway 技能安装前 ID 为 `gw-<name>`（临时），安装后数据库分配 UUID。

**解决：** `installedAgentIds` 通过 `id` 或 `gateway_name` 双重匹配。

```typescript
const skill = store.installedSkills.find(s =>
  s.id === store.selectedSkill!.id || s.gateway_name === store.selectedSkill!.gateway_name
)
```

### 11.5 source 字段生命周期

| 场景 | source 值 |
|------|----------|
| 扫描创建（skill-store 目录中） | `'store'` |
| 安装端点自动创建（gw-xxx） | `'gateway'`（默认） |
| 扫描时目录已不存在 | DELETE（从数据库移除） |

---

## 12. Agent 删除时的关联清理

文件：`server/user-manager.js`

当数字员工被删除时，必须同步清理 `skill_store_agent_skill` 关联记录。

```javascript
// DELETE /api/user/agents/:id 调用
export function deleteUserAgent(id) {
  const row = db.prepare('SELECT gateway_agent_id FROM user_agents WHERE id = ?').get(id)
  if (row) {
    db.prepare('DELETE FROM skill_store_agent_skill WHERE agent_id = ?').run(row.gateway_agent_id)
  }
  db.prepare('DELETE FROM user_agents WHERE id = ?').run(id)
}

// DELETE /api/agent-team/:id 调用
export function removeAgentForUser(userId, gatewayAgentId) {
  db.prepare('DELETE FROM skill_store_agent_skill WHERE agent_id = ?').run(gatewayAgentId)
  db.prepare('DELETE FROM user_agents WHERE user_id = ? AND gateway_agent_id = ?').run(userId, gatewayAgentId)
  db.prepare('DELETE FROM user_sessions WHERE user_id = ? AND agent_id = ?').run(userId, gatewayAgentId)
}
```

---

## 附录：文件清单

| 文件 | 作用 |
|------|------|
| `server/database.js` | 数据库 Schema + 迁移 |
| `server/index.js` | REST API 端点 + SSH 函数 |
| `server/user-manager.js` | Agent 删除时清理关联 |
| `src/api/types/skill-store.ts` | TypeScript 类型定义 |
| `src/api/types/index.ts` | Gateway Skill 类型 |
| `src/stores/skill-store.ts` | Pinia Store |
| `src/views/skill-store/SkillStorePage.vue` | 技能商店页面 |
| `src/views/agent-team/AgentEditPage.vue` | 数字员工编辑页 |
| `src/i18n/messages/zh-CN.ts` | 中文翻译 |
| `src/i18n/messages/en-US.ts` | 英文翻译 |
| `src/router/routes.ts` | 路由配置 |
