# 数字员工团队 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 WattClaw 中新增"数字员工团队"模块，实现 Agent 创建、编辑和管理功能，UI 参考飞书风格。

**Architecture:** 后端在 `server/database.js` 新增 SQLite 表和 CRUD 函数，在 `server/index.js` 新增 REST API 路由。前端新增 Pinia store、类型定义、路由和 5 个 Vue 组件。数据走本地 REST API，不经 Gateway RPC。

**Tech Stack:** Vue 3 + TypeScript + Naive UI + Pinia（前端），Express + better-sqlite3（后端）

---

## File Structure

| Action | File | Responsibility |
|--------|------|----------------|
| Modify | `server/database.js` | 新增 `agent_team` 建表语句 + CRUD 函数 |
| Modify | `server/index.js` | 新增 5 个 REST API 路由（import + 路由定义） |
| Create | `src/api/types/agent-team.ts` | `AgentTeamMember` 接口定义 |
| Modify | `src/api/types/index.ts` | barrel export 新类型 |
| Create | `src/stores/agent-team.ts` | Pinia store，CRUD 动作 |
| Modify | `src/router/routes.ts` | 新增 `agents-team` 和 `agents-team/:id` 路由 |
| Modify | `src/components/layout/AppSidebar.vue` | 新增 `SmartToyOutline` 图标映射 |
| Modify | `src/i18n/messages/zh-CN.ts` | 中文翻译 |
| Modify | `src/i18n/messages/en-US.ts` | 英文翻译 |
| Create | `src/views/agent-team/AgentTeamPage.vue` | 团队主页 |
| Create | `src/views/agent-team/AgentCard.vue` | Agent 卡片组件 |
| Create | `src/views/agent-team/CreateAgentModal.vue` | 创建弹窗（模板选择 + 自定义） |
| Create | `src/views/agent-team/AgentTemplateGrid.vue` | 预设模板网格 |
| Create | `src/views/agent-team/AgentEditPage.vue` | Agent 编辑页（左右分栏） |

---

### Task 1: Database — 新增 agent_team 表和 CRUD 函数

**Files:**
- Modify: `server/database.js:216`（db.exec 闭合前插入建表）
- Modify: `server/database.js:237`（export default db 前插入 CRUD 函数）

- [ ] **Step 1: 在 `server/database.js` 第二个 db.exec() 块中添加建表语句**

在第216行（最后一个 CREATE INDEX 之后、db.exec() 闭合反引号之前）插入：

```sql

  CREATE TABLE IF NOT EXISTS agent_team (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    avatar TEXT,
    model TEXT,
    status TEXT DEFAULT 'idle',
    soul_md TEXT,
    agents_md TEXT,
    identity_md TEXT,
    user_md TEXT,
    created_by TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_agent_team_created_by ON agent_team(created_by);
```

- [ ] **Step 2: 在 `server/database.js` export default db 之前添加 CRUD 函数**

```javascript
// Agent Team CRUD
export function getAgentTeamList(userId) {
  return db.prepare('SELECT * FROM agent_team WHERE created_by = ? ORDER BY created_at DESC').all(userId)
}

export function getAgentTeamById(id) {
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function createAgentTeam(userId, data) {
  const id = crypto.randomUUID()
  const now = Date.now()
  db.prepare(`
    INSERT INTO agent_team (id, name, description, avatar, model, status, soul_md, agents_md, identity_md, user_md, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, data.name || '', data.description || '', data.avatar || '',
    data.model || '', data.status || 'idle',
    data.soulMd || '', data.agentsMd || '', data.identityMd || '', data.userMd || '',
    userId, now, now
  )
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function updateAgentTeam(id, data) {
  const fields = []
  const values = []
  const columnMap = {
    name: 'name', description: 'description', avatar: 'avatar', model: 'model',
    status: 'status', soulMd: 'soul_md', agentsMd: 'agents_md',
    identityMd: 'identity_md', userMd: 'user_md',
  }
  for (const [key, col] of Object.entries(columnMap)) {
    if (data[key] !== undefined) {
      fields.push(`${col} = ?`)
      values.push(data[key])
    }
  }
  if (fields.length === 0) return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
  fields.push('updated_at = ?')
  values.push(Date.now())
  values.push(id)
  db.prepare(`UPDATE agent_team SET ${fields.join(', ')} WHERE id = ?`).run(...values)
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function deleteAgentTeam(id) {
  db.prepare('DELETE FROM agent_team WHERE id = ?').run(id)
}

export function getAgentTeamStats(userId) {
  const row = db.prepare('SELECT COUNT(*) as count, MIN(created_at) as earliest FROM agent_team WHERE created_by = ?').get(userId)
  return { count: row.count, earliest: row.earliest }
}
```

- [ ] **Step 3: 验证数据库初始化**

Run: `node -e "import('./server/database.js').then(m => { console.log('OK'); const r = m.getAgentTeamList('__test__'); console.log('rows:', r.length); process.exit(0) })"`
Expected: `OK` + `rows: 0`

- [ ] **Step 4: Commit**

```bash
git add server/database.js
git commit -m "feat: add agent_team table and CRUD functions"
```

---

### Task 2: Backend API — 新增 REST 路由

**Files:**
- Modify: `server/index.js:15`（import 行添加新函数）
- Modify: `server/index.js:419` 之后（新增路由块）

- [ ] **Step 1: 更新 import**

将 `server/index.js` 第15行的 import 从：
```javascript
import db, { createBackupRecord, updateBackupRecord, getBackupRecord, getBackupRecords, getBackupRecordsCount, deleteBackupRecord } from './database.js'
```
改为：
```javascript
import db, { createBackupRecord, updateBackupRecord, getBackupRecord, getBackupRecords, getBackupRecordsCount, deleteBackupRecord, getAgentTeamList, getAgentTeamById, createAgentTeam, updateAgentTeam, deleteAgentTeam, getAgentTeamStats } from './database.js'
```

- [ ] **Step 2: 在第419行之后添加路由**

```javascript
// Agent Team routes
app.get('/api/agent-team/list', authMiddleware, (req, res) => {
  const list = getAgentTeamList(req.currentUser.id)
  res.json({ ok: true, list })
})

app.get('/api/agent-team/:id', authMiddleware, (req, res) => {
  const agent = getAgentTeamById(req.params.id)
  if (!agent) return res.status(404).json({ ok: false, error: 'Agent not found' })
  if (agent.created_by !== req.currentUser.id && req.currentUser.role !== 'admin') {
    return res.status(403).json({ ok: false, error: 'Not your agent' })
  }
  res.json({ ok: true, agent })
})

app.post('/api/agent-team/create', authMiddleware, (req, res) => {
  try {
    const agent = createAgentTeam(req.currentUser.id, req.body)
    res.json({ ok: true, agent })
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message })
  }
})

app.put('/api/agent-team/:id', authMiddleware, (req, res) => {
  const existing = getAgentTeamById(req.params.id)
  if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })
  if (existing.created_by !== req.currentUser.id && req.currentUser.role !== 'admin') {
    return res.status(403).json({ ok: false, error: 'Not your agent' })
  }
  const agent = updateAgentTeam(req.params.id, req.body)
  res.json({ ok: true, agent })
})

app.delete('/api/agent-team/:id', authMiddleware, (req, res) => {
  const existing = getAgentTeamById(req.params.id)
  if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })
  if (existing.created_by !== req.currentUser.id && req.currentUser.role !== 'admin') {
    return res.status(403).json({ ok: false, error: 'Not your agent' })
  }
  deleteAgentTeam(req.params.id)
  res.json({ ok: true })
})
```

- [ ] **Step 3: 启动后端验证 API**

启动 server，登录获取 token，然后 `curl /api/agent-team/list` 验证返回 `{ ok: true, list: [] }`。

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: add agent-team REST API routes"
```

---

### Task 3: Frontend Types + Store + 路由 + 侧边栏图标

**Files:**
- Create: `src/api/types/agent-team.ts`
- Modify: `src/api/types/index.ts`
- Create: `src/stores/agent-team.ts`
- Modify: `src/router/routes.ts`
- Modify: `src/components/layout/AppSidebar.vue`

- [ ] **Step 1: 创建 `src/api/types/agent-team.ts`**

```typescript
export interface AgentTeamMember {
  id: string
  name: string
  description: string
  avatar: string
  model: string
  status: 'idle' | 'active'
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  createdBy: string
  createdAt: number
  updatedAt: number
}
```

- [ ] **Step 2: 在 `src/api/types/index.ts` 第8行后添加**

```typescript
export * from './agent-team'
```

- [ ] **Step 3: 创建 `src/stores/agent-team.ts`**

遵循现有 Composition API 模式。Store 包含 `apiCall` 辅助函数（用 `fetch()` + `authStore.getToken()`）和 5 个 CRUD 动作：`fetchAgents`、`fetchAgent`、`createAgent`、`updateAgent`、`deleteAgent`。完整代码见设计文档 Store 部分。

- [ ] **Step 4: 在 `src/router/routes.ts` 的 agents 路由后添加**

```typescript
{
  path: 'agents-team',
  name: 'AgentTeam',
  component: () => import('@/views/agent-team/AgentTeamPage.vue'),
  meta: { titleKey: 'routes.agentTeam', icon: 'SmartToyOutline' },
},
{
  path: 'agents-team/:id',
  name: 'AgentTeamEdit',
  component: () => import('@/views/agent-team/AgentEditPage.vue'),
  meta: { titleKey: 'routes.agentTeamEdit', hidden: true },
},
```

- [ ] **Step 5: 在 `src/components/layout/AppSidebar.vue` materialIconMap 中添加**

```typescript
SmartToyOutline: 'smart_toy',
```

- [ ] **Step 6: Commit**

```bash
git add src/api/types/agent-team.ts src/api/types/index.ts src/stores/agent-team.ts src/router/routes.ts src/components/layout/AppSidebar.vue
git commit -m "feat: add agent-team types, store, routes and sidebar icon"
```

---

### Task 4: i18n 国际化

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: 在两个语言文件的 `routes` 中添加**

zh-CN: `agentTeam: '数字员工'`, `agentTeamEdit: '编辑员工'`
en-US: `agentTeam: 'Digital Staff'`, `agentTeamEdit: 'Edit Staff'`

- [ ] **Step 2: 在两个语言文件的 `pages` 中添加 `agentTeam` 对象**

包含 `title`、`subtitle`、`stats.*`、`actions.*`、`create.*`、`edit.*`、`confirm.*` 所有翻译键。完整内容见设计文档。

- [ ] **Step 3: Commit**

```bash
git add src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: add agent-team i18n translations"
```

---

### Task 5: AgentCard + AgentTemplateGrid 组件

**Files:**
- Create: `src/views/agent-team/AgentCard.vue`
- Create: `src/views/agent-team/AgentTemplateGrid.vue`

- [ ] **Step 1: `mkdir -p src/views/agent-team`**

- [ ] **Step 2: 创建 `AgentCard.vue`**

飞书风格卡片：白色背景、圆角12px、轻阴影。包含头像（圆形带彩色背景）、名称、描述、3 个统计数据、禁用的"去对话"按钮、更多菜单（编辑/删除）。

- [ ] **Step 3: 创建 `AgentTemplateGrid.vue`**

3 列网格，9 个卡片（1 个虚线边框"自定义创建" + 8 个预设角色）。每个模板包含预设的 name、avatar、description、soulMd。选择模板时 emit `selectTemplate` 事件，点自定义时 emit `customCreate`。

- [ ] **Step 4: Commit**

```bash
git add src/views/agent-team/AgentCard.vue src/views/agent-team/AgentTemplateGrid.vue
git commit -m "feat: add AgentCard and AgentTemplateGrid components"
```

---

### Task 6: CreateAgentModal 组件

**Files:**
- Create: `src/views/agent-team/CreateAgentModal.vue`

- [ ] **Step 1: 创建 `CreateAgentModal.vue`**

两层弹窗：默认显示模板选择（3x3 AgentTemplateGrid），点自定义创建后切换到表单（名称输入 + 12 个 Emoji 头像选择 + 描述 textarea + 创建按钮）。创建后 emit `created` 事件并关闭弹窗。

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/CreateAgentModal.vue
git commit -m "feat: add CreateAgentModal component"
```

---

### Task 7: AgentTeamPage 团队主页

**Files:**
- Create: `src/views/agent-team/AgentTeamPage.vue`

- [ ] **Step 1: 创建 `AgentTeamPage.vue`**

顶栏（团队头像 + 标题 + 统计 + 新建按钮）+ 响应式卡片网格（auto-fill, minmax(280px, 1fr)）+ 空状态 + CreateAgentModal 弹窗。使用 `useAgentTeamStore` 获取数据，创建后跳转编辑页，删除有确认弹窗。

- [ ] **Step 2: 启动 dev server 验证页面加载**

- [ ] **Step 3: Commit**

```bash
git add src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: add AgentTeamPage with card grid and create modal"
```

---

### Task 8: AgentEditPage 编辑页

**Files:**
- Create: `src/views/agent-team/AgentEditPage.vue`

- [ ] **Step 1: 创建 `AgentEditPage.vue`**

左右分栏：左侧 280px（头像 + 可编辑名称/描述 + 状态 + 模型下拉用 `useModelStore` + 统计 + 禁用"去对话"按钮），右侧自适应（4 Tab：行为准则/工作流程/智能体档案/用户档案 + textarea + 保存按钮）。自动保存 500ms 防抖。路由参数 `route.params.id` 加载 Agent。

- [ ] **Step 2: 验证完整流程**

启动服务，完整走通：主页 → 创建 → 编辑 → 保存 → 返回 → 删除。

- [ ] **Step 3: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "feat: add AgentEditPage with tab editor and auto-save"
```

---

### Task 9: 最终验证

- [ ] **Step 1: 类型检查** — `npx vue-tsc --noEmit`
- [ ] **Step 2: 构建** — `npm run build`
- [ ] **Step 3: 启动服务** — `./restart.sh`
- [ ] **Step 4: 完整功能验证清单**
  - 侧边栏"数字员工"菜单（smart_toy 图标）
  - 团队主页空状态 → 创建预设模板 → 编辑页
  - 创建自定义 Agent → 编辑页
  - 编辑页 4 Tab 编辑 + 自动保存
  - 返回主页，卡片显示统计
  - 删除 Agent → 确认弹窗 → 删除成功
  - "去对话"按钮灰色禁用
- [ ] **Step 5: Final commit**
