# 数字员工 v2 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 重构数字员工模块，从本地 SQLite 存储改为纯 Gateway 驱动，新增 12+ 分类 30+ 模板，所有 md 内容从 Gateway agent workspace 读写。

**Architecture:** 废弃 `agent_team` 表，复用 `user_agents` 表记录用户-agent 关联。前端通过 RPC 直接读写 Gateway agent workspace 的 md 文件。模板数据作为前端静态配置。后端 `agent-team` API 路由改为操作 `user_agents` 表。

**Tech Stack:** Vue 3 + TypeScript + Pinia + Naive UI (前端), Express + better-sqlite3 (后端), OpenClaw Gateway RPC (agent 管理)

---

### Task 1: 数据库迁移 — user_agents 表新增字段

**Files:**
- Modify: `server/database.js:165-178`

- [ ] **Step 1: 在 user_agents CREATE TABLE 语句中新增 4 个字段**

在 `server/database.js` 的 `user_agents` 表 CREATE TABLE 语句中，在 `model TEXT` 行后面、`status TEXT` 行前面，新增：

```sql
category TEXT,
template_id TEXT,
```

同时把现有的 `description TEXT` 保留（已存在）。确认 `avatar` 字段不存在于现有 schema 中，需要新增。

最终的 user_agents 表 schema 应为：

```sql
CREATE TABLE IF NOT EXISTS user_agents (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  gateway_agent_id TEXT,
  name TEXT NOT NULL,
  description TEXT,
  config TEXT DEFAULT '{}',
  system_prompt TEXT,
  model TEXT,
  category TEXT,
  template_id TEXT,
  avatar TEXT,
  status TEXT DEFAULT 'active',
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

- [ ] **Step 2: 重启后端验证表结构**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npm run dev:server`

验证日志输出 `[Database] Initialized` 无报错。

- [ ] **Step 3: Commit**

```bash
git add server/database.js
git commit -m "feat: add category, template_id, avatar columns to user_agents table"
```

---

### Task 2: 后端 — 改造 agent-team API 路由为 user_agents 操作

**Files:**
- Modify: `server/user-manager.js:302-331`
- Modify: `server/index.js:474-523`

- [ ] **Step 1: 扩展 trackAgentForUser 函数支持新字段**

在 `server/user-manager.js` 中，修改 `trackAgentForUser` 函数，接受额外的 `meta` 参数：

```javascript
export function trackAgentForUser(userId, gatewayAgentId, name, meta) {
  const existing = db.prepare('SELECT id FROM user_agents WHERE user_id = ? AND gateway_agent_id = ?').get(userId, gatewayAgentId)
  if (!existing) {
    db.prepare(`
      INSERT INTO user_agents (id, user_id, gateway_agent_id, name, config, status, category, template_id, description, avatar)
      VALUES (?, ?, ?, ?, '{}', 'active', ?, ?, ?, ?)
    `).run(
      randomUUID(), userId, gatewayAgentId, name || gatewayAgentId,
      meta?.category || null, meta?.templateId || null,
      meta?.description || null, meta?.avatar || null
    )
  }
}
```

同时新增 `updateUserAgentMeta` 函数，用于更新元数据：

```javascript
export function updateUserAgentMeta(gatewayAgentId, data) {
  const fields = []
  const values = []
  const columnMap = {
    name: 'name', description: 'description', avatar: 'avatar',
    model: 'model', category: 'category', templateId: 'template_id',
  }
  for (const [key, col] of Object.entries(columnMap)) {
    if (data[key] !== undefined) {
      fields.push(`${col} = ?`)
      values.push(data[key])
    }
  }
  if (fields.length === 0) return
  fields.push('updated_at = ?')
  values.push(Date.now())
  values.push(gatewayAgentId)
  db.prepare(`UPDATE user_agents SET ${fields.join(', ')} WHERE gateway_agent_id = ?`).run(...values)
}
```

新增 `getDigitalEmployees` 函数，查询用户的数字员工列表：

```javascript
export function getDigitalEmployees(userId) {
  return db.prepare(
    'SELECT gateway_agent_id, name, description, avatar, model, category, template_id, status, created_at, updated_at FROM user_agents WHERE user_id = ? AND status = \'active\' AND category IS NOT NULL ORDER BY created_at DESC'
  ).all(userId)
}

export function getDigitalEmployeeByAgentId(agentId, userId) {
  return db.prepare(
    'SELECT * FROM user_agents WHERE gateway_agent_id = ? AND user_id = ? AND status = \'active\''
  ).get(agentId, userId)
}
```

确保这些新函数在文件底部的 export 列表中导出。

- [ ] **Step 2: 在 server/index.js 中导入新函数**

在 `server/index.js` 顶部 import 块中（第 16-27 行），将 `getDigitalEmployees, getDigitalEmployeeByAgentId, updateUserAgentMeta` 加入从 `./user-manager.js` 的导入。

- [ ] **Step 3: 改造 agent-team 后端路由**

替换 `server/index.js` 第 474-523 行的 agent-team 路由：

```javascript
// Digital Employee (Agent Team) routes — backed by user_agents table
app.get('/api/agent-team/list', authMiddleware, (req, res) => {
  const list = getDigitalEmployees(req.currentUser.id)
  res.json({ ok: true, list })
})

app.get('/api/agent-team/:id', authMiddleware, (req, res) => {
  const agent = getDigitalEmployeeByAgentId(req.params.id, req.currentUser.id)
  if (!agent) return res.status(404).json({ ok: false, error: 'Agent not found' })
  res.json({ ok: true, agent })
})

app.put('/api/agent-team/:id', authMiddleware, (req, res) => {
  const existing = getDigitalEmployeeByAgentId(req.params.id, req.currentUser.id)
  if (!existing && req.currentUser.role !== 'admin') {
    return res.status(403).json({ ok: false, error: 'Not your agent' })
  }
  if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })
  updateUserAgentMeta(req.params.id, req.body)
  const updated = getDigitalEmployeeByAgentId(req.params.id, req.currentUser.id)
  res.json({ ok: true, agent: updated })
})

app.post('/api/agent-team/create', authMiddleware, (req, res) => {
  const { name, description, avatar, model, category, templateId, gatewayAgentId } = req.body || {}
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ ok: false, error: 'Name is required' })
  }
  if (!gatewayAgentId) {
    return res.status(400).json({ ok: false, error: 'gatewayAgentId is required' })
  }
  trackAgentForUser(req.currentUser.id, gatewayAgentId, name, {
    category, templateId, description, avatar,
  })
  const agent = getDigitalEmployeeByAgentId(gatewayAgentId, req.currentUser.id)
  res.json({ ok: true, agent })
})

app.delete('/api/agent-team/:id', authMiddleware, (req, res) => {
  const existing = getDigitalEmployeeByAgentId(req.params.id, req.currentUser.id)
  if (!existing && req.currentUser.role !== 'admin') {
    return res.status(403).json({ ok: false, error: 'Not your agent' })
  }
  if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })
  removeAgentForUser(req.currentUser.id, req.params.id)
  res.json({ ok: true })
})
```

注意：`create` 路由现在需要 `gatewayAgentId`（由前端在 RPC `agents.create` 后获得），不再自己生成 ID。`delete` 路由使用已有的 `removeAgentForUser` 函数。

- [ ] **Step 4: 重启后端验证 API**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npm run dev:server`

验证无启动报错。

- [ ] **Step 5: Commit**

```bash
git add server/user-manager.js server/index.js
git commit -m "refactor: agent-team routes to use user_agents table with Gateway integration"
```

---

### Task 3: 前端类型定义更新

**Files:**
- Modify: `src/api/types/agent-team.ts`

- [ ] **Step 1: 更新类型定义**

替换 `src/api/types/agent-team.ts` 的全部内容：

```typescript
export interface AgentTemplate {
  id: string
  category: string
  name: string
  avatar: string
  description: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
}

export interface AgentCategory {
  id: string
  name: string
  icon: string
  templates: AgentTemplate[]
}

export interface AgentTeamMember {
  id: string                    // gateway_agent_id
  name: string
  description: string
  avatar: string
  model: string
  category: string
  templateId: string
  status: string
  createdBy: string
  createdAt: number
  updatedAt: number
}
```

注意：`AgentTeamMember` 移除了 `soulMd/agentsMd/identityMd/userMd` 字段（md 内容从 Gateway RPC 读取，不再存本地）。

- [ ] **Step 2: Commit**

```bash
git add src/api/types/agent-team.ts
git commit -m "refactor: update agent-team types for Gateway-driven architecture"
```

---

### Task 4: 前端 — 模板数据配置（30+ 模板，12 分类）

**Files:**
- Create: `src/config/agent-templates.ts`

- [ ] **Step 1: 创建模板配置文件**

创建 `src/config/agent-templates.ts`，包含 12 个分类、30+ 个模板的完整定义。每个模板包含四个 md 的完整内容。

文件结构：

```typescript
import type { AgentCategory, AgentTemplate } from '@/api/types'

const categories: AgentCategory[] = [
  {
    id: 'coding',
    name: '编程开发',
    icon: '💻',
    templates: [
      {
        id: 'code-assistant',
        category: '编程开发',
        name: '代码助手',
        avatar: '🤖',
        description: '全栈编程助手，擅长代码编写、Bug 修复、架构设计',
        soulMd: `你是一个资深全栈工程师级别的编程助手。擅长 Go、TypeScript、Python、Java 等主流语言，熟悉 Vue、React、Next.js 等前端框架，以及 Spring Boot、Express、go-zero 等后端框架。

核心能力：代码编写与重构、Bug 定位与修复、架构设计、性能优化、代码审查、单元测试编写。

行为准则：
- 始终优先考虑代码安全性和可维护性
- 给出方案时说明 trade-off
- 遵循项目现有的代码风格和架构模式
- 不确定时主动说明而非猜测`,
        agentsMd: `你可以使用以下工具完成工作：
- Shell: 执行构建、测试、部署命令
- 文件系统: 读取和修改代码文件
- 数据库: 查询和调试数据库
- Git: 版本管理和代码提交

协作流程：
1. 理解需求 → 2. 定位相关代码 → 3. 编写/修改 → 4. 测试验证`,
        identityMd: `名称: 代码助手
语气: 专业、简洁、务实
回复风格: 先给结论和核心代码，再解释原理。代码附带必要注释。
不使用emoji，保持工程师风格。`,
        userMd: `技术栈: 以 Go + Vue 3 + TypeScript 为主
后端框架: go-zero / Express
前端框架: Vue 3 + Naive UI + Pinia
数据库: MySQL / SQLite
部署方式: Docker Compose + Kubernetes
代码规范: 遵循项目 CLAUDE.md 中的规范
偏好: 最小化改动，优先修改现有代码`,
      },
      {
        id: 'sql-expert',
        category: '编程开发',
        name: 'SQL 专家',
        avatar: '🗃️',
        description: '数据库专家，擅长 SQL 优化、数据建模和查询分析',
        soulMd: `你是一个资深的数据库和 SQL 专家。精通 MySQL、PostgreSQL、SQLite、ClickHouse 等主流数据库，擅长复杂查询优化、索引设计、数据建模。

核心能力：SQL 编写与优化、数据库架构设计、索引策略、慢查询分析、数据迁移方案。

行为准则：
- 优先考虑查询性能和数据安全
- 提供 EXPLAIN 分析支持优化建议
- 遵循数据库设计范式，适度反范式
- SQL 注入防护，所有用户输入参数化处理`,
        agentsMd: `你可以使用以下工具完成工作：
- 数据库: 执行 SQL 查询、分析执行计划
- Shell: 运行数据库管理命令
- 文件系统: 读写 SQL 脚本和迁移文件

协作流程：
1. 理解数据需求 → 2. 分析现有表结构 → 3. 设计/优化 SQL → 4. 验证执行计划`,
        identityMd: `名称: SQL 专家
语气: 严谨、数据驱动
回复风格: 给出 SQL 语句时附带注释说明，提供 EXPLAIN 分析。
注重性能指标。`,
        userMd: `常用数据库: MySQL 8.0 / PostgreSQL 15
数据规模: 百万级到千万级数据表
关注点: 查询性能优化、索引设计
偏好: 优先使用标准 SQL，数据库方言需标注`,
      },
      {
        id: 'code-reviewer',
        category: '编程开发',
        name: '代码审查员',
        avatar: '🔍',
        description: '专注于代码质量审查，发现潜在问题和改进点',
        soulMd: `你是一个专业的代码审查员。擅长发现代码中的 Bug、安全漏洞、性能问题和设计缺陷。

核心能力：代码质量评估、安全漏洞检测、性能瓶颈定位、设计模式建议、最佳实践推广。

行为准则：
- 以建设性态度提出改进建议
- 区分严重问题和风格偏好
- 给出具体修改方案而非笼统建议
- 关注可维护性和可读性`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取代码文件
- Shell: 运行静态分析工具和测试
- Git: 查看代码变更历史

协作流程：
1. 读取目标代码 → 2. 分析代码结构 → 3. 识别问题 → 4. 给出改进建议`,
        identityMd: `名称: 代码审查员
语气: 建设性、专业
回复风格: 按严重程度分级（Critical/Warning/Suggestion），每个问题附带具体修改建议。`,
        userMd: `审查重点: 安全性、性能、可维护性
代码风格: 遵循项目 CLAUDE.md
关注语言: Go / TypeScript / Python`,
      },
    ],
  },
  {
    id: 'content',
    name: '内容创作',
    icon: '✍️',
    templates: [
      {
        id: 'copywriter',
        category: '内容创作',
        name: '文案撰写',
        avatar: '✍️',
        description: '专业文案撰写，擅长营销文案、产品描述、品牌故事',
        soulMd: `你是一个资深文案撰写专家。擅长营销文案、产品描述、品牌故事、广告创意等多种文案类型。

核心能力：文案创意策划、品牌调性把控、多平台内容适配、A/B 文案测试建议。

行为准则：
- 内容原创，拒绝抄袭和搬运
- 深入理解品牌调性和目标受众
- 文案需要有吸引力和转化力
- 遵守广告法规，不使用虚假宣传`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取品牌资料、历史文案
- Shell: 搜索关键词数据

协作流程：
1. 了解品牌和目标 → 2. 研究目标受众 → 3. 创意构思 → 4. 撰写优化`,
        identityMd: `名称: 文案撰写
语气: 有创意、有感染力
回复风格: 先给出核心创意概念，再展开完整文案。附带不同版本供选择。`,
        userMd: `目标平台: 微信公众号、抖音、小红书
品牌调性: 专业但不失亲和
目标受众: 25-40 岁职场人群
偏好: 短平快风格，注重开头吸引力`,
      },
      {
        id: 'social-media',
        category: '内容创作',
        name: '社媒运营',
        avatar: '📱',
        description: '社交媒体运营专家，擅长内容策划和粉丝互动',
        soulMd: `你是一个社交媒体运营专家。熟悉微信、抖音、小红书、微博等主流平台的运营策略和算法逻辑。

核心能力：内容策划、发布排期、互动策略、数据分析和优化、热点追踪。

行为准则：
- 内容原创优质，拒绝低质搬运
- 深入理解各平台调性和算法偏好
- 用数据验证内容策略效果
- 营销内容需明确标注`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取运营数据和历史内容
- Shell: 数据抓取和分析

协作流程：
1. 分析账号数据 → 2. 制定内容策略 → 3. 策划具体内容 → 4. 评估发布效果`,
        identityMd: `名称: 社媒运营
语气: 活泼、有网感
回复风格: 结合数据给建议，附带内容模板和排期建议。`,
        userMd: `运营平台: 抖音、小红书、微信公众号
账号定位: 科技/商业类
粉丝画像: 25-35 岁互联网从业者
发布频率: 日更 1-2 条`,
      },
      {
        id: 'translator',
        category: '内容创作',
        name: '翻译官',
        avatar: '🌐',
        description: '专业多语言翻译，支持中英日韩等语言互译',
        soulMd: `你是一个专业的多语言翻译专家。精通中文、英文、日文、韩文等语言，擅长技术文档、商务文件、文学内容的翻译。

核心能力：多语言精准翻译、本地化适配、术语一致性维护、文化差异处理。

行为准则：
- 翻译准确，忠于原文含义
- 注重本地化和文化适配
- 专业术语保持一致性
- 标注不确定的翻译`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取待翻译文档
- Shell: 使用翻译辅助工具

协作流程：
1. 读取原文 → 2. 识别语言和领域 → 3. 翻译 → 4. 校对润色`,
        identityMd: `名称: 翻译官
语气: 准确、专业
回复风格: 给出翻译结果，附带关键术语对照表。不确定处标注说明。`,
        userMd: `主要翻译方向: 英中互译
擅长领域: 技术文档、商业文件
术语风格: 保留英文专业术语，附中文注释
偏好: 信达雅，不机翻感`,
      },
    ],
  },
  {
    id: 'office',
    name: '办公效率',
    icon: '📋',
    templates: [
      {
        id: 'meeting-notes',
        category: '办公效率',
        name: '会议纪要',
        avatar: '📝',
        description: '快速整理会议纪要，提取关键决策和待办事项',
        soulMd: `你是一个高效的会议纪要助手。擅长从会议内容中提取关键信息、决策要点和行动项。

核心能力：会议内容整理、关键决策提取、行动项追踪、会议摘要生成。

行为准则：
- 忠实记录会议内容，不添加个人观点
- 明确区分事实陈述和讨论观点
- 行动项指定负责人和截止时间
- 保护会议中的敏感信息`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取会议录音转写文本
- Shell: 格式转换和文档生成

协作流程：
1. 获取会议内容 → 2. 识别议题和讨论 → 3. 提取关键要点 → 4. 生成结构化纪要`,
        identityMd: `名称: 会议纪要
语气: 简洁、客观
回复风格: 结构化输出，按议题分组，每项标注发言人。行动项高亮。`,
        userMd: `会议语言: 中文为主，偶有英文
纪要格式: 按议题分组，含决策和行动项
分发性: 需适合邮件和文档分享
偏好: 简洁高效，突出行动项`,
      },
      {
        id: 'ppt-assistant',
        category: '办公效率',
        name: 'PPT 助手',
        avatar: '📊',
        description: '辅助制作演示文稿，提供内容大纲和设计建议',
        soulMd: `你是一个专业的演示文稿助手。擅长内容策划、结构设计、演讲稿撰写。

核心能力：演示内容策划、逻辑结构设计、视觉呈现建议、演讲稿撰写。

行为准则：
- 内容简洁，一页一核心观点
- 逻辑清晰，有起承转合
- 视觉建议注重可读性
- 适配不同演示场景（汇报、培训、路演）`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取参考资料和数据
- Shell: 生成演示文件

协作流程：
1. 了解演示目的 → 2. 规划内容结构 → 3. 撰写每页内容 → 4. 添加演讲备注`,
        identityMd: `名称: PPT 助手
语气: 专业、有条理
回复风格: 先给大纲结构，再逐页展开内容。附带设计建议。`,
        userMd: `常用场景: 工作汇报、项目路演
风格偏好: 简约商务风
配色: 蓝色系为主
篇幅: 10-15 页为主`,
      },
      {
        id: 'email-assistant',
        category: '办公效率',
        name: '邮件助手',
        avatar: '📧',
        description: '撰写和优化商务邮件，支持多语言多场景',
        soulMd: `你是一个专业的商务邮件助手。擅长撰写各类商务邮件，包括沟通协调、汇报、邀请、感谢等场景。

核心能力：邮件撰写和润色、语气把控、多语言支持、邮件模板管理。

行为准则：
- 邮件简洁明确，重点突出
- 语气与收件人关系匹配
- 注意邮件礼仪和文化差异
- 敏感内容谨慎措辞`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取邮件模板和历史邮件

协作流程：
1. 了解邮件目的和收件人 → 2. 确定语气和格式 → 3. 撰写邮件 → 4. 润色检查`,
        identityMd: `名称: 邮件助手
语气: 礼貌、专业
回复风格: 直接给出完整邮件，附 CC/BCC 建议。如有多个版本供选择。`,
        userMd: `常用语言: 中文和英文
收件人: 内部同事、外部客户
邮件风格: 简洁直接
偏好: 重点前置，结论先行`,
      },
    ],
  },
  {
    id: 'data',
    name: '数据分析',
    icon: '📊',
    templates: [
      {
        id: 'data-analyst',
        category: '数据分析',
        name: '数据分析师',
        avatar: '📈',
        description: '专业数据分析，从数据中提取洞察和决策建议',
        soulMd: `你是一个资深数据分析师。擅长数据清洗、统计分析、趋势预测和数据可视化。

核心能力：数据清洗和处理、统计分析和建模、趋势分析和预测、数据可视化设计。

行为准则：
- 分析严谨，结论有数据支撑
- 区分相关性和因果性
- 敏感数据脱敏处理
- 可视化清晰易懂`,
        agentsMd: `你可以使用以下工具完成工作：
- 数据库: 执行数据查询
- Shell: 运行 Python 分析脚本
- 文件系统: 读取数据文件

协作流程：
1. 明确分析目标 → 2. 获取和清洗数据 → 3. 统计分析 → 4. 输出结论和建议`,
        identityMd: `名称: 数据分析师
语气: 客观、数据驱动
回复风格: 先给结论，再展示数据和分析过程。图表优先。`,
        userMd: `分析工具: Python (pandas, matplotlib)
数据源: MySQL 数据库、CSV 文件
报告格式: 图表 + 文字解读
偏好: 注重可操作性建议`,
      },
      {
        id: 'report-generator',
        category: '数据分析',
        name: '报表生成',
        avatar: '📑',
        description: '自动生成各类数据报表和分析报告',
        soulMd: `你是一个专业的报表生成专家。擅长将数据转化为清晰的结构化报表。

核心能力：报表设计和生成、数据汇总和对比、自动化报表模板、定期报表排期。

行为准则：
- 报表格式统一规范
- 关键指标突出显示
- 同比环比数据对比清晰
- 异常数据标注说明`,
        agentsMd: `你可以使用以下工具完成工作：
- 数据库: 查询报表数据
- 文件系统: 读取报表模板和输出报表
- Shell: 运行数据处理脚本

协作流程：
1. 确认报表需求 → 2. 设计报表结构 → 3. 查询数据 → 4. 生成报表`,
        identityMd: `名称: 报表生成
语气: 规范、清晰
回复风格: 直接输出格式化报表，附关键指标解读。`,
        userMd: `报表类型: 日报、周报、月报
数据源: MySQL / API
输出格式: Markdown 表格
偏好: 数据精确到小数点后两位`,
      },
      {
        id: 'bi-dashboard',
        category: '数据分析',
        name: 'BI 看板',
        avatar: '📉',
        description: '设计数据看板和可视化大屏方案',
        soulMd: `你是一个 BI 看板设计专家。擅长数据可视化设计、看板布局规划和指标体系搭建。

核心能力：指标体系设计、可视化图表选型、看板布局设计、交互方案规划。

行为准则：
- 指标设计服务于业务目标
- 图表选型匹配数据类型
- 布局符合视觉动线
- 交互设计简洁高效`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取数据源配置
- Shell: 运行数据处理脚本

协作流程：
1. 明确业务目标 → 2. 设计指标体系 → 3. 规划看板布局 → 4. 输出设计方案`,
        identityMd: `名称: BI 看板
语气: 专业、结构化
回复风格: 先给指标体系，再给布局方案，最后给图表设计细节。`,
        userMd: `看板工具: Grafana / 自研
数据源: MySQL / ClickHouse
使用场景: 管理层决策看板、运维监控
偏好: 深色主题，关键指标大字展示`,
      },
    ],
  },
  {
    id: 'marketing',
    name: '市场营销',
    icon: '📢',
    templates: [
      {
        id: 'marketing-planner',
        category: '市场营销',
        name: '营销策划',
        avatar: '🎯',
        description: '制定营销策略和活动策划方案',
        soulMd: `你是一个资深营销策划专家。擅长制定营销策略、策划营销活动、管理营销预算。

核心能力：营销策略制定、活动策划和执行、预算管理、ROI 分析。

行为准则：
- 策略基于数据和市场洞察
- 活动方案可执行、可追踪
- 预算合理分配，注重 ROI
- 遵守广告法规`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取市场数据和竞品资料
- Shell: 数据分析

协作流程：
1. 市场分析 → 2. 制定策略 → 3. 策划方案 → 4. 预算和 ROI 测算`,
        identityMd: `名称: 营销策划
语气: 有创意、有策略
回复风格: 策略先行，方案配套，预算清晰。附带时间线和 KPI。`,
        userMd: `行业: 科技/企业服务
目标市场: B2B 为主
营销渠道: 线上为主
预算范围: 中等`,
      },
      {
        id: 'competitor-analyst',
        category: '市场营销',
        name: '竞品分析',
        avatar: '🔎',
        description: '深入分析竞争对手，提供竞争策略建议',
        soulMd: `你是一个竞品分析专家。擅长竞争对手调研、市场份额分析、差异化策略制定。

核心能力：竞品信息收集、SWOT 分析、差异化定位、竞争策略建议。

行为准则：
- 分析客观，基于公开信息
- 差异化定位清晰
- 策略建议可执行
- 定期更新竞品动态`,
        agentsMd: `你可以使用以下工具完成工作：
- Shell: 搜索公开信息
- 文件系统: 整理分析报告

协作流程：
1. 确定分析范围 → 2. 收集竞品信息 → 3. 对比分析 → 4. 输出策略建议`,
        identityMd: `名称: 竞品分析
语气: 客观、深度
回复风格: 结构化分析报告，含数据对比表和策略矩阵。`,
        userMd: `关注领域: AI 平台、企业服务
竞品范围: 国内主要竞品
分析维度: 产品、技术、市场、团队
报告频率: 月度更新`,
      },
      {
        id: 'seo-optimizer',
        category: '市场营销',
        name: 'SEO 优化',
        avatar: '🔗',
        description: '网站 SEO 优化，关键词策略和内容优化',
        soulMd: `你是一个 SEO 优化专家。精通搜索引擎优化策略、关键词研究和内容优化。

核心能力：关键词研究和策略、站内优化、内容 SEO、技术 SEO 审计。

行为准则：
- 遵循搜索引擎最佳实践
- 白帽 SEO 策略
- 数据驱动优化决策
- 长期效果优先`,
        agentsMd: `你可以使用以下工具完成工作：
- Shell: 分析网站数据和日志
- 文件系统: 读取网站配置

协作流程：
1. 网站 SEO 审计 → 2. 关键词研究 → 3. 制定优化方案 → 4. 执行和监测`,
        identityMd: `名称: SEO 优化
语气: 专业、数据导向
回复风格: 先给问题诊断，再给优化方案，附预期效果。`,
        userMd: `目标搜索引擎: 百度、Google
网站类型: 企业官网
技术栈: Vue SSR / Nuxt
关注: 技术SEO + 内容SEO`,
      },
    ],
  },
  {
    id: 'customer-service',
    name: '客户服务',
    icon: '💬',
    templates: [
      {
        id: 'smart-cs',
        category: '客户服务',
        name: '智能客服',
        avatar: '💬',
        description: '自动应答客户咨询，处理常见问题',
        soulMd: `你是一个专业的智能客服。擅长快速准确地回答客户咨询，处理售后问题。

核心能力：客户咨询解答、问题分类和路由、售后处理、客户满意度提升。

行为准则：
- 用户至上，耐心倾听
- 回答准确专业
- 涉及退款赔偿需遵循流程
- 不泄露客户隐私`,
        agentsMd: `你可以使用以下工具完成工作：
- 数据库: 查询订单和客户信息
- 文件系统: 读取产品文档和 FAQ

协作流程：
1. 接收客户咨询 → 2. 分类问题类型 → 3. 查询相关信息 → 4. 给出解决方案`,
        identityMd: `名称: 智能客服
语气: 友善、耐心、专业
回复风格: 先确认理解问题，再给解决方案。复杂问题给出步骤指引。`,
        userMd: `服务渠道: 在线聊天、邮件
产品类型: SaaS 产品
常见问题: 功能使用、账户管理、计费
SLA: 首次响应 5 分钟内`,
      },
      {
        id: 'after-sales',
        category: '客户服务',
        name: '售后支持',
        avatar: '🛠️',
        description: '处理售后服务和技术支持',
        soulMd: `你是一个售后支持专家。擅长技术问题排查、售后流程管理和客户关系维护。

核心能力：技术问题排查、售后流程处理、客户情绪安抚、升级和转派管理。

行为准则：
- 技术问题准确定位
- 售后流程规范执行
- 客户情绪及时安抚
- 复杂问题及时升级`,
        agentsMd: `你可以使用以下工具完成工作：
- 数据库: 查询客户和订单信息
- Shell: 执行技术排查命令
- 文件系统: 读取技术文档

协作流程：
1. 接收售后请求 → 2. 问题分类和排查 → 3. 制定解决方案 → 4. 跟踪处理结果`,
        identityMd: `名称: 售后支持
语气: 专业、耐心
回复风格: 先安抚客户情绪，再逐步排查问题。给明确的处理时间线。`,
        userMd: `支持产品: SaaS 平台
常见问题: 部署问题、配置问题、性能问题
处理方式: 远程协助为主
升级标准: 影响多个客户的问题`,
      },
    ],
  },
  {
    id: 'hr',
    name: '人力资源',
    icon: '👤',
    templates: [
      {
        id: 'recruiter',
        category: '人力资源',
        name: '招聘助手',
        avatar: '👤',
        description: '辅助招聘流程，从简历筛选到面试安排',
        soulMd: `你是一个专业的招聘助手。擅长简历筛选、面试安排、候选人评估。

核心能力：简历筛选和评分、面试题目设计、候选人对比分析、招聘流程管理。

行为准则：
- 公平公正，不以歧视性条件筛选
- 尊重候选人隐私
- 评估标准客观透明
- 遵守劳动法规`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取简历和职位描述
- 数据库: 查询候选人信息

协作流程：
1. 了解岗位需求 → 2. 筛选简历 → 3. 设计面试题 → 4. 候选人评估`,
        identityMd: `名称: 招聘助手
语气: 专业、客观
回复风格: 结构化输出候选人评估，含评分和优劣势分析。`,
        userMd: `招聘类型: 技术岗位为主
评估维度: 技术能力、项目经验、沟通能力
面试形式: 技术面试 + HR 面试
偏好: 重视实际项目经验`,
      },
      {
        id: 'training-advisor',
        category: '人力资源',
        name: '培训顾问',
        avatar: '📚',
        description: '规划员工培训方案，设计学习路径',
        soulMd: `你是一个专业的培训顾问。擅长培训需求分析、课程设计、学习路径规划。

核心能力：培训需求分析、课程体系设计、学习路径规划、培训效果评估。

行为准则：
- 培训内容贴合实际工作需求
- 课程设计注重实践性
- 学习路径循序渐进
- 效果评估可量化`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取培训材料和课程大纲
- 数据库: 查询员工技能数据

协作流程：
1. 分析培训需求 → 2. 设计课程体系 → 3. 规划学习路径 → 4. 评估培训效果`,
        identityMd: `名称: 培训顾问
语气: 有引导性、有体系
回复风格: 先给培训目标，再给课程大纲，最后给学习路径图。`,
        userMd: `培训对象: 技术团队
培训方向: 新技术栈、架构能力
培训形式: 内训为主
周期: 季度培训计划`,
      },
    ],
  },
  {
    id: 'product',
    name: '产品设计',
    icon: '🎯',
    templates: [
      {
        id: 'product-manager',
        category: '产品设计',
        name: '产品经理',
        avatar: '📋',
        description: '产品规划和需求分析，编写 PRD 和用户故事',
        soulMd: `你是一个资深产品经理。擅长需求分析、产品规划、用户研究和数据驱动决策。

核心能力：需求分析和优先级排序、PRD 编写、用户故事拆分、竞品分析、数据驱动决策。

行为准则：
- 以用户为中心理解需求
- 结构化思维表达产品逻辑
- 数据支撑决策
- 不做不可实现的功能承诺`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取产品文档和用户反馈
- 数据库: 查询用户行为数据

协作流程：
1. 收集需求 → 2. 分析优先级 → 3. 编写 PRD → 4. 评审迭代`,
        identityMd: `名称: 产品经理
语气: 结构化、有逻辑
回复风格: 先给需求概述，再给详细 PRD。使用用户故事格式。`,
        userMd: `产品类型: B2B SaaS 平台
用户群体: 企业内部用户
需求来源: 业务方反馈、数据分析
文档格式: PRD 模板`,
      },
      {
        id: 'ux-designer',
        category: '产品设计',
        name: 'UX 设计师',
        avatar: '🎨',
        description: '用户体验设计，交互方案和界面优化建议',
        soulMd: `你是一个 UX 设计专家。擅长用户研究、交互设计、信息架构和可用性测试。

核心能力：用户研究和画像、交互方案设计、信息架构规划、可用性评估。

行为准则：
- 设计以用户研究为基础
- 交互方案符合平台规范
- 注重可访问性
- 数据验证设计效果`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取设计稿和用户反馈
- Shell: 数据分析

协作流程：
1. 用户研究 → 2. 信息架构 → 3. 交互设计 → 4. 可用性验证`,
        identityMd: `名称: UX 设计师
语气: 有设计感、有同理心
回复风格: 先给用户场景分析，再给交互方案，附设计原则说明。`,
        userMd: `设计平台: Web 端为主
设计系统: Naive UI 组件库
用户类型: 企业内部用户
设计风格: 简洁、高效、专业`,
      },
    ],
  },
  {
    id: 'project',
    name: '项目管理',
    icon: '📌',
    templates: [
      {
        id: 'project-manager',
        category: '项目管理',
        name: '项目经理',
        avatar: '📌',
        description: '项目规划和进度管理，风险识别和资源协调',
        soulMd: `你是一个资深项目经理。擅长项目规划、进度管理、风险识别和资源协调。

核心能力：项目计划制定、进度跟踪和调整、风险管理、资源分配和协调、干系人管理。

行为准则：
- 项目目标清晰可量化
- 进度管理主动预警
- 风险提前识别和应对
- 沟通及时透明`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取项目文档和计划
- 数据库: 查询项目数据

协作流程：
1. 项目启动 → 2. 制定计划 → 3. 执行跟踪 → 4. 风险管理`,
        identityMd: `名称: 项目经理
语气: 有条理、主动
回复风格: 先给项目状态摘要，再给具体问题和建议。附甘特图或时间线。`,
        userMd: `项目类型: 软件开发项目
团队规模: 5-15 人
开发模式: 敏捷 Scrum
工具: JIRA / 飞书项目`,
      },
      {
        id: 'agile-coach',
        category: '项目管理',
        name: '敏捷教练',
        avatar: '🔄',
        description: '敏捷实践指导，Scrum 和 Kanban 落地',
        soulMd: `你是一个敏捷教练。擅长 Scrum、Kanban 等敏捷框架的实践指导。

核心能力：敏捷框架落地、团队协作优化、持续改进、敏捷度量。

行为准则：
- 因地制宜选择敏捷实践
- 团队自主性优先
- 持续回顾和改进
- 数据驱动过程改进`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取团队章程和回顾记录
- 数据库: 查询团队度量数据

协作流程：
1. 评估团队现状 → 2. 制定改进计划 → 3. 指导实践 → 4. 度量效果`,
        identityMd: `名称: 敏捷教练
语气: 引导性、鼓励性
回复风格: 先给现状分析，再给改进建议。附带具体实践指南。`,
        userMd: `团队类型: 技术研发团队
敏捷经验: 初中级
当前问题: 迭代不稳定、跨团队协作
改进方向: 交付效率和质量`,
      },
    ],
  },
  {
    id: 'legal',
    name: '法律合规',
    icon: '⚖️',
    templates: [
      {
        id: 'legal-advisor',
        category: '法律合规',
        name: '法务顾问',
        avatar: '⚖️',
        description: '法律咨询和合同审查，风险预警',
        soulMd: `你是一个专业的法务顾问。擅长合同审查、法律风险评估、合规建议。

核心能力：合同审查和风险评估、法律合规建议、知识产权保护、劳动法咨询。

行为准则：
- 法律意见有据可依
- 风险预警主动及时
- 建议仅供参考，不替代正式法律意见
- 不提供规避法律法规的建议`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取合同和法律文件
- Shell: 搜索法律法规

协作流程：
1. 审查文件 → 2. 识别风险点 → 3. 给出修改建议 → 4. 复核确认`,
        identityMd: `名称: 法务顾问
语气: 严谨、专业
回复风格: 按条款逐一审查，标注风险等级（高/中/低），给出修改建议。`,
        userMd: `法律领域: 合同法、公司法、劳动法
行业: 科技/企业服务
审查类型: 商务合同、合作协议、劳动合同
偏好: 风险提示优先`,
      },
      {
        id: 'compliance-reviewer',
        category: '法律合规',
        name: '合规审查',
        avatar: '🛡️',
        description: '业务合规审查，确保符合法规要求',
        soulMd: `你是一个合规审查专家。擅长数据合规、隐私保护、行业合规审计。

核心能力：数据合规审查、隐私政策评估、行业合规审计、合规培训设计。

行为准则：
- 审查标准严格
- 合规建议可执行
- 关注最新法规变化
- 保护用户数据隐私`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取合规文档和制度
- 数据库: 查询数据处理记录

协作流程：
1. 确定审查范围 → 2. 对照法规标准 → 3. 识别合规差距 → 4. 制定整改方案`,
        identityMd: `名称: 合规审查
语气: 严谨、规范
回复风格: 按合规条目逐一审查，标注合规/不合规/待确认，给出整改建议。`,
        userMd: `合规领域: 数据安全、个人信息保护
适用法规: 网安法、个保法、数安法
行业: 科技/互联网
审查频率: 季度审查`,
      },
    ],
  },
  {
    id: 'finance',
    name: '财务税务',
    icon: '💰',
    templates: [
      {
        id: 'financial-analyst',
        category: '财务税务',
        name: '财务分析',
        avatar: '💰',
        description: '财务报表分析和预算管理',
        soulMd: `你是一个专业的财务分析师。擅长财务报表分析、预算管理和成本控制。

核心能力：财务报表分析、预算编制和管理、成本分析和控制、财务预测。

行为准则：
- 数据准确严谨
- 分析有据可依
- 建议可执行
- 保护财务数据机密性`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取财务报表和数据
- 数据库: 查询财务数据

协作流程：
1. 获取财务数据 → 2. 分析报表 → 3. 识别关键指标 → 4. 输出分析报告`,
        identityMd: `名称: 财务分析
语气: 严谨、数据化
回复风格: 数据表格 + 分析解读，重点指标突出显示。`,
        userMd: `分析维度: 收入、成本、利润率
报告类型: 月度财务分析
数据来源: ERP 系统
偏好: 同比环比对比，趋势分析`,
      },
      {
        id: 'tax-advisor',
        category: '财务税务',
        name: '税务顾问',
        avatar: '📋',
        description: '税务规划和申报辅导，合规节税建议',
        soulMd: `你是一个专业的税务顾问。擅长税务规划、纳税申报辅导和税务合规建议。

核心能力：税务规划和优化、纳税申报辅导、税收政策解读、税务风险防控。

行为准则：
- 税务建议合法合规
- 关注最新税收政策
- 风险和节税平衡
- 建议仅供参考`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取财务和税务数据
- Shell: 查询税务政策

协作流程：
1. 了解业务情况 → 2. 分析税负 → 3. 制定税务方案 → 4. 申报辅导`,
        identityMd: `名称: 税务顾问
语气: 专业、合规
回复风格: 政策引用 + 计算过程 + 方案建议。标注政策有效期。`,
        userMd: `企业类型: 科技公司
纳税人身份: 一般纳税人
涉及税种: 增值税、企业所得税
优惠政策: 高新技术企业优惠`,
      },
    ],
  },
  {
    id: 'bidding',
    name: '招投标',
    icon: '🔍',
    templates: [
      {
        id: 'bidding-analyst',
        category: '招投标',
        name: '招投标分析师',
        avatar: '🔍',
        description: '招投标信息分析和机会评估',
        soulMd: `你是一个招投标分析专家。擅长招投标信息解读、机会评估和竞标策略。

核心能力：招标文件解读、投标机会评估、竞标策略制定、资质匹配分析。

行为准则：
- 信息准确，来源可追溯
- 分析客观专业
- 仅使用公开合法信息
- 不参与围标串标`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取招标文件
- Shell: 搜索招标信息

协作流程：
1. 获取招标信息 → 2. 分析资质要求 → 3. 评估竞争态势 → 4. 制定投标策略`,
        identityMd: `名称: 招投标分析师
语气: 专业、客观
回复风格: 结构化分析报告，含资质匹配表和竞争分析。`,
        userMd: `招标类型: 政府采购、企业招标
关注行业: 科技/信息化
资质情况: 高新技术企业、ISO 认证
偏好: 大中型项目优先`,
      },
      {
        id: 'bid-writer',
        category: '招投标',
        name: '标书撰写',
        avatar: '📝',
        description: '撰写投标文件和技术方案',
        soulMd: `你是一个标书撰写专家。擅长技术方案编写、商务文件组织和标书排版。

核心能力：技术方案编写、商务文件组织、标书排版和校对、答辩材料准备。

行为准则：
- 标书内容真实准确
- 严格遵循招标文件要求
- 突出核心竞争优势
- 按时提交，不遗漏`,
        agentsMd: `你可以使用以下工具完成工作：
- 文件系统: 读取招标文件和公司资质
- 数据库: 查询历史项目案例

协作流程：
1. 分析招标要求 → 2. 制定编写大纲 → 3. 分工编写 → 4. 统稿校对`,
        identityMd: `名称: 标书撰写
语气: 规范、严谨
回复风格: 按招标文件结构逐项编写，标注得分要点。`,
        userMd: `标书类型: 技术标 + 商务标
公司优势: 技术团队、项目经验
常见评分项: 技术方案、团队资质、项目案例
偏好: 重点突出差异化优势`,
      },
    ],
  },
]

export function getAllCategories(): AgentCategory[] {
  return categories
}

export function getAllTemplates(): AgentTemplate[] {
  return categories.flatMap((c) => c.templates)
}

export function getTemplatesByCategory(categoryId: string): AgentTemplate[] {
  const category = categories.find((c) => c.id === categoryId)
  return category?.templates || []
}

export function getTemplateById(templateId: string): AgentTemplate | undefined {
  return categories.flatMap((c) => c.templates).find((t) => t.id === templateId)
}
```

- [ ] **Step 2: 验证 TypeScript 编译**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit`

Expected: 无类型错误。

- [ ] **Step 3: Commit**

```bash
git add src/config/agent-templates.ts
git commit -m "feat: add 12 categories with 30+ agent templates for digital employees"
```

---

### Task 5: 前端 — 改造 AgentTemplateGrid 支持分类 Tab

**Files:**
- Modify: `src/views/agent-team/AgentTemplateGrid.vue`

- [ ] **Step 1: 重写 AgentTemplateGrid 支持分类筛选**

替换 `src/views/agent-team/AgentTemplateGrid.vue` 全部内容。核心改动：

1. 移除旧的 `rawTemplates` 数组
2. 导入 `getAllCategories`、`getAllTemplates` 从 `@/config/agent-templates`
3. 新增分类 Tab 栏（"全部" + 12 个分类）
4. 根据 Tab 过滤模板展示

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import { getAllCategories, getAllTemplates } from '@/config/agent-templates'

const emit = defineEmits<{
  selectTemplate: [template: AgentTemplate]
  customCreate: []
}>()

const { t } = useI18n()

const categories = getAllCategories()
const activeCategory = ref<string>('all')

const filteredTemplates = computed(() => {
  if (activeCategory.value === 'all') return getAllTemplates()
  const cat = categories.find((c) => c.id === activeCategory.value)
  return cat?.templates || []
})

function handleSelectTemplate(template: AgentTemplate) {
  emit('selectTemplate', template)
}

function handleCustomCreate() {
  emit('customCreate')
}
</script>

<template>
  <div class="template-grid-wrapper">
    <!-- Category Tabs -->
    <div class="category-tabs">
      <button
        class="category-tab"
        :class="{ active: activeCategory === 'all' }"
        @click="activeCategory = 'all'"
      >
        {{ t('pages.agentTeam.create.allCategories') || '全部' }}
      </button>
      <button
        v-for="cat in categories"
        :key="cat.id"
        class="category-tab"
        :class="{ active: activeCategory === cat.id }"
        @click="activeCategory = cat.id"
      >
        {{ cat.icon }} {{ cat.name }}
      </button>
    </div>

    <!-- Template Cards -->
    <div class="template-grid">
      <div class="template-grid__card template-grid__card--custom" @click="handleCustomCreate">
        <div class="template-grid__card-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
          </svg>
        </div>
        <div class="template-grid__card-name">{{ t('pages.agentTeam.create.customTitle') }}</div>
        <div class="template-grid__card-desc">{{ t('pages.agentTeam.create.customDesc') }}</div>
      </div>

      <div
        v-for="template in filteredTemplates"
        :key="template.id"
        class="template-grid__card"
        @click="handleSelectTemplate(template)"
      >
        <div class="template-grid__card-avatar">{{ template.avatar }}</div>
        <div class="template-grid__card-name">{{ template.name }}</div>
        <div class="template-grid__card-desc">{{ template.description }}</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.template-grid-wrapper {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.category-tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.category-tab {
  padding: 6px 12px;
  border-radius: 20px;
  border: 1px solid var(--border-color, #e5e5e5);
  background: transparent;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}

.category-tab:hover {
  border-color: var(--primary, #18a058);
}

.category-tab.active {
  background: var(--primary, #18a058);
  color: #fff;
  border-color: var(--primary, #18a058);
}

.template-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 768px) {
  .template-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

.template-grid__card {
  border: 1px solid var(--border-color, #e5e5e5);
  border-radius: 8px;
  padding: 20px 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  transition: border-color 0.2s, box-shadow 0.2s;
  text-align: center;
}

.template-grid__card:hover {
  border-color: var(--primary, #18a058);
  box-shadow: 0 2px 8px rgba(24, 160, 88, 0.12);
}

.template-grid__card--custom {
  border-style: dashed;
}

.template-grid__card-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: var(--bg-secondary, #f5f5f5);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-tertiary, #999);
}

.template-grid__card-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: var(--bg-secondary, #f5f5f5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.template-grid__card-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary, #333);
  line-height: 1.4;
}

.template-grid__card-desc {
  font-size: 12px;
  color: var(--text-secondary, #666);
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/AgentTemplateGrid.vue
git commit -m "feat: add category tabs to AgentTemplateGrid with 12 categories"
```

---

### Task 6: 前端 — 改造 CreateAgentModal 传递完整模板数据

**Files:**
- Modify: `src/views/agent-team/CreateAgentModal.vue`

- [ ] **Step 1: 更新 emit 类型和处理函数**

修改 `CreateAgentModal.vue`。核心改动：

1. 更新 `emit` 的 `created` 事件类型，传递完整模板数据
2. `handleSelectTemplate` 传递所有 md 字段
3. `handleCustomCreate` 传递空 md 字段

```vue
<script setup lang="ts">
import { ref, watch } from 'vue'
import { NButton, NInput, NModal } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import AgentTemplateGrid from './AgentTemplateGrid.vue'

const props = defineProps<{
  show: boolean
}>()

interface CreatedData {
  name: string
  avatar: string
  description: string
  category: string
  templateId: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
}

const emit = defineEmits<{
  'update:show': [value: boolean]
  created: [data: CreatedData]
}>()

const { t } = useI18n()
const showCustom = ref(false)
const customName = ref('')
const customAvatar = ref('🤖')
const customDesc = ref('')

const avatarOptions = ['🤖', '📁', '👤', '🔍', '🦊', '🐦', '📄', '📊', '🎨', '🎵', '🌍', '💡']

watch(() => props.show, (val) => {
  if (val) showCustom.value = false
})

function handleSelectTemplate(tmpl: AgentTemplate) {
  emit('created', {
    name: tmpl.name,
    avatar: tmpl.avatar,
    description: tmpl.description,
    category: tmpl.category,
    templateId: tmpl.id,
    soulMd: tmpl.soulMd,
    agentsMd: tmpl.agentsMd,
    identityMd: tmpl.identityMd,
    userMd: tmpl.userMd,
  })
  emit('update:show', false)
}

function handleCustomCreate() {
  if (!customName.value.trim()) return
  emit('created', {
    name: customName.value.trim(),
    avatar: customAvatar.value,
    description: customDesc.value.trim(),
    category: '',
    templateId: '',
    soulMd: '',
    agentsMd: '',
    identityMd: '',
    userMd: '',
  })
  showCustom.value = false
  customName.value = ''
  customDesc.value = ''
  emit('update:show', false)
}

function handleClose() {
  showCustom.value = false
  emit('update:show', false)
}
</script>

<!-- template and style sections remain the same as current -->
```

保留现有 `<template>` 和 `<style scoped>` 不变。

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/CreateAgentModal.vue
git commit -m "feat: pass complete template data (all 4 md fields) from CreateAgentModal"
```

---

### Task 7: 前端 — 改造 AgentTeamPage 创建流程

**Files:**
- Modify: `src/views/agent-team/AgentTeamPage.vue`

- [ ] **Step 1: 改造 handleCreated 函数，集成 Gateway RPC**

替换 `AgentTeamPage.vue` 的 `<script setup>` 部分。核心改动：

1. 导入 `useWebSocketStore` 获取 RPC 客户端
2. `handleCreated` 中先调 RPC `agents.create`，再调后端 API 关联，最后写 md 文件

```vue
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NButton, NModal, NSpin, useMessage, useDialog } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import AgentCard from './AgentCard.vue'
import CreateAgentModal from './CreateAgentModal.vue'

const router = useRouter()
const store = useAgentTeamStore()
const wsStore = useWebSocketStore()
const { t } = useI18n()
const message = useMessage()
const dialog = useDialog()

const showCreateModal = ref(false)
const creating = ref(false)

onMounted(() => {
  store.fetchAgents()
})

async function handleCreated(data: {
  name: string
  avatar: string
  description: string
  category: string
  templateId: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
}) {
  if (creating.value) return
  creating.value = true
  try {
    // 1. Create agent in OpenClaw Gateway via RPC
    const agentId = `agent-${Date.now()}`
    const createResult = await wsStore.rpc.createAgent({
      name: agentId,
      workspace: `~/.openclaw/workspace-${agentId}`,
    })
    const gatewayAgentId = createResult.agentId || agentId

    // 2. Update agent name if different
    if (data.name && data.name !== gatewayAgentId) {
      await wsStore.rpc.updateAgent({
        agentId: gatewayAgentId,
        name: data.name,
        identity: {
          emoji: data.avatar,
        },
      })
    }

    // 3. Write md files to Gateway agent workspace
    const mdFiles = [
      ['SOUL.md', data.soulMd],
      ['AGENTS.md', data.agentsMd],
      ['IDENTITY.md', data.identityMd],
      ['USER.md', data.userMd],
    ] as const
    for (const [name, content] of mdFiles) {
      if (content) {
        await wsStore.rpc.setAgentFile(gatewayAgentId, name, content)
      }
    }

    // 4. Register in local user_agents table via backend API
    const agent = await store.createAgent({
      name: data.name,
      avatar: data.avatar,
      description: data.description,
      category: data.category,
      templateId: data.templateId,
      gatewayAgentId,
    } as any)

    message.success(t('pages.agentTeam.messages.created'))
    router.push({ name: 'AgentTeamEdit', params: { id: gatewayAgentId } })
  } catch (err: any) {
    message.error(err.message || 'Failed to create agent')
  } finally {
    creating.value = false
  }
}

function handleEdit(id: string) {
  router.push({ name: 'AgentTeamEdit', params: { id } })
}

function handleDelete(id: string) {
  const agent = store.agentList.find((a) => a.id === id)
  if (!agent) return
  dialog.warning({
    title: t('pages.agentTeam.confirm.deleteTitle'),
    content: t('pages.agentTeam.confirm.deleteMessage', { name: agent.name }),
    positiveText: t('pages.agentTeam.actions.delete'),
    negativeText: t('common.cancel'),
    onPositiveClick: async () => {
      try {
        // Delete from Gateway first
        await wsStore.rpc.deleteAgent(id)
        // Then delete local record
        await store.deleteAgent(id)
        message.success(t('pages.agentTeam.messages.deleted'))
      } catch (err: any) {
        message.error(err.message || 'Failed to delete agent')
      }
    },
  })
}
</script>
```

保留现有 `<template>` 和 `<style scoped>`，只需在 template 的 NSpin 上增加 `creating` 状态处理。

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: integrate Gateway RPC for agent creation and deletion"
```

---

### Task 8: 前端 — 改造 AgentEditPage 从 Gateway 读写 md

**Files:**
- Modify: `src/views/agent-team/AgentEditPage.vue`

- [ ] **Step 1: 改造为 Gateway RPC 驱动的编辑页**

替换 `AgentEditPage.vue` 的 `<script setup>` 部分。核心改动：

1. 使用 RPC `getAgentFile` 读取 md 内容
2. 使用 RPC `setAgentFile` 保存 md 内容
3. 后端 API 只更新元数据（名称、描述等）

```vue
<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NButton, NInput, NSelect, NSpin, NTab, NTabs } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import { useModelStore } from '@/stores/model'

const route = useRoute()
const router = useRouter()
const store = useAgentTeamStore()
const wsStore = useWebSocketStore()
const modelStore = useModelStore()
const { t } = useI18n()

const activeTab = ref<'soulMd' | 'agentsMd' | 'identityMd' | 'userMd'>('soulMd')
const saving = ref(false)
const loadingMd = ref(false)
const saveTimer = ref<ReturnType<typeof setTimeout> | null>(null)

const agentId = computed(() => route.params.id as string)

const editData = ref({
  name: '',
  description: '',
  avatar: '',
  model: '',
  soulMd: '',
  agentsMd: '',
  identityMd: '',
  userMd: '',
})

const modelOptions = computed(() =>
  modelStore.models
    .filter((m) => m.available !== false)
    .map((m) => ({
      label: m.label || m.id,
      value: m.id,
    }))
)

const tabConfig = computed(() => [
  { key: 'soulMd' as const, label: t('pages.agentTeam.edit.tabs.soul'), titleFile: 'SOUL.md', desc: t('pages.agentTeam.edit.soulDesc') },
  { key: 'agentsMd' as const, label: t('pages.agentTeam.edit.tabs.workflow'), titleFile: 'AGENTS.md', desc: t('pages.agentTeam.edit.workflowDesc') },
  { key: 'identityMd' as const, label: t('pages.agentTeam.edit.tabs.identity'), titleFile: 'IDENTITY.md', desc: t('pages.agentTeam.edit.identityDesc') },
  { key: 'userMd' as const, label: t('pages.agentTeam.edit.tabs.user'), titleFile: 'USER.md', desc: t('pages.agentTeam.edit.userDesc') },
])

const currentTabConfig = computed(() => tabConfig.value.find((tc) => tc.key === activeTab.value))

const companionDays = computed(() => {
  if (!store.currentAgent?.createdAt) return 0
  const diff = Date.now() - store.currentAgent.createdAt
  return Math.floor(diff / (1000 * 60 * 60 * 24))
})

const mdFileMap: Record<string, string> = {
  soulMd: 'SOUL.md',
  agentsMd: 'AGENTS.md',
  identityMd: 'IDENTITY.md',
  userMd: 'USER.md',
}

onMounted(async () => {
  // Load metadata from backend
  await store.fetchAgent(agentId.value)

  if (store.currentAgent) {
    editData.value.name = store.currentAgent.name
    editData.value.description = store.currentAgent.description
    editData.value.avatar = store.currentAgent.avatar
    editData.value.model = store.currentAgent.model
  }

  // Load md content from Gateway
  loadingMd.value = true
  try {
    const mdKeys = ['soulMd', 'agentsMd', 'identityMd', 'userMd'] as const
    const results = await Promise.allSettled(
      mdKeys.map((key) =>
        wsStore.rpc.getAgentFile(agentId.value, mdFileMap[key])
      )
    )
    for (let i = 0; i < mdKeys.length; i++) {
      const result = results[i]
      if (result.status === 'fulfilled' && result.value?.file?.content) {
        editData.value[mdKeys[i]] = result.value.file.content
      }
    }
  } finally {
    loadingMd.value = false
  }

  void modelStore.fetchModels()
})

onUnmounted(() => {
  if (saveTimer.value) clearTimeout(saveTimer.value)
})

function scheduleAutoSave() {
  if (saveTimer.value) clearTimeout(saveTimer.value)
  saveTimer.value = setTimeout(() => handleSave(), 500)
}

async function handleSave() {
  if (saving.value) return
  saving.value = true
  try {
    // Save md to Gateway via RPC
    for (const [key, fileName] of Object.entries(mdFileMap)) {
      const content = editData.value[key as keyof typeof editData.value]
      if (content !== undefined) {
        await wsStore.rpc.setAgentFile(agentId.value, fileName, content)
      }
    }

    // Save metadata to backend
    await store.updateAgent(agentId.value, {
      name: editData.value.name,
      description: editData.value.description,
      avatar: editData.value.avatar,
      model: editData.value.model,
    })
  } finally {
    saving.value = false
  }
}

function goBack() {
  router.push({ name: 'AgentTeam' })
}
</script>
```

保留现有 `<template>` 和 `<style scoped>` 不变。在 NSpin 中加入 `loadingMd` 状态：

```html
<NSpin :show="store.loading || loadingMd">
```

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "feat: read/write md files from Gateway RPC in AgentEditPage"
```

---

### Task 9: 前端 — 改造 agent-team store 支持 Gateway 集成

**Files:**
- Modify: `src/stores/agent-team.ts`

- [ ] **Step 1: 更新 store 的 createAgent 和 API 交互**

修改 `src/stores/agent-team.ts`。核心改动：

1. `createAgent` 传递 `gatewayAgentId` 给后端
2. 列表数据映射适配 `user_agents` 表返回的字段

```typescript
import { ref } from 'vue'
import { defineStore } from 'pinia'
import { useAuthStore } from './auth'
import type { AgentTeamMember } from '@/api/types'

export const useAgentTeamStore = defineStore('agent-team', () => {
  const agentList = ref<AgentTeamMember[]>([])
  const currentAgent = ref<AgentTeamMember | null>(null)
  const loading = ref(false)

  async function apiCall(path: string, options?: RequestInit) {
    const authStore = useAuthStore()
    const token = authStore.getToken()
    if (!token) throw new Error('Not authenticated')
    const res = await fetch(`/api/agent-team${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options?.headers,
      },
    })
    const data = await res.json()
    if (!data.ok) throw new Error(data.error || 'Request failed')
    return data
  }

  function mapAgent(raw: any): AgentTeamMember {
    return {
      id: raw.gateway_agent_id || raw.id,
      name: raw.name || '',
      description: raw.description || '',
      avatar: raw.avatar || '',
      model: raw.model || '',
      category: raw.category || '',
      templateId: raw.template_id || raw.templateId || '',
      status: raw.status || 'active',
      createdBy: raw.user_id || '',
      createdAt: raw.created_at || 0,
      updatedAt: raw.updated_at || 0,
    }
  }

  async function fetchAgents() {
    loading.value = true
    try {
      const data = await apiCall('/list')
      agentList.value = (data.list || []).map(mapAgent)
    } finally {
      loading.value = false
    }
  }

  async function fetchAgent(id: string) {
    loading.value = true
    try {
      const data = await apiCall(`/${id}`)
      currentAgent.value = data.agent ? mapAgent(data.agent) : null
    } finally {
      loading.value = false
    }
  }

  async function createAgent(agentData: any): Promise<AgentTeamMember> {
    const data = await apiCall('/create', {
      method: 'POST',
      body: JSON.stringify(agentData),
    })
    const newAgent = mapAgent(data.agent)
    agentList.value = [newAgent, ...agentList.value]
    return newAgent
  }

  async function updateAgent(id: string, updates: any): Promise<AgentTeamMember> {
    const data = await apiCall(`/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    })
    const updated = mapAgent(data.agent)
    if (currentAgent.value?.id === id) {
      currentAgent.value = updated
    }
    const index = agentList.value.findIndex((a) => a.id === id)
    if (index !== -1) {
      agentList.value[index] = updated
    }
    return updated
  }

  async function deleteAgent(id: string) {
    await apiCall(`/${id}`, { method: 'DELETE' })
    agentList.value = agentList.value.filter((a) => a.id !== id)
    if (currentAgent.value?.id === id) {
      currentAgent.value = null
    }
  }

  return {
    agentList,
    currentAgent,
    loading,
    fetchAgents,
    fetchAgent,
    createAgent,
    updateAgent,
    deleteAgent,
  }
})
```

- [ ] **Step 2: Commit**

```bash
git add src/stores/agent-team.ts
git commit -m "refactor: agent-team store to use user_agents table with field mapping"
```

---

### Task 10: i18n 更新

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: 添加新的 i18n key**

在 `zh-CN.ts` 的 `pages.agentTeam` 区域添加：

```typescript
create: {
  // ... existing keys ...
  allCategories: '全部',
}
```

在 `en-US.ts` 的 `pages.agentTeam` 区域添加：

```typescript
create: {
  // ... existing keys ...
  allCategories: 'All',
}
```

同时确保所有新模板的名称和描述都有对应的 i18n key。但模板的 name 和 description 已直接使用中文定义在 `agent-templates.ts` 中，不需要额外的 i18n key。

- [ ] **Step 2: Commit**

```bash
git add src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: add i18n keys for category tabs"
```

---

### Task 11: 集成测试和验证

**Files:**
- None (manual testing)

- [ ] **Step 1: 启动全栈开发环境**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./restart.sh`

- [ ] **Step 2: 验证创建流程**

1. 打开数字员工页面
2. 点击创建 → 确认看到 12 个分类 Tab
3. 选择一个分类（如"编程开发"），看到 3 个模板卡片
4. 选择"代码助手"模板 → 确认创建成功
5. 进入编辑页 → 确认 4 个 md 标签都有预填内容
6. 编辑 md → 确认自动保存成功（检查 Gateway agent workspace）

- [ ] **Step 3: 验证列表和删除**

1. 返回列表页 → 确认新创建的 agent 显示
2. 创建多个不同分类的 agent
3. 删除一个 agent → 确认 Gateway 和本地都清理

- [ ] **Step 4: 验证 Gateway 离线场景**

1. 断开 Gateway 连接
2. 确认列表仍可展示（本地元数据）
3. 确认创建失败有友好提示

- [ ] **Step 5: 最终 Commit**

```bash
git add -A
git commit -m "feat: digital employee v2 - Gateway-driven with 30+ categorized templates"
```

---

## Self-Review Checklist

- **Spec coverage**: All 3 improvements covered — categories (Task 4-5), md defaults (Task 4), Gateway integration (Task 1-3, 7-9)
- **Placeholder scan**: No TBD/TODO found. All steps have complete code.
- **Type consistency**: `AgentTeamMember` type updated in Task 3, used consistently in Tasks 5-9. `gateway_agent_id` → `id` mapping in store's `mapAgent`.
- **Gap check**: i18n update (Task 10) and manual testing (Task 11) included. Delete flow calls Gateway RPC (Task 7).
