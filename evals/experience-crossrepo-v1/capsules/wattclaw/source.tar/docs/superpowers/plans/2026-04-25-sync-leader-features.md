# 同步领导代码功能 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将领导分支的两个功能（频道绑定智能体+Gateway 同步、会话权限隔离）移植到当前代码库。

**Architecture:** 直接从领导代码库 `/Users/renming/Desktop/wattman/openclaw/tmp/token-plant_dev/` 搬运代码，嵌入到当前代码对应位置。后端改 `server/index.js`，前端改类型定义、频道页面、i18n。

**Tech Stack:** Express + better-sqlite3（后端），Vue 3 + Naive UI + vue-i18n（前端）

---

## File Structure

| Action | File | Responsibility |
|--------|------|----------------|
| Modify | `server/index.js` | Gateway 同步函数、频道路由改造、会话权限隔离、事件追踪 |
| Modify | `src/api/types/user.ts` | UserChannel 类型 webhook_url → agent_id |
| Modify | `src/views/channels/UserChannelsPage.vue` | 智能体下拉选择替代 webhook URL |
| Modify | `src/i18n/messages/zh-CN.ts` | 新增频道绑定相关翻译 |
| Modify | `src/i18n/messages/en-US.ts` | 同上英文版 |

---

### Task 1: 后端 — 新增 Gateway 同步函数 + syncSessionsFromGateway

**Files:**
- Modify: `server/index.js`

**源码位置:** 领导代码 line 109-136 (syncSessionsFromGateway)、line 489-613 (syncChannelToGateway + removeChannelFromGateway)

- [ ] **Step 1: 在 gateway.on('connected') 中添加 syncSessionsFromGateway 调用**

找到 line 103 附近：
```js
gateway.on('connected', () => {
  console.log('[Gateway] Connected to OpenClaw')
})
```
改为：
```js
gateway.on('connected', () => {
  console.log('[Gateway] Connected to OpenClaw')
  syncSessionsFromGateway()
})
```

- [ ] **Step 2: 在 gateway.on('connected') 之后添加 syncSessionsFromGateway 函数**

在 gateway.on('connected') 闭合花括号之后、gateway.on('version') 之前，插入（从领导代码 line 109-136 复制）：

```js
async function syncSessionsFromGateway() {
  try {
    const result = await gateway.call('sessions.list', {})
    let sessions = []
    if (Array.isArray(result)) {
      sessions = result
    } else if (result && typeof result === 'object') {
      for (const k of ['sessions', 'items', 'list', 'data', 'recent']) {
        if (Array.isArray(result[k])) {
          sessions = sessions.concat(result[k])
        }
      }
    }
    for (const s of sessions) {
      const sk = s.key || s.sessionKey || ''
      if (!sk) continue
      const agentId = sk.match(/^agent:([^:]+):/)?.[1]
      if (!agentId) continue
      const userIds = getUserIdsByAgentId(agentId)
      for (const uid of userIds) {
        trackSessionForUser(uid, sk, agentId)
      }
    }
    console.log(`[SessionSync] Synced ${sessions.length} sessions from Gateway`)
  } catch (err) {
    console.error('[SessionSync] Failed:', err.message)
  }
}
```

- [ ] **Step 3: 在 gateway.on('event') 中添加 session 追踪**

找到 line 125 附近：
```js
gateway.on('event', (event, payload) => {
  debug('Gateway event:', event, 'payload keys:', payload ? Object.keys(payload) : null)
  broadcastSSE({ type: 'event', event, payload }, payload)
})
```
改为（从领导代码 line 156-169 复制）：
```js
gateway.on('event', (event, payload) => {
  debug('Gateway event:', event, 'payload keys:', payload ? Object.keys(payload) : null)
  if (payload) {
    const sk = payload.sessionKey || payload.session_key || payload.key || ''
    if (sk) {
      const agentId = sk.match(/^agent:([^:]+):/)?.[1]
      if (agentId) {
        const userIds = getUserIdsByAgentId(agentId)
        for (const uid of userIds) {
          trackSessionForUser(uid, sk, agentId)
        }
      }
    }
  }
  broadcastSSE({ type: 'event', event, payload }, payload)
})
```

- [ ] **Step 4: 在 channel 路由之前添加 syncChannelToGateway 函数**

找到 `app.get('/api/user/channels'` 之前，插入（从领导代码 line 489-563 复制）：

```js
async function syncChannelToGateway(channel) {
  if (!gateway.isConnected) {
    return { synced: false, error: 'Gateway not connected' }
  }

  const channelType = channel.channel_type
  const agentId = channel.agent_id
  const config = typeof channel.config === 'string' ? JSON.parse(channel.config) : channel.config

  if (!agentId) {
    return { synced: false, error: 'No agent bound' }
  }

  try {
    const cfgResult = await gateway.call('config.get', {})
    const payload = cfgResult || {}
    const baseHash = payload.hash
    const sourceConfig = payload.sourceConfig || payload.config || payload.parsed || {}
    const existingBindings = Array.isArray(sourceConfig.bindings) ? sourceConfig.bindings : []
    const existingChannels = sourceConfig.channels || {}

    const accountId = agentId

    const channelConfig = existingChannels[channelType] || { enabled: true }
    if (!channelConfig.accounts) channelConfig.accounts = {}

    channelConfig.accounts[accountId] = {
      ...config,
      enabled: true,
      dmPolicy: 'open',
      groupPolicy: 'open',
      connectionMode: config.connectionMode || 'websocket',
    }

    if (!channelConfig.enabled) channelConfig.enabled = true

    const bindingIndex = existingBindings.findIndex(
      b => b.match && b.match.channel === channelType && b.match.accountId === accountId
    )
    const newBinding = {
      agentId,
      match: { channel: channelType, accountId },
    }

    if (bindingIndex >= 0) {
      existingBindings[bindingIndex] = newBinding
    } else {
      existingBindings.push(newBinding)
    }

    const updatedConfig = {
      ...sourceConfig,
      channels: { ...existingChannels, [channelType]: channelConfig },
      bindings: existingBindings,
    }

    await gateway.call('config.patch', {
      raw: JSON.stringify(updatedConfig),
      baseHash,
    })

    const cfgResult2 = await gateway.call('config.get', {})
    const payload2 = cfgResult2 || {}
    const sourceConfig2 = payload2.sourceConfig || payload2.config || payload2.parsed || {}

    await gateway.call('config.apply', {
      raw: JSON.stringify(sourceConfig2),
      baseHash: payload2.hash,
    })

    return { synced: true }
  } catch (err) {
    console.error('[ChannelSync] failed:', err.message)
    return { synced: false, error: err.message }
  }
}
```

- [ ] **Step 5: 在 syncChannelToGateway 之后添加 removeChannelFromGateway 函数**

紧接上一步，插入（从领导代码 line 566-612 复制）：

```js
async function removeChannelFromGateway(channel) {
  if (!gateway.isConnected) return

  const channelType = channel.channel_type
  const agentId = channel.agent_id
  if (!agentId) return

  try {
    const cfgResult = await gateway.call('config.get', {})
    const payload = cfgResult || {}
    const baseHash = payload.hash
    const sourceConfig = payload.sourceConfig || payload.config || payload.parsed || {}

    const existingChannels = sourceConfig.channels || {}
    const channelConfig = existingChannels[channelType]
    if (channelConfig && channelConfig.accounts && channelConfig.accounts[agentId]) {
      delete channelConfig.accounts[agentId]
    }

    const existingBindings = Array.isArray(sourceConfig.bindings)
      ? sourceConfig.bindings.filter(
          b => !(b.match && b.match.channel === channelType && b.match.accountId === agentId)
        )
      : []

    const updatedConfig = {
      ...sourceConfig,
      channels: { ...existingChannels, [channelType]: channelConfig || {} },
      bindings: existingBindings,
    }

    await gateway.call('config.patch', {
      raw: JSON.stringify(updatedConfig),
      baseHash,
    })

    const cfgResult2 = await gateway.call('config.get', {})
    const payload2 = cfgResult2 || {}
    const sourceConfig2 = payload2.sourceConfig || payload2.config || payload2.parsed || {}

    await gateway.call('config.apply', {
      raw: JSON.stringify(sourceConfig2),
      baseHash: payload2.hash,
    })
  } catch (err) {
    console.error('[ChannelSync] remove failed:', err.message)
  }
}
```

- [ ] **Step 6: 验证后端启动**

Run: `node -e "import('./server/index.js').catch(() => process.exit(0))"`
Expected: 无报错（可能 Gateway 连接失败，但函数定义应无误）

- [ ] **Step 7: Commit**

```bash
git add server/index.js
git commit -m "feat: add gateway sync functions and session auto-tracking"
```

---

### Task 2: 后端 — 改造频道 CRUD 路由 + agents 路由

**Files:**
- Modify: `server/index.js`

**源码位置:** 领导代码 line 615-708

- [ ] **Step 1: 修改 GET /api/user/agents 路由**

找到现有路由（约 line 390）：
```js
app.get('/api/user/agents', authMiddleware, (req, res) => {
  const agents = getUserAgents(req.currentUser.id)
  res.json({ ok: true, agents })
})
```
改为：
```js
app.get('/api/user/agents', authMiddleware, (req, res) => {
  const agents = getUserAgentsList(req.currentUser.id)
  res.json({ ok: true, agents })
})
```

注意：需要在文件顶部 import 中确认 `getUserAgentsList` 已从 `user-manager.js` 导入。如果没有，添加到 import 行。

- [ ] **Step 2: 替换 POST /api/user/channels 路由**

找到现有路由（约 line 489）：
```js
app.post('/api/user/channels', authMiddleware, (req, res) => {
  const channel = createUserChannel(req.currentUser.id, req.body)
  res.json({ ok: true, channel })
})
```
替换为（从领导代码 line 625-653 复制）：
```js
app.post('/api/user/channels', authMiddleware, async (req, res) => {
  try {
    const { agentId } = req.body
    if (!agentId) {
      return res.status(400).json({ ok: false, error: 'Agent selection is required' })
    }
    const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
    if (!ownedIds.includes(agentId)) {
      return res.status(403).json({ ok: false, error: 'Agent not owned by user' })
    }
    const channel = createUserChannel(req.currentUser.id, req.body)

    const syncResult = await syncChannelToGateway(channel)
    if (syncResult.synced) {
      updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
      channel.status = 'active'
      channel.last_sync_at = Date.now()
    } else {
      updateUserChannel(channel.id, { status: 'error', errorMessage: syncResult.error })
      channel.status = 'error'
      channel.error_message = syncResult.error
    }

    res.json({ ok: true, channel })
  } catch (err) {
    console.error('[Channels] create failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 3: 替换 PUT /api/user/channels/:id 路由**

找到现有路由：
```js
app.put('/api/user/channels/:id', authMiddleware, (req, res) => {
  const owned = getUserChannels(req.currentUser.id)
  if (!owned.find(c => c.id === req.params.id)) {
    return res.status(403).json({ ok: false, error: 'Not your channel' })
  }
  const channel = updateUserChannel(req.params.id, req.body)
  res.json({ ok: true, channel })
})
```
替换为（从领导代码 line 655-691 复制）：
```js
app.put('/api/user/channels/:id', authMiddleware, async (req, res) => {
  try {
    const owned = getUserChannels(req.currentUser.id)
    if (!owned.find(c => c.id === req.params.id)) {
      return res.status(403).json({ ok: false, error: 'Not your channel' })
    }

    const { agentId } = req.body
    if (agentId !== undefined) {
      const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
      if (!ownedIds.includes(agentId)) {
        return res.status(403).json({ ok: false, error: 'Agent not owned by user' })
      }
    }

    const channel = updateUserChannel(req.params.id, req.body)
    if (!channel) {
      return res.status(404).json({ ok: false, error: 'Channel not found' })
    }

    const syncResult = await syncChannelToGateway(channel)
    if (syncResult.synced) {
      updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
      channel.status = 'active'
      channel.last_sync_at = Date.now()
    } else {
      updateUserChannel(channel.id, { status: 'error', errorMessage: syncResult.error })
      channel.status = 'error'
      channel.error_message = syncResult.error
    }

    res.json({ ok: true, channel })
  } catch (err) {
    console.error('[Channels] update failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 4: 替换 DELETE /api/user/channels/:id 路由**

找到现有路由：
```js
app.delete('/api/user/channels/:id', authMiddleware, (req, res) => {
  const owned = getUserChannels(req.currentUser.id)
  if (!owned.find(c => c.id === req.params.id)) {
    return res.status(403).json({ ok: false, error: 'Not your channel' })
  }
  deleteUserChannel(req.params.id)
  res.json({ ok: true })
})
```
替换为（从领导代码 line 693-708 复制）：
```js
app.delete('/api/user/channels/:id', authMiddleware, async (req, res) => {
  try {
    const owned = getUserChannels(req.currentUser.id)
    const channel = owned.find(c => c.id === req.params.id)
    if (!channel) {
      return res.status(403).json({ ok: false, error: 'Not your channel' })
    }

    await removeChannelFromGateway(channel)
    deleteUserChannel(req.params.id)
    res.json({ ok: true })
  } catch (err) {
    console.error('[Channels] delete failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 5: Commit**

```bash
git add server/index.js
git commit -m "feat: channel CRUD with agent binding and gateway sync"
```

---

### Task 3: 后端 — 会话权限隔离（broadcastSSE + RPC 代理）

**Files:**
- Modify: `server/index.js`

**源码位置:** 领导代码 line 138-154 (broadcastSSE)、line 1561-1787 (RPC 部分)

- [ ] **Step 1: 改进 broadcastSSE 函数**

找到现有函数（约 line 138）：
```js
function broadcastSSE(data, rawPayload) {
  const message = `data: ${JSON.stringify(data)}\n\n`
  for (const [id, client] of sseClients) {
    try {
      if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
        const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
        if (sk) {
          const ownedKeys = getUserOwnedSessionKeys(client.userId)
          if (!ownedKeys.includes(sk)) {
            continue
          }
        }
      }
      client.res.write(message)
    } catch (e) {
      sseClients.delete(id)
    }
  }
}
```
替换为（从领导代码搬运）：
```js
function broadcastSSE(data, rawPayload) {
  const message = `data: ${JSON.stringify(data)}\n\n`
  for (const [id, client] of sseClients) {
    try {
      if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
        const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
        if (sk) {
          const ownedKeys = getUserOwnedSessionKeys(client.userId)
          if (ownedKeys.includes(sk)) {
            client.res.write(message)
          } else {
            const agentId = sk.match(/^agent:([^:]+):/)?.[1]
            if (agentId) {
              const ownedAgents = getUserOwnedAgentIds(client.userId)
              if (ownedAgents.includes(agentId)) {
                trackSessionForUser(client.userId, sk, agentId)
                client.res.write(message)
              }
            }
          }
          continue
        }
      }
      client.res.write(message)
    } catch (e) {
      sseClients.delete(id)
    }
  }
}
```

- [ ] **Step 2: 在 RPC handler 中添加 isSessionOwned 和 filterOwnedSessions 闭包**

在 `app.post('/api/rpc'...)` handler 中，找到 `const isAdmin = req.currentUser.role === 'admin'` 和 `const userId = req.currentUser.id` 之后、`const normMethod = ...` 之后，`try {` 之前的位置，插入（从领导代码 line 1561-1582 复制）：

```js
  function isSessionOwned(sessionKey) {
    if (!sessionKey) return false
    const ownedKeys = getUserOwnedSessionKeys(userId)
    if (ownedKeys.includes(sessionKey)) return true
    const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1]
    if (agentId) {
      const ownedAgents = getUserOwnedAgentIds(userId)
      if (ownedAgents.includes(agentId)) {
        trackSessionForUser(userId, sessionKey, agentId)
        return true
      }
    }
    return false
  }

  function filterOwnedSessions(list) {
    if (!Array.isArray(list)) return list
    return list.filter(s => {
      const key = s.key || s.sessionKey || ''
      return key && isSessionOwned(key)
    })
  }
```

- [ ] **Step 3: 替换 sessions.list 处理逻辑**

找到 `if (normMethod === 'sessions.list' || normMethod === 'session.list')` 块（约 line 1450），将整个块替换为：

```js
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        const result = await gateway.call(method, params)
        if (Array.isArray(result)) {
          return res.json({ ok: true, payload: filterOwnedSessions(result) })
        }
        if (result && typeof result === 'object') {
          const arrayKeys = ['sessions', 'items', 'list', 'data', 'recent']
          for (const k of arrayKeys) {
            if (Array.isArray(result[k])) {
              result[k] = filterOwnedSessions(result[k])
            }
          }
        }
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 4: 替换 sessions.reset 处理逻辑**

找到 `if (normMethod === 'sessions.reset' || normMethod === 'session.reset')` 块，替换为：

```js
      if (normMethod === 'sessions.reset' || normMethod === 'session.reset') {
        const sk = params?.key || params?.sessionKey
        if (sk && !isSessionOwned(sk)) {
          return res.status(403).json({ ok: false, error: { message: 'Access denied' } })
        }
        const result = await gateway.call(method, params)
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 5: 替换 sessions.delete 处理逻辑**

找到 `if (normMethod === 'sessions.delete' || normMethod === 'session.delete')` 块，替换为：

```js
      if (normMethod === 'sessions.delete' || normMethod === 'session.delete') {
        const sk = params?.key || params?.sessionKey
        if (sk && !isSessionOwned(sk)) {
          return res.status(403).json({ ok: false, error: { message: 'Access denied' } })
        }
        const result = await gateway.call(method, params)
        if (sk) removeSessionForUser(userId, sk)
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 6: 替换 sessions.get / sessions.history 处理逻辑**

找到 `if (normMethod === 'sessions.get' || normMethod === 'session.get' || normMethod === 'sessions.history' || normMethod === 'session.history')` 块，替换为：

```js
      if (normMethod === 'sessions.get' || normMethod === 'session.get' || normMethod === 'sessions.history' || normMethod === 'session.history') {
        const sk = params?.key || params?.sessionKey
        if (sk && !isSessionOwned(sk)) {
          return res.json({ ok: true, payload: [] })
        }
        const result = await gateway.call(method, params)
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 7: 在 sessions.history 块之后、status 块之前添加 chat.history 和 sessions.export**

插入（从领导代码 line 1728-1787 复制）：

```js
      if (normMethod === 'chat.history') {
        const sk = params?.sessionKey || params?.key || params?.session
        if (sk && !isSessionOwned(sk)) {
          return res.json({ ok: true, payload: [] })
        }
        const result = await gateway.call(method, params)
        return res.json({ ok: true, payload: result })
      }
```

同时找到现有的 `sessions.export` 块（如果有），替换为：

```js
      if (normMethod === 'sessions.export' || normMethod === 'session.export') {
        const sk = params?.key || params?.sessionKey
        if (sk && !isSessionOwned(sk)) {
          return res.json({ ok: true, payload: null })
        }
        const result = await gateway.call(method, params)
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 8: 替换 status 处理逻辑中的 filterByAgent**

找到 `if (normMethod === 'status')` 块中的内联 `filterByAgent`，替换为使用 `filterOwnedSessions`（从领导代码 line 1737-1752 复制）：

```js
      if (normMethod === 'status') {
        const result = await gateway.call(method, params)
        if (result && result.sessions) {
          const ownedAgentIds = getUserOwnedAgentIds(userId)
          if (result.sessions.recent) result.sessions.recent = filterOwnedSessions(result.sessions.recent)
          if (result.sessions.byAgent) {
            result.sessions.byAgent = result.sessions.byAgent
              .filter(ba => ownedAgentIds.includes(ba.agentId))
              .map(ba => ({
                ...ba,
                recent: filterOwnedSessions(ba.recent),
              }))
          }
        }
        return res.json({ ok: true, payload: result })
      }
```

- [ ] **Step 9: 替换 sessions.usage 处理逻辑**

找到 sessions.usage 块，替换为：

```js
      if (normMethod === 'session.usage' || normMethod === 'sessions.usage' || normMethod === 'usage.sessions') {
        const result = await gateway.call(method, params)
        if (result && Array.isArray(result.sessions)) {
          result.sessions = filterOwnedSessions(result.sessions)
        }
        return res.json({ ok: true, payload: result })
      }
```

注意：这里同时匹配 `session.usage` 和 `sessions.usage`，确保兼容。

- [ ] **Step 10: 在 session.spawn / session.send / chat.send / agent 中添加自动追踪 agent**

对每个已存在的 session 操作方法，在 `trackSessionForUser` 调用之后添加（从领导代码 line 1625-1628 复制）：

```js
if (agentId) {
  const ownedAgentIds = getUserOwnedAgentIds(userId)
  if (!ownedAgentIds.includes(agentId)) trackAgentForUser(userId, agentId, agentId)
}
```

涉及的方法：
- `session.spawn` / `sessions.spawn`
- `session.send` / `sessions.send`
- `chat.send`
- `agent`

每个方法中找到 `trackSessionForUser(userId, sk, agentId` 调用，在其后插入上述 4 行。

- [ ] **Step 11: Commit**

```bash
git add server/index.js
git commit -m "feat: session permission isolation with ownership checks"
```

---

### Task 4: 前端 — 类型定义改造

**Files:**
- Modify: `src/api/types/user.ts`

**源码位置:** 领导代码 `src/api/types/user.ts`

- [ ] **Step 1: 修改 UserChannel 接口**

找到 `webhook_url: string | null`，替换为 `agent_id: string | null`：

```ts
export interface UserChannel {
  id: string
  user_id: string
  channel_type: ChannelType
  name: string
  agent_id: string | null
  config: Record<string, unknown>
  status: 'active' | 'inactive' | 'error'
  last_sync_at: number | null
  error_message: string | null
  created_at: number
  updated_at: number
}
```

- [ ] **Step 2: 修改 CreateUserChannelParams 接口**

找到 `webhookUrl?: string`，替换为 `agentId: string`（required）：

```ts
export interface CreateUserChannelParams {
  channelType: ChannelType
  name: string
  agentId: string
  config?: Record<string, unknown>
  status?: 'active' | 'inactive'
}
```

- [ ] **Step 3: 修改 UpdateUserChannelParams 接口**

找到 `webhookUrl?: string`，替换为 `agentId?: string`：

```ts
export interface UpdateUserChannelParams {
  name?: string
  agentId?: string
  config?: Record<string, unknown>
  status?: 'active' | 'inactive' | 'error'
  errorMessage?: string
}
```

- [ ] **Step 4: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 可能有 UserChannelsPage.vue 中的类型错误（下一步修复）

- [ ] **Step 5: Commit**

```bash
git add src/api/types/user.ts
git commit -m "feat: update channel types - webhook_url to agent_id"
```

---

### Task 5: 前端 — UserChannelsPage.vue 改造

**Files:**
- Modify: `src/views/channels/UserChannelsPage.vue`

**源码位置:** 领导代码 `src/views/channels/UserChannelsPage.vue`

- [ ] **Step 1: 修改 form ref**

找到 `webhookUrl: ''`，改为 `agentId: ''`。同时添加智能体相关变量：

```ts
interface AgentOption {
  gateway_agent_id: string
  name: string
}

const agentOptions = ref<AgentOption[]>([])
const syncing = ref(false)

const form = ref({
  channelType: 'feishu' as ChannelType,
  name: '',
  agentId: '',
})
```

添加 computed：
```ts
const agentSelectOptions = computed(() =>
  agentOptions.value.map(a => ({
    label: `${a.name} (${a.gateway_agent_id})`,
    value: a.gateway_agent_id,
  }))
)
```

添加 loadAgents 函数：
```ts
async function loadAgents() {
  try {
    const token = authStore.getToken()
    const res = await fetch('/api/user/agents', {
      headers: { 'Authorization': `Bearer ${token}` },
    })
    const data = await res.json()
    if (data.ok) {
      agentOptions.value = data.agents
    }
  } catch (e) {
    console.error('[Channels] load agents failed:', e)
  }
}
```

添加辅助函数：
```ts
function getAgentName(agentId: string | null) {
  if (!agentId) return '-'
  const agent = agentOptions.value.find(a => a.gateway_agent_id === agentId)
  return agent ? agent.name : agentId
}
```

- [ ] **Step 2: 修改表格列**

找到 `webhook_url` 列定义，替换为智能体列：

```ts
{
  title: t('pages.userChannels.boundAgent'),
  key: 'agent_id',
  width: 160,
  render(row: UserChannel) {
    return h('span', getAgentName(row.agent_id))
  },
},
```

同时修改 status 列的渲染，使用 i18n：
```ts
const label = row.status === 'active'
  ? t('pages.userChannels.synced')
  : row.status === 'error'
    ? t('pages.userChannels.syncFailed')
    : row.status
return h(NTag, { type: typeMap[row.status] || 'default', size: 'small' }, {
  default: () => label,
})
```

- [ ] **Step 3: 修改 handleCreate 函数**

替换为（从领导代码搬运核心逻辑）：

```ts
async function handleCreate() {
  if (!form.value.name) {
    message.error(t('pages.userChannels.nameRequired'))
    return
  }
  if (!form.value.agentId) {
    message.error(t('pages.userChannels.agentRequired'))
    return
  }
  syncing.value = true
  try {
    const token = authStore.getToken()
    const res = await fetch('/api/user/channels', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({
        channelType: form.value.channelType,
        name: form.value.name,
        agentId: form.value.agentId,
        config: configFields.value,
      }),
    })
    const data = await res.json()
    if (data.ok) {
      showCreateModal.value = false
      if (data.channel.status === 'active') {
        message.success(t('pages.userChannels.createSyncSuccess'))
      } else {
        message.warning(t('pages.userChannels.createSuccessButSyncFailed', { error: data.channel.error_message }))
      }
      loadChannels()
    } else {
      message.error(t('pages.userChannels.createFailed') + ': ' + data.error)
    }
  } catch {
    message.error(t('pages.userChannels.createFailed'))
  } finally {
    syncing.value = false
  }
}
```

- [ ] **Step 4: 修改 handleConfigSave 函数**

同样的模式，添加 agentId 校验和 syncing 状态。

- [ ] **Step 5: 修改模板 — 创建弹窗**

将 webhook URL 的 NFormItem 替换为智能体选择：

```html
<NFormItem :label="t('pages.userChannels.boundAgent')" required>
  <NSelect
    v-model:value="form.agentId"
    :options="agentSelectOptions"
    :placeholder="t('pages.userChannels.agentPlaceholder')"
  />
</NFormItem>
```

保存按钮添加 `:loading="syncing"`。

- [ ] **Step 6: 修改模板 — 编辑弹窗**

同上，替换 webhook URL 为智能体选择。

- [ ] **Step 7: 修改 onMounted**

```ts
onMounted(() => {
  loadAgents()
  loadChannels()
})
```

- [ ] **Step 8: 修改 openConfig 函数**

将 `webhookUrl: channel.webhook_url || ''` 改为 `agentId: channel.agent_id || ''`。

- [ ] **Step 9: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: PASS

- [ ] **Step 10: Commit**

```bash
git add src/views/channels/UserChannelsPage.vue
git commit -m "feat: channel page with agent selection dropdown"
```

---

### Task 6: i18n — 新增翻译 key

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: 在 zh-CN.ts 的 pages.userChannels 中添加新 key**

在现有 `deleteFailed` 之后，添加：

```ts
agentRequired: '请选择要绑定的智能体',
boundAgent: '绑定智能体',
agentPlaceholder: '请选择智能体',
synced: '已同步',
syncFailed: '同步失败',
createSyncSuccess: '频道创建成功，已同步到 Gateway',
createSuccessButSyncFailed: '频道已创建，但同步到 Gateway 失败：{error}',
updateSyncSuccess: '频道更新成功，已同步到 Gateway',
updateSuccessButSyncFailed: '频道已更新，但同步到 Gateway 失败：{error}',
```

同时更新现有 key 的值：
- `subtitle` → `'管理您的消息渠道并与智能体绑定，实现消息双向转发'`
- `frameworkNote` → `'添加频道时请选择要绑定的智能体。保存后系统会自动将频道配置同步到 Gateway，消息将通过绑定关系路由到对应智能体。'`
- `confirmDelete` → `'确定删除该频道吗？删除后将从 Gateway 移除对应配置。'`
- `deleteSuccess` → `'频道已删除，已从 Gateway 移除配置'`

- [ ] **Step 2: 在 en-US.ts 的 pages.userChannels 中添加对应英文 key**

同样的 key，英文值：
```ts
agentRequired: 'Please select an agent to bind',
boundAgent: 'Bound Agent',
agentPlaceholder: 'Select agent',
synced: 'Synced',
syncFailed: 'Sync Failed',
createSyncSuccess: 'Channel created and synced to Gateway',
createSuccessButSyncFailed: 'Channel created, but Gateway sync failed: {error}',
updateSyncSuccess: 'Channel updated and synced to Gateway',
updateSuccessButSyncFailed: 'Channel updated, but Gateway sync failed: {error}',
```

同样更新现有 key：
- `subtitle` → `'Manage your messaging channels and bind them to agents for bidirectional message routing'`
- `frameworkNote` → `'Select an agent when adding a channel. After saving, the system will automatically sync the channel configuration to Gateway, and messages will be routed to the bound agent.'`
- `confirmDelete` → `'Are you sure you want to delete this channel? The corresponding Gateway configuration will also be removed.'`
- `deleteSuccess` → `'Channel deleted, Gateway configuration removed'`

- [ ] **Step 3: Commit**

```bash
git add src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: add channel agent binding i18n translations"
```

---

### Task 7: 最终验证

- [ ] **Step 1: 类型检查** — `npx vue-tsc --noEmit`
- [ ] **Step 2: 启动服务** — `./restart.sh`
- [ ] **Step 3: 功能验证清单**
  - 频道页面：智能体下拉框正常显示
  - 创建频道：选择智能体 → 创建 → 同步 Gateway → 状态显示"已同步"
  - 编辑频道：修改智能体 → 保存 → 重新同步
  - 删除频道：删除 → Gateway 配置移除
  - 会话隔离：user1 看不到 user2 的会话
  - 会话操作：reset/delete/get 非本人会话返回 403
