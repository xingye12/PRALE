# AI 工作台（Workspace）实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为 WattClaw 新增"AI 工作台"模块，用户可从数字员工进入对话，左侧显示 agent/会话列表，右侧聊天区支持模型切换、附件发送、思考过程展示。

**Architecture:** 独立 Store（workspace.ts）+ 独立页面（views/workspace/），复用 rpc-client.ts 通信层和 server/index.js 后端代理。不修改现有 chat store 和 ChatPage。

**Tech Stack:** Vue 3 + TypeScript + Pinia + Naive UI + vue-i18n

**Spec:** `docs/superpowers/specs/2026-04-27-ai-workspace-design.md`

---

## File Structure

```
新建：
  src/views/workspace/WorkspacePage.vue        主页面（左右分栏）
  src/views/workspace/WorkspaceSidebar.vue     左侧栏（agent + 会话列表）
  src/views/workspace/ChatHeader.vue           顶栏
  src/views/workspace/ChatInput.vue            底部输入区
  src/views/workspace/MessageList.vue          消息列表
  src/views/workspace/ThinkingBlock.vue        思考中组件
  src/views/workspace/WelcomeScreen.vue        欢迎页
  src/stores/workspace.ts                      工作台 Store

修改：
  src/router/routes.ts                         添加 /workspace 路由
  src/i18n/messages/zh-CN.ts                   中文文案
  src/i18n/messages/en-US.ts                   英文文案
  src/views/agent-team/AgentCard.vue           启用"去对话"按钮

不修改：
  server/index.js                              后端完全复用
  src/stores/chat.ts                           现有在线对话不动
  src/views/chat/ChatPage.vue                  现有在线对话不动
  src/api/rpc-client.ts                        直接复用现有方法
```

---

### Task 1: 路由 + i18n 基础

**Files:**
- Modify: `src/router/routes.ts`
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: 添加 /workspace 路由**

在 `src/router/routes.ts` 的 `children` 数组中，`agentTeam` 路由后面添加：

```typescript
{
  path: 'workspace',
  name: 'Workspace',
  component: () => import('@/views/workspace/WorkspacePage.vue'),
  meta: { titleKey: 'routes.workspace', icon: 'ChatboxEllipsesOutline' },
},
```

- [ ] **Step 2: 添加中文 i18n key**

在 `src/i18n/messages/zh-CN.ts` 的 `routes` 对象中添加：

```typescript
workspace: 'AI 工作台',
```

在 `pages` 对象中添加（与 `chat` 同级）：

```typescript
workspace: {
  title: 'AI 工作台',
  sidebar: {
    search: '搜索对话...',
    newChat: '新对话',
    sessions: '{count} 个会话',
    noSessions: '暂无会话',
    noAgents: '暂无数字员工',
    noAgentsHint: '请先在"数字员工"页面创建',
  },
  chat: {
    placeholder: '输入消息...',
    send: '发送',
    model: '选择模型',
    attach: '添加附件',
    thinking: '思考中...',
    thoughtFor: '已思考 {seconds} 秒',
    expand: '展开',
    collapse: '收起',
    messages: '{count} 条消息',
    welcome: '选择一个数字员工开始对话',
    welcomeHint: '从左侧选择一个数字员工，或从"数字员工"页面点击"去对话"',
  },
  session: {
    rename: '重命名',
    delete: '删除',
    deleteConfirm: '确认删除该会话？',
  },
},
```

- [ ] **Step 3: 添加英文 i18n key**

在 `src/i18n/messages/en-US.ts` 的 `routes` 对象中添加：

```typescript
workspace: 'AI Workspace',
```

在 `pages` 对象中添加：

```typescript
workspace: {
  title: 'AI Workspace',
  sidebar: {
    search: 'Search conversations...',
    newChat: 'New Chat',
    sessions: '{count} sessions',
    noSessions: 'No sessions',
    noAgents: 'No digital employees',
    noAgentsHint: 'Please create one on the "Digital Employees" page',
  },
  chat: {
    placeholder: 'Type a message...',
    send: 'Send',
    model: 'Select model',
    attach: 'Add attachment',
    thinking: 'Thinking...',
    thoughtFor: 'Thought for {seconds}s',
    expand: 'Expand',
    collapse: 'Collapse',
    messages: '{count} messages',
    welcome: 'Select a digital employee to start',
    welcomeHint: 'Choose from the sidebar or click "Chat" on the Digital Employees page',
  },
  session: {
    rename: 'Rename',
    delete: 'Delete',
    deleteConfirm: 'Delete this session?',
  },
},
```

- [ ] **Step 4: 验证编译通过**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -30`

Expected: 编译通过或仅有 workspace 相关文件的 import 错误（因为页面还没创建）

- [ ] **Step 5: Commit**

```bash
git add src/router/routes.ts src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: add AI workspace route and i18n keys"
```

---

### Task 2: Workspace Store

**Files:**
- Create: `src/stores/workspace.ts`

- [ ] **Step 1: 创建 workspace store 基础结构**

创建 `src/stores/workspace.ts`：

```typescript
import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { useWebSocketStore } from './websocket'
import { useAgentTeamStore } from './agent-team'
import type { ChatMessage, Session } from '@/api/types'

export interface AgentWithSessions {
  agentId: string
  name: string
  avatar: string
  category: string
  expanded: boolean
  sessions: Session[]
  loadingSessions: boolean
}

export const useWorkspaceStore = defineStore('workspace', () => {
  const wsStore = useWebSocketStore()
  const agentTeamStore = useAgentTeamStore()

  // --- State ---
  const agents = ref<AgentWithSessions[]>([])
  const selectedAgentId = ref<string | null>(null)
  const activeSessionKey = ref<string | null>(null)
  const messages = ref<ChatMessage[]>([])
  const loading = ref(false)
  const sending = ref(false)
  const lastError = ref<string | null>(null)
  const availableModels = ref<string[]>([])

  // 流式消息缓冲
  let pendingStreamMessages: ChatMessage[] = []
  let streamFlushRaf: number | null = null

  // --- Computed ---
  const selectedAgent = computed(() =>
    agents.value.find((a) => a.agentId === selectedAgentId.value) ?? null
  )

  const activeSession = computed(() => {
    if (!activeSessionKey.value || !selectedAgent.value) return null
    return selectedAgent.value.sessions.find((s) => s.key === activeSessionKey.value) ?? null
  })

  // --- Agent 管理 ---
  async function loadAgents() {
    if (agentTeamStore.agentList.length === 0) {
      await agentTeamStore.fetchAgents()
    }
    agents.value = agentTeamStore.agentList.map((a) => ({
      agentId: a.agentId,
      name: a.name,
      avatar: a.avatar || '🤖',
      category: a.category || '',
      expanded: false,
      sessions: [],
      loadingSessions: false,
    }))
  }

  async function selectAgent(agentId: string) {
    selectedAgentId.value = agentId
    activeSessionKey.value = null
    messages.value = []

    const agent = agents.value.find((a) => a.agentId === agentId)
    if (agent) {
      agent.expanded = true
      await loadAgentSessions(agentId)
    }
  }

  async function loadAgentSessions(agentId: string) {
    const agent = agents.value.find((a) => a.agentId === agentId)
    if (!agent) return

    agent.loadingSessions = true
    try {
      const allSessions = await wsStore.rpc.value.listSessions()
      agent.sessions = allSessions.filter((s) => s.agentId === agentId)
    } catch {
      agent.sessions = []
    } finally {
      agent.loadingSessions = false
    }
  }

  // --- 会话管理 ---
  async function selectSession(sessionKey: string) {
    activeSessionKey.value = sessionKey
    messages.value = []
    loading.value = true
    try {
      messages.value = await wsStore.rpc.value.listChatHistory(sessionKey)
    } catch {
      messages.value = []
    } finally {
      loading.value = false
    }
  }

  async function startNewChat(agentId: string) {
    const uuid = Math.random().toString(36).slice(2, 10)
    const sessionKey = `agent:${agentId}:${uuid}`
    activeSessionKey.value = sessionKey
    messages.value = []
  }

  // --- 消息发送 ---
  async function sendMessage(content: string, model?: string) {
    const text = content.trim()
    if (!text) return
    if (!selectedAgentId.value) return

    // 如果没有活跃会话，自动创建
    if (!activeSessionKey.value) {
      const uuid = Math.random().toString(36).slice(2, 10)
      activeSessionKey.value = `agent:${selectedAgentId.value}:${uuid}`
    }

    const idempotencyKey = `ws-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`

    // 本地添加用户消息
    const localMessage: ChatMessage = {
      id: idempotencyKey,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    }
    messages.value = [...messages.value, localMessage]

    sending.value = true
    lastError.value = null
    try {
      await wsStore.rpc.value.sendChatMessage({
        sessionKey: activeSessionKey.value,
        message: text,
        model: model?.trim() || undefined,
        idempotencyKey,
      })
    } catch (error) {
      lastError.value = error instanceof Error ? error.message : String(error)
      messages.value = messages.value.filter((item) => item.id !== idempotencyKey)
      throw error
    } finally {
      sending.value = false
    }
  }

  // --- SSE 事件处理 ---
  function handleEvent(event: string, payload: unknown) {
    if (!activeSessionKey.value) return

    // 从 payload 提取 sessionKey，过滤非当前会话的事件
    const payloadRecord = payload as Record<string, unknown> | null
    if (!payloadRecord) return
    const eventSessionKey = payloadRecord.sessionKey as string | undefined
    if (eventSessionKey && eventSessionKey !== activeSessionKey.value) return

    if (event === 'chat.delta' || event === 'chat.final') {
      const realtimeMessages = extractMessages(payload)
      if (event === 'chat.delta') {
        pendingStreamMessages.push(...realtimeMessages)
        if (streamFlushRaf === null) {
          streamFlushRaf = requestAnimationFrame(() => {
            streamFlushRaf = null
            if (pendingStreamMessages.length === 0) return
            const batch = pendingStreamMessages
            pendingStreamMessages = []
            mergeMessages(batch)
          })
        }
      } else {
        mergeMessages(realtimeMessages)
      }
    }

    if (event === 'chat.final') {
      // 刷新左侧会话列表
      if (selectedAgentId.value) {
        loadAgentSessions(selectedAgentId.value)
      }
    }
  }

  function extractMessages(payload: unknown): ChatMessage[] {
    const p = payload as Record<string, unknown> | null
    if (!p) return []
    if (Array.isArray(p.messages)) return p.messages as ChatMessage[]
    if (Array.isArray(p.items)) return p.items as ChatMessage[]
    if (p.message) return [p.message as ChatMessage]
    if (p.data) return Array.isArray(p.data) ? p.data as ChatMessage[] : [p.data as ChatMessage]
    return []
  }

  function mergeMessages(nextMessages: ChatMessage[]) {
    if (nextMessages.length === 0) return
    const list = [...messages.value]
    for (const next of nextMessages) {
      if (next.id) {
        const existingIndex = list.findIndex((item) => item.id && item.id === next.id)
        if (existingIndex >= 0) {
          const existing = list[existingIndex]
          if (!existing) continue
          list[existingIndex] = next.content.length >= existing.content.length
            ? { ...existing, ...next }
            : existing
          continue
        }
      }
      const last = list[list.length - 1]
      if (last && last.role === next.role && next.content.startsWith(last.content)) {
        list[list.length - 1] = { ...last, ...next }
        continue
      }
      list.push(next)
    }
    messages.value = list
  }

  // --- 模型列表 ---
  async function loadModels() {
    try {
      const config = await wsStore.rpc.value.getConfig()
      const configRecord = config as Record<string, unknown> | null
      if (!configRecord) return
      // 尝试从 config 中提取模型列表
      const models = configRecord.models as string[] | undefined
      if (Array.isArray(models)) {
        availableModels.value = models
        return
      }
      // 尝试从 providers 中提取
      const providers = configRecord.providers as Array<Record<string, unknown>> | undefined
      if (Array.isArray(providers)) {
        const modelSet = new Set<string>()
        for (const provider of providers) {
          if (Array.isArray(provider.models)) {
            for (const m of provider.models) {
              if (typeof m === 'string') modelSet.add(m)
              else if (m && typeof m === 'object' && 'name' in m) modelSet.add((m as { name: string }).name)
            }
          }
        }
        availableModels.value = Array.from(modelSet)
      }
    } catch {
      availableModels.value = []
    }
  }

  // --- 搜索 ---
  const searchQuery = ref('')

  const filteredAgents = computed(() => {
    if (!searchQuery.value.trim()) return agents.value
    const q = searchQuery.value.trim().toLowerCase()
    return agents.value.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.sessions.some(
          (s) => (s.label || s.key).toLowerCase().includes(q)
        )
    )
  })

  return {
    agents,
    selectedAgentId,
    activeSessionKey,
    messages,
    loading,
    sending,
    lastError,
    availableModels,
    searchQuery,
    filteredAgents,
    selectedAgent,
    activeSession,
    loadAgents,
    selectAgent,
    loadAgentSessions,
    selectSession,
    startNewChat,
    sendMessage,
    handleEvent,
    loadModels,
  }
})
```

- [ ] **Step 2: 验证 store 编译**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | grep workspace`

Expected: 无错误或仅有方法签名不匹配（如 getConfig 未在 rpc-client.ts 中定义）

- [ ] **Step 3: 检查 rpc-client.ts 中 getConfig 方法是否存在**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && grep -n 'getConfig\|config\.get' src/api/rpc-client.ts | head -10`

如果不存在，需要在 `loadModels` 中改用 `callWithFallback` 方式调用 `config.get`。根据结果调整 store 中的 `loadModels` 实现。

- [ ] **Step 4: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat: add workspace store with agent/session/message management"
```

---

### Task 3: WorkspacePage 主页面骨架

**Files:**
- Create: `src/views/workspace/WorkspacePage.vue`
- Create: `src/views/workspace/WelcomeScreen.vue`

- [ ] **Step 1: 创建 WelcomeScreen.vue**

创建 `src/views/workspace/WelcomeScreen.vue`：

```vue
<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { NResult, NButton } from 'naive-ui'

const { t } = useI18n()
</script>

<template>
  <div class="welcome-screen">
    <NResult status="info" :title="t('pages.workspace.chat.welcome')" :description="t('pages.workspace.chat.welcomeHint')">
      <template #footer>
        <NButton type="primary" @click="$router.push({ name: 'AgentTeam' })">
          {{ t('routes.agentTeam') }}
        </NButton>
      </template>
    </NResult>
  </div>
</template>

<style scoped>
.welcome-screen {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  padding: 40px;
}
</style>
```

- [ ] **Step 2: 创建 WorkspacePage.vue 主页面**

创建 `src/views/workspace/WorkspacePage.vue`：

```vue
<script setup lang="ts">
import { onMounted, onUnmounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useWorkspaceStore } from '@/stores/workspace'
import { useWebSocketStore } from '@/stores/websocket'
import WorkspaceSidebar from './WorkspaceSidebar.vue'
import ChatHeader from './ChatHeader.vue'
import MessageList from './MessageList.vue'
import ChatInput from './ChatInput.vue'
import WelcomeScreen from './WelcomeScreen.vue'

const route = useRoute()
const { t } = useI18n()
const workspaceStore = useWorkspaceStore()
const wsStore = useWebSocketStore()

let eventCleanup: (() => void) | null = null

onMounted(async () => {
  await workspaceStore.loadAgents()
  await workspaceStore.loadModels()

  // 处理从数字员工页面跳转过来的情况
  const agentId = route.query.agentId as string | undefined
  if (agentId) {
    await workspaceStore.selectAgent(agentId)
    await workspaceStore.startNewChat(agentId)
  }

  // 订阅 SSE 事件
  eventCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as { event: string; payload: unknown }
    workspaceStore.handleEvent(rpcEvent.event, rpcEvent.payload)
  })
})

onUnmounted(() => {
  eventCleanup?.()
})

// 监听路由 query 变化（从数字员工页面跳转）
watch(() => route.query.agentId, async (newAgentId) => {
  if (newAgentId && typeof newAgentId === 'string') {
    await workspaceStore.selectAgent(newAgentId)
    await workspaceStore.startNewChat(newAgentId)
  }
})
</script>

<template>
  <div class="workspace-page">
    <WorkspaceSidebar class="workspace-sidebar" />
    <div class="workspace-main">
      <template v-if="workspaceStore.selectedAgent">
        <ChatHeader />
        <MessageList />
        <ChatInput />
      </template>
      <WelcomeScreen v-else />
    </div>
  </div>
</template>

<style scoped>
.workspace-page {
  display: flex;
  height: 100%;
  overflow: hidden;
}

.workspace-sidebar {
  width: 280px;
  min-width: 280px;
  border-right: 1px solid var(--border-color, #e0e0e0);
  display: flex;
  flex-direction: column;
  background: var(--surface-container-low, #fafafa);
}

.workspace-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  background: var(--surface-bright, #ffffff);
}
</style>
```

- [ ] **Step 3: 验证编译**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: ChatHeader、MessageList、ChatInput 找不到（还没创建），其余无错误

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/WorkspacePage.vue src/views/workspace/WelcomeScreen.vue
git commit -m "feat: add WorkspacePage skeleton with sidebar and welcome screen"
```

---

### Task 4: WorkspaceSidebar 左侧栏

**Files:**
- Create: `src/views/workspace/WorkspaceSidebar.vue`

- [ ] **Step 1: 创建 WorkspaceSidebar.vue**

创建 `src/views/workspace/WorkspaceSidebar.vue`：

```vue
<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { NInput, NButton, NIcon, NEmpty, NSpin } from 'naive-ui'
import { useWorkspaceStore, type AgentWithSessions } from '@/stores/workspace'

const { t } = useI18n()
const workspaceStore = useWorkspaceStore()

function handleAgentClick(agent: AgentWithSessions) {
  if (workspaceStore.selectedAgentId === agent.agentId) {
    // 再次点击同一个 agent → 切换展开/收起
    agent.expanded = !agent.expanded
  } else {
    workspaceStore.selectAgent(agent.agentId)
    workspaceStore.startNewChat(agent.agentId)
  }
}

function handleSessionClick(sessionKey: string) {
  workspaceStore.selectSession(sessionKey)
}

function handleNewChat(agentId: string) {
  workspaceStore.startNewChat(agentId)
}

function formatTime(dateStr?: string): string {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  if (diffMins < 1) return t('common.justNow', '刚刚')
  if (diffMins < 60) return `${diffMins} ${t('common.minutesAgo', '分钟前')}`
  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours} ${t('common.hoursAgo', '小时前')}`
  const diffDays = Math.floor(diffHours / 24)
  if (diffDays < 7) return `${diffDays} ${t('common.daysAgo', '天前')}`
  return date.toLocaleDateString()
}
</script>

<template>
  <div class="workspace-sidebar">
    <!-- 顶栏 -->
    <div class="sidebar-header">
      <span class="sidebar-title">{{ t('pages.workspace.title') }}</span>
      <NButton
        size="tiny"
        type="primary"
        :disabled="!workspaceStore.selectedAgentId"
        @click="workspaceStore.selectedAgentId && handleNewChat(workspaceStore.selectedAgentId)"
      >
        {{ t('pages.workspace.sidebar.newChat') }}
      </NButton>
    </div>

    <!-- 搜索框 -->
    <div class="sidebar-search">
      <NInput
        v-model:value="workspaceStore.searchQuery"
        size="small"
        :placeholder="t('pages.workspace.sidebar.search')"
        clearable
        round
      >
        <template #prefix>
          <span class="material-symbols-outlined" style="font-size: 16px;">search</span>
        </template>
      </NInput>
    </div>

    <!-- Agent 列表 -->
    <div class="sidebar-list">
      <template v-if="workspaceStore.filteredAgents.length">
        <div
          v-for="agent in workspaceStore.filteredAgents"
          :key="agent.agentId"
          class="agent-group"
        >
          <!-- Agent 条目 -->
          <div
            class="agent-item"
            :class="{ active: workspaceStore.selectedAgentId === agent.agentId }"
            @click="handleAgentClick(agent)"
          >
            <span class="agent-avatar">{{ agent.avatar }}</span>
            <div class="agent-info">
              <div class="agent-name">{{ agent.name }}</div>
              <div class="agent-session-count">
                {{ agent.loadingSessions ? '...' : t('pages.workspace.sidebar.sessions', { count: agent.sessions.length }) }}
              </div>
            </div>
            <span class="agent-expand-icon">{{ agent.expanded ? '▼' : '▶' }}</span>
          </div>

          <!-- 会话列表（展开时显示） -->
          <div v-if="agent.expanded" class="session-list">
            <NSpin v-if="agent.loadingSessions" size="small" style="padding: 8px 0; width: 100%;" />
            <template v-else-if="agent.sessions.length">
              <div
                v-for="session in agent.sessions"
                :key="session.key"
                class="session-item"
                :class="{ active: workspaceStore.activeSessionKey === session.key }"
                @click="handleSessionClick(session.key)"
              >
                <div class="session-label">{{ session.label || session.key.split(':').pop() }}</div>
                <div class="session-meta">
                  {{ formatTime(session.lastActivity) }}
                </div>
              </div>
            </template>
            <div v-else class="session-empty">
              {{ t('pages.workspace.sidebar.noSessions') }}
            </div>
          </div>
        </div>
      </template>
      <NEmpty v-else :description="t('pages.workspace.sidebar.noAgents')" style="margin-top: 40px;">
        <template #extra>
          <NButton size="small" @click="$router.push({ name: 'AgentTeam' })">
            {{ t('pages.workspace.sidebar.noAgentsHint') }}
          </NButton>
        </template>
      </NEmpty>
    </div>
  </div>
</template>

<style scoped>
.workspace-sidebar {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-color, #e0e0e0);
}

.sidebar-title {
  font-weight: 600;
  font-size: 15px;
  color: var(--on-surface, #2d3338);
}

.sidebar-search {
  padding: 8px 12px;
}

.sidebar-list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 0;
}

.agent-group {
  margin-bottom: 2px;
}

.agent-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  cursor: pointer;
  transition: background 0.15s;
  border-left: 3px solid transparent;
}

.agent-item:hover {
  background: var(--surface-container, #ebeef3);
}

.agent-item.active {
  background: var(--primary-container, #93aafe22);
  border-left-color: var(--primary, #435ba8);
}

.agent-avatar {
  font-size: 20px;
  flex-shrink: 0;
}

.agent-info {
  flex: 1;
  min-width: 0;
}

.agent-name {
  font-weight: 600;
  font-size: 13px;
  color: var(--on-surface, #2d3338);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.agent-session-count {
  font-size: 11px;
  color: var(--on-surface-variant, #5a6065);
  margin-top: 2px;
}

.agent-expand-icon {
  font-size: 10px;
  color: var(--outline, #757b81);
  flex-shrink: 0;
}

.session-list {
  background: var(--surface-container-low, #f1f4f8);
}

.session-item {
  padding: 6px 12px 6px 44px;
  cursor: pointer;
  transition: background 0.15s;
  border-left: 3px solid transparent;
}

.session-item:hover {
  background: var(--surface-container, #ebeef3);
}

.session-item.active {
  background: var(--primary-container, #93aafe44);
  border-left-color: var(--primary, #435ba8);
}

.session-label {
  font-size: 12px;
  color: var(--on-surface, #2d3338);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.session-meta {
  font-size: 10px;
  color: var(--outline, #757b81);
  margin-top: 2px;
}

.session-empty {
  padding: 8px 12px 8px 44px;
  font-size: 11px;
  color: var(--outline, #757b81);
}
</style>
```

- [ ] **Step 2: 验证编译**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | grep -i sidebar`

Expected: 无 sidebar 相关错误

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/WorkspaceSidebar.vue
git commit -m "feat: add WorkspaceSidebar with agent/session list"
```

---

### Task 5: ChatHeader 顶栏

**Files:**
- Create: `src/views/workspace/ChatHeader.vue`

- [ ] **Step 1: 创建 ChatHeader.vue**

创建 `src/views/workspace/ChatHeader.vue`：

```vue
<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { NText } from 'naive-ui'
import { useWorkspaceStore } from '@/stores/workspace'

const { t } = useI18n()
const workspaceStore = useWorkspaceStore()
</script>

<template>
  <div class="chat-header">
    <div class="chat-header-left">
      <span class="chat-header-avatar">{{ workspaceStore.selectedAgent?.avatar }}</span>
      <span class="chat-header-name">{{ workspaceStore.selectedAgent?.name }}</span>
      <span class="chat-header-divider">|</span>
      <NText depth="3" class="chat-header-session">
        {{ workspaceStore.activeSession?.label || t('pages.workspace.sidebar.newChat') }}
      </NText>
    </div>
    <div class="chat-header-right">
      <NText depth="3" style="font-size: 12px;">
        {{ t('pages.workspace.chat.messages', { count: workspaceStore.messages.length }) }}
      </NText>
    </div>
  </div>
</template>

<style scoped>
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 20px;
  border-bottom: 1px solid var(--border-color, #e0e0e0);
  background: var(--surface-bright, #ffffff);
}

.chat-header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.chat-header-avatar {
  font-size: 18px;
}

.chat-header-name {
  font-weight: 600;
  color: var(--on-surface, #2d3338);
}

.chat-header-divider {
  color: var(--outline-variant, #adb3b8);
}

.chat-header-session {
  font-size: 13px;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add src/views/workspace/ChatHeader.vue
git commit -m "feat: add ChatHeader component"
```

---

### Task 6: ChatInput 底部输入区

**Files:**
- Create: `src/views/workspace/ChatInput.vue`

- [ ] **Step 1: 创建 ChatInput.vue**

创建 `src/views/workspace/ChatInput.vue`：

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { NInput, NButton, NSelect, NTooltip } from 'naive-ui'
import { useWorkspaceStore } from '@/stores/workspace'

const { t } = useI18n()
const workspaceStore = useWorkspaceStore()

const inputText = ref('')
const selectedModel = ref<string | null>(null)
const attachments = ref<File[]>([])

const modelOptions = computed(() =>
  workspaceStore.availableModels.map((m) => ({ label: m, value: m }))
)

function handleSend() {
  const text = inputText.value.trim()
  if (!text || workspaceStore.sending) return

  workspaceStore.sendMessage(text, selectedModel.value || undefined)
  inputText.value = ''
  // attachments 在发送后清除（v1 暂不实现附件上传逻辑）
}

function handleKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    handleSend()
  }
}

function handleFileSelect() {
  const input = document.createElement('input')
  input.type = 'file'
  input.multiple = true
  input.onchange = () => {
    if (input.files) {
      attachments.value = [...attachments.value, ...Array.from(input.files)]
    }
  }
  input.click()
}

function removeAttachment(index: number) {
  attachments.value = attachments.value.filter((_, i) => i !== index)
}
</script>

<template>
  <div class="chat-input-area">
    <!-- 附件预览 -->
    <div v-if="attachments.length" class="attachment-list">
      <div v-for="(file, index) in attachments" :key="index" class="attachment-tag">
        <span class="attachment-icon">📄</span>
        <span class="attachment-name">{{ file.name }}</span>
        <span class="attachment-remove" @click="removeAttachment(index)">✕</span>
      </div>
    </div>

    <!-- 输入行 -->
    <div class="input-row">
      <!-- 模型选择器 -->
      <NSelect
        v-if="modelOptions.length"
        v-model:value="selectedModel"
        :options="modelOptions"
        :placeholder="t('pages.workspace.chat.model')"
        size="small"
        consistent-menu-width
        style="min-width: 140px;"
      />

      <!-- 输入框 -->
      <NInput
        v-model:value="inputText"
        type="textarea"
        :placeholder="t('pages.workspace.chat.placeholder')"
        :autosize="{ minRows: 1, maxRows: 4 }"
        :disabled="workspaceStore.sending"
        @keydown="handleKeydown"
        round
      />

      <!-- 附件按钮 -->
      <NTooltip>
        <template #trigger>
          <NButton circle quaternary @click="handleFileSelect" :disabled="workspaceStore.sending">
            <template #icon>
              <span class="material-symbols-outlined" style="font-size: 18px;">attach_file</span>
            </template>
          </NButton>
        </template>
        {{ t('pages.workspace.chat.attach') }}
      </NTooltip>

      <!-- 发送按钮 -->
      <NButton
        type="primary"
        circle
        :disabled="!inputText.trim() || workspaceStore.sending"
        @click="handleSend"
      >
        <template #icon>
          <span class="material-symbols-outlined" style="font-size: 18px;">send</span>
        </template>
      </NButton>
    </div>
  </div>
</template>

<style scoped>
.chat-input-area {
  padding: 12px 20px 16px;
  border-top: 1px solid var(--border-color, #e0e0e0);
  background: var(--surface-container-low, #fafafa);
}

.attachment-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 8px;
}

.attachment-tag {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  background: var(--surface-container, #ebeef3);
  border-radius: 6px;
  font-size: 11px;
  color: var(--on-surface-variant, #5a6065);
}

.attachment-icon {
  font-size: 12px;
}

.attachment-name {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.attachment-remove {
  cursor: pointer;
  color: var(--outline, #757b81);
  margin-left: 4px;
}

.attachment-remove:hover {
  color: var(--error, #a83836);
}

.input-row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
}
</style>
```

注意：`computed` 需要从 `vue` 导入。如果编译报错，在 `import` 行添加 `computed`。

- [ ] **Step 2: 修复 import（如需要）**

确保 `<script setup>` 顶部有：

```typescript
import { ref, computed } from 'vue'
```

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "feat: add ChatInput with model selector and attachment support"
```

---

### Task 7: MessageList + ThinkingBlock 消息渲染

**Files:**
- Create: `src/views/workspace/MessageList.vue`
- Create: `src/views/workspace/ThinkingBlock.vue`

- [ ] **Step 1: 创建 ThinkingBlock.vue**

创建 `src/views/workspace/ThinkingBlock.vue`：

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'

const props = defineProps<{
  content: string
  duration?: number
  thinking?: boolean
}>()

const { t } = useI18n()
const expanded = ref(false)

const displayText = computed(() => {
  if (props.thinking) return t('pages.workspace.chat.thinking')
  if (props.duration) return t('pages.workspace.chat.thoughtFor', { seconds: props.duration })
  return t('pages.workspace.chat.thinking')
})
</script>

<template>
  <div class="thinking-block">
    <div class="thinking-header" @click="expanded = !expanded">
      <span class="thinking-icon">💡</span>
      <span class="thinking-text">{{ displayText }}</span>
      <span v-if="thinking" class="thinking-spinner">⟳</span>
      <span class="thinking-toggle">
        {{ expanded ? t('pages.workspace.chat.collapse') : t('pages.workspace.chat.expand') }}
      </span>
    </div>
    <div v-if="expanded && content" class="thinking-content">
      {{ content }}
    </div>
  </div>
</template>

<style scoped>
.thinking-block {
  border: 1px solid var(--outline-variant, #e0e0e0);
  border-radius: 10px;
  overflow: hidden;
  max-width: 75%;
}

.thinking-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 14px;
  background: var(--surface-container-low, #fafafa);
  cursor: pointer;
  user-select: none;
}

.thinking-header:hover {
  background: var(--surface-container, #ebeef3);
}

.thinking-icon {
  font-size: 14px;
}

.thinking-text {
  font-size: 13px;
  color: var(--on-surface-variant, #5a6065);
}

.thinking-spinner {
  display: inline-block;
  animation: spin 1.5s linear infinite;
  font-size: 12px;
  color: var(--outline, #757b81);
}

.thinking-toggle {
  margin-left: auto;
  font-size: 11px;
  color: var(--outline, #757b81);
}

.thinking-content {
  padding: 12px 14px;
  font-size: 12px;
  color: var(--on-surface-variant, #5a6065);
  line-height: 1.8;
  background: var(--surface-container-lowest, #ffffff);
  border-top: 1px solid var(--outline-variant, #f0f0f0);
  white-space: pre-wrap;
  max-height: 300px;
  overflow-y: auto;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
```

- [ ] **Step 2: 创建 MessageList.vue**

创建 `src/views/workspace/MessageList.vue`：

```vue
<script setup lang="ts">
import { ref, nextTick, watch } from 'vue'
import { NText } from 'naive-ui'
import { useWorkspaceStore } from '@/stores/workspace'
import ThinkingBlock from './ThinkingBlock.vue'
import type { ChatMessage } from '@/api/types'

const workspaceStore = useWorkspaceStore()
const listRef = ref<HTMLElement | null>(null)
const autoScroll = ref(true)

// 判断消息是否包含思考内容
function getThinkingContent(msg: ChatMessage): { isThinking: boolean; thinking: string; answer: string } {
  const content = msg.content || ''
  // 尝试匹配 <thinking>...</thinking> 标签
  const thinkingMatch = content.match(/<thinking>([\s\S]*?)<\/thinking>/)
  if (thinkingMatch) {
    const thinking = thinkingMatch[1].trim()
    const answer = content.replace(/<thinking>[\s\S]*?<\/thinking>/, '').trim()
    return { isThinking: true, thinking, answer }
  }
  // 检查 rawContent 中的 thinking 部分
  if (msg.rawContent && Array.isArray(msg.rawContent)) {
    const thinkingPart = msg.rawContent.find(
      (b: Record<string, unknown>) => b.type === 'thinking' || b.type === 'thought'
    )
    if (thinkingPart) {
      const textPart = msg.rawContent.find(
        (b: Record<string, unknown>) => b.type === 'text'
      )
      return {
        isThinking: true,
        thinking: (thinkingPart as Record<string, unknown>).text as string || '',
        answer: textPart ? ((textPart as Record<string, unknown>).text as string || '') : '',
      }
    }
  }
  return { isThinking: false, thinking: '', answer: content }
}

// 消息列表变化时自动滚动到底部
watch(
  () => workspaceStore.messages.length,
  async () => {
    if (autoScroll.value) {
      await nextTick()
      listRef.value?.scrollTo({ top: listRef.value.scrollHeight, behavior: 'smooth' })
    }
  }
)

// 检测是否正在流式输出（最后一条是 assistant 且无 stopReason）
const isStreaming = computed(() => {
  const msgs = workspaceStore.messages
  if (msgs.length === 0) return false
  const last = msgs[msgs.length - 1]
  return last.role === 'assistant' && !last.stopReason
})
</script>

<template>
  <div ref="listRef" class="message-list">
    <template v-if="workspaceStore.messages.length">
      <div
        v-for="(msg, index) in workspaceStore.messages"
        :key="msg.id || index"
        class="message-item"
        :class="`is-${msg.role}`"
      >
        <!-- 用户消息 -->
        <div v-if="msg.role === 'user'" class="message-bubble user-bubble">
          <div class="message-content">{{ msg.content }}</div>
        </div>

        <!-- AI 消息 -->
        <template v-else-if="msg.role === 'assistant'">
          <div class="message-row assistant-row">
            <div class="message-avatar">{{ workspaceStore.selectedAgent?.avatar || '🤖' }}</div>
            <div class="message-body">
              <!-- 思考中 -->
              <ThinkingBlock
                v-if="getThinkingContent(msg).isThinking"
                :content="getThinkingContent(msg).thinking"
                :thinking="index === workspaceStore.messages.length - 1 && isStreaming && !getThinkingContent(msg).answer"
              />
              <!-- 回答内容 -->
              <div v-if="getThinkingContent(msg).answer" class="message-bubble assistant-bubble">
                <div class="message-content">{{ getThinkingContent(msg).answer }}</div>
              </div>
            </div>
          </div>
        </template>

        <!-- 工具消息 -->
        <div v-else-if="msg.role === 'tool'" class="message-bubble tool-bubble">
          <div class="message-content">
            <NText depth="3">🔧 {{ msg.toolName || 'Tool' }}</NText>
          </div>
        </div>
      </div>

      <!-- 流式加载中指示器 -->
      <div v-if="workspaceStore.sending && !isStreaming" class="message-item">
        <div class="message-row assistant-row">
          <div class="message-avatar">{{ workspaceStore.selectedAgent?.avatar || '🤖' }}</div>
          <div class="typing-indicator">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>
    </template>

    <!-- 空状态 -->
    <div v-else class="empty-messages">
      <NText depth="3">开始新的对话</NText>
    </div>
  </div>
</template>

<style scoped>
.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.message-item {
  margin-bottom: 16px;
}

/* 用户消息 */
.message-item.is-user {
  display: flex;
  justify-content: flex-end;
}

.user-bubble {
  background: var(--primary, #435ba8);
  color: white;
  border-radius: 12px 12px 2px 12px;
  padding: 10px 16px;
  max-width: 70%;
  line-height: 1.6;
}

.user-bubble .message-content {
  white-space: pre-wrap;
  word-break: break-word;
}

/* AI 消息 */
.assistant-row {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.message-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--surface-container-high, #e4e9ee);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}

.message-body {
  flex: 1;
  max-width: calc(100% - 42px);
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.assistant-bubble {
  max-width: 100%;
}

.assistant-bubble .message-content {
  font-size: 13px;
  line-height: 1.8;
  color: var(--on-surface, #2d3338);
  white-space: pre-wrap;
  word-break: break-word;
}

/* 工具消息 */
.tool-bubble {
  background: var(--surface-container-low, #f1f4f8);
  border-radius: 8px;
  padding: 8px 12px;
  max-width: 70%;
  font-size: 12px;
}

/* 打字指示器 */
.typing-indicator {
  display: flex;
  gap: 4px;
  padding: 12px;
}

.typing-indicator span {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--outline, #757b81);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 80%, 100% { opacity: 0.3; transform: scale(0.8); }
  40% { opacity: 1; transform: scale(1); }
}

/* 空状态 */
.empty-messages {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}
</style>
```

注意：需要在 `<script setup>` 中补充 `import { computed } from 'vue'`。

- [ ] **Step 3: 修复 MessageList import**

确保 MessageList.vue 的 `<script setup>` 顶部有：

```typescript
import { ref, computed, nextTick, watch } from 'vue'
```

- [ ] **Step 4: 验证编译**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: 无 workspace 相关错误

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/MessageList.vue src/views/workspace/ThinkingBlock.vue
git commit -m "feat: add MessageList and ThinkingBlock components"
```

---

### Task 8: AgentCard "去对话"按钮

**Files:**
- Modify: `src/views/agent-team/AgentCard.vue`

- [ ] **Step 1: 启用"去对话"按钮并添加路由跳转**

在 `src/views/agent-team/AgentCard.vue` 中，修改"去对话"按钮：

将原来的 disabled 按钮：

```vue
<NButton
  class="agent-card__chat-btn"
  size="small"
  disabled
  secondary
>
  {{ t('pages.agentTeam.card.chat') }}
</NButton>
```

替换为：

```vue
<NButton
  class="agent-card__chat-btn"
  size="small"
  secondary
  @click="emit('chat', props.agent.agentId)"
>
  {{ t('pages.agentTeam.card.chat') }}
</NButton>
```

- [ ] **Step 2: 在 AgentTeamPage 中处理 chat 事件**

在 `src/views/agent-team/AgentTeamPage.vue` 中，找到 AgentCard 的渲染位置，确保 `@chat` 事件被正确处理：

```vue
<AgentCard
  ...
  @chat="handleChat"
/>
```

添加 `handleChat` 方法：

```typescript
import { useRouter } from 'vue-router'

const router = useRouter()

function handleChat(agentId: string) {
  router.push({ name: 'Workspace', query: { agentId } })
}
```

注意：如果 AgentTeamPage.vue 已经定义了 router 或 handleChat 类似方法，直接复用。

- [ ] **Step 3: 验证**

启动开发服务器，在数字员工页面点击"去对话"按钮，确认跳转到 `/workspace?agentId=xxx`。

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -10`

- [ ] **Step 4: Commit**

```bash
git add src/views/agent-team/AgentCard.vue src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: enable 'go to chat' button on AgentCard"
```

---

### Task 9: SSE 事件集成 + 端到端验证

**Files:**
- Modify: `src/stores/workspace.ts`（如有问题修复）
- Modify: `src/views/workspace/WorkspacePage.vue`（如有问题修复）

- [ ] **Step 1: 验证 rpc-client 方法可用性**

检查 rpc-client.ts 中以下方法是否存在：
- `sendChatMessage` — 已确认存在（行 2681）
- `listChatHistory` — 已确认存在（行 2670）
- `listSessions` — 已确认存在（行 2097）
- `getConfig` — 需检查

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && grep -n 'getConfig\|config\.get' src/api/rpc-client.ts | head -10`

如果 `getConfig` 不存在，需要在 workspace store 的 `loadModels` 中使用 `callWithFallback`：

```typescript
async function loadModels() {
  try {
    const config = await wsStore.rpc.value.callWithFallback<unknown>(
      ['config.get', 'configuration.get']
    )
    // ... 后续解析逻辑不变
  } catch {
    availableModels.value = []
  }
}
```

- [ ] **Step 2: 验证 SSE 事件订阅**

确认 `wsStore.subscribe('event', handler)` 的事件格式：
- 事件对象结构：`{ event: string, payload: unknown }`
- chat 相关事件：`chat.delta`、`chat.final`、`chat.error`、`chat.aborted`

根据实际 SSE 事件格式调整 `workspaceStore.handleEvent` 的实现。

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && grep -n 'subscribe\|chat\.delta\|chat\.final' src/stores/chat.ts | head -15`

- [ ] **Step 3: 启动开发服务器进行端到端测试**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npm run dev:all`

测试步骤：
1. 打开浏览器访问 `http://localhost:3000`
2. 以 admin/admin123 登录
3. 进入"数字员工"页面，确认有数字员工数据
4. 点击某个数字员工卡片的"去对话"按钮
5. 确认跳转到 AI 工作台页面
6. 确认左侧栏显示数字员工列表
7. 确认右侧显示对话区域
8. 输入消息发送，确认消息显示正常
9. 确认 AI 回复正常显示
10. 确认"思考中"组件正常展示

- [ ] **Step 4: 修复端到端测试中发现的问题**

根据测试结果修复问题。常见问题可能包括：
- SSE 事件格式不匹配
- sessionKey 构造格式不对
- 模型列表解析错误
- 流式消息渲染异常

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat: integrate SSE events and complete AI workspace end-to-end"
```

---

### Task 10: 样式打磨 + 暗色模式

**Files:**
- Modify: `src/views/workspace/*.vue`（样式调整）

- [ ] **Step 1: 检查暗色模式兼容性**

启动暗色模式，确认所有工作台组件的 CSS 变量都使用了 `var(--xxx)` 而非硬编码颜色。

重点检查：
- WorkspaceSidebar — 背景、边框、文字颜色
- ChatHeader — 背景、边框
- ChatInput — 背景、输入框样式
- MessageList — 用户气泡、AI 气泡、工具消息
- ThinkingBlock — 背景、边框、文字颜色

- [ ] **Step 2: 修复暗色模式问题**

将任何硬编码的颜色值替换为 CSS 变量。例如：
- `#fafafa` → `var(--surface-container-low, #fafafa)`
- `#e0e0e0` → `var(--border-color, #e0e0e0)`
- `#2d3338` → `var(--on-surface, #2d3338)`

- [ ] **Step 3: 对齐参考图片样式**

参考 `new/img.png` 和 `new/img_1.png`：
- 底部输入区的模型选择器使用胶囊/圆形样式
- 发送按钮使用渐变圆形样式
- 消息气泡圆角和间距对齐

- [ ] **Step 4: 验证**

在亮色和暗色模式下分别测试所有页面元素。

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/
git commit -m "style: polish AI workspace styles and dark mode support"
```

---

### Task 11: 最终提交 + 清理

**Files:**
- Review all workspace files

- [ ] **Step 1: 运行类型检查**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1`

Expected: 0 errors

- [ ] **Step 2: 确认无遗留问题**

- [ ] 所有 workspace 组件已创建
- [ ] 路由正常跳转
- [ ] 数字员工"去对话"按钮可用
- [ ] 左侧栏显示数字员工和会话列表
- [ ] 消息发送和接收正常
- [ ] 思考中组件可展开/收起
- [ ] 模型选择器工作正常
- [ ] 暗色模式兼容
- [ ] i18n 中英文完整

- [ ] **Step 3: 最终 Commit**

```bash
git add -A
git commit -m "feat: complete AI workspace feature"
```
