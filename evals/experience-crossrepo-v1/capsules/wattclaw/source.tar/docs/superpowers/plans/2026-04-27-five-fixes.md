# Five Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement 5 fixes/changes: remove "网关可视化管理系统" naming, model management user isolation, default model for agent creation, and agent card stats.

**Architecture:** Backend adds user-scoped model provider CRUD via SQLite + Gateway sync. Frontend distinguishes admin vs non-admin behavior in ModelsPage. Agent creation reads Gateway primary model as default. Agent stats queried from Gateway session history.

**Tech Stack:** Vue 3, Pinia, Naive UI, Express.js, better-sqlite3, Gateway WebSocket RPC

**Spec:** `docs/superpowers/specs/2026-04-27-five-fixes-design.md`

---

## Task 1: Remove "网关可视化管理系统" Text

**Files:**
- Modify: `index.html:7`
- Modify: `src/i18n/messages/zh-CN.ts:3,102,104,165,1615`
- Modify: `src/i18n/messages/en-US.ts:110,1611`
- Modify: `src/views/Login.vue:140`
- Modify: `src/components/layout/AppSidebar.vue:79`

- [ ] **Step 1: Edit `index.html` — replace title**

Change line 7 from:
```html
<title>WattClaw 网关可视化管理系统</title>
```
to:
```html
<title>WattClaw</title>
```

- [ ] **Step 2: Edit `src/i18n/messages/zh-CN.ts` — 5 replacements**

Line 3, change:
```
title: 'WattClaw 网关可视化管理系统',
```
to:
```
title: 'WattClaw',
```

Line 102, change:
```
title: 'WattClaw 网关可视化管理系统',
```
to:
```
title: 'WattClaw',
```

Line 104, change:
```
description: 'WattClaw 网关可视化管理系统 是一个现代化的 AI 智能体管理平台，为 OpenClaw Gateway 提供完整的 Web 管理界面。通过直观的可视化操作，轻松管理智能体、会话、模型和频道。',
```
to:
```
description: 'WattClaw 是一个现代化的 AI 智能体管理平台，为 OpenClaw Gateway 提供完整的 Web 管理界面。通过直观的可视化操作，轻松管理智能体、会话、模型和频道。',
```

Line 165, change:
```
copyright: '© 2024 WattClaw 网关可视化管理系统. All rights reserved.',
```
to:
```
copyright: '© 2026 WattClaw. All rights reserved.',
```

Line 1615, change:
```
aboutLine1: 'WattClaw 网关管理系统',
```
to:
```
aboutLine1: 'WattClaw',
```

- [ ] **Step 3: Edit `src/i18n/messages/en-US.ts` — 2 replacements**

Line 110, change:
```
title: 'Gateway Management',
```
to:
```
title: 'AI Platform',
```

Line 1611, change:
```
aboutLine1: 'WattClaw Gateway Management System',
```
to:
```
aboutLine1: 'WattClaw',
```

- [ ] **Step 4: Edit `src/views/Login.vue` — replace subtitle**

Line 140, change:
```html
<p class="login-brand-subtitle">网关可视化管理系统</p>
```
to:
```html
<p class="login-brand-subtitle">WattClaw</p>
```

- [ ] **Step 5: Edit `src/components/layout/AppSidebar.vue` — replace subtitle**

Line 79, change:
```html
<p class="logo-subtitle">网关管理系统</p>
```
to:
```html
<p class="logo-subtitle">WattClaw</p>
```

- [ ] **Step 6: Verify — run dev server and check titles**

Run: `npm run dev:all`

Verify:
- Browser tab title shows "WattClaw"
- Login page subtitle shows "WattClaw"
- Sidebar subtitle shows "WattClaw"
- No remaining "网关可视化管理系统" or "网关管理系统" in the UI

- [ ] **Step 7: Commit**

```bash
git add index.html src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts src/views/Login.vue src/components/layout/AppSidebar.vue
git commit -m "refactor: 去掉所有网关可视化管理系统描述，统一为 WattClaw"
```

---

## Task 2: Add `user_model_providers` Database Table + CRUD Helpers

**Files:**
- Modify: `server/database.js` — add table creation after `agent_team` table
- Modify: `server/user-manager.js` — add CRUD functions

- [ ] **Step 1: Add table in `server/database.js`**

After line 237 (`CREATE INDEX IF NOT EXISTS idx_agent_team_created_by ON agent_team(created_by);`), before the closing backtick, add:

```sql
CREATE TABLE IF NOT EXISTS user_model_providers (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  config TEXT NOT NULL DEFAULT '{}',
  is_primary BOOLEAN DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, provider_id)
);

CREATE INDEX IF NOT EXISTS idx_user_model_providers_user ON user_model_providers(user_id);
```

- [ ] **Step 2: Add CRUD helpers in `server/user-manager.js`**

Add these exported functions at the end of the file (before the final `export { ... }` or after the last existing function):

```javascript
// --- User Model Providers ---

export function getUserModelProviders(userId) {
  return db.prepare('SELECT * FROM user_model_providers WHERE user_id = ? ORDER BY created_at DESC').all(userId)
}

export function getUserModelProvider(userId, providerId) {
  return db.prepare('SELECT * FROM user_model_providers WHERE user_id = ? AND provider_id = ?').get(userId, providerId)
}

export function getUserModelProviderById(id) {
  return db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(id)
}

export function createUserModelProvider(userId, providerId, config) {
  const id = randomUUID()
  db.prepare(`
    INSERT INTO user_model_providers (id, user_id, provider_id, config)
    VALUES (?, ?, ?, ?)
  `).run(id, userId, providerId, JSON.stringify(config || {}))
  return db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(id)
}

export function updateUserModelProvider(id, updates) {
  const allowed = ['config', 'isPrimary']
  const fields = []
  const values = []
  for (const key of allowed) {
    if (updates[key] !== undefined) {
      const dbKey = key === 'isPrimary' ? 'is_primary' : key.replace(/([A-Z])/g, '_$1').toLowerCase()
      fields.push(`${dbKey} = ?`)
      values.push(key === 'config' ? JSON.stringify(updates[key]) : updates[key])
    }
  }
  if (fields.length === 0) return null
  fields.push('updated_at = ?')
  values.push(Date.now())
  values.push(id)
  db.prepare(`UPDATE user_model_providers SET ${fields.join(', ')} WHERE id = ?`).run(...values)
  return db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(id)
}

export function deleteUserModelProvider(id) {
  db.prepare('DELETE FROM user_model_providers WHERE id = ?').run(id)
}

export function deleteUserModelProviderByProviderId(userId, providerId) {
  db.prepare('DELETE FROM user_model_providers WHERE user_id = ? AND provider_id = ?').run(userId, providerId)
}

export function setUserModelPrimary(userId, providerId) {
  // Clear all primary flags for user
  db.prepare('UPDATE user_model_providers SET is_primary = 0, updated_at = ? WHERE user_id = ?').run(Date.now(), userId)
  // Set the specified one
  db.prepare('UPDATE user_model_providers SET is_primary = 1, updated_at = ? WHERE user_id = ? AND provider_id = ?').run(Date.now(), userId, providerId)
}
```

Make sure `randomUUID` is imported at the top of the file (it should already be: `import { randomUUID } from 'node:crypto'`).

Also add these new functions to the module's exports.

- [ ] **Step 3: Verify — restart backend, check table exists**

Run: `npm run dev:server`

Check logs for no SQL errors. Table should be created on startup.

- [ ] **Step 4: Commit**

```bash
git add server/database.js server/user-manager.js
git commit -m "feat: 添加 user_model_providers 表和 CRUD 函数"
```

---

## Task 3: Add Model Provider REST API Endpoints

**Files:**
- Modify: `server/index.js` — add routes after agent-team routes (after line 521)

- [ ] **Step 1: Import new functions from user-manager.js**

At the top of `server/index.js`, find the import from `./user-manager.js` and add the new function names:

```javascript
getUserModelProviders,
getUserModelProvider,
getUserModelProviderById,
createUserModelProvider,
updateUserModelProvider,
deleteUserModelProvider,
deleteUserModelProviderByProviderId,
setUserModelPrimary,
```

- [ ] **Step 2: Add helper function to get Gateway config**

Add this helper near the top of the route definitions (after imports, before routes):

```javascript
async function getGatewayConfig() {
  if (!gateway.isConnected) return null
  try {
    const result = await gateway.call('config.get', {})
    const payload = result || {}
    return payload.sourceConfig || payload.config || payload.parsed || {}
  } catch {
    return null
  }
}

async function patchGatewayConfig(config) {
  if (!gateway.isConnected) throw new Error('Gateway not connected')
  const cfgResult = await gateway.call('config.get', {})
  const payload = cfgResult || {}
  const baseHash = payload.hash
  await gateway.call('config.patch', {
    raw: JSON.stringify(config),
    baseHash,
  })
}
```

- [ ] **Step 3: Add GET /api/model-providers route**

After the agent-team routes block (after line 521), add:

```javascript
// --- Model Provider routes (user-scoped) ---

app.get('/api/model-providers', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'

    // Get Gateway providers
    const gatewayConfig = await getGatewayConfig()
    const gatewayProviders = gatewayConfig?.models?.providers || {}
    const gatewayProviderList = Object.entries(gatewayProviders).map(([id, config]) => ({
      id,
      providerId: id,
      config,
      source: 'shared',
    }))

    if (isAdmin) {
      return res.json({ ok: true, providers: gatewayProviderList })
    }

    // Get user's private providers
    const userProviders = getUserModelProviders(userId)

    // Consistency check: remove stale local entries not in Gateway
    const gatewayIds = new Set(Object.keys(gatewayProviders))
    for (const local of userProviders) {
      if (!gatewayIds.has(local.provider_id)) {
        deleteUserModelProvider(local.id)
      }
    }

    // Re-fetch after cleanup
    const cleanUserProviders = getUserModelProviders(userId)
    const userList = cleanUserProviders.map((row) => {
      const parsedConfig = typeof row.config === 'string' ? JSON.parse(row.config) : row.config
      return {
        id: row.id,
        providerId: row.provider_id,
        config: parsedConfig,
        isPrimary: !!row.is_primary,
        source: 'private',
      }
    })

    // Merge: shared (from Gateway) + private (from local)
    const merged = [...gatewayProviderList, ...userList]
    res.json({ ok: true, providers: merged })
  } catch (err) {
    console.error('[ModelProviders] list error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 4: Add POST /api/model-providers route**

```javascript
app.post('/api/model-providers', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'
    const { providerId, config } = req.body || {}

    if (!providerId || !config) {
      return res.status(400).json({ ok: false, error: 'providerId and config are required' })
    }

    // Sync to Gateway config
    const gatewayConfig = await getGatewayConfig()
    if (!gatewayConfig) {
      return res.status(503).json({ ok: false, error: 'Gateway not connected' })
    }

    const providers = { ...(gatewayConfig.models?.providers || {}) }
    providers[providerId] = config

    const updatedConfig = {
      ...gatewayConfig,
      models: { ...gatewayConfig.models, providers },
    }
    await patchGatewayConfig(updatedConfig)

    if (!isAdmin) {
      // Also store in local DB for user isolation
      const existing = getUserModelProvider(userId, providerId)
      if (existing) {
        updateUserModelProvider(existing.id, { config })
      } else {
        createUserModelProvider(userId, providerId, config)
      }
    }

    res.json({ ok: true, providerId })
  } catch (err) {
    console.error('[ModelProviders] create error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 5: Add PUT /api/model-providers/:id route**

```javascript
app.put('/api/model-providers/:id', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'
    const { config } = req.body || {}
    const providerId = req.params.id

    // Sync to Gateway config
    const gatewayConfig = await getGatewayConfig()
    if (!gatewayConfig) {
      return res.status(503).json({ ok: false, error: 'Gateway not connected' })
    }

    const providers = { ...(gatewayConfig.models?.providers || {}) }
    if (!providers[providerId] && !isAdmin) {
      // Check if it's a user's private provider
      const local = getUserModelProvider(userId, providerId)
      if (!local) {
        return res.status(404).json({ ok: false, error: 'Provider not found' })
      }
    }

    providers[providerId] = config
    const updatedConfig = {
      ...gatewayConfig,
      models: { ...gatewayConfig.models, providers },
    }
    await patchGatewayConfig(updatedConfig)

    if (!isAdmin) {
      const local = getUserModelProvider(userId, providerId)
      if (local) {
        updateUserModelProvider(local.id, { config })
      }
    }

    res.json({ ok: true, providerId })
  } catch (err) {
    console.error('[ModelProviders] update error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 6: Add DELETE /api/model-providers/:id route**

```javascript
app.delete('/api/model-providers/:id', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'
    const providerId = req.params.id

    // Non-admin can only delete their own private providers
    if (!isAdmin) {
      const local = getUserModelProvider(userId, providerId)
      if (!local) {
        return res.status(403).json({ ok: false, error: 'Cannot delete shared providers' })
      }
      deleteUserModelProvider(local.id)
    }

    // Remove from Gateway config
    const gatewayConfig = await getGatewayConfig()
    if (gatewayConfig) {
      const providers = { ...(gatewayConfig.models?.providers || {}) }
      delete providers[providerId]
      const updatedConfig = {
        ...gatewayConfig,
        models: { ...gatewayConfig.models, providers },
      }
      await patchGatewayConfig(updatedConfig)
    }

    res.json({ ok: true })
  } catch (err) {
    console.error('[ModelProviders] delete error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 7: Add PUT /api/model-providers/default route**

```javascript
app.put('/api/model-providers/default', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'
    const { modelRef } = req.body || {}

    if (!modelRef) {
      return res.status(400).json({ ok: false, error: 'modelRef is required' })
    }

    // Set in Gateway config
    const gatewayConfig = await getGatewayConfig()
    if (!gatewayConfig) {
      return res.status(503).json({ ok: false, error: 'Gateway not connected' })
    }

    const updatedConfig = {
      ...gatewayConfig,
      models: { ...gatewayConfig.models, primary: modelRef },
    }
    await patchGatewayConfig(updatedConfig)

    // For non-admin, also record in local DB
    if (!isAdmin) {
      const parsed = modelRef.split('/')[0] // extract providerId from "provider/model"
      if (parsed) {
        setUserModelPrimary(userId, parsed)
      }
    }

    res.json({ ok: true })
  } catch (err) {
    console.error('[ModelProviders] set default error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 8: Verify — restart backend, test endpoints with curl**

Run: `npm run dev:server`

Test with admin token:
```bash
# List providers
curl -H "Authorization: Bearer <token>" http://localhost:3001/api/model-providers
```

- [ ] **Step 9: Commit**

```bash
git add server/index.js
git commit -m "feat: 添加模型渠道用户隔离 REST API（GET/POST/PUT/DELETE /api/model-providers）"
```

---

## Task 4: Update ModelsPage.vue for User Isolation

**Files:**
- Modify: `src/views/models/ModelsPage.vue`

- [ ] **Step 1: Add auth store import and isAdmin check**

At the top of the `<script setup>` section, add the import:

```typescript
import { useAuthStore } from '@/stores/auth'
```

After the existing store initializations (after `const { t, locale } = useI18n()`), add:

```typescript
const authStore = useAuthStore()
const isAdmin = computed(() => authStore.isAdmin)
```

- [ ] **Step 2: Add model provider API helper**

Add this function for REST API calls (non-admin path):

```typescript
async function modelProviderApiCall(path: string, options?: RequestInit) {
  const token = authStore.getToken()
  if (!token) throw new Error('Not authenticated')
  const res = await fetch(`/api/model-providers${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options?.headers,
    },
  })
  const data = await res.json()
  if (!data.ok) throw new Error(data.error || 'Request failed')
  return data
}
```

- [ ] **Step 3: Modify handleCreateProvider for non-admin path**

In the `handleCreateProvider` function (around line 1986), add a branch at the beginning:

```typescript
async function handleCreateProvider(confirmed = false) {
  const providerId = normalizeProviderId(createProviderForm.id)
  // ... existing validation ...

  // Non-admin: use REST API
  if (!isAdmin.value) {
    try {
      const providerConfig = {
        api: createProviderForm.api,
        baseUrl: createProviderForm.baseUrl.trim(),
        apiKey: createProviderForm.apiKey.trim(),
        models: createProviderForm.models.map(m => ({ id: m.id, input: m.input })),
      }
      await modelProviderApiCall('', {
        method: 'POST',
        body: JSON.stringify({ providerId, config: providerConfig }),
      })
      // ... existing UI cleanup ...
      message.success(t('pages.models.messages.providerCreated'))
    } catch (err) {
      message.error(t('pages.models.messages.saveFailed', { reason: err instanceof Error ? err.message : String(err) }))
    }
    return
  }

  // ... existing admin logic below (unchanged) ...
}
```

- [ ] **Step 4: Modify handleSaveProvider for non-admin path**

In the `handleSaveProvider` function (around line 1841), add a similar branch:

```typescript
async function handleSaveProvider(confirmed = false) {
  const providerId = normalizeProviderId(providerForm.id)
  // ... existing validation ...

  // Non-admin: use REST API
  if (!isAdmin.value) {
    try {
      const providerConfig = {
        api: providerForm.api,
        baseUrl: providerForm.baseUrl.trim(),
        apiKey: providerForm.apiKey.trim(),
        models: providerForm.models.map(m => ({ id: m.id, input: m.input })),
      }
      await modelProviderApiCall(`/${providerId}`, {
        method: 'PUT',
        body: JSON.stringify({ config: providerConfig }),
      })
      // ... existing UI cleanup ...
      message.success(t('pages.models.messages.providerUpdated'))
    } catch (err) {
      message.error(t('pages.models.messages.saveFailed', { reason: err instanceof Error ? err.message : String(err) }))
    }
    return
  }

  // ... existing admin logic below (unchanged) ...
}
```

- [ ] **Step 5: Modify handleDeleteProvider for non-admin path**

In `handleDeleteProvider` (around line 1776):

```typescript
async function handleDeleteProvider(providerIdInput: string): Promise<void> {
  const providerId = normalizeProviderId(providerIdInput)
  // ... existing validation ...

  // Non-admin: use REST API
  if (!isAdmin.value) {
    try {
      await modelProviderApiCall(`/${providerId}`, { method: 'DELETE' })
      await configStore.fetchConfig()
      message.success(t('pages.models.messages.providerDeleted'))
    } catch (err) {
      message.error(t('pages.models.messages.saveFailed', { reason: err instanceof Error ? err.message : String(err) }))
    }
    return
  }

  // ... existing admin logic below (unchanged) ...
}
```

- [ ] **Step 6: Modify savePrimaryModel for non-admin path**

In `savePrimaryModel` (around line 1700):

```typescript
async function savePrimaryModel(targetInput: string): Promise<void> {
  const target = targetInput.trim()
  if (!isAdmin.value) {
    await modelProviderApiCall('/default', {
      method: 'PUT',
      body: JSON.stringify({ modelRef: target }),
    })
    return
  }
  // Existing admin logic
  const patches: ConfigPatch[] = [
    { path: 'agents.defaults.model.primary', value: target },
  ]
  await configStore.patchConfig(patches)
}
```

- [ ] **Step 7: Add source tag to provider table columns**

Find the `providerColumns` definition (around line 1040). Add a `source` column for non-admin users:

In the column definitions, add before the actions column:

```typescript
...(isAdmin.value ? [] : [{
  title: t('pages.models.table.source') || '来源',
  key: 'source',
  width: 80,
  render: (row: any) => {
    const isPrivate = row.source === 'private'
    return h(NTag, {
      size: 'small',
      type: isPrivate ? 'info' : 'default',
      bordered: false,
    }, { default: () => isPrivate ? '私有' : '共享' })
  },
}]),
```

- [ ] **Step 8: Disable edit/delete buttons for shared providers (non-admin)**

In the actions column render function, find where the edit/delete buttons are rendered. Add a disabled check:

```typescript
// For non-admin, disable actions on shared providers
const isShared = !isAdmin.value && row.source === 'shared'
// On edit button: add :disabled="isShared" and tooltip
// On delete button: add :disabled="isShared" and tooltip
```

The exact implementation depends on how the buttons are rendered in the actions column. Add `disabled: isShared` prop to the button elements.

- [ ] **Step 9: Add i18n keys for new labels**

In `src/i18n/messages/zh-CN.ts`, in the models section, add:

```typescript
source: '来源',
shared: '共享',
private: '私有',
```

In `src/i18n/messages/en-US.ts`, add:

```typescript
source: 'Source',
shared: 'Shared',
private: 'Private',
```

- [ ] **Step 10: Verify — test both admin and non-admin flows**

Run: `npm run dev:all`

Test as admin:
- Create/edit/delete providers → should work as before
- No source tag shown

Test as non-admin:
- See shared providers with "共享" tag, edit/delete disabled
- Create a private provider → appears with "私有" tag
- Edit/delete private provider → works
- Try to edit shared provider → button disabled

- [ ] **Step 11: Commit**

```bash
git add src/views/models/ModelsPage.vue src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: 模型管理页面用户隔离（admin共享/非admin私有渠道）"
```

---

## Task 5: Add Default Model for Agent Creation

**Files:**
- Modify: `src/views/agent-team/AgentTeamPage.vue:25-106`

- [ ] **Step 1: Add config store import**

In `AgentTeamPage.vue`, add to the imports:

```typescript
import { useConfigStore } from '@/stores/config'
```

And in the setup:

```typescript
const configStore = useConfigStore()
```

- [ ] **Step 2: Add default model logic in handleCreated**

In the `handleCreated` function, after step 2 (setting display name, around line 51), add a new step:

```typescript
// 2.5 Set default model from Gateway primary model
const gatewayConfig = await wsStore.rpc.getConfig()
const defaultModel = gatewayConfig?.models?.primary || gatewayConfig?.agents?.defaults?.model?.primary || ''
if (defaultModel) {
  try {
    await wsStore.rpc.setAgentFile(gatewayAgentId, 'IDENTITY.md',
      (await wsStore.rpc.getAgentFile?.(gatewayAgentId, 'IDENTITY.md') || '') +
      `\n\n## 默认模型\n\ndefaultModel: ${defaultModel}`)
  } catch {
    // Non-critical: best-effort to set default model
  }
}
```

Actually, a simpler approach: add the model to the agent's config in the identity step. After step 3 (identity config), update the agent entry to include the model:

Find the part where `currentList` is updated (around line 60):

```typescript
if (agentIndex >= 0) {
  currentList[agentIndex] = {
    ...currentList[agentIndex],
    identity: { name: data.name, emoji: data.avatar },
    ...(defaultModel ? { model: defaultModel } : {}),
  }
} else {
  currentList.push({
    id: gatewayAgentId,
    name: data.name,
    identity: { name: data.name, emoji: data.avatar },
    ...(defaultModel ? { model: defaultModel } : {}),
  })
}
```

- [ ] **Step 3: Also pass model to backend agent creation**

In step 5 (around line 90), where `store.createAgent()` is called, add the `model` field:

```typescript
await store.createAgent({
  name: data.name,
  avatar: data.avatar,
  description: data.description,
  category: data.category,
  templateId: data.templateId,
  gatewayAgentId,
  model: defaultModel,  // <-- add this
})
```

- [ ] **Step 4: Verify — create a new agent and check model**

Run: `npm run dev:all`

1. Ensure Gateway has a primary model configured
2. Create a new digital employee
3. Edit the employee → check if the model field is pre-filled

- [ ] **Step 5: Commit**

```bash
git add src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: 创建数字员工时自动设置 Gateway 主模型为默认模型"
```

---

## Task 6: Add Agent Stats Backend API

**Files:**
- Modify: `server/index.js` — add stats endpoint

- [ ] **Step 1: Add GET /api/agent-team/:id/stats endpoint**

After the existing agent-team routes (after line 521, before the channel sync function), add:

```javascript
app.get('/api/agent-team/:id/stats', authMiddleware, async (req, res) => {
  try {
    const agentId = req.params.id
    const userId = req.currentUser.id

    // Verify ownership
    const agent = getDigitalEmployeeByAgentId(agentId, userId)
    if (!agent && req.currentUser.role !== 'admin') {
      return res.status(403).json({ ok: false, error: 'Not your agent' })
    }
    if (!agent) {
      return res.status(404).json({ ok: false, error: 'Agent not found' })
    }

    if (!gateway.isConnected) {
      return res.json({ ok: true, stats: { messages: 0, tasks: 0 } })
    }

    // Get sessions for this agent from Gateway
    const sessionsResult = await gateway.call('sessions.list', {})
    const sessions = Array.isArray(sessionsResult)
      ? sessionsResult
      : (sessionsResult?.sessions || sessionsResult?.list || [])

    // Filter sessions belonging to this agent
    const agentSessions = sessions.filter((s) => {
      const agent = s.agent || s.agentId || s.agent_id || ''
      return agent === agentId
    })

    let totalMessages = 0
    let totalTasks = 0

    // Query history for each session (limit to recent 50 sessions for performance)
    const recentSessions = agentSessions.slice(0, 50)
    for (const session of recentSessions) {
      try {
        const sessionKey = session.key || session.sessionKey || session.id || session.session_key
        if (!sessionKey) continue

        const historyResult = await gateway.call('sessions.history', { key: sessionKey })
        const messages = Array.isArray(historyResult)
          ? historyResult
          : (historyResult?.messages || historyResult?.history || [])

        for (const msg of messages) {
          const role = msg.role || ''
          if (role === 'assistant') {
            totalMessages++
            // Check for tool calls
            const content = msg.content
            if (Array.isArray(content)) {
              const hasToolUse = content.some((c) =>
                c.type === 'tool_use' || c.type === 'function_call' || c.type === 'tool_call'
              )
              if (hasToolUse) totalTasks++
            }
          }
        }
      } catch {
        // Skip sessions with errors
      }
    }

    res.json({ ok: true, stats: { messages: totalMessages, tasks: totalTasks } })
  } catch (err) {
    console.error('[AgentStats] error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 2: Verify — test stats endpoint**

Run: `npm run dev:server`

Test:
```bash
curl -H "Authorization: Bearer <token>" http://localhost:3001/api/agent-team/<agent-id>/stats
```

Expected response:
```json
{ "ok": true, "stats": { "messages": 5, "tasks": 2 } }
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat: 添加数字员工统计数据 API（消息数/任务数）"
```

---

## Task 7: Update AgentCard.vue with Stats Display

**Files:**
- Modify: `src/views/agent-team/AgentCard.vue`
- Modify: `src/views/agent-team/AgentTeamPage.vue`

- [ ] **Step 1: Add stats prop to AgentCard.vue**

In `AgentCard.vue`, update the props:

```typescript
const props = defineProps<{
  agent: AgentTeamMember
  stats?: { messages: number; tasks: number } | null
}>()
```

- [ ] **Step 2: Update stats display in AgentCard.vue template**

Replace the hardcoded stats section (lines 75-88):

```vue
<div class="agent-card__stats">
  <div class="agent-card__stat">
    <span class="agent-card__stat-value">{{ companionDays }}</span>
    <span class="agent-card__stat-label">{{ t('pages.agentTeam.card.days') }}</span>
  </div>
  <div class="agent-card__stat">
    <span class="agent-card__stat-value">{{ stats?.messages ?? '-' }}</span>
    <span class="agent-card__stat-label">{{ t('pages.agentTeam.card.messages') }}</span>
  </div>
  <div class="agent-card__stat">
    <span class="agent-card__stat-value">{{ stats?.tasks ?? '-' }}</span>
    <span class="agent-card__stat-label">{{ t('pages.agentTeam.card.tasks') }}</span>
  </div>
</div>
```

- [ ] **Step 3: Add stats loading logic in AgentTeamPage.vue**

In `AgentTeamPage.vue`, add state and fetch function:

```typescript
import { onMounted, ref, reactive } from 'vue'

const agentStats = reactive<Record<string, { messages: number; tasks: number }>>({})

async function fetchAgentStats() {
  const token = authStore.getToken()
  if (!token) return
  const results = await Promise.allSettled(
    store.agentList.map(async (agent) => {
      const res = await fetch(`/api/agent-team/${agent.id}/stats`, {
        headers: { 'Authorization': `Bearer ${token}` },
      })
      const data = await res.json()
      if (data.ok) {
        agentStats[agent.id] = data.stats
      }
    })
  )
}
```

Add `authStore` import:
```typescript
import { useAuthStore } from '@/stores/auth'
const authStore = useAuthStore()
```

Call `fetchAgentStats()` after agents are loaded:

```typescript
onMounted(async () => {
  await store.fetchAgents()
  fetchAgentStats() // fire and forget — stats load in background
})
```

- [ ] **Step 4: Pass stats to AgentCard in template**

Update the AgentCard rendering:

```vue
<AgentCard
  v-for="agent in store.agentList"
  :key="agent.id"
  :agent="agent"
  :stats="agentStats[agent.id] || null"
  @edit="handleEdit"
  @delete="handleDelete"
  @chat="handleChat"
/>
```

- [ ] **Step 5: Verify — check stats display**

Run: `npm run dev:all`

1. Open agent team page
2. Cards should show days + messages/tasks stats
3. Stats may briefly show `-` while loading, then populate

- [ ] **Step 6: Commit**

```bash
git add src/views/agent-team/AgentCard.vue src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: 数字员工卡片显示消息数和任务数统计数据"
```

---

## Summary

| Task | Description | Files |
|------|-------------|-------|
| 1 | 去掉"网关可视化管理系统" | 5 files (text only) |
| 2 | 添加数据库表 + CRUD | database.js, user-manager.js |
| 3 | 模型渠道 REST API | server/index.js |
| 4 | ModelsPage 用户隔离 | ModelsPage.vue, i18n files |
| 5 | 默认模型选择 | AgentTeamPage.vue |
| 6 | Stats 后端 API | server/index.js |
| 7 | Stats 前端显示 | AgentCard.vue, AgentTeamPage.vue |

**Dependency order:** Task 1 (independent) → Task 2 → Task 3 → Task 4 (sequential). Task 5, 6, 7 are independent of each other but depend on Task 1 being done first (to avoid merge conflicts).
