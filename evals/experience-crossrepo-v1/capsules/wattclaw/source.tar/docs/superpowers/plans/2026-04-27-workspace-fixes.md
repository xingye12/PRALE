# AI 工作台修复实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复 AI 工作台的 7 个问题（路由顺序、会话计数、标题摘要、页面切换恢复、模型默认值、模型选择 UI、新会话即时显示）。

**Architecture:** 前端修改集中在 workspace store 和相关组件；后端新增 sessions.patch RPC 代理和 generate-title 端点。标题生成通过后端调 Gateway chat.send 实现。

**Tech Stack:** Vue 3 + TypeScript（前端）、Express/Node.js（后端）、Gateway WebSocket RPC

---

## Task 1: 路由顺序调整

**Files:**
- Modify: `src/router/routes.ts`

- [ ] **Step 1: 移动 workspace 路由到 chat 之前**

将 `routes.ts` 中 workspace 路由块（当前位于 lines 127-132）移到 chat 路由（lines 33-37）之前。同时更换图标为 `RocketOutline` 避免与在线对话重复。

修改后的路由顺序片段（替换 lines 33-37 和 lines 127-132 区域）：

```typescript
      {
        path: 'workspace',
        name: 'Workspace',
        component: () => import('@/views/workspace/WorkspacePage.vue'),
        meta: { titleKey: 'routes.workspace', icon: 'RocketOutline' },
      },
      {
        path: 'chat',
        name: 'Chat',
        component: () => import('@/views/chat/ChatPage.vue'),
        meta: { titleKey: 'routes.chat', icon: 'ChatboxEllipsesOutline' },
      },
```

- [ ] **Step 2: 验证路由正常**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 3: 提交**

```bash
git add src/router/routes.ts
git commit -m "fix: move workspace route above chat and update icon"
```

---

## Task 2: 预加载所有 Agent 的会话数

**Files:**
- Modify: `src/stores/workspace.ts` (`loadAgents` 函数，lines 127-141)

- [ ] **Step 1: 修改 loadAgents 函数，在初始化后并行加载所有 agent 的 sessions**

替换 `loadAgents` 函数（lines 127-141）为：

```typescript
  async function loadAgents() {
    const agentTeamStore = useAgentTeamStore()
    if (agentTeamStore.agentList.length === 0) {
      await agentTeamStore.fetchAgents()
    }
    agents.value = agentTeamStore.agentList.map((member) => ({
      agentId: member.id,
      name: member.name,
      avatar: member.avatar,
      category: member.category,
      expanded: false,
      sessions: [],
      loadingSessions: false,
    }))

    await Promise.allSettled(
      agents.value.map((agent) => loadAgentSessions(agent.agentId))
    )
  }
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 3: 提交**

```bash
git add src/stores/workspace.ts
git commit -m "fix: preload session counts for all agents on load"
```

---

## Task 3: 模型选择默认值 + UI 调整

**Files:**
- Modify: `src/stores/workspace.ts` (`loadModels` 函数，lines 341-347)
- Modify: `src/views/workspace/ChatInput.vue` (lines 11, 60-68, style)

- [ ] **Step 1: 在 workspace store 中添加 selectedModel state 和默认值逻辑**

在 workspace store 的 ref 声明区域（line 100 之后）添加：

```typescript
  const selectedModel = ref<string | null>(null)
```

修改 `loadModels` 函数（lines 341-347）为：

```typescript
  async function loadModels() {
    const modelStore = useModelStore()
    if (modelStore.models.length === 0) {
      await modelStore.fetchModels()
    }
    availableModels.value = modelStore.models.map((m) => m.id)
    if (!selectedModel.value && availableModels.value.length > 0) {
      selectedModel.value = availableModels.value[0]
    }
  }
```

在 return 对象中添加 `selectedModel`。

- [ ] **Step 2: 修改 ChatInput.vue，移除本地 selectedModel，使用 store 的**

替换 ChatInput.vue 的 script 部分（lines 1-47）为：

```typescript
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { NInput, NButton, NSelect, NTooltip } from 'naive-ui'
import { useWorkspaceStore } from '@/stores/workspace'

const { t } = useI18n()
const workspaceStore = useWorkspaceStore()

const inputText = ref('')
const attachments = ref<File[]>([])

const modelOptions = computed(() =>
  workspaceStore.availableModels.map((m) => ({ label: m, value: m }))
)

function handleSend() {
  const text = inputText.value.trim()
  if (!text || workspaceStore.sending) return
  workspaceStore.sendMessage(text)
  inputText.value = ''
}

function handleKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    handleSend()
  }
}

function handleFileSelect() {
  const input = document.createElement('input')
  input.type = 'file'
  input.multiple = true
  input.onchange = () => {
    if (input.files) {
      attachments.value = [...attachments.value, ...Array.from(input.files)]
    }
  }
  input.click()
}

function removeAttachment(index: number) {
  attachments.value = attachments.value.filter((_, i) => i !== index)
}
</script>
```

替换模板中 NSelect 部分（lines 60-68）为：

```vue
      <NSelect
        v-if="modelOptions.length"
        v-model:value="workspaceStore.selectedModel"
        :options="modelOptions"
        :placeholder="t('pages.workspace.chat.model')"
        size="small"
        :consistent-menu-width="false"
        style="min-width: 140px; max-width: 180px;"
      />
```

- [ ] **Step 3: 验证类型检查通过**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 4: 提交**

```bash
git add src/stores/workspace.ts src/views/workspace/ChatInput.vue
git commit -m "fix: add default model selection and improve model selector UI"
```

---

## Task 4: 新会话即时显示在左侧列表

**Files:**
- Modify: `src/stores/workspace.ts` (`startNewChat` 函数，lines 182-187)

- [ ] **Step 1: 修改 startNewChat，立即将临时 session 插入 agent 的 sessions 数组**

替换 `startNewChat` 函数（lines 182-187）为：

```typescript
  function startNewChat(agentId: string) {
    const uuid = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
    const sessionKey = `agent:${agentId}:${uuid}`
    activeSessionKey.value = sessionKey
    messages.value = []

    const agent = agents.value.find((a) => a.agentId === agentId)
    if (agent) {
      const existing = agent.sessions.find((s) => s.key === sessionKey)
      if (!existing) {
        agent.sessions = [
          {
            key: sessionKey,
            agentId,
            channel: '',
            peer: '',
            messageCount: 0,
            lastActivity: new Date().toISOString(),
          },
          ...agent.sessions,
        ]
      }
    }
  }
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 3: 提交**

```bash
git add src/stores/workspace.ts
git commit -m "fix: show new session immediately in sidebar list"
```

---

## Task 5: 切换页面后恢复历史消息

**Files:**
- Modify: `src/stores/workspace.ts`（添加 clearMessages 函数）
- Modify: `src/views/workspace/WorkspacePage.vue`（onMounted/onUnmounted 逻辑）

- [ ] **Step 1: 在 workspace store 添加 clearMessages 函数**

在 store 的 return 之前添加：

```typescript
  function clearMessages() {
    messages.value = []
  }
```

在 return 对象中添加 `clearMessages`。

- [ ] **Step 2: 修改 WorkspacePage.vue 的 onMounted 和 onUnmounted**

替换 `WorkspacePage.vue` 的 script 部分（lines 1-46）为：

```typescript
<script setup lang="ts">
import { onMounted, onUnmounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useWorkspaceStore } from '@/stores/workspace'
import { useWebSocketStore } from '@/stores/websocket'
import WorkspaceSidebar from './WorkspaceSidebar.vue'
import ChatHeader from './ChatHeader.vue'
import MessageList from './MessageList.vue'
import ChatInput from './ChatInput.vue'
import WelcomeScreen from './WelcomeScreen.vue'

const route = useRoute()
const { t } = useI18n()
const workspaceStore = useWorkspaceStore()
const wsStore = useWebSocketStore()

let eventCleanup: (() => void) | null = null

onMounted(async () => {
  await workspaceStore.loadAgents()
  await workspaceStore.loadModels()

  const agentId = route.query.agentId as string | undefined
  if (agentId) {
    await workspaceStore.selectAgent(agentId)
    await workspaceStore.startNewChat(agentId)
  } else if (workspaceStore.activeSessionKey) {
    await workspaceStore.selectSession(workspaceStore.activeSessionKey)
  }

  eventCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as { event: string; payload: unknown }
    workspaceStore.handleEvent(rpcEvent.event, rpcEvent.payload)
  })
})

onUnmounted(() => {
  eventCleanup?.()
  workspaceStore.clearMessages()
})

watch(() => route.query.agentId, async (newAgentId) => {
  if (newAgentId && typeof newAgentId === 'string') {
    await workspaceStore.selectAgent(newAgentId)
    await workspaceStore.startNewChat(newAgentId)
  }
})
</script>
```

- [ ] **Step 3: 验证类型检查通过**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 4: 提交**

```bash
git add src/stores/workspace.ts src/views/workspace/WorkspacePage.vue
git commit -m "fix: reload chat history when returning to workspace page"
```

---

## Task 6: 后端 - 添加 sessions.patch RPC 代理

**Files:**
- Modify: `server/index.js`（在 /api/rpc 路由处理中添加 sessions.patch case）

- [ ] **Step 1: 在 server/index.js 的 RPC 代理中添加 sessions.patch 处理**

在 `server/index.js` 中搜索 `sessions.list` 或 `session.list` 的处理代码块（在 /api/rpc 路由处理器内部），在其附近添加：

```javascript
    if (normMethod === 'sessions.patch' || normMethod === 'session.patch') {
      const sk = params?.key || params?.sessionKey
      if (sk && !isSessionOwned(sk)) {
        return res.status(403).json({ ok: false, error: { message: 'Access denied' } })
      }
      try {
        const result = await gateway.call(method, params)
        res.json({ ok: true, payload: result })
      } catch (err) {
        res.status(500).json({ ok: false, error: { message: err.message } })
      }
      return
    }
```

注意：插入位置需要在 RPC handler 的其他 sessions.* 处理逻辑附近。搜索 `sessions.list` 找到确切位置后插入。

- [ ] **Step 2: 验证后端启动正常**

Run: `node -e "require('./server/index.js')" 2>&1 | head -5` 或直接检查语法

- [ ] **Step 3: 提交**

```bash
git add server/index.js
git commit -m "feat: add sessions.patch RPC proxy for label updates"
```

---

## Task 7: 后端 - 添加 generate-title 端点

**Files:**
- Modify: `server/index.js`（新增 POST /api/workspace/generate-title 路由）

- [ ] **Step 1: 在 server/index.js 中添加 generate-title 端点**

在 server/index.js 的路由区域（其他 /api/ 路由附近）添加：

```javascript
  // Generate session title via LLM
  app.post('/api/workspace/generate-title', authMiddleware, async (req, res) => {
    try {
      const { message } = req.body
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ ok: false, error: { message: 'message is required' } })
      }

      const truncated = message.slice(0, 200)
      const prompt = `根据以下用户消息，生成一个4-6个字的中文标题，只返回标题本身，不要加引号或标点：\n${truncated}`

      const titleSessionKey = `agent:main:title-${Date.now().toString(36)}`
      const idempotencyKey = `title-${Date.now()}`

      const rpcResult = await gateway.call('chat.send', {
        sessionKey: titleSessionKey,
        message: prompt,
        idempotencyKey,
      })

      // Extract text from various response shapes
      let title = ''
      if (typeof rpcResult === 'string') {
        title = rpcResult
      } else if (rpcResult && typeof rpcResult === 'object') {
        const obj = rpcResult
        title = obj.text || obj.content || obj.message || obj.output || ''
        if (!title && Array.isArray(obj.messages)) {
          const last = obj.messages[obj.messages.length - 1]
          title = last?.text || last?.content || last?.message || ''
        }
      }

      title = String(title).trim().replace(/^["'""]+|["'""]+$/g, '').slice(0, 20)

      res.json({ ok: true, title: title || truncated.slice(0, 10) })
    } catch (err) {
      log('error', '[generate-title] failed:', err.message)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
```

注意：`authMiddleware` 和 `gateway` 在 server/index.js 中已经定义。`log` 函数也已存在。插入位置在文件中其他 POST /api/ 路由附近即可。

- [ ] **Step 2: 验证后端启动正常**

检查语法无误。

- [ ] **Step 3: 提交**

```bash
git add server/index.js
git commit -m "feat: add POST /api/workspace/generate-title endpoint"
```

---

## Task 8: 前端 - LLM 生成会话标题

**Files:**
- Modify: `src/stores/workspace.ts`（添加 generateAndSetTitle 方法）
- Modify: `src/stores/workspace.ts`（在 handleEvent 的 chat.final 分支中调用）

- [ ] **Step 1: 在 workspace store 添加 httpPost 辅助和 generateAndSetTitle 方法**

在 store 文件顶部 import 区域之后、store 定义之前，添加：

```typescript
async function httpPost(url: string, body: Record<string, unknown>): Promise<unknown> {
  const token = localStorage.getItem('token')
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  })
  const data = await resp.json()
  if (!data.ok) throw new Error(data.error?.message || 'Request failed')
  return data
}
```

在 store 的 return 之前（`loadModels` 之后），添加：

```typescript
  const titleGeneratedKeys = new Set<string>()

  async function generateAndSetTitle(sessionKey: string) {
    if (!sessionKey || titleGeneratedKeys.has(sessionKey)) return

    const userMessages = messages.value.filter((m) => m.role === 'user')
    if (userMessages.length === 0) return

    const firstMessage = userMessages[0].content
    if (!firstMessage) return

    try {
      const result = await httpPost('/api/workspace/generate-title', { message: firstMessage }) as { title: string }
      const title = result.title
      if (!title) return

      titleGeneratedKeys.add(sessionKey)

      // Update via Gateway RPC
      await wsStore.rpc.patchSession({ sessionKey, label: title })

      // Update local session list
      const agent = agents.value.find((a) => a.agentId === selectedAgentId.value)
      if (agent) {
        agent.sessions = agent.sessions.map((s) =>
          s.key === sessionKey ? { ...s, label: title } : s
        )
      }
    } catch {
      // Title generation is best-effort, don't block chat
    }
  }
```

在 return 对象中添加 `generateAndSetTitle`。

- [ ] **Step 2: 在 handleEvent 的 chat.final 分支中调用 generateAndSetTitle**

找到 `handleEvent` 函数中 `isFinal` 的处理（line 335 附近），将：

```typescript
      if (isFinal && selectedAgentId.value) {
        loadAgentSessions(selectedAgentId.value)
      }
```

替换为：

```typescript
      if (isFinal && selectedAgentId.value) {
        loadAgentSessions(selectedAgentId.value)
        if (activeSessionKey.value) {
          generateAndSetTitle(activeSessionKey.value)
        }
      }
```

- [ ] **Step 3: 验证类型检查通过**

Run: `npx vue-tsc --noEmit`
Expected: 无类型错误

- [ ] **Step 4: 提交**

```bash
git add src/stores/workspace.ts
git commit -m "feat: auto-generate session titles via LLM after first response"
```

---

## Task 9: 集成验证

- [ ] **Step 1: 启动前后端**

Run: `./restart.sh`

- [ ] **Step 2: 浏览器验证全部 7 项修复**

逐项验证：
1. 侧边栏 AI 工作台在"在线对话"上方，图标为火箭
2. 打开工作台，每个 agent 旁显示正确会话数（非0）
3. 选择 agent 发送消息，等待 AI 回复完成后，左侧会话标题自动更新为中文摘要
4. 切换到其他页面再切回工作台，消息正常显示，无 Bootstrap 内容
5. 模型选择器有默认值（第一个模型）
6. 模型选择器宽度适中，长模型名被截断
7. 发送消息后，左侧会话列表立即显示新会话

- [ ] **Step 3: 提交所有更改（如有未提交的）**

```bash
git status
git add -A
git commit -m "fix: workspace fixes - route order, session count, title, restore, model, UI"
```
