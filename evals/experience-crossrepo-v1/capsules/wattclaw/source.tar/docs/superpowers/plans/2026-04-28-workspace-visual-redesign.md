# Workspace Visual Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Redesign the AI Workspace UI to match the Hermes WebUI warm earth-tone aesthetic, with light and dark themes, while keeping all business logic unchanged.

**Architecture:** Replace the CSS variable system in `main.css` with a unified Hermes-inspired warm palette (light + dark), then update each workspace component's scoped styles to use the new tokens. No component props, events, or logic change — only `<style>` blocks and CSS variable definitions.

**Tech Stack:** Vue 3, TypeScript, CSS custom properties, Naive UI

---

## File Map

| File | Action | Responsibility |
|------|--------|---------------|
| `src/assets/styles/main.css` | Modify | CSS variables (light + dark), global resets, scrollbar, animations |
| `src/views/workspace/WorkspacePage.vue` | Modify | Layout background colors |
| `src/views/workspace/MessageList.vue` | Modify | Message bubbles, layout, streaming cursor |
| `src/views/workspace/ChatInput.vue` | Modify | Composer box, footer, buttons |
| `src/views/workspace/ThinkingBlock.vue` | Modify | Accent-tinted collapsible card |
| `src/views/workspace/components/ToolCallCard.vue` | Modify | Running state, collapsible detail |
| `src/views/workspace/WorkspaceSidebar.vue` | Modify | Warm palette integration |
| `src/views/workspace/ChatHeader.vue` | Modify | Height, colors, model chip |
| `src/views/workspace/WelcomeScreen.vue` | Modify | Icon, colors |
| `src/views/workspace/components/MarkdownRenderer.vue` | Modify | Code blocks, streaming cursor, syntax theme |
| `src/views/workspace/components/MessageActions.vue` | Modify | Hover style, scoped fix |
| `src/views/workspace/components/SlashCommandMenu.vue` | Modify | Warm palette |
| `src/views/workspace/components/ImageLightbox.vue` | Modify | Warm overlay |

---

## Task 1: CSS Variables — `main.css`

**Files:**
- Modify: `src/assets/styles/main.css`

- [ ] **Step 1: Replace the `:root` block (lines 1–54)**

Replace the entire `:root` block with the Hermes-inspired warm palette. Keep the existing layout utility classes, glass-effect, page transitions, card/button/input overrides, gradient utilities, and scroll-to-bottom button — only update their color references to use the new variables.

```css
:root {
  /* ── Hermes warm palette — Light Mode ── */
  --bg: #FEFCF7;
  --bg-sidebar: #FAF7F0;
  --bg-surface: #F3EEE3;
  --bg-input: rgba(0,0,0,.03);
  --bg-hover: rgba(0,0,0,.05);
  --bg-code: #F5F0E5;
  --code-inline-bg: rgba(0,0,0,.06);
  --border: #E0D8C8;
  --border2: rgba(0,0,0,.15);
  --text: #1A1610;
  --text-muted: #5C5344;
  --text-strong: #0F0D08;
  --accent: #B8860B;
  --accent-hover: #996F08;
  --accent-bg: rgba(184,134,11,.08);
  --accent-bg-strong: rgba(184,134,11,.15);
  --accent-text: #8B6508;
  --blue: #0288A8;
  --error: #C62828;
  --success: #3D8B40;

  /* ── Layout ── */
  --sidebar-width: 280px;
  --sidebar-collapsed: 72px;
  --header-height: 56px;
  --msg-max: 780px;
  --composer-max: 780px;

  /* ── Legacy aliases (keep other pages working) ── */
  --primary: #B8860B;
  --primary-dim: #996F08;
  --primary-container: rgba(184,134,11,.15);
  --surface: #FEFCF7;
  --surface-bright: #FEFCF7;
  --surface-dim: #F3EEE3;
  --surface-container-lowest: #FEFCF7;
  --surface-container-low: #FAF7F0;
  --surface-container: #F3EEE3;
  --surface-container-high: #E8E0D0;
  --surface-container-highest: #E0D8C8;
  --on-surface: #1A1610;
  --on-surface-variant: #5C5344;
  --outline: #8C8070;
  --outline-variant: #E0D8C8;
  --shadow-sm: 0 2px 4px rgba(0,0,0,.04);
  --shadow-md: 0 4px 12px rgba(0,0,0,.05);
  --premium-shadow: 0 20px 50px rgba(0,0,0,.06);
  --sidebar-shadow: 0 10px 40px rgba(184,134,11,.05);
  --radius-lg: 12px;
  --radius-xl: 20px;
  --radius-2xl: 24px;
  --radius-3xl: 32px;
  --shadow-focus: 0 0 0 3px rgba(184,134,11,.2);

  /* ── Workspace aliases ── */
  --bg-primary: var(--bg);
  --bg-sidebar: var(--bg-sidebar);
  --text-primary: var(--text);
  --text-secondary: var(--text-muted);
  --text-tertiary: var(--text-muted);
  --bg-card: var(--bg);
  --border-color: var(--border);
  --border-focus: var(--accent);
  --workspace-max-width: 780px;
  --message-max-width: 780px;
}
```

- [ ] **Step 2: Replace the `[data-theme='dark']` block (lines 56–88)**

```css
[data-theme='dark'] {
  /* ── Hermes warm palette — Dark Mode ── */
  --bg: #1A1814;
  --bg-sidebar: #1E1C17;
  --bg-surface: #252320;
  --bg-input: rgba(255,255,255,.04);
  --bg-hover: rgba(255,255,255,.06);
  --bg-code: #2A2722;
  --code-inline-bg: rgba(255,255,255,.08);
  --border: #3A3630;
  --border2: rgba(255,255,255,.12);
  --text: #E8E0D4;
  --text-muted: #9C9486;
  --text-strong: #F5EDE0;
  --accent: #D4A017;
  --accent-hover: #B8860B;
  --accent-bg: rgba(212,160,23,.1);
  --accent-bg-strong: rgba(212,160,23,.18);
  --accent-text: #D4A017;
  --blue: #4FC3F7;
  --error: #EF5350;
  --success: #66BB6A;

  /* ── Legacy aliases ── */
  --primary: #D4A017;
  --primary-dim: #B8860B;
  --primary-container: rgba(212,160,23,.18);
  --surface: #1A1814;
  --surface-bright: #1E1C17;
  --surface-dim: #121010;
  --surface-container-lowest: #121010;
  --surface-container-low: #1A1814;
  --surface-container: #252320;
  --surface-container-high: #2E2B27;
  --surface-container-highest: #3A3630;
  --on-surface: #E8E0D4;
  --on-surface-variant: #9C9486;
  --outline: #7A7268;
  --outline-variant: #3A3630;
  --premium-shadow: 0 20px 60px rgba(0,0,0,.4);
  --sidebar-shadow: 0 10px 40px rgba(0,0,0,.3);
  --shadow-focus: 0 0 0 3px rgba(212,160,23,.25);

  /* ── Workspace aliases ── */
  --bg-primary: var(--bg);
  --bg-card: var(--bg-surface);
  --text-primary: var(--text);
  --text-secondary: var(--text-muted);
  --text-tertiary: var(--text-muted);
  --border-color: var(--border);
}
```

- [ ] **Step 3: Update the global body/html styles (lines 90–107)**

```css
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app {
  height: 100%;
  width: 100%;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  background-color: var(--bg);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  transition-property: background-color, border-color, color;
  transition-duration: 0.15s;
  transition-timing-function: ease;
}

h1, h2, h3, h4, .font-headline {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  letter-spacing: -0.02em;
}
```

- [ ] **Step 4: Update scrollbar styles (lines 128–137)**

```css
::-webkit-scrollbar {
  width: 6px;
}
::-webkit-scrollbar-track {
  background: transparent;
}
::-webkit-scrollbar-thumb {
  background: rgba(0,0,0,.12);
  border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover {
  background: rgba(0,0,0,.25);
}
* {
  scrollbar-color: rgba(0,0,0,.12) transparent;
}

[data-theme='dark'] ::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,.12);
}
[data-theme='dark'] ::-webkit-scrollbar-thumb:hover {
  background: rgba(255,255,255,.25);
}
[data-theme='dark'] * {
  scrollbar-color: rgba(255,255,255,.12) transparent;
}
```

- [ ] **Step 5: Update glass-effect (lines 114–125)**

```css
.glass-effect {
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  background: rgba(250,247,240,0.8);
  border: 1px solid var(--border2);
}

[data-theme='dark'] .glass-effect {
  background: rgba(30,28,23,0.8);
  border: 1px solid var(--border2);
}
```

- [ ] **Step 6: Update app-card and button overrides (lines 170–185)**

```css
.app-card.n-card {
  border-radius: var(--radius-2xl);
  border: none !important;
  background: var(--bg-surface);
  box-shadow: var(--shadow-md);
  transition: box-shadow 0.3s ease;
}

.n-button {
  border-radius: var(--radius-lg) !important;
  font-weight: 600 !important;
}

.n-input {
  border-radius: var(--radius-lg) !important;
}
```

- [ ] **Step 7: Update gradient backgrounds (lines 188–196)**

```css
.bg-premium-gradient {
  background: linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%);
}

.text-gradient {
  background: linear-gradient(to right, var(--accent), var(--accent-hover));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
```

- [ ] **Step 8: Update scroll-to-bottom button (lines 198–218)**

```css
.scroll-to-bottom-btn {
  position: absolute;
  bottom: 120px;
  right: 32px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--bg-surface);
  border: 1px solid var(--border);
  box-shadow: 0 2px 8px rgba(0,0,0,.12);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  color: var(--text-muted);
  transition: all 0.15s ease;
}

.scroll-to-bottom-btn:hover {
  background: var(--bg-hover);
  color: var(--text);
}
```

- [ ] **Step 9: Add global animation keyframes at the end of the file**

Append these at the bottom of `main.css`:

```css
/* ── Workspace animations ── */
@keyframes msg-in {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: none; }
}

@keyframes pulse {
  0%, 100% { opacity: .4; }
  50% { opacity: 1; }
}

@keyframes blink {
  0%, 49% { opacity: 1; }
  50%, 100% { opacity: 0; }
}
```

- [ ] **Step 10: Verify**

Run `npm run dev` and open `localhost:3000`. Check that:
- The workspace page loads without errors
- Light mode shows warm off-white background
- Toggle to dark mode (if available) shows warm dark background
- Other pages (Agent Team, Models) still look reasonable with the new palette

- [ ] **Step 11: Commit**

```bash
git add src/assets/styles/main.css
git commit -m "feat: replace CSS variables with Hermes warm earth-tone palette"
```

---

## Task 2: WorkspacePage Layout

**Files:**
- Modify: `src/views/workspace/WorkspacePage.vue:65-88`

- [ ] **Step 1: Update the `<style scoped>` block**

Replace the entire `<style scoped>` section:

```vue
<style scoped>
.workspace-page {
  display: flex;
  height: 100%;
  overflow: hidden;
}

.workspace-sidebar {
  width: var(--sidebar-width);
  min-width: var(--sidebar-width);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  background: var(--bg-sidebar);
}

.workspace-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  background: var(--bg);
}
</style>
```

- [ ] **Step 2: Verify**

Open the workspace page. Sidebar should have warm background, main area should be slightly different shade.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/WorkspacePage.vue
git commit -m "feat: apply warm palette to workspace layout"
```

---

## Task 3: MessageList — Message Bubbles

**Files:**
- Modify: `src/views/workspace/MessageList.vue:204-322`

- [ ] **Step 1: Replace the `<style scoped>` block**

Replace the entire `<style scoped>` section with Hermes-inspired message styling:

```vue
<style scoped>
.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px;
  display: flex;
  flex-direction: column;
}

/* ── Message rows ── */
.msg-row {
  display: flex;
  align-items: flex-start;
  padding: 12px 0;
  gap: 12px;
  animation: msg-in .25s ease;
  max-width: var(--msg-max);
  margin: 0 auto;
  width: 100%;
}

/* User messages: right-aligned bubble */
.msg-row.is-user {
  align-self: flex-end;
  max-width: 60%;
  flex-direction: row-reverse;
  margin: 0;
  margin-left: auto;
}

.msg-role {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 9px;
  font-weight: 700;
}

.msg-role.user {
  background: var(--accent-bg);
  color: var(--accent-text);
  border: 1px solid var(--accent-bg-strong);
}

.msg-role.user .material-symbols-outlined {
  font-size: 12px;
}

.msg-role.assistant {
  background: rgba(138,101,32,.12);
  color: #8a6520;
  border: 1px solid rgba(138,101,32,.25);
}

[data-theme='dark'] .msg-role.assistant {
  background: rgba(212,160,23,.12);
  color: var(--accent-text);
  border: 1px solid rgba(212,160,23,.25);
}

.msg-role.assistant .material-symbols-outlined {
  font-size: 12px;
}

.msg-body {
  max-width: var(--msg-max);
  line-height: 1.75;
  position: relative;
  font-size: 14px;
  overflow-wrap: anywhere;
}

/* User bubble */
.is-user .msg-body {
  background: var(--accent);
  border: 1px solid var(--accent-hover);
  border-radius: 14px;
  padding: 10px 14px;
  max-width: none;
  text-align: left;
}

.is-user .msg-content {
  color: #fff;
}

.is-user .msg-body code {
  color: #fff;
  background: rgba(0,0,0,.1);
}

/* Assistant: plain text */
.is-assistant .msg-content {
  color: var(--text);
}

.msg-time {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 4px;
  opacity: .6;
}

.is-user .msg-time {
  text-align: right;
}

/* Tool rows */
.msg-row.is-tool {
  padding-left: 0;
}

/* ── Typing indicator ── */
.typing-indicator {
  display: flex;
  gap: 4px;
  padding: 8px 0;
}

.typing-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
  animation: pulse 1.2s ease-in-out infinite;
}

.typing-dot:nth-child(2) { animation-delay: 0.2s; }
.typing-dot:nth-child(3) { animation-delay: 0.4s; }

/* ── Error banner ── */
.error-banner {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: rgba(198,40,40,.08);
  border-radius: 8px;
  border-left: 3px solid var(--error);
  max-width: var(--msg-max);
  margin: 0 auto;
  width: 100%;
}

/* ── Empty state ── */
.empty-messages {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--text-muted);
}
</style>
```

- [ ] **Step 2: Update the template to add role label for assistant messages**

In the assistant message block (around line 136–158), add a role label row above the body. Find:

```vue
<div v-else-if="msg.role === 'assistant'" class="msg-row is-assistant">
  <div class="msg-role assistant">
    <span class="material-symbols-outlined">smart_toy</span>
  </div>
  <div class="msg-body">
```

Replace with:

```vue
<div v-else-if="msg.role === 'assistant'" class="msg-row is-assistant">
  <div class="msg-role assistant">
    <span class="material-symbols-outlined">smart_toy</span>
  </div>
  <div class="msg-body">
    <div class="msg-role-label">
      <span>{{ workspaceStore.selectedAgent?.name || 'Assistant' }}</span>
      <span class="msg-time">{{ formatTime(msg.timestamp) }}</span>
    </div>
```

And add the role label CSS after `.msg-role.assistant .material-symbols-outlined`:

```css
.msg-role-label {
  font-size: 11px;
  font-weight: 500;
  margin-bottom: 6px;
  opacity: .6;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--text-muted);
}
```

- [ ] **Step 3: Verify**

Open workspace, send a message. User message should be a right-aligned gold bubble. Assistant message should be left-aligned plain text with role label.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "feat: restyle messages with Hermes bubble design"
```

---

## Task 4: ChatInput — Composer

**Files:**
- Modify: `src/views/workspace/ChatInput.vue:250-381`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.chat-input-container {
  padding: 10px 20px 14px;
  border-top: 1px solid var(--border);
  background: var(--bg-sidebar);
  position: relative;
  z-index: 10;
}

.composer-box {
  max-width: var(--composer-max);
  margin: 0 auto;
  border-radius: 16px;
  background: var(--bg);
  border: 1px solid var(--border2);
  display: flex;
  flex-direction: column;
  transition: border-color .2s, box-shadow .2s;
  position: relative;
}

.composer-box:focus-within {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-bg);
}

.composer-input {
  width: 100%;
  min-height: 24px;
  max-height: 200px;
  resize: none;
  border: none;
  outline: none;
  background: transparent;
  font-size: 16px;
  line-height: 1.5;
  color: var(--text);
  font-family: inherit;
  padding: 12px 16px 0;
}

.composer-input::placeholder {
  color: var(--text-muted);
  opacity: .6;
}

.composer-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 10px 8px;
}

.composer-left-actions {
  display: flex;
  align-items: center;
  gap: 2px;
}

.composer-right-actions {
  display: flex;
  gap: 8px;
  align-items: center;
}

/* ── Attachment chips ── */
.attachment-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 0 16px;
  padding-top: 8px;
}

.attachment-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: var(--accent-bg);
  border: 1px solid var(--accent-bg-strong);
  border-radius: 6px;
  padding: 4px 9px;
  font-size: 12px;
  color: var(--accent-text);
}

.attachment-chip img {
  width: 32px;
  height: 32px;
  border-radius: 4px;
  object-fit: cover;
}

.attachment-chip .remove-btn {
  cursor: pointer;
  color: var(--accent-text);
  font-size: 14px;
  opacity: .6;
  margin-left: 4px;
}

.attachment-chip .remove-btn:hover {
  opacity: 1;
}

/* ── Drag over ── */
.composer-box.drag-over {
  border-color: var(--accent);
  background: var(--accent-bg);
  box-shadow: 0 0 0 2px var(--accent-bg);
}

/* ── Upload status ── */
.upload-status {
  font-size: 11px;
  color: var(--text-muted);
  padding: 0 16px;
  margin-top: 2px;
}

.upload-status.error {
  color: var(--error);
}

/* ── Send / Cancel buttons ── */
.cancel-btn {
  background: var(--error) !important;
  border-color: var(--error) !important;
  width: 34px;
  height: 34px;
  box-shadow: 0 2px 8px rgba(198,40,40,.2);
}

.cancel-btn:hover {
  transform: scale(1.06);
}

.cancel-btn:active {
  transform: scale(0.95);
}

.cancel-btn .material-symbols-outlined {
  font-size: 14px;
}

/* Send button override — accent colored circle */
.composer-right-actions :deep(.n-button--primary-type) {
  --n-color: var(--accent) !important;
  --n-color-hover: var(--accent-hover) !important;
  --n-color-pressed: var(--accent-hover) !important;
  --n-text-color: #fff !important;
  width: 34px;
  height: 34px;
  box-shadow: 0 2px 8px var(--accent-bg-strong);
  transition: all .15s;
}

.composer-right-actions :deep(.n-button--primary-type:hover) {
  transform: scale(1.08);
}

.composer-right-actions :deep(.n-button--primary-type:disabled) {
  opacity: .35;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.composer-right-actions .material-symbols-outlined {
  font-size: 16px;
}

/* Attach button */
.composer-left-actions :deep(.n-button) {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  color: var(--text-muted);
  transition: all .12s;
}

.composer-left-actions :deep(.n-button:hover) {
  background: var(--bg-hover);
  color: var(--text);
}
</style>
```

- [ ] **Step 2: Verify**

Open workspace, focus the input. It should show a rounded card with warm background, accent focus ring, and styled buttons.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "feat: restyle composer with Hermes card design"
```

---

## Task 5: ThinkingBlock — Accent Card

**Files:**
- Modify: `src/views/workspace/ThinkingBlock.vue:40-72`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.thinking-block {
  background: var(--accent-bg);
  border: 1px solid var(--accent-bg-strong);
  border-radius: 8px;
  margin: 6px 0;
  max-width: var(--msg-max);
  overflow: hidden;
  animation: msg-in .2s ease;
}

.thinking-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  color: var(--accent-text);
  user-select: none;
}

.thinking-header:hover {
  opacity: 1;
}

.toggle-icon {
  font-size: 10px;
  transition: transform .18s;
}

.toggle-icon.expanded {
  transform: rotate(90deg);
}

.thinking-label {
  flex: 1;
}

.thinking-count {
  font-size: 11px;
  color: var(--accent-text);
  opacity: .6;
}

.thinking-content {
  max-height: 500px;
  overflow-y: auto;
  padding: 8px 12px;
  border-top: 1px solid var(--accent-bg-strong);
  font-family: "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
  font-size: 11px;
  line-height: 1.6;
  color: var(--text-muted);
  white-space: pre-wrap;
  word-break: break-word;
}
</style>
```

- [ ] **Step 2: Verify**

Send a message that triggers thinking. The thinking block should appear with gold-tinted background and smooth expand/collapse.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ThinkingBlock.vue
git commit -m "feat: restyle thinking block with accent card design"
```

---

## Task 6: ToolCallCard — Running State

**Files:**
- Modify: `src/views/workspace/components/ToolCallCard.vue:51-123`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.tool-call-card {
  background: rgba(0,0,0,.02);
  border: 1px solid rgba(0,0,0,.08);
  border-radius: 8px;
  margin: 4px 0;
  max-width: var(--msg-max);
  overflow: hidden;
  cursor: pointer;
  animation: msg-in .2s ease;
}

[data-theme='dark'] .tool-call-card {
  background: rgba(255,255,255,.03);
  border-color: rgba(255,255,255,.08);
}

.tool-call-card.error {
  border-color: var(--error);
}

.tool-call-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  font-size: 12px;
  color: var(--text-muted);
  user-select: none;
}

.tool-call-header:hover {
  background: var(--bg-hover);
}

.tool-icon {
  font-size: 16px;
  flex-shrink: 0;
}

.tool-name {
  font-weight: 600;
  font-family: "SF Mono", ui-monospace, monospace;
  font-size: 11px;
  color: var(--text-muted);
}

.tool-toggle {
  margin-left: auto;
  font-size: 10px;
  color: var(--text-muted);
  opacity: .5;
  transition: transform .18s;
}

.tool-call-card.expanded .tool-toggle {
  transform: rotate(90deg);
}

.tool-call-body {
  padding: 8px 12px;
  font-family: "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
  font-size: 11px;
  max-height: 500px;
  overflow-y: auto;
  border-top: 1px solid rgba(0,0,0,.06);
}

[data-theme='dark'] .tool-call-body {
  border-top-color: rgba(255,255,255,.06);
}

.tool-section {
  margin-bottom: 4px;
}

.tool-section:last-child {
  margin-bottom: 0;
}

.tool-section-label {
  font-size: 11px;
  display: block;
  margin-bottom: 4px;
  color: var(--text-muted);
}

.tool-pre {
  font-size: 11px;
  line-height: 1.5;
  background: var(--bg-code);
  padding: 8px;
  border-radius: 6px;
  overflow-x: auto;
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 300px;
  overflow-y: auto;
  color: var(--text);
}
</style>
```

- [ ] **Step 2: Add `expanded` class binding to the template**

Find (line 32):
```vue
<div class="tool-call-card" :class="{ error: isError }" @click="toggle">
```

Replace with:
```vue
<div class="tool-call-card" :class="{ error: isError, expanded }" @click="toggle">
```

- [ ] **Step 3: Verify**

Trigger a tool call. Card should show with subtle background, expand/collapse with smooth transition.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/components/ToolCallCard.vue
git commit -m "feat: restyle tool call card with Hermes design"
```

---

## Task 7: WorkspaceSidebar — Warm Palette

**Files:**
- Modify: `src/views/workspace/WorkspaceSidebar.vue:201-332`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.workspace-sidebar {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}

.sidebar-title {
  font-weight: 600;
  font-size: 16px;
  color: var(--text);
}

.sidebar-search {
  padding: 8px 12px;
  flex-shrink: 0;
}

.sidebar-list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 0;
}

.agent-group {
  margin-bottom: 2px;
}

.agent-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  cursor: pointer;
  transition: background .12s;
  border-left: 3px solid transparent;
  border-radius: 0 8px 8px 0;
}

.agent-item:hover {
  background: var(--bg-hover);
}

.agent-item.active {
  background: var(--accent-bg);
  border-left-color: var(--accent);
}

.agent-avatar {
  font-size: 20px;
  flex-shrink: 0;
}

.agent-info {
  flex: 1;
  min-width: 0;
}

.agent-name {
  font-weight: 600;
  font-size: 13px;
  color: var(--text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.agent-session-count {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 2px;
}

.agent-expand-icon {
  font-size: 10px;
  color: var(--text-muted);
  flex-shrink: 0;
  transition: transform .18s;
}

.session-list {
  background: var(--bg-sidebar);
}

.session-group-label {
  padding: 8px 12px 3px 44px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: .04em;
}

.session-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  border-left: 3px solid transparent;
  transition: background .12s;
}

.session-item:hover {
  background: var(--bg-hover);
}

.session-item.active {
  background: var(--accent-bg);
  border-left-color: var(--accent);
}

.session-main {
  flex: 1;
  min-width: 0;
  padding-left: 28px;
  cursor: pointer;
}

.session-label {
  font-size: 13px;
  color: var(--text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.session-meta {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 2px;
}

.session-menu-btn {
  opacity: 0;
  transition: opacity .12s;
}

.session-item:hover .session-menu-btn {
  opacity: 1;
}

.session-empty {
  padding: 8px 12px 8px 44px;
  font-size: 11px;
  color: var(--text-muted);
}

.session-streaming {
  display: inline-flex;
  align-items: center;
  margin-left: 4px;
}

.spinning {
  font-size: 14px;
  color: var(--accent);
  animation: pulse 1.2s ease-in-out infinite;
}
</style>
```

- [ ] **Step 2: Update the NButton in sidebar-header**

Find (line 91–98):
```vue
<NButton
  size="tiny"
  type="primary"
  :disabled="!workspaceStore.selectedAgentId"
  @click="workspaceStore.selectedAgentId && handleNewChat(workspaceStore.selectedAgentId)"
>
```

Add a class:
```vue
<NButton
  size="tiny"
  type="primary"
  class="new-chat-btn"
  :disabled="!workspaceStore.selectedAgentId"
  @click="workspaceStore.selectedAgentId && handleNewChat(workspaceStore.selectedAgentId)"
>
```

Add CSS:
```css
.new-chat-btn {
  --n-color: var(--accent) !important;
  --n-color-hover: var(--accent-hover) !important;
  --n-text-color: #fff !important;
  border-radius: 8px !important;
}
```

- [ ] **Step 3: Verify**

Sidebar should have warm background, agent items should highlight with gold accent on select.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/WorkspaceSidebar.vue
git commit -m "feat: restyle sidebar with warm earth-tone palette"
```

---

## Task 8: ChatHeader — Compact + Warm

**Files:**
- Modify: `src/views/workspace/ChatHeader.vue:37-55`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: var(--header-height);
  border-bottom: 1px solid var(--border);
  background: var(--bg-sidebar);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.agent-icon {
  font-size: 20px;
  color: var(--accent);
}

.agent-name {
  font-weight: 600;
  font-size: 14px;
  color: var(--text);
}

.session-label {
  font-size: 13px;
  color: var(--text-muted);
  margin-left: 4px;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.model-chip {
  font-size: 12px;
  padding: 2px 10px;
  border-radius: 999px;
  background: var(--accent-bg);
  color: var(--accent-text);
  border: 1px solid var(--accent-bg-strong);
  font-weight: 500;
}

.connection-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--error);
}

.connection-dot.connected {
  background: var(--success);
}
</style>
```

- [ ] **Step 2: Verify**

Header should be 56px tall, warm background, gold accent icon, model chip with accent styling.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatHeader.vue
git commit -m "feat: restyle header with warm palette and compact height"
```

---

## Task 9: WelcomeScreen — Warm Empty State

**Files:**
- Modify: `src/views/workspace/WelcomeScreen.vue:18-48`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.welcome-screen {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  gap: 16px;
  color: var(--text-muted);
  user-select: none;
}

.welcome-icon {
  font-size: 72px;
  color: var(--accent);
  filter: drop-shadow(0 2px 8px rgba(184,134,11,.2));
}

.welcome-title {
  font-size: 22px;
  font-weight: 600;
  color: var(--text);
  margin: 0;
}

.welcome-hint {
  font-size: 14px;
  text-align: center;
  max-width: 360px;
  line-height: 1.6;
  color: var(--text-muted);
}
</style>
```

- [ ] **Step 2: Verify**

Empty state should show gold icon with drop shadow, warm text colors.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/WelcomeScreen.vue
git commit -m "feat: restyle welcome screen with warm palette"
```

---

## Task 10: MarkdownRenderer — Code Blocks + Streaming Cursor

**Files:**
- Modify: `src/views/workspace/components/MarkdownRenderer.vue:55-186`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.markdown-body {
  font-size: 14px;
  line-height: 1.75;
  color: var(--text);
  word-break: break-word;
  overflow-wrap: anywhere;
}

.markdown-body :deep(p) { margin: 0 0 10px; }
.markdown-body :deep(p:last-child) { margin-bottom: 0; }

.markdown-body :deep(pre.hljs) {
  position: relative;
  background: var(--bg-code);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 14px 16px;
  margin: 10px 0;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.6;
}

.markdown-body :deep(pre.hljs .code-copy-btn) {
  position: absolute;
  top: 6px;
  right: 6px;
  background: var(--bg-hover);
  border: none;
  border-radius: 6px;
  padding: 2px 8px;
  font-size: 11px;
  cursor: pointer;
  color: var(--text-muted);
  opacity: 0;
  transition: opacity .2s;
}

.markdown-body :deep(pre.hljs:hover .code-copy-btn) {
  opacity: 1;
}

.markdown-body :deep(code) {
  background: var(--code-inline-bg);
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 12.5px;
  font-family: "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
  color: var(--text-strong);
}

.markdown-body :deep(pre.hljs code) {
  background: none;
  padding: 0;
  font-size: inherit;
  color: inherit;
}

.markdown-body :deep(table) {
  border-collapse: collapse;
  width: 100%;
  margin: 8px 0;
  font-size: 12px;
}

.markdown-body :deep(th),
.markdown-body :deep(td) {
  border: 1px solid var(--border2);
  padding: 5px 10px;
  text-align: left;
}

.markdown-body :deep(th) {
  background: rgba(0,0,0,.04);
  font-weight: 600;
}

[data-theme='dark'] .markdown-body :deep(th) {
  background: rgba(255,255,255,.04);
}

.markdown-body :deep(tr:nth-child(even)) {
  background: rgba(0,0,0,.02);
}

[data-theme='dark'] .markdown-body :deep(tr:nth-child(even)) {
  background: rgba(255,255,255,.02);
}

.markdown-body :deep(blockquote) {
  border-left: 3px solid var(--blue);
  padding-left: 14px;
  margin: 10px 0;
  color: var(--text-muted);
  font-style: italic;
}

.markdown-body :deep(blockquote p) {
  margin: 0;
}

.markdown-body :deep(ul),
.markdown-body :deep(ol) {
  padding-left: 20px;
  margin: 6px 0 10px;
}

.markdown-body :deep(li) {
  margin-bottom: 3px;
}

.markdown-body :deep(a) {
  color: var(--blue);
  text-decoration: underline;
}

.markdown-body :deep(strong) {
  color: var(--text-strong);
  font-weight: 600;
}

.markdown-body :deep(h1),
.markdown-body :deep(h2),
.markdown-body :deep(h3) {
  margin: 16px 0 6px;
  font-weight: 600;
}

.markdown-body :deep(h1) { font-size: 18px; }
.markdown-body :deep(h2) { font-size: 16px; }
.markdown-body :deep(h3) { font-size: 14px; }

.markdown-body :deep(hr) {
  border: none;
  border-top: 1px solid var(--border);
  margin: 12px 0;
}

.markdown-body :deep(img) {
  max-width: 100%;
  border-radius: 8px;
  cursor: pointer;
}

/* ── Streaming cursor ── */
.streaming-cursor::after {
  content: '';
  display: inline-block;
  width: 7px;
  height: 1em;
  background: var(--accent);
  border-radius: 1px;
  margin-left: 2px;
  vertical-align: text-bottom;
  animation: blink .9s step-end infinite;
}
</style>
```

- [ ] **Step 2: Verify**

Code blocks should have warm beige background (light) or warm dark (dark). Streaming cursor should be a gold block.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/components/MarkdownRenderer.vue
git commit -m "feat: restyle markdown renderer with warm code blocks and gold cursor"
```

---

## Task 11: MessageActions — Hover Fix

**Files:**
- Modify: `src/views/workspace/components/MessageActions.vue:59-88`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.message-actions {
  display: flex;
  gap: 4px;
  opacity: 0;
  transition: opacity .15s ease;
  margin-top: 4px;
}

/* Use :deep to target parent class safely */
.message-actions :deep(.n-button) {
  color: var(--text-muted);
  transition: all .12s;
}

.message-actions :deep(.n-button:hover) {
  background: var(--bg-hover);
  color: var(--text);
}
</style>
```

- [ ] **Step 2: Update the template to show actions on parent hover**

The current `.msg-row:hover .message-actions` selector in the parent's scoped style won't reliably reach this child. Instead, add a prop-based approach. But since we're only changing styles, we can use a CSS trick — move the hover rule into MessageList.vue.

In `MessageList.vue`, add to the `<style scoped>` block:

```css
.msg-row:hover .message-actions {
  opacity: 1;
}
```

- [ ] **Step 3: Verify**

Hover over an assistant message — action buttons should appear.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/components/MessageActions.vue src/views/workspace/MessageList.vue
git commit -m "fix: message actions hover visibility with scoped style"
```

---

## Task 12: SlashCommandMenu — Warm Palette

**Files:**
- Modify: `src/views/workspace/components/SlashCommandMenu.vue:76-123`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.slash-menu {
  position: absolute;
  bottom: 100%;
  left: 0;
  right: 0;
  background: var(--bg-surface);
  border: 1px solid var(--border2);
  border-radius: 10px;
  box-shadow: 0 -4px 20px rgba(0,0,0,.1);
  max-height: 200px;
  overflow-y: auto;
  z-index: 100;
  margin-bottom: 4px;
  padding: 4px;
}

.slash-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  cursor: pointer;
  transition: background .1s;
  border-radius: 6px;
  font-size: 13px;
  color: var(--text);
}

.slash-item.selected,
.slash-item:hover {
  background: var(--accent-bg);
  color: var(--accent-text);
}

.slash-name {
  font-weight: 600;
  font-size: 13px;
  font-family: "SF Mono", ui-monospace, monospace;
  color: var(--accent-text);
}

.slash-args {
  font-size: 11px;
  color: var(--text-muted);
  font-family: "SF Mono", ui-monospace, monospace;
}

.slash-desc {
  font-size: 12px;
  margin-left: auto;
  color: var(--text-muted);
}
</style>
```

- [ ] **Step 2: Verify**

Type `/` in the input. Menu should appear with warm surface background and accent highlights.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/components/SlashCommandMenu.vue
git commit -m "feat: restyle slash command menu with warm palette"
```

---

## Task 13: ImageLightbox — Warm Overlay

**Files:**
- Modify: `src/views/workspace/components/ImageLightbox.vue:22-39`

- [ ] **Step 1: Replace the `<style scoped>` block**

```vue
<style scoped>
.lightbox-overlay {
  position: fixed;
  inset: 0;
  background: rgba(26,24,20,.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  cursor: pointer;
  animation: msg-in .2s ease;
}

[data-theme='dark'] .lightbox-overlay {
  background: rgba(0,0,0,.92);
}

.lightbox-image {
  max-width: 90vw;
  max-height: 90vh;
  border-radius: 8px;
  cursor: default;
}
</style>
```

- [ ] **Step 2: Verify**

Click an image in a message. Lightbox should show with warm dark overlay.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/components/ImageLightbox.vue
git commit -m "feat: warm overlay for image lightbox"
```

---

## Task 14: Final Verification + Commit

- [ ] **Step 1: Full visual test**

Run `npm run dev` and test the complete flow:
1. Open workspace — warm empty state
2. Select an agent — sidebar highlights with gold accent
3. Send a message — user bubble appears right-aligned gold, assistant left-aligned plain text
4. Thinking block appears with gold tint, collapses smoothly
5. Tool call card shows with subtle background
6. Code blocks have warm beige/dark background
7. Streaming cursor is a gold block
8. Toggle dark mode — all elements adapt to warm dark palette
9. Other pages (Agent Team, Models) still look reasonable

- [ ] **Step 2: Type check**

```bash
npx vue-tsc --noEmit
```

- [ ] **Step 3: Build check**

```bash
npm run build
```

- [ ] **Step 4: Final commit (if any fixes needed)**

```bash
git add -A
git commit -m "fix: visual polish for workspace redesign"
```
