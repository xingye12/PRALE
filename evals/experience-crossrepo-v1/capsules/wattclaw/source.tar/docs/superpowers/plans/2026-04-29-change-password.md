# 修改密码功能实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现修改密码 UI 入口 + 新用户首次登录强制改密引导

**Architecture:** 数据库新增 `password_changed_at` 字段追踪密码修改状态；路由守卫拦截未改密用户跳转引导页；头像菜单提供主动改密 Modal

**Tech Stack:** Vue 3 + TypeScript + Naive UI + Express + better-sqlite3

---

## 文件结构

| 文件 | 职责 |
|------|------|
| `server/database.js` | 新增 `password_changed_at` 迁移 |
| `server/user-manager.js` | `updateUser` 更新时间戳；`initDefaultAdmin` 设置初始值 |
| `src/api/types/user.ts` | `User` 接口新增字段 |
| `src/i18n/messages/zh-CN.ts` | 中文 i18n |
| `src/i18n/messages/en-US.ts` | 英文 i18n |
| `src/router/routes.ts` | 新增 ForceChangePassword 路由 |
| `src/router/index.ts` | beforeEach 增加强制改密检查 |
| `src/views/ForceChangePasswordPage.vue` | 强制改密全屏页面 |
| `src/components/layout/AppHeader.vue` | 头像菜单新增"修改密码" + Modal |

---

### Task 1: 数据库迁移 + 后端

**Files:**
- Modify: `server/database.js:256-266`
- Modify: `server/user-manager.js:18-34`
- Modify: `server/user-manager.js:127-155`

- [ ] **Step 1: 添加数据库迁移**

在 `server/database.js` 的 `migrations` 数组中新增一行：

```javascript
const migrations = [
  'ALTER TABLE user_agents ADD COLUMN category TEXT',
  'ALTER TABLE user_agents ADD COLUMN template_id TEXT',
  'ALTER TABLE user_agents ADD COLUMN avatar TEXT',
  'ALTER TABLE user_channels ADD COLUMN agent_id TEXT',
  'ALTER TABLE users ADD COLUMN password_changed_at INTEGER',
]
```

- [ ] **Step 2: 修改 initDefaultAdmin 设置 password_changed_at**

在 `server/user-manager.js` 的 `initDefaultAdmin` 函数中，INSERT 和 UPDATE 语句都加上 `password_changed_at`：

```javascript
export function initDefaultAdmin(username, password) {
  if (!username || !password) return
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username)
  if (!existing) {
    const { hash, salt } = hashPassword(password)
    db.prepare(`
      INSERT INTO users (id, username, password_hash, role, display_name, status, settings, password_changed_at)
      VALUES (?, ?, ?, 'admin', 'Administrator', 'active', ?, ?)
    `).run(randomUUID(), username, `${salt}:${hash}`, JSON.stringify({ salt }), Date.now())
  } else {
    const { hash, salt } = hashPassword(password)
    db.prepare(`
      UPDATE users SET password_hash = ?, settings = ?, updated_at = ?, password_changed_at = COALESCE(password_changed_at, ?)
      WHERE id = ?
    `).run(`${salt}:${hash}`, JSON.stringify({ salt }), Date.now(), Date.now(), existing.id)
  }
}
```

- [ ] **Step 3: 修改 updateUser 更新 password_changed_at**

在 `server/user-manager.js` 的 `updateUser` 函数中，当 `updates.password` 存在时，同时更新 `password_changed_at`：

```javascript
if (updates.password) {
  const { hash, salt } = hashPassword(updates.password)
  fields.push('password_hash = ?')
  values.push(`${salt}:${hash}`)
  fields.push('settings = ?')
  values.push(JSON.stringify({ salt }))
  fields.push('password_changed_at = ?')
  values.push(Date.now())
}
```

- [ ] **Step 4: 验证后端改动**

重启后端，确认：
1. 迁移无报错（`duplicate column name` 错误会被静默忽略）
2. `GET /api/auth/check` 返回的 user 对象包含 `password_changed_at` 字段
3. `PUT /api/auth/password` 成功后 `password_changed_at` 更新为当前时间

```bash
npm run dev:server
```

- [ ] **Step 5: 提交**

```bash
git add server/database.js server/user-manager.js
git commit -m "feat: add password_changed_at tracking to database and backend"
```

---

### Task 2: 前端类型 + i18n

**Files:**
- Modify: `src/api/types/user.ts:1-12`
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: 扩展 User 类型**

在 `src/api/types/user.ts` 的 `User` 接口中新增字段：

```typescript
export interface User {
  id: string
  username: string
  role: 'admin' | 'user'
  display_name: string | null
  email: string | null
  avatar: string | null
  status: 'active' | 'disabled'
  settings: Record<string, unknown>
  password_changed_at: number | null
  created_at: number
  updated_at: number
}
```

- [ ] **Step 2: 添加中文 i18n**

在 `src/i18n/messages/zh-CN.ts` 中新增：

`common` 对象中添加：
```typescript
changePassword: '修改密码',
```

`pages` 对象中添加新板块：
```typescript
forceChangePassword: {
  title: '欢迎加入 WattClaw',
  subtitle: '为了您的账户安全，请为自己设置一个新密码',
  currentPassword: '当前密码',
  currentPasswordPlaceholder: '请输入当前密码',
  newPassword: '新密码',
  newPasswordPlaceholder: '请输入新密码',
  confirmPassword: '确认新密码',
  confirmPasswordPlaceholder: '请再次输入新密码',
  submit: '确认修改',
  success: '密码修改成功',
  passwordMismatch: '两次输入的密码不一致',
  passwordTooShort: '密码长度至少6位',
},
```

- [ ] **Step 3: 添加英文 i18n**

在 `src/i18n/messages/en-US.ts` 中新增：

`common` 对象中添加：
```typescript
changePassword: 'Change Password',
```

`pages` 对象中添加新板块：
```typescript
forceChangePassword: {
  title: 'Welcome to WattClaw',
  subtitle: 'For your account security, please set a new password',
  currentPassword: 'Current Password',
  currentPasswordPlaceholder: 'Enter current password',
  newPassword: 'New Password',
  newPasswordPlaceholder: 'Enter new password',
  confirmPassword: 'Confirm New Password',
  confirmPasswordPlaceholder: 'Enter new password again',
  submit: 'Confirm',
  success: 'Password changed successfully',
  passwordMismatch: 'Passwords do not match',
  passwordTooShort: 'Password must be at least 6 characters',
},
```

- [ ] **Step 4: 类型检查**

```bash
npx vue-tsc --noEmit
```

Expected: 无新增错误（`password_changed_at` 在 auth store 的 `checkAuth` 返回中自动包含）

- [ ] **Step 5: 提交**

```bash
git add src/api/types/user.ts src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: add User.password_changed_at type and change-password i18n keys"
```

---

### Task 3: 强制改密页面

**Files:**
- Create: `src/views/ForceChangePasswordPage.vue`

- [ ] **Step 1: 创建 ForceChangePasswordPage.vue**

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { NButton, NInput, NForm, NFormItem, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const message = useMessage()
const { t } = useI18n()

const form = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
})
const loading = ref(false)

async function handleSubmit() {
  if (!form.value.currentPassword || !form.value.newPassword || !form.value.confirmPassword) {
    message.warning(t('pages.forceChangePassword.passwordTooShort'))
    return
  }
  if (form.value.newPassword.length < 6) {
    message.warning(t('pages.forceChangePassword.passwordTooShort'))
    return
  }
  if (form.value.newPassword !== form.value.confirmPassword) {
    message.warning(t('pages.forceChangePassword.passwordMismatch'))
    return
  }

  loading.value = true
  const error = await authStore.changePassword(form.value.currentPassword, form.value.newPassword)
  loading.value = false

  if (error) {
    message.error(error)
    return
  }

  await authStore.checkAuth()
  message.success(t('pages.forceChangePassword.success'))
  const redirect = typeof route.query.redirect === 'string' ? route.query.redirect : '/'
  router.push(redirect)
}
</script>

<template>
  <div class="force-change-page">
    <div class="force-change-card">
      <div class="force-change-header">
        <div class="force-change-icon">
          <span class="material-symbols-outlined">lock_reset</span>
        </div>
        <h1 class="force-change-title">{{ t('pages.forceChangePassword.title') }}</h1>
        <p class="force-change-subtitle">{{ t('pages.forceChangePassword.subtitle') }}</p>
        <p v-if="authStore.currentUser" class="force-change-user">
          {{ authStore.currentUser.display_name || authStore.currentUser.username }}
        </p>
      </div>

      <NForm class="force-change-form" @submit.prevent="handleSubmit">
        <NFormItem>
          <NInput
            v-model:value="form.currentPassword"
            type="password"
            show-password-on="click"
            :placeholder="t('pages.forceChangePassword.currentPasswordPlaceholder')"
            size="large"
          />
        </NFormItem>
        <NFormItem>
          <NInput
            v-model:value="form.newPassword"
            type="password"
            show-password-on="click"
            :placeholder="t('pages.forceChangePassword.newPasswordPlaceholder')"
            size="large"
          />
        </NFormItem>
        <NFormItem>
          <NInput
            v-model:value="form.confirmPassword"
            type="password"
            show-password-on="click"
            :placeholder="t('pages.forceChangePassword.confirmPasswordPlaceholder')"
            size="large"
            @keyup.enter="handleSubmit"
          />
        </NFormItem>
        <NButton
          type="primary"
          block
          size="large"
          :loading="loading"
          @click="handleSubmit"
        >
          {{ t('pages.forceChangePassword.submit') }}
        </NButton>
      </NForm>
    </div>
  </div>
</template>

<style scoped>
.force-change-page {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: var(--bg-primary, #f5f5f5);
  padding: 24px;
}

.force-change-card {
  width: 100%;
  max-width: 400px;
  background: var(--bg-card, #fff);
  border-radius: 16px;
  padding: 40px 32px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.force-change-header {
  text-align: center;
  margin-bottom: 32px;
}

.force-change-icon {
  width: 56px;
  height: 56px;
  border-radius: 16px;
  background: linear-gradient(135deg, #d32f2f, #b71c1c);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}

.force-change-icon .material-symbols-outlined {
  font-size: 28px;
  color: #fff;
}

.force-change-title {
  font-size: 22px;
  font-weight: 700;
  color: var(--text-primary, #1a1a1a);
  margin: 0 0 8px;
}

.force-change-subtitle {
  font-size: 14px;
  color: var(--text-secondary, #666);
  margin: 0 0 8px;
}

.force-change-user {
  font-size: 13px;
  color: var(--text-tertiary, #999);
  margin: 0;
}

.force-change-form {
  margin-top: 8px;
}
</style>
```

- [ ] **Step 2: 类型检查**

```bash
npx vue-tsc --noEmit
```

Expected: 无错误

- [ ] **Step 3: 提交**

```bash
git add src/views/ForceChangePasswordPage.vue
git commit -m "feat: add force change password page"
```

---

### Task 4: 路由 + 路由守卫

**Files:**
- Modify: `src/router/routes.ts:3-9`
- Modify: `src/router/index.ts:10-43`

- [ ] **Step 1: 添加 ForceChangePassword 路由**

在 `src/router/routes.ts` 中，在 Login 路由之后添加：

```typescript
{
  path: '/force-change-password',
  name: 'ForceChangePassword',
  component: () => import('@/views/ForceChangePasswordPage.vue'),
  meta: { public: true },
},
```

- [ ] **Step 2: 修改路由守卫**

在 `src/router/index.ts` 的 `beforeEach` 中，在 `checkAuth` 成功之后、`requiresAdmin` 检查之前，增加强制改密逻辑：

```typescript
router.beforeEach(async (to, _from, next) => {
  const authStore = useAuthStore()

  if (to.meta.public) {
    if (to.name === 'Login' && authStore.isAuthenticated) {
      const valid = await authStore.checkAuth()
      if (valid) {
        const redirect = typeof to.query.redirect === 'string' ? to.query.redirect : '/'
        next(redirect)
        return
      }
    }
    next()
    return
  }

  if (!authStore.isAuthenticated) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  const valid = await authStore.checkAuth()
  if (!valid) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  // Force password change for users who haven't changed their password
  if (authStore.currentUser?.password_changed_at === null && to.name !== 'ForceChangePassword') {
    next({ name: 'ForceChangePassword', query: { redirect: to.fullPath } })
    return
  }

  if (to.meta.requiresAdmin && !authStore.isAdmin) {
    next({ name: 'Dashboard' })
    return
  }

  next()
})
```

- [ ] **Step 3: 类型检查**

```bash
npx vue-tsc --noEmit
```

Expected: 无错误

- [ ] **Step 4: 提交**

```bash
git add src/router/routes.ts src/router/index.ts
git commit -m "feat: add force-change-password route and guard"
```

---

### Task 5: 头像菜单修改密码 Modal

**Files:**
- Modify: `src/components/layout/AppHeader.vue`

- [ ] **Step 1: 添加 Modal 状态和表单**

在 `AppHeader.vue` 的 `<script setup>` 中添加：

```typescript
const showPasswordModal = ref(false)
const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
})
const passwordLoading = ref(false)

function openChangePassword() {
  passwordForm.value = { currentPassword: '', newPassword: '', confirmPassword: '' }
  showPasswordModal.value = true
}

async function handleChangePassword() {
  if (!passwordForm.value.currentPassword || !passwordForm.value.newPassword || !passwordForm.value.confirmPassword) {
    message.warning(t('pages.forceChangePassword.passwordTooShort'))
    return
  }
  if (passwordForm.value.newPassword.length < 6) {
    message.warning(t('pages.forceChangePassword.passwordTooShort'))
    return
  }
  if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
    message.warning(t('pages.forceChangePassword.passwordMismatch'))
    return
  }

  passwordLoading.value = true
  const error = await authStore.changePassword(passwordForm.value.currentPassword, passwordForm.value.newPassword)
  passwordLoading.value = false

  if (error) {
    message.error(error)
    return
  }

  await authStore.checkAuth()
  message.success(t('pages.forceChangePassword.success'))
  showPasswordModal.value = false
}
```

需要导入 `ref` 和 `NModal, NInput, NForm, NFormItem`（检查现有导入）。

- [ ] **Step 2: 修改用户下拉菜单**

在 `userDropdownOptions` 中，在 settings 和 logout 之间插入修改密码选项：

```typescript
const userDropdownOptions = computed(() => {
  const items: Array<{ label: string; key: string; disabled?: boolean; type?: string }> = [
    { label: authStore.currentUser?.display_name || authStore.currentUser?.username || '', key: 'info', disabled: true },
    { label: '', type: 'divider', key: 'd1' },
  ]
  if (authStore.isAdmin) {
    items.push({ label: t('routes.settings'), key: 'settings' })
  }
  items.push({ label: t('common.changePassword'), key: 'changePassword' })
  items.push({ label: t('common.logout'), key: 'logout' })
  return items
})
```

- [ ] **Step 3: 修改 handleUserAction**

```typescript
function handleUserAction(key: string) {
  if (key === 'logout') handleLogout()
  else if (key === 'settings') router.push({ name: 'Settings' })
  else if (key === 'changePassword') openChangePassword()
}
```

- [ ] **Step 4: 添加 Modal 模板**

在 `</template>` 之前（header-container div 之后）添加：

```vue
<NModal v-model:show="showPasswordModal" preset="card" :title="t('common.changePassword')" style="max-width: 400px;">
  <NForm @submit.prevent="handleChangePassword">
    <NFormItem>
      <NInput
        v-model:value="passwordForm.currentPassword"
        type="password"
        show-password-on="click"
        :placeholder="t('pages.forceChangePassword.currentPasswordPlaceholder')"
      />
    </NFormItem>
    <NFormItem>
      <NInput
        v-model:value="passwordForm.newPassword"
        type="password"
        show-password-on="click"
        :placeholder="t('pages.forceChangePassword.newPasswordPlaceholder')"
      />
    </NFormItem>
    <NFormItem>
      <NInput
        v-model:value="passwordForm.confirmPassword"
        type="password"
        show-password-on="click"
        :placeholder="t('pages.forceChangePassword.confirmPasswordPlaceholder')"
        @keyup.enter="handleChangePassword"
      />
    </NFormItem>
    <NButton type="primary" block :loading="passwordLoading" @click="handleChangePassword">
      {{ t('pages.forceChangePassword.submit') }}
    </NButton>
  </NForm>
</NModal>
```

- [ ] **Step 5: 类型检查**

```bash
npx vue-tsc --noEmit
```

Expected: 无错误

- [ ] **Step 6: 提交**

```bash
git add src/components/layout/AppHeader.vue
git commit -m "feat: add change password option to user dropdown menu"
```

---

### Task 6: 验证

- [ ] **Step 1: 启动开发服务器**

```bash
./start.sh
```

- [ ] **Step 2: 验证新用户强制改密流程**

1. 用 `test1:admin123` 登录（未改过密码的用户）
2. 应自动跳转到 `/force-change-password` 页面
3. 显示"欢迎加入 WattClaw"标题和用户名
4. 输入旧密码、新密码、确认密码
5. 提交后跳转到首页
6. 再次登录不再跳转

- [ ] **Step 3: 验证头像菜单修改密码**

1. 点击右上角头像
2. 下拉菜单中应有"修改密码"选项
3. 点击后弹出 Modal
4. 输入旧密码、新密码、确认密码
5. 提交成功后弹窗关闭，提示"密码修改成功"

- [ ] **Step 4: 验证 admin 不被强制改密**

1. 用 `admin:admin123` 登录
2. 应直接进入首页，不跳转到改密页

- [ ] **Step 5: 最终提交**

```bash
git add -A
git commit -m "feat: complete change password feature with force-first-login prompt"
```
