# Deferred Session Creation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Defer session creation until the user sends their first message, eliminating the empty random-ID session from the sidebar.

**Architecture:** Remove `startNewChat` calls from agent selection paths (page mount, sidebar click). `selectAgent` becomes the single entry point for agent selection — it already clears `activeSessionKey` and loads sessions. `sendMessage`'s existing fallback handles session creation on first send.

**Tech Stack:** Vue 3 + TypeScript + Pinia

---

## File Map

| File | Change |
|------|--------|
| `src/stores/workspace.ts:214-223` | `selectAgent` — add `selectedModel` from agent config |
| `src/views/workspace/WorkspacePage.vue:20-48` | Remove `startNewChat` from mount and watcher |
| `src/views/workspace/WorkspaceSidebar.vue:19-34` | Remove `startNewChat` from `handleAgentClick`, change `handleNewChat` |

---

### Task 1: Update `selectAgent` in workspace store

**Files:**
- Modify: `src/stores/workspace.ts:214-223`

`selectAgent` already does most of what we need (sets `selectedAgentId`, clears `activeSessionKey`, clears messages, loads sessions). The only missing piece is setting `selectedModel` from the agent config — currently only `startNewChat` does this.

- [ ] **Step 1: Add `selectedModel` initialization to `selectAgent`**

In `src/stores/workspace.ts`, find `selectAgent` (line 214) and add model selection after setting the agent:

```typescript
async function selectAgent(agentId: string) {
  selectedAgentId.value = agentId
  activeSessionKey.value = null
  messages.value = []
  const agent = agents.value.find((a) => a.agentId === agentId)
  if (agent) {
    agent.expanded = true
    if (agent.model) {
      selectedModel.value = agent.model
    }
  }
  await loadAgentSessions(agentId)
}
```

- [ ] **Step 2: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: set selectedModel in selectAgent for deferred session creation"
```

---

### Task 2: Remove `startNewChat` from WorkspacePage

**Files:**
- Modify: `src/views/workspace/WorkspacePage.vue:20-48`

Currently mount calls `selectAgent + startNewChat` when `agentId` query param is present. The watcher does the same. Both should only call `selectAgent`.

- [ ] **Step 1: Update mount logic**

In `src/views/workspace/WorkspacePage.vue`, replace lines 24-30:

```typescript
// Before:
if (agentId) {
  await workspaceStore.selectAgent(agentId)
  await workspaceStore.startNewChat(agentId)
} else if (workspaceStore.activeSessionKey) {
  await workspaceStore.selectSession(workspaceStore.activeSessionKey)
}

// After:
if (agentId) {
  await workspaceStore.selectAgent(agentId)
} else if (workspaceStore.activeSessionKey) {
  await workspaceStore.selectSession(workspaceStore.activeSessionKey)
}
```

- [ ] **Step 2: Update route watcher**

Replace lines 43-48:

```typescript
// Before:
watch(() => route.query.agentId, async (newAgentId) => {
  if (newAgentId && typeof newAgentId === 'string') {
    await workspaceStore.selectAgent(newAgentId)
    await workspaceStore.startNewChat(newAgentId)
  }
})

// After:
watch(() => route.query.agentId, async (newAgentId) => {
  if (newAgentId && typeof newAgentId === 'string') {
    await workspaceStore.selectAgent(newAgentId)
  }
})
```

- [ ] **Step 3: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/WorkspacePage.vue
git commit -m "fix: remove startNewChat from workspace page mount and watcher"
```

---

### Task 3: Remove `startNewChat` from WorkspaceSidebar

**Files:**
- Modify: `src/views/workspace/WorkspaceSidebar.vue:19-34`

Two call sites need to change:
1. `handleAgentClick` — remove `startNewChat` after `selectAgent`
2. `handleNewChat` — change from `startNewChat` to `selectAgent`

- [ ] **Step 1: Update `handleAgentClick`**

Replace lines 19-26:

```typescript
// Before:
function handleAgentClick(agent: AgentWithSessions) {
  if (workspaceStore.selectedAgentId === agent.agentId) {
    agent.expanded = !agent.expanded
  } else {
    workspaceStore.selectAgent(agent.agentId)
    workspaceStore.startNewChat(agent.agentId)
  }
}

// After:
function handleAgentClick(agent: AgentWithSessions) {
  if (workspaceStore.selectedAgentId === agent.agentId) {
    agent.expanded = !agent.expanded
  } else {
    workspaceStore.selectAgent(agent.agentId)
  }
}
```

- [ ] **Step 2: Update `handleNewChat`**

Replace lines 32-34:

```typescript
// Before:
function handleNewChat(agentId: string) {
  workspaceStore.startNewChat(agentId)
}

// After:
function handleNewChat(agentId: string) {
  workspaceStore.selectAgent(agentId)
}
```

- [ ] **Step 3: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/WorkspaceSidebar.vue
git commit -m "fix: remove startNewChat from sidebar agent click and new chat button"
```

---

### Task 4: Browser verification

- [ ] **Step 1: Start dev server**

Run: `npm run dev`
Wait for server to be ready.

- [ ] **Step 2: Verify "去对话" flow**

1. Navigate to 数字员工 page
2. Click "去对话" on an agent card
3. Verify: workspace opens with agent selected, empty chat, NO random-ID session in sidebar
4. Type a message and send
5. Verify: session appears in sidebar after first message is sent

- [ ] **Step 3: Verify sidebar agent switching**

1. In workspace, click a different agent in the sidebar
2. Verify: agent switches, empty chat, NO new session in sidebar
3. Click an existing session under that agent
4. Verify: session history loads correctly

- [ ] **Step 4: Verify "新对话" button**

1. In workspace with an active session, click "新对话" button
2. Verify: chat clears, no new session in sidebar
3. Send a message
4. Verify: new session created and appears in sidebar

- [ ] **Step 5: Commit final state**

```bash
git status
```

Verify all changes are committed.
