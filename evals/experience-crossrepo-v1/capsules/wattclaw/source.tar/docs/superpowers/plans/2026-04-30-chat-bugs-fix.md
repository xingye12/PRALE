# Chat Bugs Fix Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix 5 workspace chat bugs: attachment display, thinking block, loading indicator, IME input, and auto-scroll.

**Architecture:** localStorage stores file metadata at send time for restore on history load. Thinking content extraction enhanced for both streaming and history paths. Auto-scroll watcher added for content changes. IME fix is a one-line change.

**Tech Stack:** Vue 3 + TypeScript, Pinia stores, localStorage

---

## File Map

| File | Changes |
|------|---------|
| `src/views/workspace/ChatInput.vue:123` | Add `!e.isComposing` to Enter handler |
| `src/stores/workspace.ts:126-151` | Enhance `normalizeRealtimeMessage` to extract thinking blocks |
| `src/stores/workspace.ts:290-301` | Restore file metadata from localStorage in `selectSession` |
| `src/stores/workspace.ts:361-367` | Store file metadata to localStorage in `sendMessage` |
| `src/views/workspace/MessageList.vue:110-117` | Add content-change watcher for auto-scroll |
| `src/views/workspace/MessageList.vue:235-239` | Strip thinking tags from `_renderedHtml` display |
| `src/views/workspace/MessageList.vue:267-276` | Enhance loading indicator with i18n text |
| `src/i18n/messages/zh-CN.ts:2580` | Add `processing` i18n key |
| `src/i18n/messages/en-US.ts:2575` | Add `processing` i18n key |

---

### Task 1: Fix IME Input (Bug 5)

**Files:**
- Modify: `src/views/workspace/ChatInput.vue:123`

- [ ] **Step 1: Add `!e.isComposing` check**

In `src/views/workspace/ChatInput.vue`, line 123, change:

```typescript
if (e.key === 'Enter' && !e.shiftKey) {
```

to:

```typescript
if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
```

This matches the pattern already used in `AgentChatPanel.vue:692` and `ChatPage.vue:2300`.

- [ ] **Step 2: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "fix: prevent IME composition from triggering send in workspace chat"
```

---

### Task 2: Fix Attachment Display (Bugs 1 & 2)

**Files:**
- Modify: `src/stores/workspace.ts:338-390` (sendMessage — store metadata)
- Modify: `src/stores/workspace.ts:272-307` (selectSession — restore metadata)

- [ ] **Step 1: Add localStorage helper functions**

At the top of `src/stores/workspace.ts`, after the existing imports (around line 9), add:

```typescript
const FILE_META_PREFIX = 'wc_files_'
const FILE_META_MAX = 500

function storeFileMeta(sessionKey: string, msgIndex: number, files: Array<{ name: string; size: number }>) {
  try {
    const key = `${FILE_META_PREFIX}${sessionKey}_${msgIndex}`
    localStorage.setItem(key, JSON.stringify(files))
    pruneFileMeta()
  } catch { /* quota exceeded — ignore */ }
}

function restoreFileMeta(sessionKey: string, msgIndex: number): Array<{ name: string; size: number }> | null {
  try {
    const raw = localStorage.getItem(`${FILE_META_PREFIX}${sessionKey}_${msgIndex}`)
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}

function pruneFileMeta() {
  const keys: string[] = []
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)
    if (k?.startsWith(FILE_META_PREFIX)) keys.push(k)
  }
  if (keys.length > FILE_META_MAX) {
    keys.sort()
    for (const k of keys.slice(0, keys.length - FILE_META_MAX)) {
      localStorage.removeItem(k)
    }
  }
}
```

- [ ] **Step 2: Store file metadata on send**

In `sendMessage` function, after the local message is pushed to `messages.value` (around line 368), add file metadata storage:

```typescript
// Store file metadata for history restore
if (files && files.length && activeSessionKey.value) {
  const userMsgCount = messages.value.filter(m => m.role === 'user').length
  storeFileMeta(activeSessionKey.value, userMsgCount - 1, files)
}
```

- [ ] **Step 3: Restore file metadata on session load**

In `selectSession`, modify the message mapping (lines 290-294) to restore metadata:

```typescript
messages.value = filtered.map((m, idx) => {
  if (m.role !== 'user') return m
  const { files, cleanedContent } = RPCClient.parseFileBlocks(m.content)
  if (!files) return m
  // Restore original filename and size from localStorage
  const stored = restoreFileMeta(sessionKey, idx)
  if (stored) {
    files.forEach((f, i) => {
      if (stored[i]) {
        f.name = stored[i].name
        f.size = stored[i].size
      }
    })
  }
  return { ...m, content: cleanedContent, files }
})
```

- [ ] **Step 4: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 5: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: preserve attachment filename and size across session switches via localStorage"
```

---

### Task 3: Fix Thinking Block Display (Bug 3)

**Files:**
- Modify: `src/stores/workspace.ts:126-151` (normalizeRealtimeMessage)
- Modify: `src/stores/workspace.ts:297-301` (selectSession — strip thinking from _renderedHtml)
- Modify: `src/views/workspace/MessageList.vue:235-239` (template — strip thinking from v-html)

- [ ] **Step 1: Enhance normalizeRealtimeMessage to extract thinking**

In `normalizeRealtimeMessage` (lines 126-151), the function flattens all content into a plain string. If the Gateway sends thinking as structured blocks, they get lost. Modify to detect and wrap thinking content:

```typescript
function normalizeRealtimeMessage(value: unknown): ChatMessage | null {
  const row = asRecord(value)
  if (!row) return null

  // Extract thinking from structured content blocks
  let thinkingText = ''
  const rawContent = row.content
  if (Array.isArray(rawContent)) {
    for (const item of rawContent) {
      const itemRow = asRecord(item)
      if (!itemRow) continue
      const type = typeof itemRow.type === 'string' ? itemRow.type : ''
      if (type === 'thinking' || type === 'thought') {
        const t = asText(itemRow.text || itemRow.thinking || itemRow.content)
        if (t.trim()) thinkingText += t
      }
    }
  }

  const content = asText(
    row.content ?? row.text ?? row.message ?? row.output ?? row.delta ?? row.payload ?? row.input
  ).trim()
  if (!content && !thinkingText) return null

  // Wrap thinking in tags so getThinkingContent can extract it
  const finalContent = thinkingText && !content.includes('<thinking>')
    ? `<thinking>${thinkingText}</thinking>${content}`
    : content

  const id = typeof row.id === 'string' ? row.id : typeof row.messageId === 'string' ? row.messageId : undefined
  const timestamp =
    typeof row.timestamp === 'string'
      ? row.timestamp
      : typeof row.createdAt === 'string'
        ? row.createdAt
        : typeof row.time === 'string'
          ? row.time
          : undefined

  return {
    id,
    role: normalizeRole(row.role ?? row.type),
    content: finalContent,
    timestamp,
  }
}
```

- [ ] **Step 2: Strip thinking tags from _renderedHtml**

In `selectSession`, after the markdown pre-rendering loop (lines 297-301), strip thinking tags from the rendered HTML:

```typescript
for (const m of messages.value) {
  if (m.role === 'assistant' && m.content) {
    // Strip <thinking> tags before rendering to avoid duplicate display with ThinkingBlock
    const cleanContent = m.content.replace(/<thinking>[\s\S]*?<\/thinking>/g, '').trim()
    ;(m as any)._renderedHtml = cleanContent ? renderMarkdown(cleanContent) : ''
  }
}
```

- [ ] **Step 3: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: display thinking blocks during streaming and prevent duplicate display in history"
```

---

### Task 4: Fix Loading Blank Period (Bug 4)

**Files:**
- Modify: `src/views/workspace/MessageList.vue:267-276` (enhance indicator)
- Modify: `src/i18n/messages/zh-CN.ts:2580` (add i18n key)
- Modify: `src/i18n/messages/en-US.ts:2575` (add i18n key)

- [ ] **Step 1: Add i18n key for processing state**

In `src/i18n/messages/zh-CN.ts`, after line 2580 (`emptyMessages`), add:

```typescript
processing: '正在思考...',
```

In `src/i18n/messages/en-US.ts`, after the corresponding `emptyMessages` line, add:

```typescript
processing: 'Processing...',
```

- [ ] **Step 2: Enhance the loading indicator**

In `src/views/workspace/MessageList.vue`, replace the existing typing indicator (lines 267-276):

```html
<!-- 思考中指示器 -->
<div v-if="workspaceStore.sending && !isStreaming" class="msg-row is-assistant">
  <div class="msg-role assistant">
    <span class="material-symbols-outlined">smart_toy</span>
  </div>
  <div class="typing-indicator">
    <span class="typing-dot"></span>
    <span class="typing-dot"></span>
    <span class="typing-dot"></span>
    <span class="typing-text">{{ t('pages.workspace.chat.processing') }}</span>
  </div>
</div>
```

- [ ] **Step 3: Add CSS for the typing text**

In the `<style scoped>` section, after the `.typing-dot:nth-child(3)` rule (around line 529), add:

```css
.typing-text {
  font-size: 13px;
  color: var(--text-muted);
  margin-left: 4px;
  opacity: .7;
}
```

- [ ] **Step 4: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/MessageList.vue src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "fix: show processing indicator during agent thinking/tool phase"
```

---

### Task 5: Fix Auto-Scroll During Streaming (Bug 6)

**Files:**
- Modify: `src/views/workspace/MessageList.vue:110-117` (add content watcher)

- [ ] **Step 1: Add content-change watcher for auto-scroll**

In `src/views/workspace/MessageList.vue`, after the existing `messages.length` watcher (lines 110-117), add a new watcher:

```typescript
// Auto-scroll when content changes in the last message (streaming deltas)
watch(
  () => {
    const msgs = workspaceStore.messages
    if (!msgs.length) return ''
    const last = msgs[msgs.length - 1]
    return last.content || ''
  },
  () => {
    if (isPinned.value) {
      nextTick(() => scrollToBottom())
    }
  }
)
```

Make sure `nextTick` is imported from `vue` (it should already be available via the existing `import { ref, computed, watch, onUnmounted } from 'vue'` — add `nextTick` to the import).

- [ ] **Step 2: Add nextTick to imports**

Line 2, change:

```typescript
import { ref, computed, watch, onUnmounted } from 'vue'
```

to:

```typescript
import { ref, computed, watch, onUnmounted, nextTick } from 'vue'
```

- [ ] **Step 3: Verify type check passes**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "fix: auto-scroll during streaming content updates"
```

---

### Task 6: Final Verification

- [ ] **Step 1: Run full type check**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 2: Run dev server and manual test**

Run: `npm run dev`

Test checklist:
1. Send a message with PDF/MD attachment → verify file chip shows correct name and size
2. Switch to another session, switch back → verify file chip still shows correct name and size
3. Send a message → verify thinking block appears during agent response
4. Switch session, switch back → verify thinking block displays correctly (no duplicate text)
5. Send a message → verify "正在思考..." indicator appears before content arrives
6. Type Chinese with IME → verify Enter confirms character, doesn't send message
7. During streaming → verify page auto-scrolls as content arrives
