# Chat Freeze Fix Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix workspace chat UI freeze when switching models and sending messages, caused by `sending` state getting permanently stuck as `true`.

**Architecture:** Defense-in-depth fix across 4 layers: backend error propagation, frontend timeout safety net, cancel cleanup, and model parameter passing. Two files changed, ~25 lines total.

**Tech Stack:** Node.js/Express backend, Vue 3 + TypeScript + Pinia frontend

---

## Files Modified

| File | Responsibility |
|------|---------------|
| `server/index.js:2641-2649` | `/api/workspace/send` endpoint — return error when gateway.call fails |
| `src/stores/workspace.ts:365-401` | `sendMessage` — arm timeout after POST + pass selectedModel |
| `src/stores/workspace.ts:483-510` | `forceStopStreaming` + `resetStreamTimeout` — add maxStreamTimeout |
| `src/stores/workspace.ts:633-647` | `cancelCurrentRequest` — clean up all timeouts |

---

### Task 1: Backend — Return error when gateway.call fails

**Files:**
- Modify: `server/index.js:2641-2649`

**Context:** The `/api/workspace/send` endpoint wraps `gateway.call('chat.send')` in a try/catch, but the catch block only logs the error and deletes the streamId. It does NOT return an error response — the `res.json({ ok: true, streamId })` on line 2649 always executes. This makes the frontend think the send succeeded, so it waits for SSE events that will never come.

- [ ] **Step 1: Add `return` and error response to the catch block**

In `server/index.js`, find this code block (lines 2641-2649):

```javascript
    // Send via Gateway RPC (fire-and-forget — response streams via SSE)
    try {
      await gateway.call('chat.send', { sessionKey, message, idempotencyKey })
    } catch (err) {
      streamIdMap.delete(streamId) // clean up — stream never started
      console.error('[Workspace] Gateway chat.send error:', err.message)
    }

    res.json({ ok: true, streamId })
```

Change the catch block to return an error response:

```javascript
    // Send via Gateway RPC (fire-and-forget — response streams via SSE)
    try {
      await gateway.call('chat.send', { sessionKey, message, idempotencyKey })
    } catch (err) {
      streamIdMap.delete(streamId) // clean up — stream never started
      console.error('[Workspace] Gateway chat.send error:', err.message)
      return res.status(502).json({ ok: false, error: { message: err.message } })
    }

    res.json({ ok: true, streamId })
```

The only change is adding `return res.status(502).json(...)` as the last line of the catch block. The frontend's existing `catch` block in `sendMessage` (workspace.ts:395-400) already handles HTTP errors:

```typescript
    } catch (err: unknown) {
      sending.value = false          // ← resets sending state
      activeStreamId.value = null
      lastError.value = err instanceof Error ? err.message : 'Send failed'
      console.error('[Workspace] Send error:', err)
    }
```

- [ ] **Step 2: Restart the backend and verify**

Run: `npm run dev:server`
Expected: Server starts without errors on port 3001.

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "fix: return 502 when gateway.call fails in workspace send"
```

---

### Task 2: Frontend — Timeout safety net + cancel cleanup + model passing

**Files:**
- Modify: `src/stores/workspace.ts:483` (add `maxStreamTimeout` variable)
- Modify: `src/stores/workspace.ts:365-401` (`sendMessage` — arm timeout + pass model)
- Modify: `src/stores/workspace.ts:485-502` (`forceStopStreaming` — clear maxStreamTimeout)
- Modify: `src/stores/workspace.ts:633-647` (`cancelCurrentRequest` — clear all timeouts)

**Context:** Three separate issues in the workspace store:
1. `resetStreamTimeout()` is only called when SSE events arrive — if no events come, timeout never fires
2. `cancelCurrentRequest` doesn't clear `streamTimeout` — stale forceStopStreaming can fire later
3. `sendMessage` doesn't pass `selectedModel` — model dropdown is cosmetic only

- [ ] **Step 1: Add `maxStreamTimeout` variable**

In `src/stores/workspace.ts`, find line 483:

```typescript
  let streamTimeout: ReturnType<typeof setTimeout> | null = null
```

Add `maxStreamTimeout` right after it:

```typescript
  let streamTimeout: ReturnType<typeof setTimeout> | null = null
  let maxStreamTimeout: ReturnType<typeof setTimeout> | null = null
```

- [ ] **Step 2: Update `sendMessage` — arm timeout + pass model**

In `src/stores/workspace.ts`, find the `sendMessage` function (lines 365-401). The current code:

```typescript
  async function sendMessage(content: string, displayContent?: string, files?: Array<{ name: string; size: number }>) {
    const text = content.trim()
    if (!text) return

    if (!activeSessionKey.value) {
      const agentId = selectedAgentId.value || 'main'
      startNewChat(agentId)
    }

    const idempotencyKey = `ws-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`

    const localMessage: ChatMessage = {
      id: idempotencyKey,
      role: 'user',
      content: displayContent || text,
      timestamp: new Date().toISOString(),
      files,
    }
    messages.value = [...messages.value, localMessage]

    sending.value = true
    lastError.value = null

    try {
      const result = await httpPost('/api/workspace/send', {
        sessionKey: activeSessionKey.value!,
        message: text,
        idempotencyKey,
      }) as Record<string, unknown>
      activeStreamId.value = (result.streamId as string) || null
    } catch (err: unknown) {
      sending.value = false
      activeStreamId.value = null
      lastError.value = err instanceof Error ? err.message : 'Send failed'
      console.error('[Workspace] Send error:', err)
    }
  }
```

Replace with:

```typescript
  async function sendMessage(content: string, displayContent?: string, files?: Array<{ name: string; size: number }>) {
    const text = content.trim()
    if (!text) return

    if (!activeSessionKey.value) {
      const agentId = selectedAgentId.value || 'main'
      startNewChat(agentId)
    }

    // Apply selected model to session before sending
    if (selectedModel.value && activeSessionKey.value) {
      try {
        await wsStore.rpc.patchSession({
          sessionKey: activeSessionKey.value,
          model: selectedModel.value,
        })
      } catch {
        // best-effort, don't block send
      }
    }

    const idempotencyKey = `ws-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`

    const localMessage: ChatMessage = {
      id: idempotencyKey,
      role: 'user',
      content: displayContent || text,
      timestamp: new Date().toISOString(),
      files,
    }
    messages.value = [...messages.value, localMessage]

    sending.value = true
    lastError.value = null

    try {
      const result = await httpPost('/api/workspace/send', {
        sessionKey: activeSessionKey.value!,
        message: text,
        idempotencyKey,
      }) as Record<string, unknown>
      activeStreamId.value = (result.streamId as string) || null
      // Arm timeout immediately — even if no SSE events arrive, UI recovers in 15s
      resetStreamTimeout()
      if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
      maxStreamTimeout = setTimeout(forceStopStreaming, 300_000) // 5 min max
    } catch (err: unknown) {
      sending.value = false
      activeStreamId.value = null
      lastError.value = err instanceof Error ? err.message : 'Send failed'
      console.error('[Workspace] Send error:', err)
    }
  }
```

Changes:
- Added `sessions.patch` call before sending (lines after `startNewChat`)
- Added `resetStreamTimeout()` after POST success
- Added `maxStreamTimeout` (5 min) after POST success

- [ ] **Step 3: Update `forceStopStreaming` — clear maxStreamTimeout**

In `src/stores/workspace.ts`, find `forceStopStreaming` (lines 485-502):

```typescript
  function forceStopStreaming() {
    if (!sending.value) return
    if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
    const list = messages.value
```

Change to:

```typescript
  function forceStopStreaming() {
    if (!sending.value) return
    if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
    if (maxStreamTimeout) { clearTimeout(maxStreamTimeout); maxStreamTimeout = null }
    const list = messages.value
```

Only one line added: `if (maxStreamTimeout) { clearTimeout(maxStreamTimeout); maxStreamTimeout = null }`

- [ ] **Step 4: Update `cancelCurrentRequest` — clear all timeouts**

In `src/stores/workspace.ts`, find `cancelCurrentRequest` (lines 633-647):

```typescript
  async function cancelCurrentRequest() {
    if (!activeStreamId.value && !sending.value) return

    try {
      await httpPost('/api/chat/cancel', {
        streamId: activeStreamId.value,
        sessionKey: activeSessionKey.value,
      })
    } catch {
      // best-effort
    }

    activeStreamId.value = null
    sending.value = false
  }
```

Change to:

```typescript
  async function cancelCurrentRequest() {
    if (!activeStreamId.value && !sending.value) return

    try {
      await httpPost('/api/chat/cancel', {
        streamId: activeStreamId.value,
        sessionKey: activeSessionKey.value,
      })
    } catch {
      // best-effort
    }

    if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
    if (maxStreamTimeout) { clearTimeout(maxStreamTimeout); maxStreamTimeout = null }
    activeStreamId.value = null
    sending.value = false
  }
```

Two lines added before `activeStreamId.value = null`.

- [ ] **Step 5: Verify the build passes**

Run: `npx vue-tsc --noEmit`
Expected: No type errors.

- [ ] **Step 6: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: arm stream timeout on POST success, cleanup on cancel, pass selectedModel"
```

---

## Verification Checklist

After all tasks are complete, verify manually:

1. **Backend error propagation**: Stop the gateway process, send a message in workspace chat → should see an error banner, NOT a permanent "sending" state
2. **Timeout safety net**: Send a message, then kill the SSE connection (e.g., network tab disconnect) → UI should recover within 15 seconds
3. **Cancel cleanup**: Send a message, click cancel, wait 20 seconds → no unexpected UI state changes
4. **Model passing**: Switch model in dropdown, send message → check server logs for `sessions.patch` call before `chat.send`
5. **Normal flow**: Send messages normally → streaming still works as before, no regressions
