# File Upload Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enable uploading binary files (PDF, docx, images) from the WattClaw workspace chat to the Gateway, so agents can read and analyze them — matching Feishu channel behavior.

**Architecture:** WattClaw backend acts as a file upload proxy. It receives files via HTTP multipart, then SCPs them to the Gateway server's `~/.openclaw/media/inbound/` directory via SSH. Messages reference files with `[File: path]` format, which the agent resolves using built-in tools.

**Tech Stack:** Node.js, Express, multer (multipart), ssh2 (SSH/SCP), Vue 3, FormData

---

## File Structure

| File | Action | Responsibility |
|------|--------|----------------|
| `server/gateway-file-transfer.js` | Create | SSH connection management + SCP file upload to Gateway |
| `server/index.js` | Modify | Add `POST /api/workspace/upload` endpoint |
| `src/views/workspace/ChatInput.vue` | Modify | Replace client-side file reading with HTTP upload |
| `src/i18n/messages/zh-CN.ts` | Modify | Add upload-related i18n keys |
| `src/i18n/messages/en-US.ts` | Modify | Add upload-related i18n keys |
| `.env.example` | Modify | Document new SSH config variables |

---

### Task 1: Create SSH File Transfer Module

**Files:**
- Create: `server/gateway-file-transfer.js`

- [ ] **Step 1: Create the module file with SSH connection management**

```js
// server/gateway-file-transfer.js
import { Client } from 'ssh2'
import { randomUUID } from 'crypto'
import path from 'path'

const SSH_CONFIG = {
  host: process.env.GATEWAY_SSH_HOST || '192.168.10.12',
  port: parseInt(process.env.GATEWAY_SSH_PORT || '22', 10),
  username: process.env.GATEWAY_SSH_USER || 'wattman',
  // Key-based auth (preferred)
  privateKey: process.env.GATEWAY_SSH_KEY_PATH
    ? (await import('fs')).readFileSync(process.env.GATEWAY_SSH_KEY_PATH)
    : undefined,
  // Password auth fallback
  password: process.env.GATEWAY_SSH_PASSWORD || undefined,
}

const MEDIA_DIR = process.env.GATEWAY_MEDIA_DIR || '/home/wattman/.openclaw/media/inbound'

function sanitizeFilename(name) {
  return name
    .trim()
    .replace(/[^\p{L}\p{N}._-]+/gu, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 60)
}

function buildRemotePath(fileName) {
  const ext = path.extname(fileName)
  const base = path.basename(fileName, ext)
  const safeName = sanitizeFilename(base)
  const uuid = randomUUID().slice(0, 8)
  return `${safeName}---${uuid}${ext}`
}

/**
 * Upload a file buffer to the Gateway's media/inbound directory via SCP.
 * Returns the remote file path on success.
 */
export async function uploadToGateway(buffer, fileName) {
  const remoteFileName = buildRemotePath(fileName)
  const remotePath = `${MEDIA_DIR}/${remoteFileName}`

  return new Promise((resolve, reject) => {
    const conn = new Client()
    conn.on('ready', () => {
      conn.sftp((err, sftp) => {
        if (err) { conn.end(); return reject(err) }

        // Ensure directory exists
        sftp.mkdir(MEDIA_DIR, { mode: 0o700 }, () => {
          // Ignore mkdir error (directory likely exists)
          const writeStream = sftp.createWriteStream(remotePath, {
            mode: 0o644,
            flags: 'w',
          })

          writeStream.on('close', () => {
            conn.end()
            resolve({
              path: remotePath,
              fileName: remoteFileName,
              originalName: fileName,
              size: buffer.length,
            })
          })

          writeStream.on('error', (writeErr) => {
            conn.end()
            reject(writeErr)
          })

          writeStream.end(buffer)
        })
      })
    })

    conn.on('error', (err) => {
      reject(new Error(`SSH connection failed: ${err.message}`))
    })

    conn.connect(SSH_CONFIG)
  })
}

/**
 * Test SSH connectivity to the Gateway server.
 */
export async function testConnection() {
  return new Promise((resolve, reject) => {
    const conn = new Client()
    conn.on('ready', () => {
      conn.end()
      resolve(true)
    })
    conn.on('error', (err) => {
      reject(new Error(`SSH connection failed: ${err.message}`))
    })
    conn.connect(SSH_CONFIG)
  })
}
```

- [ ] **Step 2: Verify the module compiles**

Run: `node -e "import('./server/gateway-file-transfer.js').then(m => console.log('OK:', Object.keys(m)))"`
Expected: `OK: [ 'uploadToGateway', 'testConnection' ]`

- [ ] **Step 3: Commit**

```bash
git add server/gateway-file-transfer.js
git commit -m "feat: add SSH file transfer module for Gateway media upload"
```

---

### Task 2: Add Upload Endpoint to Backend

**Files:**
- Modify: `server/index.js`

- [ ] **Step 1: Add import for the transfer module**

At the top of `server/index.js`, after the existing imports (around line 14), add:

```js
import { uploadToGateway } from './gateway-file-transfer.js'
```

- [ ] **Step 2: Add the upload endpoint**

After the existing `/api/workspace/send` endpoint (around line 2652), add:

```js
// File upload endpoint — transfers file to Gateway media/inbound via SCP
app.post('/api/workspace/upload', authMiddleware, multer().single('file'), async (req, res) => {
  try {
    const file = req.file
    if (!file) {
      return res.status(400).json({ ok: false, error: 'No file provided' })
    }

    // Size limit: 30MB
    const MAX_SIZE = 30 * 1024 * 1024
    if (file.size > MAX_SIZE) {
      return res.status(413).json({
        ok: false,
        error: `File too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Maximum is 30MB.`,
      })
    }

    console.log(`[Upload] Received: ${file.originalname} (${(file.size / 1024).toFixed(1)}KB)`)

    const result = await uploadToGateway(file.buffer, file.originalname)

    console.log(`[Upload] Saved to Gateway: ${result.path}`)
    res.json({ ok: true, ...result })
  } catch (err) {
    console.error('[Upload] Error:', err.message)
    res.status(502).json({
      ok: false,
      error: `Upload to Gateway failed: ${err.message}`,
    })
  }
})
```

- [ ] **Step 3: Add SSH config to env defaults**

In the `loadEnvConfig` function (around line 46), add new defaults:

```js
GATEWAY_SSH_HOST: '',
GATEWAY_SSH_PORT: '22',
GATEWAY_SSH_USER: '',
GATEWAY_SSH_KEY_PATH: '',
GATEWAY_SSH_PASSWORD: '',
GATEWAY_MEDIA_DIR: '',
```

And in the return object (around line 78), add:

```js
GATEWAY_SSH_HOST: process.env.GATEWAY_SSH_HOST || fileConfig.GATEWAY_SSH_HOST || defaults.GATEWAY_SSH_HOST,
GATEWAY_SSH_PORT: process.env.GATEWAY_SSH_PORT || fileConfig.GATEWAY_SSH_PORT || defaults.GATEWAY_SSH_PORT,
GATEWAY_SSH_USER: process.env.GATEWAY_SSH_USER || fileConfig.GATEWAY_SSH_USER || defaults.GATEWAY_SSH_USER,
GATEWAY_SSH_KEY_PATH: process.env.GATEWAY_SSH_KEY_PATH || fileConfig.GATEWAY_SSH_KEY_PATH || defaults.GATEWAY_SSH_KEY_PATH,
GATEWAY_SSH_PASSWORD: process.env.GATEWAY_SSH_PASSWORD || fileConfig.GATEWAY_SSH_PASSWORD || defaults.GATEWAY_SSH_PASSWORD,
GATEWAY_MEDIA_DIR: process.env.GATEWAY_MEDIA_DIR || fileConfig.GATEWAY_MEDIA_DIR || defaults.GATEWAY_MEDIA_DIR,
```

- [ ] **Step 4: Update gateway-file-transfer.js to use envConfig**

The transfer module currently reads from `process.env` directly. Since the backend loads config via `loadEnvConfig()`, we need to pass the config to the module. Update `server/gateway-file-transfer.js` to accept config as a parameter:

```js
// server/gateway-file-transfer.js
import { Client } from 'ssh2'
import { randomUUID } from 'crypto'
import path from 'path'
import { readFileSync } from 'fs'

function sanitizeFilename(name) {
  return name
    .trim()
    .replace(/[^\p{L}\p{N}._-]+/gu, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 60)
}

function buildRemotePath(fileName, mediaDir) {
  const ext = path.extname(fileName)
  const base = path.basename(fileName, ext)
  const safeName = sanitizeFilename(base)
  const uuid = randomUUID().slice(0, 8)
  return `${mediaDir}/${safeName}---${uuid}${ext}`
}

function buildSshConfig(envConfig) {
  const config = {
    host: envConfig.GATEWAY_SSH_HOST || '192.168.10.12',
    port: parseInt(envConfig.GATEWAY_SSH_PORT || '22', 10),
    username: envConfig.GATEWAY_SSH_USER || 'wattman',
  }

  const keyPath = envConfig.GATEWAY_SSH_KEY_PATH
  if (keyPath) {
    try {
      config.privateKey = readFileSync(keyPath)
    } catch (err) {
      console.warn('[GatewayUpload] Failed to read SSH key:', err.message)
    }
  }

  if (envConfig.GATEWAY_SSH_PASSWORD) {
    config.password = envConfig.GATEWAY_SSH_PASSWORD
  }

  return config
}

/**
 * Upload a file buffer to the Gateway's media/inbound directory via SCP.
 */
export async function uploadToGateway(buffer, fileName, envConfig) {
  const mediaDir = envConfig.GATEWAY_MEDIA_DIR || '/home/wattman/.openclaw/media/inbound'
  const remotePath = buildRemotePath(fileName, mediaDir)
  const sshConfig = buildSshConfig(envConfig)

  return new Promise((resolve, reject) => {
    const conn = new Client()
    conn.on('ready', () => {
      conn.sftp((err, sftp) => {
        if (err) { conn.end(); return reject(err) }

        sftp.mkdir(mediaDir, { mode: 0o700 }, () => {
          const writeStream = sftp.createWriteStream(remotePath, {
            mode: 0o644,
            flags: 'w',
          })

          writeStream.on('close', () => {
            conn.end()
            resolve({
              path: remotePath,
              fileName: path.basename(remotePath),
              originalName: fileName,
              size: buffer.length,
            })
          })

          writeStream.on('error', (writeErr) => {
            conn.end()
            reject(writeErr)
          })

          writeStream.end(buffer)
        })
      })
    })

    conn.on('error', (err) => {
      reject(new Error(`SSH connection failed: ${err.message}`))
    })

    conn.connect(sshConfig)
  })
}
```

- [ ] **Step 5: Update the endpoint to pass envConfig**

Update the upload endpoint in `server/index.js` to pass `envConfig`:

```js
const result = await uploadToGateway(file.buffer, file.originalname, envConfig)
```

- [ ] **Step 6: Commit**

```bash
git add server/gateway-file-transfer.js server/index.js
git commit -m "feat: add /api/workspace/upload endpoint with SSH transfer"
```

---

### Task 3: Update Frontend File Handling

**Files:**
- Modify: `src/views/workspace/ChatInput.vue`

- [ ] **Step 1: Add upload function and rewrite doSend**

Replace the `readFileAsText`, `isTextFile`, and `doSend` functions (lines 52-112) with:

```ts
async function uploadFile(file: File): Promise<{ path: string; fileName: string; size: number }> {
  const formData = new FormData()
  formData.append('file', file)

  const token = localStorage.getItem('auth_token')
  const res = await fetch(apiPath('/api/workspace/upload'), {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Upload failed' }))
    throw new Error(err.error || `Upload failed (${res.status})`)
  }

  return res.json()
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

async function doSend(text: string) {
  const hasFiles = attachments.value.length > 0
  let sendText = text
  let displayText = text
  const fileInfos: Array<{ name: string; size: number }> = []

  if (hasFiles) {
    const parts: string[] = []

    for (const file of attachments.value) {
      try {
        const result = await uploadFile(file)
        fileInfos.push({ name: file.name, size: file.size })
        parts.push(`[File: ${result.path}]`)
      } catch (err) {
        console.error('[Upload] Failed:', file.name, err)
        parts.push(`[File: ${file.name} — upload failed: ${err instanceof Error ? err.message : 'unknown error'}]`)
      }
    }

    const fileBlock = parts.join('\n')
    sendText = text ? `${fileBlock}\n\n${text}` : fileBlock
    displayText = text
  }

  await workspaceStore.sendMessage(sendText, displayText, fileInfos.length > 0 ? fileInfos : undefined)
  inputText.value = ''
  showSlashMenu.value = false
  attachments.value = []
  previewUrls.forEach(url => URL.revokeObjectURL(url))
  previewUrls.clear()
}
```

- [ ] **Step 2: Add apiPath import**

At the top of the `<script setup>` block, add:

```ts
import { apiPath } from '@/utils/api-path'
```

- [ ] **Step 3: Remove unused functions**

Remove the `readFileAsText` and `isTextFile` functions (lines 52-68) as they are no longer needed.

- [ ] **Step 4: Add upload progress indicator (optional)**

Add a ref for upload state:

```ts
const isUploading = ref(false)
```

Wrap the upload loop in `doSend` with loading state:

```ts
if (hasFiles) {
  isUploading.value = true
  try {
    // ... upload loop
  } finally {
    isUploading.value = false
  }
}
```

Update the send button to show uploading state:

```html
<button
  v-if="isStreaming"
  class="cancel-btn"
  ...
>
```

Add after the streaming button:

```html
<button
  v-else-if="isUploading"
  class="send-btn"
  disabled
  :title="'上传中...'"
>
  <svg class="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
  </svg>
</button>
```

Add CSS for spinner:

```css
.send-btn .spin {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "feat: replace client-side file reading with Gateway upload"
```

---

### Task 4: Add i18n Keys

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`
- Modify: `src/i18n/messages/en-US.ts`

- [ ] **Step 1: Add zh-CN keys**

In `src/i18n/messages/zh-CN.ts`, in the `workspace.chat` section (around line 2566), add:

```ts
uploading: '上传中...',
uploadFailed: '上传失败',
uploadFailedDetail: '文件上传失败：{error}',
fileTooLarge: '文件过大（{size}），最大支持 30MB',
```

- [ ] **Step 2: Add en-US keys**

In `src/i18n/messages/en-US.ts`, find the corresponding `workspace.chat` section and add:

```ts
uploading: 'Uploading...',
uploadFailed: 'Upload failed',
uploadFailedDetail: 'File upload failed: {error}',
fileTooLarge: 'File too large ({size}), maximum is 30MB',
```

- [ ] **Step 3: Update ChatInput.vue to use i18n keys**

Update the error messages in `doSend` to use `t()`:

```ts
parts.push(`[File: ${file.name} — ${t('pages.workspace.chat.uploadFailedDetail', { error: err instanceof Error ? err.message : 'unknown' })}]`)
```

Update the upload button title:

```html
:title="t('pages.workspace.chat.uploading')"
```

- [ ] **Step 4: Commit**

```bash
git add src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts src/views/workspace/ChatInput.vue
git commit -m "feat: add i18n keys for file upload"
```

---

### Task 5: Update .env.example and Documentation

**Files:**
- Modify: `.env.example`

- [ ] **Step 1: Add SSH config to .env.example**

Add the following to `.env.example`:

```env
# Gateway SSH config (for file upload to agent)
GATEWAY_SSH_HOST=192.168.10.12
GATEWAY_SSH_PORT=22
GATEWAY_SSH_USER=wattman
GATEWAY_SSH_KEY_PATH=/home/renming/.ssh/id_rsa
GATEWAY_SSH_PASSWORD=
GATEWAY_MEDIA_DIR=/home/wattman/.openclaw/media/inbound
```

- [ ] **Step 2: Commit**

```bash
git add .env.example
git commit -m "docs: add Gateway SSH config to .env.example"
```

---

### Task 6: Manual Verification

- [ ] **Step 1: Configure .env on server2**

SSH to server2 and add the SSH config to the `.env` file:

```bash
ssh server2_l
cd /home/renming/work/wattclaw/wattclaw
# Add GATEWAY_SSH_* variables to .env
```

- [ ] **Step 2: Restart the backend**

```bash
ssh server2_l "cd /home/renming/work/wattclaw/wattclaw && ./restart.sh"
```

- [ ] **Step 3: Test PDF upload**

1. Open WattClaw in browser
2. Select an agent in the workspace
3. Attach a PDF file
4. Send a message asking the agent to analyze it
5. Verify the agent can read and analyze the PDF content

- [ ] **Step 4: Test text file upload**

1. Attach a .md file
2. Send it
3. Verify it still works (should now use upload path instead of inline)

- [ ] **Step 5: Test error handling**

1. Try uploading a file > 30MB — should show size limit error
2. Stop the Gateway SSH service — should show connection error

- [ ] **Step 6: Test session switching**

1. Upload a PDF and send a message
2. Switch to another session
3. Switch back — verify the file reference is still in the message history
