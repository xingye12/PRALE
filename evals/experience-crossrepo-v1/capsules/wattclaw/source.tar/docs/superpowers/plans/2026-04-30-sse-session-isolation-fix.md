# SSE Session Isolation Fix — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix cross-user message leak where messages from other users' agent sessions appear in the current user's chat view during real-time SSE events.

**Architecture:** Two-layer defense — frontend chat store adds session-key filtering (matching workspace store pattern), and backend broadcastSSE closes the fallthrough gap for events without sessionKey.

**Tech Stack:** Vue 3 + TypeScript (Pinia stores), Node.js + Express (server), SQLite (user_sessions/user_agents ownership)

**Spec:** `docs/superpowers/specs/2026-04-30-sse-session-isolation-fix-design.md`

---

### Task 1: Fix frontend — `src/stores/chat.ts` handleRealtimeEvent

**Files:**
- Modify: `src/stores/chat.ts:590-635`

- [ ] **Step 1: Add session-key filter at the top of handleRealtimeEvent**

In `src/stores/chat.ts`, add a session-key check immediately after extracting `keyInEvent` (line 597), before any other logic. This mirrors the pattern used in `workspace.ts:487-489`:

```typescript
  function handleRealtimeEvent(
    payload: unknown,
    options?: {
      refreshHistory?: boolean
      streaming?: boolean
    }
  ) {
    const keyInEvent = extractSessionKey(payload)

    // Drop events that belong to a different session (defense against cross-user leak)
    if (sessionKey.value.trim() && keyInEvent && keyInEvent !== sessionKey.value) {
      return
    }

    // 从 sessionKey 中提取 agentId
    let agentId = 'default'
    // ... rest unchanged
```

- [ ] **Step 2: Remove the empty sessionKey auto-adoption logic**

Delete lines 599-603 entirely. This block causes the store to adopt any foreign sessionKey when the current one is empty:

```typescript
    // DELETE these lines:
    // 即使 sessionKey 为空，也处理事件，更新全局状态
    if (!sessionKey.value.trim() && keyInEvent) {
      // 当 sessionKey 为空但事件中有 sessionKey 时，更新 sessionKey
      sessionKey.value = keyInEvent
    }
```

The final `handleRealtimeEvent` function should look like:

```typescript
  function handleRealtimeEvent(
    payload: unknown,
    options?: {
      refreshHistory?: boolean
      streaming?: boolean
    }
  ) {
    const keyInEvent = extractSessionKey(payload)

    // Drop events that belong to a different session
    if (sessionKey.value.trim() && keyInEvent && keyInEvent !== sessionKey.value) {
      return
    }

    // 从 sessionKey 中提取 agentId
    let agentId = 'default'
    if (keyInEvent) {
      const match = keyInEvent.match(/^agent:([^:]+):/)
      if (match && match[1]) {
        agentId = match[1]
      }
    }

    // 处理实时消息
    const realtimeMessages = extractRealtimeMessages(payload)
    if (options?.streaming) {
      pendingStreamMessages.push(...realtimeMessages)
      if (streamFlushRaf === null) {
        streamFlushRaf = requestAnimationFrame(() => {
          streamFlushRaf = null
          if (pendingStreamMessages.length === 0) return
          const batch = pendingStreamMessages
          pendingStreamMessages = []
          mergeRealtimeMessages(batch, { streaming: true })
        })
      }
    } else {
      mergeRealtimeMessages(realtimeMessages, { streaming: false })
    }

    if (options?.refreshHistory ?? true) {
      scheduleHistoryRefresh(200)
    }
  }
```

- [ ] **Step 3: Verify TypeScript compiles**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
git add src/stores/chat.ts
git commit -m "fix: add session-key filtering in chat store to prevent cross-user message leak"
```

---

### Task 2: Fix backend — `server/index.js` broadcastSSE

**Files:**
- Modify: `server/index.js:270-291`

- [ ] **Step 1: Move `continue` to end of event-filtering block**

In `server/index.js`, the `broadcastSSE` function currently has `continue` inside the `if (sk)` block (line 288), which means events without a sessionKey fall through and get delivered to ALL clients. Move `continue` to the end of the outer `if` block so ALL `type === 'event'` messages for non-admin clients go through the ownership filter.

Before (lines 270-291):
```javascript
  for (const [id, client] of sseClients) {
    try {
      if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
        const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
        if (sk) {
          const ownedKeys = getUserOwnedSessionKeys(client.userId)
          if (ownedKeys.includes(sk)) {
            client.res.write(message)
          } else {
            const agentId = sk.match(/^agent:([^:]+):/)?.[1]
            if (agentId) {
              const ownedAgents = getUserOwnedAgentIds(client.userId)
              if (ownedAgents.includes(agentId)) {
                trackSessionForUser(client.userId, sk, agentId)
                client.res.write(message)
              }
            }
          }
          continue
        }
      }
      client.res.write(message)
    } catch (e) {
      sseClients.delete(id)
    }
  }
```

After:
```javascript
  for (const [id, client] of sseClients) {
    try {
      if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
        const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
        if (sk) {
          const ownedKeys = getUserOwnedSessionKeys(client.userId)
          if (ownedKeys.includes(sk)) {
            client.res.write(message)
          } else {
            const agentId = sk.match(/^agent:([^:]+):/)?.[1]
            if (agentId) {
              const ownedAgents = getUserOwnedAgentIds(client.userId)
              if (ownedAgents.includes(agentId)) {
                trackSessionForUser(client.userId, sk, agentId)
                client.res.write(message)
              }
            }
          }
        }
        continue
      }
      client.res.write(message)
    } catch (e) {
      sseClients.delete(id)
    }
  }
```

The only change: `continue` moves from inside `if (sk) { ... continue }` to after the `if (sk)` block, still inside the outer `if (data.type === 'event' ...)` block.

- [ ] **Step 2: Verify the server starts without syntax errors**

Run: `node -c server/index.js`
Expected: No output (syntax check passes)

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "fix: close broadcastSSE fallthrough gap for events without sessionKey"
```

---

### Task 3: Manual verification

- [ ] **Step 1: Start the dev environment**

Run: `./start.sh`
Wait for both frontend and backend to be ready.

- [ ] **Step 2: Test multi-user isolation**

1. Open browser window A, log in as User A
2. Open browser window B (incognito), log in as User B
3. In window A, open a chat session with an agent and send a message
4. In window B, open a different chat session
5. Verify: Window B does NOT show User A's messages in real-time
6. Verify: Window A does NOT show User B's messages in real-time

- [ ] **Step 3: Test admin visibility**

1. Open browser window C, log in as admin
2. Verify: Admin can see events from all sessions (unchanged behavior)

- [ ] **Step 4: Test refresh consistency**

1. In any window, refresh the page
2. Verify: Chat history loads correctly, no foreign messages present

- [ ] **Step 5: Test empty session state**

1. Open chat page without selecting a session
2. Wait for events from other users' sessions
3. Verify: No foreign messages appear, sessionKey is NOT adopted from foreign events
