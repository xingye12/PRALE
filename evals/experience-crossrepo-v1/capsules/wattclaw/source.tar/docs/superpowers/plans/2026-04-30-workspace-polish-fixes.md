# Workspace Polish Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix 3 workspace UX issues: history message styling, agent name sync on session switch, copy trailing newlines.

**Architecture:** Three independent, minimal changes: (1) extract `.markdown-body` CSS from scoped component to global stylesheet, (2) add agent lookup in `selectSession()` store function, (3) trim fallback content in template binding.

**Tech Stack:** Vue 3, TypeScript, CSS

---

### Task 1: Extract markdown-body CSS to global stylesheet

**Files:**
- Create: `src/assets/styles/markdown.css`
- Modify: `src/assets/styles/main.css` (add import)
- Modify: `src/views/workspace/components/MarkdownRenderer.vue` (remove extracted styles, keep streaming-cursor)

- [ ] **Step 1: Create `src/assets/styles/markdown.css`**

Copy all `.markdown-body` styles from `MarkdownRenderer.vue` (lines 77-219), removing `:deep()` wrappers since global CSS doesn't need them:

```css
/* ── Markdown body (shared by v-html history + MarkdownRenderer streaming) ── */
.markdown-body {
  font-size: 14px;
  line-height: 1.75;
  color: var(--text);
  word-break: break-word;
  overflow-wrap: anywhere;
}

.markdown-body p { margin: 0 0 10px; }
.markdown-body p:last-child { margin-bottom: 0; }

.markdown-body pre.hljs {
  position: relative;
  background: var(--bg-code);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 14px 16px;
  margin: 10px 0;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.6;
}

.markdown-body pre.hljs .code-copy-btn {
  position: absolute;
  top: 6px;
  right: 6px;
  background: var(--bg-hover);
  border: none;
  border-radius: 6px;
  padding: 2px 8px;
  font-size: 11px;
  cursor: pointer;
  color: var(--text-muted);
  opacity: 0;
  transition: opacity .2s;
}

.markdown-body pre.hljs:hover .code-copy-btn {
  opacity: 1;
}

.markdown-body code {
  background: var(--code-inline-bg);
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 12.5px;
  font-family: "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
  color: var(--text-strong);
}

.markdown-body pre.hljs code {
  background: none;
  padding: 0;
  font-size: inherit;
  color: inherit;
}

.markdown-body table {
  border-collapse: collapse;
  width: 100%;
  margin: 8px 0;
  font-size: 12px;
}

.markdown-body th,
.markdown-body td {
  border: 1px solid var(--border2);
  padding: 5px 10px;
  text-align: left;
}

.markdown-body th {
  background: rgba(0,0,0,.04);
  font-weight: 600;
}

[data-theme='dark'] .markdown-body th {
  background: rgba(255,255,255,.04);
}

.markdown-body tr:nth-child(even) {
  background: rgba(0,0,0,.02);
}

[data-theme='dark'] .markdown-body tr:nth-child(even) {
  background: rgba(255,255,255,.02);
}

.markdown-body blockquote {
  border-left: 3px solid var(--blue);
  padding-left: 14px;
  margin: 10px 0;
  color: var(--text-muted);
  font-style: italic;
}

.markdown-body blockquote p {
  margin: 0;
}

.markdown-body ul,
.markdown-body ol {
  padding-left: 20px;
  margin: 6px 0 10px;
}

.markdown-body li {
  margin-bottom: 3px;
}

.markdown-body a {
  color: var(--blue);
  text-decoration: underline;
}

.markdown-body strong {
  color: var(--text-strong);
  font-weight: 600;
}

.markdown-body h1,
.markdown-body h2,
.markdown-body h3 {
  margin: 16px 0 6px;
  font-weight: 600;
}

.markdown-body h1 { font-size: 18px; }
.markdown-body h2 { font-size: 16px; }
.markdown-body h3 { font-size: 14px; }

.markdown-body hr {
  border: none;
  border-top: 1px solid var(--border);
  margin: 12px 0;
}

.markdown-body img {
  max-width: 100%;
  border-radius: 8px;
  cursor: pointer;
}
```

- [ ] **Step 2: Add import in `main.css`**

Add at the end of `src/assets/styles/main.css` (after line 286):

```css
@import './markdown.css';
```

- [ ] **Step 3: Remove extracted styles from `MarkdownRenderer.vue`**

In `src/views/workspace/components/MarkdownRenderer.vue`, replace the entire `<style scoped>` block (lines 76-237) with only the streaming-cursor styles:

```vue
<style scoped>
/* ── Streaming cursor ── */
.streaming-cursor::after {
  content: '';
  display: inline-block;
  width: 2px;
  height: 1.1em;
  background: var(--accent);
  margin-left: 1px;
  vertical-align: text-bottom;
  animation: cursor-blink 1s step-end infinite;
}

@keyframes cursor-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}
</style>
```

- [ ] **Step 4: Verify**

Run `npm run dev`, open workspace, switch between sessions. History messages should have identical styling to streaming messages (code blocks with dark background, proper heading sizes, list indentation).

- [ ] **Step 5: Commit**

```bash
git add src/assets/styles/markdown.css src/assets/styles/main.css src/views/workspace/components/MarkdownRenderer.vue
git commit -m "fix: extract markdown-body CSS to global stylesheet for history message styling"
```

---

### Task 2: Sync agent name when switching sessions

**Files:**
- Modify: `src/stores/workspace.ts:272-273` (add agent lookup in `selectSession`)

- [ ] **Step 1: Add agent lookup in `selectSession()`**

In `src/stores/workspace.ts`, at the start of `selectSession()` (after line 273 `activeSessionKey.value = sessionKey`), add:

```typescript
    // Sync selectedAgentId when switching to a session owned by a different agent
    for (const agent of agents.value) {
      if (agent.sessions.some(s => s.key === sessionKey)) {
        if (selectedAgentId.value !== agent.agentId) {
          selectedAgentId.value = agent.agentId
          selectedModel.value = agent.model || selectedModel.value
        }
        break
      }
    }
```

The full function should look like:

```typescript
  async function selectSession(sessionKey: string) {
    activeSessionKey.value = sessionKey
    // Sync selectedAgentId when switching to a session owned by a different agent
    for (const agent of agents.value) {
      if (agent.sessions.some(s => s.key === sessionKey)) {
        if (selectedAgentId.value !== agent.agentId) {
          selectedAgentId.value = agent.agentId
          selectedModel.value = agent.model || selectedModel.value
        }
        break
      }
    }
    messages.value = []
    loading.value = true
    lastError.value = null
    // ... rest unchanged
```

- [ ] **Step 2: Verify**

Run `npm run dev`, open workspace with multiple agents. Click a session belonging to a different agent — ChatHeader should show that agent's name immediately.

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: sync agent name in ChatHeader when switching sessions"
```

---

### Task 3: Fix copy trailing newlines

**Files:**
- Modify: `src/views/workspace/MessageList.vue:217`

- [ ] **Step 1: Trim fallback content**

In `src/views/workspace/MessageList.vue`, change line 217 from:

```html
:content="msg._thinking.answer || msg.content"
```

to:

```html
:content="msg._thinking.answer || msg.content.trimEnd()"
```

- [ ] **Step 2: Verify**

Run `npm run dev`, send a message to an agent, copy the reply via the copy button, paste into a text editor — no trailing blank lines.

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "fix: remove trailing newlines when copying agent replies"
```
