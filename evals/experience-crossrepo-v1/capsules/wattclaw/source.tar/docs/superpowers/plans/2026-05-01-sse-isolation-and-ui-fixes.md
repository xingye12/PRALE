# SSE Session Isolation + UI Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix cross-user SSE message leakage and thinking/dots UI overlap

**Architecture:** Server-side broadcastSSE applies session ownership filtering to ALL users (including admin). Frontend stores enforce strict sessionKey filtering — events without a matching sessionKey are dropped. MessageList fixes isStreaming logic to prevent thinking/dots overlap.

**Tech Stack:** Vue 3, TypeScript, Express, SQLite (better-sqlite3)

---

## File Map

| File | Change |
|------|--------|
| `server/index.js:272` | Remove `!client.isAdmin` from broadcastSSE filter, remove agentId fallback |
| `src/stores/chat.ts:605` | Strengthen `handleRealtimeEvent` filter — drop when sessionKey is empty |
| `src/stores/chat.ts:662` | Add sessionKey filter to `handleAgentStatusEvent` |
| `src/stores/workspace.ts:613` | Strengthen `handleEvent` filter — drop when activeSessionKey is null |
| `src/composables/useEventStream.ts:17` | Add sessionKey filter to event subscription |
| `src/views/workspace/MessageList.vue:75` | Remove `stopReason` check from `isStreaming` |
| `src/views/workspace/MessageList.vue:247` | Set ThinkingBlock `:thinking` to `false` |

---

### Task 1: Server-side — broadcastSSE applies session ownership to all users

**Files:**
- Modify: `server/index.js:272-291`

- [ ] **Step 1: Read the current broadcastSSE function**

Read `server/index.js` lines 257-296 to confirm the current code matches expectations.

- [ ] **Step 2: Modify broadcastSSE filtering logic**

Change lines 272-291. Remove `!client.isAdmin` condition so admin users are also filtered. Remove agentId fallback — only check sessionKey ownership.

Current code (lines 272-291):
```javascript
if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
  const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
  if (sk) {
    const ownedKeys = getUserOwnedSessionKeys(client.userId)
    if (ownedKeys.includes(sk)) {
      client.res.write(message)
    } else {
      const agentId = sk.match(/^agent:([^:]+):/)?.[1]
      if (agentId) {
        const ownedAgents = getUserOwnedAgentIds(client.userId)
        if (ownedAgents.includes(agentId)) {
          trackSessionForUser(client.userId, sk, agentId)
          client.res.write(message)
        }
      }
    }
  }
  continue
}
client.res.write(message)
```

New code:
```javascript
if (data.type === 'event' && rawPayload && client.userId) {
  const sk = rawPayload.sessionKey || rawPayload.session_key || rawPayload.key || ''
  if (!sk) {
    continue
  }
  const ownedKeys = getUserOwnedSessionKeys(client.userId)
  if (!ownedKeys.includes(sk)) {
    continue
  }
  client.res.write(message)
  continue
}
client.res.write(message)
```

Changes:
- Line 272: Remove `&& !client.isAdmin` — admin users now also go through ownership check
- Lines 274-288: Replace nested if/else with flat early-continue pattern
- Remove agentId fallback entirely — only sessionKey ownership matters
- Remove `trackSessionForUser` call (no longer auto-tracking from events)

- [ ] **Step 3: Verify the change**

Read the modified lines to confirm correctness. The logic should be:
1. If `type === 'event'` AND has `userId` → check ownership
2. No sessionKey → drop (continue)
3. SessionKey not owned → drop (continue)
4. SessionKey owned → deliver (write + continue)
5. Non-event types or no userId → deliver as-is (line 291)

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "fix: apply session ownership filtering to all users including admin"
```

---

### Task 2: Frontend — Strengthen workspace.ts handleEvent filter

**Files:**
- Modify: `src/stores/workspace.ts:611-615`

- [ ] **Step 1: Read the current handleEvent filter**

Read `src/stores/workspace.ts` lines 609-615 to confirm current code.

- [ ] **Step 2: Change the filter logic**

Current code (lines 611-615):
```typescript
const keyInEvent = extractSessionKey(payload)

if (activeSessionKey.value && keyInEvent && keyInEvent !== activeSessionKey.value) {
  return
}
```

New code:
```typescript
const keyInEvent = extractSessionKey(payload)

// No active session → drop all events
if (!activeSessionKey.value) return

// Event has sessionKey that doesn't match → drop
if (keyInEvent && keyInEvent !== activeSessionKey.value) return
```

Changes:
- When `activeSessionKey` is null/empty → drop ALL events (previously let everything through)
- When event has a sessionKey that doesn't match → drop (unchanged)
- When event has no sessionKey → let through (unchanged — some events may not carry sessionKey)

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix: drop SSE events when no active session in workspace store"
```

---

### Task 3: Frontend — Strengthen chat.ts handleRealtimeEvent filter

**Files:**
- Modify: `src/stores/chat.ts:602-607`

- [ ] **Step 1: Read the current filter**

Read `src/stores/chat.ts` lines 595-610 to confirm current code.

- [ ] **Step 2: Change the filter logic**

Current code (lines 602-607):
```typescript
const keyInEvent = extractSessionKey(payload)

// Drop events that belong to a different session
if (sessionKey.value.trim() && keyInEvent && keyInEvent !== sessionKey.value) {
  return
}
```

New code:
```typescript
const keyInEvent = extractSessionKey(payload)

// No active session → drop all events
if (!sessionKey.value.trim()) return

// Event has sessionKey that doesn't match → drop
if (keyInEvent && keyInEvent !== sessionKey.value) return
```

Changes:
- When `sessionKey` is empty → drop ALL events (previously let everything through)
- When event has a sessionKey that doesn't match → drop (unchanged)
- When event has no sessionKey → let through (unchanged)

- [ ] **Step 3: Commit**

```bash
git add src/stores/chat.ts
git commit -m "fix: drop SSE events when no active session in chat store"
```

---

### Task 4: Frontend — Add sessionKey filter to chat.ts handleAgentStatusEvent

**Files:**
- Modify: `src/stores/chat.ts:641-662`

- [ ] **Step 1: Read the current handleAgentStatusEvent**

Read `src/stores/chat.ts` lines 641-676 to confirm current code.

- [ ] **Step 2: Add sessionKey filter after extractSessionKey**

Current code (lines 641-662):
```typescript
function handleAgentStatusEvent(eventName: string, payload: unknown) {
  const normalizedEvent = eventName.trim().toLowerCase()
  if (!normalizedEvent) return

  const keyInEvent = extractSessionKey(payload)
  const payloadRow = asRecord(payload)

  // 从 sessionKey 中提取 agentId
  let agentId = 'default'
  if (keyInEvent) {
    const match = keyInEvent.match(/^agent:([^:]+):/)
    if (match && match[1]) {
      agentId = match[1]
    }
  } else if (sessionKey.value) {
    const match = sessionKey.value.match(/^agent:([^:]+):/)
    if (match && match[1]) {
      agentId = match[1]
    }
  }

  // 处理所有智能体的会话事件，不局限于当前 sessionKey
```

New code — insert filter after line 645 (after `extractSessionKey`):
```typescript
function handleAgentStatusEvent(eventName: string, payload: unknown) {
  const normalizedEvent = eventName.trim().toLowerCase()
  if (!normalizedEvent) return

  const keyInEvent = extractSessionKey(payload)

  // Session isolation: drop events for other sessions
  if (!sessionKey.value.trim()) return
  if (keyInEvent && keyInEvent !== sessionKey.value) return

  const payloadRow = asRecord(payload)

  // 从 sessionKey 中提取 agentId
  let agentId = 'default'
  if (keyInEvent) {
    const match = keyInEvent.match(/^agent:([^:]+):/)
    if (match && match[1]) {
      agentId = match[1]
    }
  } else if (sessionKey.value) {
    const match = sessionKey.value.match(/^agent:([^:]+):/)
    if (match && match[1]) {
      agentId = match[1]
    }
  }

  // 处理 agent 状态事件
```

Changes:
- Add two filter lines after `extractSessionKey`: drop when sessionKey is empty, drop when event sessionKey doesn't match
- Remove comment "处理所有智能体的会话事件，不局限于当前 sessionKey" — this is no longer true

- [ ] **Step 3: Commit**

```bash
git add src/stores/chat.ts
git commit -m "fix: add sessionKey filter to handleAgentStatusEvent"
```

---

### Task 5: Frontend — Add sessionKey filter to useEventStream.ts

**Files:**
- Modify: `src/composables/useEventStream.ts:16-26`

- [ ] **Step 1: Read the current file**

Read `src/composables/useEventStream.ts` to confirm current code.

- [ ] **Step 2: Add imports and sessionKey filter**

Current code (lines 1-27):
```typescript
import { computed, onMounted, onUnmounted } from 'vue'
import { useWebSocketStore } from '@/stores/websocket'
import { useMonitorStore } from '@/stores/monitor'
import type { RPCEvent, AgentEvent } from '@/api/types'

export function useEventStream(eventTypes?: string[]) {
  const wsStore = useWebSocketStore()
  const monitorStore = useMonitorStore()
  let cleanup: (() => void) | null = null

  const filteredEvents = computed(() => {
    if (!eventTypes || eventTypes.length === 0) return monitorStore.events
    return monitorStore.events.filter((e) => eventTypes.includes(e.event))
  })

  onMounted(() => {
    cleanup = wsStore.subscribe('event', (evt: unknown) => {
      const rpcEvent = evt as RPCEvent
      const agentEvent: AgentEvent = {
        event: rpcEvent.event,
        payload: rpcEvent.payload,
        seq: rpcEvent.seq,
        timestamp: Date.now(),
      }
      monitorStore.addEvent(agentEvent)
    })
  })
```

New code:
```typescript
import { computed, onMounted, onUnmounted } from 'vue'
import { useWebSocketStore } from '@/stores/websocket'
import { useMonitorStore } from '@/stores/monitor'
import { useWorkspaceStore } from '@/stores/workspace'
import type { RPCEvent, AgentEvent } from '@/api/types'

function extractSessionKey(payload: unknown): string {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return ''
  const row = payload as Record<string, unknown>
  if (typeof row.sessionKey === 'string') return row.sessionKey
  if (typeof row.key === 'string') return row.key
  if (row.session && typeof row.session === 'object' && !Array.isArray(row.session)) {
    const session = row.session as Record<string, unknown>
    if (typeof session.key === 'string') return session.key
    if (typeof session.sessionKey === 'string') return session.sessionKey
  }
  return ''
}

export function useEventStream(eventTypes?: string[]) {
  const wsStore = useWebSocketStore()
  const monitorStore = useMonitorStore()
  const workspaceStore = useWorkspaceStore()
  let cleanup: (() => void) | null = null

  const filteredEvents = computed(() => {
    if (!eventTypes || eventTypes.length === 0) return monitorStore.events
    return monitorStore.events.filter((e) => eventTypes.includes(e.event))
  })

  onMounted(() => {
    cleanup = wsStore.subscribe('event', (evt: unknown) => {
      const rpcEvent = evt as RPCEvent
      const payload = rpcEvent.payload as Record<string, unknown>
      const keyInEvent = extractSessionKey(payload)

      // Only process events for the active session
      if (!workspaceStore.activeSessionKey) return
      if (keyInEvent && keyInEvent !== workspaceStore.activeSessionKey) return

      const agentEvent: AgentEvent = {
        event: rpcEvent.event,
        payload: rpcEvent.payload,
        seq: rpcEvent.seq,
        timestamp: Date.now(),
      }
      monitorStore.addEvent(agentEvent)
    })
  })
```

Changes:
- Add `useWorkspaceStore` import
- Add local `extractSessionKey` helper (same logic as chat.ts/workspace.ts versions)
- Add sessionKey filter: drop when no active session, drop when event sessionKey doesn't match

- [ ] **Step 3: Commit**

```bash
git add src/composables/useEventStream.ts
git commit -m "fix: add sessionKey filter to useEventStream composable"
```

---

### Task 6: UI Fix — isStreaming stopReason check + ThinkingBlock always collapsed

**Files:**
- Modify: `src/views/workspace/MessageList.vue:69-77` (isStreaming)
- Modify: `src/views/workspace/MessageList.vue:244-248` (ThinkingBlock)

- [ ] **Step 1: Read the current isStreaming and ThinkingBlock code**

Read `src/views/workspace/MessageList.vue` lines 69-77 and 244-248.

- [ ] **Step 2: Fix isStreaming — remove stopReason check**

Current code (lines 69-77):
```typescript
const isStreaming = computed(() => {
  if (!workspaceStore.sending) return false
  const msgs = workspaceStore.messages
  if (msgs.length === 0) return true
  const last = msgs[msgs.length - 1]
  if (!last) return true
  if (last.stopReason) return false
  return last.role === 'assistant' || last.role === 'tool'
})
```

New code:
```typescript
const isStreaming = computed(() => {
  if (!workspaceStore.sending) return false
  const msgs = workspaceStore.messages
  if (msgs.length === 0) return true
  const last = msgs[msgs.length - 1]
  if (!last) return true
  return last.role === 'assistant' || last.role === 'tool'
})
```

Change: Remove line 75 (`if (last.stopReason) return false`). During `sending`, the last message being assistant/tool is sufficient to determine streaming state.

- [ ] **Step 3: Fix ThinkingBlock — always collapsed**

Current code (lines 244-248):
```html
<ThinkingBlock
  v-if="msg._thinking.isThinking && msg._thinking.thinking"
  :content="msg._thinking.thinking"
  :thinking="isLastAssistant(msg) && !msg._thinking.answer"
/>
```

New code:
```html
<ThinkingBlock
  v-if="msg._thinking.isThinking && msg._thinking.thinking"
  :content="msg._thinking.thinking"
  :thinking="false"
/>
```

Change: Replace dynamic `:thinking` expression with `false`. ThinkingBlock always shows in collapsed state. The bouncing dots animation handles the "thinking..." indicator.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "fix: prevent thinking/dots overlap — remove stopReason check, collapse ThinkingBlock"
```

---

### Task 7: Final verification

- [ ] **Step 1: Type check**

Run: `npx vue-tsc --noEmit`
Expected: No errors

- [ ] **Step 2: Manual verification checklist**

1. Open two browser windows with different non-admin users
2. User A starts a chat → User B should NOT see A's messages
3. User B starts a chat → User A should NOT see B's messages
4. Admin user → should only see own session events
5. Send a message with a thinking model → bouncing dots show, ThinkingBlock is collapsed
6. Switch sessions → history loads correctly

- [ ] **Step 3: Final commit with all fixes**

If any fixes were needed during verification, commit them.
