# 模型管理权限重构 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 重构模型管理权限系统，实现 admin 全局可见/有限管理、非 admin 私有 Provider 隔离、只读共享、彻底移除 model_remarks。

**Architecture:** 所有 Provider 统一存入 `user_model_providers` 表（加 remark/description 字段），同步写 Gateway config。后端按用户角色过滤可见性，前端按 readOnly 标记控制操作按钮。

**Tech Stack:** Node.js/Express (backend), Vue 3 + Naive UI (frontend), SQLite (better-sqlite3), OpenClaw Gateway config API

---

## File Structure

| File | Change | Responsibility |
|------|--------|----------------|
| `server/database.js` | Modify | 表加 remark/description 字段，删 model_remarks 建表 |
| `server/user-manager.js` | Modify | 删 model_remarks 函数，更新 Provider CRUD 函数支持 remark/description，新增查询函数 |
| `server/index.js` | Modify | 重写 Provider 路由权限逻辑，删 model-remarks 路由 |
| `src/views/models/ModelsPage.vue` | Modify | 适配新 API，只读 Provider 隐藏操作按钮，新增弹窗加 remark/description 字段，删模型级备注 UI |

---

### Task 1: 数据库迁移 — 加字段、删表

**Files:**
- Modify: `server/database.js:240-275`

- [ ] **Step 1: 在 database.js 的 migrations 数组中添加 remark 和 description 字段**

在 `server/database.js` 约 line 270 的 `migrations` 数组中追加：

```javascript
const migrations = [
  'ALTER TABLE user_agents ADD COLUMN category TEXT',
  'ALTER TABLE user_agents ADD COLUMN template_id TEXT',
  'ALTER TABLE user_agents ADD COLUMN avatar TEXT',
  'ALTER TABLE user_channels ADD COLUMN agent_id TEXT',
  'ALTER TABLE users ADD COLUMN password_changed_at INTEGER',
  'ALTER TABLE user_model_providers ADD COLUMN remark TEXT DEFAULT \'\'',
  'ALTER TABLE user_model_providers ADD COLUMN description TEXT DEFAULT \'\'',
]
```

- [ ] **Step 2: 删除 model_remarks 建表语句**

删除 `server/database.js` 中约 line 254-260 的 `CREATE TABLE IF NOT EXISTS model_remarks` 块。

- [ ] **Step 3: 验证**

启动服务 `node server/index.js`，检查日志无报错。用 sqlite3 检查：
```bash
sqlite3 data/wizard.db ".schema user_model_providers"
sqlite3 data/wizard.db ".schema model_remarks"
```
确认 remark/description 字段存在，model_remarks 表不再被创建（如果已存在则保留，不影响）。

---

### Task 2: user-manager.js — 删 model_remarks 函数，更新 Provider CRUD

**Files:**
- Modify: `server/user-manager.js:429-520`

- [ ] **Step 1: 更新 createUserModelProvider 函数，接受 remark/description 参数**

```javascript
export function createUserModelProvider(userId, providerId, config, remark = '', description = '') {
  const id = randomUUID()
  db.prepare(`
    INSERT INTO user_model_providers (id, user_id, provider_id, config, remark, description)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(id, userId, providerId, JSON.stringify(config || {}), remark || '', description || '')
  return db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(id)
}
```

- [ ] **Step 2: 更新 updateUserModelProvider 函数的 allowed 字段列表**

```javascript
export function updateUserModelProvider(id, updates) {
  const allowed = ['config', 'isPrimary', 'remark', 'description']
  const fields = []
  const values = []
  for (const key of allowed) {
    if (updates[key] !== undefined) {
      const dbKey = key === 'isPrimary' ? 'is_primary' : key.replace(/([A-Z])/g, '_$1').toLowerCase()
      fields.push(`${dbKey} = ?`)
      values.push(key === 'config' ? JSON.stringify(updates[key]) : updates[key])
    }
  }
  if (fields.length === 0) return null
  fields.push('updated_at = ?')
  values.push(Date.now())
  values.push(id)
  db.prepare(`UPDATE user_model_providers SET ${fields.join(', ')} WHERE id = ?`).run(...values)
  return db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(id)
}
```

- [ ] **Step 3: 新增 getAdminUserIds 函数**

```javascript
export function getAdminUserIds() {
  const rows = db.prepare('SELECT id FROM users WHERE role = ?').all('admin')
  return rows.map(r => r.id)
}
```

- [ ] **Step 4: 新增 getAllUserModelProviders 函数（admin 列表用）**

```javascript
export function getAllUserModelProviders() {
  return db.prepare('SELECT * FROM user_model_providers ORDER BY created_at DESC').all()
}
```

- [ ] **Step 5: 新增 getVisibleUserModelProviders 函数（非 admin 用）**

```javascript
export function getVisibleUserModelProviders(userId) {
  const adminIds = getAdminUserIds()
  const placeholders = adminIds.map(() => '?').join(',')
  return db.prepare(
    `SELECT * FROM user_model_providers WHERE user_id = ? OR user_id IN (${placeholders}) ORDER BY created_at DESC`
  ).all(userId, ...adminIds)
}
```

- [ ] **Step 6: 删除全部 model_remarks 相关函数**

删除 `server/user-manager.js` 中以下函数（约 line 480-520）：
- `getModelRemark`
- `getAllModelRemarks`
- `getModelRemarksByProvider`
- `setModelRemark`
- `setModelRemarksForProvider`

---

### Task 3: server/index.js — 重写 Provider 路由权限逻辑

**Files:**
- Modify: `server/index.js:30-44` (imports)
- Modify: `server/index.js:796-1072` (routes)

- [ ] **Step 1: 更新 import，删除 model_remarks 导入，新增新函数**

将 import 块中的：
```javascript
  getAllModelRemarks,
  getModelRemarksByProvider,
  setModelRemarksForProvider,
```
替换为：
```javascript
  getAllUserModelProviders,
  getVisibleUserModelProviders,
  getAdminUserIds,
```

同时保留已有的 `getUserModelProviders`, `getUserModelProvider`, `getUserModelProviderById`, `createUserModelProvider`, `updateUserModelProvider`, `deleteUserModelProvider`, `deleteUserModelProviderByProviderId`, `setUserModelPrimary` 等导入。

- [ ] **Step 2: 重写 GET /api/model-providers**

替换 line 796-884 的整个路由处理函数：

```javascript
app.get('/api/model-providers', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const isAdmin = req.currentUser.role === 'admin'

    // Get all users for ownerName lookup
    const allUsers = listUsers(1000, 0)
    const userMap = new Map(allUsers.map(u => [u.id, u.username]))

    // Get providers from local DB
    let rows
    if (isAdmin) {
      rows = getAllUserModelProviders()
    } else {
      rows = getVisibleUserModelProviders(userId)
    }

    const adminIds = new Set(getAdminUserIds())

    const providers = rows.map(row => {
      const parsedConfig = typeof row.config === 'string' ? JSON.parse(row.config) : row.config
      const isOwner = row.user_id === userId
      const ownerIsAdmin = adminIds.has(row.user_id)
      return {
        id: row.id,
        providerId: row.provider_id,
        config: parsedConfig,
        isPrimary: !!row.is_primary,
        remark: row.remark || '',
        description: row.description || '',
        source: ownerIsAdmin ? 'shared' : 'private',
        ownerName: userMap.get(row.user_id) || 'unknown',
        ownerId: row.user_id,
        readOnly: !isOwner,
      }
    })

    res.json({ ok: true, providers })
  } catch (err) {
    console.error('[ModelProviders] list error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 3: 重写 POST /api/model-providers（新建）**

替换 line 886-920 的路由：

```javascript
app.post('/api/model-providers', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const { providerId, config, remark, description } = req.body || {}

    if (!providerId || !config) {
      return res.status(400).json({ ok: false, error: 'providerId and config are required' })
    }

    // Check duplicate providerId for this user
    const existing = getUserModelProvider(userId, providerId)
    if (existing) {
      return res.status(409).json({ ok: false, error: 'Provider ID already exists for this user' })
    }

    // Write to local DB
    const row = createUserModelProvider(userId, providerId, config, remark || '', description || '')

    // Sync to Gateway config
    try {
      const gatewayConfig = await getGatewayConfig()
      if (gatewayConfig) {
        const providers = { ...(gatewayConfig.models?.providers || {}) }
        providers[providerId] = config
        const updatedConfig = {
          ...gatewayConfig,
          models: { ...gatewayConfig.models, providers },
        }
        await patchGatewayConfig(updatedConfig)
      }
    } catch (gwErr) {
      console.error('[ModelProviders] Gateway sync error on create:', gwErr.message)
      // Non-fatal: provider saved locally even if Gateway sync fails
    }

    res.json({ ok: true, providerId, id: row.id })
  } catch (err) {
    console.error('[ModelProviders] create error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 4: 重写 PUT /api/model-providers/:id（编辑）**

替换 line 922-950 的路由：

```javascript
app.put('/api/model-providers/:id', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const providerId = req.params.id
    const { config, remark, description } = req.body || {}

    // Verify ownership: only the creator can edit
    const existing = getUserModelProvider(userId, providerId)
    if (!existing) {
      return res.status(403).json({ ok: false, error: 'You can only edit your own providers' })
    }

    // Update local DB
    const updates = {}
    if (config !== undefined) updates.config = config
    if (remark !== undefined) updates.remark = remark
    if (description !== undefined) updates.description = description
    updateUserModelProvider(existing.id, updates)

    // Sync to Gateway config
    try {
      const gatewayConfig = await getGatewayConfig()
      if (gatewayConfig) {
        const providers = { ...(gatewayConfig.models?.providers || {}) }
        providers[providerId] = config || (typeof existing.config === 'string' ? JSON.parse(existing.config) : existing.config)
        const updatedConfig = {
          ...gatewayConfig,
          models: { ...gatewayConfig.models, providers },
        }
        await patchGatewayConfig(updatedConfig)
      }
    } catch (gwErr) {
      console.error('[ModelProviders] Gateway sync error on update:', gwErr.message)
    }

    res.json({ ok: true, providerId })
  } catch (err) {
    console.error('[ModelProviders] update error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 5: 重写 DELETE /api/model-providers/:id（删除）**

替换 line 952-1001 的路由：

```javascript
app.delete('/api/model-providers/:id', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const providerId = req.params.id

    // Verify ownership: only the creator can delete
    const existing = getUserModelProvider(userId, providerId)
    if (!existing) {
      return res.status(403).json({ ok: false, error: 'You can only delete your own providers' })
    }

    // Remove from Gateway config
    try {
      const gatewayConfig = await getGatewayConfig()
      if (gatewayConfig) {
        const providers = { ...(gatewayConfig.models?.providers || {}) }
        delete providers[providerId]
        const updatedConfig = {
          ...gatewayConfig,
          models: { ...gatewayConfig.models, mode: 'replace', providers },
        }
        // Clean up agents.defaults.models entries for deleted provider
        const existingDefaultsModels = gatewayConfig.agents?.defaults?.models || {}
        const newDefaultsModels = {}
        for (const [modelRef, entry] of Object.entries(existingDefaultsModels)) {
          if (!modelRef.startsWith(`${providerId}/`)) {
            newDefaultsModels[modelRef] = entry
          }
        }
        if (Object.keys(newDefaultsModels).length !== Object.keys(existingDefaultsModels).length) {
          updatedConfig.agents = {
            ...gatewayConfig.agents,
            defaults: { ...gatewayConfig.agents?.defaults, models: newDefaultsModels },
          }
        }
        await setGatewayConfig(updatedConfig)
      }
    } catch (gwErr) {
      console.error('[ModelProviders] Gateway sync error on delete:', gwErr.message)
    }

    // Remove from local DB
    deleteUserModelProvider(existing.id)

    res.json({ ok: true })
  } catch (err) {
    console.error('[ModelProviders] delete error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 6: 重写 PUT /api/model-providers/default（设默认）**

替换 line 1004-1038 的路由：

```javascript
app.put('/api/model-providers/default', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.id
    const { modelRef } = req.body || {}

    if (!modelRef) {
      return res.status(400).json({ ok: false, error: 'modelRef is required' })
    }

    // Set primary in local DB (user-level default, not global)
    const parsed = modelRef.split('/')[0]
    if (parsed) {
      setUserModelPrimary(userId, parsed)
    }

    // Also update Gateway config for agents.defaults.models
    try {
      const gatewayConfig = await getGatewayConfig()
      if (gatewayConfig) {
        const updatedConfig = {
          ...gatewayConfig,
          models: { ...gatewayConfig.models, primary: modelRef },
        }
        await patchGatewayConfig(updatedConfig)
      }
    } catch (gwErr) {
      console.error('[ModelProviders] Gateway sync error on set default:', gwErr.message)
    }

    res.json({ ok: true })
  } catch (err) {
    console.error('[ModelProviders] set default error:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 7: 删除 model-remarks 路由**

删除 `server/index.js` 中约 line 1041-1072 的两个路由：
- `app.get('/api/model-remarks', ...)`
- `app.put('/api/model-remarks/:providerId', ...)`

- [ ] **Step 8: Commit backend changes**

```bash
git add server/database.js server/user-manager.js server/index.js
git commit -m "refactor: 重写模型管理权限系统

- 所有 Provider 统一存入 user_model_providers 表
- admin 看全部，非 admin 只看 admin 创建的 + 自己的
- 只有创建者能编辑/删除自己的 Provider
- 新增 remark/description 字段
- 删除 model_remarks 相关代码
- 所有操作同步写 Gateway config"
```

---

### Task 4: 前端 ModelsPage — 适配新 API 和权限 UI

**Files:**
- Modify: `src/views/models/ModelsPage.vue`

- [ ] **Step 1: 删除 saveModelRemarks 函数**

删除约 line 60-71 的 `saveModelRemarks` 函数。

- [ ] **Step 2: 更新 Provider 数据结构类型**

在约 line 90 的 ModelConfig 附近，添加 Provider 类型定义（或更新现有逻辑）：

```typescript
type ProviderItem = {
  id: string
  providerId: string
  config: ModelProviderConfig
  isPrimary: boolean
  remark: string
  description: string
  source: 'shared' | 'private'
  ownerName: string
  ownerId: string
  readOnly: boolean
}
```

- [ ] **Step 3: 替换 providerVisibility 逻辑**

删除 `providerVisibility` ref（约 line 592）和 `editableProviderIds` computed（约 line 601-606）。

替换为基于 REST API 返回数据的新状态：

```typescript
const apiProviders = ref<ProviderItem[]>([])

const providerList = computed(() => {
  if (isAdmin.value) {
    // Admin: use API data directly
    return apiProviders.value
  }
  // Non-admin: use API data directly
  return apiProviders.value
})

const editableProviderIds = computed(() => {
  return new Set(
    apiProviders.value
      .filter(p => !p.readOnly)
      .map(p => p.providerId)
  )
})
```

- [ ] **Step 4: 更新 onMounted 改为所有用户都调 REST API**

替换 onMounted（约 line 1192-1206）：

```typescript
onMounted(async () => {
  // All users load providers from REST API
  try {
    const data = await modelProviderApiCall('')
    apiProviders.value = (data.providers || []).map((p: any) => ({
      ...p,
      config: typeof p.config === 'string' ? JSON.parse(p.config) : p.config,
    }))
  } catch (err) {
    console.error('Failed to load providers:', err)
  }
  // Also load Gateway config for admin management
  if (isAdmin.value) {
    await configStore.fetchConfig()
  }
})
```

- [ ] **Step 5: 更新 providerEntries computed 使用 API 数据**

替换 providerEntries computed（约 line 594-598）。Admin 不再从 Gateway config 读 provider 列表，统一从 REST API 获取：

```typescript
const providerEntries = computed(() => {
  return apiProviders.value.map(p => ({
    id: p.providerId,
    provider: p.config,
    pathPrefix: 'models.providers' as const,
  }))
})
```

- [ ] **Step 6: 更新新建渠道弹窗 — 添加 remark 和 description 字段**

在新建渠道的弹窗模板中（`showCreateProviderModal`），找到表单区域，在 providerId 输入框之后添加：

```html
<NFormItem :label="t('pages.models.form.remark') || '备注'">
  <NInput v-model:value="createProviderForm.remark" :placeholder="t('pages.models.form.remarkPlaceholder') || '简短备注'" />
</NFormItem>
<NFormItem :label="t('pages.models.form.description') || '说明'">
  <NInput
    v-model:value="createProviderForm.description"
    type="textarea"
    :rows="3"
    :placeholder="t('pages.models.form.descriptionPlaceholder') || '详细说明'"
  />
</NFormItem>
```

同时在 `createProviderForm` 的初始化中添加 `remark: ''` 和 `description: ''` 字段。

- [ ] **Step 7: 更新编辑渠道弹窗 — 添加 remark 和 description 字段**

在编辑渠道的弹窗模板中（`showEditProviderModal`），同样添加 remark 和 description 的输入框，绑定到 `providerForm.remark` 和 `providerForm.description`。

同时在 `providerForm` 的初始化和 `loadProviderForm` 函数中处理这两个字段。

- [ ] **Step 8: 更新新建/编辑的 API 调用，传递 remark 和 description**

找到新建和编辑时调用 `modelProviderApiCall` 的地方，在 body 中添加 `remark` 和 `description` 字段：

新建：
```javascript
await modelProviderApiCall('', {
  method: 'POST',
  body: JSON.stringify({
    providerId: createProviderForm.providerId,
    config: buildProviderConfig(createProviderForm),
    remark: createProviderForm.remark || '',
    description: createProviderForm.description || '',
  }),
})
```

编辑：
```javascript
await modelProviderApiCall(`/${providerId}`, {
  method: 'PUT',
  body: JSON.stringify({
    config: buildProviderConfig(providerForm),
    remark: providerForm.remark || '',
    description: providerForm.description || '',
  }),
})
```

- [ ] **Step 9: 只读 Provider 隐藏编辑/删除按钮**

找到模板中编辑和删除按钮的位置（通常在 provider 详情区域），用 `readOnly` 判断控制：

```html
<template v-if="!isCurrentProviderReadOnly">
  <!-- 编辑、删除、设默认等操作按钮 -->
</template>
```

添加 computed：
```typescript
const isCurrentProviderReadOnly = computed(() => {
  const current = apiProviders.value.find(p => p.providerId === selectedProviderId.value)
  return current?.readOnly ?? false
})
```

- [ ] **Step 10: Admin 视角显示非 admin Provider 的创建者名称**

在 provider 列表项或详情区域，当 `ownerName` 存在且不是 admin 自己时，显示创建者标签：

```html
<NTag v-if="currentProvider.ownerName && currentProvider.ownerId !== authStore.userId" size="small" type="info">
  {{ currentProvider.ownerName }}
</NTag>
```

- [ ] **Step 11: 删除模型级别备注 UI**

在编辑弹窗的模型列表中，删除每个模型的 `remark` 输入框（约 line 2677-2678 和 2942-2943）。删除 `saveModelRemarks` 调用处（通常在保存 provider 时）。

- [ ] **Step 12: 添加 i18n key**

在 `src/i18n/messages/zh-CN.ts` 的 `pages.models.form` 中添加：

```typescript
remark: '备注',
remarkPlaceholder: '简短备注',
description: '说明',
descriptionPlaceholder: '详细说明（选填）',
```

在 `src/i18n/messages/en-US.ts` 对应位置添加：

```typescript
remark: 'Remark',
remarkPlaceholder: 'Short remark',
description: 'Description',
descriptionPlaceholder: 'Detailed description (optional)',
```

- [ ] **Step 13: 类型检查**

```bash
npx vue-tsc --noEmit
```

修复所有类型错误。

- [ ] **Step 14: Commit frontend changes**

```bash
git add src/views/models/ModelsPage.vue src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat: 前端适配模型管理权限系统

- 所有用户统一从 REST API 获取 Provider 列表
- 只读 Provider 隐藏编辑/删除按钮
- 新建/编辑弹窗添加备注和说明字段
- 删除模型级别备注 UI
- Admin 视角显示其他用户的 Provider 创建者"
```

---

### Task 5: 清理残留和验证

- [ ] **Step 1: 全局搜索确认无 model_remarks 残留引用**

```bash
grep -rn "model_remark\|modelRemark\|model-remark\|saveModelRemarks\|getModelRemark\|setModelRemark\|getAllModelRemarks" server/ src/
```

逐一清理残留引用。

- [ ] **Step 2: 启动服务端验证**

```bash
node server/index.js
```

检查日志无报错。

- [ ] **Step 3: 用 curl 测试 API**

```bash
# Admin 登录
TOKEN=$(curl -s -X POST http://localhost:3001/api/auth/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | jq -r '.token')

# 获取 Provider 列表（admin）
curl -s http://localhost:3001/api/model-providers -H "Authorization: Bearer $TOKEN" | jq '.providers | length'

# 非 admin 登录
TOKEN2=$(curl -s -X POST http://localhost:3001/api/auth/login -H 'Content-Type: application/json' -d '{"username":"test1","password":"admin123"}' | jq -r '.token')

# 获取 Provider 列表（非 admin）
curl -s http://localhost:3001/api/model-providers -H "Authorization: Bearer $TOKEN2" | jq '.providers | length'

# 非 admin 尝试删除 admin 的 Provider（应 403）
curl -s -X DELETE http://localhost:3001/api/model-providers/zhipu -H "Authorization: Bearer $TOKEN2" | jq .
```

- [ ] **Step 4: 前端浏览器验证**

用 admin 和 test1 分别登录，确认：
- admin 能看到所有 Provider
- test1 只能看到 admin 创建的 + 自己创建的
- test1 不能编辑/删除 admin 的 Provider
- test1 新建的 Provider test2 看不到

- [ ] **Step 5: Final commit**

```bash
git add -A
git commit -m "chore: 清理 model_remarks 残留引用"
```
