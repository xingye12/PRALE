# 模型备注与说明显示 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在聊天界面和数字员工编辑页的模型选择下拉框中显示备注（remark）和说明（description），数据源与模型管理页一致。

**Architecture:** 新建 `useModelProviders` composable 从 `GET /api/model-providers` 加载 Provider 数据，构建模型到备注/描述的映射。新建 `ModelDropdown.vue` 通用组件，封装下拉框+备注显示+说明弹出卡片。两个消费页面（ChatInput、AgentEditPage）替换现有模型选择 UI。

**Tech Stack:** Vue 3 Composition API, TypeScript, CSS Variables, Fetch API

**Note:** 本项目未配置测试框架，验证通过浏览器手动测试。

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `src/composables/useModelProviders.ts` | Create | 从 API 加载 Provider 数据，构建模型→备注/描述映射 |
| `src/components/ModelDropdown.vue` | Create | 通用模型选择下拉框组件（chip/select 两种样式） |
| `src/views/workspace/ChatInput.vue` | Modify | 替换自定义 dropdown 为 ModelDropdown |
| `src/views/agent-team/AgentEditPage.vue` | Modify | 替换 NSelect 为 ModelDropdown |

---

### Task 1: Create useModelProviders composable

**Files:**
- Create: `src/composables/useModelProviders.ts`
- Reference: `src/views/models/ModelsPage.vue` (readProviderModelIds logic, lines 389-457)
- Reference: `server/index.js` (API response shape, lines 832-848)

- [ ] **Step 1: Create the composable file**

```typescript
// src/composables/useModelProviders.ts
import { ref, computed } from 'vue'

export interface ModelOption {
  id: string
  label: string
  providerId: string
  remark: string
  description: string
}

const providers = ref<any[]>([])
const loaded = ref(false)

async function fetchProviders() {
  try {
    const token = localStorage.getItem('auth_token')
    if (!token) return
    const res = await fetch('/api/model-providers', {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
    })
    const data = await res.json()
    if (data.ok && Array.isArray(data.providers)) {
      providers.value = data.providers.map((p: any) => ({
        ...p,
        config: typeof p.config === 'string' ? JSON.parse(p.config) : p.config,
      }))
    }
    loaded.value = true
  } catch {
    loaded.value = true
  }
}

function extractModelsFromConfig(config: any): Array<{ id: string; name?: string; remark?: string }> {
  if (!config) return []
  const candidates: unknown[] = [config.models, config.modelIds, config.availableModels, config.whitelist]
  const results: Array<{ id: string; name?: string; remark?: string }> = []

  for (const candidate of candidates) {
    if (!candidate) continue
    if (Array.isArray(candidate)) {
      for (const item of candidate) {
        if (typeof item === 'string') {
          results.push({ id: item })
        } else if (item && typeof item === 'object' && 'id' in item) {
          const obj = item as Record<string, unknown>
          results.push({
            id: String(obj.id),
            name: obj.name ? String(obj.name) : undefined,
            remark: obj.remark ? String(obj.remark) : undefined,
          })
        }
      }
      break
    } else if (typeof candidate === 'object') {
      for (const [key, value] of Object.entries(candidate as Record<string, unknown>)) {
        if (value && typeof value === 'object' && 'id' in (value as Record<string, unknown>)) {
          const obj = value as Record<string, unknown>
          results.push({
            id: String(obj.id),
            name: obj.name ? String(obj.name) : undefined,
            remark: obj.remark ? String(obj.remark) : undefined,
          })
        } else {
          results.push({ id: key })
        }
      }
      break
    }
  }

  return results
}

const modelList = computed<ModelOption[]>(() => {
  const seen = new Set<string>()
  const result: ModelOption[] = []

  for (const provider of providers.value) {
    const config = provider.config || {}
    const models = extractModelsFromConfig(config)
    for (const m of models) {
      if (seen.has(m.id)) continue
      seen.add(m.id)
      result.push({
        id: m.id,
        label: m.name || m.id,
        providerId: provider.providerId,
        remark: m.remark || provider.remark || '',
        description: provider.description || '',
      })
    }
  }

  return result
})

function getModelRemark(modelId: string): string {
  return modelList.value.find((m) => m.id === modelId)?.remark || ''
}

function getModelDescription(modelId: string): string {
  return modelList.value.find((m) => m.id === modelId)?.description || ''
}

function getModelOption(modelId: string): ModelOption | undefined {
  return modelList.value.find((m) => m.id === modelId)
}

export function useModelProviders() {
  return {
    providers,
    modelList,
    loaded,
    fetchProviders,
    getModelRemark,
    getModelDescription,
    getModelOption,
  }
}
```

Key design decisions:
- Module-level `providers` ref — shared singleton across all consumers, only one API call
- `extractModelsFromConfig` handles all three config formats (string array, object array, object map)
- Remark priority: model-level `remark` > provider-level `remark`
- Description is always provider-level
- Deduplication by model id across providers

- [ ] **Step 2: Verify no TypeScript errors**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: No errors in `src/composables/useModelProviders.ts`

- [ ] **Step 3: Commit**

```bash
git add src/composables/useModelProviders.ts
git commit -m "feat: add useModelProviders composable for model remark/description data"
```

---

### Task 2: Create ModelDropdown component

**Files:**
- Create: `src/components/ModelDropdown.vue`
- Reference: `src/views/workspace/ChatInput.vue` (existing dropdown CSS, lines 402-520)

- [ ] **Step 1: Create the component file**

```vue
<!-- src/components/ModelDropdown.vue -->
<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { useModelProviders } from '@/composables/useModelProviders'

type Variant = 'chip' | 'select'

const props = withDefaults(defineProps<{
  modelValue: string
  variant?: Variant
}>(), {
  variant: 'chip',
})

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const { modelList, loaded, fetchProviders } = useModelProviders()

const showDropdown = ref(false)
const hoveredModelId = ref<string | null>(null)
const hoverTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const leaveTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const descCardPos = ref({ top: 0 })
const dropdownRef = ref<HTMLElement | null>(null)
const triggerRef = ref<HTMLElement | null>(null)

onMounted(() => {
  if (!loaded.value) fetchProviders()
})

const selectedOption = computed(() =>
  modelList.value.find((m) => m.id === props.modelValue)
)

const displayLabel = computed(() => {
  const opt = selectedOption.value
  if (!opt) return props.modelValue || 'Agent'
  return opt.label || opt.id
})

const displayRemark = computed(() => {
  return selectedOption.value?.remark || ''
})

const hasDescription = computed(() => {
  if (!hoveredModelId.value) return false
  const m = modelList.value.find((m) => m.id === hoveredModelId.value)
  return !!m?.description
})

const descContent = computed(() => {
  if (!hoveredModelId.value) return { label: '', description: '' }
  const m = modelList.value.find((m) => m.id === hoveredModelId.value)
  return {
    label: m?.label || m?.id || '',
    description: m?.description || '',
  }
})

function toggleDropdown(e: MouseEvent) {
  e.stopPropagation()
  showDropdown.value = !showDropdown.value
}

function selectModel(id: string) {
  emit('update:modelValue', id)
  showDropdown.value = false
}

function onItemEnter(modelId: string, e: MouseEvent) {
  if (leaveTimer.value) {
    clearTimeout(leaveTimer.value)
    leaveTimer.value = null
  }
  const target = e.currentTarget as HTMLElement
  descCardPos.value = { top: target.offsetTop }

  hoverTimer.value = setTimeout(() => {
    hoveredModelId.value = modelId
  }, 100)
}

function onItemLeave() {
  if (hoverTimer.value) {
    clearTimeout(hoverTimer.value)
    hoverTimer.value = null
  }
  leaveTimer.value = setTimeout(() => {
    hoveredModelId.value = null
  }, 200)
}

function onCardEnter() {
  if (leaveTimer.value) {
    clearTimeout(leaveTimer.value)
    leaveTimer.value = null
  }
}

function onCardLeave() {
  leaveTimer.value = setTimeout(() => {
    hoveredModelId.value = null
  }, 200)
}

function onDocClick(e: MouseEvent) {
  const target = e.target as HTMLElement
  if (!target.closest('.model-dropdown-root')) {
    showDropdown.value = false
  }
}

watch(showDropdown, (val) => {
  if (val) {
    document.addEventListener('click', onDocClick, { once: true })
  }
})

onUnmounted(() => {
  if (hoverTimer.value) clearTimeout(hoverTimer.value)
  if (leaveTimer.value) clearTimeout(leaveTimer.value)
  document.removeEventListener('click', onDocClick)
})
</script>

<template>
  <div class="model-dropdown-root" ref="dropdownRef">
    <!-- Chip trigger (for ChatInput) -->
    <button
      v-if="variant === 'chip'"
      class="chip"
      :class="{ active: showDropdown }"
      @click="toggleDropdown"
    >
      <span class="material-symbols-outlined" style="font-size:13px">smart_toy</span>
      <span class="chip-label">{{ displayRemark ? `${displayLabel}（${displayRemark}）` : displayLabel }}</span>
      <span class="chip-chevron">&#9662;</span>
    </button>

    <!-- Select trigger (for AgentEditPage) -->
    <button
      v-else
      class="select-trigger"
      :class="{ active: showDropdown }"
      @click="toggleDropdown"
    >
      <span class="select-value">{{ displayRemark ? `${displayLabel}（${displayRemark}）` : (displayLabel || '选择模型') }}</span>
      <span class="select-arrow">&#9662;</span>
    </button>

    <!-- Dropdown panel -->
    <div v-if="showDropdown" class="dropdown-panel">
      <div class="dropdown-scroll">
        <div
          v-for="model in modelList"
          :key="model.id"
          class="dd-item"
          :class="{ active: model.id === modelValue }"
          @click="selectModel(model.id)"
          @mouseenter="onItemEnter(model.id, $event)"
          @mouseleave="onItemLeave"
        >
          <span class="dd-name">{{ model.label || model.id }}</span>
          <span v-if="model.remark" class="dd-remark">{{ model.remark }}</span>
          <span v-if="model.id === modelValue" class="dd-check">&#10003;</span>
        </div>
      </div>

      <!-- Description popup card -->
      <Transition name="desc-card">
        <div
          v-if="hasDescription"
          class="desc-card"
          :style="{ top: descCardPos.top + 'px' }"
          @mouseenter="onCardEnter"
          @mouseleave="onCardLeave"
        >
          <div class="desc-card-title">{{ descContent.label }}</div>
          <div class="desc-card-divider"></div>
          <div class="desc-card-text">{{ descContent.description }}</div>
        </div>
      </Transition>
    </div>
  </div>
</template>

<style scoped>
.model-dropdown-root {
  position: relative;
  min-width: 0;
}

/* ── Chip trigger ── */
.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-muted);
  font-weight: 500;
  cursor: pointer;
  transition: all .12s;
  font-size: 12px;
  white-space: nowrap;
  font-family: inherit;
}

.chip:hover {
  background: var(--bg-hover);
  color: var(--text);
}

.chip.active {
  background: var(--accent-bg);
  border-color: var(--accent-bg-strong);
  color: var(--accent-text);
}

.chip-label {
  max-width: clamp(180px, 28vw, 360px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.chip-chevron {
  opacity: .5;
  font-size: 10px;
}

/* ── Select trigger ── */
.select-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  width: 100%;
  padding: 4px 8px;
  border-radius: 6px;
  border: 1px solid var(--border-color, #e0e0e6);
  background: var(--bg-card, #fff);
  color: var(--text);
  font-size: 13px;
  cursor: pointer;
  transition: all .12s;
  font-family: inherit;
  text-align: left;
}

.select-trigger:hover {
  border-color: var(--accent);
}

.select-trigger.active {
  border-color: var(--accent);
  box-shadow: 0 0 0 2px var(--accent-bg);
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.select-arrow {
  opacity: .5;
  font-size: 10px;
  flex-shrink: 0;
}

/* ── Dropdown panel ── */
.dropdown-panel {
  position: absolute;
  bottom: calc(100% + 6px);
  left: 0;
  z-index: 200;
}

.select-trigger ~ .dropdown-panel {
  bottom: auto;
  top: calc(100% + 4px);
}

.dropdown-scroll {
  min-width: 280px;
  max-width: 420px;
  width: max-content;
  max-height: 320px;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--bg-surface);
  border: 1px solid var(--border2);
  border-radius: 10px;
  box-shadow: 0 -4px 20px rgba(0,0,0,.1);
  padding: 4px;
}

[data-theme='dark'] .dropdown-scroll {
  box-shadow: 0 -4px 20px rgba(0,0,0,.3);
}

.select-trigger ~ .dropdown-panel .dropdown-scroll {
  box-shadow: 0 4px 20px rgba(0,0,0,.1);
}

/* ── Dropdown items ── */
.dd-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  font-size: 13px;
  cursor: pointer;
  transition: background .1s;
  color: var(--text);
}

.dd-name {
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
}

.dd-remark {
  margin-left: auto;
  flex-shrink: 0;
  max-width: 140px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 11px;
  color: var(--text-secondary);
}

.dd-item:hover {
  background: var(--bg-hover);
}

.dd-item.active {
  background: var(--accent-bg);
  color: var(--accent-text);
}

.dd-item.active .dd-remark {
  color: var(--accent-text);
  opacity: .7;
}

.dd-check {
  flex-shrink: 0;
  font-size: 11px;
  color: var(--accent);
}

/* ── Description popup card ── */
.desc-card {
  position: absolute;
  left: calc(100% + 8px);
  top: 0;
  width: 260px;
  max-width: 300px;
  padding: 12px;
  background: var(--bg-card);
  border: 1px solid var(--border-color, #e0e0e6);
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
  z-index: 201;
  pointer-events: auto;
}

[data-theme='dark'] .desc-card {
  box-shadow: 0 4px 16px rgba(0,0,0,.3);
}

.desc-card-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-strong, #1a1a1a);
  margin-bottom: 8px;
}

.desc-card-divider {
  height: 1px;
  background: var(--border-color, #e0e0e6);
  margin-bottom: 8px;
}

.desc-card-text {
  font-size: 12px;
  line-height: 1.6;
  color: var(--text-secondary);
  white-space: pre-wrap;
  word-break: break-word;
}

/* ── Transition ── */
.desc-card-enter-active {
  transition: opacity .15s, transform .15s;
}

.desc-card-leave-active {
  transition: opacity .1s;
}

.desc-card-enter-from {
  opacity: 0;
  transform: translateX(-4px);
}

.desc-card-leave-to {
  opacity: 0;
}
</style>
```

Key design decisions:
- `variant` prop switches between chip (ChatInput) and select (AgentEditPage) trigger styles
- Description card positioned with absolute + `left: calc(100% + 8px)` relative to dropdown panel
- Card position tracked via `offsetTop` of the hovered item
- 100ms enter delay, 200ms leave delay for smooth interaction
- `pointer-events: auto` on card ensures it captures mouse events
- `<Transition>` for smooth fade in/out
- Select variant positions dropdown below trigger (top instead of bottom)

- [ ] **Step 2: Verify no TypeScript errors**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: No errors in `src/components/ModelDropdown.vue`

- [ ] **Step 3: Commit**

```bash
git add src/components/ModelDropdown.vue
git commit -m "feat: add ModelDropdown component with remark and description display"
```

---

### Task 3: Adapt ChatInput.vue

**Files:**
- Modify: `src/views/workspace/ChatInput.vue`

This task replaces the custom model dropdown in ChatInput with the new ModelDropdown component and removes all localStorage remark code.

- [ ] **Step 1: Update imports — remove model store, add ModelDropdown**

In `src/views/workspace/ChatInput.vue`, replace lines 1-7:

```typescript
// BEFORE (lines 1-7):
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useWorkspaceStore } from '@/stores/workspace'
import { apiPath } from '@/utils/api-path'
import { useModelStore } from '@/stores/model'
import SlashCommandMenu from './components/SlashCommandMenu.vue'
```

```typescript
// AFTER:
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useWorkspaceStore } from '@/stores/workspace'
import { apiPath } from '@/utils/api-path'
import ModelDropdown from '@/components/ModelDropdown.vue'
import SlashCommandMenu from './components/SlashCommandMenu.vue'
```

- [ ] **Step 2: Remove localStorage remark code and model store references**

Remove from the script section (lines 10-59 approximately):
- `const modelStore = useModelStore()` — REMOVE
- `const availableModels = computed(...)` — REMOVE
- `const modelRemarksVersion = ref(0)` — REMOVE
- `const modelRemarks = computed(...)` — REMOVE (the entire block lines 27-44)
- `function getModelRemark(...)` — REMOVE (lines 46-52)
- `function getModelDisplayName(...)` — REMOVE (lines 54-59)
- `const showModelDropdown = ref(false)` — REMOVE
- `function formatModelLabel(...)` — REMOVE (lines 157-162)
- `function selectModel(...)` — REMOVE
- `function handleModelChipClick(...)` — REMOVE
- `function onDocClick(...)` — REMOVE
- `watch(showModelDropdown, ...)` — REMOVE

Keep `selectedModel` computed (it reads from workspaceStore). But change its usage — we only need the value:

```typescript
const selectedModel = computed(() => workspaceStore.selectedModel)
```

This stays as-is since ModelDropdown uses `v-model`.

Add the handler for model change:
```typescript
function onModelChange(modelId: string) {
  workspaceStore.selectedModel = modelId
}
```

- [ ] **Step 3: Replace the model dropdown template**

Replace lines 346-364:

```html
<!-- BEFORE: -->
          <div class="model-wrap" v-if="availableModels.length > 0">
            <button class="chip" :class="{ active: showModelDropdown }" @click="handleModelChipClick">
              <span class="material-symbols-outlined" style="font-size:13px">smart_toy</span>
              <span class="chip-label">{{ formatModelLabel(selectedModel || 'Agent') }}</span>
              <span class="chip-chevron">&#9662;</span>
            </button>
            <div class="dropdown" v-if="showModelDropdown">
              <div
                v-for="model in modelStore.models"
                :key="model.id"
                class="dd-item"
                :class="{ active: model.id === selectedModel }"
                @click="selectModel(model.id)"
              >
                <span>{{ getModelDisplayName(model) }}</span>
                <span v-if="model.id === selectedModel" class="dd-check">&#10003;</span>
              </div>
            </div>
          </div>
```

```html
<!-- AFTER: -->
          <ModelDropdown
            :model-value="selectedModel || ''"
            variant="chip"
            @update:model-value="onModelChange"
          />
```

- [ ] **Step 4: Remove unused CSS**

Remove all CSS classes that are now handled by ModelDropdown:
- `.model-wrap` — REMOVE
- `.chip`, `.chip:hover`, `.chip.active` — REMOVE
- `.chip-label` — REMOVE
- `.chip-chevron` — REMOVE
- `.dropdown` — REMOVE
- `.dd-item`, `.dd-item > span:first-child`, `.dd-item:hover`, `.dd-item.active` — REMOVE
- `.dd-check` — REMOVE

- [ ] **Step 5: Verify TypeScript compiles**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: No errors related to ChatInput.vue

- [ ] **Step 6: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "refactor: replace ChatInput model dropdown with ModelDropdown component"
```

---

### Task 4: Adapt AgentEditPage.vue

**Files:**
- Modify: `src/views/agent-team/AgentEditPage.vue`

This task replaces the NSelect in AgentEditPage with ModelDropdown and removes localStorage remark code.

- [ ] **Step 1: Update imports**

Replace lines 1-8:

```typescript
// BEFORE:
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NButton, NInput, NSelect, NSpin, NTab, NTabs, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import { useModelStore } from '@/stores/model'
```

```typescript
// AFTER:
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NButton, NInput, NSpin, NTab, NTabs, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import ModelDropdown from '@/components/ModelDropdown.vue'
```

Changes: Removed `NSelect` from naive-ui imports, removed `useModelStore`, added `ModelDropdown`.

- [ ] **Step 2: Remove model store, localStorage remark code, and modelOptions**

Remove these blocks from the script:
- `const modelStore = useModelStore()` — REMOVE
- `const MODEL_REMARKS_STORAGE_KEY = 'wattclaw:model-remarks'` — REMOVE (line 36)
- `function readModelRemark(...)` — REMOVE (lines 38-57, entire function)
- `const modelOptions = computed(...)` — REMOVE (lines 59-70, entire computed)

Remove from `onMounted`:
- `void modelStore.fetchModels()` — REMOVE (line 128)

Keep everything else in the script.

- [ ] **Step 3: Replace NSelect template**

Replace lines 195-198:

```html
<!-- BEFORE: -->
        <div class="sidebar-model">
          <p class="sidebar-label">{{ t('pages.agentTeam.edit.modelLabel') }}</p>
          <NSelect v-model:value="editData.model" :options="modelOptions" size="small" filterable @update:value="scheduleAutoSave" />
        </div>
```

```html
<!-- AFTER: -->
        <div class="sidebar-model">
          <p class="sidebar-label">{{ t('pages.agentTeam.edit.modelLabel') }}</p>
          <ModelDropdown
            :model-value="editData.model"
            variant="select"
            @update:model-value="(v: string) => { editData.model = v; scheduleAutoSave() }"
          />
        </div>
```

- [ ] **Step 4: Verify TypeScript compiles**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: No errors related to AgentEditPage.vue

- [ ] **Step 5: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "refactor: replace AgentEditPage NSelect with ModelDropdown component"
```

---

### Task 5: Manual verification

No automated tests in this project. Browser verification required.

- [ ] **Step 1: Start dev servers**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./restart.sh`

- [ ] **Step 2: Verify ChatInput model dropdown**

1. Open browser to `http://localhost:3000`
2. Login as admin (admin:admin123)
3. Go to Workspace, select an agent, start a conversation
4. Click the model chip in the input area
5. Verify: dropdown shows model names with remarks (淡色) aligned right
6. Hover over a model that has a description → description card appears on the right
7. Mouse away → card disappears after short delay
8. Select a different model → chip updates, model is used for next message

- [ ] **Step 3: Verify AgentEditPage model dropdown**

1. Go to 数字员工 (AgentTeam) page
2. Click on an agent to edit
3. Find the model selector in the left sidebar
4. Verify: it has a select-like appearance (border, not chip)
5. Click to open → same dropdown with remarks and description card
6. Select a model → auto-save triggers

- [ ] **Step 4: Verify non-admin user**

1. Login as test1 (test1:admin123)
2. Repeat steps 2-3 — should only see their visible providers' models
3. Verify remark/description shows correctly for shared (admin-created) providers

- [ ] **Step 5: Verify dark mode**

1. Toggle dark mode
2. Check dropdown and description card in both light/dark modes
3. Verify CSS variables adapt correctly

- [ ] **Step 6: Commit all changes (if any fixes needed)**

```bash
git add -A
git commit -m "fix: adjustments from browser verification"
```

---

## Self-Review Checklist

### Spec Coverage
- [x] Data from `GET /api/model-providers` → Task 1
- [x] Model list from Provider `config.models[]` → Task 1
- [x] Remark display (淡色, 右对齐, 单行) → Task 2
- [x] Description popup card (右侧, 延迟, 动画) → Task 2
- [x] ChatInput adaptation (chip variant) → Task 3
- [x] AgentEditPage adaptation (select variant) → Task 4
- [x] Remove localStorage remark code → Tasks 3, 4
- [x] No backend changes → confirmed

### Placeholder Scan
- [x] No TBD/TODO/placeholders
- [x] All code blocks contain actual implementation code
- [x] All commands are exact

### Type Consistency
- [x] `ModelOption` interface defined in Task 1, used consistently in Task 2
- [x] `useModelProviders()` return type consistent across all consumers
- [x] `variant` prop type `'chip' | 'select'` used in Tasks 3 and 4
- [x] `emit('update:modelValue', id)` matches `v-model` pattern
