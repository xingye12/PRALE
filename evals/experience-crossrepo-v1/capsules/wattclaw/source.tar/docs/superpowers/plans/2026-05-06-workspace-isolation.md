# Workspace 隔离 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为新创建的 agent 建立按用户隔离的 workspace 目录，注入文件路径规则到 BOOTSTRAP.md，并将用户上传的文件定向到 agent workspace 的 uploads/ 子目录。

**Architecture:** 改三个独立路径：workspace 路径生成（前端）、bootstrap 规则注入（前端）、文件上传路径（前端+后端）。每个路径可独立测试。

**Tech Stack:** Vue 3 + TypeScript (frontend), Node.js/Express (backend), SSH/SFTP (file transfer), Gateway RPC

---

### Task 1: 新增 `generateBootstrapWithWorkspaceRules()` 函数

**Files:**
- Modify: `src/config/agent-templates.ts`

- [ ] **Step 1: 在 `agent-templates.ts` 中添加函数**

在文件末尾（`getTemplateById` 函数之后）添加：

```typescript
export function generateBootstrapWithWorkspaceRules(
  bootstrapMd: string,
  workspacePath: string,
): string {
  const rules = `

## 文件路径规则

你的 workspace 根目录为: \`${workspacePath}\`

1. **所有中间文件**必须写到当前 workspace 目录下，禁止写入 \`/tmp/\`（工具临时文件除外）
2. **用户上传的文件**存放在: \`${workspacePath}/uploads/\`
3. **交付文件/会话生成的文件**写到: \`${workspacePath}/downloads/\`
4. **临时工作文件**写到: \`${workspacePath}/tmp/\`
5. **禁止写入用户 home 目录**（除非用户明确指定路径）
6. **使用相对路径或显式 workspace 路径**，不要依赖 shell cwd
7. 需要时在 \`downloads/\` 下创建子目录以组织输出文件
8. 如果 workspace 子目录不存在，先创建再写入
`
  const marker = '<!-- WORKSPACE_RULES -->'
  if (bootstrapMd.includes(marker)) {
    return bootstrapMd.replace(marker, rules)
  }
  return bootstrapMd + rules
}
```

- [ ] **Step 2: 运行类型检查验证**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无新增错误（可能存在预存错误，不影响）

- [ ] **Step 3: Commit**

```bash
git add src/config/agent-templates.ts
git commit -m "feat: add generateBootstrapWithWorkspaceRules function"
```

---

### Task 2: 在 29 个 bootstrap 模板文件末尾追加 WORKSPACE_RULES 标记

**Files:**
- Modify: `src/bootstrap/*.md` (29 files)

- [ ] **Step 1: 用脚本批量追加标记**

Run:
```bash
for f in src/bootstrap/*.md; do
  if ! grep -q '<!-- WORKSPACE_RULES -->' "$f"; then
    printf '\n\n<!-- WORKSPACE_RULES -->\n' >> "$f"
  fi
done
echo "Done. Files modified:"
grep -rl '<!-- WORKSPACE_RULES -->' src/bootstrap/ | wc -l
```
Expected: 29 files contain the marker

- [ ] **Step 2: 验证标记已追加**

Run: `grep -L '<!-- WORKSPACE_RULES -->' src/bootstrap/*.md`
Expected: 无输出（所有文件都包含标记）

- [ ] **Step 3: Commit**

```bash
git add src/bootstrap/
git commit -m "feat: add WORKSPACE_RULES marker to all bootstrap templates"
```

---

### Task 3: 修改数字员工 workspace 路径格式

**Files:**
- Modify: `src/views/agent-team/AgentTeamPage.vue:89-98`

- [ ] **Step 1: 修改 workspace 路径生成逻辑**

将 `AgentTeamPage.vue` 第 89-98 行从：

```typescript
const workspaceUser = sanitizeWorkspaceSegment(
  authStore.currentUser?.display_name || authStore.currentUser?.username || '',
  'user'
)
const workspaceAgent = sanitizeWorkspaceSegment(data.name, 'agent')
const workspaceTime = formatWorkspaceTimestamp()
const workspaceName = `${workspaceUser}-${workspaceAgent}-${workspaceTime}`
const createResult = await wsStore.rpc.createAgent({
  name: agentSlug,
  workspace: `~/.openclaw/${workspaceName}`,
})
```

改为：

```typescript
const workspaceUser = sanitizeWorkspaceSegment(
  authStore.currentUser?.username || '',
  'user'
)
const workspaceAgent = sanitizeWorkspaceSegment(data.name, 'agent')
const workspaceTime = formatWorkspaceTimestamp()
const workspaceName = `${workspaceAgent}-${workspaceTime}`
const workspacePath = `~/.wattclaw/${workspaceUser}/${workspaceName}`
const createResult = await wsStore.rpc.createAgent({
  name: agentSlug,
  workspace: workspacePath,
})
```

注意：`workspacePath` 变量需要在后续步骤中使用，用于 bootstrap 注入。

- [ ] **Step 2: 在写入 BOOTSTRAP.md 时注入 workspace 规则**

在 `AgentTeamPage.vue` 文件顶部 import 区域添加：

```typescript
import { generateBootstrapWithWorkspaceRules } from '@/config/agent-templates'
```

将第 130 行的 bootstrap 写入从：

```typescript
['BOOTSTRAP.md', data.bootstrapMd],
```

改为：

```typescript
['BOOTSTRAP.md', generateBootstrapWithWorkspaceRules(data.bootstrapMd, workspacePath)],
```

- [ ] **Step 3: 运行类型检查**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无新增错误

- [ ] **Step 4: Commit**

```bash
git add src/views/agent-team/AgentTeamPage.vue
git commit -m "feat: use ~/.wattclaw/{username}/ workspace path + inject workspace rules"
```

---

### Task 4: 修改低级 agent workspace 路径

**Files:**
- Modify: `src/stores/agent.ts:133`

- [ ] **Step 1: 修改默认 workspace 路径**

将 `agent.ts` 第 133 行从：

```typescript
const workspace = params.workspace || `~/.openclaw/workspace-${params.id}`;
```

改为：

```typescript
const workspace = params.workspace || `~/.wattclaw/agents/workspace-${params.id}`;
```

- [ ] **Step 2: 运行类型检查**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无新增错误

- [ ] **Step 3: Commit**

```bash
git add src/stores/agent.ts
git commit -m "feat: use ~/.wattclaw/agents/ for low-level agent workspace"
```

---

### Task 5: 修改 uploadToGateway 支持自定义目标目录

**Files:**
- Modify: `server/gateway-file-transfer.js:106-121`

- [ ] **Step 1: 添加 `targetDir` 参数支持**

将 `uploadToGateway` 函数签名（第 106 行）从：

```javascript
export async function uploadToGateway(buffer, fileName, envConfig) {
```

改为：

```javascript
export async function uploadToGateway(buffer, fileName, envConfig, targetDir) {
```

将第 113 行的默认值逻辑从：

```javascript
GATEWAY_MEDIA_DIR = '/home/wattman/.openclaw/media/inbound',
```

改为：

```javascript
GATEWAY_MEDIA_DIR = targetDir || '/home/wattman/.openclaw/media/inbound',
```

这样当 `targetDir` 传入时使用自定义目录，否则用默认值。

- [ ] **Step 2: Commit**

```bash
git add server/gateway-file-transfer.js
git commit -m "feat: uploadToGateway supports custom target directory"
```

---

### Task 6: 修改后端 upload 路由支持 agentId

**Files:**
- Modify: `server/index.js:2568-2586`

- [ ] **Step 1: 修改 upload 路由**

将 `server/index.js` 第 2568-2586 行从：

```javascript
app.post('/api/workspace/upload-to-gateway', authMiddleware, gatewayUpload.single('file'), async (req, res) => {
  try {
    const file = req.file
    if (!file) {
      return res.status(400).json({ ok: false, error: 'No file provided' })
    }

    const MAX_SIZE = 30 * 1024 * 1024 // 30 MB
    if (file.size > MAX_SIZE) {
      return res.status(413).json({ ok: false, error: 'File too large (max 30 MB)' })
    }

    const result = await uploadToGateway(file.buffer, file.originalname, envConfig)
    res.json({ ok: true, ...result })
  } catch (err) {
    console.error('[Workspace] Upload error:', err.message)
    res.status(502).json({ ok: false, error: `Upload to Gateway failed: ${err.message}` })
  }
})
```

改为：

```javascript
app.post('/api/workspace/upload-to-gateway', authMiddleware, gatewayUpload.single('file'), async (req, res) => {
  try {
    const file = req.file
    if (!file) {
      return res.status(400).json({ ok: false, error: 'No file provided' })
    }

    const MAX_SIZE = 30 * 1024 * 1024 // 30 MB
    if (file.size > MAX_SIZE) {
      return res.status(413).json({ ok: false, error: 'File too large (max 30 MB)' })
    }

    let targetDir = null
    const agentId = req.body?.agentId
    if (agentId) {
      const workspace = await getAgentWorkspace(agentId)
      if (workspace) {
        const expanded = expandHomePath(workspace)
        targetDir = expanded + '/uploads'
      }
    }

    const result = await uploadToGateway(file.buffer, file.originalname, envConfig, targetDir)
    res.json({ ok: true, ...result })
  } catch (err) {
    console.error('[Workspace] Upload error:', err.message)
    res.status(502).json({ ok: false, error: `Upload to Gateway failed: ${err.message}` })
  }
})
```

`getAgentWorkspace` 和 `expandHomePath` 已在 `server/index.js` 中定义（第 1563 行和第 1592 行），无需额外引入。

- [ ] **Step 2: Commit**

```bash
git add server/index.js
git commit -m "feat: upload route supports agentId for workspace-isolated uploads"
```

---

### Task 7: 修改前端 uploadFile 附带 agentId

**Files:**
- Modify: `src/views/workspace/ChatInput.vue:56-73`

- [ ] **Step 1: 在 FormData 中追加 agentId**

将 `ChatInput.vue` 第 56-73 行的 `uploadFile` 函数从：

```typescript
async function uploadFile(file: File): Promise<{ path: string; fileName: string; size: number }> {
  const formData = new FormData()
  formData.append('file', file)

  const token = localStorage.getItem('auth_token')
  const res = await fetch(apiPath('/api/workspace/upload-to-gateway'), {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Upload failed' }))
    throw new Error(err.error || `Upload failed (${res.status})`)
  }

  return res.json()
}
```

改为：

```typescript
async function uploadFile(file: File): Promise<{ path: string; fileName: string; size: number }> {
  const formData = new FormData()
  formData.append('file', file)
  if (workspaceStore.selectedAgentId) {
    formData.append('agentId', workspaceStore.selectedAgentId)
  }

  const token = localStorage.getItem('auth_token')
  const res = await fetch(apiPath('/api/workspace/upload-to-gateway'), {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Upload failed' }))
    throw new Error(err.error || `Upload failed (${res.status})`)
  }

  return res.json()
}
```

- [ ] **Step 2: 运行类型检查**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无新增错误

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "feat: include agentId in file upload for workspace isolation"
```

---

### Task 8: 端到端验证

- [ ] **Step 1: 重启服务**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./restart.sh`

- [ ] **Step 2: 验证数字员工创建**

在浏览器中：
1. 以 admin 登录
2. 创建一个新的数字员工（任意模板）
3. 验证创建成功无报错
4. 进入该数字员工编辑页，检查 agent 配置中 workspace 路径格式为 `~/.wattclaw/{username}/{agentname-timestamp}`

- [ ] **Step 3: 验证 bootstrap 注入**

通过 Gateway API 或编辑页查看新 agent 的 BOOTSTRAP.md，确认末尾包含"文件路径规则"段落，且 workspace 路径正确。

- [ ] **Step 4: 验证文件上传**

1. 在在线对话中选中新创建的 agent
2. 上传一个测试文件
3. 检查上传成功无报错
4. 通过 SSH 检查文件是否上传到 `{workspace}/uploads/` 目录

- [ ] **Step 5: 验证旧 agent 不受影响**

1. 确认旧的 agent 的 workspace 仍为 `~/.openclaw/...` 格式
2. 对旧 agent 上传文件，仍走默认 `media/inbound/` 路径（因为没有传 agentId 或 agent 没有 wattclaw workspace）
