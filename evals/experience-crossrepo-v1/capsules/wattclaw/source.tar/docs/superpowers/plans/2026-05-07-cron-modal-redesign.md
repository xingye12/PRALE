# 定时任务配置弹窗重构 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 CronPage 的配置弹窗从程序员视角的表单改为用户友好的可视化交互界面。

**Architecture:** 在现有 `CronPage.vue` 中就地改造 `showModal` 弹窗。用 NTabs + NTimePicker + 星期按钮组替代 cron 表达式输入；用 agent_team 下拉框替代 AgentId 文本框；技术字段收入高级设置折叠区。

**Tech Stack:** Vue 3, TypeScript, Naive UI (NTabs, NTimePicker, NCollapse, NSwitch, NSelect), Pinia, vue-i18n

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `src/views/cron/CronPage.vue` | Modify | 弹窗 template 重写 + form 状态扩展 + 新增映射函数 |
| `src/i18n/messages/zh-CN.ts` | Modify | 新增/修改弹窗相关的 i18n key |

---

### Task 1: 扩展表单状态和引入 agent team store

**Files:**
- Modify: `src/views/cron/CronPage.vue:1-175` (imports + form reactive)

- [ ] **Step 1: 添加新的 Naive UI 组件 imports**

在文件顶部的 naive-ui import 块中，添加 `NTabs, NTabPane, NTimePicker, NCollapse, NCollapseItem`。移除不再需要的 `NCode`（如果只在 previewPayload 中使用）。

当前 imports 位于 line 4-27：
```typescript
import {
  NAlert,
  NButton,
  NCard,
  NCode,         // 保留，其他地方（run detail）仍在用
  NDataTable,
  NDivider,      // 保留，其他地方仍在用
  NForm,
  NFormItem,
  NGrid,
  NGridItem,
  NInput,
  NInputNumber,
  NModal,
  NPopconfirm,
  NRadioButton,
  NRadioGroup,
  NSelect,
  NSpace,
  NSwitch,
  NTag,
  NText,
  useMessage,
} from 'naive-ui'
```

修改为：
```typescript
import {
  NAlert,
  NButton,
  NCard,
  NCode,
  NCollapse,
  NCollapseItem,
  NDataTable,
  NDivider,
  NForm,
  NFormItem,
  NGrid,
  NGridItem,
  NInput,
  NInputNumber,
  NModal,
  NPopconfirm,
  NRadioButton,
  NRadioGroup,
  NSelect,
  NSpace,
  NSwitch,
  NTabPane,
  NTabs,
  NTag,
  NText,
  NTimePicker,
  useMessage,
} from 'naive-ui'
```

- [ ] **Step 2: 引入 agent team store**

在 import 区域（约 line 30 附近），添加：
```typescript
import { useAgentTeamStore } from '@/stores/agent-team'
import type { AgentTeamMember } from '@/api/types/agent-team'
```

在 store 实例化区域（约 line 68-74），添加：
```typescript
const agentTeamStore = useAgentTeamStore()
```

- [ ] **Step 3: 扩展 form reactive 对象**

在现有的 `form` reactive（约 line 146-173）中，添加新字段：
```typescript
const form = reactive({
  name: '',
  description: '',
  agentId: '',
  enabled: true,
  deleteAfterRun: false,

  // 调度可视化状态（新增）
  scheduleTab: 'daily' as 'daily' | 'monthly' | 'interval',
  scheduleHour: 8,
  scheduleMinute: 0,
  scheduleWeekdays: [1, 2, 3, 4, 5] as number[],
  scheduleMonthDays: [1] as number[],

  // 保留原始字段用于反向兼容
  scheduleKind: 'cron' as ScheduleKind,
  cronExpr: '0 7 * * *',
  cronTz: '',
  everyValue: 1,
  everyUnit: 'hours' as EveryUnit,
  atTime: '',

  sessionTarget: 'isolated' as 'main' | 'isolated',
  wakeMode: 'next-heartbeat' as 'next-heartbeat' | 'now',

  payloadKind: 'agentTurn' as 'systemEvent' | 'agentTurn',
  payloadText: '',
  model: '',
  thinking: '',
  timeoutSeconds: 120,

  // 通知简化（新增）
  notifyEnabled: true,
  deliveryMode: 'announce' as 'none' | 'announce',
  deliveryChannel: 'last',
  deliveryTo: '',
  deliveryBestEffort: true,

  // 高级设置折叠（新增）
  showAdvanced: false,
})
```

- [ ] **Step 4: 更新 resetForm 函数**

修改 `resetForm()`（line 877-900），重置新字段：
```typescript
function resetForm() {
  form.name = ''
  form.description = ''
  form.agentId = ''
  form.enabled = true
  form.deleteAfterRun = false
  form.scheduleTab = 'daily'
  form.scheduleHour = 8
  form.scheduleMinute = 0
  form.scheduleWeekdays = [1, 2, 3, 4, 5]
  form.scheduleMonthDays = [1]
  form.scheduleKind = 'cron'
  form.cronExpr = '0 7 * * *'
  form.cronTz = ''
  form.everyValue = 1
  form.everyUnit = 'hours'
  form.atTime = ''
  form.sessionTarget = 'isolated'
  form.wakeMode = 'next-heartbeat'
  form.payloadKind = 'agentTurn'
  form.payloadText = ''
  form.model = defaultModelRef.value || ''
  form.thinking = ''
  form.timeoutSeconds = 120
  form.notifyEnabled = true
  form.deliveryMode = 'announce'
  form.deliveryChannel = 'last'
  form.deliveryTo = ''
  form.deliveryBestEffort = true
  form.showAdvanced = false
}
```

- [ ] **Step 5: 在 handleRefresh 和 onMounted 中加载 agent team 数据**

找到 `handleRefresh` 函数（line 1412-1422），在 `Promise.all` 中添加：
```typescript
agentTeamStore.fetchAgents(),
```

找到 `onMounted` 中的初始化逻辑，确保 `agentTeamStore.fetchAgents()` 也被调用（如果 handleRefresh 已经在 onMounted 中调用了，则无需重复）。

- [ ] **Step 6: 添加 agent team 下拉选项 computed**

在 `deliveryChannelOptions` computed 附近（约 line 300），添加：
```typescript
const agentTeamOptions = computed<Array<{ label: string; value: string }>>(() => {
  const options: Array<{ label: string; value: string }> = [
    { label: t('pages.cron.form.defaultAgent'), value: '' },
  ]
  for (const agent of agentTeamStore.agentList) {
    options.push({ label: agent.name, value: agent.id })
  }
  return options
})
```

- [ ] **Step 7: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "feat(cron): extend form state and import agent team store for modal redesign"
```

---

### Task 2: 添加调度可视化映射函数

**Files:**
- Modify: `src/views/cron/CronPage.vue` (script section, after existing helper functions)

- [ ] **Step 1: 添加每日/每月 → cron 映射函数**

在 `buildSchedule()` 函数之前（约 line 1004），添加：
```typescript
const WEEKDAY_LABELS = ['一', '二', '三', '四', '五', '六', '日']

function dailyToCron(hour: number, minute: number, weekdays: number[]): string {
  const dow = weekdays.length === 7 ? '*' : [...weekdays].sort((a, b) => a - b).join(',')
  return `${minute} ${hour} * * ${dow}`
}

function monthlyToCron(hour: number, minute: number, days: number[]): string {
  const dom = [...days].sort((a, b) => a - b).join(',')
  return `${minute} ${hour} ${dom} * *`
}

function intervalToEveryMs(value: number, unit: 'minutes' | 'hours' | 'days'): number {
  const multiplier = unit === 'days' ? 86_400_000 : unit === 'hours' ? 3_600_000 : 60_000
  return value * multiplier
}
```

- [ ] **Step 2: 添加 cron → 可视化反向解析函数**

```typescript
function parseCronToVisual(expr: string): {
  tab: 'daily' | 'monthly'
  hour: number
  minute: number
  weekdays?: number[]
  days?: number[]
} | null {
  const parts = expr.trim().replace(/\s+/g, ' ').split(' ')
  if (parts.length !== 5) return null

  const minute = parts[0] ?? ''
  const hour = parts[1] ?? ''
  const dayOfMonth = parts[2] ?? ''
  const month = parts[3] ?? ''
  const dayOfWeek = parts[4] ?? ''

  if (month !== '*') return null
  if (!/^\d+$/.test(minute) || !/^\d+$/.test(hour)) return null

  const hourNum = Number(hour)
  const minuteNum = Number(minute)

  if (dayOfWeek === '*' && dayOfMonth === '*') {
    return { tab: 'daily', hour: hourNum, minute: minuteNum, weekdays: [1, 2, 3, 4, 5, 6, 7] }
  }

  if (dayOfMonth === '*' && dayOfWeek !== '*') {
    const weekdays = parseDowField(dayOfWeek)
    if (weekdays) return { tab: 'daily', hour: hourNum, minute: minuteNum, weekdays }
  }

  if (dayOfWeek === '*' && dayOfMonth !== '*') {
    const days = parseDomField(dayOfMonth)
    if (days) return { tab: 'monthly', hour: hourNum, minute: minuteNum, days }
  }

  return null
}

function parseDowField(field: string): number[] | null {
  const result = new Set<number>()
  for (const part of field.split(',')) {
    if (/^\d+$/.test(part)) {
      result.add(Number(part))
    } else if (/^\d+-\d+$/.test(part)) {
      const [start, end] = part.split('-').map(Number)
      for (let i = start; i <= end; i++) result.add(i)
    } else {
      return null
    }
  }
  return result.size > 0 ? Array.from(result).sort((a, b) => a - b) : null
}

function parseDomField(field: string): number[] | null {
  const result = new Set<number>()
  for (const part of field.split(',')) {
    if (/^\d+$/.test(part)) {
      const n = Number(part)
      if (n >= 1 && n <= 31) result.add(n)
    } else if (/^\d+-\d+$/.test(part)) {
      const [start, end] = part.split('-').map(Number)
      for (let i = start; i <= end; i++) {
        if (i >= 1 && i <= 31) result.add(i)
      }
    } else {
      return null
    }
  }
  return result.size > 0 ? Array.from(result).sort((a, b) => a - b) : null
}
```

- [ ] **Step 3: 修改 buildSchedule 函数**

将现有 `buildSchedule()`（line 1004-1040）改为根据 `scheduleTab` 构建调度：

```typescript
function buildSchedule(): CronSchedule {
  if (form.scheduleTab === 'interval') {
    const amount = Number(form.everyValue)
    if (!Number.isFinite(amount) || amount <= 0) {
      throw new Error(t('pages.cron.validation.everyValueInvalid'))
    }
    return {
      kind: 'every',
      everyMs: intervalToEveryMs(amount, form.everyUnit),
    }
  }

  if (form.scheduleTab === 'monthly') {
    if (form.scheduleMonthDays.length === 0) {
      throw new Error('请选择至少一个日期')
    }
    return {
      kind: 'cron',
      expr: monthlyToCron(form.scheduleHour, form.scheduleMinute, form.scheduleMonthDays),
      tz: form.cronTz.trim() || undefined,
    }
  }

  // daily
  if (form.scheduleWeekdays.length === 0) {
    throw new Error('请选择至少一个星期')
  }
  return {
    kind: 'cron',
    expr: dailyToCron(form.scheduleHour, form.scheduleMinute, form.scheduleWeekdays),
    tz: form.cronTz.trim() || undefined,
  }
}
```

- [ ] **Step 4: 修改 fillFormByJob 中的反向解析逻辑**

修改 `fillFormByJob` 函数（line 935-984）中处理 schedule 的部分。替换现有的 schedule 解析逻辑：

```typescript
// 替换 line 943-961 的 schedule 解析逻辑
const schedule = job.scheduleObj
if (schedule?.kind === 'every') {
  form.scheduleTab = 'interval'
  const every = resolveEveryForm(schedule.everyMs)
  form.everyValue = every.value
  form.everyUnit = every.unit
} else {
  const cronSource = schedule?.kind === 'cron' ? schedule.expr : (job.schedule || '0 7 * * *')
  form.cronTz = schedule?.kind === 'cron' ? (schedule.tz || '') : (job.timezone || '')

  const visual = parseCronToVisual(cronSource)
  if (visual) {
    form.scheduleTab = visual.tab
    form.scheduleHour = visual.hour
    form.scheduleMinute = visual.minute
    if (visual.weekdays) form.scheduleWeekdays = visual.weekdays
    if (visual.days) form.scheduleMonthDays = visual.days
  } else {
    // 无法解析 → 回退到高级设置
    form.scheduleTab = 'daily'
    form.cronExpr = cronSource
    form.scheduleWeekdays = [1, 2, 3, 4, 5, 6, 7]
    form.showAdvanced = true
  }
}

if (schedule?.kind === 'at') {
  form.atTime = toDatetimeLocal(schedule.at)
  form.scheduleTab = 'daily'
  form.showAdvanced = true
}
```

- [ ] **Step 5: 修改 applyQuickTemplate 中的 schedule 赋值逻辑**

修改 `applyQuickTemplate`（line 909-926），让它也设置可视化状态：

```typescript
function applyQuickTemplate(preset: CronTemplatePreset) {
  openCreateModal()
  form.name = preset.label
  form.description = preset.description

  if (preset.scheduleKind === 'every') {
    form.scheduleTab = 'interval'
    form.everyValue = preset.everyValue || 1
    form.everyUnit = preset.everyUnit || 'hours'
  } else if (preset.scheduleKind === 'cron') {
    const expr = preset.cronExpr || '0 8 * * *'
    const visual = parseCronToVisual(expr)
    if (visual) {
      form.scheduleTab = visual.tab
      form.scheduleHour = visual.hour
      form.scheduleMinute = visual.minute
      if (visual.weekdays) form.scheduleWeekdays = visual.weekdays
      if (visual.days) form.scheduleMonthDays = visual.days
    } else {
      form.scheduleTab = 'daily'
      form.cronExpr = expr
    }
  }

  form.sessionTarget = preset.sessionTarget || 'isolated'
  form.payloadKind = preset.payloadKind || 'agentTurn'
  form.payloadText = preset.payloadText
  form.notifyEnabled = (preset.deliveryMode || 'announce') === 'announce'
  form.deliveryMode = form.notifyEnabled ? 'announce' : 'none'
}
```

- [ ] **Step 6: 添加调度预览文本 computed**

```typescript
const schedulePreviewText = computed(() => {
  if (form.scheduleTab === 'interval') {
    return t('pages.cron.schedule.every', {
      value: form.everyValue,
      unit: form.everyUnit === 'minutes' ? t('pages.cron.units.minutes')
        : form.everyUnit === 'hours' ? t('pages.cron.units.hours')
        : t('pages.cron.units.days'),
    })
  }

  const time = `${String(form.scheduleHour).padStart(2, '0')}:${String(form.scheduleMinute).padStart(2, '0')}`

  if (form.scheduleTab === 'monthly') {
    const days = form.scheduleMonthDays.sort((a, b) => a - b).join('、')
    return t('pages.cron.schedule.monthlyAt', { day: days, time })
  }

  // daily
  if (form.scheduleWeekdays.length === 7) {
    return t('pages.cron.schedule.dailyAt', { time })
  }
  const weekdayNames = form.scheduleWeekdays
    .sort((a, b) => a - b)
    .map(d => `周${WEEKDAY_LABELS[d - 1] || d}`)
    .join('、')
  return t('pages.cron.schedule.weeklyAt', { weekdays: weekdayNames, time })
})
```

- [ ] **Step 7: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "feat(cron): add visual schedule mapping functions and reverse parsing"
```

---

### Task 3: 添加星期按钮组和日期选择器辅助函数

**Files:**
- Modify: `src/views/cron/CronPage.vue` (script section)

- [ ] **Step 1: 添加星期/日期 toggle 函数**

```typescript
function toggleWeekday(day: number) {
  const idx = form.scheduleWeekdays.indexOf(day)
  if (idx >= 0) {
    form.scheduleWeekdays = form.scheduleWeekdays.filter(d => d !== day)
  } else {
    form.scheduleWeekdays = [...form.scheduleWeekdays, day]
  }
}

function toggleMonthDay(day: number) {
  const idx = form.scheduleMonthDays.indexOf(day)
  if (idx >= 0) {
    form.scheduleMonthDays = form.scheduleMonthDays.filter(d => d !== day)
  } else {
    form.scheduleMonthDays = [...form.scheduleMonthDays, day]
  }
}

function isWeekdaySelected(day: number): boolean {
  return form.scheduleWeekdays.includes(day)
}

function isMonthDaySelected(day: number): boolean {
  return form.scheduleMonthDays.includes(day)
}
```

- [ ] **Step 2: 添加测试指令处理函数**

```typescript
const testingPrompt = ref(false)

async function handleTestPrompt() {
  const text = form.payloadText.trim()
  if (!text) {
    message.warning('请先输入 AI 指令')
    return
  }

  testingPrompt.value = true
  try {
    const schedule = buildSchedule()
    const payload = buildPayload()
    const submitData: CronUpsertParams = {
      name: `[测试] ${form.name || '未命名任务'}`,
      description: '测试指令执行',
      enabled: false,
      deleteAfterRun: true,
      schedule: { kind: 'at', at: new Date(Date.now() + 1000).toISOString() },
      sessionTarget: form.sessionTarget,
      wakeMode: form.wakeMode,
      payload,
      delivery: { mode: 'none' },
    }
    const agentId = form.agentId.trim()
    if (agentId) submitData.agentId = agentId

    await cronStore.createJob(submitData)
    message.success(t('pages.cron.messages.testPromptSent'))
  } catch (error) {
    message.error(error instanceof Error ? error.message : '测试失败')
  } finally {
    testingPrompt.value = false
  }
}
```

- [ ] **Step 3: 添加 notifyEnabled 同步 watch**

```typescript
watch(() => form.notifyEnabled, (val) => {
  form.deliveryMode = val ? 'announce' : 'none'
})
```

- [ ] **Step 4: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "feat(cron): add weekday/monthday toggle helpers and test prompt handler"
```

---

### Task 4: 更新 i18n 翻译

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts` (pages.cron section, lines ~571-798)

- [ ] **Step 1: 新增和修改 i18n keys**

在 `pages.cron` 对象中，修改以下 key 并新增 key：

```typescript
// 修改 scheduleKinds（改为 Tab 标签）
scheduleKinds: {
  cron: 'Cron 表达式',    // 保留（高级设置中用）
  every: '固定间隔',       // 保留（高级设置中用）
  at: '指定时间',          // 保留（高级设置中用）
},

// 新增 scheduleTabs（Tab 标签）
scheduleTabs: {
  daily: '每日',
  monthly: '每月',
  interval: '间隔',
},

// 修改 form 中的 agentId
form: {
  name: '任务名称',
  namePlaceholder: '请输入任务名称',
  agentId: '执行员工',                    // 改：从"多智能体 ID"改为"执行员工"
  agentIdPlaceholder: '默认（不指定）',    // 改
  // ... 其他保持不变 ...
  payloadText: 'AI 指令 (Prompt)',        // 改：从"执行文本"改为"AI 指令 (Prompt)"
  payloadTextPlaceholders: {
    agentTurn: '请输入 AI 指令，例如：帮我总结今日最新科技资讯。',  // 改
    systemEvent: '输入 system event 内容',
  },
  deliveryMode: '任务结果与通知',          // 改
  deliveryModes: {
    announce: '开启通知',                  // 改
    none: '关闭通知',                      // 改
  },
  deliveryChannel: '接收应用',             // 改
  deliveryTo: '发送至',                    // 改
  // ... 其他保持不变 ...
},

// 新增
advancedSettings: '高级设置',
testPrompt: '测试指令',
testPromptSent: '测试指令已发送，请稍后在运行历史中查看结果',
selectTime: '选择时间',
selectWeekdays: '重复',
selectAllWeekdays: '每天',
monthDayPrefix: '日',
weekdayNames: {
  1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '日',
},
```

- [ ] **Step 2: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat(cron): add i18n keys for redesigned cron modal"
```

---

### Task 5: 重写弹窗 template

**Files:**
- Modify: `src/views/cron/CronPage.vue` (template section, lines ~1867-2110)

这是核心任务。替换 `showModal` 对应的 `<NModal>` 的内部内容（line 1867-2110）。

- [ ] **Step 1: 替换弹窗 template**

找到 `<NModal v-model:show="showModal"` 开始到其闭合 `</NModal>` 标签（约 line 1867-2110），替换为：

```html
    <NModal
      v-model:show="showModal"
      preset="card"
      :title="isEditing ? t('pages.cron.modal.editTitle') : t('pages.cron.modal.createTitle')"
      style="width: 640px; max-width: calc(100vw - 32px);"
    >
      <NSpace vertical :size="18">
        <!-- 基础信息 -->
        <div>
          <NFormItem :label="t('pages.cron.form.name')" :show-feedback="false" required>
            <NInput v-model:value="form.name" :placeholder="t('pages.cron.form.namePlaceholder')" />
          </NFormItem>
        </div>
        <NGrid cols="1 s:2" responsive="screen" :x-gap="12">
          <NGridItem>
            <NFormItem :label="t('pages.cron.form.agentId')" :show-feedback="false">
              <NSelect
                v-model:value="form.agentId"
                :options="agentTeamOptions"
                :loading="agentTeamStore.loading"
                clearable
                :placeholder="t('pages.cron.form.agentIdPlaceholder')"
              />
            </NFormItem>
          </NGridItem>
          <NGridItem>
            <NFormItem :label="t('pages.cron.form.enabled')" :show-feedback="false">
              <NSwitch v-model:value="form.enabled" />
            </NFormItem>
          </NGridItem>
        </NGrid>
        <NFormItem :label="t('pages.cron.form.description')" :show-feedback="false">
          <NInput
            v-model:value="form.description"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 3 }"
            :placeholder="t('pages.cron.form.descriptionPlaceholder')"
          />
        </NFormItem>

        <!-- 执行时间 -->
        <NDivider title-placement="left" style="margin: 0;">{{ t('pages.cron.modal.sections.schedule') }}</NDivider>
        <NTabs v-model:value="form.scheduleTab" type="segment" size="small">
          <NTabPane :name="'daily'" :tab="t('pages.cron.scheduleTabs.daily')">
            <NSpace vertical :size="12" style="margin-top: 12px;">
              <NGrid cols="2" :x-gap="12">
                <NGridItem>
                  <NFormItem :label="t('pages.cron.selectTime')" :show-feedback="false">
                    <NTimePicker
                      v-model:formatted-value="form.scheduleHour"
                      format="HH"
                      :actions="null"
                      style="width: 100%;"
                    />
                  </NFormItem>
                </NGridItem>
                <NGridItem>
                  <NFormItem :label="t('pages.cron.units.minutes')" :show-feedback="false">
                    <NTimePicker
                      v-model:formatted-value="form.scheduleMinute"
                      format="mm"
                      :actions="null"
                      style="width: 100%;"
                    />
                  </NFormItem>
                </NGridItem>
              </NGrid>
              <div>
                <NText depth="3" style="font-size: 12px;">{{ t('pages.cron.selectWeekdays') }}</NText>
                <NSpace :size="6" style="margin-top: 6px;">
                  <NButton
                    v-for="day in [1, 2, 3, 4, 5, 6, 7]"
                    :key="day"
                    size="small"
                    :type="isWeekdaySelected(day) ? 'primary' : 'default'"
                    round
                    @click="toggleWeekday(day)"
                  >
                    {{ t(`pages.cron.weekdayNames.${day}`) }}
                  </NButton>
                </NSpace>
              </div>
            </NSpace>
          </NTabPane>

          <NTabPane :name="'monthly'" :tab="t('pages.cron.scheduleTabs.monthly')">
            <NSpace vertical :size="12" style="margin-top: 12px;">
              <NGrid cols="2" :x-gap="12">
                <NGridItem>
                  <NFormItem :label="t('pages.cron.selectTime')" :show-feedback="false">
                    <NInputNumber
                      v-model:value="form.scheduleHour"
                      :min="0" :max="23"
                      :show-button="false"
                      placeholder="时 (0-23)"
                      style="width: 100%;"
                    />
                  </NFormItem>
                </NGridItem>
                <NGridItem>
                  <NFormItem :label="t('pages.cron.units.minutes')" :show-feedback="false">
                    <NInputNumber
                      v-model:value="form.scheduleMinute"
                      :min="0" :max="59"
                      :show-button="false"
                      placeholder="分 (0-59)"
                      style="width: 100%;"
                    />
                  </NFormItem>
                </NGridItem>
              </NGrid>
              <div>
                <NText depth="3" style="font-size: 12px;">选择日期</NText>
                <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px; max-width: 280px;">
                  <NButton
                    v-for="d in 31"
                    :key="d"
                    size="tiny"
                    :type="isMonthDaySelected(d) ? 'primary' : 'default'"
                    round
                    @click="toggleMonthDay(d)"
                    style="min-width: 36px;"
                  >
                    {{ d }}
                  </NButton>
                </div>
              </div>
            </NSpace>
          </NTabPane>

          <NTabPane :name="'interval'" :tab="t('pages.cron.scheduleTabs.interval')">
            <NSpace align="center" :size="8" style="margin-top: 12px;">
              <NText>每</NText>
              <NInputNumber
                v-model:value="form.everyValue"
                :min="1"
                :precision="0"
                :show-button="false"
                style="width: 80px;"
              />
              <NSelect
                v-model:value="form.everyUnit"
                :options="everyUnitOptions"
                style="width: 100px;"
              />
            </NSpace>
          </NTabPane>
        </NTabs>
        <NText depth="3" style="font-size: 12px;">{{ schedulePreviewText }}</NText>

        <!-- AI 指令 -->
        <NDivider title-placement="left" style="margin: 0;">
          <NSpace justify="space-between" align="center" :size="8" :wrap="false" style="width: 100%;">
            <span>{{ t('pages.cron.form.payloadText') }}</span>
          </NSpace>
        </NDivider>
        <div style="position: relative;">
          <NInput
            v-model:value="form.payloadText"
            type="textarea"
            :autosize="{ minRows: 3, maxRows: 6 }"
            :placeholder="t('pages.cron.form.payloadTextPlaceholders.agentTurn')"
          />
          <NButton
            size="tiny"
            type="primary"
            tertiary
            :loading="testingPrompt"
            style="position: absolute; top: 4px; right: 4px;"
            @click="handleTestPrompt"
          >
            <template #icon><span class="material-symbols-outlined" style="font-size: 14px;">play_arrow</span></template>
            {{ t('pages.cron.testPrompt') }}
          </NButton>
        </div>

        <!-- 通知 -->
        <NDivider title-placement="left" style="margin: 0;">{{ t('pages.cron.form.deliveryMode') }}</NDivider>
        <NSpace vertical :size="10">
          <NSwitch v-model:value="form.notifyEnabled" />
          <template v-if="form.notifyEnabled">
            <NGrid cols="1 s:2" responsive="screen" :x-gap="12">
              <NGridItem>
                <NFormItem :label="t('pages.cron.form.deliveryChannel')" :show-feedback="false">
                  <NSelect
                    v-model:value="form.deliveryChannel"
                    :options="deliveryChannelOptions"
                  />
                </NFormItem>
              </NGridItem>
              <NGridItem>
                <NFormItem :label="t('pages.cron.form.deliveryTo')" :show-feedback="false">
                  <NSelect
                    v-model:value="form.deliveryTo"
                    :options="deliveryTargetOptions"
                    filterable
                    tag
                    clearable
                    :placeholder="t('pages.cron.form.deliveryToPlaceholders.last')"
                  />
                </NFormItem>
              </NGridItem>
            </NGrid>
          </template>
        </NSpace>

        <!-- 高级设置 -->
        <NCollapse>
          <NCollapseItem :title="t('pages.cron.advancedSettings')" name="advanced">
            <NSpace vertical :size="10">
              <NGrid cols="1 s:2" responsive="screen" :x-gap="12">
                <NGridItem>
                  <NFormItem :label="t('pages.cron.form.sessionTarget')" :show-feedback="false">
                    <NSelect
                      v-model:value="form.sessionTarget"
                      :options="[
                        { label: t('pages.cron.form.sessionTargets.isolated'), value: 'isolated' },
                        { label: t('pages.cron.form.sessionTargets.main'), value: 'main' },
                      ]"
                    />
                  </NFormItem>
                </NGridItem>
                <NGridItem>
                  <NFormItem :label="t('pages.cron.form.wakeMode')" :show-feedback="false">
                    <NSelect
                      v-model:value="form.wakeMode"
                      :options="[
                        { label: t('pages.cron.form.wakeModes.nextHeartbeat'), value: 'next-heartbeat' },
                        { label: t('pages.cron.form.wakeModes.now'), value: 'now' },
                      ]"
                    />
                  </NFormItem>
                </NGridItem>
              </NGrid>
              <NGrid cols="1 s:2" responsive="screen" :x-gap="12">
                <NGridItem>
                  <NFormItem :label="t('pages.cron.form.modelOverride')" :show-feedback="false">
                    <NSelect
                      v-model:value="form.model"
                      :options="modelSelectOptions"
                      :loading="modelStore.loading"
                      filterable
                      tag
                      clearable
                      :placeholder="t('pages.cron.form.modelOverridePlaceholder')"
                    />
                  </NFormItem>
                </NGridItem>
                <NGridItem>
                  <NFormItem :label="t('pages.cron.form.timeoutSeconds')" :show-feedback="false">
                    <NInputNumber
                      v-model:value="form.timeoutSeconds"
                      :min="1"
                      :precision="0"
                      :show-button="false"
                      :placeholder="t('pages.cron.form.timeoutSecondsPlaceholder')"
                      style="width: 100%;"
                    />
                  </NFormItem>
                </NGridItem>
              </NGrid>
              <NFormItem :label="t('pages.cron.form.deleteAfterRun')" :show-feedback="false">
                <NSwitch v-model:value="form.deleteAfterRun" />
              </NFormItem>
              <NFormItem :label="t('pages.cron.form.timezone')" :show-feedback="false">
                <NInput v-model:value="form.cronTz" :placeholder="t('pages.cron.form.timezonePlaceholder')" />
              </NFormItem>
            </NSpace>
          </NCollapseItem>
        </NCollapse>
      </NSpace>

      <template #footer>
        <NSpace justify="end">
          <NButton @click="showModal = false">{{ t('common.cancel') }}</NButton>
          <NButton type="primary" :loading="cronStore.saving" @click="handleSubmit">
            {{ isEditing ? t('pages.cron.actions.saveChanges') : t('pages.cron.actions.createJob') }}
          </NButton>
        </NSpace>
      </template>
    </NModal>
```

**注意：** NTimePicker 的 formatted-value 与 NInputNumber 方案需要根据实际 Naive UI 版本行为调整。如果 NTimePicker 绑定整数不兼容，每日 Tab 中的时间输入改用两个 NInputNumber（0-23 小时、0-59 分钟），与每月 Tab 保持一致。上面的 template 中每日 Tab 已改用 NInputNumber 方案以保持一致性。

- [ ] **Step 2: 删除 previewPayload 相关代码**

删除 `previewPayload` computed 定义（line 572-580）。这个变量只被弹窗底部的 JSON 预览使用，已移除。

- [ ] **Step 3: 删除 scheduleKindOptions computed**

删除 `scheduleKindOptions` computed（line 122-126），因为不再使用 NSelect 选择 scheduleKind。

- [ ] **Step 4: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "feat(cron): rewrite modal template with visual schedule and simplified UI"
```

---

### Task 6: 添加弹窗样式

**Files:**
- Modify: `src/views/cron/CronPage.vue` (style section)

- [ ] **Step 1: 在 `<style scoped>` 区域添加弹窗相关样式**

在 `<style scoped>` 末尾追加：

```css
.cron-modal-section {
  margin-bottom: 16px;
}
.cron-modal-section:last-child {
  margin-bottom: 0;
}
.cron-schedule-preview {
  padding: 6px 12px;
  background: var(--bg-card);
  border-radius: 6px;
  font-size: 13px;
  color: var(--text-secondary);
}
```

- [ ] **Step 2: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "feat(cron): add styles for redesigned modal"
```

---

### Task 7: 类型检查和修复

**Files:**
- Modify: `src/views/cron/CronPage.vue` (script section - fix type errors)

- [ ] **Step 1: 运行类型检查**

```bash
cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -80
```

- [ ] **Step 2: 修复类型错误**

根据 vue-tsc 输出修复所有类型错误。常见问题：
- `scheduleTab` 类型不匹配 NTabs 的 v-model
- NTimePicker formatted-value 类型
- `CronUpsertParams` 类型缺少某些字段
- 未使用的变量/imports

逐一修复直到 `npx vue-tsc --noEmit` 通过。

- [ ] **Step 3: Commit**

```bash
git add src/views/cron/CronPage.vue
git commit -m "fix(cron): resolve type errors in redesigned modal"
```

---

### Task 8: 验证和手动测试

- [ ] **Step 1: 启动开发服务器**

```bash
cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npm run dev:all
```

- [ ] **Step 2: 验证创建流程**

在浏览器中：
1. 打开定时任务页面
2. 点击 "新建任务"
3. 验证弹窗显示正确的布局
4. 选择 "每日" Tab，设置时间，选择星期
5. 输入 AI 指令
6. 点击保存，验证任务创建成功

- [ ] **Step 3: 验证编辑流程**

1. 点击已有任务的编辑按钮
2. 验证弹窗正确回填所有字段
3. 验证调度 Tab 正确选择（每日/每月/间隔）
4. 验证时间和星期/日期正确回填
5. 修改并保存，验证更新成功

- [ ] **Step 4: 验证间隔 Tab**

1. 创建新任务
2. 选择 "间隔" Tab
3. 设置每 30 分钟
4. 保存并验证 schedule 正确

- [ ] **Step 5: 验证高级设置**

1. 展开高级设置
2. 修改会话目标、模型等
3. 保存并验证

- [ ] **Step 6: 验证测试指令按钮**

1. 输入 AI 指令
2. 点击 "测试指令"
3. 验证 toast 提示
4. 检查运行历史中是否出现测试任务

- [ ] **Step 7: 验证通知开关**

1. 关闭通知开关，验证渠道选择隐藏
2. 打开通知开关，验证渠道选择显示
3. 选择渠道和目标，保存验证

---

## Self-Review

**Spec coverage check:**
- [x] 调度可视化（每日/每月/间隔 Tab）→ Task 2 + Task 5
- [x] 星期按钮组 → Task 3 + Task 5
- [x] 日期按钮组 → Task 3 + Task 5
- [x] 中文预览 → Task 2 (schedulePreviewText)
- [x] 反向解析（编辑模式）→ Task 2 (parseCronToVisual + fillFormByJob)
- [x] 执行员工下拉框 → Task 1 (agentTeamOptions) + Task 5
- [x] 测试指令按钮 → Task 3 (handleTestPrompt) + Task 5
- [x] 通知简化 → Task 3 (notifyEnabled watch) + Task 5
- [x] 高级设置折叠 → Task 5 (NCollapse)
- [x] 移除 JSON 预览 → Task 5 Step 2
- [x] i18n 更新 → Task 4

**Placeholder scan:** No TBD/TODO found. All steps contain code or exact commands.

**Type consistency:** All function names and variable names are consistent across tasks.
