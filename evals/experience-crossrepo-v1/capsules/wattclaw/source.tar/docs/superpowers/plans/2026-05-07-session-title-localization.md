# Session Title Localization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将会话显示标题与 Gateway label 解耦，标题存本地 SQLite，消除重复标题导致 UUID 显示、刷新后缀、不必要列表刷新三个问题。

**Architecture:** `user_sessions.label` 字段语义从「Gateway label 同步」变为「本地显示标题」。后端合并 Gateway sessions + 本地标题后返回前端。前端不再直接调 `patchSession(label)`。

**Tech Stack:** Node.js/Express (后端), Vue 3 + TypeScript (前端), SQLite (better-sqlite3)

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `server/user-manager.js` | Modify | `trackSessionForUser` UPDATE 用 COALESCE |
| `server/index.js` | Modify | 新增 `getLocalSessionTitles`/`getAllSessionTitles` 函数；`/api/workspace/send` 增加 title 保存；`/api/rpc` sessions.list 合并标题；新增 `/api/workspace/rename-session` 端点 |
| `src/stores/workspace.ts` | Modify | `sendMessage` 传 title 参数；`forceStopStreaming` 移除 refresh；`loadAgentSessions` 移除 localLabels；`renameSession` 改走本地 API |

---

### Task 1: 后端 — trackSessionForUser 使用 COALESCE

**Files:**
- Modify: `server/user-manager.js:319-329`

- [ ] **Step 1: 修改 trackSessionForUser 的 UPDATE 语句**

将 `server/user-manager.js` 第 322 行的 UPDATE 语句从覆盖 label 改为 COALESCE：

```javascript
// 旧（第 322 行）：
db.prepare('UPDATE user_sessions SET updated_at = ?, agent_id = ?, label = ? WHERE id = ?').run(Date.now(), agentId || null, label || null, existing.id)

// 新：
db.prepare('UPDATE user_sessions SET updated_at = ?, agent_id = ?, label = COALESCE(label, ?) WHERE id = ?').run(Date.now(), agentId || null, label || null, existing.id)
```

只改这一个 SQL 语句，其他代码不变。

- [ ] **Step 2: 验证**

启动服务 `./restart.sh`，确认无报错。用 `curl` 测试：连续两次调 `trackSessionForUser` 同一个 session key，第一次传 label="你好"，第二次传 label="世界"，确认第二次调用后 label 仍为 "你好"（COALESCE 保留）。

- [ ] **Step 3: 提交**

```
feat(session): trackSessionForUser 使用 COALESCE 保留已有标题
```

---

### Task 2: 后端 — 新增 getLocalSessionTitles / getAllSessionTitles 函数

**Files:**
- Modify: `server/index.js`（在模块顶层，`getLocalSessionTitles` 放在 `getAllGatewayAgentIds` 附近）

- [ ] **Step 1: 在 server/index.js 模块顶层添加两个函数**

在 `server/index.js` 中找到现有的 `getCachedAllSessions` 函数附近（约第 245 行之后），添加：

```javascript
function getLocalSessionTitles(userId) {
  const rows = db.prepare('SELECT session_key, label FROM user_sessions WHERE user_id = ? AND label IS NOT NULL').all(userId)
  return new Map(rows.map(r => [r.session_key, r.label]))
}

function getAllSessionTitles() {
  const rows = db.prepare('SELECT session_key, label FROM user_sessions WHERE label IS NOT NULL').all()
  return new Map(rows.map(r => [r.session_key, r.label]))
}
```

- [ ] **Step 2: 验证**

启动服务确认无语法错误。

- [ ] **Step 3: 提交**

```
feat(session): 新增 getLocalSessionTitles / getAllSessionTitles 函数
```

---

### Task 3: 后端 — /api/workspace/send 增加 title 参数

**Files:**
- Modify: `server/index.js:2269-2291`

- [ ] **Step 1: 修改 /api/workspace/send handler**

将 `server/index.js` 第 2272 行从：

```javascript
const { sessionKey, message, idempotencyKey } = req.body
```

改为：

```javascript
const { sessionKey, message, idempotencyKey, title } = req.body
```

然后在 `await gateway.call('chat.send', ...)` 成功之后、`res.json(...)` 之前（约第 2285 行），添加标题保存和 Gateway label 设置：

```javascript
    // 保存显示标题到本地数据库
    if (title && sessionKey) {
      const parts = sessionKey.split(':')
      const agentId = parts.length >= 2 ? parts[1] : null
      trackSessionForUser(req.currentUser.id, sessionKey, agentId, title, null)
    }

    // 设置 Gateway label（fire-and-forget，title + timestamp 保证唯一）
    if (title && sessionKey) {
      const gatewayLabel = `${title}-${Date.now()}`
      gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
    }
```

确保这段代码在 `res.json({ ok: true, streamId })` 之前，但仍在 `try` 块内。

- [ ] **Step 2: 验证**

启动服务。用 curl 发送带 title 的请求：

```bash
curl -X POST http://localhost:3001/api/workspace/send \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"sessionKey":"agent:test-agent:abc123","message":"你好","idempotencyKey":"test1","title":"你好"}'
```

检查 SQLite 数据库 `user_sessions` 表，确认 label 字段为 "你好"。

- [ ] **Step 3: 提交**

```
feat(session): /api/workspace/send 支持 title 参数，保存到本地数据库
```

---

### Task 4: 后端 — /api/rpc sessions.list 合并本地标题

**Files:**
- Modify: `server/index.js:2385-2398`（非 admin）
- Modify: `server/index.js:2645-2656`（admin）

- [ ] **Step 1: 修改非 admin sessions.list**

将 `server/index.js` 第 2385-2398 行从：

```javascript
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        const allSessions = await getCachedAllSessions()
        const ownedSessions = filterOwnedSessions(allSessions)

        return res.json({
          ok: true,
          payload: {
            sessions: ownedSessions,
            total: ownedSessions.length,
            page: 1,
            limit: ownedSessions.length,
            hasMore: false
          }
        })
      }
```

改为：

```javascript
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        const allSessions = await getCachedAllSessions()
        const ownedSessions = filterOwnedSessions(allSessions)

        const localTitles = getLocalSessionTitles(req.currentUser.id)
        const sessionsWithTitles = ownedSessions.map(s => ({
          ...s,
          label: localTitles.get(s.key || s.sessionKey) || s.label || ''
        }))

        return res.json({
          ok: true,
          payload: {
            sessions: sessionsWithTitles,
            total: sessionsWithTitles.length,
            page: 1,
            limit: sessionsWithTitles.length,
            hasMore: false
          }
        })
      }
```

- [ ] **Step 2: 修改 admin sessions.list**

将 `server/index.js` 第 2645-2656 行从：

```javascript
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        const allSessions = await getCachedAllSessions()
        return res.json({
          ok: true,
          payload: {
            sessions: allSessions,
            total: allSessions.length,
            page: 1,
            limit: allSessions.length,
            hasMore: false
          }
        })
      }
```

改为：

```javascript
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        const allSessions = await getCachedAllSessions()

        const allTitles = getAllSessionTitles()
        const sessionsWithTitles = allSessions.map(s => ({
          ...s,
          label: allTitles.get(s.key || s.sessionKey) || s.label || ''
        }))

        return res.json({
          ok: true,
          payload: {
            sessions: sessionsWithTitles,
            total: sessionsWithTitles.length,
            page: 1,
            limit: sessionsWithTitles.length,
            hasMore: false
          }
        })
      }
```

- [ ] **Step 3: 验证**

启动服务。在前端打开在线对话页面，切换 agent，确认会话列表正常显示。检查浏览器 Network 面板中 `sessions.list` RPC 响应，确认 label 字段已包含本地标题。

- [ ] **Step 4: 提交**

```
feat(session): sessions.list 响应合并本地显示标题
```

---

### Task 5: 后端 — 新增 /api/workspace/rename-session 端点

**Files:**
- Modify: `server/index.js`（在 `/api/workspace/send` 附近添加）

- [ ] **Step 1: 添加新端点**

在 `server/index.js` 中 `/api/workspace/send` 端点之后，添加：

```javascript
// Rename session — updates local display title only
app.post('/api/workspace/rename-session', authMiddleware, async (req, res) => {
  try {
    const { sessionKey, label } = req.body
    if (!sessionKey || !label) {
      return res.status(400).json({ ok: false, error: 'sessionKey and label required' })
    }

    const row = db.prepare('SELECT id, user_id FROM user_sessions WHERE session_key = ?').get(sessionKey)
    if (!row || (row.user_id !== req.currentUser.id && req.currentUser.role !== 'admin')) {
      return res.status(403).json({ ok: false, error: 'Access denied' })
    }

    db.prepare('UPDATE user_sessions SET label = ? WHERE session_key = ?').run(label, sessionKey)
    res.json({ ok: true })
  } catch (err) {
    console.error('[Workspace] Rename error:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

注意：auth middleware 使用 `req.currentUser`，用户 ID 为 `req.currentUser.id`，admin 判断为 `req.currentUser.role === 'admin'`。

- [ ] **Step 2: 验证**

```bash
curl -X POST http://localhost:3001/api/workspace/rename-session \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"sessionKey":"agent:test-agent:abc123","label":"新标题"}'
```

检查数据库 label 已更新。

- [ ] **Step 3: 提交**

```
feat(session): 新增 /api/workspace/rename-session 端点
```

---

### Task 6: 前端 — sendMessage 传 title 参数给后端

**Files:**
- Modify: `src/stores/workspace.ts:547-558`（标题生成块）
- Modify: `src/stores/workspace.ts:594-598`（httpPost 调用）

- [ ] **Step 1: 修改标题生成块，用局部变量传递**

将 `src/stores/workspace.ts` 第 547-558 行从：

```typescript
    // Set title from first user message immediately (synchronous, before any await)
    if (activeSessionKey.value && !titleGeneratedKeys.has(activeSessionKey.value)) {
      titleGeneratedKeys.add(activeSessionKey.value)
      const title = text.length > 32 ? text.slice(0, 32) + '...' : text
      const agent = agents.value.find((a) => a.agentId === selectedAgentId.value)
      if (agent) {
        agent.sessions = agent.sessions.map((s) =>
          s.key === activeSessionKey.value ? { ...s, label: title } : s
        )
      }
      wsStore.rpc.patchSession({ sessionKey: activeSessionKey.value, label: title }).catch(() => {})
    }
```

改为：

```typescript
    // Set title from first user message immediately (synchronous, before any await)
    let titleToSend: string | undefined
    if (activeSessionKey.value && !titleGeneratedKeys.has(activeSessionKey.value)) {
      titleGeneratedKeys.add(activeSessionKey.value)
      const title = text.length > 32 ? text.slice(0, 32) + '...' : text
      titleToSend = title
      const agent = agents.value.find((a) => a.agentId === selectedAgentId.value)
      if (agent) {
        agent.sessions = agent.sessions.map((s) =>
          s.key === activeSessionKey.value ? { ...s, label: title } : s
        )
      }
    }
```

改动点：
1. 新增 `let titleToSend: string | undefined`
2. `titleToSend = title` 赋值给局部变量
3. **删除** `wsStore.rpc.patchSession(...)` 那行

- [ ] **Step 2: 修改 httpPost 调用，传递 title 参数**

将 `src/stores/workspace.ts` 第 594-598 行从：

```typescript
      const result = await httpPost('/api/workspace/send', {
        sessionKey: activeSessionKey.value!,
        message: text,
        idempotencyKey,
      }) as Record<string, unknown>
```

改为：

```typescript
      const result = await httpPost('/api/workspace/send', {
        sessionKey: activeSessionKey.value!,
        message: text,
        idempotencyKey,
        ...(titleToSend ? { title: titleToSend } : {}),
      }) as Record<string, unknown>
```

- [ ] **Step 3: 类型检查**

```bash
npx vue-tsc --noEmit
```

确认无类型错误。

- [ ] **Step 4: 提交**

```
feat(chat): sendMessage 通过后端 API 保存标题，不再直接调 patchSession
```

---

### Task 7: 前端 — forceStopStreaming 移除会话列表刷新

**Files:**
- Modify: `src/stores/workspace.ts:710-713`

- [ ] **Step 1: 删除 forceStopStreaming 中的刷新逻辑**

将 `src/stores/workspace.ts` 第 710-713 行从：

```typescript
    if (selectedAgentId.value) {
      invalidateSessionCache()
      loadAgentSessions(selectedAgentId.value)
    }
```

删除这 4 行（保留前面的闭合大括号 `}` 即可）。

- [ ] **Step 2: 检查是否还有其他对 invalidateSessionCache 的引用**

```bash
grep -rn 'invalidateSessionCache' src/
```

如果只在 workspace.ts 的其他位置使用（如 loadAgentSessions 内部），保留。如果 forceStopStreaming 是唯一调用者，该函数可以后续清理。

- [ ] **Step 3: 类型检查 + 提交**

```bash
npx vue-tsc --noEmit
```

```
fix(chat): 移除 agent 回复完成后的会话列表刷新
```

---

### Task 8: 前端 — loadAgentSessions 移除 localLabels 合并逻辑

**Files:**
- Modify: `src/stores/workspace.ts:380-386`

- [ ] **Step 1: 简化 loadAgentSessions**

将 `src/stores/workspace.ts` 第 380-386 行从：

```typescript
      const localLabels = new Map(agent.sessions.map((s) => [s.key, s.label]))
      agent.sessions = newSessions.map((s) => {
        if (!s.label && localLabels.get(s.key)) {
          return { ...s, label: localLabels.get(s.key) }
        }
        return s
      })
```

改为：

```typescript
      agent.sessions = newSessions
```

- [ ] **Step 2: 类型检查**

```bash
npx vue-tsc --noEmit
```

- [ ] **Step 3: 提交**

```
refactor(chat): loadAgentSessions 直接赋值，后端已合并标题
```

---

### Task 9: 前端 — renameSession 改走本地 API

**Files:**
- Modify: `src/stores/workspace.ts:1028-1039`

- [ ] **Step 1: 重写 renameSession 函数**

将 `src/stores/workspace.ts` 第 1028-1039 行从：

```typescript
  async function renameSession(sessionKey: string, label: string) {
    try {
      await wsStore.rpc.patchSession({ sessionKey, label })
      for (const agent of agents.value) {
        agent.sessions = agent.sessions.map(s =>
          s.key === sessionKey ? { ...s, label } : s
        )
      }
    } catch (error) {
      lastError.value = error instanceof Error ? error.message : String(error)
    }
  }
```

改为：

```typescript
  async function renameSession(sessionKey: string, label: string) {
    try {
      await httpPost('/api/workspace/rename-session', { sessionKey, label })
      const gatewayLabel = `${label}-${Date.now()}`
      wsStore.rpc.patchSession({ sessionKey, label: gatewayLabel }).catch(() => {})
      for (const agent of agents.value) {
        agent.sessions = agent.sessions.map(s =>
          s.key === sessionKey ? { ...s, label } : s
        )
      }
    } catch (error) {
      lastError.value = error instanceof Error ? error.message : String(error)
    }
  }
```

- [ ] **Step 2: 类型检查**

```bash
npx vue-tsc --noEmit
```

- [ ] **Step 3: 提交**

```
feat(chat): renameSession 改走本地 API，Gateway label 用 timestamp 保证唯一
```

---

### Task 10: 端到端验证

- [ ] **Step 1: 启动服务**

```bash
./restart.sh
```

- [ ] **Step 2: 测试重复标题**

1. 选择一个数字员工
2. 发送消息「你好」→ 确认左侧栏显示「你好」
3. 新建会话，再发「你好」→ 确认左侧栏两个会话都显示「你好」，无 UUID
4. 等待 agent 回复完成 → 确认会话列表无刷新闪烁

- [ ] **Step 3: 测试刷新保持**

1. 刷新页面（F5）
2. 确认两个会话标题仍为「你好」，无后缀

- [ ] **Step 4: 测试重命名**

1. 右键某个会话 → 重命名 → 输入「测试标题」
2. 确认标题立即更新
3. 刷新页面 → 确认新标题保持

- [ ] **Step 5: 测试切换 agent**

1. 切换到另一个数字员工
2. 确认会话列表正常加载，标题正确

- [ ] **Step 6: 最终提交（如有修复）**

如果验证过程中发现并修复了问题，提交修复。
