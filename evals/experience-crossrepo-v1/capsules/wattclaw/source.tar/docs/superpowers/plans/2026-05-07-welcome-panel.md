# Welcome Panel 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在在线对话空会话时显示欢迎面板，包含 Agent 自我介绍、功能标语和可点击的预设提示词按钮。

**Architecture:** 在 MessageList 的空状态区域替换为新的 WelcomePanel 组件。AgentTemplate 类型扩展 tagline + prompts 字段，22 个模板各配内容。点击提示词按钮填入 ChatInput，不自动发送。

**Tech Stack:** Vue 3 + TypeScript + Naive UI（仅 NText）, Pinia store

---

## File Structure

| Action | File | Responsibility |
|--------|------|----------------|
| Modify | `src/api/types/agent-team.ts` | AgentTemplate 加 tagline + prompts 字段 |
| Modify | `src/config/agent-templates.ts` | 22 个模板各加 tagline + prompts 数据 |
| Create | `src/views/workspace/WelcomePanel.vue` | 欢迎面板组件（头像、问候语、标语、提示词按钮） |
| Modify | `src/views/workspace/MessageList.vue` | 空状态引入 WelcomePanel |
| Modify | `src/stores/workspace.ts` | 新增 presetPrompt ref + setPresetPrompt 方法 |
| Modify | `src/views/workspace/ChatInput.vue` | watch presetPrompt 填入 textarea |

---

### Task 1: 扩展 AgentTemplate 类型

**Files:**
- Modify: `src/api/types/agent-team.ts:1-12`

- [ ] **Step 1: 在 AgentTemplate 接口中添加 tagline 和 prompts 字段**

在 `src/api/types/agent-team.ts` 的 `AgentTemplate` 接口中，在 `bootstrapMd?: string` 之后添加：

```typescript
export interface AgentTemplate {
  id: string
  category: string
  name: string
  avatar: string
  description: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  bootstrapMd?: string
  tagline: string       // 功能标语
  prompts: string[]     // 预设提示词（2-4 个）
}
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 报错指向 agent-templates.ts 中缺少 tagline/prompts 字段的模板定义（这是预期的，Task 2 修复）

- [ ] **Step 3: Commit**

```bash
git add src/api/types/agent-team.ts
git commit -m "feat(welcome-panel): add tagline and prompts fields to AgentTemplate"
```

---

### Task 2: 为 22 个模板添加 tagline + prompts 内容

**Files:**
- Modify: `src/config/agent-templates.ts:109-813`

- [ ] **Step 1: 在每个模板对象中添加 tagline 和 prompts 字段**

在 `src/config/agent-templates.ts` 中，为每个模板的 `userMd` 字段之后、闭合 `}` 之前添加 `tagline` 和 `prompts`。以下是全部 22 个模板的内容：

**编程开发（3 个）：**

code-assistant（约第 116 行）：
```typescript
tagline: '全栈编程、Bug 修复、架构设计，写代码的事交给我',
prompts: ['帮我写一个 REST API 接口', '这段代码有 Bug，帮我修复', '帮我重构这个函数，提升可读性'],
```

sql-expert（约第 143 行）：
```typescript
tagline: 'SQL 优化、数据建模、查询分析，让数据库飞起来',
prompts: ['帮我优化这个慢查询', '设计一个订单系统的表结构', '解释一下这个 SQL 的执行计划'],
```

code-reviewer（约第 166 行）：
```typescript
tagline: '代码质量审查，发现潜在问题和安全隐患',
prompts: ['帮我审查这段代码的安全问题', '这个函数的性能可以怎么优化', '帮我检查代码规范'],
```

**内容创作（3 个）：**

copywriter（约第 193 行）：
```typescript
tagline: '营销文案、产品描述、品牌故事，写出打动人心的文字',
prompts: ['帮我写一个产品上线的宣传文案', '给这个功能写一段吸引人的描述', '帮我写一封营销邮件'],
```

social-media（约第 216 行）：
```typescript
tagline: '内容策划、粉丝互动、账号运营，打造爆款内容',
prompts: ['帮我策划这周的抖音内容选题', '写一篇小红书种草笔记', '分析一下我们的账号数据'],
```

translator（约第 236 行）：
```typescript
tagline: '中英日韩多语言互译，专业准确不失韵味',
prompts: ['把这段中文翻译成英文', '帮我翻译这份技术文档', '这段英文翻译成中文，保持专业语气'],
```

**办公效率（3 个）：**

meeting-notes（约第 264 行）：
```typescript
tagline: '会议内容整理、关键决策提取、待办事项跟踪',
prompts: ['帮我整理一份会议纪要', '提取这段会议录音的关键决策', '根据这些要点生成会议报告'],
```

ppt-assistant（约第 285 行）：
```typescript
tagline: '演示文稿制作、内容大纲、设计建议，让汇报更出彩',
prompts: ['帮我做一个季度汇报的大纲', '写一份产品路演 PPT 的内容', '帮我优化这页 PPT 的文案'],
```

email-assistant（约第 306 行）：
```typescript
tagline: '商务邮件撰写、语气优化、多语言支持',
prompts: ['帮我写一封项目进度汇报邮件', '写一封婉拒客户需求的邮件', '帮我润色这封英文邮件'],
```

**数据分析（3 个）：**

data-analyst（约第 332 行）：
```typescript
tagline: '数据洞察、统计分析、决策建议，让数据说话',
prompts: ['分析一下最近一个月的用户增长趋势', '帮我做一份用户行为分析报告', '找出这些数据中的异常点'],
```

report-generator（约第 355 行）：
```typescript
tagline: '日报周报月报，自动生成结构化数据报表',
prompts: ['生成本周的数据运营报表', '帮我做一个销售数据对比表', '自动生成月度 KPI 完成情况'],
```

bi-dashboard（约第 377 行）：
```typescript
tagline: '数据看板设计、指标体系规划、可视化方案',
prompts: ['帮我设计一个运维监控看板', '规划一个管理层数据看板的指标', '设计一个实时销售大屏方案'],
```

**市场营销（3 个）：**

marketing-planner（约第 404 行）：
```typescript
tagline: '营销策略、活动策划、ROI 测算，让每一分钱花到位',
prompts: ['帮我策划一个线上推广活动', '制定下季度的营销策略', '测算一下这个营销方案的 ROI'],
```

competitor-analyst（约第 426 行）：
```typescript
tagline: '竞品追踪、对比分析、竞争策略，知己知彼',
prompts: ['帮我分析一下主要竞品的功能差异', '做一份竞品定价策略对比', '追踪最近一个月的竞品动态'],
```

seo-optimizer（约第 447 行）：
```typescript
tagline: 'SEO 审计、关键词策略、内容优化，提升搜索排名',
prompts: ['帮我做一次网站 SEO 审计', '规划一批目标关键词', '优化这篇文章的 SEO'],
```

**客户服务（2 个）：**

smart-cs（约第 474 行）：
```typescript
tagline: '客户咨询应答、常见问题处理、服务升级',
prompts: ['帮我回复这个客户的技术咨询', '整理一份产品常见问题 FAQ', '这个客户投诉怎么处理'],
```

after-sales（约第 496 行）：
```typescript
tagline: '售后技术支持、问题排查、远程协助',
prompts: ['帮我排查一个部署环境的问题', '写一份故障处理 SOP', '客户反馈性能差怎么排查'],
```

**人力资源（2 个）：**

recruiter（约第 524 行）：
```typescript
tagline: '简历筛选、面试设计、候选人评估',
prompts: ['帮我筛选这份简历的匹配度', '设计一个前端工程师的面试题', '写一份 Java 开发的岗位描述'],
```

training-advisor（约第 546 行）：
```typescript
tagline: '培训方案设计、学习路径规划、效果评估',
prompts: ['制定一个新员工入职培训计划', '设计一条前端技术学习路径', '评估一下上次培训的效果'],
```

**产品设计（2 个）：**

product-manager（约第 573 行）：
```typescript
tagline: '需求分析、PRD 编写、用户故事，让产品更懂用户',
prompts: ['帮我写一个功能的 PRD 文档', '把这个需求拆解成用户故事', '分析一下用户反馈中的高频需求'],
```

ux-designer（约第 595 行）：
```typescript
tagline: '用户体验设计、交互方案、界面优化建议',
prompts: ['帮我设计一个注册流程的交互方案', '优化这个表单的用户体验', '做一个信息架构分析'],
```

**项目管理（2 个）：**

project-manager（约第 622 行）：
```typescript
tagline: '项目规划、进度管理、风险识别，让项目按时交付',
prompts: ['帮我制定一个项目计划', '识别一下当前项目的风险点', '写一份项目进度周报'],
```

agile-coach（约第 644 行）：
```typescript
tagline: '敏捷实践指导、Scrum 落地、团队效能提升',
prompts: ['帮我们设计一个 Sprint 流程', '团队迭代不稳定怎么办', '写一份敏捷回顾会议的模板'],
```

**法律合规（2 个）：**

legal-advisor（约第 671 行）：
```typescript
tagline: '法律咨询、合同审查、风险预警',
prompts: ['帮我审查这份合同的条款', '这个方案有什么法律风险', '起草一份 NDA 保密协议'],
```

compliance-reviewer（约第 693 行）：
```typescript
tagline: '数据合规审查、隐私保护、合规整改方案',
prompts: ['帮我做一次数据处理合规检查', '审查这个功能是否符合个保法', '制定一份数据安全整改方案'],
```

**财务税务（2 个）：**

financial-analyst（约第 720 行）：
```typescript
tagline: '财务报表分析、预算管理、经营洞察',
prompts: ['分析一下本月的财务报表', '做一份季度预算执行报告', '帮我做成本结构分析'],
```

tax-advisor（约第 742 行）：
```typescript
tagline: '税务规划、申报辅导、合规节税',
prompts: ['帮我做一份税务规划方案', '高新技术企业能享受哪些税收优惠', '辅导一下本月的增值税申报'],
```

**招投标（2 个）：**

bidding-analyst（约第 769 行）：
```typescript
tagline: '招标信息分析、资质匹配、投标策略制定',
prompts: ['帮我评估这个招标项目的匹配度', '分析一下竞争对手的投标策略', '判断我们是否满足资质要求'],
```

bid-writer（约第 790 行）：
```typescript
tagline: '标书编写、技术方案、商务响应',
prompts: ['帮我写一份技术标方案', '标书的商务部分怎么写', '帮我整理公司的项目案例'],
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无类型错误

- [ ] **Step 3: Commit**

```bash
git add src/config/agent-templates.ts
git commit -m "feat(welcome-panel): add tagline and prompts for all 22 agent templates"
```

---

### Task 3: workspace store 添加 presetPrompt

**Files:**
- Modify: `src/stores/workspace.ts`

- [ ] **Step 1: 在 store 中添加 presetPrompt ref 和 setPresetPrompt 方法**

在 `src/stores/workspace.ts` 中：

1. 在 `activeStreamId` ref 声明之后（约第 250 行）添加：
```typescript
const presetPrompt = ref<string | null>(null)
```

2. 在 `cancelCurrentRequest` 函数之后添加新方法：
```typescript
function setPresetPrompt(text: string) {
  presetPrompt.value = text
}
```

3. 在 return 对象中添加导出（约第 1066 行 `selectedAgent,` 之后）：
```typescript
presetPrompt,
setPresetPrompt,
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无错误

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat(welcome-panel): add presetPrompt ref and setPresetPrompt to workspace store"
```

---

### Task 4: ChatInput 监听 presetPrompt

**Files:**
- Modify: `src/views/workspace/ChatInput.vue:1-35`

- [ ] **Step 1: 添加 watch presetPrompt 逻辑**

在 `src/views/workspace/ChatInput.vue` 中，在现有的 `watch(inputText, ...)` 之后（约第 35 行之后）添加：

```typescript
watch(() => workspaceStore.presetPrompt, (text) => {
  if (!text) return
  inputText.value = text
  presetPrompt.value = null
  nextTick(() => {
    if (textareaRef.value) {
      autoResize(textareaRef.value)
      textareaRef.value.focus()
    }
  })
})
```

同时确保在 import 行中 `nextTick` 已被导入（检查现有 import 行，如果已有则跳过）：
```typescript
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无错误

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/ChatInput.vue
git commit -m "feat(welcome-panel): ChatInput watches presetPrompt to fill textarea"
```

---

### Task 5: 创建 WelcomePanel 组件

**Files:**
- Create: `src/views/workspace/WelcomePanel.vue`

- [ ] **Step 1: 创建 WelcomePanel.vue**

创建 `src/views/workspace/WelcomePanel.vue`，完整内容如下：

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { NText } from 'naive-ui'
import { useWorkspaceStore } from '@/stores/workspace'
import { useAgentTeamStore } from '@/stores/agent-team'
import { getTemplateById } from '@/config/agent-templates'

const workspaceStore = useWorkspaceStore()
const agentTeamStore = useAgentTeamStore()

const agent = computed(() => workspaceStore.selectedAgent)

const templateData = computed(() => {
  if (!agent.value) return null
  const member = agentTeamStore.agentList.find(m => m.id === agent.value!.agentId)
  const tid = member?.templateId
  if (tid) {
    const tpl = getTemplateById(tid)
    if (tpl) {
      return {
        avatar: tpl.avatar,
        name: tpl.name,
        tagline: tpl.tagline,
        prompts: tpl.prompts,
      }
    }
  }
  return {
    avatar: agent.value.avatar || 'smart_toy',
    name: agent.value.name,
    tagline: member?.description || '我可以帮你完成各种任务',
    prompts: [] as string[],
  }
})

const greeting = computed(() => `Hi，我是${templateData.value?.name || 'AI 助手'}`)

function selectPrompt(text: string) {
  workspaceStore.setPresetPrompt(text)
}
</script>

<template>
  <div class="welcome-panel" v-if="templateData">
    <div class="wp-avatar">{{ templateData.avatar }}</div>
    <h2 class="wp-greeting">{{ greeting }}</h2>
    <p class="wp-tagline">{{ templateData.tagline }}</p>
    <div v-if="templateData.prompts.length" class="wp-prompts">
      <button
        v-for="(prompt, i) in templateData.prompts"
        :key="i"
        class="wp-prompt-btn"
        @click="selectPrompt(prompt)"
      >
        {{ prompt }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.welcome-panel {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  gap: 12px;
  user-select: none;
  padding: 24px;
}

.wp-avatar {
  font-size: 64px;
  line-height: 1;
  filter: drop-shadow(0 2px 8px rgba(67, 91, 168, 0.2));
}

.wp-greeting {
  font-size: 20px;
  font-weight: 600;
  color: var(--text);
  margin: 0;
}

.wp-tagline {
  font-size: 14px;
  color: var(--text-muted);
  margin: 0;
  text-align: center;
  max-width: 400px;
  line-height: 1.5;
}

.wp-prompts {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 12px;
  width: 100%;
  max-width: 420px;
}

.wp-prompt-btn {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  padding: 12px 16px;
  font-size: 14px;
  color: var(--text);
  text-align: left;
  cursor: pointer;
  transition: all 0.2s ease;
  line-height: 1.4;
}

.wp-prompt-btn:hover {
  border-color: var(--accent);
  background: rgba(67, 91, 168, 0.06);
}

[data-theme='dark'] .wp-prompt-btn:hover {
  background: rgba(100, 120, 200, 0.1);
}
</style>
```

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无错误

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/WelcomePanel.vue
git commit -m "feat(welcome-panel): create WelcomePanel component with avatar, greeting, prompts"
```

---

### Task 6: MessageList 空状态集成 WelcomePanel

**Files:**
- Modify: `src/views/workspace/MessageList.vue`

- [ ] **Step 1: 导入 WelcomePanel 组件**

在 `src/views/workspace/MessageList.vue` 的 import 区域（约第 10 行之后），添加：

```typescript
import WelcomePanel from './WelcomePanel.vue'
```

- [ ] **Step 2: 替换空状态区域**

找到 MessageList 模板中的空状态区域（约第 426-429 行）：

```html
    <!-- 空状态 -->
    <div v-else class="empty-messages">
      <NText depth="3">{{ t('pages.workspace.chat.emptyMessages') }}</NText>
    </div>
```

替换为：

```html
    <!-- 空状态 -->
    <WelcomePanel v-else />
```

- [ ] **Step 3: 可选 — 删除未使用的 empty-messages CSS**

在 MessageList 的 `<style scoped>` 中找到 `.empty-messages` 样式块（约第 886 行），删除：

```css
.empty-messages {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--text-muted);
  font-size: 14px;
}
```

- [ ] **Step 4: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无错误

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "feat(welcome-panel): integrate WelcomePanel into MessageList empty state"
```

---

### Task 7: 浏览器验证

- [ ] **Step 1: 启动开发服务器**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./start.sh`

- [ ] **Step 2: 验证空会话欢迎面板**

1. 登录后进入"在线对话"
2. 选中一个数字员工（如代码助手）
3. 确认显示：avatar emoji + "Hi，我是代码助手" + tagline + 3 个提示词按钮
4. 点击一个提示词按钮 → 文字应填入底部输入框 → 输入框聚焦
5. 发送消息后 → 欢迎面板消失，消息正常显示

- [ ] **Step 3: 验证无模板 Agent 的 fallback**

1. 选中一个用户自定义的 Agent（无 templateId）
2. 确认显示：smart_toy 图标 + "Hi，我是xxx" + description 作为 tagline
3. 不显示提示词按钮区域

- [ ] **Step 4: 验证深色模式**

1. 切换深色模式
2. 确认欢迎面板样式正常（文字颜色、背景、hover 效果）

- [ ] **Step 5: 验证不同模板**

1. 依次选择不同类别的数字员工
2. 确认每个模板的 tagline 和 prompts 内容正确

- [ ] **Step 6: Final commit**

```bash
git add -A
git commit -m "feat(welcome-panel): complete welcome panel with preset prompts for all templates"
```
