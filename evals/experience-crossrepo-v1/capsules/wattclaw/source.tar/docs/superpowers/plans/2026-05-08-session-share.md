# Session Sharing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Allow users to select chat messages and generate a public static HTML page shareable via link.

**Architecture:** Frontend adds a share button + message selection modal. Backend generates self-contained HTML files (using `markdown-it` for markdown rendering) and saves them to `data/shared/`. Express serves these files statically at `/shared/{id}.html`.

**Tech Stack:** Vue 3 + Naive UI (frontend), Express + markdown-it + crypto.randomUUID (backend), SQLite for share metadata tracking.

---

## File Structure

| File | Action | Purpose |
|------|--------|---------|
| `src/views/workspace/ChatHeader.vue` | Modify | Add share button |
| `src/views/workspace/components/ShareModal.vue` | Create | Message selection + link generation modal |
| `src/stores/workspace.ts` | Modify | Add `shareSession()` method |
| `src/i18n/messages/zh-CN.ts` | Modify | Add share-related i18n keys |
| `server/index.js` | Modify | Add `POST /api/share` endpoint + static serving |
| `server/share-generator.js` | Create | HTML generation logic |

---

### Task 1: Add i18n Keys

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts:2647-2652`

- [ ] **Step 1: Add share i18n keys after the `session` block**

In `src/i18n/messages/zh-CN.ts`, find the `session` block (line 2647) and add a `share` block after it (before the closing `},` of `workspace`):

```typescript
      share: {
        title: '分享会话',
        selectMessages: '选择要分享的消息',
        selectAll: '全选',
        deselectAll: '取消全选',
        selected: '已选择 {count} 条消息',
        generate: '生成链接',
        generating: '生成中...',
        linkReady: '链接已生成',
        copyLink: '复制链接',
        copied: '已复制',
        noMessages: '请先选择要分享的消息',
        shareFailed: '分享失败',
        disclaimer: '内容由 AI 生成，仅供参考',
        poweredBy: '由 WattClaw 生成',
      },
```

- [ ] **Step 2: Verify the i18n structure compiles**

Run: `npx vue-tsc --noEmit`
Expected: No type errors

- [ ] **Step 3: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat(share): add i18n keys for session sharing"
```

---

### Task 2: Add Share Button to ChatHeader

**Files:**
- Modify: `src/views/workspace/ChatHeader.vue:9-11,36-46`

- [ ] **Step 1: Add emit for share modal**

In `ChatHeader.vue`, update the `defineEmits` block (line 9) to add a `toggle-share` event:

```typescript
const emit = defineEmits<{
  (e: 'toggle-file-panel'): void
  (e: 'toggle-share'): void
}>()
```

- [ ] **Step 2: Add share button to template**

In the template, inside `div.header-right` (line 36), add a share button before the file panel button (before line 38):

```html
      <button class="file-panel-btn" @click="emit('toggle-share')" :title="t('pages.workspace.share.title')">
        <span class="material-symbols-outlined">share</span>
      </button>
```

- [ ] **Step 3: Verify the component compiles**

Run: `npx vue-tsc --noEmit`
Expected: No type errors

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/ChatHeader.vue
git commit -m "feat(share): add share button to chat header"
```

---

### Task 3: Create ShareModal Component

**Files:**
- Create: `src/views/workspace/components/ShareModal.vue`

- [ ] **Step 1: Create the ShareModal component**

Create `src/views/workspace/components/ShareModal.vue`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { NModal, NButton, NCheckbox, NIcon } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { ChatMessage } from '@/api/types'

const { t } = useI18n()

const props = defineProps<{
  visible: boolean
  messages: ChatMessage[]
  sessionLabel: string
}>()

const emit = defineEmits<{
  (e: 'update:visible', value: boolean): void
  (e: 'share', indices: number[]): void
}>()

const selectedIndices = ref<Set<number>>(new Set())
const shareUrl = ref<string | null>(null)
const loading = ref(false)
const copied = ref(false)

const displayMessages = computed(() =>
  props.messages
    .map((msg, index) => ({ msg, index }))
    .filter(({ msg }) => msg.role === 'user' || msg.role === 'assistant')
)

const allSelected = computed(() =>
  displayMessages.value.length > 0 &&
  displayMessages.value.every(({ index }) => selectedIndices.value.has(index))
)

function toggleSelect(index: number) {
  const next = new Set(selectedIndices.value)
  if (next.has(index)) {
    next.delete(index)
  } else {
    next.add(index)
  }
  selectedIndices.value = next
}

function toggleSelectAll() {
  if (allSelected.value) {
    selectedIndices.value = new Set()
  } else {
    selectedIndices.value = new Set(displayMessages.value.map(({ index }) => index))
  }
}

async function handleShare() {
  if (selectedIndices.value.size === 0) return
  loading.value = true
  try {
    emit('share', Array.from(selectedIndices.value))
  } finally {
    loading.value = false
  }
}

async function handleCopyLink() {
  if (!shareUrl.value) return
  const fullUrl = window.location.origin + shareUrl.value
  try {
    await navigator.clipboard.writeText(fullUrl)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = fullUrl
    ta.style.cssText = 'position:fixed;left:-9999px'
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    document.body.removeChild(ta)
  }
  copied.value = true
  setTimeout(() => { copied.value = false }, 2000)
}

function handleClose() {
  emit('update:visible', false)
  // Reset state when closing
  setTimeout(() => {
    selectedIndices.value = new Set()
    shareUrl.value = null
    copied.value = false
  }, 300)
}

function setShareUrl(url: string) {
  shareUrl.value = url
}

defineExpose({ setShareUrl })
</script>

<template>
  <NModal
    :show="visible"
    @update:show="(val: boolean) => !val && handleClose()"
    preset="card"
    :title="t('pages.workspace.share.title')"
    style="width: 600px; max-height: 80vh"
    :bordered="false"
    :segmented="{ content: true, footer: true }"
  >
    <div class="share-modal-content">
      <div v-if="!shareUrl" class="message-list">
        <div
          v-for="{ msg, index } in displayMessages"
          :key="index"
          class="share-message-row"
          :class="msg.role"
          @click="toggleSelect(index)"
        >
          <NCheckbox
            :checked="selectedIndices.has(index)"
            @update:checked="toggleSelect(index)"
          />
          <div class="message-bubble" :class="msg.role">
            <div class="message-content">{{ msg.content }}</div>
          </div>
        </div>
        <div v-if="displayMessages.length === 0" class="empty-state">
          {{ t('pages.workspace.share.noMessages') }}
        </div>
      </div>

      <div v-else class="share-result">
        <div class="share-link-box">
          <input
            type="text"
            :value="shareUrl"
            readonly
            class="share-link-input"
          />
          <NButton type="primary" @click="handleCopyLink">
            {{ copied ? t('pages.workspace.share.copied') : t('pages.workspace.share.copyLink') }}
          </NButton>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="share-modal-footer" v-if="!shareUrl">
        <div class="footer-left">
          <NButton size="small" @click="toggleSelectAll">
            {{ allSelected ? t('pages.workspace.share.deselectAll') : t('pages.workspace.share.selectAll') }}
          </NButton>
          <span class="selected-count">
            {{ t('pages.workspace.share.selected', { count: selectedIndices.size }) }}
          </span>
        </div>
        <NButton
          type="primary"
          :disabled="selectedIndices.size === 0"
          :loading="loading"
          @click="handleShare"
        >
          {{ t('pages.workspace.share.generate') }}
        </NButton>
      </div>
    </template>
  </NModal>
</template>

<style scoped>
.share-modal-content {
  max-height: 50vh;
  overflow-y: auto;
}

.message-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.share-message-row {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: background .15s;
}

.share-message-row:hover {
  background: var(--bg-hover);
}

.message-bubble {
  flex: 1;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 13px;
  line-height: 1.5;
  max-height: 120px;
  overflow: hidden;
  position: relative;
}

.message-bubble.user {
  background: var(--accent-bg);
  color: var(--accent-text);
  margin-left: auto;
  max-width: 80%;
}

.message-bubble.assistant {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
}

.message-content {
  white-space: pre-wrap;
  word-break: break-word;
}

.message-bubble::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 24px;
  background: linear-gradient(transparent, var(--bg-card));
  pointer-events: none;
}

.message-bubble.user::after {
  background: linear-gradient(transparent, var(--accent-bg));
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: var(--text-muted);
}

.share-result {
  padding: 20px 0;
}

.share-link-box {
  display: flex;
  gap: 8px;
  align-items: center;
}

.share-link-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background: var(--bg);
  color: var(--text);
  font-size: 13px;
  outline: none;
}

.share-modal-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.footer-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.selected-count {
  font-size: 13px;
  color: var(--text-muted);
}
</style>
```

- [ ] **Step 2: Verify the component compiles**

Run: `npx vue-tsc --noEmit`
Expected: No type errors

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/components/ShareModal.vue
git commit -m "feat(share): create ShareModal component"
```

---

### Task 4: Add shareSession to Workspace Store

**Files:**
- Modify: `src/stores/workspace.ts`

- [ ] **Step 1: Add shareSession method**

In `src/stores/workspace.ts`, find the `renameSession` method (around line 1040) and add a `shareSession` method after it:

```typescript
async function shareSession(messageIndices: number[]): Promise<string> {
  if (!activeSessionKey.value) throw new Error('No active session')
  const data = await httpPost('/api/workspace/share', {
    sessionKey: activeSessionKey.value,
    messageIndices,
    title: activeSession.value?.label || '',
  }) as { url: string }
  return data.url
}
```

- [ ] **Step 2: Export the new method**

In the return statement of the store (around line 1055-1093), add `shareSession` to the exported members.

- [ ] **Step 3: Verify compilation**

Run: `npx vue-tsc --noEmit`
Expected: No type errors

- [ ] **Step 4: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat(share): add shareSession method to workspace store"
```

---

### Task 5: Wire ShareModal into WorkspacePage

**Files:**
- Modify: `src/views/workspace/WorkspacePage.vue`

- [ ] **Step 1: Import and wire up ShareModal**

In `WorkspacePage.vue`:

1. Import `ShareModal` from `./components/ShareModal.vue`
2. Add `showShareModal` ref
3. Add `shareModalRef` ref
4. Add `handleShare` function that calls `workspaceStore.shareSession()` and sets the URL on the modal
5. Add `<ShareModal>` component to the template
6. Handle the `toggle-share` event from `ChatHeader`

The relevant additions:

```typescript
// In script setup
import ShareModal from './components/ShareModal.vue'

const showShareModal = ref(false)
const shareModalRef = ref<InstanceType<typeof ShareModal> | null>(null)

async function handleShare(indices: number[]) {
  try {
    const url = await workspaceStore.shareSession(indices)
    shareModalRef.value?.setShareUrl(url)
  } catch (err) {
    console.error('[Share] Failed:', err)
  }
}
```

```html
<!-- In template, add ShareModal component -->
<ShareModal
  ref="shareModalRef"
  v-model:visible="showShareModal"
  :messages="workspaceStore.messages"
  :session-label="workspaceStore.activeSession?.label || ''"
  @share="handleShare"
/>

<!-- Update ChatHeader to handle toggle-share -->
<ChatHeader
  @toggle-file-panel="showFilePanel = !showFilePanel"
  @toggle-share="showShareModal = true"
/>
```

- [ ] **Step 2: Verify compilation**

Run: `npx vue-tsc --noEmit`
Expected: No type errors

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/WorkspacePage.vue
git commit -m "feat(share): wire ShareModal into workspace page"
```

---

### Task 6: Create HTML Generator

**Files:**
- Create: `server/share-generator.js`

- [ ] **Step 1: Create the share generator module**

Create `server/share-generator.js`:

```javascript
const markdownIt = require('markdown-it')

const md = markdownIt({
  html: false,
  linkify: true,
  typographer: true,
  breaks: true,
})

/**
 * Generate a self-contained HTML file for a shared session.
 * @param {object} options
 * @param {string} options.title - Session title
 * @param {Array} options.messages - Filtered messages to include
 * @param {string} options.id - Share ID
 * @returns {string} Complete HTML string
 */
function generateShareHtml({ title, messages, id }) {
  const now = new Date()
  const dateStr = `${now.getFullYear()} 年 ${now.getMonth() + 1} 月 ${now.getDate()} 日`

  const renderedMessages = messages
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .map(m => {
      const contentHtml = m.role === 'assistant'
        ? md.render(m.content || '')
        : escapeHtml(m.content || '')

      const filesHtml = m.files && m.files.length > 0
        ? `<div class="files">${m.files.map(f => `
          <div class="file-card">
            <span class="material-symbols-outlined">description</span>
            <span class="file-name">${escapeHtml(f.name)}</span>
            <span class="file-size">${formatSize(f.size)}</span>
          </div>`).join('')}</div>`
        : ''

      return `
      <div class="message ${m.role}">
        <div class="bubble">
          <div class="content">${contentHtml}</div>
          ${filesHtml}
        </div>
      </div>`
    })
    .join('\n')

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)} - WattClaw</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #f5f5f5;
      color: #1a1a1a;
      line-height: 1.6;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    header {
      margin-bottom: 32px;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    header h1 {
      font-size: 24px;
      font-weight: 600;
      margin-bottom: 8px;
      color: #1a1a1a;
    }
    header .meta {
      font-size: 13px;
      color: #888;
    }
    .messages {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .message {
      display: flex;
    }
    .message.user {
      justify-content: flex-end;
    }
    .message.assistant {
      justify-content: flex-start;
    }
    .bubble {
      max-width: 80%;
      padding: 12px 16px;
      border-radius: 12px;
      font-size: 14px;
      line-height: 1.6;
      word-break: break-word;
    }
    .message.user .bubble {
      background: #e3f2fd;
      color: #1565c0;
      border-bottom-right-radius: 4px;
    }
    .message.assistant .bubble {
      background: #fff;
      border: 1px solid #e0e0e0;
      border-bottom-left-radius: 4px;
    }
    .content { white-space: pre-wrap; }
    .content h1, .content h2, .content h3, .content h4 {
      margin: 16px 0 8px;
      font-weight: 600;
    }
    .content h1 { font-size: 20px; }
    .content h2 { font-size: 18px; }
    .content h3 { font-size: 16px; }
    .content p { margin: 8px 0; }
    .content ul, .content ol { padding-left: 20px; margin: 8px 0; }
    .content li { margin: 4px 0; }
    .content code {
      background: #f0f0f0;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 13px;
      font-family: 'SF Mono', Monaco, Consolas, monospace;
    }
    .content pre {
      background: #1e1e1e;
      color: #d4d4d4;
      padding: 16px;
      border-radius: 8px;
      overflow-x: auto;
      margin: 12px 0;
    }
    .content pre code {
      background: none;
      padding: 0;
      color: inherit;
    }
    .content table {
      border-collapse: collapse;
      width: 100%;
      margin: 12px 0;
    }
    .content th, .content td {
      border: 1px solid #e0e0e0;
      padding: 8px 12px;
      text-align: left;
    }
    .content th {
      background: #f5f5f5;
      font-weight: 600;
    }
    .content a {
      color: #1976d2;
      text-decoration: none;
    }
    .content a:hover {
      text-decoration: underline;
    }
    .content blockquote {
      border-left: 3px solid #e0e0e0;
      padding-left: 12px;
      margin: 12px 0;
      color: #666;
    }
    .content img {
      max-width: 100%;
      border-radius: 8px;
    }
    .files {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 8px;
    }
    .file-card {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 10px;
      background: #f0f0f0;
      border-radius: 6px;
      font-size: 12px;
    }
    .file-card .material-symbols-outlined {
      font-size: 16px;
      color: #666;
    }
    .file-name {
      font-weight: 500;
    }
    .file-size {
      color: #888;
    }
    footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e0e0e0;
      text-align: center;
      font-size: 12px;
      color: #888;
    }
    @media (prefers-color-scheme: dark) {
      body { background: #1a1a1a; color: #e0e0e0; }
      header { border-bottom-color: #333; }
      header h1 { color: #e0e0e0; }
      .message.assistant .bubble {
        background: #2a2a2a;
        border-color: #333;
      }
      .message.user .bubble {
        background: #1a3a5c;
        color: #90caf9;
      }
      .content code { background: #333; }
      .content pre { background: #0d0d0d; }
      .content th { background: #2a2a2a; }
      .content th, .content td { border-color: #333; }
      .content a { color: #64b5f6; }
      .content blockquote { border-left-color: #444; color: #999; }
      .file-card { background: #333; }
      .file-card .material-symbols-outlined { color: #999; }
      footer { border-top-color: #333; }
    }
    @media (max-width: 640px) {
      .container { padding: 20px 12px; }
      .bubble { max-width: 90%; }
      header h1 { font-size: 20px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>${escapeHtml(title)}</h1>
      <div class="meta">${dateStr} • 内容由 AI 生成，仅供参考</div>
    </header>
    <div class="messages">
      ${renderedMessages}
    </div>
    <footer>由 WattClaw 生成</footer>
  </div>
</body>
</html>`
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function formatSize(bytes) {
  if (!bytes) return ''
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

module.exports = { generateShareHtml }
```

- [ ] **Step 2: Verify the module loads**

Run: `node -e "const { generateShareHtml } = require('./server/share-generator'); console.log(typeof generateShareHtml)"`
Expected: `function`

- [ ] **Step 3: Commit**

```bash
git add server/share-generator.js
git commit -m "feat(share): create HTML generator for shared sessions"
```

---

### Task 7: Add Share API Endpoint

**Files:**
- Modify: `server/index.js:2813` (after rename-session endpoint)
- Modify: `server/index.js:5273` (before SPA fallback)

- [ ] **Step 1: Add import for share generator**

At the top of `server/index.js`, after the existing `require` statements (around line 10), add:

```javascript
const { generateShareHtml } = require('./share-generator')
```

- [ ] **Step 2: Create shared directory on startup**

After the existing directory setup (around line 110-115), add:

```javascript
const sharedDir = join(__dirname, '..', 'data', 'shared')
fs.mkdirSync(sharedDir, { recursive: true })
```

- [ ] **Step 3: Add static serving for /shared BEFORE SPA fallback**

Before the `if (hasDist)` block (line 5273), add:

```javascript
// Serve shared session pages (public, no auth)
app.use('/shared', express.static(sharedDir))
```

- [ ] **Step 4: Add POST /api/workspace/share endpoint**

After the rename-session endpoint (after line 2813), add:

```javascript
// Share session — generates a static HTML file
app.post('/api/workspace/share', authMiddleware, async (req, res) => {
  try {
    const { sessionKey, messageIndices, title } = req.body
    if (!sessionKey || !Array.isArray(messageIndices)) {
      return res.status(400).json({ ok: false, error: 'sessionKey and messageIndices required' })
    }

    // Verify session ownership
    const row = db.prepare('SELECT id, user_id FROM user_sessions WHERE session_key = ?').get(sessionKey)
    if (!row || (row.user_id !== req.currentUser.id && req.currentUser.role !== 'admin')) {
      return res.status(403).json({ ok: false, error: 'Access denied' })
    }

    // Fetch transcript from gateway
    let messages = []
    try {
      const historyMethods = ['chat.history', 'sessions.history', 'session.history']
      for (const method of historyMethods) {
        try {
          const result = await gateway.call(method, { key: sessionKey, sessionKey, limit: 500 })
          if (Array.isArray(result)) {
            messages = result
            break
          }
          if (result?.messages) {
            messages = result.messages
            break
          }
          if (result?.transcript) {
            messages = result.transcript
            break
          }
        } catch { /* try next method */ }
      }
    } catch (err) {
      console.error('[Share] Failed to fetch transcript:', err)
    }

    // Filter by indices
    const filtered = messageIndices
      .filter(i => i >= 0 && i < messages.length)
      .map(i => messages[i])

    if (filtered.length === 0) {
      return res.status(400).json({ ok: false, error: 'No valid messages selected' })
    }

    // Generate share ID and HTML
    const shareId = crypto.randomUUID().replace(/-/g, '').slice(0, 12)
    const sessionTitle = title || '分享的会话'
    const html = generateShareHtml({ title: sessionTitle, messages: filtered, id: shareId })

    // Save to file
    const filePath = join(sharedDir, `${shareId}.html`)
    fs.writeFileSync(filePath, html, 'utf-8')

    res.json({ ok: true, url: `/shared/${shareId}.html`, id: shareId })
  } catch (err) {
    console.error('[Share] Error:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 5: Verify the server starts**

Run: `npm run dev:server` (or check for syntax errors)
Expected: Server starts without errors

- [ ] **Step 6: Commit**

```bash
git add server/index.js server/share-generator.js
git commit -m "feat(share): add share API endpoint and static serving"
```

---

### Task 8: End-to-End Verification

- [ ] **Step 1: Start the dev server**

Run: `npm run dev:all`
Expected: Both frontend and backend start

- [ ] **Step 2: Test the share flow**

1. Open the workspace page
2. Select an agent and start a conversation (or use existing)
3. Click the share button in the chat header
4. Verify the ShareModal opens and shows messages
5. Select some messages
6. Click "生成链接"
7. Verify the link is displayed
8. Click "复制链接"
9. Open the link in a new tab
10. Verify the shared page renders correctly with markdown

- [ ] **Step 3: Verify dark mode**

1. Toggle system to dark mode
2. Refresh the shared page
3. Verify dark theme applies

- [ ] **Step 4: Commit final state**

```bash
git add -A
git commit -m "feat(share): complete session sharing feature"
```
