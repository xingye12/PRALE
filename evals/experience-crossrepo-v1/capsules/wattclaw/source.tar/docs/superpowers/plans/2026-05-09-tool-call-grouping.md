# 工具调用分组折叠 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将聊天界面中连续的工具调用分组到一个可折叠容器中，减少视觉刷屏。

**Architecture:** 在 MessageList.vue 的 `unifiedTimeline` computed 和模板之间增加一层 `groupedTimeline` computed，将连续的 tool 条目合并为 `ToolGroupEntry`。新建 `ToolGroupCard.vue` 组件渲染折叠容器。不改变 store 数据结构和交织算法。

**Tech Stack:** Vue 3 Composition API, TypeScript, Naive UI

---

## File Structure

| 文件 | 操作 | 职责 |
|------|------|------|
| `src/views/workspace/components/ToolGroupCard.vue` | 新建 | 工具分组折叠容器组件 |
| `src/views/workspace/MessageList.vue` | 修改 | 新增 groupedTimeline computed + 模板改造 |
| `src/i18n/messages/zh-CN.ts` | 修改 | 新增工具分组相关 i18n key |

---

### Task 1: 创建 ToolGroupCard.vue 组件

**Files:**
- Create: `src/views/workspace/components/ToolGroupCard.vue`

- [ ] **Step 1: 创建组件文件**

```vue
<script setup lang="ts">
import { ref, watch, computed } from 'vue'
import type { AgentActivity } from '@/stores/workspace'
import type { ChatMessage } from '@/api/types'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps<{
  tools: AgentActivity[]
  historyMessages?: ChatMessage[]
  isActive: boolean
}>()

const expanded = ref(false)

// 当所有工具完成时自动折叠
watch(() => props.isActive, (active) => {
  if (!active) expanded.value = false
})

const toolCount = computed(() => {
  if (props.tools.length) return props.tools.length
  return props.historyMessages?.length ?? 0
})

const statusText = computed(() => {
  if (props.isActive) return t('pages.workspace.chat.toolGroupRunning')
  return t('pages.workspace.chat.toolGroupDone')
})

// 展开状态下，哪些工具详情被展开
const expandedTools = ref(new Set<string>())

function toggleTool(id: string) {
  const s = new Set(expandedTools.value)
  if (s.has(id)) s.delete(id)
  else s.add(id)
  expandedTools.value = s
}

function truncateJson(raw: string | null | undefined, max = 300): string {
  if (!raw) return ''
  return raw.length > max ? raw.slice(0, max) + '...' : raw
}
</script>

<template>
  <div class="tool-group-card" :class="{ 'is-active': isActive }">
    <!-- Header -->
    <div class="tool-group-header" @click="expanded = !expanded">
      <span class="tool-group-arrow">{{ expanded ? '▼' : '▶' }}</span>
      <span class="tool-group-icon">🔧</span>
      <span class="tool-group-title">{{ t('pages.workspace.chat.toolGroupTitle') }}</span>
      <span class="tool-group-count">{{ toolCount }}</span>
      <span v-if="isActive" class="streaming-pulse"></span>
      <span class="tool-group-status" :class="{ active: isActive }">{{ statusText }}</span>
    </div>

    <!-- Expanded: tool list -->
    <div v-if="expanded" class="tool-group-body">
      <!-- Streaming activities -->
      <template v-if="tools.length">
        <div
          v-for="tool in tools"
          :key="tool.id"
          class="tool-group-item"
        >
          <div class="tool-item-header" @click="toggleTool(tool.id)">
            <span class="tool-item-icon">🔧</span>
            <span class="tool-item-name">{{ tool.toolName || 'tool' }}</span>
            <span v-if="tool.done" class="tool-item-done">✓</span>
            <span v-else class="streaming-pulse"></span>
            <span class="tool-item-toggle">{{ expandedTools.has(tool.id) ? '▼' : '▶' }}</span>
          </div>
          <div v-if="expandedTools.has(tool.id)" class="tool-item-detail">
            <div v-if="tool.toolArgs" class="activity-section">
              <div class="activity-section-label">▸ {{ t('pages.workspace.chat.arguments') }}</div>
              <pre class="activity-pre">{{ truncateJson(tool.toolArgs) }}</pre>
            </div>
            <div v-if="tool.toolPartial" class="activity-section">
              <div class="activity-section-label">▸ Partial</div>
              <pre class="activity-pre">{{ truncateJson(tool.toolPartial) }}</pre>
            </div>
            <div v-if="tool.toolResult" class="activity-section" :class="{ 'is-error': tool.toolIsError }">
              <div class="activity-section-label">▸ {{ t('pages.workspace.chat.result') }}</div>
              <pre class="activity-pre">{{ truncateJson(tool.toolResult) }}</pre>
            </div>
          </div>
        </div>
      </template>

      <!-- History tool messages -->
      <template v-if="historyMessages?.length">
        <div
          v-for="(msg, idx) in historyMessages"
          :key="msg.id || idx"
          class="tool-group-item"
        >
          <div class="tool-item-header" @click="toggleTool(msg.id || `hist-${idx}`)">
            <span class="tool-item-icon">🔧</span>
            <span class="tool-item-name">{{ msg.toolName || t('pages.workspace.chat.toolFallback') }}</span>
            <span v-if="msg.isError" class="tool-item-error">✗</span>
            <span v-else class="tool-item-done">✓</span>
            <span class="tool-item-toggle">{{ expandedTools.has(msg.id || `hist-${idx}`) ? '▼' : '▶' }}</span>
          </div>
          <div v-if="expandedTools.has(msg.id || `hist-${idx}`) && msg.content" class="tool-item-detail">
            <div class="activity-section" :class="{ 'is-error': msg.isError }">
              <div class="activity-section-label">▸ {{ t('pages.workspace.chat.result') }}</div>
              <pre class="activity-pre">{{ truncateJson(msg.content) }}</pre>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.tool-group-card {
  border: 1px solid var(--border-color, rgba(0,0,0,.08));
  border-radius: 10px;
  overflow: hidden;
  background: var(--bg-surface, #fafafa);
  animation: msg-in .2s ease;
}

[data-theme='dark'] .tool-group-card {
  border-color: rgba(255,255,255,.08);
}

.tool-group-card.is-active {
  border-color: var(--accent-bg-strong, rgba(91,124,250,.25));
  background: var(--accent-bg, rgba(91,124,250,.06));
}

.tool-group-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  cursor: pointer;
  user-select: none;
  font-size: 13px;
  background: var(--bg-surface, #f5f5f5);
  transition: background .15s;
}

.tool-group-card.is-active .tool-group-header {
  background: var(--accent-bg, rgba(91,124,250,.08));
}

.tool-group-header:hover {
  background: var(--bg-hover, rgba(0,0,0,.04));
}

.tool-group-arrow {
  font-size: 10px;
  color: var(--text-muted);
  transition: transform .2s;
}

.tool-group-icon {
  font-size: 14px;
}

.tool-group-title {
  font-weight: 500;
  color: var(--text);
}

.tool-group-count {
  background: var(--border-color, rgba(0,0,0,.08));
  color: var(--text-muted);
  font-size: 11px;
  padding: 1px 8px;
  border-radius: 10px;
  font-weight: 500;
}

.tool-group-status {
  font-size: 11px;
  color: var(--text-muted);
  margin-left: auto;
}

.tool-group-status.active {
  color: var(--accent, #5b7cfa);
}

.tool-group-body {
  border-top: 1px solid var(--border-color, rgba(0,0,0,.06));
  padding: 4px 0;
}

[data-theme='dark'] .tool-group-body {
  border-top-color: rgba(255,255,255,.06);
}

.tool-group-item {
  /* each tool row */
}

.tool-item-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  font-size: 12px;
  cursor: pointer;
  transition: background .1s;
}

.tool-item-header:hover {
  background: var(--bg-hover, rgba(0,0,0,.03));
}

.tool-item-icon {
  font-size: 12px;
  flex-shrink: 0;
}

.tool-item-name {
  font-family: "SF Mono", ui-monospace, monospace;
  font-weight: 600;
  color: var(--text);
}

.tool-item-done {
  font-size: 11px;
  color: #2e7d32;
  margin-left: auto;
}

[data-theme='dark'] .tool-item-done {
  color: #81c784;
}

.tool-item-error {
  font-size: 11px;
  color: var(--error, #c62828);
  margin-left: auto;
}

.tool-item-toggle {
  font-size: 9px;
  color: var(--text-muted);
  flex-shrink: 0;
}

.tool-item-detail {
  padding: 4px 14px 8px;
}

.activity-section {
  margin-bottom: 6px;
}

.activity-section:last-child {
  margin-bottom: 0;
}

.activity-section.is-error {
  border-left: 3px solid var(--error, #c62828);
  padding-left: 8px;
}

.activity-section-label {
  font-size: 11px;
  font-weight: 600;
  color: var(--text-muted);
  margin-bottom: 4px;
}

.activity-pre {
  font-size: 11px;
  font-family: "SF Mono", ui-monospace, monospace;
  background: var(--bg-code, #f6f8fa);
  border-radius: 4px;
  padding: 6px 8px;
  max-height: 250px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0;
  color: var(--text);
}

.streaming-pulse {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent, #5b7cfa);
  animation: pulse-glow 1.4s ease-in-out infinite;
  flex-shrink: 0;
}

@keyframes pulse-glow {
  0%, 100% { opacity: .3; }
  50% { opacity: 1; }
}

@keyframes msg-in {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
```

- [ ] **Step 2: 验证组件无语法错误**

Run: `npx vue-tsc --noEmit 2>&1 | head -20`

Expected: 无 ToolGroupCard 相关错误（可能有 MessageList 中未 import 的警告，这是正常的，Task 2 会修复）

- [ ] **Step 3: Commit**

```bash
git add src/views/workspace/components/ToolGroupCard.vue
git commit -m "feat(chat): add ToolGroupCard component for collapsible tool call grouping"
```

---

### Task 2: 修改 MessageList.vue — 新增分组 computed + 模板改造

**Files:**
- Modify: `src/views/workspace/MessageList.vue`

这是核心改动。分为 5 个步骤：import 组件、新增类型定义、新增 groupedTimeline computed、替换 displayedItems 数据源、改造模板。

- [ ] **Step 2a: 在 import 区域添加 ToolGroupCard**

在 MessageList.vue 的第 9 行 `import ToolCallCard` 后面添加：

```typescript
import ToolGroupCard from './components/ToolGroupCard.vue'
```

- [ ] **Step 2b: 新增 ToolGroupEntry 类型和 groupedTimeline computed**

在 `type UnifiedEntry = TimelineEntry | ActivityEntry`（第 154 行）之后添加类型定义和 computed：

```typescript
// ── Tool grouping ──
interface ToolGroupEntry {
  _key: string
  type: 'tool-group'
  source: 'activity' | 'history'
  activities: AgentActivity[]
  messages: ProcessedMessage[]
  isActive: boolean
}

type GroupedEntry = UnifiedEntry | ToolGroupEntry

const groupedTimeline = computed<GroupedEntry[]>(() => {
  const items = displayedItems.value
  const result: GroupedEntry[] = []
  let pendingTools: { activities: AgentActivity[]; messages: ProcessedMessage[] } = { activities: [], messages: [] }

  function flushPendingTools() {
    const acts = pendingTools.activities
    const msgs = pendingTools.messages
    if (acts.length === 0 && msgs.length === 0) return

    if (acts.length > 0) {
      result.push({
        _key: 'tg-' + acts[0]!.id,
        type: 'tool-group',
        source: 'activity',
        activities: [...acts],
        messages: [],
        isActive: acts.some(a => !a.done),
      })
    }
    if (msgs.length > 0) {
      result.push({
        _key: 'tg-' + msgs[0]!._key,
        type: 'tool-group',
        source: 'history',
        activities: [],
        messages: [...msgs],
        isActive: false,
      })
    }
    pendingTools = { activities: [], messages: [] }
  }

  for (const entry of items) {
    if (entry.type === 'activity' && entry.act.type === 'tool') {
      pendingTools.activities.push(entry.act)
    } else if (entry.type === 'message' && entry.msg.role === 'tool') {
      pendingTools.messages.push(entry.msg)
    } else {
      flushPendingTools()
      result.push(entry)
    }
  }
  flushPendingTools()

  return result
})
```

- [ ] **Step 2c: 替换 displayedItems 为 groupedTimeline**

将第 308 行的 `v-for="entry in displayedItems"` 改为 `v-for="entry in groupedTimeline"`。

同时更新 `hasMore` computed（第 25 行）中的引用：

将 `displayedItems.value` 相关逻辑改为基于 `unifiedTimeline.value` 判断（displayedItems 仍是分页基础，groupedTimeline 基于 displayedItems 分组后提供渲染数据）。`hasMore` 不需要改，因为它直接用 `displayCount < unifiedTimeline.value.length`。

- [ ] **Step 2d: 在模板中添加 tool-group 分支**

在 `<!-- ── Activity entries ── -->` 的 `<template v-else-if="entry.type === 'activity'">` 之前，添加 `tool-group` 分支。同时将 activity 中的 tool 类型渲染移除（因为 tool 已被分组消费），只保留 thinking 和 command_output：

```html
          <!-- ── Tool group entries ── -->
          <template v-else-if="entry.type === 'tool-group'">
            <div class="msg-row is-assistant is-activity is-tool-group">
              <div class="msg-role assistant">
                <img v-if="isImageAvatar(assistantAvatar)" :src="assistantAvatar" :alt="workspaceStore.selectedAgent?.name || 'Assistant'" />
                <span v-else-if="assistantAvatar">{{ assistantAvatar }}</span>
                <span v-else class="material-symbols-outlined">smart_toy</span>
              </div>
              <div class="msg-content-wrap">
                <ToolGroupCard
                  :tools="entry.activities"
                  :history-messages="entry.messages"
                  :is-active="entry.isActive"
                />
              </div>
            </div>
          </template>

          <!-- ── Activity entries (thinking + command_output only) ── -->
          <template v-else-if="entry.type === 'activity'">
            <!-- 只保留 thinking 和 command_output，tool 已被 tool-group 消费 -->
            <div v-if="entry.act.type !== 'tool'" class="msg-row is-assistant is-activity">
              <div class="msg-role assistant">
                <img v-if="isImageAvatar(assistantAvatar)" :src="assistantAvatar" :alt="workspaceStore.selectedAgent?.name || 'Assistant'" />
                <span v-else-if="assistantAvatar">{{ assistantAvatar }}</span>
                <span v-else class="material-symbols-outlined">smart_toy</span>
              </div>
              <div class="msg-content-wrap">
                <div
                  class="activity-card"
                  :class="[`is-${entry.act.type}`, { 'is-active': !entry.act.done }]"
                >
                  <!-- Thinking card -->
                  <template v-if="entry.act.type === 'thinking'">
                    <div class="activity-header" @click="toggleActivity(entry.act.id)">
                      <span class="activity-icon">🧠</span>
                      <span class="activity-title">{{ entry.act.done ? '已思考' : '思考中...' }}</span>
                      <span v-if="!entry.act.done" class="streaming-pulse"></span>
                      <span class="activity-toggle">{{ expandedActivities.has(entry.act.id) ? '▼' : '▶' }}</span>
                    </div>
                    <div v-if="expandedActivities.has(entry.act.id) && entry.act.text" class="activity-body">
                      <div class="activity-pre">{{ entry.act.text }}</div>
                    </div>
                  </template>

                  <!-- Command output card -->
                  <template v-else-if="entry.act.type === 'command_output'">
                    <div class="activity-header" @click="toggleActivity(entry.act.id)">
                      <span class="activity-icon">⬛</span>
                      <span class="activity-title">stdout/stderr</span>
                      <span v-if="!entry.act.done" class="streaming-pulse"></span>
                      <span class="activity-toggle">{{ expandedActivities.has(entry.act.id) ? '▼' : '▶' }}</span>
                    </div>
                    <div v-if="expandedActivities.has(entry.act.id) && entry.act.output" class="activity-body">
                      <pre class="activity-pre">{{ entry.act.output }}</pre>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </template>
```

- [ ] **Step 2e: 移除历史消息中独立的 tool 渲染**

当前第 374-380 行的工具消息独立渲染（`v-else-if="entry.msg.role === 'tool'"`）已被 `tool-group` 分支消费，需要删除这段代码：

```html
<!-- 删除这整段 -->
              <!-- 工具消息 -->
              <div v-else-if="entry.msg.role === 'tool'" class="msg-row is-tool">
                <ToolCallCard
                  :name="entry.msg.toolName || t('pages.workspace.chat.toolFallback')"
                  :result="entry.msg.content"
                  :is-error="entry.msg.isError"
                />
              </div>
```

- [ ] **Step 2f: 添加工具分组行样式**

在 `<style scoped>` 中添加：

```css
/* ── Tool group rows ── */
.msg-row.is-tool-group {
  padding: 6px 12px;
}

.msg-row.is-tool-group .msg-content-wrap {
  max-width: 70%;
}
```

- [ ] **Step 2g: 运行类型检查**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`

Expected: 无错误。如果有 ToolCallCard 未使用的 import 警告，移除 `import ToolCallCard` 行（第 9 行）。

- [ ] **Step 2h: Commit**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "feat(chat): group consecutive tool calls into collapsible containers"
```

---

### Task 3: 添加 i18n key

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`

- [ ] **Step 3a: 在 chat 区域添加工具分组相关 key**

在 `zh-CN.ts` 的 `chat` 对象中（约第 2684 行 `rateLimitedRemark` 之后）添加：

```typescript
        toolGroupTitle: '工具调用',
        toolGroupRunning: '运行中...',
        toolGroupDone: '全部已完成 ✓',
```

- [ ] **Step 3b: 验证 i18n key 被正确引用**

Run: `grep -n 'toolGroupTitle\|toolGroupRunning\|toolGroupDone' src/views/workspace/components/ToolGroupCard.vue`

Expected: 3 行匹配，分别是 `t('pages.workspace.chat.toolGroupTitle')`、`t('pages.workspace.chat.toolGroupRunning')`、`t('pages.workspace.chat.toolGroupDone')`。

- [ ] **Step 3c: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat(i18n): add tool group collapsible container strings"
```

---

### Task 4: 浏览器验证

- [ ] **Step 4a: 启动开发服务器**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./restart.sh`

- [ ] **Step 4b: 功能验证清单**

在浏览器中打开 http://localhost:3000，登录后进入工作台，选择一个数字员工进行对话，触发多轮工具调用：

1. **流式分组** — 发送需要工具调用的消息，观察工具是否从第 1 个开始就出现在折叠容器中
2. **自动折叠** — 所有工具完成后，容器自动折叠
3. **展开/折叠** — 点击 header 展开，看到每个工具名称；点击某个工具展开详情
4. **消息分隔** — 如果 agent 在工具之间发送了文本消息，工具应分成两个独立组
5. **历史消息** — 切换到一个有历史工具调用的会话，验证历史 tool 消息也被分组
6. **单工具** — 只触发 1 个工具调用时，仍显示折叠容器
7. **深色模式** — 切换深色模式，验证样式正常
8. **thinking 不受影响** — 思考过程仍然独立显示

- [ ] **Step 4c: 修复发现的问题**

如果验证中发现任何问题，修复后追加 commit。

---

## Self-Review

1. **Spec coverage:**
   - 分组算法 (groupedTimeline) → Task 2b ✓
   - 流式兼容 (computed 自动重算) → Task 2b ✓
   - ToolGroupCard 组件 → Task 1 ✓
   - 历史消息 tool 分组 → Task 2b（history 分支）+ Task 2e ✓
   - 折叠/展开交互 → Task 1 ✓
   - 运行中视觉 → Task 1 ✓
   - 自动折叠 → Task 1（watch isActive）✓
   - thinking/command_output 不受影响 → Task 2d ✓
   - i18n → Task 3 ✓

2. **Placeholder scan:** 无 TBD/TODO/placeholder。

3. **Type consistency:**
   - `ToolGroupEntry` 定义了 `activities: AgentActivity[]` 和 `messages: ProcessedMessage[]`，与 ToolGroupCard 的 `tools: AgentActivity[]` 和 `historyMessages?: ChatMessage[]` props 对应
   - `GroupedEntry = UnifiedEntry | ToolGroupEntry` 覆盖所有模板分支
   - `truncateJson` 函数在 ToolGroupCard 中定义，不依赖 MessageList
