# 未读消息通知功能实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在在线对话中，当数字员工回复消息后，实现侧边栏红点提醒、会话/员工置顶和未读红点标记。

**Architecture:** 在 workspace store 中新增 activityTimestamps（排序）、unreadMap（红点）、sidebarNotified（侧边栏红点）三个响应式状态。通过 DefaultLayout.vue 中的全局 WebSocket 事件订阅捕获 lifecycle end 事件，不依赖 WorkspacePage 生命周期。UI 层用 computed 派生排序和红点状态。

**Tech Stack:** Vue 3 Composition API, Pinia, Naive UI NMenu

**验证方式:** 本项目无测试框架，通过 `npx vue-tsc --noEmit` 类型检查 + 浏览器手动验证。

---

## Task 1: 提取 extractSessionKey 为共享工具函数

**Files:**
- Create: `src/utils/event-helpers.ts`
- Modify: `src/composables/useEventStream.ts:1-18`

**背景:** `extractSessionKey` 目前定义在 `useEventStream.ts` 中，DefaultLayout 也需要用它。提取为共享工具函数。

- [ ] **Step 1: 创建 `src/utils/event-helpers.ts`**

从 `useEventStream.ts` 第 7-18 行提取 `extractSessionKey` 函数，并新增 `isLifecycleEndEvent` 函数：

```typescript
/**
 * 从 SSE payload 中提取 sessionKey
 */
export function extractSessionKey(payload: unknown): string {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return ''
  const row = payload as Record<string, unknown>
  if (typeof row.sessionKey === 'string') return row.sessionKey
  if (typeof row.key === 'string') return row.key
  if (row.session && typeof row.session === 'object' && !Array.isArray(row.session)) {
    const session = row.session as Record<string, unknown>
    if (typeof session.key === 'string') return session.key
    if (typeof session.sessionKey === 'string') return session.sessionKey
  }
  return ''
}

/**
 * 判断事件是否为 lifecycle end（agent 完成回复）
 */
export function isLifecycleEndEvent(event: string, payload: unknown): boolean {
  const normalized = event.trim().toLowerCase()
  if (normalized === 'agent.done') return true
  if (normalized !== 'agent') return false
  const row = payload as Record<string, unknown> | null
  if (!row || typeof row !== 'object') return false
  const stream = typeof row.stream === 'string' ? row.stream.trim().toLowerCase() : ''
  if (stream !== 'lifecycle') return false
  const data = typeof row.data === 'object' && row.data !== null ? row.data as Record<string, unknown> : null
  if (!data) return false
  const phase = typeof data.phase === 'string' ? data.phase.trim().toLowerCase() : ''
  return phase === 'end' || phase === 'stop' || phase === 'completed' || phase === 'error'
}
```

- [ ] **Step 2: 修改 `src/composables/useEventStream.ts`**

删除第 7-18 行的本地 `extractSessionKey` 函数，改为从工具文件导入：

```typescript
// 在文件顶部 import 区新增
import { extractSessionKey } from '@/utils/event-helpers'

// 删除本地 function extractSessionKey(payload: unknown): string { ... } 整个函数
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误

- [ ] **Step 4: 提交**

```bash
git add src/utils/event-helpers.ts src/composables/useEventStream.ts
git commit -m "refactor: extract extractSessionKey and isLifecycleEndEvent to shared utils"
```

---

## Task 2: workspace store 新增通知状态和核心函数

**Files:**
- Modify: `src/stores/workspace.ts:1-15` (import)
- Modify: `src/stores/workspace.ts:285-299` (状态声明区)
- Modify: `src/stores/workspace.ts:520-531` (selectSession 函数)
- Modify: `src/stores/workspace.ts:1140-1178` (return 导出)

- [ ] **Step 1: 新增 import**

在 `src/stores/workspace.ts` 顶部 import 区（第 1 行之后）新增：

```typescript
import { useRouter } from 'vue-router'
```

在已有的工具导入行之后新增：

```typescript
import { extractSessionKey, isLifecycleEndEvent } from '@/utils/event-helpers'
```

注意：`extractSessionKey` 在 workspace.ts 中已有一个本地版本（用于 handleEvent），需要替换为从 `@/utils/event-helpers` 导入。先搜索确认 workspace.ts 中是否有本地 `extractSessionKey`：

如果 workspace.ts 中有本地 `extractSessionKey` 函数定义，删除它并改为 `import { extractSessionKey } from '@/utils/event-helpers'`。如果没有，只添加 `isLifecycleEndEvent` 的导入。

- [ ] **Step 2: 新增响应式状态**

在 `src/stores/workspace.ts` 的 `defineStore` 回调内，`rateLimitedModels` 声明之后（约第 286 行后），新增：

```typescript
  // ── Notification state ──
  const activityTimestamps = ref<Map<string, number>>(new Map())
  const unreadMap = ref<Map<string, number>>(new Map())
  const sidebarNotified = ref<Set<string>>(new Set())

  const router = useRouter()
```

- [ ] **Step 3: 实现 handleNotification 和路由 watch**

在 `selectSession` 函数之前（约第 519 行前），新增：

```typescript
  function handleNotification(sessionKey: string) {
    if (!sessionKey) return

    const isWorkspaceRoute = router.currentRoute.value.name === 'Workspace'
    const isActiveSession = sessionKey === activeSessionKey.value

    // 置顶：所有消息都更新活动时间戳
    activityTimestamps.value = new Map(activityTimestamps.value).set(sessionKey, Date.now())

    // 红点：仅非活跃会话 或 用户不在工作台页面
    if (!isActiveSession || !isWorkspaceRoute) {
      const prev = unreadMap.value.get(sessionKey) || 0
      unreadMap.value = new Map(unreadMap.value).set(sessionKey, prev + 1)
      sidebarNotified.value = new Set(sidebarNotified.value).add(sessionKey)
    }
  }

  function clearSidebarNotification() {
    sidebarNotified.value = new Set()
  }

  // 进入工作台时清除侧边栏红点（用路由 watch，不依赖 onMounted）
  watch(() => router.currentRoute.value.name, (name) => {
    if (name === 'Workspace') {
      clearSidebarNotification()
    }
  })

  // 暴露给 UI 的只读接口
  const hasSidebarNotification = computed(() => sidebarNotified.value.size > 0)

  function isSessionUnread(sessionKey: string): boolean {
    return unreadMap.value.has(sessionKey)
  }

  function hasAgentUnread(agentId: string): boolean {
    for (const [key] of unreadMap.value) {
      if (key.startsWith(`agent:${agentId}:`)) return true
    }
    return false
  }

  function getSessionActivityTs(sessionKey: string): number {
    return activityTimestamps.value.get(sessionKey) || 0
  }
```

- [ ] **Step 4: 在 selectSession 中清除 unreadMap**

在 `selectSession` 函数开头（第 521 行 `activeSessionKey.value = sessionKey` 之后），新增：

```typescript
    // 清除该会话的未读状态
    const newUnread = new Map(unreadMap.value)
    newUnread.delete(sessionKey)
    unreadMap.value = newUnread
```

- [ ] **Step 5: 在 return 中导出新增接口**

在 `return {}` 块中（约第 1140 行），在 `shareSession,` 之后新增：

```typescript
    handleNotification,
    clearSidebarNotification,
    hasSidebarNotification,
    isSessionUnread,
    hasAgentUnread,
    getSessionActivityTs,
```

- [ ] **Step 6: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误

- [ ] **Step 7: 提交**

```bash
git add src/stores/workspace.ts
git commit -m "feat(notification): add notification state and core logic to workspace store"
```

---

## Task 3: DefaultLayout 全局通知事件订阅

**Files:**
- Modify: `src/layouts/DefaultLayout.vue:1-17`

- [ ] **Step 1: 修改 DefaultLayout.vue**

完整替换 `<script setup>` 部分：

```vue
<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { NLayout, NLayoutSider, NLayoutHeader, NLayoutContent } from 'naive-ui'
import AppHeader from '@/components/layout/AppHeader.vue'
import AppSidebar from '@/components/layout/AppSidebar.vue'
import { useWebSocketStore } from '@/stores/websocket'
import { useWorkspaceStore } from '@/stores/workspace'
import { extractSessionKey, isLifecycleEndEvent } from '@/utils/event-helpers'

const collapsed = ref(false)
const wsStore = useWebSocketStore()
const workspaceStore = useWorkspaceStore()
let notificationCleanup: (() => void) | null = null

onMounted(() => {
  wsStore.connect()

  notificationCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as { event: string; payload: unknown }
    const payload = rpcEvent.payload as Record<string, unknown>
    if (isLifecycleEndEvent(rpcEvent.event, payload)) {
      const sessionKey = extractSessionKey(payload)
      workspaceStore.handleNotification(sessionKey)
    }
  })
})

onUnmounted(() => {
  notificationCleanup?.()
  wsStore.disconnect()
})
</script>
```

- [ ] **Step 2: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误

- [ ] **Step 3: 提交**

```bash
git add src/layouts/DefaultLayout.vue
git commit -m "feat(notification): add global notification listener in DefaultLayout"
```

---

## Task 4: 侧边栏菜单红点（AppSidebar.vue）

**Files:**
- Modify: `src/components/layout/AppSidebar.vue:1-77` (script)
- Modify: `src/components/layout/AppSidebar.vue:79-105` (template)
- Modify: `src/components/layout/AppSidebar.vue:107-241` (style)

**背景:** NMenu 的菜单项通过 `renderIcon` 函数渲染图标。需要在"在线对话"（路由名 `Workspace`，图标 `RocketOutline`）的图标右上角叠加一个红色小圆点。`renderIcon` 返回一个渲染函数，可以用 `h('span', ...)` 包裹图标和红点。

- [ ] **Step 1: 修改 AppSidebar.vue script 部分**

在 import 区新增：

```typescript
import { useWorkspaceStore } from '@/stores/workspace'
```

在 `const authStore = useAuthStore()` 之后新增：

```typescript
const workspaceStore = useWorkspaceStore()
```

修改 `renderIcon` 函数，增加红点支持。将第 51-54 行的 `renderIcon` 替换为：

```typescript
function renderIcon(iconName: string, showBadge = false) {
  const mIcon = materialIconMap[iconName] || 'question_mark'
  return () => {
    const icon = h('span', { class: 'material-symbols-outlined', style: { fontSize: '20px' } }, { default: () => mIcon })
    if (!showBadge) return icon
    return h('span', { class: 'menu-icon-wrapper' }, [
      icon,
      h('span', { class: 'notification-badge' }),
    ])
  }
}
```

修改 `menuOptions` computed，在 map 中增加 icon 调用参数。将第 66 行的 `icon: child.meta?.icon ? renderIcon(child.meta.icon as string) : undefined,` 替换为：

```typescript
      icon: child.meta?.icon
        ? renderIcon(
            child.meta.icon as string,
            (child.name as string) === 'Workspace' && workspaceStore.hasSidebarNotification,
          )
        : undefined,
```

- [ ] **Step 2: 新增红点 CSS**

在 `<style scoped>` 末尾（`</style>` 之前）新增：

```css
.menu-icon-wrapper {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.notification-badge {
  position: absolute;
  top: -4px;
  right: -6px;
  width: 8px;
  height: 8px;
  background: #f44336;
  border-radius: 50%;
  border: 1.5px solid var(--bg-card, #fff);
}
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误

- [ ] **Step 4: 浏览器验证**

1. 启动开发服务器 `./start.sh`
2. 打开工作台，选一个数字员工发送消息
3. 等待回复完成，确认侧边栏"在线对话"菜单项无红点（因为在工作台页面）
4. 切换到其他页面（如首页）
5. 再切回工作台发消息、等待回复、切走
6. 由于离开工作台后全局监听仍然工作，等待新消息后侧边栏应出现红点

- [ ] **Step 5: 提交**

```bash
git add src/components/layout/AppSidebar.vue
git commit -m "feat(notification): add sidebar badge on Workspace menu item"
```

---

## Task 5: WorkspaceSidebar 红点和置顶

**Files:**
- Modify: `src/views/workspace/WorkspaceSidebar.vue:1-104` (script)
- Modify: `src/views/workspace/WorkspaceSidebar.vue:106-199` (template)
- Modify: `src/views/workspace/WorkspaceSidebar.vue` (style)

**背景:** WorkspaceSidebar 渲染数字员工列表和会话列表。需要：
1. 新增 `sortedAgents` computed，按未读/活动时间排序
2. 每个会话条目显示未读红点
3. 每个数字员工条目显示未读红点
4. 会话列表按活动时间排序

- [ ] **Step 1: 在 script 中新增排序 computed**

在 `handleSessionAction` 函数之后（`</script>` 之前），新增：

```typescript
const sortedAgents = computed(() => {
  const agents = workspaceStore.filteredAgents
  if (!agents.length) return agents

  return [...agents].sort((a, b) => {
    const aUnread = workspaceStore.hasAgentUnread(a.agentId)
    const bUnread = workspaceStore.hasAgentUnread(b.agentId)
    if (aUnread !== bUnread) return aUnread ? -1 : 1

    // 都有未读或都没有，按最新活动时间排序
    let aTs = 0
    let bTs = 0
    for (const s of a.sessions) {
      const ts = workspaceStore.getSessionActivityTs(s.key)
      if (ts > aTs) aTs = ts
    }
    for (const s of b.sessions) {
      const ts = workspaceStore.getSessionActivityTs(s.key)
      if (ts > bTs) bTs = ts
    }
    return bTs - aTs
  })
})

function sortedSessions(sessions: Session[]): Session[] {
  return [...sessions].sort((a, b) => {
    const aTs = workspaceStore.getSessionActivityTs(a.key)
    const bTs = workspaceStore.getSessionActivityTs(b.key)
    if (aTs && bTs) return bTs - aTs
    if (aTs) return -1
    if (bTs) return 1
    // fallback 到原始顺序
    return 0
  })
}
```

- [ ] **Step 2: 修改模板 — agent 列表使用 sortedAgents**

将模板中第 143 行的 `v-for="(agent, index) in workspaceStore.filteredAgents"` 替换为：

```html
        <template v-for="(agent, index) in sortedAgents" :key="agent.agentId">
```

- [ ] **Step 3: 修改模板 — agent 条目增加未读红点**

在第 159 行 `<div class="agent-name">` 之后，`agent.name` 之后，新增红点标记：

将：
```html
<div class="agent-name">{{ agent.name }}</div>
```

替换为：
```html
<div class="agent-name">{{ agent.name }}<span v-if="workspaceStore.hasAgentUnread(agent.agentId)" class="unread-dot" /></div>
```

- [ ] **Step 4: 修改模板 — 会话列表使用 sortedSessions**

将第 173 行的 `v-for="session in agent.sessions"` 替换为：

```html
                  v-for="session in sortedSessions(agent.sessions)"
```

- [ ] **Step 5: 修改模板 — 会话条目增加未读红点**

在第 179-185 行的 `<div class="session-label">` 内，在 `{{ getSessionLabel(session) }}` 之后新增红点：

将：
```html
                        {{ getSessionLabel(session) }}
```

替换为：
```html
                        {{ getSessionLabel(session) }}<span v-if="workspaceStore.isSessionUnread(session.key)" class="unread-dot" />
```

- [ ] **Step 6: 新增红点 CSS**

在 `<style scoped>` 末尾新增：

```css
.unread-dot {
  display: inline-block;
  width: 6px;
  height: 6px;
  background: #f44336;
  border-radius: 50%;
  margin-left: 6px;
  vertical-align: middle;
  flex-shrink: 0;
}
```

- [ ] **Step 7: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误

- [ ] **Step 8: 浏览器验证**

1. 打开工作台，选择数字员工 A 发消息并等待回复
2. 回复后，该会话应该仍然在最顶部
3. 切换到数字员工 A 的另一个会话
4. 再发一条消息给 A 的第一个会话（通过另一个浏览器或直接用 API）
5. 确认：A 的会话列表中第一个会话有红点，且排到最顶部
6. 确认：A 的数字员工条目名称旁有红点，且排到列表最顶部
7. 点击该会话，确认红点消失

- [ ] **Step 9: 提交**

```bash
git add src/views/workspace/WorkspaceSidebar.vue
git commit -m "feat(notification): add unread dots and sort-by-activity in WorkspaceSidebar"
```

---

## Task 6: 端到端场景验证

**Files:** 无修改，纯验证

- [ ] **Step 1: 验证场景 1 — 侧边栏红点**

1. 在工作台发消息并等待回复
2. 切换到首页（"数字员工"页面）
3. 在工作台中用另一个会话发消息并等待回复
4. 确认侧边栏"在线对话"图标右上角出现红点
5. 点击"在线对话"进入工作台
6. 确认红点消失

- [ ] **Step 2: 验证场景 2 — 会话置顶**

1. 在工作台查看数字员工 A 的会话列表
2. 向 A 发消息并等待回复
3. 确认该会话自动排到最顶部

- [ ] **Step 3: 验证场景 3 — 数字员工置顶**

1. 有多个数字员工，当前查看的是 B
2. 向 A 的某个会话发消息并等待回复
3. 确认 A 排到员工列表最顶部

- [ ] **Step 4: 验证场景 4 — 未读红点**

1. 在工作台查看数字员工 A 的会话 1
2. 切换到 A 的会话 2
3. 向会话 1 发消息（通过 API 或其他方式触发回复）
4. 确认：会话 1 显示红点，A 的员工条目显示红点
5. 点击会话 1，确认红点消失
6. 确认 A 的员工红点也消失

- [ ] **Step 5: 类型检查最终确认**

Run: `npx vue-tsc --noEmit`
Expected: 无错误

---

## 自查清单

### Spec 覆盖度

| 需求 | 对应 Task |
|------|-----------|
| 侧边栏"在线对话"红点 | Task 4 |
| 进入工作台后红点消失 | Task 2（路由 watch） |
| 会话置顶 | Task 5（sortedSessions） |
| 数字员工置顶 | Task 5（sortedAgents） |
| 正在查看的会话也置顶 | Task 2（handleNotification 无条件更新 activityTimestamps） |
| 会话未读红点 | Task 5 |
| 数字员工未读红点 | Task 5 |
| 点击会话清除红点 | Task 2（selectSession 中 delete unreadMap） |
| 全局事件监听（非工作台页面） | Task 3 |

### Placeholder 检查

无 TBD/TODO/占位符。所有步骤包含完整代码。

### 类型一致性

- `handleNotification(sessionKey: string)` — Task 2 定义，Task 3 调用 ✓
- `isLifecycleEndEvent(event, payload)` — Task 1 定义，Task 3 调用 ✓
- `extractSessionKey(payload)` — Task 1 定义，Task 1/3 调用 ✓
- `hasSidebarNotification` — Task 2 定义，Task 4 使用 ✓
- `isSessionUnread(sessionKey)` — Task 2 定义，Task 5 使用 ✓
- `hasAgentUnread(agentId)` — Task 2 定义，Task 5 使用 ✓
- `getSessionActivityTs(sessionKey)` — Task 2 定义，Task 5 使用 ✓
