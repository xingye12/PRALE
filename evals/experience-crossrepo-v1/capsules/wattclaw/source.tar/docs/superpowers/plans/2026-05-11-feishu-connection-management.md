# Feishu Connection Management Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add binding status display, unbind via `channels.logout`, and strengthen agent deletion cleanup for Feishu channels.

**Architecture:** Frontend loads channel binding status from REST API, conditionally renders connected/disconnected UI. Backend adds `channels.logout` RPC call before config cleanup. Agent deletion gets enhanced with residual config check.

**Tech Stack:** Vue 3 + TypeScript (frontend), Express + better-sqlite3 (backend), OpenClaw Gateway RPC (WebSocket)

---

### Task 1: Add `logoutChannelFromGateway` helper to backend

**Files:**
- Modify: `server/index.js` (insert after `removeChannelFromGateway` function, ~line 1419)

- [ ] **Step 1: Add the helper function**

Insert after line 1419 (after `removeChannelFromGateway` closing brace):

```javascript
async function logoutChannelFromGateway(channel) {
  if (!gateway.isConnected) return
  try {
    await gateway.call('channels.logout', {
      channel: channel.channel_type,
      accountId: channel.agent_id,
    })
    console.log(`[ChannelSync] logged out ${channel.channel_type}/${channel.agent_id}`)
  } catch (err) {
    console.error('[ChannelSync] logout failed:', err.message)
  }
}
```

- [ ] **Step 2: Verify no syntax error**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/index.js`
Expected: No output (syntax OK)

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(channels): add logoutChannelFromGateway helper for channels.logout RPC"
```

---

### Task 2: Update `DELETE /api/user/channels/:id` to call `channels.logout`

**Files:**
- Modify: `server/index.js` (~line 1494-1509, the `app.delete('/api/user/channels/:id')` route)

- [ ] **Step 1: Add logout call before remove**

Replace the existing delete handler body:

```javascript
app.delete('/api/user/channels/:id', authMiddleware, async (req, res) => {
  try {
    const owned = getUserChannels(req.currentUser.id)
    const channel = owned.find(c => c.id === req.params.id)
    if (!channel) {
      return res.status(403).json({ ok: false, error: 'Not your channel' })
    }

    await logoutChannelFromGateway(channel)
    await removeChannelFromGateway(channel)
    deleteUserChannel(req.params.id)
    res.json({ ok: true })
  } catch (err) {
    console.error('[Channels] delete failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

Key change: `logoutChannelFromGateway(channel)` is called before `removeChannelFromGateway(channel)`.

- [ ] **Step 2: Verify syntax**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/index.js`

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(channels): call channels.logout before config cleanup on unbind"
```

---

### Task 3: Update `DELETE /api/agent-team/:id` to call `channels.logout` + residual check

**Files:**
- Modify: `server/index.js` (~line 817-836, the `app.delete('/api/agent-team/:id')` route)

- [ ] **Step 1: Add logout and residual check to agent deletion**

Replace the existing delete handler:

```javascript
app.delete('/api/agent-team/:id', authMiddleware, async (req, res) => {
  try {
    const userId = req.currentUser.role === 'admin' ? null : req.currentUser.id
    const existing = getDigitalEmployeeByAgentId(req.params.id, userId)
    if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })

    // Cascade: logout + clean up channel bindings before removing agent
    const channels = getChannelsByAgentId(req.params.id)
    for (const channel of channels) {
      await logoutChannelFromGateway(channel)
      await removeChannelFromGateway(channel)
    }
    removeChannelsByAgentId(req.params.id)

    removeAgentForUser(existing.user_id, req.params.id)

    // Residual check: verify Gateway config has no leftover channel accounts
    try {
      const cfgResult = configGetPolling.getData() || await gateway.call('config.get', {})
      const payload = cfgResult || {}
      const sourceConfig = payload.sourceConfig || payload.config || payload.parsed || {}
      const feishuAccounts = sourceConfig.channels?.feishu?.accounts
      if (feishuAccounts && feishuAccounts[req.params.id]) {
        delete feishuAccounts[req.params.id]
        const bindings = Array.isArray(sourceConfig.bindings)
          ? sourceConfig.bindings.filter(b => !(b.match?.channel === 'feishu' && b.match?.accountId === req.params.id))
          : []
        await gateway.call('config.patch', { raw: JSON.stringify({ ...sourceConfig, channels: { ...sourceConfig.channels, feishu: { ...sourceConfig.channels.feishu, accounts: feishuAccounts } }, bindings }), baseHash: payload.hash })
        await configGetPolling.refresh()
        const payload2 = configGetPolling.getData() || {}
        const sourceConfig2 = payload2.sourceConfig || payload2.config || payload2.parsed || {}
        await gateway.call('config.apply', { raw: JSON.stringify(sourceConfig2), baseHash: payload2.hash })
        configGetPolling.refresh()
        console.log(`[AgentTeam] cleaned residual feishu config for ${req.params.id}`)
      }
    } catch (residualErr) {
      console.error('[AgentTeam] residual check failed:', residualErr.message)
    }

    res.json({ ok: true })
  } catch (err) {
    console.error('[AgentTeam] delete failed:', err.message)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

Key changes:
1. `logoutChannelFromGateway(channel)` called before `removeChannelFromGateway(channel)` in the cascade loop
2. After agent removal, residual check scans Gateway config for leftover feishu accounts/bindings and cleans them

- [ ] **Step 2: Verify syntax**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/index.js`

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "fix(agent-team): add channels.logout + residual config check on agent deletion"
```

---

### Task 4: Add `POST /api/user/channels/sync-from-gateway` endpoint

**Files:**
- Modify: `server/index.js` (insert after the existing `app.delete('/api/user/channels/:id')` route, ~line 1510)

- [ ] **Step 1: Add the sync endpoint**

Insert after the delete channel route:

```javascript
app.post('/api/user/channels/sync-from-gateway', authMiddleware, async (req, res) => {
  try {
    const { agentId } = req.body
    if (!agentId) return res.status(400).json({ ok: false, error: 'agentId required' })

    // Verify ownership
    const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
    if (!ownedIds.includes(agentId)) {
      return res.status(403).json({ ok: false, error: '无权操作该 Agent' })
    }

    // Check DB first
    const existing = getChannelsByAgentId(agentId)
    if (existing.length > 0) {
      return res.json({ ok: true, channel: existing[0] })
    }

    // Check Gateway config
    if (!gateway.isConnected) {
      return res.json({ ok: true, channel: null })
    }

    const cfgResult = configGetPolling.getData() || await gateway.call('config.get', {})
    const payload = cfgResult || {}
    const sourceConfig = payload.sourceConfig || payload.config || payload.parsed || {}

    const feishuAccount = sourceConfig.channels?.feishu?.accounts?.[agentId]
    const hasBinding = Array.isArray(sourceConfig.bindings)
      && sourceConfig.bindings.some(b => b.match?.channel === 'feishu' && b.match?.accountId === agentId)

    if (feishuAccount || hasBinding) {
      // Create missing DB record
      const channel = createUserChannel(req.currentUser.id, {
        channelType: 'feishu',
        name: `Feishu-synced-${agentId}`,
        agentId,
        config: feishuAccount ? { appId: feishuAccount.appId || '', appSecret: feishuAccount.appSecret || '' } : {},
      })
      updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
      channel.status = 'active'
      channel.last_sync_at = Date.now()
      console.log(`[ChannelSync] synced gateway feishu config to DB for ${agentId}`)
      return res.json({ ok: true, channel })
    }

    res.json({ ok: true, channel: null })
  } catch (err) {
    console.error('[Channels] sync-from-gateway failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})
```

- [ ] **Step 2: Verify syntax**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/index.js`

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(channels): add sync-from-gateway endpoint to recover missing DB records"
```

---

### Task 5: Frontend — Add `feishuChannel` state and loading logic

**Files:**
- Modify: `src/views/agent-team/AgentEditPage.vue`

- [ ] **Step 1: Add feishuChannel ref and loading function**

After the existing Feishu state variables (line 36, after `let feishuPollActive = false`), add:

```typescript
interface ChannelInfo {
  id: string
  agent_id: string
  channel_type: string
  name: string
  status: string
  created_at: number
}

const feishuChannel = ref<ChannelInfo | null>(null)
const feishuLoading = ref(false)
const unbinding = ref(false)
```

After the `closeFeishuModal` function (line 209), add:

```typescript
async function loadFeishuChannel() {
  feishuLoading.value = true
  try {
    const token = authStore.getToken()
    const res = await fetch(apiPath('/api/user/channels'), {
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    if (data.ok) {
      feishuChannel.value = (data.channels || []).find(
        (c: ChannelInfo) => c.agent_id === agentId.value && c.channel_type === 'feishu'
      ) || null
    }

    // Fallback: if DB has no record, check Gateway config
    if (!feishuChannel.value) {
      const syncRes = await fetch(apiPath('/api/user/channels/sync-from-gateway'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ agentId: agentId.value }),
      })
      const syncData = await syncRes.json()
      if (syncData.ok && syncData.channel) {
        feishuChannel.value = syncData.channel
      }
    }
  } catch (e) {
    console.error('[AgentEditPage] load feishu channel error:', e)
  } finally {
    feishuLoading.value = false
  }
}

async function handleUnbindFeishu() {
  if (!feishuChannel.value) return
  unbinding.value = true
  try {
    const token = authStore.getToken()
    const res = await fetch(apiPath(`/api/user/channels/${feishuChannel.value.id}`), {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    if (data.ok) {
      message.success('已解除飞书连接')
      feishuChannel.value = null
    } else {
      message.error('解除失败：' + data.error)
    }
  } catch (e) {
    console.error('[AgentEditPage] unbind error:', e)
    message.error('解除连接失败')
  } finally {
    unbinding.value = false
  }
}
```

- [ ] **Step 2: Call `loadFeishuChannel` in onMounted**

In the `onMounted` callback (line 211), add `loadFeishuChannel()` call. Find the end of the existing onMounted and add before the closing `}`:

```typescript
loadFeishuChannel()
```

- [ ] **Step 3: Also reload after successful binding**

In `createFeishuChannelBinding` function, after `showFeishuModal.value = false` (line 193), add:

```typescript
loadFeishuChannel()
```

- [ ] **Step 4: Verify no TypeScript errors**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

- [ ] **Step 5: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "feat(agent-edit): add feishuChannel state, loading, and unbind logic"
```

---

### Task 6: Frontend — Update connections tab template

**Files:**
- Modify: `src/views/agent-team/AgentEditPage.vue` (~line 361-385, the connections tab template)

- [ ] **Step 1: Replace the connections template with conditional rendering**

Replace the entire `<template v-if="activeTab === 'connections'">` block (lines 361-385) with:

```html
<template v-if="activeTab === 'connections'">
  <div class="connections-panel">
    <NGrid :cols="2" :x-gap="16" :y-gap="16" responsive="screen">
      <NGridItem>
        <NCard title="飞书 (Feishu)" class="connection-card glass-effect" hoverable>
          <template #header-extra>
            <template v-if="feishuChannel">
              <NButton size="small" type="error" dashed :loading="unbinding" @click="handleUnbindFeishu">
                解除连接
              </NButton>
            </template>
            <template v-else>
              <NButton size="small" type="primary" dashed @click="handleAddFeishuConfig">
                接入飞书
              </NButton>
            </template>
          </template>
          <div class="connection-item-content">
            <div class="connection-icon feishu-icon">
              <span class="material-symbols-outlined">forum</span>
            </div>
            <div class="connection-info">
              <template v-if="feishuChannel">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                  <NTag size="small" type="success" :bordered="false">已接入</NTag>
                  <span style="font-size: 13px; color: var(--text-secondary);">{{ feishuChannel.name }}</span>
                </div>
                <p v-if="feishuChannel.created_at" style="font-size: 12px; color: var(--text-tertiary, #999);">
                  绑定时间：{{ new Date(feishuChannel.created_at).toLocaleString('zh-CN') }}
                </p>
              </template>
              <template v-else>
                <p class="connection-desc">连接到飞书企业内部群或私聊，实现自动化消息收发。</p>
                <NSpace style="margin-top: 8px;">
                  <NTag size="small" type="info" :bordered="false">企业协作</NTag>
                  <NTag size="small" type="default" :bordered="false">支持卡片</NTag>
                </NSpace>
              </template>
            </div>
          </div>
        </NCard>
      </NGridItem>
    </NGrid>
  </div>
</template>
```

Key changes:
- Header button: "接入飞书" (unbound) / "解除连接" (bound, with loading state)
- Content: bound state shows green "已接入" tag + channel name + bind time; unbound shows original description

- [ ] **Step 2: Add confirmation dialog for unbind**

We need a confirmation before unbinding. Modify `handleUnbindFeishu` to use `window.confirm` (simplest approach, no extra Naive UI dialog setup needed). Update the function from Task 5:

```typescript
async function handleUnbindFeishu() {
  if (!feishuChannel.value) return
  if (!window.confirm('确定要解除飞书连接吗？解除后飞书消息将不再触发回复。')) return
  // ... rest of the function unchanged
```

- [ ] **Step 3: Verify TypeScript and visual**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Then start dev server and verify the connections tab renders correctly for both bound and unbound agents.

- [ ] **Step 4: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "feat(agent-edit): show feishu binding status with unbind button in connections tab"
```

---

### Task 7: Integration test — verify full flow

- [ ] **Step 1: Start dev server**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./restart.sh`

- [ ] **Step 2: Test unbound agent**

1. Open a digital employee that has NOT been bound to Feishu
2. Go to "连接" tab
3. Verify: button shows "接入飞书", description text visible, no "已接入" tag

- [ ] **Step 3: Test bound agent**

1. Open a digital employee that HAS been bound to Feishu
2. Go to "连接" tab
3. Verify: button shows "解除连接", green "已接入" tag visible, channel name and bind time displayed
4. Click "解除连接" → confirm dialog appears → confirm
5. Verify: success message, UI switches back to unbound state
6. Send a message to the agent via Feishu → verify no response (connection is disconnected)

- [ ] **Step 4: Test delete agent**

1. Create a new digital employee
2. Bind it to Feishu
3. Delete the digital employee
4. SSH to OpenClaw server and check `~/.openclaw/openclaw.json` → verify no residual feishu account for that agentId

- [ ] **Step 5: Test residual recovery**

1. Manually add a feishu account entry in Gateway config for an existing agent (simulate orphaned config)
2. Open that agent's edit page → "连接" tab
3. Verify: `sync-from-gateway` endpoint detects the orphaned config and creates DB record
4. Verify: UI shows "已接入" state correctly
