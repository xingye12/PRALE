# Token 消耗展示 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add real-time token consumption display to chat sessions (ChatHeader badge) and agent ranking to the dashboard.

**Architecture:** Backend intercepts chat completion events, asynchronously fetches session usage from Gateway, and pushes token updates via SSE through the existing event channel. Frontend handles the update in workspace store and propagates to session store. Dashboard adds a Top Agent ranking card by reusing existing agentStats computed.

**Tech Stack:** Vue 3 + TypeScript frontend, Node.js/Express backend, SSE event streaming, NaiveUI components.

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `server/index.js` | Modify | Add `pushTokenUpdate()` + call in event handler |
| `src/stores/session.ts` | Modify | Add `updateSessionTokenUsage()` method |
| `src/stores/workspace.ts` | Modify | Handle `token_update` event in `handleEvent()` |
| `src/views/workspace/ChatHeader.vue` | Modify | Add token badge + tooltip |
| `src/views/Dashboard.vue` | Modify | Add Top Agent rank card |
| `src/i18n/messages/zh-CN.ts` | Modify | Add translation keys |

---

### Task 1: Backend — pushTokenUpdate function

**Files:**
- Modify: `server/index.js:534` (after `_autoTitleInFlight`)

- [ ] **Step 1: Add the `_tokenUpdateInFlight` Set and `pushTokenUpdate` function**

Insert after line 537 (after `_hasLabelStmt` declaration), before the `tryAutoTitleForChannelSession` function:

```javascript
const _tokenUpdateInFlight = new Set()

async function pushTokenUpdate(sessionKey) {
  if (!sessionKey || _tokenUpdateInFlight.has(sessionKey)) return
  if (!gateway.isConnected) return
  _tokenUpdateInFlight.add(sessionKey)
  try {
    const result = await gateway.call('sessions.usage', { key: sessionKey })
    if (!result || !Array.isArray(result.sessions)) return
    const match = result.sessions.find(s =>
      (s.key || s.sessionKey || s.id) === sessionKey
    )
    if (!match || !match.usage) return
    const u = match.usage
    const totalInput = u.input ?? u.inputTokens ?? u.promptTokens ?? u.input_tokens
    const totalOutput = u.output ?? u.outputTokens ?? u.completionTokens ?? u.output_tokens
    if (totalInput == null && totalOutput == null) return
    broadcastSSE({
      type: 'event',
      event: 'token_update',
      payload: {
        sessionKey,
        tokenUsage: {
          totalInput: Math.max(0, Math.floor(totalInput || 0)),
          totalOutput: Math.max(0, Math.floor(totalOutput || 0)),
        },
      },
    }, { sessionKey })
  } catch (e) {
    debug('pushTokenUpdate failed:', e?.message)
  } finally {
    _tokenUpdateInFlight.delete(sessionKey)
  }
}
```

- [ ] **Step 2: Wire up pushTokenUpdate in the gateway event handler**

In the `gateway.on('event')` handler at line 526-528, add the `pushTokenUpdate` call alongside the existing `tryAutoTitleForChannelSession`. Change:

```javascript
      if ((stream === 'lifecycle' && phase === 'end') || event === 'agent.done') {
        tryAutoTitleForChannelSession(sk)
      }
```

to:

```javascript
      if ((stream === 'lifecycle' && phase === 'end') || event === 'agent.done') {
        tryAutoTitleForChannelSession(sk)
        pushTokenUpdate(sk)
      }
```

Also add `chat.done` handling. After the block above, add:

```javascript
      if (event === 'chat.done' || event === 'chat.final') {
        pushTokenUpdate(sk)
      }
```

- [ ] **Step 3: Verify backend starts without errors**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -e "require('./server/gateway.js'); console.log('gateway.js loads ok')"` — just confirm no syntax errors in the modified file.

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: add pushTokenUpdate to push session token usage via SSE on chat completion"
```

---

### Task 2: Session store — updateSessionTokenUsage method

**Files:**
- Modify: `src/stores/session.ts:254` (return object)

- [ ] **Step 1: Add the `updateSessionTokenUsage` function**

Insert before the `return {` statement (around line 254) in `src/stores/session.ts`:

```typescript
  function updateSessionTokenUsage(sessionKey: string, tokenUsage: { totalInput: number; totalOutput: number }): void {
    const idx = sessions.value.findIndex(s => s.key === sessionKey)
    if (idx < 0) return
    const session = sessions.value[idx]!
    if (
      session.tokenUsage?.totalInput === tokenUsage.totalInput &&
      session.tokenUsage?.totalOutput === tokenUsage.totalOutput
    ) return
    const updated = { ...session, tokenUsage: { ...tokenUsage } }
    sessions.value = sessions.value.map((s, i) => i === idx ? updated : s)
  }
```

- [ ] **Step 2: Export the new method**

Add `updateSessionTokenUsage` to the return object (line 254). The return object should include:

```typescript
    updateSessionTokenUsage,
```

Add it after `patchSessionLabel,` (line 271).

- [ ] **Step 3: Verify TypeScript compiles**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: No errors related to session.ts. There may be pre-existing unrelated errors — that's OK.

- [ ] **Step 4: Commit**

```bash
git add src/stores/session.ts
git commit -m "feat: add updateSessionTokenUsage to session store for real-time token sync"
```

---

### Task 3: Workspace store — handle token_update event

**Files:**
- Modify: `src/stores/workspace.ts:1` (imports) and `src/stores/workspace.ts:915` (handleEvent)

- [ ] **Step 1: Add session store import**

Add to the import section at the top of `src/stores/workspace.ts` (after line 7):

```typescript
import { useSessionStore } from './session'
```

- [ ] **Step 2: Initialize session store inside the store function**

Find where `const wsStore = useWebSocketStore()` is declared (around line 362). Add after it:

```typescript
  const sessionStore = useSessionStore()
```

- [ ] **Step 3: Add token_update handling in handleEvent**

In the `handleEvent` function (line 915), add a token_update handler right after the `isRelevant` check block (after line 1123 `}`) and before the `Handle completion` section (line 1125). Insert:

```typescript
    // ── Token usage update from backend ──
    if (normalizedEvent === 'token_update' && payloadRow) {
      const sk = payloadRow.sessionKey as string | undefined
      const tu = payloadRow.tokenUsage as { totalInput?: number; totalOutput?: number } | undefined
      if (sk && tu && (tu.totalInput != null || tu.totalOutput != null)) {
        const tokenUsage = {
          totalInput: Math.max(0, Math.floor(tu.totalInput ?? 0)),
          totalOutput: Math.max(0, Math.floor(tu.totalOutput ?? 0)),
        }
        // Update workspace store's agent.sessions
        for (const agent of agents.value) {
          const sIdx = agent.sessions.findIndex(s => s.key === sk)
          if (sIdx >= 0) {
            agent.sessions[sIdx] = { ...agent.sessions[sIdx]!, tokenUsage }
            break
          }
        }
        // Sync to session store (for Dashboard agentStats)
        sessionStore.updateSessionTokenUsage(sk, tokenUsage)
      }
      return
    }
```

- [ ] **Step 4: Verify TypeScript compiles**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: No new errors from workspace.ts.

- [ ] **Step 5: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat: handle token_update SSE event in workspace store"
```

---

### Task 4: ChatHeader — token badge display

**Files:**
- Modify: `src/views/workspace/ChatHeader.vue`

- [ ] **Step 1: Add token computed properties**

In the `<script setup>` section, after the existing computed properties (after line 24 `const connectionLabel = ...`), add:

```typescript
const tokenUsage = computed(() => workspaceStore.activeSession?.tokenUsage)
const totalTokens = computed(() => {
  const u = tokenUsage.value
  if (!u) return 0
  return u.totalInput + u.totalOutput
})

function formatTokenCount(n: number): string {
  if (n < 1000) return String(n)
  if (n < 1_000_000) return `${(n / 1000).toFixed(1)}K`
  if (n < 1_000_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  return `${(n / 1_000_000_000).toFixed(1)}B`
}
```

- [ ] **Step 2: Add token badge to the template**

In the template, after the `<span class="model-chip">` (line 39) and before the share button (line 40), insert:

```html
      <span
        v-if="totalTokens > 0"
        class="token-badge"
        :title="`${t('pages.workspace.token.input')}: ${formatTokenCount(tokenUsage!.totalInput)}\n${t('pages.workspace.token.output')}: ${formatTokenCount(tokenUsage!.totalOutput)}`"
      >
        {{ formatTokenCount(totalTokens) }}
      </span>
```

- [ ] **Step 3: Add token badge styles**

Add to the `<style scoped>` section (after the `.connection-dot.connected` rule at line 166):

```css
.token-badge {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 999px;
  background: #e8f5e9;
  color: #2e7d32;
  border: 1px solid #c8e6c9;
  font-weight: 600;
  cursor: default;
  white-space: nowrap;
  line-height: 1.4;
}

[data-theme='dark'] .token-badge {
  background: rgba(46, 125, 50, 0.15);
  color: #66bb6a;
  border-color: rgba(46, 125, 50, 0.3);
}
```

- [ ] **Step 4: Verify the component renders**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: No new errors from ChatHeader.vue.

- [ ] **Step 5: Commit**

```bash
git add src/views/workspace/ChatHeader.vue
git commit -m "feat: add token consumption badge to chat header"
```

---

### Task 5: i18n — add translation keys

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`

- [ ] **Step 1: Add workspace token keys**

Find the `pages.workspace` section in `zh-CN.ts`. Search for an existing key pattern like `pages.workspace.share` or `pages.workspace.filePanel`. Add within the `workspace` object:

```typescript
        token: {
          input: '输入',
          output: '输出',
        },
```

The exact location depends on the nesting structure. Find a sibling key under the same `workspace` parent and add alongside it.

- [ ] **Step 2: Add dashboard agent ranking keys**

Find `pages.dashboard.top` section (around line 1138). Add after `tools:`:

```typescript
        agents: '热门 Agent',
```

So the `top` section becomes:

```typescript
      top: {
        models: '热门模型',
        providers: '热门提供商',
        tools: '热门工具',
        agents: '热门 Agent',
      },
```

- [ ] **Step 3: Verify no i18n errors**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

- [ ] **Step 4: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat: add i18n keys for token display and agent ranking"
```

---

### Task 6: Dashboard — Top Agent ranking card

**Files:**
- Modify: `src/views/Dashboard.vue`

- [ ] **Step 1: Add agent store import**

At the top of the `<script setup>`, after `import { useAuthStore }` (line 19), add:

```typescript
import { useAgentStore } from '@/stores/agent'
```

And after `const authStore = useAuthStore()` (line 34), add:

```typescript
const agentStore = useAgentStore()
```

- [ ] **Step 2: Add topAgents computed**

After the `topTools` computed (around line 383), add:

```typescript
const topAgents = computed(() => {
  const stats = agentStore.agentStats
  const entries = Object.entries(stats)
    .map(([agentId, stat]) => ({
      agentId,
      name: agentStore.getAgentById(agentId)?.name || agentId,
      totalTokens: stat.input + stat.output,
      sessions: stat.sessions,
    }))
    .filter(a => a.totalTokens > 0)
    .sort((a, b) => b.totalTokens - a.totalTokens)
    .slice(0, 5)
  return entries
})

const topAgentMax = computed(() =>
  Math.max(...topAgents.value.map(a => a.totalTokens), 0)
)
```

- [ ] **Step 3: Change grid to 4 columns**

Find the rankings section NGrid (line 981):

```html
<NGrid cols="1 m:3" responsive="screen" :x-gap="24" :y-gap="24">
```

Change to:

```html
<NGrid cols="1 m:2 l:4" responsive="screen" :x-gap="24" :y-gap="24">
```

- [ ] **Step 4: Add Top Agent rank card**

After the Top Tools NGridItem closing tag (before `</NGrid>` at line 1030), insert a new NGridItem:

```html
            <NGridItem>
              <div class="rank-card glass-effect">
                <h3 class="rank-title">{{ t('pages.dashboard.top.agents') }}</h3>
                <div v-if="topAgents.length" class="rank-list">
                   <div v-for="item in topAgents" :key="item.agentId" class="rank-row">
                      <div class="rank-meta">
                         <p class="rank-name">{{ item.name }}</p>
                         <p class="rank-val">{{ formatCompactNumber(item.totalTokens) }}</p>
                      </div>
                      <div class="rank-bar-bg">
                         <div class="rank-bar-fill bg-success" :style="{ width: topBarWidth(item.totalTokens, topAgentMax) }"></div>
                      </div>
                   </div>
                </div>
              </div>
            </NGridItem>
```

- [ ] **Step 5: Verify TypeScript compiles and dashboard renders**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`

Expected: No new errors.

- [ ] **Step 6: Commit**

```bash
git add src/views/Dashboard.vue
git commit -m "feat: add Top Agent ranking card to dashboard"
```

---

### Task 7: Manual verification

- [ ] **Step 1: Start the dev environment**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./start.sh`

- [ ] **Step 2: Test ChatHeader token badge**

1. Open the app in browser, navigate to workspace
2. Start a chat session with any agent
3. Send a message, wait for response to complete
4. Verify the green token badge appears next to the model chip in the chat header
5. Hover over the badge — verify tooltip shows input/output breakdown
6. Send another message — verify the token count updates

- [ ] **Step 3: Test Dashboard Agent ranking**

1. Navigate to the Dashboard page
2. Verify the Top Agent card appears alongside Top Models, Top Provider, Top Tools
3. Verify agent names and token counts are displayed correctly
4. Verify the progress bars render with green color

- [ ] **Step 4: Test dark mode**

1. Toggle dark mode
2. Verify token badge and Agent card render correctly in dark theme

- [ ] **Step 5: Test responsive layout**

1. Resize browser to different widths
2. Verify the 4-column ranking grid collapses to 2 columns on medium screens and 1 column on small screens
