# 延迟 Token 加载优化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 去掉 Workspace 页面加载时的全量 `sessions.usage` 调用，改为选中 session 时按需获取单条 token 数据，将页面加载速度从 2-9 秒降到 <500ms。

**Architecture:** 删除 `fetchAllSessionsCached()` 中的 `getSessionsUsage()` 全量 enrich，新增 `fetchSingleSessionUsage()` 辅助函数在 `selectSession()` 中按需调用。SSE `token_update` 实时推送路径不变。

**Tech Stack:** Vue 3 + Pinia + TypeScript

---

### Task 1: 删除 fetchAllSessionsCached 中的全量 usage enrich

**Files:**
- Modify: `src/stores/workspace.ts:389-423`

- [ ] **Step 1: 删除 getSessionsUsage 调用**

将 `fetchAllSessionsCached()` 中第 396-419 行的 usage enrich 逻辑删除，保留 `listSessions` 调用。

修改后的函数：

```typescript
async function fetchAllSessionsCached(): Promise<Session[]> {
  if (_sessionCache && Date.now() - _sessionCache.ts < SESSION_CACHE_TTL) {
    return _sessionCache.data
  }
  const result = await wsStore.rpc.listSessions()
  const allSessions: Session[] = Array.isArray(result) ? result : (result.sessions || [])
  _sessionCache = { data: allSessions, ts: Date.now() }
  return allSessions
}
```

变更点：
- 删除 `let allSessions`（改为 `const`）
- 删除第 396-419 行整个 `if (allSessions.length > 0 ...)` enrich 块
- 删除第 421 行 `_sessionCache = { data: allSessions, ts: Date.now() }` 之前多余的空行

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无 workspace.ts 相关错误

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "perf: remove bulk sessions.usage call from page load"
```

---

### Task 2: 新增 fetchSingleSessionUsage 辅助函数

**Files:**
- Modify: `src/stores/workspace.ts` (在 `fetchAllSessionsCached` 之后、`loadAgents` 之前插入)

- [ ] **Step 1: 在 fetchAllSessionsCached 和 loadAgents 之间插入新函数**

在第 423 行（`fetchAllSessionsCached` 结束）和第 425 行（`loadAgents` 开始）之间插入：

```typescript
async function fetchSingleSessionUsage(sessionKey: string) {
  try {
    const usageResult = await wsStore.rpc.getSessionsUsage({ key: sessionKey })
    const item = usageResult?.sessions?.[0]
    if (!item?.usage || !activeSessionKey.value) return
    const u = item.usage
    const tokenUsage = {
      totalInput: Math.max(0, Math.floor(u.input ?? u.inputTokens ?? u.promptTokens ?? 0)),
      totalOutput: Math.max(0, Math.floor(u.output ?? u.outputTokens ?? u.completionTokens ?? 0)),
    }
    if (tokenUsage.totalInput === 0 && tokenUsage.totalOutput === 0) return
    for (const agent of agents.value) {
      const idx = agent.sessions.findIndex(s => s.key === sessionKey)
      if (idx >= 0) {
        agent.sessions[idx] = { ...agent.sessions[idx]!, tokenUsage }
        agent.sessions = [...agent.sessions]
        break
      }
    }
  } catch { /* optional */ }
}
```

要点：
- 复用 SSE `token_update` handler 的 usage 字段兼容逻辑（input/inputTokens/promptTokens 多种字段名）
- 更新 `agent.sessions` 后重新赋值数组引用触发 Vue 响应式
- 只更新当前活跃 session（`activeSessionKey.value` 守卫防止切走后更新旧 session）
- fire-and-forget，catch 静默

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无错误

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat: add fetchSingleSessionUsage for lazy token loading"
```

---

### Task 3: 在 selectSession 中按需调用 fetchSingleSessionUsage

**Files:**
- Modify: `src/stores/workspace.ts:624-636`（agent sync 循环区域）

- [ ] **Step 1: 在 selectSession 的 agent sync 循环中添加按需加载**

在 `selectSession()` 第 624-636 行的 agent sync 循环中，`break` 之前添加 token 按需加载：

```typescript
    // Sync selectedAgentId and restore per-session model preference
    for (const agent of agents.value) {
      const session = agent.sessions.find(s => s.key === sessionKey)
      if (session) {
        if (selectedAgentId.value !== agent.agentId) {
          selectedAgentId.value = agent.agentId
          selectedModel.value = session.model || agent.model || selectedModel.value
        } else if (session.model && session.model !== selectedModel.value) {
          selectedModel.value = session.model
        }
        // Lazy load token usage for historical sessions
        if (!session.tokenUsage && session.messageCount > 0) {
          fetchSingleSessionUsage(sessionKey).catch(() => {})
        }
        break
      }
    }
```

只新增 `if (!session.tokenUsage && session.messageCount > 0)` 这个分支 + fire-and-forget 调用，其余代码不动。

`messageCount > 0` 守卫确保空 session 不发无效请求。

- [ ] **Step 2: 验证类型检查通过**

Run: `npx vue-tsc --noEmit 2>&1 | head -30`
Expected: 无错误

- [ ] **Step 3: 浏览器验证**

启动 `./start.sh`，验证：
1. 打开在线对话页面 → 侧边栏快速加载（不卡 2-9 秒）
2. 点击有历史的 session → ChatHeader token badge 在几百毫秒内出现
3. 点击空 session → 无报错，无 badge（正常）
4. 发送新消息 → 对话完成后 SSE token_update 推送 token badge

- [ ] **Step 4: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat: lazy load token usage on session selection"
```
