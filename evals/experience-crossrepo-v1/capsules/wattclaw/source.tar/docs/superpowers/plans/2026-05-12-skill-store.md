# 技能商店（Skill Store）实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现技能商店模块——用户可浏览 Gateway 机器上的技能目录，将技能安装到数字员工，并管理已安装技能。

**Architecture:** 后端通过 SSH 扫描 Gateway 机器 `/home/wattman/skills-store` 目录，将技能元数据存入 SQLite。前端通过 REST API 与后端交互，不直接调 Gateway RPC（安装/删除操作除外，需要 SSH 文件操作）。技能与数字员工通过关联表实现多对多关系。

**Tech Stack:** Express.js + better-sqlite3 + ssh2（后端）、Vue 3 + Pinia + Naive UI + TypeScript（前端）

**Reference:** `docs/skill-store-module.md` — 绝对参考标准，所有实现细节以该文档为准。

---

## File Structure

| Action | File | Responsibility |
|--------|------|----------------|
| Modify | `server/database.js` | 添加 skill_store_skill 和 skill_store_agent_skill 表 + 迁移 |
| Modify | `server/index.js` | 添加 10 个 REST API 端点 + 3 个 SSH 辅助函数 |
| Modify | `server/user-manager.js` | Agent 删除时清理 skill_store_agent_skill 关联 |
| Create | `src/api/types/skill-store.ts` | 前端类型定义 |
| Modify | `src/api/types/index.ts` | 导出 skill-store 类型 |
| Create | `src/stores/skill-store.ts` | Pinia Store |
| Create | `src/views/skill-store/SkillStorePage.vue` | 技能商店页面（Store Tab + Manage Tab + 弹窗） |
| Modify | `src/views/agent-team/AgentEditPage.vue` | 数字员工编辑页技能 Tab |
| Modify | `src/router/routes.ts` | 添加 skill-store 路由 |
| Modify | `src/i18n/messages/zh-CN.ts` | 添加 i18n 翻译 |

---

## Task 1: 数据库 Schema

**Files:**
- Modify: `server/database.js` (在现有 CREATE TABLE 块末尾追加)

- [ ] **Step 1: 添加 skill_store_skill 表和 skill_store_agent_skill 表**

在 `server/database.js` 的 `db.exec(...)` 模板字符串中，`backup_records` 表后面、闭合反引号之前，追加：

```sql
CREATE TABLE IF NOT EXISTS skill_store_skill (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '',
  icon_color TEXT NOT NULL DEFAULT '#6366f1',
  category TEXT NOT NULL DEFAULT 'general',
  usage TEXT NOT NULL DEFAULT '',
  version TEXT NOT NULL DEFAULT '1.0.0',
  type TEXT NOT NULL DEFAULT 'builtin',
  installed INTEGER NOT NULL DEFAULT 0,
  gateway_name TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS skill_store_agent_skill (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL REFERENCES skill_store_skill(id) ON DELETE CASCADE,
  agent_id TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(skill_id, agent_id)
);
```

- [ ] **Step 2: 添加迁移列**

在 `server/database.js` 的 `migrations` 数组中追加：

```javascript
'ALTER TABLE skill_store_skill ADD COLUMN readme TEXT DEFAULT \'\'',
'ALTER TABLE skill_store_skill ADD COLUMN source TEXT DEFAULT \'gateway\'',
```

- [ ] **Step 3: 启动验证**

Run: `npm run dev:server`，确认无报错，数据库表创建成功。

- [ ] **Step 4: Commit**

```bash
git add server/database.js
git commit -m "feat: add skill_store_skill and skill_store_agent_skill tables"
```

---

## Task 2: 后端 SSH 辅助函数

**Files:**
- Modify: `server/index.js`（在现有 `sshExec` 函数附近追加）

- [ ] **Step 1: 添加 sshCopySkillToAgent 和 sshRemoveSkillFromAgent**

在 `server/index.js` 中 `sshExec` 函数定义之后，追加：

```javascript
async function sshCopySkillToAgent(gatewayName, agentId) {
  const workspace = await getAgentWorkspace(agentId)
  if (!workspace) throw new Error(`无法获取 Agent ${agentId} 的 workspace 路径`)
  const skillsPath = envConfig.GATEWAY_SKILLS_STORE_PATH || '/home/wattman/skills-store'
  const srcDir = `${skillsPath}/${gatewayName}`
  const destDir = `${workspace}/skills/${gatewayName}`
  await sshExec(`mkdir -p "$(dirname "${destDir}")" && cp -r "${srcDir}" "${destDir}"`)
  // OpenClaw Gateway 硬编码识别 SKILL.md（大写），自动处理大小写
  await sshExec(`if [ -f "${destDir}/skill.md" ] && [ ! -f "${destDir}/SKILL.md" ]; then mv "${destDir}/skill.md" "${destDir}/SKILL.md"; fi`)
}

async function sshRemoveSkillFromAgent(gatewayName, agentId) {
  const workspace = await getAgentWorkspace(agentId)
  if (!workspace) return
  const destDir = `${workspace}/skills/${gatewayName}`
  await sshExec(`rm -rf "${destDir}"`)
}
```

- [ ] **Step 2: 在 envConfig 中添加 GATEWAY_SKILLS_STORE_PATH**

在 `server/index.js` 的 `loadEnvConfig()` 的 `defaults` 对象中追加：

```javascript
GATEWAY_SKILLS_STORE_PATH: '/home/wattman/skills-store',
```

在 `loadEnvConfig()` 返回的对象中追加：

```javascript
GATEWAY_SKILLS_STORE_PATH: process.env.GATEWAY_SKILLS_STORE_PATH || fileConfig.GATEWAY_SKILLS_STORE_PATH || defaults.GATEWAY_SKILLS_STORE_PATH,
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat: add SSH skill copy/remove functions for skill store"
```

---

## Task 3: 后端 getAllSkillsWithAgents 内部函数

**Files:**
- Modify: `server/index.js`（在 API 路由之前追加）

- [ ] **Step 1: 添加 getAllSkillsWithAgents**

在 `server/index.js` 中 skill-store 路由注册之前，追加：

```javascript
function getAllSkillsWithAgents() {
  const skills = db.prepare('SELECT * FROM skill_store_skill ORDER BY created_at DESC').all()
  if (skills.length === 0) return []
  const skillIds = skills.map(s => s.id)
  const placeholders = skillIds.map(() => '?').join(',')
  const agentRows = db.prepare(
    `SELECT sas.skill_id, sas.agent_id, sas.enabled, ua.name AS agent_name, ua.avatar AS agent_avatar
     FROM skill_store_agent_skill sas
     LEFT JOIN user_agents ua ON sas.agent_id = ua.gateway_agent_id
     WHERE sas.skill_id IN (${placeholders})`
  ).all(...skillIds)
  const agentMap = {}
  for (const row of agentRows) {
    if (!agentMap[row.skill_id]) agentMap[row.skill_id] = []
    agentMap[row.skill_id].push({
      agent_id: row.agent_id,
      agent_name: row.agent_name,
      agent_avatar: row.agent_avatar,
      enabled: Boolean(row.enabled),
    })
  }
  return skills.map(skill => ({
    ...skill,
    installed: Boolean(skill.installed),
    agents: agentMap[skill.id] || [],
  }))
}
```

- [ ] **Step 2: Commit**

```bash
git add server/index.js
git commit -m "feat: add getAllSkillsWithAgents helper for skill store"
```

---

## Task 4: 后端 API 端点 — 查询类

**Files:**
- Modify: `server/index.js`（在现有路由之后追加）

- [ ] **Step 1: 添加 GET /api/skill-store/catalog**

```javascript
app.get('/api/skill-store/catalog', authMiddleware, (req, res) => {
  try {
    let skills = getAllSkillsWithAgents()
    const { category, search } = req.query
    if (category && category !== 'all') skills = skills.filter(s => s.category === category)
    if (search) {
      const q = search.toLowerCase()
      skills = skills.filter(s =>
        s.name.toLowerCase().includes(q) ||
        (s.description || '').toLowerCase().includes(q)
      )
    }
    res.json({ ok: true, skills })
  } catch (e) {
    console.error('[SkillStore] catalog error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 2: 添加 GET /api/skill-store/installed**

```javascript
app.get('/api/skill-store/installed', authMiddleware, (req, res) => {
  try {
    const all = getAllSkillsWithAgents()
    res.json({ ok: true, skills: all })
  } catch (e) {
    console.error('[SkillStore] installed error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 3: 添加 GET /api/skill-store/skills/:id**

```javascript
app.get('/api/skill-store/skills/:id', authMiddleware, (req, res) => {
  try {
    const all = getAllSkillsWithAgents()
    const skill = all.find(s => s.id === req.params.id)
    if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })
    res.json({ ok: true, skill })
  } catch (e) {
    console.error('[SkillStore] get skill error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 4: 添加 GET /api/skill-store/agents**

```javascript
app.get('/api/skill-store/agents', authMiddleware, (req, res) => {
  try {
    const agentIds = db.prepare('SELECT DISTINCT gateway_agent_id FROM user_agents').all()
      .map(r => r.gateway_agent_id)
      .filter(Boolean)
    if (agentIds.length === 0) return res.json({ ok: true, agents: [] })

    const placeholders = agentIds.map(() => '?').join(',')
    const skillRows = db.prepare(
      `SELECT sas.agent_id, ss.id AS skill_id, ss.name AS skill_name, ss.icon AS skill_icon,
              ss.icon_color AS skill_icon_color, sas.enabled
       FROM skill_store_agent_skill sas
       JOIN skill_store_skill ss ON sas.skill_id = ss.id
       WHERE sas.agent_id IN (${placeholders})`
    ).all(...agentIds)

    const skillMap = {}
    for (const row of skillRows) {
      if (!skillMap[row.agent_id]) skillMap[row.agent_id] = []
      skillMap[row.agent_id].push({
        skillId: row.skill_id,
        skillName: row.skill_name,
        skillIcon: row.skill_icon,
        skillIconColor: row.skill_icon_color,
        enabled: Boolean(row.enabled),
      })
    }

    const agents = db.prepare(
      `SELECT gateway_agent_id AS id, name, avatar FROM user_agents WHERE gateway_agent_id IN (${placeholders})`
    ).all(...agentIds)

    res.json({
      ok: true,
      agents: agents.map(a => ({
        id: a.id,
        name: a.name,
        avatar: a.avatar,
        avatarColor: '',
        skills: skillMap[a.id] || [],
      })),
    })
  } catch (e) {
    console.error('[SkillStore] agents error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 5: 添加 GET /api/skill-store/agent/:agentId/skills**

```javascript
app.get('/api/skill-store/agent/:agentId/skills', authMiddleware, (req, res) => {
  try {
    const { agentId } = req.params
    const all = getAllSkillsWithAgents()
    const agentSkills = all.filter(s => s.agents.some(a => a.agent_id === agentId))
    res.json({ ok: true, skills: agentSkills })
  } catch (e) {
    console.error('[SkillStore] agent skills error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 6: Commit**

```bash
git add server/index.js
git commit -m "feat: add skill store query API endpoints"
```

---

## Task 5: 后端 API 端点 — 写操作类

**Files:**
- Modify: `server/index.js`

- [ ] **Step 1: 添加 POST /api/skill-store/skills/:id/install**

安装技能到指定 agent。如果 id 以 `gw-` 开头且 DB 无记录，自动创建（source='gateway'）。

```javascript
app.post('/api/skill-store/skills/:id/install', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params
    const { agentIds } = req.body
    if (!Array.isArray(agentIds) || agentIds.length === 0) {
      return res.status(400).json({ ok: false, error: 'agentIds is required' })
    }

    let skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(id)

    // 自动创建 gw- 前缀的记录（source='gateway'，不出现在商店主区域）
    if (!skill && id.startsWith('gw-')) {
      const gwName = id.slice(3)
      const iconPool = ['🤖', '🔧', '📊', '🧠', '💡', '📝', '🔍', '⚙️']
      const colorPool = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#6b7280']
      const idx = Math.abs(gwName.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % iconPool.length
      const newId = 'sk-' + Date.now() + '-' + Math.random().toString(36).slice(2)
      db.prepare(
        `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name, source)
         VALUES (?, ?, '', ?, ?, 'general', '', '1.0.0', 'builtin', 0, ?, 'gateway')`
      ).run(newId, gwName, iconPool[idx], colorPool[idx], gwName)
      skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(newId)
    }

    if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })

    for (const agentId of agentIds) {
      const existing = db.prepare('SELECT id FROM skill_store_agent_skill WHERE skill_id = ? AND agent_id = ?')
        .get(skill.id, agentId)
      if (!existing) {
        db.prepare('INSERT INTO skill_store_agent_skill (id, skill_id, agent_id, enabled) VALUES (?, ?, ?, 1)')
          .run('as-' + Date.now() + '-' + Math.random().toString(36).slice(2), skill.id, agentId)
      }
      if (skill.gateway_name) {
        try { await sshCopySkillToAgent(skill.gateway_name, agentId) }
        catch (e) { console.error(`[SkillStore] SSH copy failed for ${skill.gateway_name} -> ${agentId}:`, e.message) }
      }
    }

    db.prepare('UPDATE skill_store_skill SET installed = 1 WHERE id = ?').run(skill.id)
    res.json({ ok: true })
  } catch (e) {
    console.error('[SkillStore] install error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 2: 添加 PATCH /api/skill-store/skills/:id/toggle**

```javascript
app.patch('/api/skill-store/skills/:id/toggle', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params
    const { agentId, enabled } = req.body
    if (!agentId || enabled === undefined) {
      return res.status(400).json({ ok: false, error: 'agentId and enabled are required' })
    }

    db.prepare('UPDATE skill_store_agent_skill SET enabled = ? WHERE skill_id = ? AND agent_id = ?')
      .run(enabled ? 1 : 0, id, agentId)

    const skill = db.prepare('SELECT gateway_name FROM skill_store_skill WHERE id = ?').get(id)
    if (skill && skill.gateway_name) {
      if (enabled) {
        await sshCopySkillToAgent(skill.gateway_name, agentId)
      } else {
        await sshRemoveSkillFromAgent(skill.gateway_name, agentId)
      }
    }

    res.json({ ok: true })
  } catch (e) {
    console.error('[SkillStore] toggle error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 3: 添加 DELETE /api/skill-store/skills/:id**

```javascript
app.delete('/api/skill-store/skills/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params
    const skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(id)
    if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })

    if (skill.gateway_name) {
      const agentRows = db.prepare('SELECT agent_id FROM skill_store_agent_skill WHERE skill_id = ?').all(id)
      for (const row of agentRows) {
        try { await sshRemoveSkillFromAgent(skill.gateway_name, row.agent_id) }
        catch (e) { console.error('[SkillStore] SSH remove failed:', e.message) }
      }
    }

    db.prepare('DELETE FROM skill_store_agent_skill WHERE skill_id = ?').run(id)
    db.prepare('DELETE FROM skill_store_skill WHERE id = ?').run(id)
    res.json({ ok: true })
  } catch (e) {
    console.error('[SkillStore] delete error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: add skill store write API endpoints (install/toggle/delete)"
```

---

## Task 6: 后端 API 端点 — 扫描

**Files:**
- Modify: `server/index.js`

- [ ] **Step 1: 添加 POST /api/skill-store/scan**

核心端点：SSH 扫描 Gateway skills-store 目录，同步到数据库。

```javascript
app.post('/api/skill-store/scan', authMiddleware, async (req, res) => {
  try {
    const skillsPath = envConfig.GATEWAY_SKILLS_STORE_PATH || '/home/wattman/skills-store'
    const output = await sshExec(`find "${skillsPath}" -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' 2>/dev/null`)
    const dirNames = output.trim().split('\n').filter(Boolean)

    // 清理不在目录中的旧 store 记录
    if (dirNames.length > 0) {
      const placeholders = dirNames.map(() => '?').join(',')
      db.prepare(`DELETE FROM skill_store_agent_skill WHERE skill_id IN (
        SELECT id FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})
      )`).run(...dirNames)
      db.prepare(`DELETE FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})`)
        .run(...dirNames)
    } else {
      db.prepare(`DELETE FROM skill_store_agent_skill WHERE skill_id IN (
        SELECT id FROM skill_store_skill WHERE source = 'store'
      )`).run()
      db.prepare(`DELETE FROM skill_store_skill WHERE source = 'store'`).run()
    }

    const iconPool = ['🤖', '🔧', '📊', '🧠', '💡', '📝', '🔍', '⚙️']
    const colorPool = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#6b7280']

    for (const gwName of dirNames) {
      let readme = ''
      try {
        readme = await sshExec(`cat "${skillsPath}/${gwName}/SKILL.md" 2>/dev/null || cat "${skillsPath}/${gwName}/skill.md" 2>/dev/null`)
      } catch (e) { /* no readme file */ }

      let description = ''
      const fmMatch = readme.match(/^---\s*\n([\s\S]*?)\n---/)
      if (fmMatch) {
        const descMatch = fmMatch[1].match(/^description:\s*(.+)$/m)
        if (descMatch) description = descMatch[1].trim()
      }
      if (!description) {
        const bulletMatch = readme.match(/[-*]\s*\*\*[Dd]escription\*\*:\s*(.+)/)
        if (bulletMatch) description = bulletMatch[1].trim()
      }

      const existing = db.prepare('SELECT id FROM skill_store_skill WHERE gateway_name = ?').get(gwName)
      if (existing) {
        db.prepare(`UPDATE skill_store_skill SET description=?, readme=?, source='store', updated_at=datetime('now') WHERE gateway_name=?`)
          .run(description, readme, gwName)
      } else {
        const id = 'sk-' + Date.now() + '-' + Math.random().toString(36).slice(2)
        const idx = Math.abs(gwName.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % iconPool.length
        db.prepare(
          `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name, readme, source)
           VALUES (?, ?, ?, ?, ?, 'general', '', '1.0.0', 'builtin', 0, ?, ?, 'store')`
        ).run(id, gwName, description, iconPool[idx], colorPool[idx], gwName, readme)
      }
    }

    res.json({ ok: true, count: dirNames.length })
  } catch (e) {
    console.error('[SkillStore] scan error:', e.message)
    res.status(500).json({ ok: false, error: e.message })
  }
})
```

- [ ] **Step 2: 启动验证**

Run: `npm run dev:server`，确认无语法错误，端口正常监听。

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat: add skill store scan endpoint with SSH gateway sync"
```

---

## Task 7: Agent 删除级联清理

**Files:**
- Modify: `server/user-manager.js`

- [ ] **Step 1: 在 deleteUserAgent 中追加清理**

修改 `deleteUserAgent` 函数，在删除 user_agents 之前先查 gateway_agent_id 并清理关联：

```javascript
export function deleteUserAgent(id) {
  const row = db.prepare('SELECT gateway_agent_id FROM user_agents WHERE id = ?').get(id)
  if (row) {
    db.prepare('DELETE FROM skill_store_agent_skill WHERE agent_id = ?').run(row.gateway_agent_id)
  }
  db.prepare('DELETE FROM user_agents WHERE id = ?').run(id)
}
```

- [ ] **Step 2: 在 removeAgentForUser 中追加清理**

```javascript
export function removeAgentForUser(userId, gatewayAgentId) {
  db.prepare('DELETE FROM skill_store_agent_skill WHERE agent_id = ?').run(gatewayAgentId)
  db.prepare('DELETE FROM user_agents WHERE user_id = ? AND gateway_agent_id = ?').run(userId, gatewayAgentId)
  db.prepare('DELETE FROM user_sessions WHERE user_id = ? AND agent_id = ?').run(userId, gatewayAgentId)
}
```

- [ ] **Step 3: Commit**

```bash
git add server/user-manager.js
git commit -m "feat: cascade delete skill_store_agent_skill on agent removal"
```

---

## Task 8: 前端类型定义

**Files:**
- Create: `src/api/types/skill-store.ts`
- Modify: `src/api/types/index.ts`

- [ ] **Step 1: 创建 src/api/types/skill-store.ts**

```typescript
export interface SkillStoreSkill {
  id: string
  name: string
  description: string
  icon: string
  icon_color: string
  category: string
  usage: string
  version: string
  type: string
  installed: boolean
  gateway_name?: string
  readme?: string
  source?: string
  agents: SkillStoreAgentSkill[]
  created_at: string
  updated_at: string
}

export interface SkillStoreAgentSkill {
  agent_id: string
  agent_name: string
  agent_avatar: string
  enabled: boolean
}

export interface SkillStoreAgent {
  id: string
  name: string
  avatar: string
  avatarColor: string
  skills: SkillStoreAgentSkillDetail[]
}

export interface SkillStoreAgentSkillDetail {
  skillId: string
  skillName: string
  skillIcon: string
  skillIconColor: string
  enabled: boolean
}

export type SkillStoreCategory = 'all' | 'featured' | 'general' | 'creative'
```

- [ ] **Step 2: 在 src/api/types/index.ts 顶部追加导出**

在第一行 `export * from './rpc'` 之后追加：

```typescript
export * from './skill-store'
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`，确认无类型错误。

- [ ] **Step 4: Commit**

```bash
git add src/api/types/skill-store.ts src/api/types/index.ts
git commit -m "feat: add skill store TypeScript type definitions"
```

---

## Task 9: 前端 Pinia Store

**Files:**
- Create: `src/stores/skill-store.ts`

- [ ] **Step 1: 创建 src/stores/skill-store.ts**

```typescript
import { ref } from 'vue'
import { defineStore } from 'pinia'
import { useAuthStore } from './auth'
import type { SkillStoreSkill, SkillStoreAgent, SkillStoreCategory } from '@/api/types'

export const useSkillStoreStore = defineStore('skill-store', () => {
  const skills = ref<SkillStoreSkill[]>([])
  const installedSkills = ref<SkillStoreSkill[]>([])
  const agents = ref<SkillStoreAgent[]>([])
  const activeTab = ref<'store' | 'manage'>('store')
  const category = ref<SkillStoreCategory>('all')
  const search = ref('')
  const selectedSkill = ref<SkillStoreSkill | null>(null)
  const detailOpen = ref(false)
  const agentSelectOpen = ref(false)
  const loading = ref(false)
  const scanning = ref(false)

  async function apiCall(path: string, options?: RequestInit) {
    const token = useAuthStore().getToken()
    const res = await fetch(`/api/skill-store${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        ...options?.headers,
      },
    })
    const data = await res.json()
    if (!data.ok) throw new Error(data.error || 'Request failed')
    return data
  }

  async function fetchSkills() {
    try {
      const data = await apiCall('/catalog')
      skills.value = data.skills || []
    } catch (e) {
      console.error('[SkillStore] fetchSkills failed:', e)
    }
  }

  async function fetchInstalled() {
    try {
      const data = await apiCall('/installed')
      installedSkills.value = data.skills || []
    } catch (e) {
      console.error('[SkillStore] fetchInstalled failed:', e)
    }
  }

  async function fetchAgents() {
    try {
      const data = await apiCall('/agents')
      agents.value = data.agents || []
    } catch (e) {
      console.error('[SkillStore] fetchAgents failed:', e)
    }
  }

  async function refreshAll() {
    await Promise.all([fetchSkills(), fetchInstalled(), fetchAgents()])
  }

  async function scanGateway() {
    scanning.value = true
    try {
      await apiCall('/scan', { method: 'POST' })
      await refreshAll()
    } finally {
      scanning.value = false
    }
  }

  async function installSkill(skillId: string, agentIds: string[]) {
    await apiCall(`/skills/${skillId}/install`, {
      method: 'POST',
      body: JSON.stringify({ agentIds }),
    })
    await refreshAll()
  }

  async function toggleSkill(skillId: string, agentId: string, enabled: boolean) {
    await apiCall(`/skills/${skillId}/toggle`, {
      method: 'PATCH',
      body: JSON.stringify({ agentId, enabled }),
    })
    await refreshAll()
  }

  async function deleteSkill(skillId: string) {
    await apiCall(`/skills/${skillId}`, { method: 'DELETE' })
    await refreshAll()
  }

  return {
    skills, installedSkills, agents,
    activeTab, category, search,
    selectedSkill, detailOpen, agentSelectOpen,
    loading, scanning,
    fetchSkills, fetchInstalled, fetchAgents,
    refreshAll, scanGateway,
    installSkill, toggleSkill, deleteSkill,
  }
})
```

- [ ] **Step 2: 类型检查**

Run: `npx vue-tsc --noEmit`

- [ ] **Step 3: Commit**

```bash
git add src/stores/skill-store.ts
git commit -m "feat: add skill store Pinia store"
```

---

## Task 10: 路由配置 + i18n

**Files:**
- Modify: `src/router/routes.ts`
- Modify: `src/i18n/messages/zh-CN.ts`

- [ ] **Step 1: 添加 skill-store 路由**

在 `src/router/routes.ts` 的 children 数组中，`skills` 路由（约 line 91）之后追加：

```typescript
{
  path: 'skill-store',
  name: 'SkillStore',
  component: () => import('@/views/skill-store/SkillStorePage.vue'),
  meta: { titleKey: 'routes.skillStore', icon: 'StorefrontOutline' },
},
```

- [ ] **Step 2: 添加 i18n 翻译**

在 `src/i18n/messages/zh-CN.ts` 的 `routes` 对象中追加：

```typescript
skillStore: '技能商店',
```

在 `src/i18n/messages/zh-CN.ts` 的 `pages` 对象中追加 `skillStore` 子对象：

```typescript
skillStore: {
  title: '技能商店',
  tabs: { store: '技能商店', manage: '技能管理' },
  globalInstall: '已全局内置',
  storeEmpty: '暂无技能，点击扫描按钮同步 Gateway 技能',
  scanButton: '扫描技能',
  scanning: '扫描中...',
  searchPlaceholder: '搜索技能...',
  categoryAll: '全部',
  installButton: '添加到智能体',
  deleteButton: '删除',
  installed: '已安装',
  notInstalled: '未安装',
  statusEnabled: '已启动',
  statusDisabled: '已关闭',
  selectAgent: {
    title: '选择数字员工',
    installed: '已安装',
    confirm: '确认安装',
    cancel: '取消',
    empty: '暂无可用的数字员工',
  },
  detail: {
    version: '版本',
    category: '分类',
    usage: '使用说明',
    readme: '技能文档',
    agents: '已安装到',
    noAgents: '暂未安装到任何数字员工',
  },
  manage: {
    title: '技能管理',
    empty: '暂无已安装的技能',
    skillName: '技能名称',
    type: '类型',
    version: '版本',
    agents: '数字员工',
    status: '状态',
    actions: '操作',
    builtin: '内置',
    private: '私有',
  },
  toast: {
    scanSuccess: '已扫描 {count} 个技能',
    scanFail: '扫描失败',
    installSuccess: '安装成功',
    installFail: '安装失败',
    deleteSuccess: '删除成功',
    deleteFail: '删除失败',
    toggleSuccess: '操作成功',
    toggleFail: '操作失败',
  },
},
```

- [ ] **Step 3: Commit**

```bash
git add src/router/routes.ts src/i18n/messages/zh-CN.ts
git commit -m "feat: add skill store route and i18n translations"
```

---

## Task 11: 技能商店页面

**Files:**
- Create: `src/views/skill-store/SkillStorePage.vue`

- [ ] **Step 1: 创建 SkillStorePage.vue**

创建目录 `src/views/skill-store/`，然后创建 `SkillStorePage.vue`。

完整实现参考 `docs/skill-store-module.md` 第 7 节。页面结构：

1. **顶部 Tab 栏**：Store / Manage 切换
2. **Store Tab**：
   - 分类栏（全部/featured/general/creative）+ 搜索框 + 扫描按钮
   - 技能网格卡片（图标 + 名称 + 描述 + 安装状态）
   - 「已全局内置」折叠区
3. **Manage Tab**：
   - 已安装技能表格（技能名称/类型/版本/agent 列表/状态/操作）
4. **详情弹窗**：技能描述 + readme + 操作按钮
5. **Agent 选择弹窗**：agent 列表 + 已安装标记 + 确认按钮

数据加载流程（onMounted）：
```typescript
onMounted(async () => {
  gatewaySkills.value = await wsStore.rpc.listSkills()
  await store.refreshAll()
  store.scanGateway()
})
```

allSkills computed 核心逻辑：区分 `source === 'store'`（商店主区域）和其他（全局内置）。

样式：使用项目已有 CSS 变量（`--bg-card`, `--bg`, `--text`, `--border-color`, `--accent` 等），支持深浅模式。

由于此文件较大（约 600-800 行），完整代码参考 `docs/skill-store-module.md` 第 7.1-7.7 节逐段实现。

- [ ] **Step 2: 浏览器验证**

Run: `npm run dev`，打开 `http://localhost:3000`，导航到技能商店页面，验证：
- Tab 切换正常
- 扫描按钮触发后端扫描
- 技能卡片渲染
- 详情弹窗打开/关闭
- Agent 选择弹窗安装流程

- [ ] **Step 3: Commit**

```bash
git add src/views/skill-store/SkillStorePage.vue
git commit -m "feat: add SkillStorePage with store/manage tabs and dialogs"
```

---

## Task 12: 数字员工编辑页技能 Tab

**Files:**
- Modify: `src/views/agent-team/AgentEditPage.vue`

- [ ] **Step 1: 在 AgentEditPage 中添加技能 Tab**

在 `AgentEditPage.vue` 的 tab 列表中追加「技能」tab，实现：

1. `loadAgentSkills()` — 合并后端 DB 技能和 Gateway RPC 技能，区分 agent/global 来源
2. 已安装技能网格 — `skillSource === 'agent'` 的技能
3. 全局内置折叠区 — `skillSource !== 'agent'` 的技能
4. 技能详情弹窗 — agent 技能显示启用/禁用开关，全局技能只显示标签

参考 `docs/skill-store-module.md` 第 8 节的完整逻辑。

关键代码片段（`loadAgentSkills`）：
```typescript
async function loadAgentSkills() {
  const dbSkills = skillStore.skills
  const gwList = await wsStore.rpc.listSkills()
  // 区分 agent/global 来源，构建技能列表
}
```

- [ ] **Step 2: 浏览器验证**

在数字员工编辑页面切换到技能 Tab，验证：
- 已安装技能和全局技能分区显示
- 启用/禁用开关工作正常
- 详情弹窗正确显示

- [ ] **Step 3: Commit**

```bash
git add src/views/agent-team/AgentEditPage.vue
git commit -m "feat: add skills tab to agent edit page with install/toggle support"
```

---

## Task 13: 整体验证

- [ ] **Step 1: 类型检查**

Run: `npx vue-tsc --noEmit`

Expected: 无错误

- [ ] **Step 2: 完整功能验证**

1. 启动 `npm run dev:all`
2. 以 admin 登录
3. 导航到技能商店页面
4. 点击「扫描技能」验证后端 SSH 扫描 Gateway 目录
5. 选择一个技能，点击「添加到智能体」，选择 agent，确认安装
6. 切换到「技能管理」Tab，验证已安装技能列表
7. 切换启用/禁用，验证 SSH 文件操作
8. 导航到数字员工编辑页，技能 Tab，验证技能列表和开关
9. 删除一个技能，验证级联清理
10. 以 test1 登录，验证非 admin 也能使用技能商店

- [ ] **Step 3: Final commit**

```bash
git add -A
git commit -m "feat: complete skill store module"
```
