# 数字员工创建与添加模块实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现两个弹窗（自定义创建 + 推荐添加）+ 进度条组件 + 创建逻辑 composable + 跨页面自动发消息

**Architecture:** 提取 `useAgentCreation` composable 封装 Gateway 创建 → md 文件写入 → 后端注册的全流程；两个弹窗直接调用 composable 并管理进度条状态；创建成功后通过 URL query 传递 `greet=1` 到 Workspace 页自动发送问候语。

**Tech Stack:** Vue 3 + TypeScript + Naive UI + Pinia + Vue Router

---

## 文件结构映射

| 文件 | 操作 | 职责 |
|------|------|------|
| `src/composables/useAgentCreation.ts` | **新增** | 封装完整的创建流程（Gateway create → setAgentFile → backend API），支持 onProgress 回调 |
| `src/components/CreateProgressBar.vue` | **新增** | 共用进度条组件，Props: progress, statusText, subText |
| `src/views/agent-team/AgentAddDetailModal.vue` | **新增** | 推荐员工详情弹窗，展示模板信息 + 添加按钮 + 进度条 |
| `src/views/agent-team/CreateAgentModal.vue` | **重写** | 自定义创建弹窗，含表单验证、头像选择、模型选择、进度条 |
| `src/views/agent-team/AgentTeamPage.vue` | **修改** | 移除内联 handleCreated，改为导入 useAgentCreation；集成两个弹窗的 show 控制 |
| `src/views/agent-team/AgentTemplateGrid.vue` | **修改** | 点击模板卡片 emit 打开详情弹窗事件，不再直接创建 |
| `src/views/workspace/WorkspacePage.vue` | **修改** | 在 selectAgent 后检测 route.query.greet，自动发消息并清除参数 |
| `src/i18n/messages/zh-CN.ts` | **修改** | 新增弹窗相关文案 |

---

### Task 1: useAgentCreation Composable

**Files:**
- Create: `src/composables/useAgentCreation.ts`

- [ ] **Step 1: 创建 composable 文件**

```typescript
import { useWebSocketStore } from '@/stores/websocket'
import { useAuthStore } from '@/stores/auth'
import { useAgentTeamStore } from '@/stores/agent-team'
import { buildUserMdWithWorkspaceRules } from '@/config/agent-templates'

export interface CreateAgentParams {
  name: string
  avatar: string
  description: string
  category: string
  templateId: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  workStyle?: string
  model?: string
}

export interface CreateAgentResult {
  agentId: string
  gatewayAgentId: string
  workspacePath: string
}

function sanitizeWorkspaceSegment(value: string, fallback: string): string {
  const sanitized = value
    .trim()
    .replace(/[\\/:*?"<>|\x00-\x1F]/g, '-')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
  return sanitized || fallback
}

function formatWorkspaceTimestamp(date = new Date()): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

export function useAgentCreation() {
  const wsStore = useWebSocketStore()
  const authStore = useAuthStore()
  const store = useAgentTeamStore()

  async function createAgent(
    params: CreateAgentParams,
    onProgress?: (progress: number, stage: string) => void
  ): Promise<CreateAgentResult> {
    const agentSlug = `agent-${Date.now()}`
    const displayName = sanitizeWorkspaceSegment(
      authStore.currentUser?.display_name || authStore.currentUser?.username || '',
      'user'
    )
    const userName = sanitizeWorkspaceSegment(
      authStore.currentUser?.username || '',
      'user'
    )
    const workspaceFolder = `${displayName}-${userName}`
    const workspaceAgent = sanitizeWorkspaceSegment(params.name, 'agent')
    const workspaceTime = formatWorkspaceTimestamp()
    const workspaceName = `${displayName}的${workspaceAgent}-${workspaceTime}`
    const workspacePath = `~/.wattclaw/${workspaceFolder}/${workspaceName}`

    const config = await wsStore.rpc.getConfig()
    const defaultModel = config?.models?.primary || config?.agents?.defaults?.model?.primary || ''
    const model = params.model || defaultModel

    const createResult = await wsStore.rpc.createAgent({
      name: agentSlug,
      workspace: workspacePath,
      ...(model ? { model } : {}),
      emoji: params.avatar,
    })
    onProgress?.(20, '创建中...')

    const gatewayAgentId = createResult.agentId || createResult.name || agentSlug

    const mergedUserMd = buildUserMdWithWorkspaceRules(params.userMd, workspacePath)
    const mdFiles = ([
      ['SOUL.md', params.soulMd],
      ['AGENTS.md', params.agentsMd],
      ['IDENTITY.md', params.identityMd],
      ['USER.md', mergedUserMd],
    ] as [string, string][]).filter(([, content]) => content)

    const progressMap = [35, 50, 65, 80]
    const stageMap = ['配置资源', '初始化知识库', '初始化知识库', '下载资源']

    for (let i = 0; i < mdFiles.length; i++) {
      const [name, content] = mdFiles[i]!
      await wsStore.rpc.setAgentFile(gatewayAgentId, name, content)
      onProgress?.(progressMap[i]!, stageMap[i]!)
    }

    const token = authStore.getToken()
    if (token) {
      fetch('/api/agent-team/complete-bootstrap', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspacePath }),
      }).catch(() => {})
    }

    let dbAgent: { id: string }
    try {
      dbAgent = await store.createAgent({
        name: params.name,
        avatar: params.avatar,
        description: params.description,
        category: params.category,
        templateId: params.templateId,
        gatewayAgentId,
        model,
      })
    } catch (dbErr: any) {
      try { await wsStore.rpc.deleteAgent(gatewayAgentId) } catch {}
      throw dbErr
    }

    onProgress?.(100, '完成')

    return {
      agentId: dbAgent.id,
      gatewayAgentId,
      workspacePath,
    }
  }

  return { createAgent }
}
```

- [ ] **Step 2: Commit**

```bash
git add src/composables/useAgentCreation.ts
git commit -m "feat: add useAgentCreation composable with progress callback"
```

---

### Task 2: CreateProgressBar Component

**Files:**
- Create: `src/components/CreateProgressBar.vue`

- [ ] **Step 1: 创建进度条组件**

```vue
<script setup lang="ts">
interface Props {
  progress: number
  statusText: string
  subText: string
}

defineProps<Props>()
</script>

<template>
  <div class="create-progress">
    <div class="progress-labels">
      <span class="progress-status">{{ statusText }}</span>
      <span class="progress-sub">{{ subText }}</span>
    </div>
    <div class="progress-track">
      <div
        class="progress-fill"
        :style="{ width: `${Math.min(100, Math.max(0, progress))}%` }"
      />
    </div>
  </div>
</template>

<style scoped>
.create-progress {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.progress-labels {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
}

.progress-status {
  color: var(--text-primary, #1f2937);
  font-weight: 500;
}

.progress-sub {
  color: var(--text-secondary, #6b7280);
}

.progress-track {
  height: 6px;
  background: var(--border-color, #e5e7eb);
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #3b82f6, #60a5fa);
  border-radius: 3px;
  transition: width 0.3s ease;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add src/components/CreateProgressBar.vue
git commit -m "feat: add CreateProgressBar shared component"
```

---

### Task 3: AgentAddDetailModal Component

**Files:**
- Create: `src/views/agent-team/AgentAddDetailModal.vue`
- Modify: `src/views/agent-team/AgentTemplateGrid.vue` (emit 事件调整)

- [ ] **Step 1: 创建添加详情弹窗**

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { NButton, NModal, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar } from '@/utils/agent-avatar'
import { useAgentCreation } from '@/composables/useAgentCreation'
import CreateProgressBar from '@/components/CreateProgressBar.vue'

const props = defineProps<{
  show: boolean
  template: AgentTemplate | null
}>()

const emit = defineEmits<{
  'update:show': [value: boolean]
}>()

const { t } = useI18n()
const router = useRouter()
const message = useMessage()
const { createAgent } = useAgentCreation()

const isAdding = ref(false)
const progress = ref(0)
const stageText = ref('创建中...')
const subText = ref('下载资源')
let progressTimer: ReturnType<typeof setInterval> | null = null

function startSimulatedProgress() {
  progress.value = 0
  progressTimer = setInterval(() => {
    if (progress.value < 85) {
      progress.value += 2
    }
  }, 100)
}

function stopSimulatedProgress() {
  if (progressTimer) {
    clearInterval(progressTimer)
    progressTimer = null
  }
}

function handleProgress(p: number, stage: string) {
  progress.value = p
  stageText.value = stage
}

async function handleAdd() {
  if (!props.template || isAdding.value) return
  isAdding.value = true
  startSimulatedProgress()

  try {
    const result = await createAgent({
      name: props.template.name,
      avatar: props.template.avatar,
      description: props.template.description,
      category: props.template.category,
      templateId: props.template.id,
      soulMd: props.template.soulMd,
      agentsMd: props.template.agentsMd,
      identityMd: props.template.identityMd,
      userMd: props.template.userMd,
    }, handleProgress)

    stopSimulatedProgress()
    progress.value = 100

    setTimeout(() => {
      emit('update:show', false)
      isAdding.value = false
      progress.value = 0
      stageText.value = '创建中...'

      router.push({
        name: 'Workspace',
        query: { agentId: result.agentId, greet: '1' }
      })
    }, 300)
  } catch (err: any) {
    stopSimulatedProgress()
    isAdding.value = false
    progress.value = 0
    message.error(err.message || t('pages.agentTeam.messages.createFailed') || '创建失败')
  }
}

function handleClose() {
  if (isAdding.value) return
  emit('update:show', false)
}
</script>

<template>
  <NModal
    :show="show"
    @update:show="handleClose"
    :mask-closable="!isAdding"
  >
    <div class="add-detail-modal">
      <button class="modal-close" @click="handleClose">
        <span class="material-symbols-outlined">close</span>
      </button>

      <div class="modal-header-center">
        <div class="modal-avatar">
          <img v-if="template && isImageAvatar(template.avatar)" :src="template.avatar" :alt="template.name" />
          <span v-else>{{ template?.avatar }}</span>
        </div>
        <h3 class="modal-title">{{ template?.name }}</h3>
      </div>

      <div class="modal-section">
        <div class="section-title">
          <span class="material-symbols-outlined">auto_awesome</span>
          <span>员工介绍</span>
        </div>
        <p class="section-text">{{ template?.description }}</p>
      </div>

      <div class="modal-section">
        <div class="section-title">
          <span class="material-symbols-outlined">description</span>
          <span>怎么使用？</span>
        </div>
        <div class="usage-list">
          <ul>
            <li v-for="(prompt, index) in template?.prompts" :key="index">{{ prompt }}</li>
          </ul>
        </div>
      </div>

      <div v-if="isAdding" class="progress-area">
        <CreateProgressBar
          :progress="progress"
          :status-text="stageText"
          :sub-text="subText"
        />
      </div>

      <NButton
        type="primary"
        block
        :disabled="isAdding"
        :loading="isAdding"
        class="add-btn"
        @click="handleAdd"
      >
        {{ isAdding ? '创建中...' : '添加' }}
      </NButton>

      <div class="security-hint">
        <span class="material-symbols-outlined" style="color: #22c55e;">verified_user</span>
        <span>已通过安全合规验证，无恶意代码或数据泄露风险。</span>
      </div>
    </div>
  </NModal>
</template>

<style scoped>
.add-detail-modal {
  background: var(--bg-card, #ffffff);
  border-radius: 12px;
  padding: 24px;
  width: 480px;
  max-width: 90vw;
  max-height: 80vh;
  overflow-y: auto;
  position: relative;
}

.modal-close {
  position: absolute;
  top: 16px;
  right: 16px;
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-secondary, #6b7280);
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-close:hover {
  color: var(--text-primary, #1f2937);
}

.modal-header-center {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
}

.modal-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: var(--bg-secondary, #f3f4f6);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  overflow: hidden;
}

.modal-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.modal-title {
  font-size: 18px;
  font-weight: 700;
  margin: 0;
  color: var(--text-primary, #1f2937);
}

.modal-section {
  margin-bottom: 20px;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary, #1f2937);
  margin-bottom: 8px;
}

.section-title .material-symbols-outlined {
  font-size: 18px;
  color: var(--primary, #3b82f6);
}

.section-text {
  font-size: 14px;
  line-height: 1.6;
  color: var(--text-secondary, #4b5563);
  margin: 0;
}

.usage-list {
  background: var(--bg-secondary, #f9fafb);
  border-radius: 8px;
  padding: 12px 16px;
}

.usage-list ul {
  margin: 0;
  padding-left: 16px;
}

.usage-list li {
  font-size: 14px;
  line-height: 1.8;
  color: var(--text-secondary, #4b5563);
}

.progress-area {
  margin-bottom: 16px;
}

.add-btn {
  background: #1a1a1a;
  color: #fff;
  border: none;
  height: 44px;
  font-size: 15px;
  font-weight: 500;
}

.add-btn:hover {
  background: #333;
}

.add-btn:disabled {
  background: #9ca3af;
  cursor: not-allowed;
}

.security-hint {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-top: 12px;
  font-size: 12px;
  color: var(--text-secondary, #6b7280);
}
</style>
```

- [ ] **Step 2: 修改 AgentTemplateGrid 触发方式**

在 `AgentTemplateGrid.vue` 中，将 `selectTemplate` 事件的语义改为"打开详情"而非直接创建。修改 `handleSelectTemplate` 函数名或保持 emit 名不变，父组件改为打开 `AgentAddDetailModal`。

具体修改：`AgentTeamPage.vue` 中监听 `@select-template` 时改为打开 `AgentAddDetailModal`（在 Task 6 中完成）。

- [ ] **Step 3: Commit**

```bash
git add src/views/agent-team/AgentAddDetailModal.vue
git commit -m "feat: add AgentAddDetailModal for template-based agent creation"
```

---

### Task 4: CreateAgentModal (重写)

**Files:**
- Modify: `src/views/agent-team/CreateAgentModal.vue`

- [ ] **Step 1: 重写 CreateAgentModal**

```vue
<script setup lang="ts">
import { ref, watch } from 'vue'
import { NButton, NInput, NModal, NCollapse, NCollapseItem, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import ModelDropdown from '@/components/ModelDropdown.vue'
import { useAgentCreation } from '@/composables/useAgentCreation'
import CreateProgressBar from '@/components/CreateProgressBar.vue'

const props = defineProps<{
  show: boolean
}>()

const emit = defineEmits<{
  'update:show': [value: boolean]
}>()

const { t } = useI18n()
const router = useRouter()
const message = useMessage()
const { createAgent } = useAgentCreation()

const name = ref('')
const avatar = ref('🤖')
const description = ref('')
const workStyle = ref('')
const model = ref('')

const isCreating = ref(false)
const progress = ref(0)
const stageText = ref('创建中...')
const subText = ref('下载资源')
let progressTimer: ReturnType<typeof setInterval> | null = null

const avatarOptions = ['🤖', '📁', '👤', '🔍', '🦊', '🐦', '📄', '📊', '🎨', '🎵', '🌍', '💡']

watch(() => props.show, (val) => {
  if (val) {
    name.value = ''
    avatar.value = '🤖'
    description.value = ''
    workStyle.value = ''
    model.value = ''
    isCreating.value = false
    progress.value = 0
    stageText.value = '创建中...'
  }
})

function startSimulatedProgress() {
  progress.value = 0
  progressTimer = setInterval(() => {
    if (progress.value < 85) {
      progress.value += 2
    }
  }, 100)
}

function stopSimulatedProgress() {
  if (progressTimer) {
    clearInterval(progressTimer)
    progressTimer = null
  }
}

function handleProgress(p: number, stage: string) {
  progress.value = p
  stageText.value = stage
}

function buildSoulMd(): string {
  const n = name.value.trim()
  const d = description.value.trim()
  return `# ${n}\n\n${d || '帮助用户完成指定工作'}\n\n## 初始化规则\n\n你已经知道自己是${n}，不要反复确认身份。直接处理用户任务。`
}

function buildIdentityMd(): string {
  const n = name.value.trim()
  const ws = workStyle.value.trim()
  const parts = [`名称: ${n}`]
  if (ws) parts.push(`工作风格: ${ws}`)
  parts.push('语气: 清晰、自然、高效')
  parts.push('回复风格: 直接围绕用户任务工作，避免重复身份初始化。')
  return parts.join('\n')
}

async function handleCreate() {
  const trimmedName = name.value.trim()
  if (!trimmedName) return
  if (isCreating.value) return

  isCreating.value = true
  startSimulatedProgress()

  try {
    const result = await createAgent({
      name: trimmedName,
      avatar: avatar.value,
      description: description.value.trim(),
      category: '',
      templateId: '',
      soulMd: buildSoulMd(),
      agentsMd: '',
      identityMd: buildIdentityMd(),
      userMd: '',
      workStyle: workStyle.value.trim(),
      model: model.value || undefined,
    }, handleProgress)

    stopSimulatedProgress()
    progress.value = 100

    setTimeout(() => {
      emit('update:show', false)
      isCreating.value = false
      progress.value = 0

      router.push({
        name: 'Workspace',
        query: { agentId: result.agentId, greet: '1' }
      })
    }, 300)
  } catch (err: any) {
    stopSimulatedProgress()
    isCreating.value = false
    progress.value = 0
    message.error(err.message || t('pages.agentTeam.messages.createFailed') || '创建失败')
  }
}

function handleClose() {
  if (isCreating.value) return
  emit('update:show', false)
}
</script>

<template>
  <NModal
    :show="show"
    @update:show="handleClose"
    :mask-closable="!isCreating"
  >
    <div class="create-agent-modal">
      <div class="modal-header">
        <div class="header-text">
          <h3 class="modal-title">欢迎创建你的专属数字员工</h3>
          <p class="modal-subtitle">
            数字员工不仅是一个聊天机器人，它更是基于 Agent（智能体）架构的"数字同事"。它能独立思考、拆解任务，并调用技能工具自主解决问题。
          </p>
        </div>
        <button class="modal-close" @click="handleClose">
          <span class="material-symbols-outlined">close</span>
        </button>
      </div>

      <div class="form-body">
        <!-- Avatar + Name row -->
        <div class="avatar-name-row">
          <div class="avatar-section">
            <div class="current-avatar">{{ avatar }}</div>
            <div class="avatar-options">
              <button
                v-for="emoji in avatarOptions"
                :key="emoji"
                class="avatar-option"
                :class="{ selected: avatar === emoji }"
                @click="avatar = emoji"
              >
                {{ emoji }}
              </button>
            </div>
          </div>

          <div class="name-section">
            <label class="form-label">
              员工名称 <span class="required">*</span>
            </label>
            <NInput
              v-model:value="name"
              placeholder="请输入名字"
              maxlength="15"
              show-count
            />
          </div>
        </div>

        <!-- Description -->
        <div class="form-field">
          <label class="form-label">
            请简要描述该员工的核心职责 <span class="required">*</span>
          </label>
          <NInput
            v-model:value="description"
            type="textarea"
            :rows="4"
            placeholder="例如：负责生成营销文案与品牌传播内容"
            maxlength="100"
            show-count
          />
        </div>

        <!-- Advanced Settings -->
        <NCollapse>
          <NCollapseItem title="高级设置">
            <div class="advanced-content">
              <div class="form-field">
                <label class="form-label">工作风格</label>
                <NInput
                  v-model:value="workStyle"
                  placeholder="例如：专业严谨、幽默风趣、温暖贴心..."
                />
              </div>

              <div class="form-field">
                <label class="form-label">模型</label>
                <ModelDropdown
                  v-model="model"
                  variant="select"
                />
              </div>
            </div>
          </NCollapseItem>
        </NCollapse>

        <!-- Progress -->
        <div v-if="isCreating" class="progress-area">
          <CreateProgressBar
            :progress="progress"
            :status-text="stageText"
            :sub-text="subText"
          />
        </div>

        <!-- Submit -->
        <NButton
          type="primary"
          block
          :disabled="!name.trim() || isCreating"
          :loading="isCreating"
          class="submit-btn"
          @click="handleCreate"
        >
          {{ isCreating ? '创建中...' : '创建' }}
        </NButton>
      </div>
    </div>
  </NModal>
</template>

<style scoped>
.create-agent-modal {
  background: var(--bg-card, #ffffff);
  border-radius: 12px;
  padding: 24px;
  width: 560px;
  max-width: 90vw;
  max-height: 85vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
  gap: 12px;
}

.header-text {
  flex: 1;
}

.modal-title {
  font-size: 18px;
  font-weight: 700;
  margin: 0 0 8px;
  color: var(--text-primary, #1f2937);
}

.modal-subtitle {
  font-size: 13px;
  line-height: 1.5;
  color: var(--text-secondary, #6b7280);
  margin: 0;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-secondary, #6b7280);
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.modal-close:hover {
  color: var(--text-primary, #1f2937);
}

.form-body {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.avatar-name-row {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}

.avatar-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.current-avatar {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: var(--bg-secondary, #f3f4f6);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
}

.avatar-options {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  width: 120px;
  justify-content: center;
}

.avatar-option {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 2px solid transparent;
  background: var(--bg-secondary, #f3f4f6);
  font-size: 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.avatar-option:hover {
  border-color: var(--border-color, #e5e7eb);
}

.avatar-option.selected {
  border-color: var(--primary, #3b82f6);
  background: rgba(59, 130, 246, 0.1);
}

.name-section {
  flex: 1;
}

.form-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-label {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-primary, #1f2937);
}

.required {
  color: #ef4444;
}

.advanced-content {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding-top: 4px;
}

.progress-area {
  margin-top: 4px;
}

.submit-btn {
  background: #1a1a1a;
  color: #fff;
  border: none;
  height: 44px;
  font-size: 15px;
  font-weight: 500;
}

.submit-btn:hover {
  background: #333;
}

.submit-btn:disabled {
  background: #9ca3af;
  cursor: not-allowed;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/CreateAgentModal.vue
git commit -m "feat: rewrite CreateAgentModal with new design, progress bar, and model selection"
```

---

### Task 5: AgentTemplateGrid 触发方式修改

**Files:**
- Modify: `src/views/agent-team/AgentTemplateGrid.vue`

- [ ] **Step 1: 保持 emit 签名不变，父组件改变处理方式**

实际上 `AgentTemplateGrid.vue` 的 emit 签名已经正确（`selectTemplate` 和 `customCreate`），只需要在 `AgentTeamPage.vue` 中改变对 `selectTemplate` 的处理方式。

此任务无需修改 `AgentTemplateGrid.vue` 本身，处理逻辑在 Task 6 中完成。

---

### Task 6: AgentTeamPage 改造

**Files:**
- Modify: `src/views/agent-team/AgentTeamPage.vue`

- [ ] **Step 1: 移除内联 handleCreated，改为导入 useAgentCreation 并集成两个弹窗**

```vue
<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NButton, NInput, NSpin, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import { useAgentTeamStore } from '@/stores/agent-team'
import CreateAgentModal from '@/views/agent-team/CreateAgentModal.vue'
import AgentAddDetailModal from '@/views/agent-team/AgentAddDetailModal.vue'

const route = useRoute()
const router = useRouter()
const store = useAgentTeamStore()
const { t } = useI18n()

const searchQuery = ref('')
const showCreateModal = ref(false)
const showAddDetailModal = ref(false)
const selectedTemplate = ref<AgentTemplate | null>(null)

const activeTab = computed(() => {
  if (route.path.includes('/management')) return 'management'
  return 'market'
})

function switchTab(tab: string) {
  if (tab === 'market') {
    router.push({ name: 'AgentMarket' })
  } else {
    router.push({ name: 'AgentManagement' })
  }
}

function handleSelectTemplate(template: AgentTemplate) {
  selectedTemplate.value = template
  showAddDetailModal.value = true
}

function handleCustomCreate() {
  showCreateModal.value = true
}
</script>

<template>
  <div class="agent-team-page">
    <!-- Header with Tab Switcher -->
    <div class="team-header-bar">
      <div class="tab-switcher">
        <button
          class="tab-btn"
          :class="{ active: activeTab === 'market' }"
          @click="switchTab('market')"
        >
          {{ t('pages.agentTeam.tabMarket') }}
        </button>
        <button
          class="tab-btn"
          :class="{ active: activeTab === 'management' }"
          @click="switchTab('management')"
        >
          {{ t('pages.agentTeam.tabManagement') }}
        </button>
      </div>

      <div v-if="activeTab === 'market'" class="header-tools">
        <NInput
          v-model:value="searchQuery"
          clearable
          :placeholder="t('pages.agentMarket.searchPlaceholder')"
          class="search-input"
        >
          <template #prefix>
            <span class="material-symbols-outlined" style="font-size: 18px;">search</span>
          </template>
        </NInput>
        <NButton type="primary" class="create-btn" @click="showCreateModal = true">
          <span class="material-symbols-outlined" style="font-size: 18px; margin-right: 4px;">add</span>
          {{ t('pages.agentMarket.create') }}
        </NButton>
      </div>
    </div>

    <!-- Content -->
    <div class="team-content">
      <router-view v-slot="{ Component }">
        <component
          :is="Component"
          :search-query="searchQuery"
          @select-template="handleSelectTemplate"
          @custom-create="handleCustomCreate"
          class="team-view"
        />
      </router-view>
    </div>

    <CreateAgentModal v-model:show="showCreateModal" />
    <AgentAddDetailModal v-model:show="showAddDetailModal" :template="selectedTemplate" />
  </div>
</template>

<style scoped>
/* 保持原有样式不变 */
.agent-team-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.team-header-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 24px;
  border-bottom: 1px solid var(--border-color, #e5e7eb);
  background: var(--bg-card, #ffffff);
  flex-shrink: 0;
}

.tab-switcher {
  display: flex;
  gap: 4px;
}

.tab-btn {
  padding: 8px 16px;
  border: none;
  background: transparent;
  color: var(--text-secondary, #6b7280);
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  position: relative;
  transition: color 0.2s ease;
}

.tab-btn:hover {
  color: var(--text-primary, #111827);
}

.tab-btn.active {
  color: var(--text-primary, #111827);
  font-weight: 600;
}

.tab-btn.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 12px;
  right: 12px;
  height: 2px;
  background: var(--primary, #3b82f6);
  border-radius: 1px;
}

.header-tools {
  display: flex;
  align-items: center;
  gap: 12px;
}

.search-input {
  width: 280px;
}

.create-btn {
  background: #1a1a1a;
  color: #fff;
  border: none;
}

.create-btn:hover {
  background: #333;
}

.team-content {
  flex: 1;
  overflow: hidden;
  min-height: 0;
}

.team-view {
  height: 100%;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add src/views/agent-team/AgentTeamPage.vue
git commit -m "refactor: AgentTeamPage remove inline handleCreated, integrate both modals"
```

---

### Task 7: WorkspacePage 自动发消息

**Files:**
- Modify: `src/views/workspace/WorkspacePage.vue`

- [ ] **Step 1: 在 onMounted 中增加 greet 参数检测**

找到 `onMounted` 中的 `else if (agentId)` 分支，在其后增加问候语发送逻辑：

```typescript
// 在 onMounted 内部
} else if (agentId) {
  await workspaceStore.selectAgent(agentId)

  // 新增：自动发送问候语
  if (route.query.greet === '1') {
    const agent = workspaceStore.selectedAgent
    if (agent) {
      const greeting = buildGreeting(agent)
      await workspaceStore.sendMessage(greeting)
    }
    // 清除参数，防止刷新重复发送
    router.replace({ query: { ...route.query, greet: undefined } })
  }
}
```

同时在 `<script setup>` 顶部增加 `buildGreeting` 辅助函数：

```typescript
function buildGreeting(agent: { name?: string; description?: string }): string {
  const name = agent.name || '数字员工'
  const desc = agent.description || ''
  if (desc) {
    return `你好，我是${name}，${desc}，有什么可以帮你的？`
  }
  return `你好，我是${name}，有什么可以帮你的？`
}
```

- [ ] **Step 2: Commit**

```bash
git add src/views/workspace/WorkspacePage.vue
git commit -m "feat: auto-send greeting message when navigating to workspace with greet=1"
```

---

### Task 8: i18n 文案

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`

- [ ] **Step 1: 在 pages.agentTeam.create 下新增文案**

在 `src/i18n/messages/zh-CN.ts` 的 `pages.agentTeam.create` 对象中增加以下 key：

```typescript
create: {
  // ... 现有 key ...
  welcomeTitle: '欢迎创建你的专属数字员工',
  welcomeSubtitle: '数字员工不仅是一个聊天机器人，它更是基于 Agent（智能体）架构的"数字同事"。它能独立思考、拆解任务，并调用技能工具自主解决问题。',
  nameRequired: '员工名称',
  descRequired: '请简要描述该员工的核心职责',
  descPlaceholderNew: '例如：负责生成营销文案与品牌传播内容',
  advancedSettings: '高级设置',
  workStyleLabel: '工作风格',
  workStylePlaceholder: '例如：专业严谨、幽默风趣、温暖贴心...',
  modelLabel: '模型',
  creating: '创建中...',
  add: '添加',
  employeeIntro: '员工介绍',
  howToUse: '怎么使用？',
  securityHint: '已通过安全合规验证，无恶意代码或数据泄露风险。',
},
```

- [ ] **Step 2: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat: add i18n keys for agent creation modals"
```

---

## 自检

### Spec 覆盖检查

| 设计文档章节 | 对应任务 |
|---|---|
| useAgentCreation composable (3) | Task 1 |
| CreateAgentModal 详细设计 (4) | Task 4 |
| AgentAddDetailModal 详细设计 (5) | Task 3 |
| CreateProgressBar (6) | Task 2 |
| 跨页面自动发消息 (7) | Task 7 |
| AgentTemplateGrid 触发 (5.4) | Task 5/6 |
| i18n 文案 | Task 8 |

### Placeholder 扫描

- [x] 无 "TBD", "TODO", "implement later"
- [x] 每个代码步骤包含完整代码
- [x] 无 "Similar to Task N" 引用
- [x] 类型和函数名在所有任务中一致

### 类型一致性

- `useAgentCreation().createAgent` 的签名在所有调用处一致
- `AgentTemplate` 类型引用正确
- `CreateAgentParams` 和 `CreateAgentResult` 在定义和调用处一致

---

## 执行选项

**Plan complete and saved to `docs/superpowers/plans/2026-05-13-agent-creation-modal.md`.**

Two execution options:

**1. Subagent-Driven (recommended)** - I dispatch a fresh subagent per task, review between tasks, fast iteration

**2. Inline Execution** - Execute tasks in this session using executing-plans, batch execution with checkpoints

Which approach?