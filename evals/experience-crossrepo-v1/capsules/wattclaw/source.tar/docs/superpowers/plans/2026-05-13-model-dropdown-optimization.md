# 模型选择下拉框优化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为模型下拉框添加供应商图标和固定优先级排序，提升可读性。

**Architecture:** 最小改动方案。新增 SVG 图标资源和 `provider-icon.ts` 映射工具；在 `useModelProviders.ts` 的 `modelList` computed 中注入排序逻辑；在 `ModelDropdown.vue` 的 `dd-item` 模板中插入图标 `<img>`。保留所有现有右侧标签逻辑。

**Tech Stack:** Vue 3, TypeScript, Vite, Naive UI (仅触发器样式)

---

## File Structure

| File | Action | Responsibility |
|---|---|---|
| `src/assets/icons/providers/*.svg` | Create ×7 | 7 个供应商品牌图标（单色/反色，适配暗色模式） |
| `src/utils/provider-icon.ts` | Create | `providerId → SVG URL` 映射函数 |
| `src/composables/useModelProviders.ts` | Modify | 在 `modelList` computed 中添加固定优先级排序 |
| `src/components/ModelDropdown.vue` | Modify | 在 `dd-item` 中插入图标；添加 `.provider-icon` 样式 |

---

## Task 1: 创建 SVG 图标资产

**Files:**
- Create: `src/assets/icons/providers/minimax.svg`
- Create: `src/assets/icons/providers/deepseek.svg`
- Create: `src/assets/icons/providers/gpt.svg`
- Create: `src/assets/icons/providers/claude.svg`
- Create: `src/assets/icons/providers/zai.svg`
- Create: `src/assets/icons/providers/ollama.svg`
- Create: `src/assets/icons/providers/xiaomi.svg`

**Step 1: 创建目录**

Run:
```bash
mkdir -p src/assets/icons/providers
```

**Step 2: 写入 `minimax.svg`**

Write `src/assets/icons/providers/minimax.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <rect x="2" y="8" width="2.5" height="8" rx="1.25"/>
  <rect x="6.5" y="4" width="2.5" height="16" rx="1.25"/>
  <rect x="11" y="7" width="2.5" height="10" rx="1.25"/>
  <rect x="15.5" y="2" width="2.5" height="20" rx="1.25"/>
  <rect x="20" y="6" width="2.5" height="12" rx="1.25"/>
</svg>
```

**Step 3: 写入 `deepseek.svg`**

Write `src/assets/icons/providers/deepseek.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M12 2C9.5 2 7.2 3.1 5.7 4.9c-.3.4-.2 1 .2 1.3.4.3 1 .2 1.3-.2.9-1.1 2.2-1.8 3.6-1.9h.4c2.5 0 4.8 1.7 5.4 4.2.1.5.6.8 1.1.7.5-.1.8-.6.7-1.1C17.6 4.5 15 2.2 12 2z"/>
  <path d="M19.5 9.5c-.5-.2-1.1.1-1.3.6-.4 1.1-1.1 2-2 2.7-.5.4-.5 1-.2 1.4.4.4 1 .5 1.4.1 1.3-1 2.2-2.4 2.8-3.9.2-.5-.1-1.1-.6-1.3z"/>
  <path d="M20 15c-.5 0-1 .4-1 1 0 2.2-.9 4.2-2.3 5.7-.4.4-.3 1 .1 1.4.4.4 1 .3 1.4-.1 1.7-1.9 2.7-4.4 2.7-7 0-.6-.4-1-1-1z"/>
  <path d="M4 12c-.6 0-1 .4-1 1 0 3.9 2.2 7.3 5.4 9 .5.3 1.1.1 1.4-.4.3-.5.1-1.1-.4-1.4C6.7 18.8 5 16 5 13c0-.6-.4-1-1-1z"/>
  <path d="M12 7c-3.3 0-6 2.7-6 6s2.7 6 6 6 6-2.7 6-6-2.7-6-6-6zm0 10c-2.2 0-4-1.8-4-4s1.8-4 4-4 4 1.8 4 4-1.8 4-4 4z"/>
</svg>
```

**Step 4: 写入 `gpt.svg`**

Write `src/assets/icons/providers/gpt.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M22.5 10.5c-.8-.5-1.8-.6-2.7-.3-.2-.8-.6-1.5-1.2-2.1-.6-.6-1.3-1-2.1-1.2.3-.9.2-1.9-.3-2.7-.5-.8-1.3-1.3-2.2-1.5-.9-.2-1.9 0-2.7.5-.7-.7-1.7-1.1-2.7-1.1s-2 .4-2.7 1.1c-.8-.5-1.8-.7-2.7-.5-.9.2-1.7.7-2.2 1.5-.5.8-.6 1.8-.3 2.7-.8.2-1.5.6-2.1 1.2-.6.6-1 1.3-1.2 2.1-.9-.3-1.9-.2-2.7.3-.8.5-1.3 1.3-1.5 2.2-.2.9 0 1.9.5 2.7-.7.7-1.1 1.7-1.1 2.7s.4 2 1.1 2.7c-.5.8-.7 1.8-.5 2.7.2.9.7 1.7 1.5 2.2.8.5 1.8.6 2.7.3.2.8.6 1.5 1.2 2.1.6.6 1.3 1 2.1 1.2-.3.9-.2 1.9.3 2.7.5.8 1.3 1.3 2.2 1.5.9.2 1.9 0 2.7-.5.7.7 1.7 1.1 2.7 1.1s2-.4 2.7-1.1c.8.5 1.8.7 2.7.5.9-.2 1.7-.7 2.2-1.5.5-.8.6-1.8.3-2.7.8-.2 1.5-.6 2.1-1.2.6-.6 1-1.3 1.2-2.1.9.3 1.9.2 2.7-.3.8-.5 1.3-1.3 1.5-2.2.2-.9 0-1.9-.5-2.7.7-.7 1.1-1.7 1.1-2.7s-.4-2-1.1-2.7c.5-.8.7-1.8.5-2.7-.2-.9-.7-1.7-1.5-2.2-.8-.5-1.8-.6-2.7-.3-.2-.8-.6-1.5-1.2-2.1-.6-.6-1.3-1-2.1-1.2zM12 18c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z"/>
</svg>
```

**Step 5: 写入 `claude.svg`**

Write `src/assets/icons/providers/claude.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.2l7.5 3.8L12 11.8 4.5 8l7.5-3.8zM4 9.5l7 3.5v6.8l-7-3.5V9.5zm9 10.3v-6.8l7-3.5v6.8l-7 3.5z"/>
</svg>
```

**Step 6: 写入 `zai.svg`**

Write `src/assets/icons/providers/zai.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M4 4h10l-6 8h6L6 20h12v-4h-4l6-8h-6l4-4H4v4z"/>
</svg>
```

**Step 7: 写入 `ollama.svg`**

Write `src/assets/icons/providers/ollama.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M12 2C8 2 5 5 5 9c0 2 .8 3.8 2.2 5.2-.4.3-.7.7-.7 1.3 0 .8.7 1.5 1.5 1.5.3 0 .5-.1.7-.2.5 1.2 1.5 2.1 2.8 2.5v1.7c0 .6.4 1 1 1s1-.4 1-1v-1.7c1.3-.4 2.3-1.3 2.8-2.5.2.1.5.2.7.2.8 0 1.5-.7 1.5-1.5 0-.6-.3-1-.7-1.3C18.2 12.8 19 11 19 9c0-4-3-7-7-7zm0 2c2.8 0 5 2.2 5 5 0 1.5-.7 2.8-1.7 3.7-.5-.3-1.1-.5-1.7-.5-.6 0-1.2.2-1.7.5-1-.9-1.7-2.2-1.7-3.7 0-2.8 2.2-5 5-5z"/>
</svg>
```

**Step 8: 写入 `xiaomi.svg`**

Write `src/assets/icons/providers/xiaomi.svg`:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
  <path d="M2 4h4v12h4V4h4v12h4V4h4v16H2V4z"/>
</svg>
```

---

## Task 2: 创建 provider-icon.ts 映射工具

**Files:**
- Create: `src/utils/provider-icon.ts`

**Step 1: 写入映射文件**

Write `src/utils/provider-icon.ts`:

```typescript
// src/utils/provider-icon.ts
// Maps providerId to SVG icon URL.
// Uses Vite's static asset handling: new URL('@/assets/...', import.meta.url).href

const PROVIDER_ICON_MAP: Record<string, string> = {
  minimax: new URL('@/assets/icons/providers/minimax.svg', import.meta.url).href,
  deepseek: new URL('@/assets/icons/providers/deepseek.svg', import.meta.url).href,
  gpt: new URL('@/assets/icons/providers/gpt.svg', import.meta.url).href,
  claude: new URL('@/assets/icons/providers/claude.svg', import.meta.url).href,
  zai: new URL('@/assets/icons/providers/zai.svg', import.meta.url).href,
  ollama: new URL('@/assets/icons/providers/ollama.svg', import.meta.url).href,
  xiaomi: new URL('@/assets/icons/providers/xiaomi.svg', import.meta.url).href,
}

export function getProviderIconUrl(providerId: string): string | undefined {
  return PROVIDER_ICON_MAP[providerId]
}
```

**Step 2: 验证映射可访问**

在 `ModelDropdown.vue` 同目录下快速测试（临时，验证后删除）：

Run:
```bash
npx vite-node -e "import { getProviderIconUrl } from './src/utils/provider-icon.ts'; console.log(getProviderIconUrl('deepseek'));"
```

Expected: 输出一个以 `data:image/svg+xml` 或 `/src/assets/...` 开头的 URL 字符串（Vite 开发模式下）。

> 如果 `vite-node` 不可用，跳过此步，在 Task 5 的构建验证中一并检查。

---

## Task 3: 修改 useModelProviders.ts 添加排序逻辑

**Files:**
- Modify: `src/composables/useModelProviders.ts`

**Step 1: 在文件顶部引入排序常量**

在 `src/composables/useModelProviders.ts` 中，`const providers = ref<any[]>([])` 之前添加：

```typescript
const PROVIDER_PRIORITY: Record<string, number> = {
  minimax: 1,
  deepseek: 2,
  gpt: 3,
  claude: 4,
  zai: 5,
  ollama: 6,
  xiaomi: 7,
}

function getProviderPriority(providerId: string): number {
  return PROVIDER_PRIORITY[providerId] ?? Infinity
}
```

**Step 2: 修改 `modelList` computed 注入排序**

找到现有的 `modelList` computed（约第 93-116 行），将 `return result` 替换为：

```typescript
  return result.sort((a, b) => {
    const pa = getProviderPriority(a.providerId)
    const pb = getProviderPriority(b.providerId)
    if (pa !== pb) return pa - pb
    return a.label.localeCompare(b.label)
  })
```

完整替换后的 `modelList` computed 如下：

```typescript
const modelList = computed<ModelOption[]>(() => {
  const seen = new Set<string>()
  const result: ModelOption[] = []

  for (const provider of providers.value) {
    const config = provider.config || {}
    const models = extractModelsFromConfig(config)
    const descriptionMeta = parseProviderDescriptionMeta(provider.description)
    for (const m of models) {
      if (seen.has(m.id)) continue
      seen.add(m.id)
      const meta = descriptionMeta[m.id] || {}
      result.push({
        id: m.id,
        label: m.name || m.id,
        providerId: provider.providerId,
        remark: (meta.remark || m.remark || provider.remark || '').toString(),
        description: (meta.description || '').toString(),
      })
    }
  }

  return result.sort((a, b) => {
    const pa = getProviderPriority(a.providerId)
    const pb = getProviderPriority(b.providerId)
    if (pa !== pb) return pa - pb
    return a.label.localeCompare(b.label)
  })
})
```

**Step 3: 类型检查**

Run:
```bash
npx vue-tsc --noEmit
```

Expected: 无新增类型错误。

---

## Task 4: 修改 ModelDropdown.vue 添加图标渲染

**Files:**
- Modify: `src/components/ModelDropdown.vue`

**Step 1: 引入 `getProviderIconUrl`**

在 `<script setup>` 的 import 区域（第 1-6 行附近），在 `useWorkspaceStore` 的 import 之后添加：

```typescript
import { getProviderIconUrl } from '@/utils/provider-icon'
```

**Step 2: 在 chip variant 的 `dd-item` 中插入图标**

找到 chip variant 的下拉项模板（约第 200-213 行）：

```vue
        <div
          v-for="model in modelList"
          :key="model.id"
          class="dd-item"
          :class="{ active: model.id === modelValue }"
          @click="selectModel(model.id)"
          @mouseenter="onItemEnter(model.id, $event)"
          @mouseleave="onItemLeave"
        >
          <span class="dd-name">{{ model.label || model.id }}</span>
```

在 `<span class="dd-name">` 之前插入图标：

```vue
          <img
            v-if="getProviderIconUrl(model.providerId)"
            :src="getProviderIconUrl(model.providerId)"
            class="provider-icon"
            alt=""
          />
```

**Step 3: 在 select variant 的 `dd-item` 中插入图标**

找到 select variant 的下拉项模板（约第 237-250 行），做同样的插入：

在 `<span class="dd-name">` 之前添加：

```vue
          <img
            v-if="getProviderIconUrl(model.providerId)"
            :src="getProviderIconUrl(model.providerId)"
            class="provider-icon"
            alt=""
          />
```

**Step 4: 添加 `.provider-icon` CSS 样式**

在 `<style scoped>` 区域（约第 470 行的 `.dd-check` 样式之后）添加：

```css
.provider-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  object-fit: contain;
}
```

**Step 5: 确认行对齐**

检查 `.dd-item` 已有 `display: flex; align-items: center; gap: 8px;`，图标会自动与文字垂直居中对齐，无需额外调整。

---

## Task 5: 构建验证

**Files:** 无新增，验证已有修改

**Step 1: 类型检查**

Run:
```bash
npx vue-tsc --noEmit
```

Expected: 无类型错误。

**Step 2: 生产构建**

Run:
```bash
npm run build
```

Expected: 构建成功，`dist/` 目录生成，无报错。

**Step 3: 开发服务器快速验证**

Run:
```bash
npm run dev
```

在浏览器中打开工作台页面，点击模型下拉框，确认：
- 同供应商模型相邻显示（如 DeepSeek 的模型都在一起）
- 每个选项左侧显示 20×20 图标
- 图标与文字垂直居中对齐
- 暗色模式下图标清晰可见（使用 `currentColor` 填充的 SVG 会自动跟随文字颜色）
- 选中、hover、爆满标签等行为正常

---

## Self-Review Checklist

- [x] **Spec coverage:** 图标资产 ✓、排序逻辑 ✓、UI 渲染 ✓、构建验证 ✓
- [x] **Placeholder scan:** 无 TBD/TODO，所有步骤含实际代码
- [x] **Type consistency:** `providerId` 在 `ModelOption` 和 `PROVIDER_PRIORITY` 中类型一致（`string`）
- [x] **File paths:** 所有路径基于实际项目结构（`src/assets/icons/providers/`、`src/utils/provider-icon.ts` 等）
