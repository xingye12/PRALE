# WattClaw 迁移 Implementation Plan

**日期**: 2026-05-22
**状态**: Ready
**部署执行**: 用户手动操作（本 Plan 仅包含代码与配置变更）

---

## 目标

完成 WattClaw 代码侧的 colocated 模式改造，使其支持在同节点（与 Gateway 同一物理机）通过 Docker 运行，无需 SSH/SCP。

---

## 任务拆分

### Task 1: `server/index.js` — SSH 执行降级

**文件**: `server/index.js`
**目标**: 新增 `GATEWAY_DEPLOY_MODE=colocated` 分支，同节点时走 `child_process.spawn` 本地执行。

**具体修改**:
1. 在 `SSH_CONFIG` 定义附近（约第 2619 行），新增环境变量读取：
   ```javascript
   const DEPLOY_MODE = process.env.GATEWAY_DEPLOY_MODE || 'distributed'
   ```
2. 在 `sshExec()` 函数前（约第 2626 行），新增 `localExec` 辅助函数：
   ```javascript
   const { spawn } = require('child_process')

   async function localExec(command, args = []) {
     return new Promise((resolve, reject) => {
       const child = spawn(command, args, { stdio: 'pipe' })
       let stdout = '', stderr = ''
       child.stdout.on('data', (d) => { stdout += d })
       child.stderr.on('data', (d) => { stderr += d })
       child.on('close', (code) => {
         resolve({ code, stdout, stderr })
       })
       child.on('error', reject)
     })
   }
   ```
3. 改造 `sshExec()` 为 `gatewayExec()`，增加模式分支：
   ```javascript
   async function gatewayExec(command) {
     if (DEPLOY_MODE === 'colocated') {
       const [cmd, ...args] = command.split(' ')
       return localExec(cmd, args)
     }
     // 原有 SSH 逻辑保持不变
     const ssh = new NodeSSH()
     await ssh.connect(SSH_CONFIG)
     const result = await ssh.execCommand(command)
     await ssh.dispose()
     return result
   }
   ```
4. 全文搜索 `sshExec(` 调用点，替换为 `gatewayExec(`（如有其他函数名引用）。
5. 确认 `sshCopySkillToAgent` / `sshRemoveSkillFromAgent`（约第 2660-2672 行）是否也走 SSH；如果是，一并改为调用 `gatewayExec()` 或文件系统操作。

**验证方式**:
- `grep -n "sshExec\|gatewayExec" server/index.js` 确认所有调用点已更新
- 本地临时设置 `GATEWAY_DEPLOY_MODE=colocated`，执行 `node -e "require('./server/index.js')"` 无报错（仅验证加载）

---

### Task 2: `server/gateway-file-transfer.js` — SFTP 文件操作降级

**文件**: `server/gateway-file-transfer.js`
**目标**: 新增 `GATEWAY_FILE_TRANSFER_MODE=local` 分支，同节点时走 `fs.promises` 本地文件操作。

**具体修改**:
1. 文件头部新增环境变量读取和 `fs` 导入：
   ```javascript
   const fs = require('fs').promises
   const path = require('path')

   const TRANSFER_MODE = process.env.GATEWAY_FILE_TRANSFER_MODE || 'sftp'
   const GATEWAY_CONFIG_DIR = process.env.GATEWAY_CONFIG_DIR || '/host/openclaw'
   ```
2. 改造 `uploadToGateway(localPath, remotePath)`:
   - 在函数开头增加 `local` 分支：
     ```javascript
     if (TRANSFER_MODE === 'local') {
       const dest = path.join(GATEWAY_CONFIG_DIR, remotePath)
       await fs.mkdir(path.dirname(dest), { recursive: true })
       await fs.copyFile(localPath, dest)
       return { success: true }
     }
     ```
   - 原有 SFTP 逻辑保持不变，放在分支之后
3. 改造 `deleteRemoteFile(remotePath)`:
   - 增加 `local` 分支：
     ```javascript
     if (TRANSFER_MODE === 'local') {
       const target = path.join(GATEWAY_CONFIG_DIR, remotePath)
       await fs.unlink(target).catch(() => {})
       return { success: true }
     }
     ```
4. 改造 `writeRemoteFile(remotePath, content)`:
   - 增加 `local` 分支：
     ```javascript
     if (TRANSFER_MODE === 'local') {
       const dest = path.join(GATEWAY_CONFIG_DIR, remotePath)
       await fs.mkdir(path.dirname(dest), { recursive: true })
       await fs.writeFile(dest, content, 'utf-8')
       return { success: true }
     }
     ```

**验证方式**:
- `grep -n "TRANSFER_MODE\|GATEWAY_CONFIG_DIR" server/gateway-file-transfer.js` 确认变量已使用
- 本地临时测试：
  ```bash
  GATEWAY_FILE_TRANSFER_MODE=local GATEWAY_CONFIG_DIR=/tmp/mock-openclaw \
    node -e "const m = require('./server/gateway-file-transfer.js'); console.log('loaded')"
  ```

---

### Task 3: `.env.example` — 新增环境变量

**文件**: `.env.example`
**目标**: 添加两个新环境变量，供用户参考。

**具体修改**:
在文件末尾新增：
```bash
# Gateway 部署模式：distributed（跨机SSH）| colocated（同节点本地）
GATEWAY_DEPLOY_MODE=distributed

# 文件传输模式：sftp（SSH上传）| local（本地文件操作）
GATEWAY_FILE_TRANSFER_MODE=sftp
```

**验证方式**:
- 确认文件格式与其他变量一致

---

### Task 4: 新增 `Dockerfile.wattclaw`

**文件**: `Dockerfile.wattclaw`（新建）
**目标**: 独立容器镜像，基于 `node:24-alpine`，使用 `wattman` 用户运行。

**具体内容**:
```dockerfile
# syntax=docker/dockerfile:1
FROM node:24-alpine

ARG WATTMAN_UID=1000
ARG WATTMAN_GID=1000

RUN addgroup -g ${WATTMAN_GID} wattman && \
    adduser -u ${WATTMAN_UID} -G wattman -s /bin/sh -D wattman

WORKDIR /app

COPY --chown=wattman:wattman package*.json ./
RUN npm ci --only=production

COPY --chown=wattman:wattman dist ./dist
COPY --chown=wattman:wattman server ./server

RUN mkdir -p /app/data /app/uploads && \
    chown -R wattman:wattman /app

USER wattman

ENV NODE_ENV=production
ENV PORT=3001
ENV HOME=/home/wattman
ENV GATEWAY_DEPLOY_MODE=colocated
ENV GATEWAY_FILE_TRANSFER_MODE=local
ENV GATEWAY_CONFIG_DIR=/host/openclaw

EXPOSE 3001

CMD ["node", "server/index.js"]
```

**验证方式**:
- `docker build --build-arg WATTMAN_UID=$(id -u) --build-arg WATTMAN_GID=$(id -g) -f Dockerfile.wattclaw -t wattclaw:test .` 构建成功

---

### Task 5: 新增 `docker-compose.wattclaw.yml`

**文件**: `docker-compose.wattclaw.yml`（新建）
**目标**: 容器编排配置，含 4 大挂载点和网络隔离。

**具体内容**:
```yaml
version: '3.8'

services:
  wattclaw:
    build:
      context: .
      dockerfile: Dockerfile.wattclaw
      args:
        - WATTMAN_UID=${WATTMAN_UID:-1000}
        - WATTMAN_GID=${WATTMAN_GID:-1000}
    container_name: wattclaw
    user: "${WATTMAN_UID:-1000}:${WATTMAN_GID:-1000}"
    networks:
      - wattclaw-net
    ports:
      - "127.0.0.1:3001:3001"
    environment:
      - NODE_ENV=production
      - PORT=3001
      - HOME=/home/wattman
      - GATEWAY_DEPLOY_MODE=colocated
      - GATEWAY_FILE_TRANSFER_MODE=local
      - GATEWAY_CONFIG_DIR=/host/openclaw
      - OPENCLAW_WS_URL=ws://172.17.0.1:18789
    volumes:
      - /home/wattman/.openclaw:/host/openclaw:rw
      - /home/wattman/.wattclaw:/home/wattman/.wattclaw:rw
      - /home/wattman/wattclaw/data:/app/data:rw
      - /home/wattman/wattclaw/uploads:/app/uploads:rw
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3001/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

networks:
  wattclaw-net:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16
```

**验证方式**:
- `docker-compose -f docker-compose.wattclaw.yml config` 解析成功，无格式错误

---

### Task 6: 本地构建验证

**目标**: 在提交前确认 Docker 镜像可正常构建。

**步骤**:
1. 确认 `dist/` 目录存在（执行 `npm run build` 生成）
2. 执行 `docker build -f Dockerfile.wattclaw -t wattclaw:local-test .`
3. 构建成功即通过

**注意**: 实际容器运行验证（挂载、Gateway 连通性）需要在 openclaw 服务器上由用户手动执行，不在本 Plan 范围内。

---

### Task 7: TypeScript / 代码检查

**目标**: 确认代码变更未引入语法错误。

**步骤**:
- 由于项目无 linter，手动检查以下文件语法：
  - `node server/index.js` 能正常加载（无 require 错误）
  - `node server/gateway-file-transfer.js` 能正常加载

---

## 执行顺序

```
Task 1 ──┐
Task 2 ──┼── Task 6 ── Task 7
Task 3 ──┘
Task 4 ──┘
Task 5 ──┘
```

Task 1-5 互相独立，可并行开发；Task 6 依赖 Task 1-5 完成；Task 7 依赖 Task 6。

---

## 提交规范

```
feat(deploy): 支持 colocated 模式与 Docker 容器化部署

- server/index.js: SSH 执行降级为本地 spawn（GATEWAY_DEPLOY_MODE）
- server/gateway-file-transfer.js: SFTP 降级为本地 fs 操作（GATEWAY_FILE_TRANSFER_MODE）
- .env.example: 新增 DEPLOY_MODE / FILE_TRANSFER_MODE 环境变量
- 新增 Dockerfile.wattclaw: node:24-alpine + wattman 用户
- 新增 docker-compose.wattclaw.yml: 4 大挂载点 + 桥接网络
```

---

## 用户手动部署清单（参考）

以下步骤由用户在 openclaw 服务器上手动执行，不在代码 Plan 内：

1. `git clone / git pull` 最新代码
2. `npm install && npm run build`
3. `scp` 复制 `wattclaw.db` 从 server2_l
4. `docker network create wattclaw-net ...`
5. `docker build -f Dockerfile.wattclaw -t wattclaw:latest .`
6. `docker-compose -f docker-compose.wattclaw.yml up -d`
7. 内网访问 `http://openclaw:3001` 验证
8. 停止 server2_l screen 会话 + Nginx 切换
