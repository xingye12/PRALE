# 三层接入模型 REST 化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 `sessions.list`、`config.patch`、`chat.history` 从 `POST /api/rpc` 代理迁移为独立 HTTP REST API，并在 SSE 数据面注入心跳保活。

**Architecture:** 控制面独立 REST 化（GET /api/sessions、PATCH /api/config、GET /api/chat/history），数据面 SSE 透传增加心跳，事件面完全保留。

**Tech Stack:** Node.js/Express (backend), Vue 3/Pinia/TypeScript (frontend), OpenClaw Gateway HTTP/WebSocket.

---

## File Structure

| File | Responsibility |
|------|---------------|
| `server/index.js` | 新增 3 个 Express REST 路由；清理 `/api/rpc` switch 中对应分支 |
| `src/stores/session.ts` | `fetchSessions()` 改用 `fetch GET /api/sessions` |
| `src/stores/workspace.ts` | `fetchAllSessionsCached()`、`selectSession()` 改用 REST；复用现有 `httpPost` 模式 |
| `src/stores/chat.ts` | `fetchHistory()` 改用 `fetch GET /api/chat/history` |
| `src/stores/config.ts` | `patchConfig()` 改用 `fetch PATCH /api/config`，移除前端 hash 计算 |
| `server/services/chat-stream-proxy.ts` | `ChatStreamHandleImpl` 新增心跳计时器 |

---

## Task 1: Backend — GET /api/sessions

**Files:**
- Modify: `server/index.js`

**Context:** 当前 `/api/rpc` switch 中 `sessions.list` 有两份逻辑：非 admin (~lines 3264-3284) 和 admin (~lines 3568-3586)。提取为独立路由。

- [ ] **Step 1: 在 `/api/rpc` 路由区域附近新增 `GET /api/sessions`**

在 `server/index.js` 中 `/api/rpc` 路由之前（或其他路由附近，如 `/api/sessions` 已存在则覆盖）添加：

```javascript
app.get('/api/sessions', authMiddleware, async (req, res) => {
  try {
    const isAdmin = req.currentUser?.role === 'admin'
    const allSessions = await getCachedAllSessions()

    if (isAdmin) {
      const allTitles = getAllSessionTitles()
      const sessionsWithTitles = allSessions.map(s => ({
        ...s,
        label: allTitles.get(s.key || s.sessionKey) || s.label || ''
      }))
      return res.json({
        ok: true,
        payload: {
          sessions: sessionsWithTitles,
          total: allSessions.length,
          page: 1,
          limit: allSessions.length,
          hasMore: false
        }
      })
    }

    const ownedSessions = filterOwnedSessions(allSessions)
    const localTitles = getLocalSessionTitles(req.currentUser.id)
    const sessionsWithTitles = ownedSessions.map(s => ({
      ...s,
      label: localTitles.get(s.key || s.sessionKey) || s.label || ''
    }))

    return res.json({
      ok: true,
      payload: {
        sessions: sessionsWithTitles,
        total: ownedSessions.length,
        page: 1,
        limit: ownedSessions.length,
        hasMore: false
      }
    })
  } catch (err) {
    return res.status(500).json({ ok: false, error: { message: err.message } })
  }
})
```

- [ ] **Step 2: Commit**

```bash
git add server/index.js
git commit -m "feat(backend): add GET /api/sessions REST endpoint"
```

---

## Task 2: Backend — PATCH /api/config

**Files:**
- Modify: `server/index.js`

**Context:** 前端 `rpc-client.ts` 的 `patchConfig` 计算了 `baseHash` 和 `raw`，但后端 `/api/rpc` 完全不用 `baseHash`，只读取 `params.raw` 传给 `configQueueExecute`。新路由接收结构化 `{ patches }`，后端负责构建 merge-patch 对象并走 ConfigQueue。

- [ ] **Step 1: 在 `server/index.js` 中新增 merge-patch helper**

在 `server/index.js` 的顶部 helper 函数区域（如 `generateSafeTitle` 附近）添加：

```javascript
/**
 * 将 ConfigPatch[] 转换为嵌套 merge-patch 对象。
 * 与前端 rpc-client.ts buildConfigPatchRaw 语义一致。
 */
function buildMergePatchFromPatches(patches) {
  const payload = {}
  for (const patch of patches) {
    const path = typeof patch.path === 'string' ? patch.path.trim() : ''
    if (!path) continue
    const segments = path.split('/').filter(Boolean)
    let target = payload
    for (let i = 0; i < segments.length - 1; i++) {
      const key = segments[i]
      if (!target[key] || typeof target[key] !== 'object' || Array.isArray(target[key])) {
        target[key] = {}
      }
      target = target[key]
    }
    const lastKey = segments[segments.length - 1]
    target[lastKey] = patch.value
  }
  return payload
}
```

- [ ] **Step 2: 在 `server/index.js` 中新增 `PATCH /api/config` 路由**

```javascript
app.patch('/api/config', authMiddleware, async (req, res) => {
  try {
    const patches = Array.isArray(req.body?.patches) ? req.body.patches : []
    if (patches.length === 0) {
      return res.status(400).json({ ok: false, error: { message: 'Missing patches' } })
    }

    const mergePatch = buildMergePatchFromPatches(patches)
    await configQueueExecute(
      (sourceConfig) => ({ ...sourceConfig, ...mergePatch }),
      'http-config-patch'
    )
    configGetPolling.refresh()
    return res.json({ ok: true, payload: {} })
  } catch (err) {
    return res.status(500).json({ ok: false, error: { message: err.message } })
  }
})
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(backend): add PATCH /api/config REST endpoint with server-side patch building"
```

---

## Task 3: Backend — GET /api/chat/history

**Files:**
- Modify: `server/index.js`

**Context:** 替代 `/api/rpc` 中 `chat.history` 代理（~lines 3343-3355）。新路由调用 OpenClaw Gateway 原生 HTTP 历史端点，支持游标分页。

- [ ] **Step 1: 确认环境变量中 `OPENCLAW_AUTH_TOKEN` 可用**

`server/index.js` 顶部 `loadEnvConfig()` 已加载 `OPENCLAW_AUTH_TOKEN`。在路由中直接读取 `process.env.OPENCLAW_AUTH_TOKEN`。

- [ ] **Step 2: 在 `server/index.js` 中新增 `GET /api/chat/history` 路由**

```javascript
app.get('/api/chat/history', authMiddleware, async (req, res) => {
  try {
    const sessionKey = req.query.sessionKey
    if (!sessionKey || typeof sessionKey !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing sessionKey' } })
    }

    if (!isSessionOwned(sessionKey)) {
      return res.json({ ok: true, payload: { messages: [], cursor: null, hasMore: false } })
    }

    const limit = Math.min(1000, Math.max(1, parseInt(req.query.limit) || 50))
    const cursor = req.query.cursor || ''

    const wsUrl = new URL(process.env.OPENCLAW_WS_URL || 'ws://localhost:18789')
    const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
    const gatewayUrl = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, `${protocol}://${wsUrl.host}`)
    gatewayUrl.searchParams.set('limit', String(limit))
    if (cursor) {
      gatewayUrl.searchParams.set('cursor', String(cursor))
    }

    const gatewayRes = await fetch(gatewayUrl.toString(), {
      headers: {
        Authorization: `Bearer ${process.env.OPENCLAW_AUTH_TOKEN || ''}`,
      },
    })

    if (!gatewayRes.ok) {
      const text = await gatewayRes.text().catch(() => 'Gateway error')
      return res.status(502).json({ ok: false, error: { message: `Gateway history error: ${text}` } })
    }

    const gatewayData = await gatewayRes.json()
    const messages = Array.isArray(gatewayData.messages)
      ? gatewayData.messages
      : (Array.isArray(gatewayData.history) ? gatewayData.history : [])

    return res.json({
      ok: true,
      payload: {
        messages,
        cursor: gatewayData.cursor || null,
        hasMore: !!gatewayData.hasMore,
      }
    })
  } catch (err) {
    return res.status(500).json({ ok: false, error: { message: err.message } })
  }
})
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(backend): add GET /api/chat/history REST endpoint with cursor pagination"
```

---

## Task 4: Frontend — session.ts

**Files:**
- Modify: `src/stores/session.ts`

**Context:** `fetchSessions()` 当前调用 `wsStore.rpc.listSessions()`（line ~137），需要改为 `fetch GET /api/sessions`。

- [ ] **Step 1: 在 `fetchSessions()` 中替换 RPC 为 HTTP fetch**

找到 `src/stores/session.ts` 中的 `fetchSessions()` 函数：

```typescript
  async function fetchSessions() {
    loading.value = true
    try {
      // BEFORE:
      // const result = await wsStore.rpc.listSessions()

      // AFTER:
      const token = localStorage.getItem('auth_token')
      const resp = await fetch('/api/sessions', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
      const data = await resp.json()
      if (!data.ok) throw new Error(data.error?.message || 'Failed')
      const result = data.payload

      const list = result.sessions
      // ... rest unchanged
```

保留 `list` 变量之后的所有逻辑不变（`hasMessageCount`、`hasMissingTokenUsage`、`mergeUsageIntoSessions` 等）。

- [ ] **Step 2: Commit**

```bash
git add src/stores/session.ts
git commit -m "feat(frontend): session store fetchSessions uses GET /api/sessions"
```

---

## Task 5: Frontend — workspace.ts

**Files:**
- Modify: `src/stores/workspace.ts`

**Context:** 两个方法需要替换：
1. `fetchAllSessionsCached()`（~line 1091）调用 `wsStore.rpc.listSessions()`
2. `selectSession()`（~line 1382）调用 `wsStore.rpc.listChatHistory(sessionKey)`

- [ ] **Step 1: 修改 `fetchAllSessionsCached()`**

```typescript
  async function fetchAllSessionsCached(): Promise<Session[]> {
    if (_sessionCache && Date.now() - _sessionCache.ts < SESSION_CACHE_TTL) {
      return _sessionCache.data
    }
    // BEFORE:
    // const result = await wsStore.rpc.listSessions()

    // AFTER:
    const token = localStorage.getItem('auth_token')
    const resp = await fetch('/api/sessions', {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
    const data = await resp.json()
    if (!data.ok) throw new Error(data.error?.message || 'Failed')
    const result = data.payload

    const rawSessions: Session[] = Array.isArray(result.sessions) ? result.sessions : (Array.isArray(result) ? result : [])
    const allSessions = rawSessions.map((s) => ({
      ...s,
      label: cleanSessionLabel(s.label),
    }))
    _sessionCache = { data: allSessions, ts: Date.now() }
    return allSessions
  }
```

- [ ] **Step 2: 修改 `selectSession()` 中的历史加载**

在 `selectSession()` 函数内部，找到 `const history = await wsStore.rpc.listChatHistory(sessionKey)` 这一行（约 line 1382），替换为：

```typescript
      // BEFORE:
      // const history = await wsStore.rpc.listChatHistory(sessionKey)

      // AFTER:
      const token = localStorage.getItem('auth_token')
      const historyResp = await fetch(`/api/chat/history?sessionKey=${encodeURIComponent(sessionKey)}&limit=50`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      if (!historyResp.ok) throw new Error(`HTTP ${historyResp.status}`)
      const historyData = await historyResp.json()
      if (!historyData.ok) throw new Error(historyData.error?.message || 'Failed')
      const history = Array.isArray(historyData.payload?.messages)
        ? historyData.payload.messages
        : (Array.isArray(historyData.payload) ? historyData.payload : [])
```

确保 `history` 变量之后的 `parseHistoryMessages(history, sessionKey)` 调用不受影响。

- [ ] **Step 3: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "feat(frontend): workspace store uses REST for sessions and chat history"
```

---

## Task 6: Frontend — chat.ts

**Files:**
- Modify: `src/stores/chat.ts`

**Context:** `fetchHistory()`（~line 330）当前调用 `wsStore.rpc.listChatHistory(normalizedKey)`。

- [ ] **Step 1: 修改 `fetchHistory()`**

找到 `messages.value = await wsStore.rpc.listChatHistory(normalizedKey)` 这一行（约 line 360），替换为：

```typescript
      // BEFORE:
      // messages.value = await wsStore.rpc.listChatHistory(normalizedKey)

      // AFTER:
      const token = localStorage.getItem('auth_token')
      const resp = await fetch(`/api/chat/history?sessionKey=${encodeURIComponent(normalizedKey)}&limit=50`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
      const data = await resp.json()
      if (!data.ok) throw new Error(data.error?.message || 'Failed')
      messages.value = Array.isArray(data.payload?.messages)
        ? data.payload.messages
        : (Array.isArray(data.payload) ? data.payload : [])
```

- [ ] **Step 2: Commit**

```bash
git add src/stores/chat.ts
git commit -m "feat(frontend): chat store fetchHistory uses GET /api/chat/history"
```

---

## Task 7: Frontend — config.ts

**Files:**
- Modify: `src/stores/config.ts`

**Context:** `patchConfig()`（~line 28）当前调用 `wsStore.rpc.patchConfig(patches)`，前端做了很多冗余的 hash 计算。改为直接发送结构化 patches。

- [ ] **Step 1: 修改 `patchConfig()`**

```typescript
  async function patchConfig(patches: ConfigPatch[]) {
    saving.value = true
    lastError.value = null
    try {
      // BEFORE:
      // await wsStore.rpc.patchConfig(patches)

      // AFTER:
      const token = localStorage.getItem('auth_token')
      const resp = await fetch('/api/config', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ patches }),
      })
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
      const data = await resp.json()
      if (!data.ok) throw new Error(data.error?.message || 'Failed')

      await fetchConfig()
    } catch (error) {
      lastError.value = error instanceof Error ? error.message : String(error)
      throw error
    } finally {
      saving.value = false
    }
  }
```

- [ ] **Step 2: Commit**

```bash
git add src/stores/config.ts
git commit -m "feat(frontend): config store patchConfig uses PATCH /api/config, removes client hash computation"
```

---

## Task 8: Backend — 清理 /api/rpc 中已迁移的分支

**Files:**
- Modify: `server/index.js`

**Context:** `/api/rpc` 的 switch/case 中 `sessions.list`、`chat.history`、`config.patch` 三个分支已不需要。注释掉或删除，避免请求走旧路径。

- [ ] **Step 1: 注释/删除 `sessions.list` 分支（非 admin 和 admin 各一份）**

在 `/api/rpc` switch 内找到：

```javascript
      if (normMethod === 'sessions.list' || normMethod === 'session.list') {
        ...
      }
```

替换为（注释标记）：

```javascript
      // MIGRATED: use GET /api/sessions instead
      // if (normMethod === 'sessions.list' || normMethod === 'session.list') { ... }
```

对 admin 区域的 `sessions.list` 同样处理。

- [ ] **Step 2: 注释/删除 `chat.history` 分支**

```javascript
      // MIGRATED: use GET /api/chat/history instead
      // if (normMethod === 'chat.history') { ... }
```

- [ ] **Step 3: 注释/删除 `config.patch` 分支**

```javascript
      // MIGRATED: use PATCH /api/config instead
      // if (normMethod === 'config.patch' || normMethod === 'config.set') { ... }
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "refactor(backend): remove migrated RPC proxy branches for sessions.list, chat.history, config.patch"
```

---

## Task 9: SSE Phase 1 — ChatStreamHandleImpl 心跳注入

**Files:**
- Modify: `server/services/chat-stream-proxy.ts`

**Context:** `ChatStreamHandleImpl` 当前有 `armIdleTimer()` / `disarmIdleTimer()` 用于检测流空闲超时并关闭连接。Phase 1 目标：将空闲超时改为心跳发送（15s 无 upstream data 时发送 `:keepalive\n\n`），避免代理层超时断开。

- [ ] **Step 1: 修改 `ChatStreamHandleImpl` 构造函数和 idle timer 逻辑**

当前 `idleTimeoutMs` 是 60000（来自 `streamIdleTimeoutMs`）。为了心跳，新增一个独立的心跳间隔字段，与空闲超时区分。

在构造函数参数和字段中：

```typescript
  // 新增字段
  private readonly heartbeatIntervalMs: number

  constructor(upstream: Readable, idleTimeoutMs: number) {
    // ... existing init ...
    this.heartbeatIntervalMs = 15000 // 15s heartbeat
    // ... rest unchanged ...
  }
```

修改 `armIdleTimer()`：

```typescript
  private armIdleTimer(): void {
    this.disarmIdleTimer()
    this.idleTimer = setTimeout(() => {
      // Phase 1: send keepalive instead of closing
      if (this.res && !this.res.writableEnded && !this.res.destroyed) {
        try {
          this.res.write(':keepalive\n\n')
          // Re-arm for next heartbeat
          this.armIdleTimer()
          return
        } catch {
          // write failed, fall through to finalize
        }
      }
      this.finalize('timeout', new Error(`Stream idle timeout after ${this.idleTimeoutMs}ms`))
    }, this.heartbeatIntervalMs)
  }
```

注意：此改动将原来的空闲关闭行为改为心跳。如果需要保留原来的 60s 真正超时，可以增加第二个 timer（`hardTimeoutTimer`），但为了 Phase 1 最小改动，仅替换行为即可。如需保留硬超时，可新增：

```typescript
  private hardTimeoutTimer: ReturnType<typeof setTimeout> | null = null

  private armHardTimeout(): void {
    this.hardTimeoutTimer = setTimeout(() => {
      this.finalize('timeout', new Error(`Hard stream timeout after ${this.idleTimeoutMs}ms`))
    }, this.idleTimeoutMs)
  }
```

并在 `disarmIdleTimer` 中同时清理 `hardTimeoutTimer`。为最小化改动，这里采用**仅心跳**方案（15s 间隔），如果上游确实死了，pipeline error 或 client close 会触发 finalize。

- [ ] **Step 2: Commit**

```bash
git add server/services/chat-stream-proxy.ts
git commit -m "feat(backend): SSE keepalive heartbeat in ChatStreamHandleImpl"
```

---

## Task 10: 验证

- [ ] **Step 1: 后端 curl 验证 `/api/sessions`**

```bash
curl -s -H "Authorization: Bearer <token>" http://localhost:3001/api/sessions | jq '.payload.sessions | length'
```
Expected: 返回数字（非 403/500）。

- [ ] **Step 2: 后端 curl 验证 `/api/config`**

```bash
curl -s -X PATCH -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d '{"patches":[{"path":"/test","value":"hello"}]}' http://localhost:3001/api/config | jq '.ok'
```
Expected: `true`。

- [ ] **Step 3: 后端 curl 验证 `/api/chat/history`**

```bash
curl -s -H "Authorization: Bearer <token>" "http://localhost:3001/api/chat/history?sessionKey=agent:main:main:dm:webchat-xxx&limit=10" | jq '.payload.messages | length'
```
Expected: 返回数字或 0（对于未拥有 session 返回空数组）。

- [ ] **Step 4: 前端回归 — Session 列表加载**

打开浏览器 DevTools Network 面板，刷新页面进入 Sessions 页。
Expected: 看到 `GET /api/sessions` 请求，响应包含 `sessions` 数组，列表正常渲染。

- [ ] **Step 5: 前端回归 — Workspace 历史消息加载**

进入 Workspace，点击一个已有会话。
Expected: 看到 `GET /api/chat/history?sessionKey=...` 请求，消息正常渲染，无 `/api/rpc` body 含 `chat.history` 的请求。

- [ ] **Step 6: 前端回归 — Config 修改**

在 Settings 页修改任意配置（如 model provider）。
Expected: 看到 `PATCH /api/config` 请求，Body 为 `{ patches: [...] }`，修改生效。

- [ ] **Step 7: 前端回归 — `/api/rpc` 其他方法不受影响**

发送一条聊天消息。
Expected: `/api/workspace/send` SSE 流正常，无 `/api/rpc` body 含 `sessions.list` / `config.patch` / `chat.history` 的请求。

- [ ] **Step 8: 统一 commit（如所有验证通过）**

```bash
git commit --allow-empty -m "feat: migrate sessions.list, config.patch, chat.history to REST APIs"
```

---

## Self-Review Checklist

**1. Spec coverage:**
- [x] GET /api/sessions → Task 1
- [x] PATCH /api/config → Task 2
- [x] GET /api/chat/history with cursor pagination → Task 3
- [x] Frontend stores migration (session, workspace, chat, config) → Tasks 4-7
- [x] Cleanup /api/rpc branches → Task 8
- [x] SSE heartbeat Phase 1 → Task 9
- [x] Verification → Task 10

**2. Placeholder scan:** 无 TBD/TODO/"implement later"/"add appropriate error handling"。每个步骤含完整代码。

**3. Type consistency：**
- `buildMergePatchFromPatches` 与前端 `buildConfigPatchRaw` 语义对齐（`path.split('/')` 过滤空 segment）。
- 后端响应统一使用 `{ ok: true, payload: ... }` 信封格式。
- 前端消费 `data.payload.messages` 与后端返回一致。
- `limit` 参数后端默认 50，最大 1000，与 Gateway 原生上限一致。
