# History Local Store (PostgreSQL) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Store chat messages in WattClaw's own PostgreSQL so history reads are <10ms instead of ~10s Gateway calls.

**Architecture:** Two new modules (`server/message-store.js` for PostgreSQL CRUD, `server/backfill-queue.js` for background backfill). Read path checks PostgreSQL first, falls back to Gateway. Write path captures messages at send time (user) and SSE event arrival (assistant/tool). Session lifecycle cleanup cascades to PostgreSQL. Zero frontend changes.

**Tech Stack:** `pg` (node-postgres), PostgreSQL 15+, Docker Compose for local dev.

**Spec:** `docs/superpowers/specs/2026-05-28-history-local-store-design.md`

---

## File Structure

| Operation | File | Responsibility |
|-----------|------|---------------|
| Create | `server/message-store.js` | PostgreSQL pool init, table creation, message CRUD (upsert, read, delete), seq allocation with advisory lock |
| Create | `server/backfill-queue.js` | Global queue processor (2 concurrent, 500ms interval), preload scheduling, reconciliation |
| Modify | `server/index.js` | Import message-store + backfill-queue; write path capture in send endpoint + event handler; read path switch in history endpoint; session lifecycle cleanup; preload trigger on SSE connect |
| Modify | `package.json` | Add `pg` dependency |
| Modify | `.env.example` | Add `DATABASE_URL` |
| Modify | `docker-compose.yml` | Add PostgreSQL service |

---

## Task 1: Add PostgreSQL Dependency and Configuration

**Files:**
- Modify: `package.json`
- Modify: `.env.example`

- [ ] **Step 1: Install pg package**

Run:
```bash
cd /Users/renming/Desktop/wattman/openclaw/wattclaw
npm install pg
```

- [ ] **Step 2: Verify pg appears in package.json dependencies**

Run: `grep '"pg"' package.json`
Expected: a line like `"pg": "^8.x.x"`

- [ ] **Step 3: Add DATABASE_URL to .env.example**

Append after the last line in `.env.example`:

```
# PostgreSQL connection for chat message local store
DATABASE_URL=postgresql://wattclaw:wattclaw@localhost:5432/wattclaw
```

- [ ] **Step 4: Add DATABASE_URL to .env**

Append to `.env`:

```
DATABASE_URL=postgresql://wattclaw:wattclaw@localhost:5432/wattclaw
```

- [ ] **Step 5: Add PostgreSQL service to docker-compose.yml**

Add a `postgres` service and a named volume. The existing `openclaw` service should depend on it. Add after the `services:` key (before `openclaw:`):

```yaml
services:
  postgres:
    image: postgres:15-alpine
    container_name: wattclaw-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: wattclaw
      POSTGRES_PASSWORD: wattclaw
      POSTGRES_DB: wattclaw
    ports:
      - "${POSTGRES_PORT:-5432}:5432"
    volumes:
      - postgres-data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U wattclaw"]
      interval: 5s
      timeout: 5s
      retries: 5

  openclaw:
    # ... existing config ...
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      # ... existing env vars ...
      DATABASE_URL: postgresql://wattclaw:wattclaw@postgres:5432/wattclaw

volumes:
  # ... existing volumes ...
  postgres-data:
    name: wattclaw_postgres_data
```

Note: The `depends_on`, `DATABASE_URL` env override, and `postgres-data` volume are additions to existing content — do not duplicate the `openclaw` service definition.

- [ ] **Step 6: Commit**

```bash
git add package.json package-lock.json .env.example .env docker-compose.yml
git commit -m "chore: add pg dependency and PostgreSQL configuration for message store"
```

---

## Task 2: Create message-store.js — PostgreSQL Pool and Table Init

**Files:**
- Create: `server/message-store.js`

- [ ] **Step 1: Write message-store.js with pool init and table creation**

Create `server/message-store.js`:

```js
import pg from 'pg'

const { Pool } = pg

let pool = null
let _initPromise = null

export async function initMessageStore() {
  if (pool) return pool
  if (_initPromise) return _initPromise

  _initPromise = (async () => {
    const connectionString = process.env.DATABASE_URL
    if (!connectionString) {
      console.warn('[MessageStore] DATABASE_URL not set, message store disabled')
      return null
    }

    pool = new Pool({
      connectionString,
      max: 20,
      min: 2,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    })

    pool.on('error', (err) => {
      console.error('[MessageStore] Unexpected pool error:', err.message)
    })

    await pool.query(`
      CREATE TABLE IF NOT EXISTS session_messages (
        id            BIGSERIAL PRIMARY KEY,
        session_key   TEXT NOT NULL,
        seq           INTEGER NOT NULL,
        msg_id        TEXT,
        role          TEXT NOT NULL,
        content       TEXT NOT NULL DEFAULT '',
        raw_content   JSONB,
        model         TEXT,
        status        TEXT NOT NULL DEFAULT 'confirmed',
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(session_key, seq)
      );

      CREATE INDEX IF NOT EXISTS idx_msg_session_seq ON session_messages (session_key, seq DESC);
      CREATE INDEX IF NOT EXISTS idx_msg_session_status ON session_messages (session_key, status);
    `)

    console.log('[MessageStore] Initialized, table session_messages ready')
    return pool
  })()

  return _initPromise
}

export function getPool() {
  return pool
}

export function isReady() {
  return pool !== null
}
```

- [ ] **Step 2: Verify file is syntactically valid**

Run: `node -e "import('./server/message-store.js').then(() => console.log('OK')).catch(e => console.error(e.message))"`
Expected: No import/syntax errors. May print "DATABASE_URL not set" warning — that's expected without a running PostgreSQL.

- [ ] **Step 3: Commit**

```bash
git add server/message-store.js
git commit -m "feat(message-store): PostgreSQL pool init and session_messages table creation"
```

---

## Task 3: Add upsertMessage and getNextSeq to message-store.js

**Files:**
- Modify: `server/message-store.js`

- [ ] **Step 1: Add upsertMessage function**

Append to `server/message-store.js` (before the closing of the module):

```js
/**
 * Allocate next seq for a session using advisory lock to prevent races.
 */
export async function getNextSeq(sessionKey) {
  if (!pool) return null
  const client = await pool.connect()
  try {
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])
    const { rows } = await client.query(
      'SELECT COALESCE(MAX(seq), 0) + 1 AS next_seq FROM session_messages WHERE session_key = $1',
      [sessionKey]
    )
    return rows[0].next_seq
  } finally {
    client.release()
  }
}

/**
 * Upsert a message. Older data never overwrites newer data (by created_at).
 */
export async function upsertMessage({ sessionKey, seq, msgId, role, content, rawContent, model, status }) {
  if (!pool) return false
  try {
    await pool.query(
      `INSERT INTO session_messages (session_key, seq, msg_id, role, content, raw_content, model, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (session_key, seq) DO UPDATE SET
         content = CASE
           WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.content
           ELSE session_messages.content
         END,
         raw_content = CASE
           WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.raw_content
           ELSE session_messages.raw_content
         END,
         status = EXCLUDED.status,
         msg_id = COALESCE(EXCLUDED.msg_id, session_messages.msg_id)`,
      [sessionKey, seq, msgId || null, role, content || '', rawContent ? JSON.stringify(rawContent) : null, model || null, status || 'confirmed']
    )
    return true
  } catch (err) {
    console.error('[MessageStore] upsertMessage error:', err.message)
    return false
  }
}
```

- [ ] **Step 2: Add updateMessageStatus function**

```js
/**
 * Update message status (e.g., pending → confirmed / orphaned).
 */
export async function updateMessageStatus(sessionKey, seq, status) {
  if (!pool) return false
  try {
    await pool.query(
      'UPDATE session_messages SET status = $1 WHERE session_key = $2 AND seq = $3',
      [status, sessionKey, seq]
    )
    return true
  } catch (err) {
    console.error('[MessageStore] updateMessageStatus error:', err.message)
    return false
  }
}
```

- [ ] **Step 3: Verify syntax**

Run: `node -e "import('./server/message-store.js').then(m => console.log(typeof m.upsertMessage, typeof m.getNextSeq)).catch(e => console.error(e.message))"`
Expected: `function function`

- [ ] **Step 4: Commit**

```bash
git add server/message-store.js
git commit -m "feat(message-store): add upsertMessage, getNextSeq, updateMessageStatus"
```

---

## Task 4: Add readMessages and deleteMessages to message-store.js

**Files:**
- Modify: `server/message-store.js`

- [ ] **Step 1: Add readMessages function**

```js
/**
 * Read confirmed messages for a session, ordered by seq DESC.
 */
export async function readMessages(sessionKey, { limit = 50, beforeSeq = null } = {}) {
  if (!pool) return []
  try {
    let query, params
    if (beforeSeq != null) {
      query = `SELECT * FROM session_messages
               WHERE session_key = $1 AND status = 'confirmed' AND seq < $2
               ORDER BY seq DESC LIMIT $3`
      params = [sessionKey, beforeSeq, limit]
    } else {
      query = `SELECT * FROM session_messages
               WHERE session_key = $1 AND status = 'confirmed'
               ORDER BY seq DESC LIMIT $2`
      params = [sessionKey, limit]
    }
    const { rows } = await pool.query(query, params)
    return rows
  } catch (err) {
    console.error('[MessageStore] readMessages error:', err.message)
    return []
  }
}
```

- [ ] **Step 2: Add countConfirmedMessages function**

```js
/**
 * Count confirmed messages for a session.
 */
export async function countConfirmedMessages(sessionKey) {
  if (!pool) return 0
  try {
    const { rows } = await pool.query(
      "SELECT COUNT(*)::int AS cnt FROM session_messages WHERE session_key = $1 AND status = 'confirmed'",
      [sessionKey]
    )
    return rows[0].cnt
  } catch (err) {
    console.error('[MessageStore] countConfirmedMessages error:', err.message)
    return 0
  }
}
```

- [ ] **Step 3: Add deleteSessionMessages function**

```js
/**
 * Delete all messages for a session (reset / delete lifecycle).
 */
export async function deleteSessionMessages(sessionKey) {
  if (!pool) return false
  try {
    await pool.query('DELETE FROM session_messages WHERE session_key = $1', [sessionKey])
    console.log('[MessageStore] Deleted messages for session:', sessionKey)
    return true
  } catch (err) {
    console.error('[MessageStore] deleteSessionMessages error:', err.message)
    return false
  }
}
```

- [ ] **Step 4: Add batchUpsertMessages function**

Used by backfill (Phase 1/2) to write many messages efficiently.

```js
/**
 * Batch upsert messages. Uses advisory lock per session for seq allocation.
 */
export async function batchUpsertMessages(sessionKey, messages) {
  if (!pool || !messages.length) return 0
  let written = 0
  const client = await pool.connect()
  try {
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])

    // Get current max seq
    const { rows } = await client.query(
      'SELECT COALESCE(MAX(seq), 0) AS max_seq FROM session_messages WHERE session_key = $1',
      [sessionKey]
    )
    let nextSeq = rows[0].max_seq + 1

    for (const msg of messages) {
      const seq = msg.seq != null ? msg.seq : nextSeq++
      try {
        await client.query(
          `INSERT INTO session_messages (session_key, seq, msg_id, role, content, raw_content, model, status)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           ON CONFLICT (session_key, seq) DO UPDATE SET
             content = CASE
               WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.content
               ELSE session_messages.content
             END,
             raw_content = CASE
               WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.raw_content
               ELSE session_messages.raw_content
             END,
             status = EXCLUDED.status,
             msg_id = COALESCE(EXCLUDED.msg_id, session_messages.msg_id)`,
          [sessionKey, seq, msg.msgId || msg.msg_id || null,
           msg.role || 'unknown', msg.content || '',
           msg.rawContent ? JSON.stringify(msg.rawContent) : (msg.raw_content ? JSON.stringify(msg.raw_content) : null),
           msg.model || null, msg.status || 'confirmed']
        )
        written++
      } catch (err) {
        console.error('[MessageStore] batchUpsert row error:', err.message)
      }
    }
  } catch (err) {
    console.error('[MessageStore] batchUpsertMessages error:', err.message)
  } finally {
    client.release()
  }
  return written
}
```

- [ ] **Step 5: Verify syntax**

Run: `node -e "import('./server/message-store.js').then(m => console.log(Object.keys(m).sort().join(', '))).catch(e => console.error(e.message))"`
Expected: `batchUpsertMessages,countConfirmedMessages,deleteSessionMessages,getPool,getNextSeq,initMessageStore,isReady,readMessages,updateMessageStatus,upsertMessage`

- [ ] **Step 6: Commit**

```bash
git add server/message-store.js
git commit -m "feat(message-store): add readMessages, countConfirmedMessages, deleteSessionMessages, batchUpsertMessages"
```

---

## Task 5: Create backfill-queue.js

**Files:**
- Create: `server/backfill-queue.js`

- [ ] **Step 1: Write backfill-queue.js**

Create `server/backfill-queue.js`:

```js
import { batchUpsertMessages, countConfirmedMessages, isReady } from './message-store.js'

const MAX_CONCURRENT = 2
const BATCH_INTERVAL_MS = 500
const MAX_PENDING = 50

let activeJobs = 0
const pendingQueue = []
const inFlightSessionKeys = new Set()

/**
 * Enqueue a backfill job. Deduplicates by sessionKey.
 */
export function enqueueBackfill(sessionKey, { limit = 50, fetchFn, label = 'backfill' } = {}) {
  if (!isReady()) return
  if (inFlightSessionKeys.has(sessionKey)) return
  if (pendingQueue.length >= MAX_PENDING) return

  pendingQueue.push({ sessionKey, limit, fetchFn, label })
  inFlightSessionKeys.add(sessionKey)
  processQueue()
}

function processQueue() {
  while (activeJobs < MAX_CONCURRENT && pendingQueue.length > 0) {
    const job = pendingQueue.shift()
    activeJobs++
    executeJob(job).finally(() => {
      activeJobs--
      inFlightSessionKeys.delete(job.sessionKey)
      if (pendingQueue.length > 0) {
        setTimeout(processQueue, BATCH_INTERVAL_MS)
      }
    })
  }
}

async function executeJob({ sessionKey, limit, fetchFn, label }) {
  try {
    if (!fetchFn) {
      console.warn(`[Backfill] No fetchFn for ${sessionKey}, skipping`)
      return
    }
    const messages = await fetchFn(sessionKey, limit)
    if (messages && messages.length > 0) {
      const written = await batchUpsertMessages(sessionKey, messages)
      console.log(`[Backfill] ${label} ${sessionKey}: ${written}/${messages.length} messages upserted`)
    }
  } catch (err) {
    console.error(`[Backfill] ${label} ${sessionKey} error:`, err.message)
  }
}

/**
 * Schedule preload for active user: top N sessions per agent, limit=50 each.
 * Skips sessions that already have data in PostgreSQL.
 */
export async function schedulePreloadForUser(userId, { getUserSessionsFn, fetchFn, topN = 4 }) {
  if (!isReady()) return
  if (!getUserSessionsFn) return

  const sessions = getUserSessionsFn(userId)
  if (!sessions || !sessions.length) return

  // Group by agent_id, take top N per agent (most recently updated)
  const byAgent = new Map()
  for (const s of sessions) {
    const aid = s.agent_id || '_none'
    if (!byAgent.has(aid)) byAgent.set(aid, [])
    byAgent.get(aid).push(s)
  }

  const candidates = []
  for (const [, agentSessions] of byAgent) {
    agentSessions.sort((a, b) => (b.updated_at || 0) - (a.updated_at || 0))
    candidates.push(...agentSessions.slice(0, topN))
  }

  // Filter out sessions that already have local data
  for (const s of candidates) {
    const sk = s.session_key || s.key
    if (!sk) continue
    const count = await countConfirmedMessages(sk)
    if (count > 0) continue
    enqueueBackfill(sk, { limit: 50, fetchFn, label: 'preload' })
  }
}

/**
 * Trigger Phase 2 background full backfill for a session.
 */
export function triggerPhase2Backfill(sessionKey, { fetchFn }) {
  if (!isReady()) return
  enqueueBackfill(sessionKey, { limit: 1000, fetchFn, label: 'phase2' })
}
```

- [ ] **Step 2: Verify syntax**

Run: `node -e "import('./server/backfill-queue.js').then(m => console.log(Object.keys(m).join(', '))).catch(e => console.error(e.message))"`
Expected: `enqueueBackfill,schedulePreloadForUser,triggerPhase2Backfill`

- [ ] **Step 3: Commit**

```bash
git add server/backfill-queue.js
git commit -m "feat(backfill-queue): global queue processor with preload and phase2 backfill"
```

---

## Task 6: Initialize MessageStore in server/index.js on Startup

**Files:**
- Modify: `server/index.js` (import section + startup)

- [ ] **Step 1: Add imports near line 22**

After the existing `import { ChatStreamProxyService, ... }` line (line 22), add:

```js
import { initMessageStore, isReady as isMessageStoreReady, upsertMessage, getNextSeq, updateMessageStatus, readMessages, countConfirmedMessages, deleteSessionMessages, batchUpsertMessages } from './message-store.js'
import { enqueueBackfill, schedulePreloadForUser, triggerPhase2Backfill } from './backfill-queue.js'
```

- [ ] **Step 2: Add initMessageStore() call in server startup**

Find the `server.listen(envConfig.PORT, ...)` callback (around line 7185). Inside the callback, after existing init calls like `deduplicateSharedSessions()`, add:

```js
    initMessageStore().then(() => {
      console.log('[MessageStore] Ready')
    }).catch(err => {
      console.error('[MessageStore] Init failed:', err.message)
    })
```

- [ ] **Step 3: Verify server still starts**

Run: `timeout 5 node server/index.js 2>&1 | head -20` (or start manually and check console output)
Expected: Server starts, prints `[MessageStore] DATABASE_URL not set, message store disabled` (since no PostgreSQL running yet) or `[MessageStore] Ready` if PostgreSQL is available. Server should NOT crash.

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat(server): import and initialize message-store on startup"
```

---

## Task 7: Write Path — Capture User Messages in POST /api/chat/send

**Files:**
- Modify: `server/index.js` (POST /api/chat/send handler, lines 4131-4183)

- [ ] **Step 1: Add user message capture after ownership tracking**

In the `POST /api/chat/send` handler, after the ownership tracking block (after line 4160, before `const gatewayParams = ...` at line 4162), insert:

```js
  // Capture user message to local PostgreSQL (best-effort, non-blocking)
  const _userMsgSeq = await getNextSeq(sessionKey)
  if (_userMsgSeq) {
    upsertMessage({
      sessionKey,
      seq: _userMsgSeq,
      msgId: idempotencyKey,
      role: 'user',
      content: message,
      rawContent: null,
      model: model || null,
      status: 'pending',
    }).catch(err => console.error('[MessageStore] user msg capture error:', err.message))
  }
```

- [ ] **Step 2: Update status to confirmed on Gateway success**

In the same handler, after the `gateway.call('chat.send', gatewayParams)` succeeds (around line 4175), change the success branch to also confirm the message:

Replace:
```js
    const result = await gateway.call('chat.send', gatewayParams)
    return res.json({ ok: true, payload: result })
```

With:
```js
    const result = await gateway.call('chat.send', gatewayParams)
    // Confirm user message in local store
    if (_userMsgSeq) {
      updateMessageStatus(sessionKey, _userMsgSeq, 'confirmed').catch(() => {})
    }
    return res.json({ ok: true, payload: result })
```

- [ ] **Step 3: Update status to orphaned on Gateway failure**

In the same handler's catch block (around line 4177-4182), add orphan marking:

Replace:
```js
  } catch (err) {
    return res.status(502).json({
      ok: false,
      error: { message: err.message || 'Gateway chat.send failed' },
    })
  }
```

With:
```js
  } catch (err) {
    // Mark user message as orphaned (Gateway rejected)
    if (_userMsgSeq) {
      updateMessageStatus(sessionKey, _userMsgSeq, 'orphaned').catch(() => {})
    }
    return res.status(502).json({
      ok: false,
      error: { message: err.message || 'Gateway chat.send failed' },
    })
  }
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat(chat-send): capture user messages to PostgreSQL with pending→confirmed/orphaned lifecycle"
```

---

## Task 8: Write Path — Capture Assistant/Tool Messages from SSE Events

**Files:**
- Modify: `server/index.js` (gateway.on('event') handler, lines 889-914)

- [ ] **Step 1: Add assistant message capture in the event handler**

In the `gateway.on('event', ...)` handler (line 889), inside the `if (sk)` block (after line 910), add message capture logic:

After the existing `if (event === 'chat.done' || event === 'chat.final')` block (line 908-910), and before the closing `}` of the `if (sk)` block (line 911), insert:

```js
      // Capture assistant/tool messages from SSE events
      if (event === 'chat.done' || event === 'chat.final') {
        captureEventMessage(sk, payload).catch(err =>
          console.error('[MessageStore] event capture error:', err.message)
        )
      }
```

- [ ] **Step 2: Add the captureEventMessage helper function**

Add this function near the top of `server/index.js`, close to other helper functions (after `extractMessagesFromHistoryPayload` around line 327):

```js
/** Capture a completed assistant/tool message from Gateway SSE event to local PostgreSQL. */
async function captureEventMessage(sessionKey, payload) {
  if (!isMessageStoreReady()) return

  // Extract the assistant message from the event payload
  const data = payload.data || payload
  const content = data.content || data.text || data.message || ''
  const role = data.role || 'assistant'
  const msgId = data.id || data.messageId || null
  const model = data.model || null
  const rawContent = data.rawContent || data.raw_content || null

  if (!content && !rawContent) return

  const seq = await getNextSeq(sessionKey)
  if (!seq) return

  await upsertMessage({
    sessionKey,
    seq,
    msgId,
    role,
    content: typeof content === 'string' ? content : JSON.stringify(content),
    rawContent: rawContent || (typeof content !== 'string' ? content : null),
    model,
    status: 'confirmed',
  })
}
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(events): capture assistant/tool messages from Gateway SSE events to PostgreSQL"
```

---

## Task 9: Read Path — Switch GET /api/chat/history to PostgreSQL-First

**Files:**
- Modify: `server/index.js` (GET /api/chat/history handler, lines 4299-4384)

This is the core change. The read path now checks PostgreSQL first and only falls back to Gateway when local data is insufficient.

- [ ] **Step 1: Rewrite the history handler**

Replace the entire `app.get('/api/chat/history', authMiddleware, async (req, res) => { ... })` handler (lines 4299-4384) with:

```js
app.get('/api/chat/history', authMiddleware, async (req, res) => {
  const apmStart = performance.now()
  try {
    const sessionKey = req.query.sessionKey
    if (!sessionKey || typeof sessionKey !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing sessionKey' } })
    }

    if (!isSessionOwned(sessionKey, req.currentUser.id)) {
      return res.json({ ok: true, payload: { messages: [], cursor: null, hasMore: false } })
    }

    const limit = Math.min(1000, Math.max(1, parseInt(req.query.limit) || 50))
    const cursor = req.query.cursor || ''

    // ── PostgreSQL read path ──
    if (isMessageStoreReady()) {
      const localCount = await countConfirmedMessages(sessionKey)
      if (localCount >= limit) {
        const rows = await readMessages(sessionKey, { limit, beforeSeq: cursor ? parseInt(cursor) || null : null })
        if (rows.length > 0) {
          const messages = rows.map(r => {
            const raw = r.raw_content
            if (raw && typeof raw === 'object') return raw
            return { role: r.role, content: r.content, ...(r.model ? { model: r.model } : {}) }
          })
          const oldestSeq = rows[rows.length - 1].seq
          const hasMore = localCount > rows.length
          const totalMs = (performance.now() - apmStart).toFixed(1)
          console.log(`[APM - History] PostgreSQL HIT: ${totalMs}ms, ${messages.length} msgs from local store`)
          flushPendingTokenUpdate(sessionKey)
          return res.json({ ok: true, payload: { messages, cursor: oldestSeq > 1 ? String(oldestSeq) : null, hasMore } })
        }
      }
    }

    // ── Gateway fallback (Phase 1: lazy backfill on first access) ──
    const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
    const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
    const gatewayUrl = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, `${protocol}://${wsUrl.host}`)
    gatewayUrl.searchParams.set('limit', String(limit))
    if (cursor) {
      gatewayUrl.searchParams.set('cursor', String(cursor))
    }

    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 30_000)

    const fetchStart = performance.now()
    console.log(`[APM - History] Cache MISS, fetching ${gatewayUrl.toString()}`)

    try {
      const gatewayRes = await fetch(gatewayUrl.toString(), {
        headers: {
          Authorization: `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN || ''}`,
        },
        signal: controller.signal,
      })

      const ttfbMs = (performance.now() - fetchStart).toFixed(1)
      console.log(`[APM - History] TTFB (first byte from Gateway): ${ttfbMs}ms, status=${gatewayRes.status}`)

      if (gatewayRes.ok) {
        const bodyStart = performance.now()
        const gatewayData = await gatewayRes.json()
        const bodyMs = (performance.now() - bodyStart).toFixed(1)
        console.log(`[APM - History] body download + JSON parse: ${bodyMs}ms`)

        const extractStart = performance.now()
        const messages = extractMessagesFromHistoryPayload(gatewayData)
        const extractMs = (performance.now() - extractStart).toFixed(1)
        console.log(`[APM - History] extractMessagesFromHistoryPayload: ${extractMs}ms, messages=${messages.length}`)

        const totalMs = (performance.now() - apmStart).toFixed(1)
        console.log(`[APM - History] TOTAL end-to-end: ${totalMs}ms (TTFB=${ttfbMs}, body=${bodyMs}, extract=${extractMs})`)

        // Phase 1: upsert fetched messages to PostgreSQL (non-blocking)
        if (isMessageStoreReady() && messages.length > 0) {
          const backfillMsgs = messages.map((m, i) => ({
            seq: i + 1,
            msgId: m.id || m.msg_id || null,
            role: m.role || 'unknown',
            content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
            rawContent: m,
            model: m.model || null,
            status: 'confirmed',
          }))
          batchUpsertMessages(sessionKey, backfillMsgs).then(written => {
            console.log(`[Backfill] Phase 1 ${sessionKey}: ${written} msgs upserted`)
            // Phase 2: trigger background full backfill
            triggerPhase2Backfill(sessionKey, { fetchFn: fetchHistoryFromGateway })
          }).catch(err => console.error('[Backfill] Phase 1 error:', err.message))
        }

        flushPendingTokenUpdate(sessionKey)

        return res.json({
          ok: true,
          payload: {
            messages,
            cursor: gatewayData.nextCursor || gatewayData.cursor || null,
            hasMore: !!gatewayData.hasMore,
          }
        })
      }

      const text = await gatewayRes.text().catch(() => '')
      const totalMs = (performance.now() - apmStart).toFixed(1)
      console.log(`[APM - History] Gateway error response in ${totalMs}ms, status=${gatewayRes.status}`)
      return res.status(502).json({ ok: false, error: { message: `Gateway history error: ${text}` } })
    } finally {
      clearTimeout(timeout)
    }
  } catch (err) {
    const totalMs = (performance.now() - apmStart).toFixed(1)
    if (err.name === 'AbortError') {
      console.error(`[APM - History] ABORTED after 30s timeout at ${totalMs}ms`)
      return res.status(504).json({ ok: false, error: { message: 'Gateway history timeout (30s)' } })
    }
    console.error(`[APM - History] error at ${totalMs}ms:`, err.message)
    return res.status(500).json({ ok: false, error: { message: err.message } })
  }
})
```

- [ ] **Step 2: Add the fetchHistoryFromGateway helper function**

Add near the `captureEventMessage` function added in Task 8:

```js
/** Fetch history from Gateway HTTP endpoint for backfill. */
async function fetchHistoryFromGateway(sessionKey, limit = 50) {
  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
  const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
  const gatewayUrl = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, `${protocol}://${wsUrl.host}`)
  gatewayUrl.searchParams.set('limit', String(limit))

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 30_000)

  try {
    const gatewayRes = await fetch(gatewayUrl.toString(), {
      headers: { Authorization: `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN || ''}` },
      signal: controller.signal,
    })
    if (!gatewayRes.ok) return []

    const gatewayData = await gatewayRes.json()
    const messages = extractMessagesFromHistoryPayload(gatewayData)
    return messages.map((m, i) => ({
      seq: i + 1,
      msgId: m.id || m.msg_id || null,
      role: m.role || 'unknown',
      content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
      rawContent: m,
      model: m.model || null,
      status: 'confirmed',
    }))
  } catch (err) {
    console.error(`[Backfill] fetchHistoryFromGateway ${sessionKey} error:`, err.message)
    return []
  } finally {
    clearTimeout(timeout)
  }
}
```

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "feat(history): PostgreSQL-first read path with lazy Gateway backfill"
```

---

## Task 10: Session Lifecycle — Cleanup on Reset/Delete

**Files:**
- Modify: `server/index.js` (RPC handler + REST delete endpoint)

- [ ] **Step 1: Add cleanup to sessions.reset RPC handler**

In the RPC handler for `sessions.reset` (line 3449-3456), after the `gateway.call(method, params)` call succeeds, add:

After line 3454 (`const result = await gateway.call(method, params)`), before `return res.json(...)`:

```js
        // Clean local message store on session reset
        deleteSessionMessages(sk).catch(err =>
          console.error('[MessageStore] reset cleanup error:', err.message)
        )
```

- [ ] **Step 2: Add cleanup to sessions.delete RPC handler**

In the RPC handler for `sessions.delete` (line 3458-3471), after the existing `removeSessionForUser` call (line 3465), add:

After line 3465 (`removeSessionForUser(userId, sk)`):

```js
          // Clean local message store on session delete
          deleteSessionMessages(sk).catch(err =>
            console.error('[MessageStore] delete cleanup error:', err.message)
          )
```

- [ ] **Step 3: Add cleanup to REST session delete endpoint**

In `app.delete('/api/user/sessions/:sessionKey', ...)` (line 1878-1881), add message cleanup:

Replace:
```js
app.delete('/api/user/sessions/:sessionKey', authMiddleware, (req, res) => {
  deleteUserSession(req.currentUser.id, req.params.sessionKey)
  res.json({ ok: true })
})
```

With:
```js
app.delete('/api/user/sessions/:sessionKey', authMiddleware, (req, res) => {
  deleteUserSession(req.currentUser.id, req.params.sessionKey)
  deleteSessionMessages(req.params.sessionKey).catch(err =>
    console.error('[MessageStore] user session delete cleanup error:', err.message)
  )
  res.json({ ok: true })
})
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat(lifecycle): cascade message store cleanup on session reset/delete"
```

---

## Task 11: Preload — Trigger on SSE Connect

**Files:**
- Modify: `server/index.js` (SSE endpoint, line 4387-4417)

- [ ] **Step 1: Add preload trigger on SSE connection**

In the `app.get('/api/events', ...)` handler, after the client is registered in `sseClients` (after line 4397), add:

After `sseClients.set(clientId, { ... })` and before `res.write(...)`:

```js
  // Preload recent sessions for active user (non-blocking)
  schedulePreloadForUser(req.currentUser.id, {
    getUserSessionsFn: (uid) => getUserSessions(uid),
    fetchFn: fetchHistoryFromGateway,
    topN: 4,
  }).catch(err => console.error('[Preload] error:', err.message))
```

- [ ] **Step 2: Commit**

```bash
git add server/index.js
git commit -m "feat(preload): trigger session preload for active users on SSE connect"
```

---

## Task 12: Integration Testing — End-to-End Verification

**Files:** No new files — manual verification

This task requires a running PostgreSQL instance. Start one with Docker:

```bash
docker run -d --name wattclaw-postgres \
  -e POSTGRES_USER=wattclaw \
  -e POSTGRES_PASSWORD=wattclaw \
  -e POSTGRES_DB=wattclaw \
  -p 5432:5432 \
  postgres:15-alpine
```

- [ ] **Step 1: Verify table creation on startup**

Run the server with `DATABASE_URL=postgresql://wattclaw:wattclaw@localhost:5432/wattclaw node server/index.js`.
Check console for `[MessageStore] Initialized, table session_messages ready`.

Run in PostgreSQL:
```bash
docker exec wattclaw-postgres psql -U wattclaw -d wattclaw -c "\dt session_messages"
```
Expected: Table exists with columns matching spec.

- [ ] **Step 2: Verify write path — user message**

Use the chat UI to send a message. Check PostgreSQL:
```bash
docker exec wattclaw-postgres psql -U wattclaw -d wattclaw -c "SELECT session_key, seq, role, status, LEFT(content, 50) FROM session_messages ORDER BY seq DESC LIMIT 5"
```
Expected: A row with `role='user'`, `status='confirmed'`.

- [ ] **Step 3: Verify write path — assistant message**

After receiving a response, check PostgreSQL again.
Expected: At least one row with `role='assistant'`, `status='confirmed'`.

- [ ] **Step 4: Verify read path — PostgreSQL hit**

Reload the same session in the UI. Check server logs for:
```
[APM - History] PostgreSQL HIT: Xms, N msgs from local store
```
Expected: `Xms < 10ms`, no `[APM - History] Cache MISS` log.

- [ ] **Step 5: Verify read path — lazy backfill**

Access a session that hasn't been visited since PostgreSQL was enabled.
Expected: Logs show `Cache MISS` → Gateway fetch → `[Backfill] Phase 1 ... upserted`.

- [ ] **Step 6: Verify session reset**

Reset a session via UI. Check PostgreSQL:
```bash
docker exec wattclaw-postgres psql -U wattclaw -d wattclaw -c "SELECT COUNT(*) FROM session_messages WHERE session_key = '<the-reset-key>'"
```
Expected: `count = 0`.

- [ ] **Step 7: Verify session delete**

Delete a session via UI. Same check as above.
Expected: `count = 0`.

- [ ] **Step 8: Verify orphan message**

Send a message to a session that doesn't exist in Gateway (manually construct a bad sessionKey). Check PostgreSQL for `status='orphaned'`. Reload history — orphaned message should NOT appear.

- [ ] **Step 9: Verify loadMore (scroll up)**

In a session with >50 messages, scroll up to trigger loadMore. Check server logs for PostgreSQL read with `beforeSeq` parameter.

- [ ] **Step 10: Final commit (if any fixes were needed)**

```bash
git add -A
git commit -m "fix(message-store): integration test fixes"
```

---

## Self-Review Checklist

- [x] **Spec coverage:** Every section in the design doc maps to a task:
  - Section 1 (Storage) → Tasks 2, 3, 4
  - Section 2 (Write Path) → Tasks 7, 8
  - Section 3 (Read Path) → Task 9
  - Section 4 (Lifecycle) → Task 10
  - Section 6 (Preload) → Task 11
  - Section 7 (Pool) → Task 2
  - Section 10 (Implementation Scope) → Tasks 1-11
- [x] **Placeholder scan:** No TBD/TODO/fill-in-later. Every code step has full implementation.
- [x] **Type consistency:** All function names (`upsertMessage`, `getNextSeq`, `batchUpsertMessages`, etc.) match between message-store.js exports and server/index.js imports.
- [x] **No placeholders:** All code steps contain complete implementation.
