# Gateway Stream Decoupling Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Decouple the Gateway HTTP SSE stream from the frontend HTTP connection so that frontend disconnects (refresh, close, timeout) do not terminate Agent execution.

**Architecture:** Replace `pipeline(upstream, res)` with manual data handling in `chat-stream-proxy.js`. Frontend disconnect only nulls the `res` reference; upstream continues consuming Gateway data and discarding it. Only user-initiated cancel explicitly aborts the upstream. Add 1h absolute frontend timeout as last-resort safety net. Persist user messages to PG in workspace send path.

**Tech Stack:** Node.js streams, Express SSE, Vue 3 Pinia, PostgreSQL

**Spec:** `docs/superpowers/specs/2026-05-29-gateway-stream-decoupling-design.md`

---

## File Structure

| File | Action | Responsibility |
|------|--------|----------------|
| `server/services/chat-stream-proxy.js` | Modify | `bind()` rewrite: decouple upstream from res |
| `server/index.js` | Modify | `activeStreamHandles` Map, cancel path, user message PG write |
| `src/stores/workspace.ts` | Modify | Remove 60s/300s timeouts, add 1h fallback |

---

### Task 1: Rewrite `bind()` in chat-stream-proxy.js

**Files:**
- Modify: `server/services/chat-stream-proxy.js:175-222`

This is the core change. Replace `pipeline()` and `req.close → finalize('abort')` with decoupled data handling.

- [ ] **Step 1: Rewrite the `bind()` method**

Replace lines 175-222 (the entire `bind()` method body) with:

```javascript
    bind(req, res) {
        if (this._phase !== StreamPhase.Idle) {
            throw new Error('ChatStreamHandle can only be bound once');
        }
        this.res = res;
        this.transition(StreamPhase.Streaming);

        // Frontend disconnect → detach res, upstream continues independently
        req.once('close', () => {
            this.res = null;
        });

        // Manual data handling: write to res if connected, discard otherwise
        this.upstream.on('data', (chunk) => {
            this.disarmIdleTimer();
            this.armIdleTimer();
            if (this.res && !this.res.writableEnded && !this.res.destroyed) {
                try {
                    this.res.write(chunk);
                } catch {
                    // Write failed (res closing), will detach on next req.close
                }
            }
        });

        this.upstream.on('end', () => this.finalize('end'));
        this.upstream.on('error', (err) => this.finalize('error', err));

        // RAII: destroy upstream on cleanup
        this.registerCleanup(() => {
            if (!this.upstream.destroyed) {
                this.upstream.destroy();
            }
        });

        this.armIdleTimer();
    }
```

- [ ] **Step 2: Remove unused `pipeline` import**

The `pipeline` import on line 15 is no longer used. Change:

```javascript
import { pipeline, Readable } from 'node:stream';
```

to:

```javascript
import { Readable } from 'node:stream';
```

- [ ] **Step 3: Verify no other references to `pipeline` in this file**

Run: `grep -n "pipeline" server/services/chat-stream-proxy.js`

Expected: Only comments should remain (lines 13, 258 mention "pipeline" in comments — update or leave as-is).

- [ ] **Step 4: Commit**

```bash
git add server/services/chat-stream-proxy.js
git commit -m "refactor(stream-proxy): decouple Gateway upstream from frontend HTTP connection

- Replace pipeline(upstream, res) with manual upstream.on('data') + res.write()
- Frontend disconnect only nulls this.res, upstream continues consuming
- Upstream lifecycle controlled by: end/error/idle-timer/abort only
- Remove unused pipeline import"
```

---

### Task 2: Add `activeStreamHandles` and user message PG write in server/index.js

**Files:**
- Modify: `server/index.js`

- [ ] **Step 1: Add `activeStreamHandles` Map declaration**

After line 24 (`import { enqueueBackfill, ... } from './backfill-queue.js'`), add:

```javascript
// Active Gateway stream handles keyed by sessionKey (for cancel path)
const activeStreamHandles = new Map()
```

- [ ] **Step 2: Modify `/api/workspace/send` route — add user message PG write and handle registration**

The current route starts at line 3879. Modify it to:

1. Write user message to PG **before** `chatProxy.connect()` (after ownership tracking)
2. Register handle in `activeStreamHandles` after `handle.bind()`
3. Clean up on `settled`

Replace the `/api/workspace/send` handler (lines 3879-3923) with:

```javascript
app.post('/api/workspace/send', authMiddleware, async (req, res) => {
  try {
    const { sessionKey, message, title, model } = req.body
    if (!sessionKey || !message) {
      return res.status(400).json({ ok: false, error: 'sessionKey and message required' })
    }

    const parts = sessionKey.split(':')
    const agentId = parts.length >= 2 ? parts[1] : null

    // Persist user message to PG before connecting to Gateway
    if (isMessageStoreReady()) {
      const userMsgSeq = await getNextSeq(sessionKey)
      if (userMsgSeq) {
        await upsertMessage({
          sessionKey,
          seq: userMsgSeq,
          role: 'user',
          content: message,
          rawContent: null,
          model: model || null,
          status: 'confirmed',
        }).catch(err => console.error('[MessageStore] workspace user msg write error:', err.message))
      }
    }

    // Phase 2 Service: connection timeout + stream lifecycle management
    const handle = await chatProxy.connect({ sessionKey, message, model, title, agentId })

    // Protocol conversion (Controller layer only)
    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.setHeader('X-Accel-Buffering', 'no')
    res.flushHeaders()

    // Bind stream and activate all lifecycle guards
    handle.bind(req, res)

    // Register handle for cancel path
    activeStreamHandles.set(sessionKey, handle)
    handle.settled.then(() => activeStreamHandles.delete(sessionKey))

    // Fire-and-forget side effects (non-blocking, must not throw)
    const safeTitle = title ? generateSafeTitle(title) : ''
    if (safeTitle && sessionKey) {
      const gatewayLabel = `${safeTitle}-${Date.now()}`
      gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
    }
    trackSessionForUser(req.currentUser.id, sessionKey, agentId, safeTitle, null)

    // Wait for stream to fully close before ending the handler
    await handle.settled
  } catch (err) {
    console.error('[Workspace] Send error:', err)
    if (!res.headersSent) {
      if (err instanceof ChatProxyError) {
        return res.status(err.statusCode).json({ ok: false, error: err.message })
      }
      return res.status(500).json({ ok: false, error: err.message })
    } else if (!res.writableEnded) {
      res.end()
    }
  }
})
```

- [ ] **Step 3: Modify `/api/chat/abort` route to call `handle.abort()`**

The current route is at line 4294. Add `handle.abort()` before the `gateway.call('chat.abort')`.

In the try block (around line 4311), change:

```javascript
    const result = await gateway.call('chat.abort', { sessionKey, ...(runId ? { runId } : {}) })
```

to:

```javascript
    // Abort active Gateway stream handle if one exists
    const streamHandle = activeStreamHandles.get(sessionKey)
    if (streamHandle) streamHandle.abort('user cancelled')
    const result = await gateway.call('chat.abort', { sessionKey, ...(runId ? { runId } : {}) })
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat(workspace-send): persist user message to PG and add stream handle cancel

- Write user message to PG (confirmed) before chatProxy.connect()
- Register handle in activeStreamHandles for cancel path
- /api/chat/cancel now calls handle.abort() before Gateway RPC
- Ensures user message survives page refresh"
```

---

### Task 3: Remove frontend timeouts and add 1h fallback in workspace.ts

**Files:**
- Modify: `src/stores/workspace.ts`

- [ ] **Step 1: Remove `resetStreamTimeout()` function and `streamTimeout` variable**

Delete lines 1950 and 1992-2001:

```typescript
// DELETE line 1950:
let streamTimeout: ReturnType<typeof setTimeout> | null = null

// DELETE lines 1992-2001:
function resetStreamTimeout() {
  if (streamTimeout) clearTimeout(streamTimeout)
  if (sending.value) {
    // 60s idle timeout: cover long tool-call silent periods
    streamTimeout = setTimeout(() => {
      lastError.value = '响应超时，请重试'
      forceStopStreaming()
    }, 60_000)
  }
}
```

Change `maxStreamTimeout` (line 1951) to hold the 1h fallback:

```typescript
let maxStreamTimeout: ReturnType<typeof setTimeout> | null = null
```

(stays the same, just removing `streamTimeout` on the line above)

- [ ] **Step 2: Update `forceStopStreaming()` — remove `streamTimeout` cleanup**

In `forceStopStreaming()` (line 1953), remove the `streamTimeout` line:

```typescript
// DELETE this line:
if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
```

Keep the `maxStreamTimeout` cleanup line.

- [ ] **Step 3: Replace `resetStreamTimeout()` calls in `sendMessage()`**

In `sendMessage()` around line 1666-1669, replace:

```typescript
        // Arm timeout immediately — even if no SSE events arrive, UI recovers in 15s
        resetStreamTimeout()
        if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
        maxStreamTimeout = setTimeout(() => forceStopStreaming(sessionKey), 300_000) // 5 min max
```

with:

```typescript
        // 1h absolute ceiling — last-resort safety net
        if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
        maxStreamTimeout = setTimeout(() => {
          lastError.value = '响应超时，请重试'
          forceStopStreaming(sessionKey)
        }, 3_600_000) // 1 hour
```

- [ ] **Step 4: Remove `resetStreamTimeout()` call in `appendStreamingContent()`**

At line 1756, delete:

```typescript
    resetStreamTimeout()
```

- [ ] **Step 5: Remove all `resetStreamTimeout()` calls in `handleRealtimeEvent()`**

Delete these lines:
- Line 2065 (thinking handler): `resetStreamTimeout()`
- Line 2163 (tool handler): `resetStreamTimeout()`
- Line 2233 (item handler): `resetStreamTimeout()`
- Line 2283 (command_output handler): `resetStreamTimeout()`
- Line 2385 (assistant/compaction handler): `resetStreamTimeout()`
- Line 2396 (lifecycle start handler): `resetStreamTimeout()`

- [ ] **Step 6: Remove `resetStreamTimeout()` calls in `handleEvent()`**

Delete these lines:
- Line 2425: `if (!isAgentDone) resetStreamTimeout()`
- Line 2511: `resetStreamTimeout()`

- [ ] **Step 7: Verify no remaining references**

Run: `grep -n "resetStreamTimeout\|streamTimeout" src/stores/workspace.ts`

Expected: Zero matches (all references deleted).

Run: `grep -n "maxStreamTimeout" src/stores/workspace.ts`

Expected: Only the declaration (line ~1950) and cleanup in `forceStopStreaming()` and the new 1h timer in `sendMessage()`, and the finally block.

- [ ] **Step 8: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix(workspace): remove 60s/300s frontend timeouts, add 1h absolute ceiling

- Delete resetStreamTimeout() and all 12 call sites
- Remove streamTimeout variable (60s idle timer)
- Replace maxStreamTimeout 300s with 1h absolute ceiling
- Backend 600s idle timer is now the primary safety net"
```

---

### Task 4: Manual smoke test

No automated tests are configured. Verify manually.

- [ ] **Step 1: Start dev server**

```bash
npm run dev:all
```

- [ ] **Step 2: Test normal message flow**

Send a simple message. Verify:
- Response streams correctly
- Text delta appears in real time
- Tool calls show progress

- [ ] **Step 3: Test refresh during active task**

Send a complex task (e.g., "列出当前目录文件并分析"). While the agent is processing, refresh the page. Verify:
- Agent continues executing (check server logs for `[ChatStream]` — should NOT show `finalize('abort')`)
- Page loads, shows existing messages from PG
- When agent finishes, final result appears

- [ ] **Step 4: Test user cancel**

Send a message. Click "stop" button. Verify:
- Agent stops executing
- Server logs show `finalize('abort')`

- [ ] **Step 5: Verify server logs**

Check that frontend disconnect logs show:
```
[ChatStream] Finalize reason=end  (NOT reason=abort)
```

When user refreshes, you should NOT see `Finalize reason=abort` immediately after.
