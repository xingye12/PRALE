# HTTP+WS 分离重构实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将聊天功能回退到主分支的 HTTP+EventSource 方案（完整 lifecycle 事件），保留其他接口的 HTTP 优化。

**Architecture:** 前端所有接口统一使用 HTTP；后端 chat.send 使用 Gateway WS RPC 触发获取完整事件，其他接口使用 Gateway HTTP REST。

**Tech Stack:** Vue 3 + TypeScript + Pinia, Express + Node.js, OpenClaw Gateway WebSocket/HTTP

---

## 文件结构

| 文件 | 职责 | 操作 |
|------|------|------|
| `src/stores/workspace.ts` | 聊天核心逻辑：发送消息、事件处理、流式状态 | 修改：回退 sendMessage，删除 fetch SSE 代码 |
| `src/stores/session.ts` | 会话管理：列表、创建、切换 | 保持当前分支 HTTP |
| `src/stores/model.ts` | 模型管理：列表、选择 | 保持当前分支 HTTP |
| `src/stores/websocket.ts` | WebSocket/EventSource 连接管理 | 保持 |
| `src/api/http-client.ts` | HTTP 客户端、EventSource | 保持 |
| `server/index.js` | Express 路由：REST API + SSE 广播 | 修改：回退聊天路由 |
| `server/gateway.js` | Gateway WebSocket 客户端 | 保持 |
| `server/services/chat-stream-proxy.js` | HTTP SSE 流代理 | 删除 |
| `server/utils.js` | 轮询缓存工具 | 保持 |

---

## Task 1: workspace.ts 回退 sendMessage

**Files:**
- Modify: `src/stores/workspace.ts:1556-1751`

**背景：** 当前分支使用 `fetch` + `getReader()` 直接解析 Gateway HTTP SSE 流，丢失了 lifecycle/thinking/tool 事件。需要回退到主分支的 `httpPost` + EventSource 方案。

- [ ] **Step 1: 定位当前 sendMessage 代码**

找到 `src/stores/workspace.ts` 中 `sendMessage` 函数（约 line 1556-1751），确认当前使用 `fetch` 的实现。

- [ ] **Step 2: 替换为 httpPost**

将 `sendMessage` 中的 `fetch` 调用替换为 `httpPost`：

```typescript
// 删除当前分支的 fetch 代码（约 line 1632-1751）
// 包括：
// - const abortController = new AbortController()
// - activeAbortController.value = abortController
// - fetch(apiPath('/api/workspace/send'), {...})
// - const reader = response.body!.getReader()
// - while (true) { reader.read() ... }
// - SSE 解析逻辑（data: 前缀、JSON.parse、choices[0].delta.content）

// 替换为主分支代码：
try {
  const result = await httpPost('/api/workspace/send', {
    sessionKey,
    message: text,
    idempotencyKey,
    ...(titleToSend ? { title: titleToSend } : {}),
  }) as Record<string, unknown>
  const sid = (result.streamId as string) || null
  streamState.streamId = sid
  activeStreamId.value = sid
  // Arm timeout immediately — even if no SSE events arrive, UI recovers in 15s
  resetStreamTimeout()
  if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
  maxStreamTimeout = setTimeout(() => forceStopStreaming(sessionKey), 300_000) // 5 min max
} catch (err: unknown) {
  // 保持现有错误处理
  setSessionSending(sessionKey, false)
  activeStreamId.value = null
  streamState.anchorIndex = null
  streamState.streamId = null
  setSessionStreaming(sessionKey, false)
  const errMsg = err instanceof Error ? err.message : 'Send failed'
  lastError.value = errMsg
  isRateLimited.value = errMsg.includes('rate limit') || errMsg.includes('操作过于频繁')
  const activeModel = getActiveSessionModel()
  if (isRateLimited.value && activeModel) {
    rateLimitedModels.value = new Map(rateLimitedModels.value).set(activeModel, Date.now())
  }
  console.error('[Workspace] Send error:', err)
  throw err
}
```

- [ ] **Step 3: 删除辅助变量和函数**

删除当前分支新增的辅助内容：

```typescript
// 删除（如存在）：
// - activeAbortController ref
// - cancelCurrentRequest 中的 abortController 逻辑
// - appendStreamingContent 函数（如不再使用）
// - appendStreamingToolCall 函数（如不再使用）
// - finalizeStreaming 函数（如不再使用）
```

注意：`cancelCurrentRequest` 需要保留，但改为调用 `httpPost('/api/chat/cancel')`（当前分支已实现）。

- [ ] **Step 4: 验证 httpPost helper 存在**

确认 `httpPost` helper 函数在文件顶部存在（约 line 210）：

```typescript
async function httpPost(url: string, body: Record<string, unknown>): Promise<unknown> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  return response.json()
}
```

如不存在，从主分支复制。

- [ ] **Step 5: 编译检查**

```bash
npx vue-tsc --noEmit
```

Expected: 无错误（或仅与本次修改无关的错误）

- [ ] **Step 6: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "refactor(workspace): revert sendMessage to httpPost + EventSource"
```

---

## Task 2: 恢复 handleEvent 完整处理

**Files:**
- Modify: `src/stores/workspace.ts:2389-2510`

**背景：** 当前分支的 `handleEvent` 可能已存在（用于 EventSource），但需要确认它能正确处理 lifecycle/thinking/tool/command_output 事件。

- [ ] **Step 1: 检查当前 handleEvent 实现**

找到 `handleEvent` 函数（约 line 2389-2510），确认是否已处理所有事件类型：

```typescript
// 应包含以下 case：
function handleEvent(event) {
  switch (event.stream) {
    case 'lifecycle':
      handleLifecycle(event)
      break
    case 'thinking':
      handleThinking(event)
      break
    case 'tool':
      handleTool(event)
      break
    case 'command_output':
      handleCommandOutput(event)
      break
    case 'assistant':
      handleAssistant(event)
      break
    case 'item':
      handleItem(event)
      break
    case 'compaction':
      handleCompaction(event)
      break
  }
}
```

- [ ] **Step 2: 对比主分支补全缺失逻辑**

如当前分支的 `handleEvent` 有缺失，从主分支复制完整实现。

关键检查点：
- `lifecycle:start` 是否正确创建 Agent 活动？
- `lifecycle:end` 是否正确清理状态？
- `thinking` 是否正确显示思考过程？
- `tool` 是否正确显示工具调用？
- `command_output` 是否正确显示命令输出？

- [ ] **Step 3: 编译检查**

```bash
npx vue-tsc --noEmit
```

- [ ] **Step 4: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix(workspace): restore full handleEvent for lifecycle/thinking/tool"
```

---

## Task 3: 后端回退 /api/workspace/send

**Files:**
- Modify: `server/index.js:3889-3984`

**背景：** 当前分支的 `/api/workspace/send` 使用 `ChatStreamProxyService` 透传 Gateway HTTP SSE。需要回退到主分支的 `gateway.call('chat.send')` 触发模式。

- [ ] **Step 1: 定位当前后端路由**

找到 `server/index.js` 中 `app.post('/api/workspace/send', ...)`（约 line 3889-3984）。

- [ ] **Step 2: 替换为 WS RPC 触发**

```javascript
// 删除当前分支代码：
// - const chatProxy = new ChatStreamProxyService()
// - await chatProxy.connect(...)
// - const handle = chatProxy.getStreamHandler()
// - handle.bind(req, res)

// 替换为主分支代码：
app.post('/api/workspace/send', async (req, res) => {
  try {
    const { sessionKey, message, idempotencyKey, title } = req.body
    
    // 验证用户权限
    const userId = req.user?.id
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' })
    }
    
    // 检查会话所有权
    if (!isSessionOwned(sessionKey, userId)) {
      return res.status(403).json({ error: 'Session not owned' })
    }
    
    // 使用 Gateway WS RPC 触发（非阻塞，立即返回 streamId）
    const result = await gateway.call('chat.send', {
      sessionKey,
      message,
      idempotencyKey,
      ...(title ? { title } : {}),
    })
    
    // 返回 streamId
    res.json({ streamId: result.streamId })
    
    // 追踪会话
    trackSessionForUser(sessionKey, userId)
    
  } catch (err) {
    console.error('[Workspace Send] Error:', err)
    res.status(500).json({ error: err.message || 'Send failed' })
  }
})
```

- [ ] **Step 3: 删除 ChatStreamProxyService 引用**

```javascript
// 删除文件顶部引用（如存在）：
// const ChatStreamProxyService = require('./services/chat-stream-proxy')
```

- [ ] **Step 4: 测试后端路由**

```bash
curl -X POST http://localhost:3001/api/workspace/send \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"sessionKey":"agent:test:dm:user","message":"hello","idempotencyKey":"test-123"}'
```

Expected: `{"streamId":"..."}`

- [ ] **Step 5: Commit**

```bash
git add server/index.js
git commit -m "refactor(backend): revert /api/workspace/send to WS RPC trigger"
```

---

## Task 4: 删除 chat-stream-proxy.js

**Files:**
- Delete: `server/services/chat-stream-proxy.js`

**背景：** 该服务仅在当前分支用于透传 Gateway HTTP SSE。回退后不再使用。

- [ ] **Step 1: 确认无其他引用**

```bash
grep -r "chat-stream-proxy" server/ src/
```

Expected: 仅 `/api/workspace/send` 路由中的引用（已在 Task 3 删除）

- [ ] **Step 2: 删除文件**

```bash
rm server/services/chat-stream-proxy.js
```

- [ ] **Step 3: Commit**

```bash
git add server/services/chat-stream-proxy.js
git commit -m "chore: remove unused chat-stream-proxy service"
```

---

## Task 5: 验证其他 HTTP 接口保持正常

**Files:**
- Verify: `src/stores/session.ts`
- Verify: `src/stores/model.ts`
- Verify: `server/index.js` HTTP 路由

**背景：** 当前分支已将 `sessions.list`、`models.list` 等改为 HTTP。需要确认这些改动保持不变。

- [ ] **Step 1: 验证 session.ts**

```typescript
// 确认 listSessions 使用 HTTP
async function listSessions() {
  const token = localStorage.getItem('auth_token')
  const resp = await fetch('/api/sessions', {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
  const data = await resp.json()
  if (!data.ok) throw new Error(data.error?.message || 'Failed')
  const result = data.payload
  const rawSessions = Array.isArray(result.sessions) ? result.sessions : (Array.isArray(result) ? result : [])
  // ...
}
```

- [ ] **Step 2: 验证 model.ts**

```typescript
// 确认 listModels 使用 HTTP
async function listModels() {
  const resp = await fetch('/api/models', { headers })
  const data = await resp.json()
  return data.payload
}
```

- [ ] **Step 3: 验证后端 HTTP 路由存在**

```javascript
// server/index.js 中应存在：
app.get('/api/sessions', ...)
app.get('/api/models', ...)
app.get('/api/config', ...)
```

- [ ] **Step 4: 测试 HTTP 接口**

```bash
# 测试会话列表
curl http://localhost:3001/api/sessions \
  -H "Authorization: Bearer <token>"

# 测试模型列表
curl http://localhost:3001/api/models \
  -H "Authorization: Bearer <token>"
```

Expected: 正常返回 JSON

- [ ] **Step 5: Commit（如有修改）**

```bash
git add -A
git commit -m "verify: keep HTTP optimizations for non-chat APIs"
```

---

## Task 6: 端到端验证

**Files:**
- Test: 完整聊天流程
- Test: 复杂任务（工具调用）

- [ ] **Step 1: 启动服务**

```bash
./start.sh
```

- [ ] **Step 2: 测试简单聊天**

1. 打开浏览器，登录系统
2. 选择 Agent，发送消息"你好"
3. 确认：
   - 消息正常显示
   - 收到回复
   - Network 面板显示 `POST /api/workspace/send` 返回 `{"streamId":"..."}`
   - EventSource 连接 `/api/events` 正常接收事件

- [ ] **Step 3: 测试复杂任务（工具调用）**

1. 发送消息"帮我查看 docker 状态"
2. 确认：
   - 显示 thinking 过程
   - 显示 tool 调用
   - 显示 command_output
   - 最终收到回复
   - 无断流、无丢失

- [ ] **Step 4: 测试取消功能**

1. 发送长消息
2. 点击取消按钮
3. 确认请求终止

- [ ] **Step 5: 测试历史记录**

1. 切换会话
2. 确认历史记录正常加载（HTTP GET `/api/chat/history`）

- [ ] **Step 6: 测试会话列表**

1. 刷新页面
2. 确认会话列表正常加载（HTTP GET `/api/sessions`）

- [ ] **Step 7: Commit**

```bash
git add -A
git commit -m "test: verify chat lifecycle + HTTP APIs after revert"
```

---

## 验证清单

- [ ] 聊天正常收发，能收到 lifecycle 事件
- [ ] 复杂任务（工具调用）正常，显示 thinking/tool/command_output
- [ ] 历史记录加载正常（HTTP GET `/api/chat/history`）
- [ ] 会话列表加载正常（HTTP GET `/api/sessions`）
- [ ] 模型列表加载正常（HTTP GET `/api/models`）
- [ ] 空闲时无轮询 RPC
- [ ] 取消按钮正常
- [ ] 新建会话正常
- [ ] ScenarioWizard 正常
- [ ] 多用户并发，非聊天接口不阻塞

---

## 回滚方案

如实施过程中出现问题，回滚步骤：

```bash
# 查看当前分支提交
git log --oneline -10

# 回滚到实施前状态
git reset --hard <实施前-commit-hash>

# 或逐个回滚
git revert <task-commit-hash>
```

---

## 参考文档

- [设计文档 V2](../specs/2026-05-30-http-ws-separation-design-v2.md)
- [HTTP+WS 分离分析](../../chat-flow-v2/http-ws-separation-analysis.md)
- [当前流式链路梳理](../../chat-flow-v2/current-streaming-linkage-analysis.md)
