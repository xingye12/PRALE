# WS RPC → HTTP 迁移实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 WattClaw 后端与 OpenClaw Gateway 的非聊天 WS RPC 通信迁移到 HTTP，消除单连接队头阻塞。

**Architecture:** 新增 4 个 HTTP 工具函数（`_buildGatewayHttpOptions`、`gatewayAdminRpc`、`gatewayHttpGet`、`gatewayHttpPost`），替换 `server/index.js` 中 47 处 `gateway.call()` 中的 25 处为 HTTP 调用，12 处 `gateway.isConnected` 守卫去掉，1 处改为方法级别判断。

**Tech Stack:** Node.js / Express / fetch API / admin-http-rpc 插件

**Design Spec:** `docs/superpowers/specs/2026-05-31-ws-rpc-to-http-migration-design.md`

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `server/index.js` | Modify | 唯一改动文件。新增 HTTP 工具函数、替换 WS RPC 调用、去掉 isConnected 守卫 |

> 不新增文件，不拆分文件。所有改动集中在 `server/index.js` 中，遵循现有单文件架构。

---

## Task 1: 添加 HTTP 工具函数

**Files:**
- Modify: `server/index.js`（在 `fetchHistoryFromGateway` 函数之前插入，约 line 350 附近）

- [ ] **Step 1: 在 `server/index.js` 中 `fetchHistoryFromGateway` 函数之前，添加 4 个 HTTP 工具函数**

在 line 356（`async function fetchHistoryFromGateway`）之前插入：

```javascript
// ─── Gateway HTTP Communication Layer ───────────────────────
// 通过 admin-http-rpc 插件和 Gateway 原生 HTTP 端点，
// 将 WS RPC 调用迁移到 HTTP，消除单连接队头阻塞。

function _buildGatewayHttpOptions() {
  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
  const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
  return {
    baseUrl: `${protocol}://${wsUrl.host}`,
    headers: {
      Authorization: `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN || ''}`,
    },
  }
}

async function gatewayAdminRpc(method, params = {}, timeoutMs = 15_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL('/api/v1/admin/rpc', baseUrl)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: `rpc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        method,
        params,
      }),
      signal: controller.signal,
    })

    if (!res.ok) {
      return { ok: false, error: `Gateway admin RPC HTTP ${res.status}` }
    }

    const data = await res.json()
    if (data.ok) {
      return { ok: true, payload: data.payload }
    }
    return { ok: false, error: data.error?.message || 'Gateway admin RPC error' }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}

async function gatewayHttpGet(path, params = {}, timeoutMs = 30_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL(path, baseUrl)
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, String(v))
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      headers,
      signal: controller.signal,
    })
    if (!res.ok) return { ok: false, error: `Gateway HTTP ${res.status}` }
    const data = await res.json()
    return { ok: true, data }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}

async function gatewayHttpPost(path, body = {}, timeoutMs = 30_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL(path, baseUrl)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    if (!res.ok) return { ok: false, error: `Gateway HTTP ${res.status}` }
    const data = await res.json()
    return { ok: true, data }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}
```

- [ ] **Step 2: 验证函数插入位置正确**

Run: `grep -n '_buildGatewayHttpOptions\|gatewayAdminRpc\|gatewayHttpGet\|gatewayHttpPost' server/index.js | head -10`
Expected: 4 个函数签名出现在 `fetchHistoryFromGateway` 之前

- [ ] **Step 3: 快速冒烟测试 — 启动后端确认无语法错误**

Run: `node -e "require('./server/index.js')" 2>&1 | head -5`
Expected: 无 SyntaxError（可能有连接错误但不应有解析错误）

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: add Gateway HTTP utility functions for admin-http-rpc migration"
```

---

## Task 2: 重构 fetchHistoryFromGateway

**Files:**
- Modify: `server/index.js`（`fetchHistoryFromGateway` 函数，原 line 356-395）

- [ ] **Step 1: 替换 `fetchHistoryFromGateway` 函数体**

将 `fetchHistoryFromGateway` 函数中的内联 fetch 替换为 `gatewayHttpGet`。保留 `extractMessagesFromHistoryPayload` 调用和后续的标准化逻辑。

改前（内联 URL 构建 + fetch）：
```javascript
const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
const gatewayUrl = new URL(...)
// ... 手动 fetch
```

改后：
```javascript
async function fetchHistoryFromGateway(sessionKey, limit = 50) {
  const result = await gatewayHttpGet(
    `/sessions/${encodeURIComponent(sessionKey)}/history`,
    { limit }
  )
  if (!result.ok) return []

  const messages = extractMessagesFromHistoryPayload(result.data)
  return messages.map((m, i) => {
    let msgTimestamp = null
    if (m.timestamp || m.createdAt || m.created_at || m.ts || m.time) {
      try { msgTimestamp = new Date(m.timestamp || m.createdAt || m.created_at || m.ts || m.time).toISOString() } catch {}
    }
    return {
      seq: i + 1,
      msgId: m.id || m.msg_id || null,
      role: m.role || 'unknown',
      content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
      rawContent: m,
      model: m.model || null,
      status: 'confirmed',
      msgTimestamp,
    }
  })
}
```

- [ ] **Step 2: 验证重构后格式不变**

Run: `grep -A5 'extractMessagesFromHistoryPayload' server/index.js | head -10`
Expected: `extractMessagesFromHistoryPayload(result.data)` 调用存在

- [ ] **Step 3: Commit**

```bash
git add server/index.js
git commit -m "refactor: rewrite fetchHistoryFromGateway to use gatewayHttpGet"
```

---

## Task 3: 替换轮询缓存 fetcher

**Files:**
- Modify: `server/index.js`（`cronListPolling` line 736、`modelsListPolling` line 741、`configGetPolling` line 751）

- [ ] **Step 1: 替换 `cronListPolling`**

改前（line ~736）：
```javascript
const cronListPolling = createPollingCache(11_000, async () => {
  if (!gateway.isConnected) return cronListPolling?.getData() || null
  return gateway.call('cron.list', {includeDisabled: true})
})
```

改后：
```javascript
const cronListPolling = createPollingCache(11_000, async () => {
  const result = await gatewayAdminRpc('cron.list', { includeDisabled: true })
  if (!result.ok) return cronListPolling?.getData() || null
  return result.payload
})
```

- [ ] **Step 2: 替换 `modelsListPolling`**

改前（line ~741）：
```javascript
const modelsListPolling = createPollingCache(13_000, async () => {
  if (!gateway.isConnected) return modelsListPolling?.getData() || null
  return gateway.call('models.list', {})
})
```

改后：
```javascript
const modelsListPolling = createPollingCache(13_000, async () => {
  const result = await gatewayAdminRpc('models.list', {})
  if (!result.ok) return modelsListPolling?.getData() || null
  return result.payload
})
```

- [ ] **Step 3: 替换 `configGetPolling`**

改前（line ~751）：
```javascript
const configGetPolling = createPollingCache(19_000, async () => {
  if (!gateway.isConnected) return configGetPolling?.getData() || null
  return gateway.call('config.get', {})
})
```

改后：
```javascript
const configGetPolling = createPollingCache(19_000, async () => {
  const result = await gatewayAdminRpc('config.get', {})
  if (!result.ok) return configGetPolling?.getData() || null
  return result.payload
})
```

- [ ] **Step 4: 验证 3 个缓存都改完**

Run: `grep -n 'gatewayAdminRpc' server/index.js | grep 'Polling'`
Expected: cronListPolling、modelsListPolling、configGetPolling 各出现一次

- [ ] **Step 5: Commit**

```bash
git add server/index.js
git commit -m "feat: migrate cron/models/config polling caches from WS RPC to HTTP"
```

---

## Task 4: 替换 ConfigQueue 内部调用

**Files:**
- Modify: `server/index.js`（`configQueueExecute` line ~859、`ConfigQueue._execute` 内部 4 处 `gateway.call`）

- [ ] **Step 1: 去掉 `configQueueExecute` 的 `gateway.isConnected` 检查**

改前（line ~859）：
```javascript
function configQueueExecute (transformFn, label, method) {
  if (!gateway.isConnected) throw new Error('Gateway not connected')
  return configQueue.enqueue(transformFn, label, method)
}
```

改后：
```javascript
function configQueueExecute (transformFn, label, method) {
  return configQueue.enqueue(transformFn, label, method)
}
```

- [ ] **Step 2: 替换 `ConfigQueue._execute` 内部 4 处 `gateway.call`**

在 `_execute` 方法中，每次 `gateway.call(...)` 替换为 `gatewayAdminRpc(...)` + `if (!ok) throw` 模式：

改前：
```javascript
const payload = await gateway.call('config.get', {})
```

改后：
```javascript
const _r1 = await gatewayAdminRpc('config.get', {})
if (!_r1.ok) throw new Error(_r1.error)
const payload = _r1.payload
```

同样模式应用于第 2、3、4 次调用。注意第 2 次调用是动态 method：
```javascript
const _r2 = await gatewayAdminRpc(method, { raw, baseHash })
if (!_r2.ok) throw new Error(_r2.error)
// result of patch/set, may not need payload
```

- [ ] **Step 3: 验证 ConfigQueue 中不再有 `gateway.call`**

Run: `grep -n 'gateway.call' server/index.js | grep -i 'config\|queue\|execute'`
Expected: 无匹配

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: migrate ConfigQueue from WS RPC to HTTP via gatewayAdminRpc"
```

---

## Task 5: 替换 REST 端点和辅助函数中的直接调用

**Files:**
- Modify: `server/index.js`（7 个位置）

- [ ] **Step 1: 替换 `backfillAgentModels()` fallback（line ~225）**

改前：
```javascript
const cfgResult = configGetPolling.getData() || await gateway.call('config.get', {})
```

改后：
```javascript
let cfgResult = configGetPolling.getData()
if (!cfgResult) {
  const rpcResult = await gatewayAdminRpc('config.get', {})
  cfgResult = rpcResult.ok ? rpcResult.payload : null
}
```

同时去掉 line ~219 的 `gateway.isConnected` 守卫（如果该入口有的话）。

- [ ] **Step 2: 替换 `GET /api/system-info` 中的 `health` 调用（line ~2752）**

改前：
```javascript
if (gateway.isConnected) {
  const health = await gateway.call('health')
  uptime = health?.uptime || uptime
}
```

改后（去掉 isConnected 守卫，改用 HTTP）：
```javascript
try {
  const rpcResult = await gatewayAdminRpc('health')
  if (rpcResult.ok) {
    uptime = rpcResult.payload?.uptime || uptime
  }
} catch {}
```

- [ ] **Step 3: 替换 `GET /api/status` 端点（line ~3396-3403）**

改前：
```javascript
app.get('/api/status', authMiddleware, async (req, res) => {
  try {
    if (!gateway.isConnected) {
      return res.status(503).json({ error: 'Gateway not connected' })
    }
    const status = await gateway.call('status')
    res.json({ ok: true, payload: status })
```

改后：
```javascript
app.get('/api/status', authMiddleware, async (req, res) => {
  try {
    const rpcResult = await gatewayAdminRpc('status')
    if (!rpcResult.ok) {
      return res.status(503).json({ error: rpcResult.error })
    }
    res.json({ ok: true, payload: rpcResult.payload })
```

- [ ] **Step 4: 替换 `getAgentWorkspace()` 函数（line ~2844-2860）**

改前：
```javascript
if (!gateway.isConnected) {
  return null
}
try {
  const listResult = await gateway.call('agents.list')
  const agents = listResult?.agents || listResult || []
```

改后：
```javascript
try {
  const rpcResult = await gatewayAdminRpc('agents.list')
  if (!rpcResult.ok) return null
  const listResult = rpcResult.payload
  const agents = listResult?.agents || listResult || []
```

同时去掉 line ~2867 的 `gateway.isConnected` 守卫。

- [ ] **Step 5: 替换 `sync-from-gateway` 中的 `config.get`（line ~2437）**

改前：
```javascript
if (!gateway.isConnected) {
  return res.json({ channel: null })
}
// ...
const cfgResult = await gateway.call('config.get')
```

改后（缓存优先 + HTTP fallback）：
```javascript
let cfgResult = configGetPolling.getData()
if (!cfgResult) {
  const rpcResult = await gatewayAdminRpc('config.get')
  cfgResult = rpcResult.ok ? rpcResult.payload : null
}
if (!cfgResult) {
  return res.json({ channel: null })
}
```

- [ ] **Step 6: 替换 `logoutChannelFromGateway()`（line ~2313-2324）**

改前：
```javascript
async function logoutChannelFromGateway(channel) {
  if (!gateway.isConnected) return
  try {
    await gateway.call('channels.logout', {
      channel: channel.channel_type,
      accountId: channel.agent_id,
    })
```

改后：
```javascript
async function logoutChannelFromGateway(channel) {
  try {
    const rpcResult = await gatewayAdminRpc('channels.logout', {
      channel: channel.channel_type,
      accountId: channel.agent_id,
    })
    if (!rpcResult.ok) {
      console.error('[ChannelSync] logout failed:', rpcResult.error)
      return
    }
```

- [ ] **Step 7: 替换 agent-team 中的 `agents.list` 调用（line ~1646, ~1749）**

在 `POST /api/agent-team/migrate-bootstrap` 和 `POST /api/agent-team/repair-bootstrap` 中：

改前：
```javascript
const agentsResult = await gateway.call('agents.list')
```

改后：
```javascript
const _rpcResult = await gatewayAdminRpc('agents.list')
if (!_rpcResult.ok) throw new Error(_rpcResult.error)
const agentsResult = _rpcResult.payload
```

两处都改。

- [ ] **Step 8: 去掉 channel CRUD 相关的 `gateway.isConnected` 守卫（line ~2209, ~2278）**

`syncChannelToGateway` 和 `removeChannelFromGateway` 的入口守卫：
```javascript
// 改前
if (!gateway.isConnected) {
  // ... return or throw
}

// 改后：直接删除这几行（ConfigQueue 已改为 HTTP，不再依赖 WS）
```

- [ ] **Step 9: Commit**

```bash
git add server/index.js
git commit -m "feat: migrate REST endpoints and helpers from WS RPC to HTTP"
```

---

## Task 6: 替换 autoTitle 和 agent session 批量历史

**Files:**
- Modify: `server/index.js`（`autoTitle` line ~1060-1118、agent session history line ~1895-1934）

- [ ] **Step 1: 替换 `autoTitle()` 中的 WS RPC 调用**

改前（line ~1074-1092）：
```javascript
let historyResult = null
const candidates = [
  { method: 'chat.history', params: { sessionKey } },
  { method: 'sessions.history', params: { sessionKey } },
]
for (const c of candidates) {
  try {
    historyResult = await gateway.call(c.method, c.params)
    if (historyResult) break
  } catch { /* try next */ }
}
if (!historyResult) return

let messages
if (Array.isArray(historyResult)) {
  messages = historyResult
} else if (historyResult && typeof historyResult === 'object') {
  messages = historyResult.messages || historyResult.history || []
}
```

改后：
```javascript
const httpResult = await gatewayHttpGet(
  `/sessions/${encodeURIComponent(sessionKey)}/history`,
  { limit: 10 }
)
if (!httpResult.ok) return

let messages
const data = httpResult.data
if (Array.isArray(data)) {
  messages = data
} else if (data && typeof data === 'object') {
  messages = data.messages || data.history || data.items || []
}
```

- [ ] **Step 2: 去掉 `autoTitle` 入口附近的 `gateway.isConnected` 检查**

`autoTitle` 函数中如果有 `!gateway.isConnected` 守卫，改为只检查 `sessionKey`：
```javascript
// 改前
if (!sessionKey || !gateway.isConnected) return

// 改后
if (!sessionKey) return
```

- [ ] **Step 3: 替换 agent session 批量历史查询（line ~1895-1934）**

改前（5 种 WS RPC 候选方法循环）：
```javascript
const candidates = [
  { method: 'chat.history', params: { sessionKey } },
  { method: 'sessions.history', params: { sessionKey } },
  { method: 'session.history', params: { sessionKey } },
  { method: 'sessions.get', params: { key: sessionKey } },
  { method: 'session.get', params: { key: sessionKey } },
]
for (const c of candidates) {
  try {
    historyResult = await gateway.call(c.method, c.params)
    if (historyResult) break
  } catch {
    // Try next method
  }
}
if (!historyResult) continue

let messages
if (Array.isArray(historyResult)) {
  messages = historyResult
} else if (historyResult && typeof historyResult === 'object') {
  messages = historyResult.messages || historyResult.history || historyResult.payload
  if (!Array.isArray(messages)) messages = []
} else {
  messages = []
}
```

改后（直接用 HTTP）：
```javascript
const httpResult = await gatewayHttpGet(
  `/sessions/${encodeURIComponent(sessionKey)}/history`,
  { limit: 50 }
)
if (!httpResult.ok) continue

let messages
const data = httpResult.data
if (Array.isArray(data)) {
  messages = data
} else if (data && typeof data === 'object') {
  messages = data.messages || data.history || data.items || data.payload || []
  if (!Array.isArray(messages)) messages = []
} else {
  messages = []
}
```

- [ ] **Step 4: Commit**

```bash
git add server/index.js
git commit -m "feat: migrate autoTitle and batch history from WS RPC to gatewayHttpGet"
```

---

## Task 7: 替换 /api/rpc 代理端点

**Files:**
- Modify: `server/index.js`（`POST /api/rpc` 端点，line ~3406-3880）

这是最复杂的任务。改动包括：
1. 全局守卫改为方法级别
2. 非管理员分支中 `status` 调用改用 HTTP
3. 管理员分支缓存返回（cron/agents/config/models 已通过轮询缓存走 HTTP）
4. 管理员分支 `isUsage` 保留 WS RPC
5. 管理员透传段加白名单判断

- [ ] **Step 1: 在文件顶部（HTTP 工具函数附近）定义统一的 `HTTP_RPC_METHODS` Set**

```javascript
const HTTP_RPC_METHODS = new Set([
  // Polling cache methods
  'config.get', 'cron.list', 'models.list', 'agents.list',
  // Config mutations
  'config.patch', 'config.set', 'config.apply',
  // System
  'health', 'status',
  // Admin-only methods (passthrough)
  'agents.create', 'agents.update', 'agents.delete',
  'channels.status', 'channels.start', 'channels.stop', 'channels.logout',
  'config.schema', 'config.schema.lookup',
  'cron.status', 'cron.get', 'cron.add', 'cron.update', 'cron.remove', 'cron.run', 'cron.runs',
  'models.authStatus',
  'exec.approvals.get', 'exec.approvals.set',
  'exec.approvals.node.get', 'exec.approvals.node.set',
  'node.list', 'node.describe', 'node.pair.list', 'node.pair.approve', 'node.pair.reject', 'node.pair.remove', 'node.rename',
  'tasks.list', 'tasks.get', 'tasks.cancel',
  'usage.status', 'usage.cost',
  'logs.tail', 'gateway.restart.request',
  'device.pair.list', 'device.pair.approve', 'device.pair.reject', 'device.pair.remove',
  'doctor.memory.status', 'update.status',
])
```

- [ ] **Step 2: 改造 `/api/rpc` 全局守卫（line ~3413）**

改前：
```javascript
if (!gateway.isConnected) {
  return res.status(503).json({ error: 'Gateway not connected' })
}
```

改后：
```javascript
if (!gateway.isConnected && !HTTP_RPC_METHODS.has(normMethod)) {
  return res.status(503).json({ error: 'Gateway not connected' })
}
```

- [ ] **Step 3: 替换非管理员分支中 `status` 调用（line ~3606）**

改前：
```javascript
const status = await gateway.call(method, params)
```

改后：
```javascript
const rpcResult = await gatewayAdminRpc(method, params)
if (!rpcResult.ok) throw new Error(rpcResult.error)
const status = rpcResult.payload
```

- [ ] **Step 4: 替换管理员分支中 `health / status` 调用**

在管理员分支的特定处理中，如果 `health` 或 `status` 有直接的 `gateway.call`，替换为 `gatewayAdminRpc`。

- [ ] **Step 5: 替换管理员透传段（line ~3822）**

在管理员分支末尾的通用透传代码前，加入 `isUsage` 保留 + 白名单判断：

```javascript
// 优先处理 usage（不走 HTTP，不在白名单）
if (isUsage) {
  const result = await callGatewayUsage(params)
  // ... usage 重建逻辑保持不变 ...
  return res.json({ ok: true, payload: result })
}

// 白名单方法走 HTTP
if (HTTP_RPC_METHODS.has(normMethod)) {
  const rpcResult = await gatewayAdminRpc(method, params)
  if (!rpcResult.ok) throw new Error(rpcResult.error)
  return res.json({ ok: true, payload: rpcResult.payload })
}

// 最终 fallback 走 WS RPC
const result = await gateway.call(method, params)
return res.json({ ok: true, payload: result })
```

- [ ] **Step 6: 验证 `/api/rpc` 中无遗漏的 `gateway.call`**

Run: `grep -n 'gateway.call' server/index.js | grep -v 'chat\.\|session\.\|skills\.\|agents\.files\.\|system-presence'`
Expected: 仅剩聊天、session 管理、skills、agents.files 等不可迁移方法的调用

- [ ] **Step 7: Commit**

```bash
git add server/index.js
git commit -m "feat: migrate /api/rpc proxy to HTTP with method-level routing"
```

---

## Task 8: 清理剩余 isConnected 守卫 + 最终验证

**Files:**
- Modify: `server/index.js`（按设计文档 3.7 节清单清理）

- [ ] **Step 1: 确认所有需要去掉的 `gateway.isConnected` 已处理**

按设计文档 3.7 节清单逐一验证：

Run: `grep -n 'gateway.isConnected' server/index.js`
Expected: 仅保留以下行（12 处）：
- `allSessionsPolling`（sessions.list 不迁移）
- `skillsStatusPolling`（skills.status 不迁移）
- `_doPushTokenUpdate`（sessions.usage 不迁移）
- agent-team 3 处（agents.files 不迁移）
- 状态展示字符串 2 处（纯展示）
- `system-presence` 调用（不在白名单）
- `chat.send` / `chat.abort` 端点守卫（不迁移）
- `/api/rpc` 已改为方法级别

如果有多余的未去掉守卫，逐个去掉。

- [ ] **Step 2: 启动后端确认无报错**

Run: `./start.sh`
Expected: 后端正常启动，无 Uncaught TypeError 或 ReferenceError

- [ ] **Step 3: 功能验证 — 轮询缓存**

打开前端，观察浏览器 Network 面板：
1. 模型列表正常加载 → `modelsListPolling` 通过 HTTP 拿到数据
2. 定时任务列表正常 → `cronListPolling` 通过 HTTP 拿到数据
3. 配置正常显示 → `configGetPolling` 通过 HTTP 拿到数据

- [ ] **Step 4: 功能验证 — REST 端点**

1. 系统监控页面 → `GET /api/system-info` 的 health 数据正常
2. 系统状态页面 → `GET /api/status` 正常
3. Agent 工作空间 → `GET /api/agents/workspace` 正常
4. 频道管理 → 创建/更新/删除频道正常（通过 ConfigQueue HTTP）

- [ ] **Step 5: 功能验证 — 聊天**

1. 打开会话列表 → `sessions.list` 仍走 WS RPC，正常显示
2. 发送消息 → `chat.send` 仍走 WS RPC，正常收发
3. 取消生成 → `chat.abort` 仍走 WS RPC，正常取消

- [ ] **Step 6: 最终 Commit**

```bash
git add server/index.js
git commit -m "refactor: clean up remaining gateway.isConnected guards for HTTP-migrated methods"
```

---

## Self-Review Checklist

- [x] **Spec coverage**: 设计文档 3.1-3.7 每一节都有对应 Task 覆盖
- [x] **Placeholder scan**: 无 TBD/TODO，每步有具体代码
- [x] **Type consistency**: `gatewayAdminRpc` 返回 `{ ok, payload }` 在所有 Task 中一致使用
- [x] **No test framework**: CLAUDE.md 明确说明 "No test framework configured yet"，验证通过手动启动 + 功能测试
- [x] **Single file change**: 所有改动在 `server/index.js`
- [x] **Commit granularity**: 8 个 Task，每个独立可提交
