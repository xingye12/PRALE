# Models SQLite Localization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move model-list reads from Gateway RPC to SQLite, with one frontend model store and one backend model repository.

**Architecture:** `models` becomes the SQLite source of truth for reads. Gateway is only a synchronization source via `syncModelsFromGateway()`. Frontend model state is centralized in `useModelStore`; all direct `wsStore.rpc.listModels()` calls are removed.

**Tech Stack:** Vue 3 + Pinia + TypeScript frontend, Node.js/Express backend, better-sqlite3 SQLite, OpenClaw Gateway admin RPC for synchronization only.

---

## File Structure

### Backend

- Modify: `server/database.js`
  - Add `models` table.
  - Add model indexes.
  - Migrate `model_remarks` into `models.remark`.
  - Rename `model_remarks` to `model_remarks_deprecated` when present.

- Create: `server/model-manager.js`
  - Own model normalization.
  - Own SQLite model reads.
  - Own Gateway-to-SQLite synchronization.
  - Preserve `enabled` and `remark` during sync.
  - Mark missing Gateway models `available = 0`.

- Create: `server/handlers/models.js`
  - `GET /api/models` reads SQLite.
  - `POST /api/models/sync` is admin-only and synchronizes from Gateway.

- Modify: `server/index.js`
  - Register `createModelRoutes(app)`.
  - Import and call `syncModelsFromGateway()` on Gateway connect/reconnect.
  - Remove `getModelsList` and `invalidateModelsCache` imports.
  - Delete `models.list` / `models.get` RPC proxy branches for both normal users and admins.

- Modify: `server/core/gateway-client.js`
  - Remove `_modelsCache`.
  - Remove `getModelsList()`.
  - Remove `invalidateModelsCache()`.
  - Keep `gatewayAdminRpc()` unchanged.

### Frontend

- Modify: `src/stores/model.ts`
  - Remove WebSocket store dependency.
  - Fetch models through `GET /api/models`.
  - Normalize REST response to `ModelInfo[]`.

- Modify: `src/stores/agent.ts`
  - Delete local `models` ref.
  - Delete local `fetchModels()`.
  - Remove `await fetchModels()` from initialization.
  - Remove `models` and `fetchModels` from store return.

- Modify: `src/views/agents/AgentsPage.vue`
  - Import `useModelStore` if not already imported.
  - Replace `agentStore.fetchModels()` with `modelStore.fetchModels()`.

- Modify: `src/views/Dashboard.vue`
  - Replace direct `wsStore.rpc.listModels()` with local model API/store.
  - Ensure dashboard counts use locally fetched models.

---

## Task 1: Add SQLite `models` schema and migrate `model_remarks`

**Files:**
- Modify: `server/database.js`

- [ ] **Step 1: Inspect current DB schema block**

Read `server/database.js` around the `user_model_providers` and `model_remarks` schema area. Confirm `user_model_providers` exists and `model_remarks` is created or migrated elsewhere.

- [ ] **Step 2: Add `models` table creation**

In `server/database.js`, add this SQL near other core table definitions, before migration code runs:

```sql
CREATE TABLE IF NOT EXISTS models (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL DEFAULT '',
  label TEXT DEFAULT '',
  family TEXT DEFAULT '',
  enabled INTEGER DEFAULT 1,
  available INTEGER DEFAULT 1,
  description TEXT DEFAULT '',
  context_window INTEGER DEFAULT 0,
  capabilities TEXT DEFAULT '[]',
  remark TEXT DEFAULT '',
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
);

CREATE INDEX IF NOT EXISTS idx_models_provider ON models(provider);
CREATE INDEX IF NOT EXISTS idx_models_available ON models(available);
```

Use `provider TEXT NOT NULL DEFAULT ''` so legacy remark migration can insert remark-only rows before Gateway backfill knows provider metadata.

- [ ] **Step 3: Add safe remark migration code**

After the generic column migrations, add guarded JS migration logic:

```js
try {
  const hasModelRemarks = db.prepare(
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'model_remarks'"
  ).get()
  if (hasModelRemarks) {
    db.exec(`
      INSERT INTO models (id, provider, remark, updated_at)
        SELECT model_id, provider_id, remark, updated_at FROM model_remarks
        WHERE model_id IS NOT NULL AND model_id != ''
        ON CONFLICT(id) DO UPDATE SET
          remark = CASE
            WHEN models.remark IS NULL OR models.remark = '' THEN excluded.remark
            ELSE models.remark
          END,
          updated_at = MAX(models.updated_at, excluded.updated_at)
    `)

    const hasDeprecated = db.prepare(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'model_remarks_deprecated'"
    ).get()
    if (!hasDeprecated) {
      db.exec('ALTER TABLE model_remarks RENAME TO model_remarks_deprecated')
    }
  }
} catch (e) {
  console.error('[Database] model_remarks migration error:', e.message)
}
```

This preserves existing `models.remark` if it already exists and only renames `model_remarks` once.

- [ ] **Step 4: Verify schema initializes**

Run:

```bash
node -e "import('./server/database.js').then(() => console.log('database ok'))"
```

Expected output includes:

```text
database ok
```

- [ ] **Step 5: Verify table exists**

Run:

```bash
sqlite3 data/wizard.db ".schema models"
```

Expected output contains:

```text
CREATE TABLE models
CREATE INDEX idx_models_provider
CREATE INDEX idx_models_available
```

---

## Task 2: Create backend model repository and synchronization module

**Files:**
- Create: `server/model-manager.js`

- [ ] **Step 1: Create `server/model-manager.js` with imports and helpers**

Create the file with this structure:

```js
import db from './database.js'
import { gatewayAdminRpc } from './core/gateway-client.js'

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function asString(value, fallback = '') {
  if (value === undefined || value === null) return fallback
  return String(value)
}

function asNumber(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function asBoolean(value, fallback = true) {
  if (value === undefined || value === null) return fallback
  if (typeof value === 'boolean') return value
  if (typeof value === 'number') return value !== 0
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase()
    if (['true', '1', 'yes', 'on'].includes(normalized)) return true
    if (['false', '0', 'no', 'off'].includes(normalized)) return false
  }
  return fallback
}

function normalizeCapabilities(value) {
  if (!Array.isArray(value)) return []
  return value.map(item => asString(item)).filter(Boolean)
}
```

- [ ] **Step 2: Add model normalization**

Add:

```js
export function normalizeModelItem(value) {
  const row = asRecord(value)
  const contextWindow = asNumber(
    row.contextWindow || row.context_window || row.context_length || row.context || row.maxContext,
    0
  )
  const id = asString(row.id || row.model || row.name, '')
  const provider = asString(row.provider || row.vendor || id.split('/')[0] || '', '')

  return {
    id,
    label: asString(row.label || row.displayName || row.name || row.model || id, ''),
    provider,
    family: asString(row.family || row.type, ''),
    enabled: asBoolean(row.enabled, true),
    available: asBoolean(row.available, true),
    description: asString(row.description, ''),
    contextWindow,
    capabilities: normalizeCapabilities(row.capabilities),
  }
}

export function normalizeModelList(payload) {
  const row = asRecord(payload)
  const candidates = [row.models, row.items, row.list, row.data, row.entries, payload]
  const list = candidates.find(Array.isArray) || []
  return list.map(normalizeModelItem).filter(item => item.id)
}
```

- [ ] **Step 3: Add DB row mapping and list query**

Add:

```js
function parseCapabilities(value) {
  if (!value) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed.map(item => asString(item)).filter(Boolean) : []
  } catch {
    return []
  }
}

function mapModelRow(row) {
  return {
    id: row.id,
    label: row.label || undefined,
    provider: row.provider || undefined,
    family: row.family || undefined,
    enabled: !!row.enabled,
    available: !!row.available,
    description: row.description || undefined,
    contextWindow: row.context_window > 0 ? row.context_window : undefined,
    capabilities: parseCapabilities(row.capabilities),
    remark: row.remark || '',
  }
}

export function listModelsFromDb({ includeUnavailable = true } = {}) {
  const sql = includeUnavailable
    ? 'SELECT * FROM models ORDER BY provider ASC, id ASC'
    : 'SELECT * FROM models WHERE available = 1 AND enabled = 1 ORDER BY provider ASC, id ASC'
  return db.prepare(sql).all().map(mapModelRow)
}
```

- [ ] **Step 4: Add upsert sync logic**

Add:

```js
const existingMetaStmt = db.prepare('SELECT id, enabled, remark FROM models')
const upsertModelStmt = db.prepare(`
  INSERT OR REPLACE INTO models
  (id, provider, label, family, enabled, available, description, context_window, capabilities, remark, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`)

function upsertModels(models) {
  const now = Date.now()
  const existing = new Map(existingMetaStmt.all().map(row => [row.id, row]))

  for (const model of models) {
    const previous = existing.get(model.id)
    upsertModelStmt.run(
      model.id,
      model.provider || '',
      model.label || '',
      model.family || '',
      previous ? previous.enabled : (model.enabled ? 1 : 0),
      model.available ? 1 : 0,
      model.description || '',
      model.contextWindow || 0,
      JSON.stringify(model.capabilities || []),
      previous ? (previous.remark || '') : '',
      now
    )
  }
}

function markMissingModelsUnavailable(models) {
  const ids = models.map(model => model.id)
  if (ids.length === 0) {
    return db.prepare('UPDATE models SET available = 0, updated_at = ?').run(Date.now()).changes
  }

  const placeholders = ids.map(() => '?').join(',')
  return db.prepare(
    `UPDATE models SET available = 0, updated_at = ? WHERE id NOT IN (${placeholders})`
  ).run(Date.now(), ...ids).changes
}
```

- [ ] **Step 5: Add Gateway sync export**

Add:

```js
export async function syncModelsFromGateway() {
  const rpcResult = await gatewayAdminRpc('models.list', {})
  if (!rpcResult.ok) {
    return { ok: false, error: rpcResult.error || 'models.list failed', count: 0, unavailable: 0 }
  }

  const models = normalizeModelList(rpcResult.payload)
  const tx = db.transaction(() => {
    upsertModels(models)
    const unavailable = markMissingModelsUnavailable(models)
    return unavailable
  })
  const unavailable = tx()

  console.log(`[Models] synced ${models.length} models, marked unavailable ${unavailable}`)
  return { ok: true, count: models.length, unavailable }
}
```

- [ ] **Step 6: Smoke test module import**

Run:

```bash
node -e "import('./server/model-manager.js').then(m => console.log(typeof m.listModelsFromDb, typeof m.syncModelsFromGateway))"
```

Expected output:

```text
function function
```

---

## Task 3: Add REST model routes

**Files:**
- Create: `server/handlers/models.js`

- [ ] **Step 1: Create route handler file**

Create `server/handlers/models.js`:

```js
import { authMiddleware, adminMiddleware } from '../core/auth.js'
import { listModelsFromDb, syncModelsFromGateway } from '../model-manager.js'

export function createModelRoutes(app) {
  app.get('/api/models', authMiddleware, (req, res) => {
    try {
      const includeUnavailable = req.currentUser.role === 'admin'
      const models = listModelsFromDb({ includeUnavailable })
      res.json({ ok: true, models })
    } catch (err) {
      console.error('[Models] list error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/models/sync', authMiddleware, adminMiddleware, async (req, res) => {
    try {
      const result = await syncModelsFromGateway()
      if (!result.ok) {
        return res.status(502).json({ ok: false, error: result.error })
      }
      res.json({ ok: true, count: result.count, unavailable: result.unavailable })
    } catch (err) {
      console.error('[Models] sync error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })
}
```

- [ ] **Step 2: Smoke test route module import**

Run:

```bash
node -e "import('./server/handlers/models.js').then(m => console.log(typeof m.createModelRoutes))"
```

Expected output:

```text
function
```

---

## Task 4: Wire backend routes and remove Gateway model cache/proxy path

**Files:**
- Modify: `server/index.js`
- Modify: `server/core/gateway-client.js`

- [ ] **Step 1: Update imports in `server/index.js`**

Change the gateway-client import from including model cache helpers to only needed Gateway helpers.

Remove these imported names:

```js
getModelsList,
invalidateModelsCache,
```

Add imports:

```js
import { createModelRoutes } from './handlers/models.js'
import { syncModelsFromGateway } from './model-manager.js'
```

- [ ] **Step 2: Register routes in `server/index.js`**

Near other route registrations, add:

```js
createModelRoutes(app)
```

- [ ] **Step 3: Replace Gateway connected model cache invalidation**

In the first `gateway.on('connected', ...)`, replace:

```js
invalidateModelsCache()
```

with:

```js
syncModelsFromGateway().catch(err => {
  console.error('[Models] sync on connect error:', err.message)
})
```

- [ ] **Step 4: Replace Gateway reconnect model cache invalidation**

In the reconnect `newGw.on('connected', ...)`, replace:

```js
invalidateModelsCache()
```

with:

```js
syncModelsFromGateway().catch(err => {
  console.error('[Models] sync on reconnect error:', err.message)
})
```

- [ ] **Step 5: Delete normal-user `models.list` RPC branch**

Remove this block from the non-admin branch:

```js
if (normMethod === 'models.list' || normMethod === 'models.get') {
  const r = await getModelsList()
  return res.json(r.ok ? { ok: true, payload: r.payload } : { ok: false, error: r.error })
}
```

- [ ] **Step 6: Delete admin `models.list` RPC branch**

Remove this block from the admin branch:

```js
if (normMethod === 'models.list' || normMethod === 'models.get') {
  const r = await getModelsList()
  return res.json(r.ok ? { ok: true, payload: r.payload } : { ok: false, error: r.error })
}
```

- [ ] **Step 7: Remove model cache helpers from `server/core/gateway-client.js`**

Delete:

```js
let _modelsCache = null
const _MODELS_CACHE_TTL = 10 * 60 * 1000

export async function getModelsList() {
  const now = Date.now()
  if (_modelsCache && (now - _modelsCache.ts) < _MODELS_CACHE_TTL) {
    return _modelsCache.result
  }
  const r = await gatewayAdminRpc('models.list', {})
  if (r.ok) {
    _modelsCache = { result: r, ts: now }
  }
  return r
}

export function invalidateModelsCache() {
  _modelsCache = null
}
```

- [ ] **Step 8: Verify backend imports**

Run:

```bash
node -e "import('./server/index.js').then(() => console.log('server import ok')).catch(e => { console.error(e.message); process.exit(1) })"
```

Expected result: either `server import ok` or normal server startup logs. There must be no error like:

```text
The requested module ... does not provide an export named 'getModelsList'
```

---

## Task 5: Convert `useModelStore` to REST and remove AgentStore model state

**Files:**
- Modify: `src/stores/model.ts`
- Modify: `src/stores/agent.ts`

- [ ] **Step 1: Replace `src/stores/model.ts` imports**

Remove:

```ts
import { useWebSocketStore } from './websocket'
```

Add:

```ts
import { useAuthStore } from './auth'
```

- [ ] **Step 2: Replace WebSocket-backed fetch in `src/stores/model.ts`**

Replace the body with this pattern:

```ts
export const useModelStore = defineStore('model', () => {
  const models = ref<ModelInfo[]>([])
  const loading = ref(false)
  const lastError = ref<string | null>(null)

  async function fetchModels() {
    loading.value = true
    lastError.value = null
    try {
      const authStore = useAuthStore()
      const token = authStore.getToken()
      const resp = await fetch('/api/models', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      const data = await resp.json()
      if (!resp.ok || !data.ok) {
        throw new Error(data.error || `HTTP ${resp.status}`)
      }
      models.value = Array.isArray(data.models) ? data.models : []
    } catch (error) {
      models.value = []
      lastError.value = error instanceof Error ? error.message : String(error)
      console.error('[ModelStore] fetchModels failed:', error)
    } finally {
      loading.value = false
    }
  }

  return {
    models,
    loading,
    lastError,
    fetchModels,
  }
})
```

- [ ] **Step 3: Remove model state from `src/stores/agent.ts`**

Delete the import type if it becomes unused:

```ts
ModelInfo,
```

Delete:

```ts
const models = ref<ModelInfo[]>([]);
```

Delete the whole function:

```ts
async function fetchModels() {
  try {
    models.value = await wsStore.rpc.listModels();
  } catch {
    models.value = [];
  }
}
```

Delete this call from `initialize()`:

```ts
await fetchModels();
```

Delete these return fields:

```ts
models,
fetchModels,
```

- [ ] **Step 4: Type-check these stores**

Run:

```bash
npx vue-tsc --noEmit
```

Expected at this stage: there may be errors from `AgentsPage.vue` still calling `agentStore.fetchModels`. That will be fixed in Task 6. There must be no errors inside `src/stores/model.ts` or `src/stores/agent.ts` about missing imports.

---

## Task 6: Update frontend call sites to the single model store

**Files:**
- Modify: `src/views/agents/AgentsPage.vue`
- Modify: `src/views/Dashboard.vue`

- [ ] **Step 1: Update `AgentsPage.vue` imports/setup**

Find the existing store setup in `src/views/agents/AgentsPage.vue`. Add:

```ts
import { useModelStore } from '@/stores/model'
```

Add near other store instances:

```ts
const modelStore = useModelStore()
```

- [ ] **Step 2: Replace `agentStore.fetchModels()` in `AgentsPage.vue`**

Replace:

```ts
await agentStore.fetchModels();
```

with:

```ts
await modelStore.fetchModels();
```

- [ ] **Step 3: Update `Dashboard.vue` model loading**

Find:

```ts
const modelsPromise = authStore.isAdmin ? wsStore.rpc.listModels() : Promise.resolve([])
```

Replace with:

```ts
const modelsPromise = fetch('/api/models', {
  headers: token ? { Authorization: `Bearer ${token}` } : {},
}).then(r => r.json()).then(d => d.models || [])
```

Keep the existing `Promise.allSettled` shape intact so later `modelsRes` handling does not need structural changes.

- [ ] **Step 4: Verify no direct frontend model RPC remains**

Run:

```bash
grep -rn "rpc\.listModels" src --include="*.ts" --include="*.vue"
```

Expected: no output.

- [ ] **Step 5: Type-check frontend**

Run:

```bash
npx vue-tsc --noEmit
```

Expected: PASS, or unrelated pre-existing errors only. Any new errors mentioning `fetchModels`, `models`, or `listModels` must be fixed before continuing.

---

## Task 7: Verify backend and end-to-end model read path

**Files:**
- Verify only; no planned code changes.

- [ ] **Step 1: Start backend or full app**

Run one of:

```bash
npm run dev:server
```

or:

```bash
npm run dev:all
```

Expected: backend starts without import/export errors.

- [ ] **Step 2: Trigger model sync as admin**

With an admin JWT token available, run:

```bash
curl -s -X POST http://localhost:3001/api/models/sync \
  -H "Authorization: Bearer $TOKEN" | jq
```

Expected shape:

```json
{
  "ok": true,
  "count": 1,
  "unavailable": 0
}
```

`count` may be greater than 1 depending on Gateway models.

- [ ] **Step 3: Verify local read endpoint**

Run:

```bash
curl -s http://localhost:3001/api/models \
  -H "Authorization: Bearer $TOKEN" | jq '.ok, (.models | length), .models[0]'
```

Expected:

```text
true
<number greater than or equal to 0>
{
  "id": "...",
  "provider": "..."
}
```

- [ ] **Step 4: Verify SQLite rows**

Run:

```bash
sqlite3 data/wizard.db "SELECT id, provider, enabled, available FROM models LIMIT 5;"
```

Expected: rows with model IDs and provider IDs.

- [ ] **Step 5: Verify workspace model load no longer hits WebSocket RPC**

Open online workspace and watch backend logs. Expected:

```text
GET /api/models
```

There should be no new Gateway log for:

```text
models.list
```

unless Gateway just connected or admin explicitly called `/api/models/sync`.

---

## Task 8: Final validation and cleanup

**Files:**
- Modify only if validation reveals missed references.

- [ ] **Step 1: Search removed backend symbols**

Run:

```bash
grep -rn "getModelsList\|invalidateModelsCache\|_modelsCache" server --include="*.js"
```

Expected: no output.

- [ ] **Step 2: Search frontend direct model RPC**

Run:

```bash
grep -rn "rpc\.listModels" src --include="*.ts" --include="*.vue"
```

Expected: no output.

- [ ] **Step 3: Search duplicate AgentStore model state**

Run:

```bash
grep -n "models\|fetchModels\|ModelInfo" src/stores/agent.ts
```

Expected: no output for model list state. `models` may appear only as part of unrelated words if any; inspect manually if it does.

- [ ] **Step 4: Run production build**

Run:

```bash
npm run build
```

Expected: build succeeds.

- [ ] **Step 5: Review changed files**

Run:

```bash
git diff -- server/database.js server/model-manager.js server/handlers/models.js server/index.js server/core/gateway-client.js src/stores/model.ts src/stores/agent.ts src/views/agents/AgentsPage.vue src/views/Dashboard.vue
```

Expected: diff matches this plan and does not modify unrelated infrastructure files.

---

## Self-Review

### Spec Coverage

- `models` table added: Task 1.
- `model_remarks` merged into `models.remark`: Task 1.
- `user_model_providers` preserved: no task changes it.
- Backend model repository created: Task 2.
- REST model routes created: Task 3.
- Gateway connect synchronization wired: Task 4.
- RPC model proxy removed: Task 4.
- Frontend model store converted to REST: Task 5.
- AgentStore duplicate model state removed: Task 5.
- Dashboard and AgentsPage direct calls fixed: Task 6.
- Verification of no direct `wsStore.rpc.listModels()`: Task 6 and Task 8.

### Placeholder Scan

No task uses TBD/TODO/fill-later language. Code snippets and commands are concrete.

### Type Consistency

- Backend uses `context_window` in DB and `contextWindow` in API.
- Frontend uses existing `ModelInfo` fields.
- Sync preserves `enabled` and `remark`; marks missing models with `available = 0`.
