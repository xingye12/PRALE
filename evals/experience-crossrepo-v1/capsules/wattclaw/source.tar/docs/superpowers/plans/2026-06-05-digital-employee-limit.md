# 数字员工创建数量上限 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 限制每个用户最多拥有 10 个数字员工，并在超过上限时显示友好弹窗。

**Architecture:** 后端以本地 SQLite `user_agents` 为唯一数量来源，提供创建前预检并在最终创建接口再次硬校验。前端创建编排先预检，再创建 Gateway Agent，再落库；两个创建入口统一识别限额错误并弹窗提示。

**Tech Stack:** Node.js/Express、better-sqlite3、Vue 3 `<script setup lang="ts">`、Pinia、Naive UI、vue-tsc。

---

## 架构师复核结论

设计文档已修正一个关键点：当前数字员工实际运行数据源不是旧 `agent_team`，而是 `/api/agent-team/*` 路由使用的 `user_agents` 表。数量限制必须按当前运行链路计算：

```sql
SELECT COUNT(*) FROM user_agents
WHERE user_id = ?
  AND status = 'active'
  AND category IS NOT NULL
```

删除逻辑是硬删除：

```sql
DELETE FROM user_agents WHERE user_id = ? AND gateway_agent_id = ?
```

所以删除后会释放名额。

## File Structure

- Modify: `server/handlers/agent-team.js`
  - 增加 `AGENT_TEAM_LIMIT`、`AGENT_TEAM_LIMIT_REACHED`。
  - 增加本地 count helper。
  - 新增 `/api/agent-team/create-limit` 预检接口。
  - 在 `/api/agent-team/create` 前置硬校验。
- Modify: `src/stores/agent-team.ts`
  - 保留后端错误 code。
  - 新增 `checkCreateLimit()`。
- Modify: `src/composables/useAgentCreation.ts`
  - 导出限额错误常量和识别 helper。
  - 在调用 `wsStore.rpc.createAgent()` 前执行 `store.checkCreateLimit()`。
- Modify: `src/views/agent-team/CreateAgentModal.vue`
  - 使用 Naive UI `useDialog()`。
  - 限额错误时展示友好弹窗。
- Modify: `src/views/agent-team/AgentAddDetailModal.vue`
  - 同上，覆盖模板创建入口。
- Verify only: `package.json`
  - 使用现有 `npm run build`。

---

### Task 1: Backend limit helper and preflight API

**Files:**
- Modify: `server/handlers/agent-team.js:14-123`

- [ ] **Step 1: Add constants and helper near imports**

Add after `import db from '../database.js'`:

```javascript
const AGENT_TEAM_LIMIT = 10
const AGENT_TEAM_LIMIT_REACHED = 'AGENT_TEAM_LIMIT_REACHED'

function getDigitalEmployeeCount(userId) {
  const row = db.prepare(`
    SELECT COUNT(*) AS count
    FROM user_agents
    WHERE user_id = ?
      AND status = 'active'
      AND category IS NOT NULL
  `).get(userId)
  return Number(row?.count || 0)
}

function sendAgentTeamLimitReached(res) {
  return res.status(409).json({
    ok: false,
    code: AGENT_TEAM_LIMIT_REACHED,
    error: '每个用户最多可以创建 10 个数字员工',
  })
}

function canCreateDigitalEmployee(userId) {
  return getDigitalEmployeeCount(userId) < AGENT_TEAM_LIMIT
}
```

- [ ] **Step 2: Add preflight route before `/api/agent-team/create`**

Insert before current `app.post('/api/agent-team/create'...)`:

```javascript
  app.get('/api/agent-team/create-limit', authMiddleware, (req, res) => {
    const count = getDigitalEmployeeCount(req.currentUser.id)
    res.json({
      ok: true,
      limit: AGENT_TEAM_LIMIT,
      count,
      remaining: Math.max(AGENT_TEAM_LIMIT - count, 0),
      canCreate: count < AGENT_TEAM_LIMIT,
    })
  })
```

- [ ] **Step 3: Add hard check at start of create route**

In `app.post('/api/agent-team/create'...)`, after validating `name`, `gatewayAgentId`, and `workspace`, but before `trackAgentForUser(...)`, add:

```javascript
    if (!canCreateDigitalEmployee(req.currentUser.id)) {
      return sendAgentTeamLimitReached(res)
    }
```

Expected create route shape:

```javascript
  app.post('/api/agent-team/create', authMiddleware, (req, res) => {
    const { name, description, avatar, model, category, templateId, gatewayAgentId, workspace } = req.body || {}
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ ok: false, error: 'Name is required' })
    }
    if (!gatewayAgentId) {
      return res.status(400).json({ ok: false, error: 'gatewayAgentId is required' })
    }
    const normalizedWorkspace = normalizeWorkspaceForCurrentUser(workspace, req.currentUser)
    if (!normalizedWorkspace) {
      return res.status(400).json({ ok: false, error: 'Invalid workspace' })
    }
    if (!canCreateDigitalEmployee(req.currentUser.id)) {
      return sendAgentTeamLimitReached(res)
    }
    trackAgentForUser(req.currentUser.id, gatewayAgentId, name, {
      category,
      templateId,
      description,
      avatar,
      model,
      workspace: normalizedWorkspace,
    })
    const agent = getDigitalEmployeeByAgentId(gatewayAgentId, req.currentUser.id)
    res.json({ ok: true, agent })
  })
```

- [ ] **Step 4: Manual backend smoke check**

Run:

```bash
npm run dev:server
```

Expected:

```text
server starts without syntax error
```

In another terminal or via browser devtools, authenticated GET `/api/agent-team/create-limit` should return:

```json
{
  "ok": true,
  "limit": 10,
  "count": 0,
  "remaining": 10,
  "canCreate": true
}
```

Exact `count` may differ based on current user data.

---

### Task 2: Preserve backend error codes in Pinia store

**Files:**
- Modify: `src/stores/agent-team.ts:11-26`

- [ ] **Step 1: Add typed API error class above store definition**

Add after imports:

```typescript
export class AgentTeamApiError extends Error {
  code?: string
  status: number

  constructor(message: string, status: number, code?: string) {
    super(message)
    this.name = 'AgentTeamApiError'
    this.status = status
    this.code = code
  }
}
```

- [ ] **Step 2: Update `apiCall` error parsing**

Replace:

```typescript
    const data = await res.json()
    if (!data.ok) throw new Error(data.error || 'Request failed')
    return data
```

with:

```typescript
    const data = await res.json()
    if (!data.ok) {
      const errorMessage = typeof data.error === 'string' ? data.error : 'Request failed'
      const errorCode = typeof data.code === 'string' ? data.code : undefined
      throw new AgentTeamApiError(errorMessage, res.status, errorCode)
    }
    return data
```

- [ ] **Step 3: Add create limit API method**

Add before `createAgent(...)`:

```typescript
  async function checkCreateLimit(): Promise<{
    limit: number
    count: number
    remaining: number
    canCreate: boolean
  }> {
    const data = await apiCall('/create-limit')
    return {
      limit: Number(data.limit || 0),
      count: Number(data.count || 0),
      remaining: Number(data.remaining || 0),
      canCreate: Boolean(data.canCreate),
    }
  }
```

- [ ] **Step 4: Export method from store return**

Update return block:

```typescript
  return {
    agentList,
    currentAgent,
    loading,
    fetchAgents,
    fetchAgent,
    checkCreateLimit,
    createAgent,
    updateAgent,
    deleteAgent,
    reset,
  }
```

- [ ] **Step 5: Type check this file through project build**

Run later in final verification:

```bash
npm run build
```

Expected: `vue-tsc -b` passes.

---

### Task 3: Preflight before Gateway creation

**Files:**
- Modify: `src/composables/useAgentCreation.ts:1-215`

- [ ] **Step 1: Import API error type**

Change:

```typescript
import { useAgentTeamStore } from '@/stores/agent-team'
```

to:

```typescript
import { AgentTeamApiError, useAgentTeamStore } from '@/stores/agent-team'
```

- [ ] **Step 2: Add exported constants and helper after interfaces**

Add after `CreateAgentResult`:

```typescript
export const AGENT_TEAM_LIMIT_REACHED = 'AGENT_TEAM_LIMIT_REACHED'

export function isAgentTeamLimitError(error: unknown): boolean {
  return error instanceof AgentTeamApiError && error.code === AGENT_TEAM_LIMIT_REACHED
}
```

- [ ] **Step 3: Call preflight before config/Gateway RPC**

In `createAgent(...)`, after workspace path is built and before `report(20, '创建中...')`, add:

```typescript
    await store.checkCreateLimit()
```

Expected order:

```typescript
    const workspacePath = buildWorkspacePath({
      userDisplayName: displayName,
      userName,
      agentName: params.name,
    })

    await store.checkCreateLimit()

    report(20, '创建中...')
```

This ensures limit failure happens before `wsStore.rpc.getConfig()` and `wsStore.rpc.createAgent(...)`.

- [ ] **Step 4: Keep final hard check behavior**

Do not remove existing rollback block:

```typescript
    } catch (dbErr) {
      try {
        await wsStore.rpc.deleteAgent(gatewayAgentId)
      } catch {
        // best-effort rollback
      }
      throw dbErr
    }
```

If another tab reaches the limit between preflight and final DB create, backend returns `AGENT_TEAM_LIMIT_REACHED`, and this rollback deletes the just-created Gateway Agent.

---

### Task 4: Friendly dialog in custom create modal

**Files:**
- Modify: `src/views/agent-team/CreateAgentModal.vue:1-132`

- [ ] **Step 1: Import `useDialog` and limit helper**

Change Naive UI import:

```typescript
import { NButton, NInput, NModal, NCollapse, NCollapseItem, useMessage } from 'naive-ui'
```

to:

```typescript
import { NButton, NInput, NModal, NCollapse, NCollapseItem, useDialog, useMessage } from 'naive-ui'
```

Change composable import:

```typescript
import { useAgentCreation, resolveDefaultModel } from '@/composables/useAgentCreation'
```

to:

```typescript
import { isAgentTeamLimitError, useAgentCreation, resolveDefaultModel } from '@/composables/useAgentCreation'
```

- [ ] **Step 2: Initialize dialog**

After:

```typescript
const message = useMessage()
```

add:

```typescript
const dialog = useDialog()
```

- [ ] **Step 3: Add friendly dialog helper**

Add before `handleCreate()`:

```typescript
function showLimitReachedDialog() {
  dialog.warning({
    title: '数字员工数量已达上限',
    content: '你已经拥有 10 个数字员工啦。可以先删除一个暂时不需要的数字员工，再创建新的成员。',
    positiveText: '我知道了',
  })
}
```

- [ ] **Step 4: Update catch block**

Replace current catch body:

```typescript
  } catch (err: any) {
    stopSimulatedProgress()
    isCreating.value = false
    progress.value = 0
    message.error(err.message || t('pages.agentTeam.messages.createFailed') || '创建失败')
  }
```

with:

```typescript
  } catch (err: unknown) {
    stopSimulatedProgress()
    isCreating.value = false
    progress.value = 0
    if (isAgentTeamLimitError(err)) {
      showLimitReachedDialog()
      return
    }
    const messageText = err instanceof Error
      ? err.message
      : t('pages.agentTeam.messages.createFailed') || '创建失败'
    message.error(messageText)
  }
```

---

### Task 5: Friendly dialog in template add modal

**Files:**
- Modify: `src/views/agent-team/AgentAddDetailModal.vue:1-86`

- [ ] **Step 1: Import `useDialog` and limit helper**

Change Naive UI import:

```typescript
import { NButton, NModal, useMessage } from 'naive-ui'
```

to:

```typescript
import { NButton, NModal, useDialog, useMessage } from 'naive-ui'
```

Change composable import:

```typescript
import { useAgentCreation } from '@/composables/useAgentCreation'
```

to:

```typescript
import { isAgentTeamLimitError, useAgentCreation } from '@/composables/useAgentCreation'
```

- [ ] **Step 2: Initialize dialog**

After:

```typescript
const message = useMessage()
```

add:

```typescript
const dialog = useDialog()
```

- [ ] **Step 3: Add friendly dialog helper**

Add before `handleAdd()`:

```typescript
function showLimitReachedDialog() {
  dialog.warning({
    title: '数字员工数量已达上限',
    content: '你已经拥有 10 个数字员工啦。可以先删除一个暂时不需要的数字员工，再创建新的成员。',
    positiveText: '我知道了',
  })
}
```

- [ ] **Step 4: Update catch block**

Replace:

```typescript
  } catch (err: any) {
    stopSimulatedProgress()
    isAdding.value = false
    progress.value = 0
    message.error(err.message || t('pages.agentTeam.messages.createFailed') || '创建失败')
  }
```

with:

```typescript
  } catch (err: unknown) {
    stopSimulatedProgress()
    isAdding.value = false
    progress.value = 0
    if (isAgentTeamLimitError(err)) {
      showLimitReachedDialog()
      return
    }
    const messageText = err instanceof Error
      ? err.message
      : t('pages.agentTeam.messages.createFailed') || '创建失败'
    message.error(messageText)
  }
```

---

### Task 6: Verification

**Files:**
- Verify: `server/handlers/agent-team.js`
- Verify: `src/stores/agent-team.ts`
- Verify: `src/composables/useAgentCreation.ts`
- Verify: `src/views/agent-team/CreateAgentModal.vue`
- Verify: `src/views/agent-team/AgentAddDetailModal.vue`

- [ ] **Step 1: Run build**

Run:

```bash
npm run build
```

Expected:

```text
vue-tsc -b passes
vite build completes
```

- [ ] **Step 2: Manual verify preflight response**

With backend running and an authenticated user, call:

```bash
curl -H "Authorization: Bearer <token>" http://localhost:3001/api/agent-team/create-limit
```

Expected when below limit:

```json
{"ok":true,"limit":10,"count":9,"remaining":1,"canCreate":true}
```

Expected at limit:

```json
{"ok":true,"limit":10,"count":10,"remaining":0,"canCreate":false}
```

- [ ] **Step 3: Manual verify backend hard limit**

At 10 active digital employees for the same user, POST `/api/agent-team/create` with valid payload.

Expected:

```json
{"ok":false,"code":"AGENT_TEAM_LIMIT_REACHED","error":"每个用户最多可以创建 10 个数字员工"}
```

HTTP status must be `409`.

- [ ] **Step 4: Manual verify UI custom create**

Open custom create modal when user already has 10 digital employees.

Expected:

- Progress stops.
- Modal remains open.
- A dialog appears with title `数字员工数量已达上限`.
- Dialog content says `你已经拥有 10 个数字员工啦。可以先删除一个暂时不需要的数字员工，再创建新的成员。`

- [ ] **Step 5: Manual verify UI template create**

Open template add modal when user already has 10 digital employees.

Expected same dialog behavior as custom create.

- [ ] **Step 6: Manual verify deletion frees capacity**

Delete one digital employee, then create again.

Expected:

- `create-limit` returns `count: 9`, `remaining: 1`, `canCreate: true`.
- Creation succeeds.

---

## Self-Review

- Spec coverage: covered hard backend limit, preflight before Gateway, both UI entry points, delete frees capacity, admin/user same rule.
- Placeholder scan: no `TBD`, no `TODO`, no undefined future steps.
- Type consistency: `AgentTeamApiError.code`, `AGENT_TEAM_LIMIT_REACHED`, and `isAgentTeamLimitError()` are consistently referenced.
- Scope check: no schema change, no Gateway protocol change, no delete logic change.
