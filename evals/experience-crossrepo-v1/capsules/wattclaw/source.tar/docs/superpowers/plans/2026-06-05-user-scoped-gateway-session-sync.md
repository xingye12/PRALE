# User-Scoped Gateway Session Sync Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Feishu/OpenClaw-created sessions appear in WattClaw by reconciling Gateway sessions per user-owned agent without blocking `/api/sessions` or pulling message history.

**Architecture:** `/api/sessions` remains a local SQLite read and schedules a background user-scoped sync after responding. A new `server/core/session-sync.js` module performs bounded `sessions.list({ agentId, limit: 50 })` calls and upserts only session metadata. V1 deliberately does not add SSE or frontend auto-refresh; users see newly synced sessions after refreshing the online conversation/session list again.

**Tech Stack:** Node.js ESM, Express 5, better-sqlite3, Vitest, Vue 3, Pinia, TypeScript.

---

## File Structure

- Create: `server/core/session-sync.js`
  - User-scoped sync scheduler, singleflight, cooldown, timeout, Gateway session normalization, per-agent calls, metadata upsert orchestration.
- Create: `server/core/session-sync.test.js`
  - Unit tests for bounded agent-scoped Gateway calls, ownership filtering, cooldown/singleflight, no global list calls, and recently-deleted filtering.
- Modify: `server/user-manager.js`
  - Add `upsertSyncedUserSession()` for metadata-only session upsert while preserving custom labels. The current schema has no `peer` column, so `peer` is accepted but not persisted in V1.
- Modify: `server/handlers/sessions.js`
  - Schedule background user sync after returning local `/api/sessions` data.
- Modify: `server/index.js`
  - Pass Gateway RPC dependency into `registerSessionRoutes()`.
- Verify only: `src/api/http-client.ts`, `src/stores/session.ts`, `src/stores/workspace.ts`
  - No V1 changes. Existing reload behavior is enough; users refresh once more to see newly synced sessions.
- Verify only: `docs/superpowers/specs/2026-06-05-user-scoped-gateway-session-sync-design.md`
  - Design source. Implementation intentionally defers SSE auto-refresh to reduce complexity.

---

### Task 1: Add Metadata Upsert Helper

**Files:**
- Modify: `server/user-manager.js`
- Test: covered in `server/core/session-sync.test.js` in Task 2

- [ ] **Step 1: Add timestamp parser near existing session helpers**

Add this helper before `trackSessionForUser()`:

```js
function normalizeSessionUpdatedAt(value, fallback = Date.now()) {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
    return value > 1e12 ? Math.floor(value) : Math.floor(value * 1000)
  }
  if (typeof value === 'string' && value.trim()) {
    const numeric = Number(value)
    if (Number.isFinite(numeric) && numeric > 0) {
      return numeric > 1e12 ? Math.floor(numeric) : Math.floor(numeric * 1000)
    }
    const parsed = Date.parse(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return fallback
}
```

- [ ] **Step 2: Add metadata-only upsert export**

Add this after `trackSessionForUser()`:

```js
export function upsertSyncedUserSession({ userId, sessionKey, agentId, channel, peer, label, lastActivity }) {
  void peer
  if (!userId || !sessionKey) return { changed: false, action: 'skipped' }

  const now = Date.now()
  const updatedAt = normalizeSessionUpdatedAt(lastActivity, now)
  const existing = db.prepare(`
    SELECT id, agent_id, channel, label, updated_at
    FROM user_sessions
    WHERE user_id = ? AND session_key = ?
  `).get(userId, sessionKey)

  if (!existing) {
    db.prepare(`
      INSERT INTO user_sessions (id, user_id, session_key, agent_id, label, channel, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      randomUUID(),
      userId,
      sessionKey,
      agentId || null,
      label || null,
      channel || null,
      updatedAt
    )
    return { changed: true, action: 'inserted' }
  }

  const nextAgentId = agentId || existing.agent_id || null
  const nextChannel = channel || existing.channel || null
  const nextLabel = existing.label || label || null
  const nextUpdatedAt = Math.max(Number(existing.updated_at) || 0, updatedAt)

  const changed =
    nextAgentId !== (existing.agent_id || null) ||
    nextChannel !== (existing.channel || null) ||
    nextLabel !== (existing.label || null) ||
    nextUpdatedAt !== (Number(existing.updated_at) || 0)

  if (!changed) return { changed: false, action: 'unchanged' }

  db.prepare(`
    UPDATE user_sessions
    SET updated_at = ?, agent_id = ?, channel = ?, label = ?
    WHERE id = ?
  `).run(nextUpdatedAt, nextAgentId, nextChannel, nextLabel, existing.id)

  return { changed: true, action: 'updated' }
}
```

- [ ] **Step 3: Run syntax check**

Run: `node --check server/user-manager.js`

Expected: no output and exit code 0.

---

### Task 2: Build Session Sync Core With Tests

**Files:**
- Create: `server/core/session-sync.js`
- Create: `server/core/session-sync.test.js`
- Modify: `server/user-manager.js` from Task 1 is used by this module

- [ ] **Step 1: Write failing tests**

Create `server/core/session-sync.test.js`:

```js
import { describe, expect, it, vi, beforeEach } from 'vitest'

vi.mock('../user-manager.js', () => ({
  getAllGatewayAgentIds: vi.fn(),
  getUserOwnedAgentIds: vi.fn(),
  upsertSyncedUserSession: vi.fn(),
}))

vi.mock('../handlers/sessions.js', () => ({
  recentlyDeletedSessions: new Set(),
}))

const userManager = await import('../user-manager.js')
const sessionsHandler = await import('../handlers/sessions.js')
const syncModule = await import('./session-sync.js')

const {
  DEFAULT_SESSION_SYNC_OPTIONS,
  normalizeGatewaySessionForSync,
  syncUserSessionsFromGateway,
  scheduleUserSessionSync,
  resetSessionSyncStateForTests,
} = syncModule

describe('session-sync', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    sessionsHandler.recentlyDeletedSessions.clear()
    resetSessionSyncStateForTests()
  })

  it('normalizes stable and legacy Gateway session fields', () => {
    const item = {
      sessionKey: 'agent:agent-a:feishu-peer-1',
      agentId: 'agent-a',
      channel: 'feishu',
      peer: 'ou_xxx',
      label: 'Feishu chat',
      lastActivity: '2026-06-05T12:00:00.000Z',
    }

    expect(normalizeGatewaySessionForSync(item, 'fallback')).toEqual({
      sessionKey: 'agent:agent-a:feishu-peer-1',
      agentId: 'agent-a',
      channel: 'feishu',
      peer: 'ou_xxx',
      label: 'Feishu chat',
      lastActivity: '2026-06-05T12:00:00.000Z',
    })
  })

  it('queries only user-owned agents with explicit agentId and bounded limit', async () => {
    userManager.getUserOwnedAgentIds.mockReturnValue(['agent-a', 'agent-b'])
    userManager.upsertSyncedUserSession.mockReturnValue({ changed: true, action: 'inserted' })
    const gatewayRpc = vi.fn(async (_method, params) => ({
      ok: true,
      payload: { sessions: [{ key: `agent:${params.agentId}:s1`, agentId: params.agentId }] },
    }))

    const result = await syncUserSessionsFromGateway({
      userId: 'user-1',
      role: 'user',
      gatewayRpc,
    })

    expect(result.changed).toBe(2)
    expect(gatewayRpc).toHaveBeenCalledTimes(2)
    expect(gatewayRpc).toHaveBeenNthCalledWith(1, 'sessions.list', { agentId: 'agent-a', limit: DEFAULT_SESSION_SYNC_OPTIONS.perAgentLimit })
    expect(gatewayRpc).toHaveBeenNthCalledWith(2, 'sessions.list', { agentId: 'agent-b', limit: DEFAULT_SESSION_SYNC_OPTIONS.perAgentLimit })
    expect(gatewayRpc).not.toHaveBeenCalledWith('sessions.list', {})
  })

  it('drops sessions for agents outside the user ownership set', async () => {
    userManager.getUserOwnedAgentIds.mockReturnValue(['agent-a'])
    const gatewayRpc = vi.fn(async () => ({
      ok: true,
      payload: { sessions: [{ key: 'agent:agent-b:s1', agentId: 'agent-b' }] },
    }))

    const result = await syncUserSessionsFromGateway({
      userId: 'user-1',
      role: 'user',
      gatewayRpc,
    })

    expect(result.changed).toBe(0)
    expect(userManager.upsertSyncedUserSession).not.toHaveBeenCalled()
  })

  it('does not reinsert recently deleted sessions', async () => {
    userManager.getUserOwnedAgentIds.mockReturnValue(['agent-a'])
    sessionsHandler.recentlyDeletedSessions.add('agent:agent-a:deleted')
    const gatewayRpc = vi.fn(async () => ({
      ok: true,
      payload: { sessions: [{ key: 'agent:agent-a:deleted', agentId: 'agent-a' }] },
    }))

    const result = await syncUserSessionsFromGateway({
      userId: 'user-1',
      role: 'user',
      gatewayRpc,
    })

    expect(result.changed).toBe(0)
    expect(userManager.upsertSyncedUserSession).not.toHaveBeenCalled()
  })

  it('coalesces scheduled syncs for the same user', async () => {
    userManager.getUserOwnedAgentIds.mockReturnValue(['agent-a'])
    userManager.upsertSyncedUserSession.mockReturnValue({ changed: true, action: 'inserted' })
    let calls = 0
    const gatewayRpc = vi.fn(async () => {
      calls += 1
      await new Promise(resolve => setTimeout(resolve, 10))
      return { ok: true, payload: { sessions: [{ key: 'agent:agent-a:s1', agentId: 'agent-a' }] } }
    })

    await Promise.all([
      scheduleUserSessionSync({ userId: 'user-1', role: 'user', gatewayRpc, cooldownMs: 0 }),
      scheduleUserSessionSync({ userId: 'user-1', role: 'user', gatewayRpc, cooldownMs: 0 }),
    ])

    expect(calls).toBe(1)
  })

  it('does not emit refresh events in V1', async () => {
    userManager.getUserOwnedAgentIds.mockReturnValue(['agent-a'])
    userManager.upsertSyncedUserSession.mockReturnValue({ changed: true, action: 'inserted' })
    const onChanged = vi.fn()
    const gatewayRpc = vi.fn(async () => ({
      ok: true,
      payload: { sessions: [{ key: 'agent:agent-a:s1', agentId: 'agent-a' }] },
    }))

    await scheduleUserSessionSync({ userId: 'user-1', role: 'user', gatewayRpc, onChanged, cooldownMs: 0 })

    expect(onChanged).not.toHaveBeenCalled()
  })
})
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `npx vitest run server/core/session-sync.test.js`

Expected: FAIL because `server/core/session-sync.js` does not exist or exports are missing.

- [ ] **Step 3: Implement session sync module**

Create `server/core/session-sync.js`:

```js
import {
  getAllGatewayAgentIds,
  getUserOwnedAgentIds,
  upsertSyncedUserSession,
} from '../user-manager.js'
import { recentlyDeletedSessions } from '../handlers/sessions.js'

export const DEFAULT_SESSION_SYNC_OPTIONS = Object.freeze({
  perAgentLimit: 50,
  cooldownMs: 60_000,
  overallTimeoutMs: 8_000,
  gatewayConcurrency: 2,
})

const inFlightByUserId = new Map()
const lastSyncAtByUserId = new Map()

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null
}

function extractSessions(payload) {
  if (Array.isArray(payload)) return payload
  const row = asRecord(payload)
  if (!row) return []
  if (Array.isArray(row.sessions)) return row.sessions
  if (Array.isArray(row.items)) return row.items
  if (Array.isArray(row.list)) return row.list
  if (Array.isArray(row.data)) return row.data
  const data = asRecord(row.data)
  if (Array.isArray(data?.sessions)) return data.sessions
  if (Array.isArray(data?.items)) return data.items
  return []
}

function readString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim()
  }
  return ''
}

function extractAgentIdFromSessionKey(sessionKey) {
  return sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
}

export function normalizeGatewaySessionForSync(value, fallbackAgentId = '') {
  const row = asRecord(value)
  if (!row) return null

  const sessionKey = readString(row.key, row.sessionKey, row.session_key, row.id)
  if (!sessionKey) return null

  const agentId = readString(row.agentId, row.agent_id, row.agent, extractAgentIdFromSessionKey(sessionKey), fallbackAgentId)
  if (!agentId) return null

  return {
    sessionKey,
    agentId,
    channel: readString(row.channel, row.channelKey, row.channel_key),
    peer: readString(row.peer, row.peerId, row.peer_id, row.userId, row.user_id),
    label: readString(row.label, row.title, row.name),
    lastActivity: row.lastActivity ?? row.last_activity ?? row.updatedAt ?? row.updated_at ?? row.timestamp ?? null,
  }
}

async function mapWithConcurrency(items, limit, mapper) {
  const results = []
  let nextIndex = 0
  const workerCount = Math.min(Math.max(1, limit), items.length)

  async function worker() {
    while (nextIndex < items.length) {
      const index = nextIndex
      nextIndex += 1
      results[index] = await mapper(items[index], index)
    }
  }

  await Promise.all(Array.from({ length: workerCount }, () => worker()))
  return results
}

function withTimeout(promise, timeoutMs) {
  let timer
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`session sync timeout after ${timeoutMs}ms`)), timeoutMs)
  })
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer))
}

function getAgentIdsForUser(userId, role) {
  const ids = role === 'admin' ? getAllGatewayAgentIds() : getUserOwnedAgentIds(userId)
  return [...new Set(ids.filter(id => typeof id === 'string' && id.trim()).map(id => id.trim()))]
}

async function listGatewaySessionsForAgent({ agentId, gatewayRpc, perAgentLimit }) {
  const result = await gatewayRpc('sessions.list', { agentId, limit: perAgentLimit })
  if (!result?.ok) {
    const message = result?.error?.message || result?.error || `sessions.list failed for ${agentId}`
    throw new Error(message)
  }
  return extractSessions(result.payload)
}

export async function syncUserSessionsFromGateway({
  userId,
  role,
  gatewayRpc,
  perAgentLimit = DEFAULT_SESSION_SYNC_OPTIONS.perAgentLimit,
  overallTimeoutMs = DEFAULT_SESSION_SYNC_OPTIONS.overallTimeoutMs,
  gatewayConcurrency = DEFAULT_SESSION_SYNC_OPTIONS.gatewayConcurrency,
}) {
  if (!userId || typeof gatewayRpc !== 'function') {
    return { changed: 0, scanned: 0, agents: 0 }
  }

  const run = async () => {
    const agentIds = getAgentIdsForUser(userId, role)
    if (agentIds.length === 0) return { changed: 0, scanned: 0, agents: 0 }

    const allowedAgentIds = new Set(agentIds)
    let changed = 0
    let scanned = 0

    await mapWithConcurrency(agentIds, gatewayConcurrency, async (agentId) => {
      let rawSessions = []
      try {
        rawSessions = await listGatewaySessionsForAgent({ agentId, gatewayRpc, perAgentLimit })
      } catch (err) {
        console.warn(`[SessionSync] agent ${agentId} skipped: ${err.message}`)
        return
      }

      for (const raw of rawSessions) {
        scanned += 1
        const session = normalizeGatewaySessionForSync(raw, agentId)
        if (!session) continue
        if (!allowedAgentIds.has(session.agentId)) continue
        if (recentlyDeletedSessions.has(session.sessionKey)) continue

        const result = upsertSyncedUserSession({ userId, ...session })
        if (result.changed) changed += 1
      }
    })

    return { changed, scanned, agents: agentIds.length }
  }

  return withTimeout(run(), overallTimeoutMs)
}

export function scheduleUserSessionSync({
  userId,
  role,
  gatewayRpc,
  cooldownMs = DEFAULT_SESSION_SYNC_OPTIONS.cooldownMs,
  ...options
}) {
  if (!userId) return Promise.resolve({ changed: 0, skipped: true })

  const now = Date.now()
  const lastSyncAt = lastSyncAtByUserId.get(userId) || 0
  if (now - lastSyncAt < cooldownMs) {
    return Promise.resolve({ changed: 0, skipped: true, reason: 'cooldown' })
  }

  const existing = inFlightByUserId.get(userId)
  if (existing) return existing

  const promise = syncUserSessionsFromGateway({ userId, role, gatewayRpc, ...options })
    .then((result) => {
      lastSyncAtByUserId.set(userId, Date.now())
      return result
    })
    .catch((err) => {
      console.error(`[SessionSync] user ${userId} failed: ${err.message}`)
      return { changed: 0, error: err.message }
    })
    .finally(() => {
      inFlightByUserId.delete(userId)
    })

  inFlightByUserId.set(userId, promise)
  return promise
}

export function resetSessionSyncStateForTests() {
  inFlightByUserId.clear()
  lastSyncAtByUserId.clear()
}
```

- [ ] **Step 4: Run session sync tests**

Run: `npx vitest run server/core/session-sync.test.js`

Expected: PASS.

- [ ] **Step 5: Run syntax checks**

Run:

```bash
node --check server/core/session-sync.js
node --check server/user-manager.js
```

Expected: both pass with no output.

---

### Task 3: Wire Backend Session Route Scheduling

**Files:**
- Modify: `server/handlers/sessions.js`
- Modify: `server/index.js`
- Test: `server/core/session-sync.test.js` remains green

- [ ] **Step 1: Modify sessions route registration signature**

In `server/handlers/sessions.js`, import the scheduler:

```js
import { scheduleUserSessionSync } from '../core/session-sync.js'
```

Change the exported function signature from:

```js
export function registerSessionRoutes({ app, authMiddleware, gateway, getLocalSessionTitles, getAllSessionTitles }) {
```

to:

```js
export function registerSessionRoutes({
  app,
  authMiddleware,
  gateway,
  getLocalSessionTitles,
  getAllSessionTitles,
  gatewayRpc,
}) {
```

- [ ] **Step 2: Schedule sync after local response**

Inside `app.get('/api/sessions', ...)`, after `res.json(...)` is sent, schedule the background sync. Replace the current `return res.json(...)` with:

```js
      res.json({
        ok: true,
        payload: {
          sessions,
          total: sessions.length,
          page: 1,
          limit: sessions.length,
          hasMore: false,
        }
      })

      if (typeof gatewayRpc === 'function') {
        setImmediate(() => {
          void scheduleUserSessionSync({
            userId,
            role: req.currentUser.role,
            gatewayRpc,
          })
        })
      }
      return
```

- [ ] **Step 3: Wire dependencies from server index**

Find the `registerSessionRoutes(...)` call in `server/index.js` and add:

```js
  gatewayRpc: gatewayAdminRpc,
```

The resulting call should include the existing fields plus `gatewayRpc` only. Do not add SSE dependencies.

- [ ] **Step 4: Run backend syntax checks**

Run:

```bash
node --check server/handlers/sessions.js
node --check server/index.js
node --check server/core/session-sync.js
```

Expected: all pass with no output.

- [ ] **Step 5: Re-run unit tests**

Run: `npx vitest run server/core/session-sync.test.js server/handlers/cron.test.js`

Expected: PASS.

---

### Task 4: Confirm Frontend Stays Unchanged

**Files:**
- Verify only: `src/api/http-client.ts`
- Verify only: `src/stores/session.ts`
- Verify only: `src/stores/workspace.ts`

- [ ] **Step 1: Confirm no SSE refresh code is added**

Run:

```bash
git diff -- src/api/http-client.ts src/stores/session.ts src/stores/workspace.ts
```

Expected: no diff from this feature.

- [ ] **Step 2: Confirm existing refresh path still works**

Existing `src/stores/session.ts` already calls `/api/sessions` through `fetchSessions()`. Do not add a dedicated sync API and do not add a frontend-triggered sync button.

Expected user flow:

```text
first open online conversation -> backend schedules sync -> user refreshes -> local DB list includes synced session
```

---

### Task 5: Integration Verification

**Files:**
- No new files unless a small verification note is useful.
- Verify changed files from Tasks 1-5.

- [ ] **Step 1: Run focused automated tests**

Run:

```bash
npx vitest run server/core/session-sync.test.js server/handlers/cron.test.js
```

Expected: PASS.

- [ ] **Step 2: Run TypeScript/build verification**

Run:

```bash
npx vue-tsc --noEmit
```

Expected: PASS.

If this repo requires production build verification for the final gate, run:

```bash
npm run build
```

Expected: PASS.

- [ ] **Step 3: Verify no forbidden Gateway-wide session sync call was added**

Run:

```bash
rg -n "sessions\.list', \{\}|sessions\.list\", \{\}|sessions\.list\(\{\}\)|session\.list', \{\}" server src
```

Expected: no new active code path for `sessions.list({})`. Existing backup files may match; do not modify backup files unless explicitly requested.

- [ ] **Step 4: Verify no SSE or frontend auto-refresh was added**

Run:

```bash
rg -n "sessions\.updated|broadcastSSEToUser|event:sessions\.updated" server src
```

Expected: no matches from this feature.

- [ ] **Step 5: Manual runtime check with Feishu session**

Start app:

```bash
npm run dev:all
```

Expected: frontend and backend start.

Manual flow:

1. Log in as the user who owns the Feishu-bound digital employee.
2. Open online conversation.
3. Confirm `/api/sessions` returns before any Gateway sync completes.
4. Confirm backend logs show `sessions.list` with explicit `agentId` only.
5. Send or receive a Feishu message for that agent.
6. Refresh online conversation/session list once more.
7. Confirm the Feishu session appears in the WattClaw list.
8. Open that session.
9. Confirm message content appears via existing `/api/chat/history` backfill.

- [ ] **Step 6: Check git diff scope**

Run:

```bash
git diff --stat
git diff -- server/core/session-sync.js server/core/session-sync.test.js server/user-manager.js server/handlers/sessions.js server/index.js
```

Expected: changes are limited to backend session metadata sync.

---

## Self-Review Notes

Spec coverage:

- User-scoped sync: Task 2 and Task 4.
- No global `sessions.list({})`: Task 2 tests and Task 6 grep check.
- Metadata only: Task 1/2 upsert session rows only; no history calls in session-sync module.
- Lazy messages: untouched existing `/api/chat/history`; verified in Task 6 manual flow.
- Singleflight/cooldown/limits/timeouts: Task 2 constants and tests.
- Frontend does not initiate sync: Task 4 verifies no frontend sync endpoint/button/listener.
- No SSE V1: Task 4 and Task 5 verify no SSE refresh code.

No placeholders remain. Constants are fixed for first implementation: limit 50, cooldown 60s, timeout 8s, concurrency 2. V1 accepts one manual refresh after background sync to keep architecture simple and reduce regression risk.
