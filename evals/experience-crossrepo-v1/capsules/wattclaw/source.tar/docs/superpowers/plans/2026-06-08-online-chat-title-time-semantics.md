# Online Chat Title and Time Semantics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rebuild online chat title and time semantics so display titles, peer IDs, message occurrence time, and session last-message time are separate, stable domain fields.

**Architecture:** Add backend domain services for session titles, session activity, and message normalization. Add SQLite semantic fields (`peer_id`, `display_title`, `last_message_at`) and make `/api/sessions` a pure read path. Frontend renders normalized API fields and stops deriving titles or list times from session keys / `Date.now()`.

**Tech Stack:** Node.js ESM, Express, better-sqlite3, PostgreSQL message store, Vue 3, Pinia, TypeScript, vue-tsc.

---

## Scope Check

This plan covers one subsystem: **online chat session identity and time semantics**. It touches backend session metadata, backend message normalization, and frontend rendering. These changes are coupled by one invariant: the backend local store is the source of truth for `display_title` and `last_message_at`.

## File Structure

### Create

- `server/services/session-title-service.js`
  - Single owner of user-visible session title generation.
  - Guarantees internal peer IDs are never returned as display titles.

- `server/services/session-activity-service.js`
  - Single owner of `last_message_at` writes.
  - Exposes `advanceSessionLastMessageAt(sessionKey, occurredAt)`.

- `server/services/message-normalizer.js`
  - Normalizes raw Gateway/external messages before message-store writes.
  - Exposes `normalizeMessageEnvelope()` and `extractOccurredAt()`.

### Modify

- `server/database.js`
  - Add idempotent SQLite columns and indexes: `peer_id`, `display_title`, `last_message_at`.

- `server/user-manager.js`
  - Split ownership tracking from activity updates.
  - Stop updating session list time during ownership sync.

- `server/handlers/sessions.js`
  - Make `/api/sessions` pure read.
  - Return `displayTitle` and `lastMessageAt`, while retaining `label` and `lastActivity` compatibility.

- `server/handlers/chat.js`
  - Return timestamps from persisted message time.
  - Backfill Gateway messages using normalized occurredAt.

- `server/message-store.js`
  - Reuse normalizer for timestamp extraction.

- `server/core/message-sync.js`
  - Normalize external `session.message` events before PG write.
  - Advance session activity only through `SessionActivityService`.
  - Stop `sessions.changed` from using `Date.now()` as last activity.

- `server/core/session-sync.js`
  - Normalize Gateway session sync into metadata only unless a real timestamp exists.

- `server/index.js`
  - Replace auto-title inline rules with `SessionTitleService`.

- `src/api/types/session.ts`
  - Add `peerId`, `displayTitle`, `lastMessageAt` optional compatibility fields.

- `src/stores/workspace-message-utils.ts`
  - Parse timestamp consistently, preserve assistant timestamp on merge.

- `src/stores/workspace.ts`
  - Restrict `activityTimestamps` to real message event timestamps.

- `src/views/workspace/WorkspaceSidebar.vue`
  - Render backend display title only.
  - Sort by backend last-message time or real event occurredAt.

- `src/views/workspace/MessageList.vue`
  - Keep `HH:mm`, shared for user and assistant.

---

## Task 1: Add SQLite Semantic Fields

**Files:**
- Modify: `server/database.js`

- [ ] **Step 1: Add idempotent migration helper near existing ALTER blocks**

Insert after the existing `tasks.execution_history` ALTER block around `server/database.js:103-109`:

```js
function addColumnIfMissing(table, column, definition) {
  try {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`)
  } catch (e) {
    if (!e.message.includes('duplicate column name')) {
      console.error(`[Database] Failed to add ${table}.${column}:`, e.message)
    }
  }
}
```

- [ ] **Step 2: Add semantic columns after `user_sessions` table creation block**

Insert after the `db.exec` block that creates `user_sessions` and indexes, after `server/database.js:331` or immediately after that schema section ends:

```js
addColumnIfMissing('user_sessions', 'peer_id', 'TEXT')
addColumnIfMissing('user_sessions', 'display_title', 'TEXT')
addColumnIfMissing('user_sessions', 'last_message_at', 'INTEGER')

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_user_sessions_last_message_at ON user_sessions(last_message_at);
  CREATE INDEX IF NOT EXISTS idx_user_sessions_peer_id ON user_sessions(peer_id);
`)
```

- [ ] **Step 3: Run backend startup migration smoke test**

Run:

```bash
node --check server/database.js
node --check server/index.js
```

Expected: no syntax errors.

- [ ] **Step 4: Commit**

```bash
git add server/database.js
git commit -m "feat(chat): add session semantic fields"
```

---

## Task 2: Create MessageNormalizer

**Files:**
- Create: `server/services/message-normalizer.js`
- Modify: `server/message-store.js`

- [ ] **Step 1: Create `server/services/message-normalizer.js`**

```js
const TIME_FIELDS = ['timestamp', 'createdAt', 'created_at', 'ts', 'time', 'msgTimestamp', 'msg_timestamp']

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null
}

export function normalizeTimestamp(value) {
  if (value == null || value === '') return null
  const numeric = Number(value)
  const date = Number.isFinite(numeric) && numeric > 0
    ? new Date(numeric > 1e12 ? numeric : numeric * 1000)
    : new Date(value)
  return Number.isFinite(date.getTime()) ? date.toISOString() : null
}

export function extractOccurredAt(raw) {
  const row = asRecord(raw)
  if (!row) return null
  for (const field of TIME_FIELDS) {
    const timestamp = normalizeTimestamp(row[field])
    if (timestamp) return timestamp
  }
  return null
}

export function normalizeMessageEnvelope({ sessionKey, message, seq, msgId, role, content, occurredAt }) {
  const raw = asRecord(message) || {}
  const normalizedRole = role || raw.role || raw.type || 'unknown'
  const normalizedContent = content != null
    ? content
    : raw.content != null
      ? raw.content
      : ''
  const normalizedOccurredAt = normalizeTimestamp(occurredAt) || extractOccurredAt(raw)

  return {
    id: msgId || raw.id || raw.msg_id || null,
    sessionKey,
    seq: seq ?? raw.seq ?? raw.messageSeq ?? null,
    role: normalizedRole,
    content: normalizedContent,
    occurredAt: normalizedOccurredAt,
    raw: message || raw,
    model: raw.model || null,
  }
}
```

- [ ] **Step 2: Update `server/message-store.js` timestamp extraction**

At top of `server/message-store.js`, add:

```js
import { extractOccurredAt } from './services/message-normalizer.js'
```

Replace existing `extractTimestamp(msg)` body with:

```js
function extractTimestamp(msg) {
  return extractOccurredAt(msg)
}
```

- [ ] **Step 3: Run syntax checks**

```bash
node --check server/services/message-normalizer.js
node --check server/message-store.js
```

Expected: no syntax errors.

- [ ] **Step 4: Commit**

```bash
git add server/services/message-normalizer.js server/message-store.js
git commit -m "feat(chat): normalize message occurrence time"
```

---

## Task 3: Create SessionActivityService

**Files:**
- Create: `server/services/session-activity-service.js`

- [ ] **Step 1: Create service file**

```js
import db from '../database.js'
import { normalizeTimestamp } from './message-normalizer.js'

function toMillis(isoString) {
  const time = new Date(isoString).getTime()
  return Number.isFinite(time) ? time : null
}

export function advanceSessionLastMessageAt(sessionKey, occurredAt) {
  if (!sessionKey) return { changed: false, reason: 'missing-session-key' }
  const normalized = normalizeTimestamp(occurredAt)
  if (!normalized) return { changed: false, reason: 'missing-occurred-at' }

  const nextMs = toMillis(normalized)
  if (!nextMs) return { changed: false, reason: 'invalid-occurred-at' }

  const rows = db.prepare(`
    SELECT id, last_message_at
    FROM user_sessions
    WHERE session_key = ?
  `).all(sessionKey)

  let changed = 0
  const update = db.prepare(`
    UPDATE user_sessions
    SET last_message_at = ?, updated_at = ?
    WHERE id = ?
      AND (last_message_at IS NULL OR last_message_at < ?)
  `)

  const now = Date.now()
  const tx = db.transaction((items) => {
    for (const row of items) {
      const result = update.run(nextMs, now, row.id, nextMs)
      changed += result.changes
    }
  })
  tx(rows)

  return { changed: changed > 0, rows: changed, occurredAt: normalized }
}

export function recomputeSessionLastMessageAt(sessionKey, occurredAtValues) {
  const timestamps = occurredAtValues
    .map(normalizeTimestamp)
    .filter(Boolean)
    .map((value) => ({ iso: value, ms: toMillis(value) }))
    .filter((item) => item.ms)

  if (timestamps.length === 0) return { changed: false, reason: 'no-real-message-time' }
  timestamps.sort((a, b) => b.ms - a.ms)
  return advanceSessionLastMessageAt(sessionKey, timestamps[0].iso)
}
```

- [ ] **Step 2: Run syntax check**

```bash
node --check server/services/session-activity-service.js
```

Expected: no syntax errors.

- [ ] **Step 3: Commit**

```bash
git add server/services/session-activity-service.js
git commit -m "feat(chat): add session activity service"
```

---

## Task 4: Create SessionTitleService

**Files:**
- Create: `server/services/session-title-service.js`

- [ ] **Step 1: Create service file**

```js
const CHANNEL_LABELS = {
  feishu: '飞书',
  lark: '飞书',
  qqbot: 'QQ Bot',
  qq: 'QQ',
  telegram: 'Telegram',
  whatsapp: 'WhatsApp',
  discord: 'Discord',
  slack: 'Slack',
  main: '在线对话',
  webchat: '在线对话',
}

const INTERNAL_PEER_PATTERNS = [
  /^ou_[a-z0-9_\-]+$/i,
  /^oc_[a-z0-9_\-]+$/i,
  /^on_[a-z0-9_\-]+$/i,
  /^chat_[a-z0-9_\-]+$/i,
]

const MEANINGLESS_TITLES = new Set(['', 'OpenClaw Web Backend', 'main'])

function normalizeChannel(channel) {
  return String(channel || '').trim().toLowerCase()
}

export function getChannelLabel(channel) {
  const key = normalizeChannel(channel)
  return CHANNEL_LABELS[key] || channel || '会话'
}

export function isInternalPeerId(value) {
  const text = String(value || '').trim()
  if (!text) return false
  return INTERNAL_PEER_PATTERNS.some((pattern) => pattern.test(text))
}

export function summarizeMessage(content) {
  const text = String(content || '')
    .replace(/^\[[^\]]+\]\s*/, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (!text) return ''
  return text.length > 32 ? `${text.slice(0, 32)}…` : text
}

export function shouldBackfillDisplayTitle(existingTitle, peerId) {
  const title = String(existingTitle || '').trim()
  return MEANINGLESS_TITLES.has(title) || isInternalPeerId(title) || title === String(peerId || '').trim()
}

export function resolveSessionDisplayTitle({ channel, peerProfile, firstUserMessage, isGroup = false }) {
  const channelLabel = getChannelLabel(channel)
  const profileName = peerProfile?.groupName || peerProfile?.displayName || ''
  if (profileName && !isInternalPeerId(profileName)) {
    return `${channelLabel} · ${profileName}`
  }

  const summary = summarizeMessage(firstUserMessage)
  if (summary && !isInternalPeerId(summary)) {
    return `${channelLabel} · ${summary}`
  }

  if (normalizeChannel(channel) === 'feishu' || normalizeChannel(channel) === 'lark') {
    return isGroup || peerProfile?.isGroup ? '飞书群聊' : '飞书私聊'
  }

  return `${channelLabel}会话`
}
```

- [ ] **Step 2: Run syntax check**

```bash
node --check server/services/session-title-service.js
```

Expected: no syntax errors.

- [ ] **Step 3: Commit**

```bash
git add server/services/session-title-service.js
git commit -m "feat(chat): add session title service"
```

---

## Task 5: Fix User Session Ownership Writes

**Files:**
- Modify: `server/user-manager.js`

- [ ] **Step 1: Import title service**

Add near imports:

```js
import { shouldBackfillDisplayTitle } from './services/session-title-service.js'
import { normalizeTimestamp } from './services/message-normalizer.js'
```

- [ ] **Step 2: Change `getUserSessions` ordering**

Replace:

```js
export function getUserSessions(userId) {
  return db.prepare('SELECT * FROM user_sessions WHERE user_id = ? ORDER BY updated_at DESC').all(userId)
}
```

With:

```js
export function getUserSessions(userId) {
  return db.prepare(`
    SELECT * FROM user_sessions
    WHERE user_id = ?
    ORDER BY COALESCE(last_message_at, 0) DESC, updated_at DESC
  `).all(userId)
}
```

- [ ] **Step 3: Replace `trackSessionForUser`**

Replace the function with:

```js
export function trackSessionForUser(userId, sessionKey, agentId, label, channel, options = {}) {
  const now = Date.now()
  const peerId = options.peerId || null
  const occurredAt = normalizeTimestamp(options.occurredAt)
  const lastMessageAt = occurredAt ? new Date(occurredAt).getTime() : null
  const existing = db.prepare(`
    SELECT id, display_title, label, last_message_at
    FROM user_sessions
    WHERE user_id = ? AND session_key = ?
  `).get(userId, sessionKey)

  if (existing) {
    const existingTitle = existing.display_title || existing.label || ''
    const nextDisplayTitle = shouldBackfillDisplayTitle(existingTitle, peerId) ? (label || null) : existing.display_title
    db.prepare(`
      UPDATE user_sessions
      SET updated_at = ?,
          agent_id = COALESCE(?, agent_id),
          channel = COALESCE(?, channel),
          peer_id = COALESCE(?, peer_id),
          display_title = COALESCE(?, display_title),
          label = COALESCE(label, ?),
          last_message_at = CASE
            WHEN ? IS NOT NULL AND (last_message_at IS NULL OR last_message_at < ?) THEN ?
            ELSE last_message_at
          END
      WHERE id = ?
    `).run(
      now,
      agentId || null,
      channel || null,
      peerId,
      nextDisplayTitle,
      label || null,
      lastMessageAt,
      lastMessageAt,
      lastMessageAt,
      existing.id,
    )
    return
  }

  db.prepare(`
    INSERT INTO user_sessions (
      id, user_id, session_key, agent_id, label, display_title, channel, peer_id, last_message_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    randomUUID(),
    userId,
    sessionKey,
    agentId || null,
    label || null,
    label || null,
    channel || null,
    peerId,
    lastMessageAt,
    now,
  )
}
```

- [ ] **Step 4: Replace `upsertSyncedUserSession` last activity logic**

Inside `upsertSyncedUserSession`, replace `const updatedAt = normalizeSessionUpdatedAt(lastActivity, now)` with:

```js
const normalizedLastActivity = normalizeTimestamp(lastActivity)
const lastMessageAt = normalizedLastActivity ? new Date(normalizedLastActivity).getTime() : null
```

Update the SELECT to include semantic columns:

```sql
SELECT id, agent_id, channel, label, display_title, peer_id, last_message_at, updated_at
```

For insert, use:

```js
db.prepare(`
  INSERT INTO user_sessions (
    id, user_id, session_key, agent_id, label, display_title, channel, peer_id, last_message_at, updated_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`).run(
  randomUUID(),
  userId,
  sessionKey,
  agentId || null,
  label || null,
  label || null,
  channel || null,
  peer || null,
  lastMessageAt,
  now,
)
```

For update, compute:

```js
const nextAgentId = agentId || existing.agent_id || null
const nextChannel = channel || existing.channel || null
const nextPeerId = peer || existing.peer_id || null
const existingTitle = existing.display_title || existing.label || ''
const nextDisplayTitle = shouldBackfillDisplayTitle(existingTitle, nextPeerId)
  ? (label || existing.display_title || existing.label || null)
  : (existing.display_title || existing.label || null)
const nextLabel = existing.label || nextDisplayTitle || null
const nextLastMessageAt = lastMessageAt != null
  ? Math.max(Number(existing.last_message_at) || 0, lastMessageAt)
  : (existing.last_message_at || null)
```

Update SQL:

```js
db.prepare(`
  UPDATE user_sessions
  SET updated_at = ?, agent_id = ?, channel = ?, peer_id = ?, label = ?, display_title = ?, last_message_at = ?
  WHERE id = ?
`).run(now, nextAgentId, nextChannel, nextPeerId, nextLabel, nextDisplayTitle, nextLastMessageAt, existing.id)
```

- [ ] **Step 5: Run syntax check**

```bash
node --check server/user-manager.js
```

Expected: no syntax errors.

- [ ] **Step 6: Commit**

```bash
git add server/user-manager.js
git commit -m "fix(chat): separate session ownership from activity time"
```

---

## Task 6: Make Sessions API Pure Read

**Files:**
- Modify: `server/handlers/sessions.js`

- [ ] **Step 1: Import title helpers**

Add near imports:

```js
import { getChannelLabel, isInternalPeerId } from '../services/session-title-service.js'
```

- [ ] **Step 2: Replace `normalizeLocalSession`**

Replace function with:

```js
function normalizeLocalSession(local, localTitles) {
  const key = local.session_key
  const agentId = key.match(/^agent:([^:]+):/)?.[1] || local.agent_id || 'main'
  const channel = key.match(/^agent:[^:]+:([^:]+):/)?.[1] || local.channel || 'main'
  const peer = local.peer_id || key.match(/^agent:[^:]+:[^:]+:[^:]+:(.+)$/)?.[1] || 'user'
  const storedTitle = local.display_title || local.label || localTitles.get(key) || ''
  const displayTitle = storedTitle && !isInternalPeerId(storedTitle)
    ? storedTitle
    : `${getChannelLabel(channel)}会话`
  const lastMessageAt = local.last_message_at ? new Date(local.last_message_at).toISOString() : ''

  return {
    key,
    agentId,
    channel,
    peer,
    peerId: peer,
    messageCount: local.msg_total || 0,
    lastActivity: lastMessageAt,
    lastMessageAt,
    model: undefined,
    label: displayTitle,
    displayTitle,
    tokenUsage: undefined,
  }
}
```

- [ ] **Step 3: Keep background sync but enforce pure read contract**

Leave the existing `setImmediate(scheduleUserSessionSync)` in place. It may update metadata only through `upsertSyncedUserSession`, which Task 5 changed so missing `lastActivity` does not mutate `last_message_at`.

- [ ] **Step 4: Run syntax check**

```bash
node --check server/handlers/sessions.js
```

Expected: no syntax errors.

- [ ] **Step 5: Commit**

```bash
git add server/handlers/sessions.js
git commit -m "fix(chat): make sessions list use semantic fields"
```

---

## Task 7: Normalize Chat History Timestamps

**Files:**
- Modify: `server/handlers/chat.js`

- [ ] **Step 1: Import normalizer and activity service**

Add near imports:

```js
import { extractOccurredAt, normalizeMessageEnvelope } from '../services/message-normalizer.js'
import { recomputeSessionLastMessageAt } from '../services/session-activity-service.js'
```

- [ ] **Step 2: Add local row DTO helper near route setup**

```js
function messageRowToDto(row) {
  const raw = row.raw_content && typeof row.raw_content === 'object' ? row.raw_content : null
  const timestamp = row.msg_timestamp || extractOccurredAt(raw) || undefined
  if (raw) {
    return {
      ...raw,
      timestamp,
    }
  }
  return {
    role: row.role,
    content: row.content,
    timestamp,
    ...(row.model ? { model: row.model } : {}),
  }
}
```

- [ ] **Step 3: Replace local messages mapping**

Replace current `rows.map(r => { ... })` block in `/api/chat/history` with:

```js
const messages = rows.map(messageRowToDto)
```

- [ ] **Step 4: Normalize Gateway backfill messages**

Replace `backfillMsgs = messages.map((m, i) => { ... })` with:

```js
const backfillMsgs = messages.map((m, i) => {
  const envelope = normalizeMessageEnvelope({
    sessionKey,
    message: m,
    seq: i + 1,
    msgId: m.id || m.msg_id || null,
    role: m.role || 'unknown',
    content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
  })
  return {
    seq: envelope.seq || i + 1,
    msgId: envelope.id,
    role: envelope.role,
    content: typeof envelope.content === 'string' ? envelope.content : JSON.stringify(envelope.content || ''),
    rawContent: envelope.raw,
    model: envelope.model,
    status: 'confirmed',
    msgTimestamp: envelope.occurredAt,
  }
})
```

- [ ] **Step 5: Advance session time after replace**

Inside the `.then(written => { ... })` block after `replaceSession`, add:

```js
recomputeSessionLastMessageAt(
  sessionKey,
  backfillMsgs.map((message) => message.msgTimestamp),
)
```

- [ ] **Step 6: Run syntax check**

```bash
node --check server/handlers/chat.js
```

Expected: no syntax errors.

- [ ] **Step 7: Commit**

```bash
git add server/handlers/chat.js
git commit -m "fix(chat): return persisted message timestamps"
```

---

## Task 8: Update External Message Sync

**Files:**
- Modify: `server/core/message-sync.js`

- [ ] **Step 1: Import services**

Add near imports:

```js
import { normalizeMessageEnvelope } from '../services/message-normalizer.js'
import { advanceSessionLastMessageAt } from '../services/session-activity-service.js'
```

- [ ] **Step 2: Normalize `handleSessionMessage` before save**

Inside `handleSessionMessage`, after `fields` is created and before `saveMessage`, add:

```js
const envelope = normalizeMessageEnvelope({
  sessionKey,
  message,
  seq: fields.seq,
  msgId: fields.msgId,
  role: fields.role,
  content: fields.content,
  occurredAt: fields.timestamp,
})
```

Replace `saveMessage` fields with:

```js
await saveMessage({
  sessionKey,
  seq: envelope.seq,
  msgId: envelope.id,
  role: envelope.role,
  content: envelope.content,
  rawContent: envelope.raw,
  status: 'confirmed',
  msgTimestamp: envelope.occurredAt,
})
advanceSessionLastMessageAt(sessionKey, envelope.occurredAt)
```

- [ ] **Step 3: Stop `sessions.changed` from injecting Date.now**

Replace:

```js
lastActivity: payload.updatedAt || Date.now(),
```

With:

```js
lastActivity: payload.updatedAt || null,
```

- [ ] **Step 4: Update catch-up local query**

Replace in `catchUpMissedMessages`:

```sql
WHERE updated_at > ?
```

With:

```sql
WHERE COALESCE(last_message_at, updated_at) > ?
```

This preserves catch-up behavior while moving semantic ordering to `last_message_at`.

- [ ] **Step 5: Run syntax check**

```bash
node --check server/core/message-sync.js
```

Expected: no syntax errors.

- [ ] **Step 6: Commit**

```bash
git add server/core/message-sync.js
git commit -m "fix(chat): advance session time from real message events"
```

---

## Task 9: Update Gateway Session Sync

**Files:**
- Modify: `server/core/session-sync.js`

- [ ] **Step 1: Ensure normalized session preserves real last activity only**

Find `normalizeGatewaySessionForSync`. Ensure returned object uses actual Gateway fields only:

```js
return {
  sessionKey,
  agentId,
  channel,
  peer,
  label,
  lastActivity: row.lastActivity || row.last_activity || row.updatedAt || row.updated_at || row.timestamp || null,
}
```

Do not add `Date.now()` fallback in this function.

- [ ] **Step 2: Run syntax check**

```bash
node --check server/core/session-sync.js
```

Expected: no syntax errors.

- [ ] **Step 3: Commit**

```bash
git add server/core/session-sync.js
git commit -m "fix(chat): remove synthetic session sync activity time"
```

---

## Task 10: Replace Auto Title Logic With SessionTitleService

**Files:**
- Modify: `server/index.js`

- [ ] **Step 1: Import service**

Add near existing imports:

```js
import { resolveSessionDisplayTitle, shouldBackfillDisplayTitle } from './services/session-title-service.js'
```

- [ ] **Step 2: Update `tryAutoTitleForChannelSession` title generation**

Replace title computation:

```js
const title = generateSafeTitle(content)
```

With:

```js
const channel = channels[0]
const channelType = channel.channel_type || channel.type || channel.channel || 'feishu'
const peerId = sessionKey.match(/^agent:[^:]+:[^:]+:[^:]+:(.+)$/)?.[1] || ''
const title = resolveSessionDisplayTitle({
  channel: channelType,
  peerProfile: {
    channel: channelType,
    peerId,
    displayName: channel.accountName || channel.name || '',
    isGroup: sessionKey.includes(':group:'),
  },
  firstUserMessage: content,
  isGroup: sessionKey.includes(':group:'),
})
```

- [ ] **Step 3: Call `trackSessionForUser` with peerId option**

Replace:

```js
trackSessionForUser(uid, sessionKey, agentId, title, null)
```

With:

```js
trackSessionForUser(uid, sessionKey, agentId, title, channelType, { peerId })
```

- [ ] **Step 4: Remove direct `generateSafeTitle` dependency if unused**

If `generateSafeTitle` is only used by this auto title path, remove the import/function. If still used elsewhere, keep it.

- [ ] **Step 5: Run syntax check**

```bash
node --check server/index.js
```

Expected: no syntax errors.

- [ ] **Step 6: Commit**

```bash
git add server/index.js
git commit -m "fix(chat): generate channel session titles via domain service"
```

---

## Task 11: Update Frontend Session Type and Normalization

**Files:**
- Modify: `src/api/types/session.ts`
- Modify: `src/api/rpc-client.ts`

- [ ] **Step 1: Extend Session interface**

In `src/api/types/session.ts`, update `Session`:

```ts
export interface Session {
  key: string
  agentId: string
  channel: string
  peer: string
  peerId?: string
  messageCount: number
  lastActivity: string
  lastMessageAt?: string
  model?: string
  tokenUsage?: TokenUsage
  label?: string
  displayTitle?: string
  isStreaming?: boolean
}
```

- [ ] **Step 2: Update RPC session normalization**

In `src/api/rpc-client.ts`, find `normalizeSessionItem`. Ensure returned object maps aliases:

```ts
const displayTitle = asString(row.displayTitle) || asString(row.display_title) || asString(row.label)
const lastMessageAt = asString(row.lastMessageAt) || asString(row.last_message_at) || asString(row.lastActivity)
```

Returned session should include:

```ts
label: displayTitle,
displayTitle,
lastActivity: lastMessageAt,
lastMessageAt,
peerId: asString(row.peerId) || asString(row.peer_id) || peer,
```

- [ ] **Step 3: Run type check**

```bash
npx vue-tsc --noEmit
```

Expected: either PASS, or only pre-existing unrelated errors. If errors reference changed files, fix them before continuing.

- [ ] **Step 4: Commit**

```bash
git add src/api/types/session.ts src/api/rpc-client.ts
git commit -m "feat(chat): expose session semantic fields"
```

---

## Task 12: Fix Frontend History Timestamp Parsing

**Files:**
- Modify: `src/stores/workspace-message-utils.ts`

- [ ] **Step 1: Add timestamp helper near existing utility helpers**

```ts
function normalizeMessageTimestamp(row: Record<string, unknown>): string | undefined {
  const candidates = [row.timestamp, row.createdAt, row.created_at, row.ts, row.time]
  for (const value of candidates) {
    if (value == null || value === '') continue
    const numeric = Number(value)
    const date = Number.isFinite(numeric) && numeric > 0
      ? new Date(numeric > 1e12 ? numeric : numeric * 1000)
      : new Date(String(value))
    if (Number.isFinite(date.getTime())) return date.toISOString()
  }
  return undefined
}
```

- [ ] **Step 2: Replace timestamp extraction in `parseHistoryMessages`**

Replace:

```ts
const timestamp = typeof row.timestamp === 'string' ? row.timestamp : undefined
const ts = Number(row.timestamp) || Date.now()
```

With:

```ts
const timestamp = normalizeMessageTimestamp(row)
const ts = timestamp ? new Date(timestamp).getTime() : 0
```

- [ ] **Step 3: Preserve timestamp when merging assistant messages**

In adjacent assistant merge object, add:

```ts
timestamp: lastMsg.timestamp || timestamp,
```

- [ ] **Step 4: Run type check**

```bash
npx vue-tsc --noEmit
```

Expected: changed file has no TypeScript errors.

- [ ] **Step 5: Commit**

```bash
git add src/stores/workspace-message-utils.ts
git commit -m "fix(chat): preserve historical message timestamps"
```

---

## Task 13: Stop Frontend Clicks From Affecting Session List Time

**Files:**
- Modify: `src/stores/workspace.ts`

- [ ] **Step 1: Add helper for real event activity timestamps**

Near `getSessionActivityTs`, add:

```ts
function setSessionActivityFromEvent(sessionKey: string, occurredAt?: string | number | null) {
  if (!sessionKey || occurredAt == null || occurredAt === '') return
  const numeric = Number(occurredAt)
  const date = Number.isFinite(numeric) && numeric > 0
    ? new Date(numeric > 1e12 ? numeric : numeric * 1000)
    : new Date(String(occurredAt))
  const time = date.getTime()
  if (!Number.isFinite(time)) return
  activityTimestamps.value = new Map(activityTimestamps.value).set(sessionKey, time)
}
```

- [ ] **Step 2: Update `handleNotification` signature**

Replace:

```ts
function handleNotification(sessionKey: string, isWorkspaceRoute: boolean) {
```

With:

```ts
function handleNotification(sessionKey: string, isWorkspaceRoute: boolean, occurredAt?: string | number | null) {
```

Replace inside it:

```ts
activityTimestamps.value = new Map(activityTimestamps.value).set(sessionKey, Date.now())
```

With:

```ts
setSessionActivityFromEvent(sessionKey, occurredAt)
```

- [ ] **Step 3: Replace other `activityTimestamps` writes using Date.now**

Find writes matching:

```ts
activityTimestamps.value = new Map(activityTimestamps.value).set(..., Date.now())
```

For real message send path, use the local message timestamp:

```ts
setSessionActivityFromEvent(sessionKey, localMessage.timestamp)
```

For non-message paths, remove the write.

- [ ] **Step 4: Expose helper if event handling needs it**

In returned store object, include:

```ts
setSessionActivityFromEvent,
```

- [ ] **Step 5: Run type check**

```bash
npx vue-tsc --noEmit
```

Expected: changed file has no TypeScript errors.

- [ ] **Step 6: Commit**

```bash
git add src/stores/workspace.ts
git commit -m "fix(chat): restrict session list activity timestamps"
```

---

## Task 14: Update WorkspaceSidebar Rendering

**Files:**
- Modify: `src/views/workspace/WorkspaceSidebar.vue`

- [ ] **Step 1: Replace `getSessionLabel`**

Replace current function with:

```ts
function getSessionLabel(session: { label?: string; displayTitle?: string; key: string }): string {
  return session.displayTitle || session.label || '会话'
}
```

Do not derive title from `session.key`.

- [ ] **Step 2: Update `sessionEffectiveTs` to prefer semantic time**

Replace `const ts = session.lastActivity` with:

```ts
const ts = session.lastMessageAt || session.lastActivity
```

- [ ] **Step 3: Run type check**

```bash
npx vue-tsc --noEmit
```

Expected: changed file has no TypeScript errors.

- [ ] **Step 4: Commit**

```bash
git add src/views/workspace/WorkspaceSidebar.vue
git commit -m "fix(chat): render session display titles from backend"
```

---

## Task 15: Verify MessageList Time Display

**Files:**
- Modify if needed: `src/views/workspace/MessageList.vue`

- [ ] **Step 1: Confirm shared format function handles numeric strings**

Ensure `formatTime(ts?: string)` remains:

```ts
function formatTime(ts?: string) {
  if (!ts) return ''
  const numeric = Number(ts)
  const date = Number.isFinite(numeric) && numeric > 0
    ? new Date(numeric > 1e12 ? numeric : numeric * 1000)
    : new Date(ts)
  if (isNaN(date.getTime())) return ''
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}
```

- [ ] **Step 2: Confirm assistant and user both use `formatTime(msg.timestamp)`**

Expected template snippets:

```vue
<div class="msg-time">{{ formatTime(msg.timestamp) }}</div>
```

and:

```vue
<span class="msg-time">{{ formatTime(msg.timestamp) }}</span>
```

- [ ] **Step 3: Run type check**

```bash
npx vue-tsc --noEmit
```

Expected: changed file has no TypeScript errors.

- [ ] **Step 4: Commit only if file changed**

```bash
git add src/views/workspace/MessageList.vue
git commit -m "fix(chat): unify message time display"
```

---

## Task 16: End-to-End Verification

**Files:**
- No code changes unless verification exposes a bug.

- [ ] **Step 1: Run backend syntax checks**

```bash
node --check server/database.js
node --check server/user-manager.js
node --check server/handlers/sessions.js
node --check server/handlers/chat.js
node --check server/core/message-sync.js
node --check server/core/session-sync.js
node --check server/index.js
node --check server/services/message-normalizer.js
node --check server/services/session-title-service.js
node --check server/services/session-activity-service.js
```

Expected: all pass.

- [ ] **Step 2: Run frontend type check/build**

```bash
npx vue-tsc --noEmit
```

Expected: PASS. If project has existing unrelated errors, capture them in final report and ensure no errors reference changed files.

- [ ] **Step 3: Search for forbidden session activity writes**

```bash
grep -R "UPDATE user_sessions SET updated_at" server || true
grep -R "lastActivity: .*Date.now" server src || true
grep -R "activityTimestamps.*Date.now" src/stores src/views || true
```

Expected:

- No new direct `UPDATE user_sessions SET updated_at` expressing session activity.
- No `lastActivity: Date.now()` in sync paths.
- No `activityTimestamps` writes using `Date.now()` except deleted/irrelevant historical context.

- [ ] **Step 4: Manual browser verification**

Run app:

```bash
npm run dev:all
```

Expected startup: frontend on port 3000, backend on port 3001.

Manual checks:

1. Open an old Feishu conversation.
2. Confirm title is not `ou_...` or `oc_...`.
3. Confirm user history messages show `HH:mm`.
4. Confirm assistant history messages show `HH:mm`.
5. Refresh page after only opening the old session.
6. Confirm sidebar time did not change to “刚刚”.
7. Send a new message.
8. Confirm sidebar time updates to “刚刚”.

- [ ] **Step 5: Final commit for any verification fixes**

If verification required small fixes:

```bash
git add <specific-files>
git commit -m "fix(chat): stabilize title and time semantics"
```

---

## Self-Review

### Spec coverage

- `peer_id` / `display_title` / `last_message_at`: Tasks 1, 5, 6, 11, 14.
- `updated_at` as row update time only: Tasks 1, 3, 5, 8, 16.
- `SessionTitleService`: Tasks 4, 10.
- `SessionActivityService`: Tasks 3, 7, 8.
- `MessageNormalizer`: Tasks 2, 7, 8.
- Message write-before-read normalization: Tasks 2, 7, 8.
- `/api/sessions` pure read: Task 6 and Task 16 grep verification.
- Frontend pure rendering: Tasks 11-15.

### Placeholder scan

No TBD/TODO placeholders. Every task has file paths, code snippets, commands, and expected outcomes.

### Type consistency

- Backend semantic names: `peer_id`, `display_title`, `last_message_at`.
- API compatibility names: `peerId`, `displayTitle`, `lastMessageAt`.
- Existing frontend compatibility retained: `label`, `lastActivity`.
- Service names are consistent across tasks.
