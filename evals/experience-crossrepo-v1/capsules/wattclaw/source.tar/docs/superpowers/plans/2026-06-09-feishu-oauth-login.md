# 飞书 OAuth 授权登录 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 WattClaw 登录页新增飞书 OAuth 授权登录入口，管理员通过后台脚本预绑定飞书 union_id 与 WattClaw 用户。

**Architecture:** Base+Plugin 模式。新增独立的 `feishu-oauth.js`（API 交互）和 `feishu-auth.js`（路由处理器）作为插件模块，不修改任何现有认证核心文件（user-manager.js、core/auth.js、users 表）。State 持久化至 SQLite，消除重启丢失风险。

**Tech Stack:** Node.js Express（后端）、Vue 3 + Naive UI（前端）、SQLite（持久化）、飞书 OAuth 2.0

**设计文档:** `docs/superpowers/specs/2026-06-09-feishu-oauth-login-design.md`

---

## 文件清单

| 操作 | 文件 | 职责 |
|------|------|------|
| 新建 | `server/core/feishu-oauth.js` | 飞书 API 交互：构造授权 URL、code 换 token、获取用户信息、state 管理、速率限制 |
| 新建 | `server/handlers/feishu-auth.js` | 3 个 HTTP 端点：config / authorize / callback |
| 新建 | `src/views/auth/FeishuCallback.vue` | 回调落地页：提取 code+state、发送请求、存储 Token |
| 新建 | `src/api/types/feishu-auth.ts` | 飞书认证 TypeScript 类型 |
| 新建 | `scripts/bind-feishu.js` | 后台绑定/解绑/重绑脚本 |
| 修改 | `server/database.js` | 追加 `user_oauth_bindings` + `oauth_states` 建表 |
| 修改 | `server/index.js:84` | 追加 import + 注册路由 |
| 修改 | `src/router/routes.ts:6-12` | 追加 `/auth/feishu/callback` 公开路由 |
| 修改 | `src/views/Login.vue:166-175` | 追加飞书登录按钮区域 |
| 修改 | `src/stores/auth.ts` | 追加 `feishuLogin` action |
| 修改 | `src/api/types/index.ts` | 追加 barrel export |
| 修改 | `src/i18n/messages/zh-CN.ts:206-217` | 追加飞书登录相关文案 |

**冻结确认：** `users` 表 ✅ | `auth_tokens` 表 ✅ | `user-manager.js` ✅ | `core/auth.js` ✅ — 不修改。

---

### Task 1: 数据库 Schema — 新增 `user_oauth_bindings` + `oauth_states` 表

**Files:**
- Modify: `server/database.js` (在现有 `CREATE TABLE` 块之后追加，约第 365 行)

- [ ] **Step 1: 在 database.js 的 CREATE TABLE 块末尾追加两张新表**

在 `database.js` 中，找到最后一个 `CREATE INDEX` 语句（`idx_cron_jobs_agent_id`，约第 364 行），在其后追加：

```javascript
  // ── Feishu OAuth tables ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_oauth_bindings (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      provider TEXT NOT NULL DEFAULT 'feishu',
      union_id TEXT NOT NULL,
      open_id TEXT,
      display_name TEXT,
      avatar_url TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_oauth_provider_union
      ON user_oauth_bindings(provider, union_id);
    CREATE INDEX IF NOT EXISTS idx_oauth_user_id
      ON user_oauth_bindings(user_id);

    CREATE TABLE IF NOT EXISTS oauth_states (
      state TEXT PRIMARY KEY,
      created_at INTEGER NOT NULL
    );
  `)
```

- [ ] **Step 2: 添加过期 state 定期清理**

在 `database.js` 的 Migration 区域（`addColumnIfMissing` 函数之后）追加：

```javascript
// Cleanup expired OAuth states every minute
setInterval(() => {
  try {
    const cutoff = Date.now() - 5 * 60 * 1000 // 5 min TTL
    db.prepare('DELETE FROM oauth_states WHERE created_at < ?').run(cutoff)
  } catch {}
}, 60_000)
```

- [ ] **Step 3: 启动服务验证建表成功**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && timeout 5 node -e "import('./server/database.js').then(() => console.log('OK'))" 2>&1 || true`
Expected: 输出 `OK`，无 SQL 错误

- [ ] **Step 4: Commit**

```bash
git add server/database.js
git commit -m "feat(auth): add user_oauth_bindings and oauth_states tables"
```

---

### Task 2: 核心模块 — `feishu-oauth.js`（飞书 API 交互 + state 管理）

**Files:**
- Create: `server/core/feishu-oauth.js`

- [ ] **Step 1: 创建 `server/core/feishu-oauth.js`**

```javascript
// Feishu OAuth 2.0 service — code exchange, user info, state management
import { randomBytes } from 'crypto'
import db from '../database.js'

const FEISHU_APP_ID = process.env.FEISHU_APP_ID || ''
const FEISHU_APP_SECRET = process.env.FEISHU_APP_SECRET || ''
const FEISHU_REDIRECT_URI = process.env.FEISHU_REDIRECT_URI || ''

const STATE_TTL = 5 * 60 * 1000 // 5 minutes

// ── Rate limiting ──
const _authorizeRateLimit = new Map() // ip → { count, resetAt }
const AUTHORIZE_RATE_LIMIT = 10 // per minute per IP

function checkAuthorizeRateLimit(ip) {
  const now = Date.now()
  const entry = _authorizeRateLimit.get(ip)
  if (!entry || now > entry.resetAt) {
    _authorizeRateLimit.set(ip, { count: 1, resetAt: now + 60_000 })
    return true
  }
  if (entry.count >= AUTHORIZE_RATE_LIMIT) return false
  entry.count++
  return true
}

// ── State management (SQLite-backed) ──
function generateState() {
  const state = randomBytes(32).toString('hex')
  db.prepare('INSERT INTO oauth_states (state, created_at) VALUES (?, ?)').run(state, Date.now())
  return state
}

function consumeState(state) {
  const row = db.prepare('SELECT created_at FROM oauth_states WHERE state = ?').get(state)
  if (!row) return false
  db.prepare('DELETE FROM oauth_states WHERE state = ?').run(state)
  return Date.now() - row.created_at <= STATE_TTL
}

// ── Authorization URL construction ──
export function isFeishuAuthEnabled() {
  return !!(FEISHU_APP_ID && FEISHU_APP_SECRET && FEISHU_REDIRECT_URI)
}

export function buildAuthorizeUrl(ip) {
  if (!isFeishuAuthEnabled()) return null
  if (!checkAuthorizeRateLimit(ip)) return { error: 'rate_limited' }

  const state = generateState()
  const params = new URLSearchParams({
    app_id: FEISHU_APP_ID,
    redirect_uri: FEISHU_REDIRECT_URI,
    state,
  })
  return { url: `https://open.feishu.cn/open-apis/authen/v1/authorize?${params.toString()}` }
}

// ── Token exchange ──
async function exchangeCodeForToken(code) {
  const response = await fetch('https://open.feishu.cn/open-apis/authen/v2/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'authorization_code',
      client_id: FEISHU_APP_ID,
      client_secret: FEISHU_APP_SECRET,
      code,
      redirect_uri: FEISHU_REDIRECT_URI,
    }),
  })
  const body = await response.json()
  if (body.code !== 0) {
    throw new Error(body.msg || 'Token exchange failed')
  }
  return body.data // { access_token, token_type, expires_in, refresh_token }
}

// ── User info ──
async function getUserInfo(accessToken) {
  const response = await fetch('https://open.feishu.cn/open-apis/authen/v1/user_info', {
    headers: { Authorization: `Bearer ${accessToken}` },
  })
  const body = await response.json()
  if (body.code !== 0) {
    throw new Error(body.msg || 'Get user info failed')
  }
  return body.data // { union_id, open_id, name, avatar_url, user_id }
}

// ── Full callback flow ──
export async function handleFeishuCallback(code, state) {
  // 1. Validate state
  if (!state || !consumeState(state)) {
    return { ok: false, status: 403, error: 'state 已过期，请重新登录' }
  }

  // 2. Exchange code for token
  let tokenData
  try {
    tokenData = await exchangeCodeForToken(code)
  } catch (e) {
    return { ok: false, status: 502, error: '飞书授权服务不可用' }
  }

  // 3. Get user info
  let feishuUser
  try {
    feishuUser = await getUserInfo(tokenData.access_token)
  } catch (e) {
    return { ok: false, status: 502, error: '获取飞书用户信息失败' }
  }

  // 4. Look up binding
  const binding = db.prepare(
    'SELECT user_id FROM user_oauth_bindings WHERE provider = ? AND union_id = ?'
  ).get('feishu', feishuUser.union_id)

  if (!binding) {
    return { ok: false, status: 401, error: '该飞书账号未绑定系统用户' }
  }

  // 5. Snapshot display info
  db.prepare(`
    UPDATE user_oauth_bindings
    SET open_id = ?, display_name = ?, avatar_url = ?, updated_at = ?
    WHERE provider = 'feishu' AND union_id = ?
  `).run(feishuUser.open_id || null, feishuUser.name || null, feishuUser.avatar_url || null, Date.now(), feishuUser.union_id)

  return { ok: true, userId: binding.user_id }
}
```

- [ ] **Step 2: 验证语法无误**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/core/feishu-oauth.js && echo "SYNTAX OK"`
Expected: `SYNTAX OK`

- [ ] **Step 3: Commit**

```bash
git add server/core/feishu-oauth.js
git commit -m "feat(auth): add feishu-oauth core module — state, token exchange, user info"
```

---

### Task 3: 路由处理器 — `feishu-auth.js`

**Files:**
- Create: `server/handlers/feishu-auth.js`
- Modify: `server/index.js:84` (追加 import) 和 `server/index.js:613` (追加路由注册)

- [ ] **Step 1: 创建 `server/handlers/feishu-auth.js`**

```javascript
// Feishu OAuth auth routes: config, authorize, callback
import { isFeishuAuthEnabled, buildAuthorizeUrl, handleFeishuCallback } from '../core/feishu-oauth.js'
import { createAuthToken, getUserById } from '../user-manager.js'

export function createFeishuAuthRoutes(app) {
  // GET /api/auth/feishu/config — 前端判断是否显示飞书登录按钮
  app.get('/api/auth/feishu/config', (_req, res) => {
    res.json({ enabled: isFeishuAuthEnabled() })
  })

  // GET /api/auth/feishu/authorize — 生成 state + 返回完整授权 URL
  app.get('/api/auth/feishu/authorize', (req, res) => {
    const result = buildAuthorizeUrl(req.ip)
    if (!result) {
      return res.status(400).json({ error: '飞书登录未配置' })
    }
    if (result.error === 'rate_limited') {
      return res.status(429).json({ error: '请求过于频繁，请稍后再试' })
    }
    res.json({ url: result.url })
  })

  // POST /api/auth/feishu/callback — 接收 code+state，完成 OAuth 流程
  app.post('/api/auth/feishu/callback', async (req, res) => {
    const { code, state } = req.body
    if (!code || !state) {
      return res.status(400).json({ ok: false, error: '参数缺失' })
    }

    try {
      const result = await handleFeishuCallback(code, state)
      if (!result.ok) {
        return res.status(result.status).json({ ok: false, error: result.error })
      }

      // Verify user still active
      const user = getUserById(result.userId)
      if (!user || user.status !== 'active') {
        return res.status(403).json({ ok: false, error: '账号已被禁用' })
      }

      // Issue WattClaw internal token (same flow as password login)
      const { token, expiresAt } = createAuthToken(user.id, req.headers['user-agent'], req.ip)
      res.json({ ok: true, token, user, expiresAt })
    } catch (e) {
      console.error('[FeishuAuth] Callback error:', e.message)
      res.status(500).json({ ok: false, error: '飞书登录失败' })
    }
  })
}
```

- [ ] **Step 2: 在 `server/index.js` 注册路由**

在 `server/index.js` 第 84 行（`import { createFeishuProxyRoutes }` 之后）追加 import：

```javascript
import { createFeishuAuthRoutes } from './handlers/feishu-auth.js'
```

在 `server/index.js` 的路由注册区（`createFeishuProxyRoutes(app)` 之后，约第 613 行）追加：

```javascript
createFeishuAuthRoutes(app)
```

- [ ] **Step 3: 验证语法无误**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c server/handlers/feishu-auth.js && node -c server/index.js && echo "SYNTAX OK"`
Expected: `SYNTAX OK`

- [ ] **Step 4: 启动服务验证路由注册**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && timeout 3 node server/index.js 2>&1 | head -20 || true`
Expected: 服务启动无报错（端口绑定信息或 "Listening" 日志）

- [ ] **Step 5: Commit**

```bash
git add server/handlers/feishu-auth.js server/index.js
git commit -m "feat(auth): add feishu OAuth routes — config, authorize, callback"
```

---

### Task 4: 前端类型定义 + i18n 文案

**Files:**
- Create: `src/api/types/feishu-auth.ts`
- Modify: `src/api/types/index.ts` (追加 export)
- Modify: `src/i18n/messages/zh-CN.ts:217` (在 `community: ''` 之前追加)

- [ ] **Step 1: 创建 `src/api/types/feishu-auth.ts`**

```typescript
export interface FeishuAuthConfig {
  enabled: boolean
}

export interface FeishuAuthorizeResponse {
  url: string
}

export interface FeishuCallbackRequest {
  code: string
  state: string
}

export interface FeishuCallbackResponse {
  ok: boolean
  token?: string
  user?: import('./index').User
  expiresAt?: number
  error?: string
}
```

- [ ] **Step 2: 在 `src/api/types/index.ts` 末尾追加 barrel export**

在文件最后一行 export 之后追加：

```typescript
export type { FeishuAuthConfig, FeishuAuthorizeResponse, FeishuCallbackRequest, FeishuCallbackResponse } from './feishu-auth'
```

- [ ] **Step 3: 在 `src/i18n/messages/zh-CN.ts` 的 login 节点内追加飞书文案**

在第 206 行 `invalidCredentials` 之后、第 207 行 `register` 之前，追加：

```typescript
      feishuLogin: '飞书登录',
      feishuLoggingIn: '飞书登录中...',
      feishuNotBound: '该飞书账号未绑定系统用户，请联系管理员',
      feishuAuthFailed: '飞书授权失败',
      feishuStateExpired: '授权已过期，请重新登录',
      feishuServiceUnavailable: '飞书服务暂不可用，请稍后重试',
      feishuCallbackError: '飞书登录处理失败',
      backToLogin: '返回登录',
      orDivider: '或',
      retry: '重试',
```

注意：`retry` 键名与第 198 行的 `retry` 重复。此处使用 `feishuRetry` 替代：

```typescript
      feishuRetry: '重试',
```

- [ ] **Step 4: 验证类型检查**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无新增类型错误（可能有预存的无关错误）

- [ ] **Step 5: Commit**

```bash
git add src/api/types/feishu-auth.ts src/api/types/index.ts src/i18n/messages/zh-CN.ts
git commit -m "feat(auth): add feishu auth types and i18n keys"
```

---

### Task 5: Auth Store — 新增 `feishuLogin` action

**Files:**
- Modify: `src/stores/auth.ts`

- [ ] **Step 1: 在 `src/stores/auth.ts` 的 return 对象前追加 `feishuLogin` action**

在 `changePassword` 函数之后、`getToken` 函数之前追加：

```typescript
  async function feishuLogin(code: string, state: string): Promise<boolean> {
    loading.value = true
    error.value = null

    try {
      const response = await fetch(apiPath('/api/auth/feishu/callback'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, state }),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        if (data.token) setToken(data.token)
        if (data.user) setCurrentUser(data.user)
        loading.value = false
        return true
      } else {
        error.value = data.error || '飞书登录失败'
        loading.value = false
        return false
      }
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Network error'
      loading.value = false
      return false
    }
  }
```

- [ ] **Step 2: 在 return 对象中导出 `feishuLogin`**

在 `changePassword,` 之后追加 `feishuLogin,`。

- [ ] **Step 3: 验证类型检查**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无新增类型错误

- [ ] **Step 4: Commit**

```bash
git add src/stores/auth.ts
git commit -m "feat(auth): add feishuLogin action to auth store"
```

---

### Task 6: 回调落地页 — `FeishuCallback.vue`

**Files:**
- Create: `src/views/auth/FeishuCallback.vue`
- Modify: `src/router/routes.ts`

- [ ] **Step 1: 创建 `src/views/auth/FeishuCallback.vue`**

```vue
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { NButton, NSpin } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const { t } = useI18n()

const loading = ref(true)
const error = ref('')

onMounted(async () => {
  const code = route.query.code as string
  const state = route.query.state as string

  if (!code || !state) {
    error.value = t('pages.login.feishuCallbackError')
    loading.value = false
    return
  }

  const success = await authStore.feishuLogin(code, state)

  if (success) {
    const redirect = (route.query.redirect as string) || '/'
    router.push(redirect)
  } else {
    const err = authStore.error || ''
    if (err.includes('未绑定')) {
      error.value = t('pages.login.feishuNotBound')
    } else if (err.includes('过期') || err.includes('state')) {
      error.value = t('pages.login.feishuStateExpired')
    } else if (err.includes('不可用')) {
      error.value = t('pages.login.feishuServiceUnavailable')
    } else {
      error.value = t('pages.login.feishuAuthFailed')
    }
    loading.value = false
  }
})

function goBack() {
  router.push({ name: 'Login' })
}

function retry() {
  window.location.reload()
}
</script>

<template>
  <div class="callback-container">
    <div class="callback-card">
      <div v-if="loading" class="callback-loading">
        <NSpin size="large" />
        <p class="loading-text">{{ t('pages.login.feishuLoggingIn') }}</p>
      </div>
      <template v-else>
        <div class="callback-error">
          <span class="material-symbols-outlined error-icon">error</span>
          <p class="error-text">{{ error }}</p>
          <div class="callback-actions">
            <NButton @click="goBack">{{ t('pages.login.backToLogin') }}</NButton>
            <NButton v-if="error.includes(t('pages.login.feishuServiceUnavailable'))" type="primary" @click="retry">
              {{ t('pages.login.feishuRetry') }}
            </NButton>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.callback-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #020c1b;
}

.callback-card {
  background: rgba(4, 20, 45, 0.65);
  backdrop-filter: blur(24px);
  border: 1px solid rgba(0, 212, 170, 0.15);
  border-radius: 24px;
  padding: 48px;
  text-align: center;
  min-width: 360px;
}

.callback-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.loading-text {
  color: rgba(255, 255, 255, 0.6);
  font-size: 14px;
}

.callback-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.error-icon {
  font-size: 48px;
  color: #e88080;
}

.error-text {
  color: rgba(255, 255, 255, 0.8);
  font-size: 14px;
  margin: 0;
  line-height: 1.6;
}

.callback-actions {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.material-symbols-outlined {
  vertical-align: middle;
}
</style>
```

- [ ] **Step 2: 在 `src/router/routes.ts` 中注册路由**

在 Login 路由（第 12 行 `}` 之后）追加：

```typescript
  {
    path: '/auth/feishu/callback',
    name: 'FeishuCallback',
    component: () => import('@/views/auth/FeishuCallback.vue'),
    meta: { titleKey: 'routes.login', public: true },
  },
```

- [ ] **Step 3: 验证类型检查**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无新增类型错误

- [ ] **Step 4: Commit**

```bash
git add src/views/auth/FeishuCallback.vue src/router/routes.ts
git commit -m "feat(auth): add FeishuCallback page and route"
```

---

### Task 7: Login.vue — 新增飞书登录按钮

**Files:**
- Modify: `src/views/Login.vue`

- [ ] **Step 1: 在 `<script setup>` 中添加飞书相关状态和方法**

在 `import` 块之后、`const loading = ref(true)` 之前追加：

```typescript
import type { FeishuAuthConfig, FeishuAuthorizeResponse } from '@/api/types/feishu-auth'

const feishuConfig = ref<FeishuAuthConfig>({ enabled: false })

onMounted(async () => {
  checking.value = false
  loading.value = false

  // Check feishu auth config
  try {
    const res = await fetch('/api/auth/feishu/config')
    if (res.ok) feishuConfig.value = await res.json()
  } catch {}

  if (authStore.isAuthenticated) {
    const valid = await authStore.checkAuth()
    if (valid) {
      const redirect = (route.query.redirect as string) || '/'
      router.push(redirect)
    }
  }
})

async function handleFeishuLogin() {
  loading.value = true
  error.value = ''
  try {
    const res = await fetch('/api/auth/feishu/authorize')
    const data: FeishuAuthorizeResponse = await res.json()
    if (data.url) {
      window.location.href = data.url
    } else {
      error.value = '飞书登录未配置'
      loading.value = false
    }
  } catch {
    error.value = '网络错误'
    loading.value = false
  }
}
```

**注意**：原有的 `onMounted` 块需要删除（上面已合并了原有逻辑）。删除以下代码：

```typescript
onMounted(async () => {
  checking.value = false
  loading.value = false

  if (authStore.isAuthenticated) {
    const valid = await authStore.checkAuth()
    if (valid) {
      const redirect = (route.query.redirect as string) || '/'
      router.push(redirect)
    }
  }
})
```

- [ ] **Step 2: 在 `<template>` 中添加飞书登录按钮**

在登录按钮（`</NButton>` 约 174 行）之后、`</NForm>` 之前追加：

```html
            <!-- Feishu Login -->
            <div v-if="feishuConfig.enabled" class="feishu-section">
              <div class="divider">
                <span class="divider-text">{{ t('pages.login.orDivider') }}</span>
              </div>
              <NButton
                block
                size="large"
                class="feishu-btn"
                @click="handleFeishuLogin"
                :loading="loading"
              >
                <template #icon>
                  <span class="material-symbols-outlined">login</span>
                </template>
                {{ t('pages.login.feishuLogin') }}
              </NButton>
            </div>
```

- [ ] **Step 3: 在 `<style scoped>` 中追加飞书按钮样式**

在现有样式末尾（`</style>` 之前）追加：

```css
.feishu-section {
  margin-top: 8px;
}

.divider {
  display: flex;
  align-items: center;
  margin: 12px 0;
}

.divider::before,
.divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: rgba(255, 255, 255, 0.1);
}

.divider-text {
  padding: 0 16px;
  color: rgba(255, 255, 255, 0.35);
  font-size: 13px;
}

.feishu-btn {
  height: 50px;
  border-radius: 12px;
  font-weight: 600;
  font-size: 16px;
  background: rgba(255, 255, 255, 0.06) !important;
  border: 1px solid rgba(255, 255, 255, 0.12) !important;
  color: rgba(255, 255, 255, 0.85) !important;
  transition: all 0.2s;
}

.feishu-btn:hover {
  background: rgba(255, 255, 255, 0.1) !important;
  border-color: rgba(0, 212, 170, 0.3) !important;
}
```

- [ ] **Step 4: 验证类型检查**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && npx vue-tsc --noEmit 2>&1 | head -20`
Expected: 无新增类型错误

- [ ] **Step 5: Commit**

```bash
git add src/views/Login.vue
git commit -m "feat(auth): add Feishu login button to Login page"
```

---

### Task 8: 后台绑定脚本 — `bind-feishu.js`

**Files:**
- Create: `scripts/bind-feishu.js`

- [ ] **Step 1: 创建 `scripts/bind-feishu.js`**

```javascript
#!/usr/bin/env node
// Feishu OAuth binding management script
// Usage:
//   node scripts/bind-feishu.js --bind --user-id <UUID> --union-id <feishu_union_id>
//   node scripts/bind-feishu.js --unbind --union-id <feishu_union_id>
//   node scripts/bind-feishu.js --rebind --user-id <UUID> --union-id <new_union_id>
//   node scripts/bind-feishu.js --list
//   node scripts/bind-feishu.js --file bindings.csv

import Database from 'better-sqlite3'
import { randomUUID } from 'crypto'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { readFileSync } from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const dbPath = join(__dirname, '../data/wizard.db')
const db = new Database(dbPath)

const args = process.argv.slice(2)

function parseArgs() {
  const result = {}
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      result[args[i].slice(2)] = args[i + 1]
      i++
    }
  }
  return result
}

function bind(userId, unionId) {
  const user = db.prepare('SELECT id, username FROM users WHERE id = ?').get(userId)
  if (!user) {
    console.error(`❌ User not found: ${userId}`)
    process.exit(1)
  }
  const existing = db.prepare('SELECT id FROM user_oauth_bindings WHERE provider = ? AND union_id = ?').get('feishu', unionId)
  if (existing) {
    console.error(`❌ union_id ${unionId} already bound to another user`)
    process.exit(1)
  }
  db.prepare(`
    INSERT INTO user_oauth_bindings (id, user_id, provider, union_id, created_at, updated_at)
    VALUES (?, ?, 'feishu', ?, ?, ?)
  `).run(randomUUID(), userId, unionId, Date.now(), Date.now())
  console.log(`✅ Bound feishu:${unionId} → ${user.username} (${userId})`)
}

function unbind(unionId) {
  const result = db.prepare('DELETE FROM user_oauth_bindings WHERE provider = ? AND union_id = ?').run('feishu', unionId)
  if (result.changes === 0) {
    console.error(`❌ No binding found for union_id: ${unionId}`)
    process.exit(1)
  }
  console.log(`✅ Unbound feishu:${unionId}`)
}

function rebind(userId, unionId) {
  const user = db.prepare('SELECT id, username FROM users WHERE id = ?').get(userId)
  if (!user) {
    console.error(`❌ User not found: ${userId}`)
    process.exit(1)
  }
  db.prepare('DELETE FROM user_oauth_bindings WHERE provider = ? AND user_id = ?').run('feishu', userId)
  db.prepare(`
    INSERT INTO user_oauth_bindings (id, user_id, provider, union_id, created_at, updated_at)
    VALUES (?, ?, 'feishu', ?, ?, ?)
  `).run(randomUUID(), userId, unionId, Date.now(), Date.now())
  console.log(`✅ Rebound ${user.username} (${userId}) → feishu:${unionId}`)
}

function list() {
  const rows = db.prepare(`
    SELECT b.union_id, b.open_id, b.display_name, u.username, b.created_at
    FROM user_oauth_bindings b
    JOIN users u ON u.id = b.user_id
    WHERE b.provider = 'feishu'
    ORDER BY b.created_at DESC
  `).all()
  if (rows.length === 0) {
    console.log('No bindings found.')
    return
  }
  console.log(`${'union_id'.padEnd(40)} ${'username'.padEnd(20)} ${'display_name'.padEnd(15)} created_at`)
  console.log('-'.repeat(100))
  for (const r of rows) {
    console.log(`${r.union_id.padEnd(40)} ${r.username.padEnd(20)} ${(r.display_name || '-').padEnd(15)} ${new Date(r.created_at).toISOString()}`)
  }
}

function batchFile(filePath) {
  const content = readFileSync(filePath, 'utf-8')
  const lines = content.trim().split('\n')
  let success = 0, failed = 0
  for (const line of lines) {
    const [userId, unionId] = line.split(',').map(s => s.trim())
    if (!userId || !unionId) { failed++; continue }
    try {
      bind(userId, unionId)
      success++
    } catch {
      console.error(`  Failed: ${userId} ← ${unionId}`)
      failed++
    }
  }
  console.log(`\nBatch done: ${success} success, ${failed} failed`)
}

const opts = parseArgs()
if (opts.bind && opts['user-id'] && opts['union-id']) {
  bind(opts['user-id'], opts['union-id'])
} else if (opts.unbind && opts['union-id']) {
  unbind(opts['union-id'])
} else if (opts.rebind && opts['user-id'] && opts['union-id']) {
  rebind(opts['user-id'], opts['union-id'])
} else if (opts.list !== undefined) {
  list()
} else if (opts.file) {
  batchFile(opts.file)
} else {
  console.log('Usage:')
  console.log('  node scripts/bind-feishu.js --bind --user-id <UUID> --union-id <union_id>')
  console.log('  node scripts/bind-feishu.js --unbind --union-id <union_id>')
  console.log('  node scripts/bind-feishu.js --rebind --user-id <UUID> --union-id <new_union_id>')
  console.log('  node scripts/bind-feishu.js --list')
  console.log('  node scripts/bind-feishu.js --file bindings.csv')
  process.exit(1)
}

db.close()
```

- [ ] **Step 2: 验证语法**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && node -c scripts/bind-feishu.js && echo "SYNTAX OK"`
Expected: `SYNTAX OK`

- [ ] **Step 3: Commit**

```bash
git add scripts/bind-feishu.js
git commit -m "feat(auth): add feishu binding management script"
```

---

### Task 9: 环境变量 + 端到端验证

**Files:**
- Modify: `.env` (本地配置，gitignored)

- [ ] **Step 1: 在 `.env` 中添加飞书配置**

追加以下行（值留空，运行前填入真实值）：

```bash
FEISHU_APP_ID=
FEISHU_APP_SECRET=
FEISHU_REDIRECT_URI=
```

- [ ] **Step 2: 启动全栈服务验证**

Run: `cd /Users/renming/Desktop/wattman/openclaw/wattclaw && ./start.sh`

手动验证：
1. 浏览器打开 `http://localhost:3000/login`
2. 未配置 FEISHU_APP_ID 时 → 不显示飞书按钮 ✅
3. 配置 FEISHU_APP_ID 后重启 → 显示飞书按钮 ✅
4. 点击飞书按钮 → 跳转到飞书授权页（如果配置了正确的凭据）
5. 飞书回调 → FeishuCallback.vue 加载 → 自动处理登录

- [ ] **Step 3: 最终 commit**

```bash
git add -A
git commit -m "feat(auth): feishu OAuth login complete — e2e verified"
```

---

## 自检清单

- [x] **Spec 覆盖**：每个 API 端点、数据表、前端页面、错误场景均有对应 Task
- [x] **占位符扫描**：无 TBD/TODO/实现细节待定
- [x] **类型一致性**：`FeishuAuthConfig.enabled`（boolean）、`FeishuAuthorizeResponse.url`（string）、`FeishuCallbackResponse.ok`（boolean）在类型定义和实际使用中一致
- [x] **冻结确认**：Task 1-8 均未修改 `users` 表、`auth_tokens` 表、`user-manager.js`、`core/auth.js`
