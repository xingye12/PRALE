# Usage Cache Read/Write Separation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make dashboard usage APIs read only from SQLite, and move Gateway usage writes into bounded startup/session sync paths keyed by `user_id + session_key`.

**Architecture:** SQLite `user_sessions` remains the usage display source for this fix. Gateway usage is synchronized only by explicit background jobs: startup batch sync after session ownership sync, and debounced per-session sync after chat/session completion. All writes must resolve one existing local owner before updating; unmatched or conflicting Gateway sessions are skipped and reported.

**Tech Stack:** Node.js ESM, Express, better-sqlite3, Vitest, Vue 3/TypeScript frontend compatibility via existing `/api/sessions/usage` response shape.

---

## Source Spec

Design document: `docs/superpowers/specs/2026-06-11-usage-cache-redesign.md`

## File Structure

### Modify: `server/core/session-usage-cache.js`

Responsibility after this change:

- Own all SQLite usage read/write primitives.
- Normalize Gateway usage session rows.
- Update usage only through `user_id + session_key`.
- Batch sync only locally owned, uniquely matched sessions.
- Produce `UsageSyncReport` for observability.
- Provide admin `userUsage` aggregation from SQLite.

New/changed exports:

```js
export function updateSessionUsageForUser(userId, sessionKey, usageData) {}
export function batchUpdateMatchedGatewayUsage(gatewayResult) {}
export function getAdminUserUsageAggregates() {}
export function hasUsageSyncRows(userId = null) {}
```

Keep these compatibility exports, but route them through safe behavior:

```js
export function updateSessionUsage(sessionKey, usageData) {}
export function updateSessionTokenUsage(sessionKey, usageData) {}
export function batchUpdateFromGatewayUsage(gatewayResult, userId = null) {}
export function getUserAggregates(userId = null) {}
```

### Create: `server/core/usage-sync.js`

Responsibility:

- Own Gateway usage sync orchestration.
- Keep Gateway calls out of read APIs.
- Provide startup sync and debounced single-session sync.
- Avoid per-session RPC storms with in-memory debounce/singleflight maps.

Exports:

```js
export async function syncUsageFromGatewayOnStartup() {}
export function scheduleSessionUsageSync(sessionKey, options = {}) {}
export async function syncSessionUsageNow(sessionKey) {}
```

### Modify: `server/index.js`

Responsibility in this plan:

- Change `_handleUsageProxy()` to pure SQLite read.
- Preserve frontend response compatibility for `userUsage` at top-level route response.
- Start usage sync only after existing ownership/session startup sync has completed.
- Replace direct token usage writes in push token path with safe per-session sync scheduling.

### Test: `server/core/session-usage-cache.test.js`

Responsibility:

- Cover ownership-safe writes and skipped-conflict behavior.
- Cover admin user usage aggregation.
- Cover `hasUsageSyncRows()`.

### Test: `server/core/usage-sync.test.js`

Responsibility:

- Cover debounce/singleflight scheduler behavior with mocked Gateway sync function.
- Cover startup sync report behavior through dependency injection or exported test hooks.

### Optional Modify: `package.json`

Only if desired after tests are added: append the new Vitest files to `test:server`. This is not required because exact commands below call the new test files directly.

---

## Task 1: Add ownership-safe usage cache tests

**Files:**
- Create: `server/core/session-usage-cache.test.js`
- Modify later: `server/core/session-usage-cache.js`

- [ ] **Step 1: Write failing tests for safe usage writes and admin aggregation**

Create `server/core/session-usage-cache.test.js` with this content:

```js
import { beforeEach, describe, expect, it, vi } from 'vitest'

const runMock = vi.fn()
const getMock = vi.fn()
const allMock = vi.fn()
const prepareMock = vi.fn(() => ({ run: runMock, get: getMock, all: allMock }))

vi.mock('../database.js', () => ({
  default: {
    prepare: prepareMock,
  },
}))

const usageCache = await import('./session-usage-cache.js')

function resetDbMocks() {
  prepareMock.mockClear()
  runMock.mockReset()
  getMock.mockReset()
  allMock.mockReset()
}

function findSql(fragment) {
  const call = prepareMock.mock.calls.find(([sql]) => String(sql).includes(fragment))
  return call ? String(call[0]) : ''
}

describe('session usage cache ownership-safe writes', () => {
  beforeEach(() => {
    resetDbMocks()
  })

  it('updates a session only through user_id + session_key', () => {
    runMock.mockReturnValue({ changes: 1 })

    const result = usageCache.updateSessionUsageForUser('user-a', 'session-a', {
      model: 'anthropic/claude-sonnet-4-6',
      modelProvider: null,
      tokenInput: 10,
      tokenOutput: 20,
      tokenTotal: 30,
      costTotal: 0.12,
      toolUsage: [],
    })

    expect(result.userId).toBe('user-a')
    expect(result.sessionKey).toBe('session-a')

    const sql = findSql('UPDATE user_sessions')
    expect(sql).toContain('WHERE user_id = ? AND session_key = ?')
    expect(runMock).toHaveBeenCalled()
    const args = runMock.mock.calls[0]
    expect(args.at(-2)).toBe('user-a')
    expect(args.at(-1)).toBe('session-a')
  })

  it('throws when updateSessionUsage is called without a userId', () => {
    expect(() => usageCache.updateSessionUsage('session-a', { tokenTotal: 1 })).toThrow(
      'updateSessionUsage requires usageData.userId'
    )
    expect(runMock).not.toHaveBeenCalled()
  })

  it('batch sync skips unmatched and conflicting gateway sessions', () => {
    allMock.mockImplementation((...args) => {
      const sessionKey = args[0]
      if (sessionKey === 'owned') return [{ user_id: 'user-a', session_key: 'owned' }]
      if (sessionKey === 'conflict') {
        return [
          { user_id: 'user-a', session_key: 'conflict' },
          { user_id: 'user-b', session_key: 'conflict' },
        ]
      }
      return []
    })
    runMock.mockReturnValue({ changes: 1 })

    const report = usageCache.batchUpdateMatchedGatewayUsage({
      sessions: [
        { key: 'owned', usage: { input: 1, output: 2, totalTokens: 3 } },
        { key: 'missing', usage: { input: 4, output: 5, totalTokens: 9 } },
        { key: 'conflict', usage: { input: 6, output: 7, totalTokens: 13 } },
      ],
    })

    expect(report.scanned).toBe(3)
    expect(report.updated).toBe(1)
    expect(report.skippedUnmatched).toBe(1)
    expect(report.skippedConflict).toBe(1)
    expect(report.failed).toBe(0)
  })
})

describe('session usage cache SQLite read helpers', () => {
  beforeEach(() => {
    resetDbMocks()
  })

  it('returns admin user usage rows from SQLite', () => {
    allMock.mockReturnValue([
      {
        userId: 'user-a',
        username: 'alice',
        displayName: 'Alice',
        sessionCount: 2,
        totalTokens: 30,
        totalCost: 0.4,
        inputTokens: 10,
        outputTokens: 20,
      },
    ])

    const rows = usageCache.getAdminUserUsageAggregates()

    expect(rows).toEqual([
      {
        userId: 'user-a',
        username: 'alice',
        displayName: 'Alice',
        sessionCount: 2,
        totalTokens: 30,
        totalCost: 0.4,
        inputTokens: 10,
        outputTokens: 20,
      },
    ])
    const sql = findSql('LEFT JOIN user_sessions')
    expect(sql).toContain("WHERE u.status = 'active'")
  })

  it('checks whether any usage rows have synced for admin or a user', () => {
    getMock.mockReturnValueOnce({ count: 1 }).mockReturnValueOnce({ count: 0 })

    expect(usageCache.hasUsageSyncRows()).toBe(true)
    expect(usageCache.hasUsageSyncRows('user-b')).toBe(false)
  })
})
```

- [ ] **Step 2: Run the failing cache tests**

Run:

```bash
npx vitest run server/core/session-usage-cache.test.js --exclude '**/.claude/**'
```

Expected: FAIL with missing exports such as `updateSessionUsageForUser`, `batchUpdateMatchedGatewayUsage`, `getAdminUserUsageAggregates`, or `hasUsageSyncRows`.

- [ ] **Step 3: Commit the failing tests**

```bash
git add server/core/session-usage-cache.test.js
git commit -m "test: cover ownership-safe usage cache writes"
```

---

## Task 2: Implement ownership-safe usage cache primitives

**Files:**
- Modify: `server/core/session-usage-cache.js`
- Test: `server/core/session-usage-cache.test.js`

- [ ] **Step 1: Replace unsafe write functions with owner-scoped writes**

In `server/core/session-usage-cache.js`, keep `_normalizeModelFields()` and replace the current `updateSessionUsage()` / `_persistToDatabase()` write block with this implementation:

```js
function _buildUsageEntry(userId, sessionKey, usageData) {
  const { model, modelProvider } = _normalizeModelFields(usageData.model, usageData.modelProvider)
  return {
    sessionKey,
    userId,
    agentId: usageData.agentId || null,
    model,
    modelProvider,
    tokenInput: Math.max(0, Math.floor(usageData.tokenInput || 0)),
    tokenOutput: Math.max(0, Math.floor(usageData.tokenOutput || 0)),
    tokenCacheRead: Math.max(0, Math.floor(usageData.tokenCacheRead || 0)),
    tokenCacheWrite: Math.max(0, Math.floor(usageData.tokenCacheWrite || 0)),
    tokenTotal: Math.max(0, Math.floor(usageData.tokenTotal || 0)),
    costTotal: Number(usageData.costTotal || 0),
    msgTotal: Math.max(0, Math.floor(usageData.msgTotal || 0)),
    msgUser: Math.max(0, Math.floor(usageData.msgUser || 0)),
    msgAssistant: Math.max(0, Math.floor(usageData.msgAssistant || 0)),
    msgToolCalls: Math.max(0, Math.floor(usageData.msgToolCalls || 0)),
    msgToolResults: Math.max(0, Math.floor(usageData.msgToolResults || 0)),
    msgErrors: Math.max(0, Math.floor(usageData.msgErrors || 0)),
    toolUsage: Array.isArray(usageData.toolUsage) ? usageData.toolUsage : [],
    usageSyncedAt: Date.now(),
  }
}

export function updateSessionUsageForUser(userId, sessionKey, usageData) {
  if (!userId) throw new Error('updateSessionUsageForUser requires userId')
  if (!sessionKey) throw new Error('updateSessionUsageForUser requires sessionKey')

  const entry = _buildUsageEntry(userId, sessionKey, usageData || {})
  const result = db.prepare(`
    UPDATE user_sessions
    SET agent_id = COALESCE(?, agent_id),
        model = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE model END,
        model_provider = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE model_provider END,
        token_input = ?,
        token_output = ?,
        token_cache_read = ?,
        token_cache_write = ?,
        token_total = ?,
        cost_total = ?,
        msg_total = ?,
        msg_user = ?,
        msg_assistant = ?,
        msg_tool_calls = ?,
        msg_tool_results = ?,
        msg_errors = ?,
        tool_usage_json = ?,
        usage_synced_at = ?,
        updated_at = ?
    WHERE user_id = ? AND session_key = ?
  `).run(
    entry.agentId,
    entry.model, entry.model, entry.model,
    entry.modelProvider, entry.modelProvider, entry.modelProvider,
    entry.tokenInput,
    entry.tokenOutput,
    entry.tokenCacheRead,
    entry.tokenCacheWrite,
    entry.tokenTotal,
    entry.costTotal,
    entry.msgTotal,
    entry.msgUser,
    entry.msgAssistant,
    entry.msgToolCalls,
    entry.msgToolResults,
    entry.msgErrors,
    JSON.stringify(entry.toolUsage),
    entry.usageSyncedAt,
    Date.now(),
    userId,
    sessionKey
  )

  if (result.changes === 0) {
    console.warn(`[UsageCache] UPDATE 0 rows: ${sessionKey} for user ${userId} — not tracked yet`)
  }

  return entry
}

export function updateSessionUsage(sessionKey, usageData) {
  if (!usageData?.userId) {
    throw new Error('updateSessionUsage requires usageData.userId')
  }
  return updateSessionUsageForUser(usageData.userId, sessionKey, usageData)
}
```

- [ ] **Step 2: Add Gateway usage normalization and matched batch sync**

In the same file, replace `batchUpdateFromGatewayUsage()` with these helpers and exports:

```js
function _emptyUsageSyncReport() {
  return {
    scanned: 0,
    updated: 0,
    skippedUnmatched: 0,
    skippedConflict: 0,
    failed: 0,
    durationMs: 0,
  }
}

function _gatewaySessionKey(session) {
  return session?.key || session?.sessionKey || session?.id || ''
}

function _gatewayUsageToUsageData(session) {
  const usage = session?.usage || {}
  const msgCounts = usage.messageCounts || {}
  const toolUsage = usage.toolUsage || {}
  const { model, modelProvider } = _normalizeModelFields(
    session?.model || null,
    session?.modelProvider || session?.provider || null
  )

  return {
    agentId: session?.agentId || session?.agent || null,
    model,
    modelProvider,
    tokenInput: usage.input ?? usage.inputTokens ?? usage.promptTokens ?? usage.input_tokens ?? 0,
    tokenOutput: usage.output ?? usage.outputTokens ?? usage.completionTokens ?? usage.output_tokens ?? 0,
    tokenCacheRead: usage.cacheRead ?? 0,
    tokenCacheWrite: usage.cacheWrite ?? 0,
    tokenTotal: usage.totalTokens ?? usage.tokens ?? usage.total ?? 0,
    costTotal: usage.totalCost ?? usage.cost ?? 0,
    msgTotal: msgCounts.total ?? 0,
    msgUser: msgCounts.user ?? 0,
    msgAssistant: msgCounts.assistant ?? 0,
    msgToolCalls: msgCounts.toolCalls ?? 0,
    msgToolResults: msgCounts.toolResults ?? 0,
    msgErrors: msgCounts.errors ?? 0,
    toolUsage: Array.isArray(toolUsage.tools) ? toolUsage.tools : [],
  }
}

function _findSessionOwners(sessionKey) {
  return db.prepare(`
    SELECT user_id, session_key
    FROM user_sessions
    WHERE session_key = ?
  `).all(sessionKey)
}

export function batchUpdateMatchedGatewayUsage(gatewayResult) {
  const startedAt = Date.now()
  const report = _emptyUsageSyncReport()
  const sessions = Array.isArray(gatewayResult?.sessions) ? gatewayResult.sessions : []

  for (const session of sessions) {
    report.scanned++
    const sessionKey = _gatewaySessionKey(session)
    if (!sessionKey) {
      report.skippedUnmatched++
      continue
    }

    const owners = _findSessionOwners(sessionKey)
    if (owners.length === 0) {
      report.skippedUnmatched++
      continue
    }
    if (owners.length > 1) {
      report.skippedConflict++
      console.warn(`[UsageCache] skipped conflicting session_key: ${sessionKey}`)
      continue
    }

    try {
      const owner = owners[0]
      updateSessionUsageForUser(owner.user_id, sessionKey, _gatewayUsageToUsageData(session))
      report.updated++
    } catch (error) {
      report.failed++
      console.warn(`[UsageCache] failed to sync ${sessionKey}:`, error?.message || error)
    }
  }

  report.durationMs = Date.now() - startedAt
  console.log('[UsageCache] batch sync report:', report)
  return report
}

export function batchUpdateFromGatewayUsage(gatewayResult) {
  return batchUpdateMatchedGatewayUsage(gatewayResult)
}
```

- [ ] **Step 3: Add admin aggregation and sync presence helpers**

In `server/core/session-usage-cache.js`, add these exports near `getUserAggregates()`:

```js
export function getAdminUserUsageAggregates() {
  const rows = db.prepare(`
    SELECT
      u.id AS userId,
      u.username AS username,
      COALESCE(u.display_name, u.username) AS displayName,
      COUNT(us.id) AS sessionCount,
      COALESCE(SUM(us.token_total), 0) AS totalTokens,
      COALESCE(SUM(us.cost_total), 0) AS totalCost,
      COALESCE(SUM(us.token_input), 0) AS inputTokens,
      COALESCE(SUM(us.token_output), 0) AS outputTokens
    FROM users u
    LEFT JOIN user_sessions us ON us.user_id = u.id
    WHERE u.status = 'active'
    GROUP BY u.id, u.username, u.display_name
    ORDER BY totalTokens DESC
  `).all()

  return rows.map(row => ({
    userId: row.userId,
    username: row.username,
    displayName: row.displayName || row.username,
    sessionCount: Number(row.sessionCount || 0),
    totalTokens: Number(row.totalTokens || 0),
    totalCost: Number(row.totalCost || 0),
    inputTokens: Number(row.inputTokens || 0),
    outputTokens: Number(row.outputTokens || 0),
  }))
}

export function hasUsageSyncRows(userId = null) {
  const row = userId
    ? db.prepare(`
        SELECT COUNT(*) AS count
        FROM user_sessions
        WHERE user_id = ? AND usage_synced_at IS NOT NULL
      `).get(userId)
    : db.prepare(`
        SELECT COUNT(*) AS count
        FROM user_sessions
        WHERE usage_synced_at IS NOT NULL
      `).get()
  return Number(row?.count || 0) > 0
}
```

- [ ] **Step 4: Run cache tests and verify pass**

Run:

```bash
npx vitest run server/core/session-usage-cache.test.js --exclude '**/.claude/**'
```

Expected: PASS.

- [ ] **Step 5: Run existing server tests**

Run:

```bash
npm run test:server
```

Expected: PASS. If it fails because an existing caller depended on unsafe `updateSessionUsage(sessionKey, usageData)` without `userId`, update that caller to `updateSessionUsageForUser(userId, sessionKey, usageData)` or to the scheduler from Task 4. Do not reintroduce `WHERE session_key = ?` writes.

- [ ] **Step 6: Commit cache primitives**

```bash
git add server/core/session-usage-cache.js server/core/session-usage-cache.test.js
git commit -m "fix: scope usage cache writes by session owner"
```

---

## Task 3: Make `/api/sessions/usage` read-only

**Files:**
- Modify: `server/index.js`
- Modify: `server/core/session-usage-cache.js` only if import names need adjustment

- [ ] **Step 1: Update usage imports in `server/index.js`**

Find the import from `./core/session-usage-cache.js` and ensure it imports these names:

```js
import {
  getUserAggregates,
  getAdminUserUsageAggregates,
  hasUsageSyncRows,
} from './core/session-usage-cache.js'
```

If `server/index.js` still needs `updateSessionTokenUsage`, `batchUpdateFromGatewayUsage`, or `mergeGatewayWithSqlite` for unrelated code during this task, leave those imports in place until Task 4 replaces them. The important rule for this task is that `_handleUsageProxy()` must not call Gateway.

- [ ] **Step 2: Replace `_handleUsageProxy()` with pure SQLite read logic**

In `server/index.js`, replace the current `_handleUsageProxy(params, userId, isAdmin)` implementation with:

```js
function _shouldIncludeUserUsage(params) {
  const include = String(params?.include || '')
  return include.split(',').map(s => s.trim()).includes('userUsage')
}

async function _handleUsageProxy(params, userId, isAdmin) {
  const scopedUserId = isAdmin ? null : userId
  const result = getUserAggregates(scopedUserId)

  return {
    result,
    userUsage: isAdmin && _shouldIncludeUserUsage(params)
      ? getAdminUserUsageAggregates()
      : null,
    shouldEnqueueSync: !hasUsageSyncRows(scopedUserId),
  }
}
```

This function intentionally returns metadata for the route handler. It does not call Gateway and does not write SQLite.

- [ ] **Step 3: Update usage route responses to preserve frontend compatibility**

Find both branches that currently do:

```js
const result = await _handleUsageProxy(params, userId, isAdmin)
return res.json({ ok: true, payload: result })
```

Replace each branch with:

```js
const usageResponse = await _handleUsageProxy(params, userId, isAdmin)
if (usageResponse.shouldEnqueueSync) {
  scheduleUsageSyncAfterRead().catch(err => {
    debug('usage read-triggered background sync failed:', err?.message || err)
  })
}
return res.json({
  ok: true,
  payload: usageResponse.result,
  ...(usageResponse.userUsage ? { userUsage: usageResponse.userUsage } : {}),
})
```

If `scheduleUsageSyncAfterRead()` does not exist yet, add this local temporary no-op above `_handleUsageProxy()`:

```js
async function scheduleUsageSyncAfterRead() {
  // Implemented in Task 4. Kept as a non-blocking no-op so read API stays pure now.
}
```

Task 4 will replace this no-op with `syncUsageFromGatewayOnStartup()` scheduling.

- [ ] **Step 4: Remove Gateway usage calls from `_handleUsageProxy()`**

Confirm `_handleUsageProxy()` no longer contains any of these calls:

```js
callGatewayUsage(params)
batchUpdateFromGatewayUsage(gwResult, userId)
mergeGatewayWithSqlite(gwResult, userId, isAdmin)
```

Use this command:

```bash
node -e "const fs=require('fs'); const s=fs.readFileSync('server/index.js','utf8'); const body=s.slice(s.indexOf('async function _handleUsageProxy'), s.indexOf('async function _handleUsageCostProxy')); for (const bad of ['callGatewayUsage(params)', 'batchUpdateFromGatewayUsage(gwResult, userId)', 'mergeGatewayWithSqlite(gwResult, userId, isAdmin)']) if (body.includes(bad)) throw new Error('Still present: '+bad); console.log('usage proxy is read-only')"
```

Expected:

```text
usage proxy is read-only
```

- [ ] **Step 5: Run targeted tests and build**

Run:

```bash
npx vitest run server/core/session-usage-cache.test.js --exclude '**/.claude/**'
npm run build
```

Expected: both PASS.

- [ ] **Step 6: Commit read-only usage API**

```bash
git add server/index.js server/core/session-usage-cache.js
git commit -m "fix: make usage dashboard reads SQLite-only"
```

---

## Task 4: Add Gateway usage sync orchestration

**Files:**
- Create: `server/core/usage-sync.js`
- Create: `server/core/usage-sync.test.js`
- Modify: `server/index.js`

- [ ] **Step 1: Write failing scheduler tests**

Create `server/core/usage-sync.test.js` with this content:

```js
import { beforeEach, describe, expect, it, vi } from 'vitest'

const callGatewayUsageMock = vi.fn()
const batchUpdateMatchedGatewayUsageMock = vi.fn()
const setTimeoutMock = vi.fn((fn) => {
  fn()
  return 1
})
const clearTimeoutMock = vi.fn()

vi.mock('./gateway-client.js', () => ({
  callGatewayUsage: callGatewayUsageMock,
}))

vi.mock('./session-usage-cache.js', () => ({
  batchUpdateMatchedGatewayUsage: batchUpdateMatchedGatewayUsageMock,
}))

const usageSync = await import('./usage-sync.js')

beforeEach(() => {
  callGatewayUsageMock.mockReset()
  batchUpdateMatchedGatewayUsageMock.mockReset()
  setTimeoutMock.mockClear()
  clearTimeoutMock.mockClear()
  usageSync.__resetUsageSyncForTests()
  usageSync.__setUsageSyncTimersForTests({
    setTimeoutFn: setTimeoutMock,
    clearTimeoutFn: clearTimeoutMock,
  })
})

describe('usage sync orchestration', () => {
  it('runs startup sync and returns the batch report', async () => {
    callGatewayUsageMock.mockResolvedValue({ sessions: [{ key: 's1', usage: { totalTokens: 1 } }] })
    batchUpdateMatchedGatewayUsageMock.mockReturnValue({
      scanned: 1,
      updated: 1,
      skippedUnmatched: 0,
      skippedConflict: 0,
      failed: 0,
      durationMs: 1,
    })

    const report = await usageSync.syncUsageFromGatewayOnStartup()

    expect(callGatewayUsageMock).toHaveBeenCalledWith({ limit: 1000 })
    expect(report.updated).toBe(1)
  })

  it('debounces repeated session usage sync scheduling', async () => {
    callGatewayUsageMock.mockResolvedValue({ sessions: [{ key: 's1', usage: { totalTokens: 3 } }] })
    batchUpdateMatchedGatewayUsageMock.mockReturnValue({
      scanned: 1,
      updated: 1,
      skippedUnmatched: 0,
      skippedConflict: 0,
      failed: 0,
      durationMs: 1,
    })

    usageSync.scheduleSessionUsageSync('s1', { delayMs: 100 })
    usageSync.scheduleSessionUsageSync('s1', { delayMs: 100 })

    expect(clearTimeoutMock).toHaveBeenCalledTimes(1)
    expect(setTimeoutMock).toHaveBeenCalledTimes(2)
  })

  it('does not start duplicate in-flight session syncs', async () => {
    let releaseGateway
    callGatewayUsageMock.mockReturnValue(new Promise(resolve => {
      releaseGateway = resolve
    }))

    const first = usageSync.syncSessionUsageNow('s1')
    const second = usageSync.syncSessionUsageNow('s1')

    releaseGateway({ sessions: [{ key: 's1', usage: { totalTokens: 4 } }] })
    await Promise.all([first, second])

    expect(callGatewayUsageMock).toHaveBeenCalledTimes(1)
  })
})
```

- [ ] **Step 2: Run failing scheduler tests**

Run:

```bash
npx vitest run server/core/usage-sync.test.js --exclude '**/.claude/**'
```

Expected: FAIL because `server/core/usage-sync.js` does not exist.

- [ ] **Step 3: Create `server/core/usage-sync.js`**

Create the file with this implementation:

```js
import { callGatewayUsage } from './gateway-client.js'
import { batchUpdateMatchedGatewayUsage } from './session-usage-cache.js'

const DEFAULT_USAGE_SYNC_DELAY_MS = 1000
const DEFAULT_USAGE_SYNC_LIMIT = 1000

const pendingSessionTimers = new Map()
const inFlightSessionSyncs = new Map()
let setTimeoutFn = setTimeout
let clearTimeoutFn = clearTimeout

function _emptyReport() {
  return {
    scanned: 0,
    updated: 0,
    skippedUnmatched: 0,
    skippedConflict: 0,
    failed: 0,
    durationMs: 0,
  }
}

export async function syncUsageFromGatewayOnStartup() {
  const startedAt = Date.now()
  try {
    const gatewayResult = await callGatewayUsage({ limit: DEFAULT_USAGE_SYNC_LIMIT })
    const report = batchUpdateMatchedGatewayUsage(gatewayResult)
    console.log('[UsageSync] startup report:', report)
    return report
  } catch (error) {
    const report = { ..._emptyReport(), failed: 1, durationMs: Date.now() - startedAt }
    console.warn('[UsageSync] startup failed:', error?.message || error)
    return report
  }
}

export function scheduleSessionUsageSync(sessionKey, options = {}) {
  if (!sessionKey) return null
  const delayMs = Number.isFinite(options.delayMs)
    ? Math.max(0, options.delayMs)
    : DEFAULT_USAGE_SYNC_DELAY_MS

  const pending = pendingSessionTimers.get(sessionKey)
  if (pending) clearTimeoutFn(pending)

  const timer = setTimeoutFn(() => {
    pendingSessionTimers.delete(sessionKey)
    syncSessionUsageNow(sessionKey).catch(error => {
      console.warn(`[UsageSync] session sync failed for ${sessionKey}:`, error?.message || error)
    })
  }, delayMs)

  pendingSessionTimers.set(sessionKey, timer)
  return timer
}

export async function syncSessionUsageNow(sessionKey) {
  if (!sessionKey) return _emptyReport()
  const existing = inFlightSessionSyncs.get(sessionKey)
  if (existing) return existing

  const promise = (async () => {
    const startedAt = Date.now()
    try {
      const gatewayResult = await callGatewayUsage({ key: sessionKey, limit: 1 })
      const sessions = Array.isArray(gatewayResult?.sessions)
        ? gatewayResult.sessions.filter(session => (session.key || session.sessionKey || session.id) === sessionKey)
        : []
      const report = batchUpdateMatchedGatewayUsage({ sessions })
      console.log(`[UsageSync] session report ${sessionKey}:`, report)
      return report
    } catch (error) {
      const report = { ..._emptyReport(), failed: 1, durationMs: Date.now() - startedAt }
      console.warn(`[UsageSync] session failed ${sessionKey}:`, error?.message || error)
      return report
    } finally {
      inFlightSessionSyncs.delete(sessionKey)
    }
  })()

  inFlightSessionSyncs.set(sessionKey, promise)
  return promise
}

export function __resetUsageSyncForTests() {
  for (const timer of pendingSessionTimers.values()) clearTimeoutFn(timer)
  pendingSessionTimers.clear()
  inFlightSessionSyncs.clear()
}

export function __setUsageSyncTimersForTests({ setTimeoutFn: nextSetTimeout, clearTimeoutFn: nextClearTimeout }) {
  setTimeoutFn = nextSetTimeout || setTimeout
  clearTimeoutFn = nextClearTimeout || clearTimeout
}
```

- [ ] **Step 4: Run scheduler tests and verify pass**

Run:

```bash
npx vitest run server/core/usage-sync.test.js --exclude '**/.claude/**'
```

Expected: PASS.

- [ ] **Step 5: Wire startup sync into `server/index.js` after ownership sync**

Import the startup sync function:

```js
import {
  scheduleSessionUsageSync,
  syncUsageFromGatewayOnStartup,
} from './core/usage-sync.js'
```

Find the `server.listen(envConfig.PORT, () => { ... })` block. Keep server listen non-blocking, but chain usage sync after the existing session ownership startup work. Use this pattern around the existing startup sync code:

```js
server.listen(envConfig.PORT, () => {
  console.log(`Server running on http://localhost:${envConfig.PORT}`)
  console.log(`OpenClaw Gateway: ${envConfig.OPENCLAW_WS_URL}`)
  deduplicateSharedSessions()

  Promise.resolve()
    .then(() => syncSessionsFromGateway())
    .then(() => syncUsageFromGatewayOnStartup())
    .catch(err => {
      console.error('[UsageStartupSync] Failed:', err?.message || err)
    })

  syncAgentWorkspacesFromGateway().catch(err => {
    console.error('[AgentWorkspaceSync] Failed:', err.message)
  })

  initMessageStore().then(() => {
    console.log('[MessageStore] Ready')
    return repairSessionTitleAndActivitySemantics()
  }).then((result) => {
    if (!result) return
    console.log(`[SessionRepair] titles=${result.titlesChanged}, lastMessageAt=${result.lastMessageAtChanged}, scanned=${result.sessionsScanned}`)
  }).catch(err => {
    console.error('[MessageStore] Init failed:', err.message)
  })
})
```

If the current `server.listen` block already calls `syncSessionsFromGateway()` elsewhere, do not duplicate it. Instead, attach `.then(() => syncUsageFromGatewayOnStartup())` to that existing promise chain. The invariant is: usage startup sync runs after ownership/session sync, not in parallel before it.

- [ ] **Step 6: Replace read-triggered no-op with background startup sync enqueue**

Replace the temporary `scheduleUsageSyncAfterRead()` from Task 3 with:

```js
let readTriggeredUsageSyncInFlight = null

async function scheduleUsageSyncAfterRead() {
  if (readTriggeredUsageSyncInFlight) return readTriggeredUsageSyncInFlight
  readTriggeredUsageSyncInFlight = syncUsageFromGatewayOnStartup()
    .catch(err => {
      debug('read-triggered usage sync failed:', err?.message || err)
    })
    .finally(() => {
      readTriggeredUsageSyncInFlight = null
    })
  return readTriggeredUsageSyncInFlight
}
```

This preserves the pure read response path because route handlers must call it without awaiting it.

- [ ] **Step 7: Replace direct token usage write after chat/session completion**

Find the existing `_doPushTokenUpdate(sessionKey)` / `pushTokenUpdate(sessionKey)` code in `server/index.js`. Replace the body of `pushTokenUpdate(sessionKey)` with scheduling only:

```js
function pushTokenUpdate(sessionKey) {
  scheduleSessionUsageSync(sessionKey, { delayMs: TOKEN_UPDATE_COOLDOWN_MS })
}
```

If `_doPushTokenUpdate()` becomes unused after this change, remove it and remove imports only used by it. Keep the SSE `token_update` broadcast only if another existing path still computes token deltas safely. Do not call `updateSessionTokenUsage(sessionKey, ...)` without owner resolution.

- [ ] **Step 8: Run targeted tests**

Run:

```bash
npx vitest run server/core/session-usage-cache.test.js server/core/usage-sync.test.js --exclude '**/.claude/**'
```

Expected: PASS.

- [ ] **Step 9: Run build**

Run:

```bash
npm run build
```

Expected: PASS.

- [ ] **Step 10: Commit sync orchestration**

```bash
git add server/core/usage-sync.js server/core/usage-sync.test.js server/index.js
git commit -m "fix: move gateway usage sync to background jobs"
```

---

## Task 5: Remove obsolete Gateway usage merge path from read APIs

**Files:**
- Modify: `server/core/session-usage-cache.js`
- Modify: `server/index.js`

- [ ] **Step 1: Find unused compatibility paths**

Run:

```bash
node - <<'NODE'
const fs = require('fs')
for (const file of ['server/index.js', 'server/core/session-usage-cache.js']) {
  const s = fs.readFileSync(file, 'utf8')
  for (const name of ['mergeGatewayWithSqlite', '_handleUsageCostProxy', 'batchUpdateFromGatewayUsage']) {
    const count = (s.match(new RegExp(name, 'g')) || []).length
    console.log(`${file} ${name} ${count}`)
  }
}
NODE
```

Expected before cleanup: counts show whether legacy paths remain. Use the counts to remove only truly unused code.

- [ ] **Step 2: Make `_handleUsageCostProxy()` read-only if it still exists**

If `_handleUsageCostProxy(params, userId, isAdmin)` still calls Gateway or `batchUpdateFromGatewayUsage`, replace it with:

```js
async function _handleUsageCostProxy(params, userId, isAdmin) {
  const result = getUserAggregates(isAdmin ? null : userId)
  const daily = result.aggregates.daily || []
  return {
    ok: true,
    payload: {
      updatedAt: Date.now(),
      days: daily.length,
      daily,
      totals: result.totals,
    },
  }
}
```

- [ ] **Step 3: Remove `mergeGatewayWithSqlite()` if no longer referenced**

If the command in Step 1 shows `mergeGatewayWithSqlite` is only defined and not imported/called, remove the export and its helper-only dependencies from `server/core/session-usage-cache.js`.

Do not remove `getUserAggregates()`.

- [ ] **Step 4: Keep `batchUpdateFromGatewayUsage()` only as a safe alias**

If other modules still import `batchUpdateFromGatewayUsage`, keep this safe alias:

```js
export function batchUpdateFromGatewayUsage(gatewayResult) {
  return batchUpdateMatchedGatewayUsage(gatewayResult)
}
```

Do not keep a `userId` parameter in implementation logic.

- [ ] **Step 5: Run grep-free static check for forbidden patterns**

Run:

```bash
node - <<'NODE'
const fs = require('fs')
const index = fs.readFileSync('server/index.js', 'utf8')
const usageProxy = index.slice(index.indexOf('async function _handleUsageProxy'), index.indexOf('async function _handleUsageCostProxy'))
if (usageProxy.includes('callGatewayUsage')) throw new Error('_handleUsageProxy still calls Gateway')
if (usageProxy.includes('batchUpdateFromGatewayUsage')) throw new Error('_handleUsageProxy still writes cache')
const cache = fs.readFileSync('server/core/session-usage-cache.js', 'utf8')
if (cache.includes('WHERE session_key = ?\n')) throw new Error('Found unsafe WHERE session_key-only update')
console.log('forbidden usage patterns absent')
NODE
```

Expected:

```text
forbidden usage patterns absent
```

- [ ] **Step 6: Run tests and build**

Run:

```bash
npx vitest run server/core/session-usage-cache.test.js server/core/usage-sync.test.js --exclude '**/.claude/**'
npm run test:server
npm run build
```

Expected: all PASS.

- [ ] **Step 7: Commit cleanup**

```bash
git add server/index.js server/core/session-usage-cache.js
git commit -m "refactor: remove gateway usage writes from read paths"
```

---

## Task 6: Manual verification checklist

**Files:**
- No code changes expected unless verification finds a bug.

- [ ] **Step 1: Verify admin usage API shape**

Start backend if needed:

```bash
npm run dev:server
```

In another terminal, call the admin endpoint with a valid admin token from the browser/dev session:

```bash
curl -s 'http://localhost:3001/api/sessions/usage?include=userUsage' \
  -H 'Authorization: Bearer <ADMIN_TOKEN>' | jq '{ok, hasPayload: (.payload != null), hasUserUsage: (.userUsage != null), userUsageCount: (.userUsage | length)}'
```

Expected shape:

```json
{
  "ok": true,
  "hasPayload": true,
  "hasUserUsage": true,
  "userUsageCount": 0
}
```

`userUsageCount` may be greater than 0 when users exist. The important checks are `ok: true`, `hasPayload: true`, and `hasUserUsage: true`.

- [ ] **Step 2: Verify normal user API shape**

Call with a normal user token:

```bash
curl -s 'http://localhost:3001/api/sessions/usage' \
  -H 'Authorization: Bearer <USER_TOKEN>' | jq '{ok, hasPayload: (.payload != null), hasUserUsage: (.userUsage != null)}'
```

Expected:

```json
{
  "ok": true,
  "hasPayload": true,
  "hasUserUsage": false
}
```

- [ ] **Step 3: Verify dashboard read does not synchronously hit Gateway usage**

Temporarily set `LOG_LEVEL=DEBUG` and call:

```bash
curl -s 'http://localhost:3001/api/sessions/usage?include=userUsage' \
  -H 'Authorization: Bearer <ADMIN_TOKEN>' >/dev/null
```

Expected backend behavior:

```text
No synchronous Gateway sessions.usage call is required before the HTTP response returns.
```

If a background sync is enqueued because SQLite has no synced rows, it may log after the response path. That is acceptable.

- [ ] **Step 4: Verify conflict behavior with a controlled local database**

Use a development database only. Insert two `user_sessions` rows with the same `session_key` but different users, then run a batch sync through the unit test or a short local script. Expected:

```text
updated: 0
skippedConflict: 1
```

Do not run this against production data.

- [ ] **Step 5: Final build**

Run:

```bash
npm run build
```

Expected: PASS.

- [ ] **Step 6: Commit verification notes only if docs changed**

If no files changed during verification, do not commit. If you added notes to the design or plan, commit only those docs:

```bash
git add docs/superpowers/specs/2026-06-11-usage-cache-redesign.md docs/superpowers/plans/2026-06-11-usage-cache-read-write-separation.md
git commit -m "docs: record usage cache verification plan"
```

---

## Self-Review

### Spec coverage

- Read API pure SQLite: Task 3.
- Admin `userUsage` top-level compatibility: Task 3.
- `user_id + session_key` writes: Task 2.
- Skip unmatched/conflicting Gateway sessions: Task 2 tests and implementation.
- Startup sync after ownership sync: Task 4.
- Read-triggered background sync without awaiting Gateway: Task 4.
- Chat/session completion debounce/singleflight: Task 4.
- `UsageSyncReport`: Task 2 and Task 4.
- Historical pollution not auto-fixed: Task 6 verifies no production data mutation; no cleanup script is added.

### Placeholder scan

No `TBD`, `TODO`, “implement later”, or unspecified edge handling remains. Code snippets define exact functions and commands.

### Type and name consistency

Function names used across tasks are consistent:

- `updateSessionUsageForUser`
- `batchUpdateMatchedGatewayUsage`
- `getAdminUserUsageAggregates`
- `hasUsageSyncRows`
- `syncUsageFromGatewayOnStartup`
- `scheduleSessionUsageSync`
- `syncSessionUsageNow`

---

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-06-11-usage-cache-read-write-separation.md`. Two execution options:

1. **Subagent-Driven (recommended)** - Dispatch a fresh subagent per task, review between tasks, fast iteration.

2. **Inline Execution** - Execute tasks in this session using executing-plans, batch execution with checkpoints.

Which approach?
