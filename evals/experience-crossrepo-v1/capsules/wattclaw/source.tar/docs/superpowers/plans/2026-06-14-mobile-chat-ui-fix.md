# 移动端对话模块 UI 与实时流修复 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复移动端 `/m` 对话模块 5 个问题（标题 uuid、无思考过程、消息未渲染 markdown、收不到实时推送、无工具调用），使行为对齐网页端。

**Architecture:** 方案 A——移动端新建/改造展示组件，复用现有 `chat.ts`（数据层已完整）与 `renderMarkdown` 工具，不改动网页端。实时问题根因为移动端从未调用 `wsStore.connect()` 建立 SSE，修复即在移动端 layout 接入连接。

**Tech Stack:** Vue 3 `<script setup lang="ts">`、Pinia、Naive UI、markdown-it（经 `renderMarkdown`）、SSE（`useWebSocketStore`→`OpenClawWebSocket`→`ApiClient`）。

**验证约定（项目无单测框架）：** 每个 task 用 `npx vue-tsc --noEmit` 做类型检查；全部完成后 `npm run build` + 手动验证。每个 task 末尾提交，仅 `git add` 该 task 涉及的具体文件。

**配套 spec：** `docs/superpowers/specs/2026-06-14-mobile-chat-ui-fix-design.md`

---

## File Structure

新增：
- `src/mobile/views/chat/AgentStatusBlock.vue` — 渲染 `chat.ts` 的 agent 思考时间线 + 工具调用（args/result 可折叠）。单一职责：只读 store、只做展示。

修改：
- `src/utils/session-title.ts` — 新增 `extractPureTitle()`，剥离「渠道·摘要」前缀与时间戳后缀（DRY，供移动端标题复用）。
- `src/mobile/views/chat/MobileConversationsPage.vue` — 标题用 `extractPureTitle` 显示纯标题。
- `src/mobile/views/chat/MessageBubble.vue` — assistant 用 `renderMarkdown` 渲染，user 保持纯文本。
- `src/mobile/layout/MobileTabLayout.vue` — onMounted 接入 `wsStore.connect()`（对齐 `DefaultLayout.vue`）。
- `src/mobile/views/chat/MobileChatPage.vue` — onMounted 兜底 connect；接入 `AgentStatusBlock`；`createNewSession` 传 `channel: 'webchat'`。
- `src/i18n/messages/zh-CN.ts`、`src/i18n/messages/en-US.ts` — 新增 `newConversation`、`thinking` key。

---

## Task 1: 标题纯标题（问题 1）

**Files:**
- Modify: `src/utils/session-title.ts`（追加 `extractPureTitle`）
- Modify: `src/mobile/views/chat/MobileConversationsPage.vue:182`（标题显示）
- Modify: `src/i18n/messages/zh-CN.ts`、`src/i18n/messages/en-US.ts`（`newConversation` key）

- [ ] **Step 1: 在 `src/utils/session-title.ts` 末尾追加 `extractPureTitle`**

在文件末尾（`generateSafeTitle` 函数之后）追加：

```typescript
const GENERATED_TITLE_SUFFIX_RE = /^(.+)-(\d{10}|\d{13})$/

/**
 * 从 server 生成的「渠道 · 摘要」或「摘要-时间戳」标题中提取纯摘要。
 * 与 server session-title-service 的 stripGeneratedTitleSuffix 保持一致的前端镜像。
 */
export function extractPureTitle(value: string): string {
  const trimmed = (value || '').trim()
  if (!trimmed) return ''

  // 1. 剥离「渠道 · 摘要」前缀，取最后一段摘要
  const segs = trimmed.split(' · ')
  let result = segs[segs.length - 1].trim()

  // 2. 剥离 server 生成的时间戳后缀「title-1234567890」
  const match = result.match(GENERATED_TITLE_SUFFIX_RE)
  if (match && match[1]) {
    result = match[1].trim()
  }

  return result || trimmed
}
```

- [ ] **Step 2: `MobileConversationsPage.vue` 改用纯标题**

在 `<script setup>` 顶部 import 区追加：

```typescript
import { extractPureTitle } from '@/utils/session-title'
```

在 `truncate` 函数下方追加 `formatSessionTitle`：

```typescript
function formatSessionTitle(session: { displayTitle?: string; label?: string }): string {
  const raw = extractPureTitle(session.displayTitle || session.label || '')
  const title = raw.trim()
  if (!title) return t('pages.mobile.chat.newConversation')
  return truncate(title, 32)
}
```

将模板 `:182` 的 session-title 行：

```vue
<span class="session-title">
  {{ truncate(session.displayTitle || session.label || session.key, 32) }}
</span>
```

改为：

```vue
<span class="session-title">
  {{ formatSessionTitle(session) }}
</span>
```

- [ ] **Step 3: 新增 i18n `newConversation` key**

在 `src/i18n/messages/zh-CN.ts` 的 `pages.mobile.chat` 块内（与 `newChat` 同级）追加：

```typescript
newConversation: '新对话',
```

在 `src/i18n/messages/en-US.ts` 对应位置追加：

```typescript
newConversation: 'New chat',
```

- [ ] **Step 4: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误（既有错误不变）。

- [ ] **Step 5: Commit**

```bash
git add src/utils/session-title.ts src/mobile/views/chat/MobileConversationsPage.vue src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "fix(mobile): 会话标题显示纯标题，剥离渠道前缀与 uuid"
```

---

## Task 2: 消息 markdown 渲染（问题 3）

**Files:**
- Modify: `src/mobile/views/chat/MessageBubble.vue`（全文重写 script/template，补 markdown 样式）

- [ ] **Step 1: 重写 `MessageBubble.vue` 的 `<script setup>`**

将 `<script setup lang="ts">` 块替换为：

```typescript
import { computed } from 'vue'
import { renderMarkdown } from '@/utils/render-markdown'
import { isImageAvatar } from '@/utils/agent-avatar'

interface Props {
  role: 'user' | 'assistant' | 'tool' | 'system'
  content: string
  avatar?: string
}

const props = defineProps<Props>()
const avatarIsImage = computed(() => isImageAvatar(props.avatar))
const isAssistant = computed(() => props.role === 'assistant')
const renderedHtml = computed(() =>
  isAssistant.value ? renderMarkdown(props.content) : ''
)
```

- [ ] **Step 2: 重写 `MessageBubble.vue` 的 `<template>`**

将 `<template>` 块替换为：

```vue
<template>
  <div class="message-bubble" :class="[`bubble-${role}`]">
    <span v-if="role === 'assistant' && avatar" class="bubble-avatar" :class="{ image: avatarIsImage }">
      <img
        v-if="avatarIsImage"
        v-avatar-fallback
        :src="avatar"
        alt="assistant"
        class="bubble-avatar-img"
      >
      <span v-else>{{ avatar }}</span>
    </span>
    <div class="bubble-content">
      <div v-if="isAssistant" class="bubble-text markdown-body" v-html="renderedHtml" />
      <div v-else class="bubble-text">{{ content }}</div>
    </div>
  </div>
</template>
```

- [ ] **Step 3: 在 `<style scoped>` 内追加 markdown 元素样式**

在现有 `.bubble-text :deep(strong)` 规则之后追加：

```css
.bubble-assistant .bubble-text {
  white-space: normal;
}

.bubble-text.markdown-body :deep(p) {
  margin: 0 0 8px;
}

.bubble-text.markdown-body :deep(p:last-child) {
  margin-bottom: 0;
}

.bubble-text.markdown-body :deep(h1),
.bubble-text.markdown-body :deep(h2),
.bubble-text.markdown-body :deep(h3),
.bubble-text.markdown-body :deep(h4) {
  margin: 10px 0 6px;
  font-weight: 700;
  line-height: 1.35;
}

.bubble-text.markdown-body :deep(h1) { font-size: 17px; }
.bubble-text.markdown-body :deep(h2) { font-size: 16px; }
.bubble-text.markdown-body :deep(h3) { font-size: 15px; }
.bubble-text.markdown-body :deep(h4) { font-size: 14px; }

.bubble-text.markdown-body :deep(ul),
.bubble-text.markdown-body :deep(ol) {
  margin: 4px 0 8px;
  padding-left: 20px;
}

.bubble-text.markdown-body :deep(li) {
  margin: 2px 0;
}

.bubble-text.markdown-body :deep(blockquote) {
  margin: 6px 0;
  padding: 4px 10px;
  border-left: 3px solid var(--m-border);
  color: var(--m-text-hint);
}

.bubble-text.markdown-body :deep(a) {
  color: var(--m-primary);
  word-break: break-all;
}

.bubble-text.markdown-body :deep(table) {
  border-collapse: collapse;
  margin: 6px 0;
  font-size: 12px;
}

.bubble-text.markdown-body :deep(th),
.bubble-text.markdown-body :deep(td) {
  border: 1px solid var(--m-border);
  padding: 4px 8px;
}
```

- [ ] **Step 4: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误。

- [ ] **Step 5: Commit**

```bash
git add src/mobile/views/chat/MessageBubble.vue
git commit -m "fix(mobile): AI 消息渲染 markdown，区分用户/助手气泡"
```

---

## Task 3: 建立 SSE 连接，修复实时推送（问题 4）

**Files:**
- Modify: `src/mobile/layout/MobileTabLayout.vue`（onMounted 接入 connect）
- Modify: `src/mobile/views/chat/MobileChatPage.vue`（全屏页兜底 connect）

- [ ] **Step 1: `MobileTabLayout.vue` 接入 `wsStore.connect()`**

将整个 `<script setup>` 块替换为：

```typescript
import { computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useWebSocketStore } from '@/stores/websocket'
import MobileTabBar from '@/mobile/components/MobileTabBar.vue'

const route = useRoute()
const wsStore = useWebSocketStore()
const tabViewKey = computed(() => route.path.split('/').slice(0, 3).join('/'))

// 对齐网页端 DefaultLayout：进入移动端主框架即建立 SSE 实时通道
onMounted(() => {
  wsStore.connect()
})
```

- [ ] **Step 2: `MobileChatPage.vue` 全屏页兜底 connect**

`/m/chat` 是 MobileTabLayout 之外的全屏页，深链直进时需兜底。在 `MobileChatPage.vue` 的 import 区追加：

```typescript
import { useWebSocketStore } from '@/stores/websocket'
import { ConnectionState } from '@/api/types'
```

在 `const sessionStore = useSessionStore()` 下方追加：

```typescript
const wsStore = useWebSocketStore()
```

将 `onMounted` 改为（在现有逻辑前插入兜底 connect）：

```typescript
onMounted(async () => {
  // 全屏聊天页可能在 MobileTabLayout 之外（深链直进），兜底确保 SSE 已连接
  if (
    wsStore.state === ConnectionState.DISCONNECTED ||
    wsStore.state === ConnectionState.FAILED
  ) {
    wsStore.connect()
  }
  void agentTeamStore.fetchAgents()
  void modelStore.fetchModels()
  chatStore.subscribeRealtimeEvents()
  const agentId = route.query.agentId as string | undefined
  if (!props.sessionKey && agentId) {
    await createNewSession(agentId)
  }
})
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误。

- [ ] **Step 4: Commit**

```bash
git add src/mobile/layout/MobileTabLayout.vue src/mobile/views/chat/MobileChatPage.vue
git commit -m "fix(mobile): 接入 SSE 连接，修复实时推送缺失"
```

---

## Task 4: 新增 AgentStatusBlock 组件（问题 2 / 5）

**Files:**
- Create: `src/mobile/views/chat/AgentStatusBlock.vue`
- Modify: `src/i18n/messages/zh-CN.ts`、`src/i18n/messages/en-US.ts`（`thinking` key）

- [ ] **Step 1: 创建 `src/mobile/views/chat/AgentStatusBlock.vue`**

```vue
<script setup lang="ts">
import { computed, ref } from 'vue'
import { useChatStore } from '@/stores/chat'
import { useI18n } from 'vue-i18n'

const props = defineProps<{ agentId: string }>()
const chatStore = useChatStore()
const { t } = useI18n()

const expanded = ref(false)

const status = computed(() => chatStore.agentStatuses.get(props.agentId) || null)
const steps = computed(() => chatStore.agentSteps.get(props.agentId) || [])
const tool = computed(() => chatStore.toolProgress.get(props.agentId) || null)

const visible = computed(() => {
  const phase = status.value?.phase
  if (!phase) return false
  return !['idle', 'done', 'aborted', 'error'].includes(phase)
})

const currentLabel = computed(() => {
  const last = steps.value[steps.value.length - 1]
  return last?.label || t('pages.mobile.chat.thinking')
})
</script>

<template>
  <div v-if="visible" class="agent-status-block">
    <div class="status-line">
      <span class="status-dot" :class="status?.phase" />
      <span class="status-label">{{ currentLabel }}</span>
    </div>

    <div v-if="tool" class="tool-block">
      <button class="tool-header" type="button" @click="expanded = !expanded">
        <span class="tool-icon">🔧</span>
        <span class="tool-name">{{ tool.name }}</span>
        <span class="tool-arrow">{{ expanded ? '▾' : '▸' }}</span>
      </button>
      <div v-if="expanded" class="tool-detail">
        <div v-if="tool.argsPreview" class="tool-section">
          <div class="tool-section-label">{{ t('pages.mobile.chat.toolArgs') }}</div>
          <pre class="tool-pre">{{ tool.argsPreview }}</pre>
        </div>
        <div v-if="tool.resultPreview" class="tool-section">
          <div class="tool-section-label">{{ t('pages.mobile.chat.toolResult') }}</div>
          <pre class="tool-pre" :class="{ error: tool.isError }">{{ tool.resultPreview }}</pre>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.agent-status-block {
  align-self: flex-start;
  max-width: 88%;
  padding: 8px 12px;
  border-radius: 16px;
  background: color-mix(in srgb, var(--m-bg-input) 86%, transparent);
  border: 1px solid color-mix(in srgb, var(--m-border) 58%, transparent);
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.status-line {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--m-text-hint);
  flex-shrink: 0;
  animation: status-pulse 1.4s ease-in-out infinite;
}

.status-dot.tool { background: var(--m-primary); }
.status-dot.repeating { background: #10b981; }
.status-dot.error { background: var(--m-danger); animation: none; }

.status-label {
  font-size: 13px;
  color: var(--m-text-secondary);
  line-height: 1.4;
}

.tool-block {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.tool-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 0;
  background: transparent;
  border: none;
  color: var(--m-text-primary);
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}

.tool-name {
  flex: 1;
  min-width: 0;
  font-weight: 600;
}

.tool-arrow {
  color: var(--m-text-hint);
  font-size: 11px;
}

.tool-detail {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-top: 2px;
}

.tool-section-label {
  font-size: 11px;
  color: var(--m-text-hint);
  margin-bottom: 2px;
}

.tool-pre {
  margin: 0;
  padding: 6px 8px;
  max-height: 180px;
  overflow: auto;
  background: rgba(0, 0, 0, 0.04);
  border-radius: 8px;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  font-size: 11px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
}

.tool-pre.error {
  background: rgba(255, 77, 79, 0.08);
  color: var(--m-danger);
}

@keyframes status-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}
</style>
```

- [ ] **Step 2: 新增 i18n `thinking`、`toolArgs`、`toolResult` key**

`src/i18n/messages/zh-CN.ts` 的 `pages.mobile.chat` 块内追加：

```typescript
thinking: '思考中',
toolArgs: '参数',
toolResult: '结果',
```

`src/i18n/messages/en-US.ts` 对应位置追加：

```typescript
thinking: 'Thinking',
toolArgs: 'Args',
toolResult: 'Result',
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误。

- [ ] **Step 4: Commit**

```bash
git add src/mobile/views/chat/AgentStatusBlock.vue src/i18n/messages/zh-CN.ts src/i18n/messages/en-US.ts
git commit -m "feat(mobile): 新增 AgentStatusBlock，展示思考过程与工具调用"
```

---

## Task 5: 接入 AgentStatusBlock 到聊天页（问题 2 / 5）

**Files:**
- Modify: `src/mobile/views/chat/MobileChatPage.vue`（消息列表后插入状态块）

- [ ] **Step 1: import AgentStatusBlock**

在 `MobileChatPage.vue` 的 import 区（`MessageBubble` import 下方）追加：

```typescript
import AgentStatusBlock from '@/mobile/views/chat/AgentStatusBlock.vue'
```

- [ ] **Step 2: 在消息列表末尾插入 AgentStatusBlock**

将模板中的消息列表块：

```vue
      <MessageBubble
        v-for="msg in chatStore.messages"
        :key="msg.id"
        :role="msg.role"
        :content="msg.content"
        :avatar="msg.role === 'assistant' ? currentAgentAvatar : ''"
      />
    </div>
```

改为（在 `v-for` 之后、闭合 `</div>` 之前插入状态块）：

```vue
      <MessageBubble
        v-for="msg in chatStore.messages"
        :key="msg.id"
        :role="msg.role"
        :content="msg.content"
        :avatar="msg.role === 'assistant' ? currentAgentAvatar : ''"
      />
      <AgentStatusBlock v-if="currentAgentId" :agent-id="currentAgentId" />
    </div>
```

- [ ] **Step 3: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误。

- [ ] **Step 4: Commit**

```bash
git add src/mobile/views/chat/MobileChatPage.vue
git commit -m "feat(mobile): 聊天页接入 AgentStatusBlock"
```

---

## Task 6: createNewSession 传正确 channel（问题 1 源头治理）

**Files:**
- Modify: `src/mobile/views/chat/MobileChatPage.vue`（`createNewSession` body）

- [ ] **Step 1: 修改 createNewSession 的 body**

将 `MobileChatPage.vue` 中 `createNewSession` 的 `body: JSON.stringify({...})` 块：

```typescript
      body: JSON.stringify({
        sessionKey: newKey,
        agentId,
        label: '',
        channel: '',
      }),
```

改为：

```typescript
      body: JSON.stringify({
        sessionKey: newKey,
        agentId,
        label: '',
        channel: 'webchat',
      }),
```

- [ ] **Step 2: 类型检查**

Run: `npx vue-tsc --noEmit`
Expected: 无新增错误。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/views/chat/MobileChatPage.vue
git commit -m "fix(mobile): 新建会话传 channel=webchat，避免 uuid 兜底为渠道标签"
```

---

## Task 7: 构建验证与端到端手动验证

**Files:** 无（仅验证）

- [ ] **Step 1: 生产构建**

Run: `npm run build`
Expected: 构建成功，仅 Vite chunk-size warning 可接受。

- [ ] **Step 2: 启动服务**

Run: `./start.sh`（前端 :3000 + 后端 :3001）

- [ ] **Step 3: 移动端手动验证（浏览器开发者工具切移动视口，访问 `http://localhost:3000/m`）**

逐项验证：

1. **标题**：选数字员工 → 新对话 → 发送「你好，请介绍一下你自己」→ 返回会话列表，历史标题显示「你好，请介绍一下你自己」，无 `uuid ·` 前缀。
2. **思考过程**：发送后，消息流末尾出现带脉冲圆点的状态行（「思考中」→「回复中」等）。
3. **markdown**：AI 回复中的 `##`/`###`/`-` 列表/代码块正确渲染为标题、列表、代码块。
4. **实时推送**：发送后无需刷新或退出，AI 回复增量实时出现（不再只能从历史会话看结果）；浏览器 Network 面板可见 SSE 连接已建立。
5. **工具调用**：触发工具时，状态块出现 `🔧 工具名`，点击展开可见参数与结果。
6. **深链兜底**：直接访问 `/m/chat/<sessionKey>`，实时推送仍可用。

- [ ] **Step 4: 网页端回归**

访问 `http://localhost:3000/chat`，确认网页端标题、实时流、markdown 渲染均未受影响。

- [ ] **Step 5: 若全部通过，更新记忆**

更新 `memory/active.md` 的「最新提交」与「当前页面」字段至本次修复完成状态。

---

## Self-Review

**1. Spec coverage：**
- 问题 1（标题）→ Task 1 + Task 6 ✓
- 问题 2（思考过程）→ Task 4 + Task 5 ✓
- 问题 3（markdown）→ Task 2 ✓
- 问题 4（推送）→ Task 3 ✓
- 问题 5（工具调用）→ Task 4 + Task 5（与问题 2 共用 AgentStatusBlock）✓
- 验证 → Task 7 ✓

**2. Placeholder scan：** 无 TBD/TODO；每个代码 step 含完整代码；i18n key 含完整 value。

**3. Type consistency：**
- `extractPureTitle(value: string): string` 定义（Task 1）与 `MobileConversationsPage` 调用一致。
- `AgentStatusBlock` props `{ agentId: string }` 定义（Task 4）与 `MobileChatPage` 传入 `:agent-id="currentAgentId"` 一致；`currentAgentId` 已存在于 `MobileChatPage.vue:36`。
- `chatStore.agentStatuses/agentSteps/toolProgress` 的读取与 `chat.ts` 暴露一致。
- i18n key（`newConversation`/`thinking`/`toolArgs`/`toolResult`）定义与组件 `t()` 调用一致。

**4. 依赖顺序：** Task 4（创建组件）先于 Task 5（接入）；Task 1 的 `extractPureTitle` 先于使用。顺序正确。
