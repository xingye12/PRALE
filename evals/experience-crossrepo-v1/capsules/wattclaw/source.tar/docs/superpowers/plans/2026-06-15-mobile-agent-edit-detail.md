# 移动端数字员工创建/编辑细节优化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 移动端 `/m` 数字员工创建/编辑页对齐网页端：模板精选/全部分类、设定四文件补齐（改名「设定」+描述）、markdown 预览 + 全屏编辑 + 可折叠。

**Architecture:** 创建态设定只读预览（模板预填）、编辑态读写 Gateway 文件（`/api/agent-team/:id/files` + `setAgentFile`）；拆分 4 个聚焦组件 + 1 个网页/移动共享常量，消除重复实现。设定编辑交互为可折叠卡片列表 + 近全屏覆盖层。

**Tech Stack:** Vue 3 `<script setup lang="ts">`、Pinia、Naive UI、markdown-it（`renderMarkdown`）、i18n（仅 zh-CN）、Aurora 移动端样式（CSS 变量 `--m-*`）。

**Spec:** `docs/superpowers/specs/2026-06-15-mobile-agent-edit-detail-design.md`

**验证约定（无测试框架）：** 每个任务结束跑 `npm run build`（vue-tsc 类型检查 + Vite 构建）确认类型/编译通过；集成任务额外列手动验证要点。

**Git 红线：** 每次 commit 用 pathspec 隔离（`git add <具体文件>`），禁止 `git add .`/`git add -A`。

---

## File Structure

| 文件 | 动作 | 职责 |
|---|---|---|
| `src/config/agent-settings.ts` | 新建 | 设定文件映射常量（file/field/label/desc），网页+移动单一权威 |
| `src/views/agent-management/tabs/SettingsTab.vue` | 改 | 改用共享常量，删除内联 `FILE_LABELS` |
| `src/i18n/messages/zh-CN.ts` | 改 | `pages.mobile.agents` 下新增设定相关 key |
| `src/mobile/components/MobileMarkdownEditorOverlay.vue` | 新建 | 近全屏编辑覆盖层（顶栏 ✕标题✓ + textarea 占满） |
| `src/mobile/views/agents/MobileTemplatePicker.vue` | 新建 | 创建态：精选/全部 tab + 模板网格 |
| `src/mobile/views/agents/MobileSettingSection.vue` | 新建 | 设定区：4 折叠卡片，markdown 预览 + 编辑态调起覆盖层 |
| `src/mobile/views/agents/MobileAgentEditPage.vue` | 改 | 瘦身编排，接入上述组件，设定标题改「设定」 |

任务依赖顺序：Task 1（常量）→ Task 2（i18n）→ Task 3（覆盖层）→ Task 4（模板选择）→ Task 5（设定区，依赖 1/2/3）→ Task 6（集成，依赖 4/5）。

---

## Task 1: 新建设定共享常量并重构网页端 SettingsTab

**Files:**
- Create: `src/config/agent-settings.ts`
- Modify: `src/views/agent-management/tabs/SettingsTab.vue`

- [ ] **Step 1: 创建共享常量文件**

创建 `src/config/agent-settings.ts`：

```ts
export type AgentSettingFileName = 'SOUL.md' | 'AGENTS.md' | 'IDENTITY.md' | 'USER.md'
export type AgentSettingField = 'soulMd' | 'agentsMd' | 'identityMd' | 'userMd'

export interface AgentSettingFile {
  file: AgentSettingFileName
  field: AgentSettingField
  label: string
  desc: string
}

/** 设定文件映射（网页端 SettingsTab + 移动端共用，单一权威）。label/desc 为业务固定中文文案。 */
export const AGENT_SETTING_FILES: AgentSettingFile[] = [
  { file: 'SOUL.md',     field: 'soulMd',     label: '行为准则', desc: '定义核心行为规范、安全边界和不可逾越的底线' },
  { file: 'AGENTS.md',   field: 'agentsMd',   label: '工作流程', desc: '定义工作流程、协作方式和工具使用规则' },
  { file: 'IDENTITY.md', field: 'identityMd', label: '身份档案', desc: '定义身份信息、专业领域、技能特长和沟通风格' },
  { file: 'USER.md',     field: 'userMd',     label: '用户档案', desc: '记录用户的信息偏好、使用习惯和个性化需求' },
]

/** 按文件名快速查表（替代网页端原 FILE_LABELS 的 Record 查找）。 */
export const AGENT_SETTING_BY_FILE: Record<string, AgentSettingFile> = Object.fromEntries(
  AGENT_SETTING_FILES.map((f) => [f.file, f]),
)
```

- [ ] **Step 2: SettingsTab 引入共享常量**

编辑 `src/views/agent-management/tabs/SettingsTab.vue`，在 `<script setup>` 顶部 import 区（约第 9 行 `import { apiPath } from '@/utils/api-path'` 之后）新增：

```ts
import { AGENT_SETTING_BY_FILE } from '@/config/agent-settings'
```

- [ ] **Step 3: 删除内联 FILE_LABELS 并替换引用**

删除第 24-29 行的 `const FILE_LABELS: Record<string, { zh: string; desc: string }> = { ... }` 整块。

模板中 3 处引用替换（`?.zh` → `?.label`）：
- 第 151 行：`{{ FILE_LABELS[file.name]?.zh || file.name }}` → `{{ AGENT_SETTING_BY_FILE[file.name]?.label || file.name }}`
- 第 161 行：`{{ FILE_LABELS[activeFile]?.zh || activeFile }}` → `{{ AGENT_SETTING_BY_FILE[activeFile]?.label || activeFile }}`
- 第 164 行：`v-if="FILE_LABELS[activeFile]?.desc"` 与 `{{ FILE_LABELS[activeFile]!.desc }}` → `v-if="AGENT_SETTING_BY_FILE[activeFile]?.desc"` 与 `{{ AGENT_SETTING_BY_FILE[activeFile]!.desc }}`

- [ ] **Step 4: 构建验证**

Run: `npm run build`
Expected: 通过（vue-tsc 无类型错误，仅有 Vite chunk-size warning）。网页端 SettingsTab 渲染逻辑零改动，label/desc 文案不变。

- [ ] **Step 5: Commit**

```bash
git add src/config/agent-settings.ts src/views/agent-management/tabs/SettingsTab.vue
git commit -m "refactor: 抽取设定文件映射为共享常量 agent-settings.ts"
```

---

## Task 2: 新增移动端设定相关 i18n key

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`

- [ ] **Step 1: 定位 `pages.mobile.agents` 命名空间**

Run: `grep -n "roleConfig\|soulLabel\|templateHint" src/i18n/messages/zh-CN.ts`
Expected: 命中 `pages.mobile.agents` 块内约第 3183-3189 行。

- [ ] **Step 2: 在 `pages.mobile.agents` 块内新增 key**

在第 3189 行 `templateHint: '选择身份模板，快速配置',` 之后追加（保持该对象内缩进一致）：

```ts
        setting: '设定',
        preview: '预览',
        editAction: '编辑',
        save: '保存',
        cancel: '取消',
        collapseHint: '点击展开/收起',
```

> 精选/全部标签复用现有 `common.featured` / `common.all`（网页端 `CATEGORY_CONFIGS` 已用），不新增。
> 原 `roleConfig` / `soulLabel` 暂保留，Task 6 切换引用后如确认无其他引用可删除。

- [ ] **Step 3: 构建验证**

Run: `npm run build`
Expected: 通过。

- [ ] **Step 4: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit -m "feat(i18n): 移动端新增设定区文案 key"
```

---

## Task 3: 新建全屏编辑覆盖层组件

**Files:**
- Create: `src/mobile/components/MobileMarkdownEditorOverlay.vue`

- [ ] **Step 1: 创建组件文件**

创建 `src/mobile/components/MobileMarkdownEditorOverlay.vue`：

```vue
<script setup lang="ts">
import { ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'

const props = defineProps<{
  visible: boolean
  title: string
  value: string
}>()
const emit = defineEmits<{
  (e: 'save', value: string): void
  (e: 'cancel'): void
}>()

const { t } = useI18n()
const draft = ref(props.value)

// 每次打开覆盖层时，用最新 value 重置草稿，避免上次编辑残留
watch(
  () => props.visible,
  (v) => {
    if (v) draft.value = props.value
  },
)
</script>

<template>
  <Transition name="overlay">
    <div v-if="visible" class="overlay">
      <header class="overlay-bar">
        <button class="bar-btn" @click="emit('cancel')">{{ t('pages.mobile.agents.cancel') }}</button>
        <span class="bar-title">{{ title }}</span>
        <button class="bar-btn primary" @click="emit('save', draft)">
          {{ t('pages.mobile.agents.save') }}
        </button>
      </header>
      <textarea
        v-model="draft"
        class="overlay-editor"
        :placeholder="t('pages.mobile.agents.editAction')"
        autocomplete="off"
      />
    </div>
  </Transition>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  z-index: 2000;
  display: flex;
  flex-direction: column;
  background: var(--m-bg-page);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}
.overlay-bar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: calc(12px + env(safe-area-inset-top)) 16px 12px;
  border-bottom: 1px solid var(--m-border);
  background: var(--m-tab-bar-bg);
}
.bar-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--m-text-primary);
}
.bar-btn {
  min-width: 48px;
  padding: 7px 14px;
  border: none;
  border-radius: var(--m-radius-md);
  background: transparent;
  color: var(--m-text-secondary);
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.bar-btn.primary {
  background: var(--m-bubble-user-bg);
  color: #fff;
}
.bar-btn:active { opacity: 0.7; }
.overlay-editor {
  flex: 1;
  width: 100%;
  margin: 0;
  padding: 16px;
  border: none;
  background: transparent;
  color: var(--m-text-primary);
  font-family: 'SF Mono', 'JetBrains Mono', 'Menlo', monospace;
  font-size: 13px;
  line-height: 1.7;
  resize: none;
  outline: none;
}
.overlay-enter-active,
.overlay-leave-active {
  transition: transform 0.28s cubic-bezier(0.22, 0.61, 0.36, 1), opacity 0.28s ease;
}
.overlay-enter-from,
.overlay-leave-to {
  transform: translateY(100%);
  opacity: 0;
}
@media (prefers-reduced-motion: reduce) {
  .overlay-enter-active,
  .overlay-leave-active { transition: none; }
}
</style>
```

- [ ] **Step 2: 构建验证**

Run: `npm run build`
Expected: 通过（组件未被引用，但类型/编译须无误）。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/components/MobileMarkdownEditorOverlay.vue
git commit -m "feat(mobile): 新建全屏 markdown 编辑覆盖层组件"
```

---

## Task 4: 新建模板选择组件（精选/全部）

**Files:**
- Create: `src/mobile/views/agents/MobileTemplatePicker.vue`

- [ ] **Step 1: 创建组件文件**

创建 `src/mobile/views/agents/MobileTemplatePicker.vue`：

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { getAllTemplates, FEATURED_TEMPLATE_IDS } from '@/config/agent-templates'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { categoryAccent } from '@/mobile/utils/category-accent'

defineProps<{ selectedId: string }>()
const emit = defineEmits<{
  (e: 'select', template: AgentTemplate): void
}>()

const { t } = useI18n()
const tab = ref<'featured' | 'all'>('featured')
const templates = computed(() => getAllTemplates())

const filtered = computed(() =>
  tab.value === 'featured'
    ? templates.value.filter((tpl) => FEATURED_TEMPLATE_IDS.has(tpl.id))
    : templates.value,
)

function avatarOf(tpl: AgentTemplate): string {
  return resolveAgentAvatar(tpl.id, tpl.avatar || '🤖')
}
function accentOf(category: string) {
  return categoryAccent(category || '')
}
</script>

<template>
  <div class="picker">
    <div class="tabs">
      <button
        class="tab"
        :class="{ active: tab === 'featured' }"
        @click="tab = 'featured'"
      >
        {{ t('common.featured') }}
      </button>
      <button
        class="tab"
        :class="{ active: tab === 'all' }"
        @click="tab = 'all'"
      >
        {{ t('common.all') }}
      </button>
    </div>

    <div class="tpl-grid">
      <button
        v-for="tpl in filtered"
        :key="tpl.id"
        class="tpl"
        :class="{ selected: selectedId === tpl.id }"
        @click="emit('select', tpl)"
      >
        <span class="tpl-accent" :style="{ background: accentOf(tpl.category).bar }" />
        <span
          class="tpl-avatar"
          :class="{ image: isImageAvatar(avatarOf(tpl)) }"
          :style="!isImageAvatar(avatarOf(tpl)) ? { background: accentOf(tpl.category).avatarTint } : undefined"
        >
          <img
            v-if="isImageAvatar(avatarOf(tpl))"
            v-avatar-fallback
            :src="avatarOf(tpl)"
            :alt="tpl.name"
            class="tpl-avatar-img"
          >
          <span v-else>{{ avatarOf(tpl) }}</span>
        </span>
        <span class="tpl-name">{{ tpl.name }}</span>
        <span class="tpl-check" aria-hidden="true">
          <svg viewBox="0 0 24 24" class="ic"><path d="M5 12l4 4 10-10" /></svg>
        </span>
      </button>
    </div>
  </div>
</template>

<style scoped>
.tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}
.tab {
  padding: 6px 16px;
  border: 1.5px solid var(--m-border);
  border-radius: 999px;
  background: var(--m-bg-input);
  color: var(--m-text-secondary);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: all 0.18s ease;
}
.tab.active {
  border-color: var(--m-primary);
  color: var(--m-primary);
  background: var(--m-primary-light);
}

.tpl-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}
.tpl {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 12px 4px 9px;
  background: var(--m-bg-input);
  border: 1.5px solid var(--m-border);
  border-radius: var(--m-radius-md);
  cursor: pointer;
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
}
.tpl:active { transform: scale(0.95); }
.tpl-accent {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2.5px;
}
.tpl-avatar {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 14px;
  color: var(--m-primary);
  font-size: 22px;
  line-height: 1;
  overflow: hidden;
  box-shadow: 0 6px 14px rgba(15, 23, 42, 0.08);
}
.tpl-avatar.image { background: #fff; }
.tpl-avatar-img { width: 100%; height: 100%; object-fit: cover; }
.tpl-name {
  font-size: 11px;
  font-weight: 500;
  color: var(--m-text-secondary);
  text-align: center;
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tpl-check {
  position: absolute;
  top: 6px; right: 6px;
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--m-primary);
  color: #fff;
  opacity: 0;
  transform: scale(0.4);
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.tpl-check .ic { width: 11px; height: 11px; }
.tpl.selected {
  border-color: var(--m-primary);
  background: var(--m-primary-light);
  box-shadow: var(--m-shadow-soft);
}
.tpl.selected .tpl-check { opacity: 1; transform: scale(1); }
.tpl.selected .tpl-name { color: var(--m-primary); font-weight: 600; }

.ic {
  width: 20px;
  height: 20px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
</style>
```

- [ ] **Step 2: 构建验证**

Run: `npm run build`
Expected: 通过。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/views/agents/MobileTemplatePicker.vue
git commit -m "feat(mobile): 新建模板选择组件（精选/全部分类）"
```

---

## Task 5: 新建设定区组件（折叠卡片 + markdown 预览 + 编辑）

**Files:**
- Create: `src/mobile/views/agents/MobileSettingSection.vue`

- [ ] **Step 1: 创建组件文件**

创建 `src/mobile/views/agents/MobileSettingSection.vue`：

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { renderMarkdown } from '@/utils/render-markdown'
import { AGENT_SETTING_FILES, AGENT_SETTING_BY_FILE } from '@/config/agent-settings'
import MobileMarkdownEditorOverlay from '@/mobile/components/MobileMarkdownEditorOverlay.vue'

const props = defineProps<{
  /** create=只读预览（无编辑按钮）；edit=可预览可编辑 */
  mode: 'create' | 'edit'
  /** key=文件名(SOUL.md...)，value=内容。create 态来自模板预填，edit 态来自 Gateway */
  files: Record<string, string>
}>()
const emit = defineEmits<{
  (e: 'edit', payload: { file: string; content: string }): void
}>()

const { t } = useI18n()
/** 当前展开的文件名（空=全部折叠） */
const expanded = ref<string>('')
/** 正在编辑的文件（非空则覆盖层可见） */
const editing = ref<{ file: string; content: string } | null>(null)

function toggle(file: string) {
  expanded.value = expanded.value === file ? '' : file
}
function startEdit(file: string) {
  editing.value = { file, content: props.files[file] || '' }
}
function onSave(content: string) {
  if (editing.value) emit('edit', { file: editing.value.file, content })
  editing.value = null
}
function onCancel() {
  editing.value = null
}
const editingTitle = computed(() =>
  editing.value ? AGENT_SETTING_BY_FILE[editing.value.file]?.label || editing.value.file : '',
)
</script>

<template>
  <div class="setting-list">
    <div
      v-for="s in AGENT_SETTING_FILES"
      :key="s.file"
      class="set-card"
      :class="{ expanded: expanded === s.file }"
    >
      <button class="set-head" @click="toggle(s.file)">
        <span class="set-icon">{{ s.label.charAt(0) }}</span>
        <span class="set-meta">
          <span class="set-label">{{ s.label }}</span>
          <span class="set-desc">{{ s.desc }}</span>
        </span>
        <svg
          class="set-arrow"
          :class="{ rotated: expanded === s.file }"
          viewBox="0 0 24 24"
        ><path d="M6 9l6 6 6-6" /></svg>
      </button>

      <div v-if="expanded === s.file" class="set-body">
        <div class="set-preview" v-html="renderMarkdown(files[s.file] || '')" />
        <button
          v-if="mode === 'edit'"
          class="set-edit-btn"
          @click="startEdit(s.file)"
        >
          <svg viewBox="0 0 24 24" class="ic"><path d="M4 20h4l10-10-4-4L4 16v4z" /></svg>
          {{ t('pages.mobile.agents.editAction') }}
        </button>
        <p v-else class="set-readonly-hint">{{ t('pages.mobile.agents.collapseHint') }}</p>
      </div>
    </div>

    <MobileMarkdownEditorOverlay
      :visible="!!editing"
      :title="editingTitle"
      :value="editing?.content || ''"
      @save="onSave"
      @cancel="onCancel"
    />
  </div>
</template>

<style scoped>
.setting-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.set-card {
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-md);
  background: var(--m-bg-input);
  overflow: hidden;
  transition: border-color 0.18s ease;
}
.set-card.expanded { border-color: var(--m-primary); }
.set-head {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border: none;
  background: transparent;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.set-icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  flex-shrink: 0;
  border-radius: 10px;
  background: var(--m-primary-light);
  color: var(--m-primary);
  font-size: 14px;
  font-weight: 700;
}
.set-meta {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.set-label {
  font-size: 14px;
  font-weight: 600;
  color: var(--m-text-primary);
}
.set-desc {
  font-size: 11px;
  line-height: 1.4;
  color: var(--m-text-hint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.set-arrow {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  color: var(--m-text-hint);
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: transform 0.2s ease;
}
.set-arrow.rotated { transform: rotate(180deg); }

.set-body {
  padding: 0 14px 14px;
  border-top: 1px dashed var(--m-border);
}
.set-preview {
  margin-top: 10px;
  font-size: 13px;
  line-height: 1.7;
  color: var(--m-text-primary);
  word-break: break-word;
}
.set-preview :deep(h1),
.set-preview :deep(h2),
.set-preview :deep(h3) { margin: 10px 0 6px; font-weight: 700; }
.set-preview :deep(ul) { padding-left: 18px; margin: 6px 0; }
.set-preview :deep(code) {
  background: var(--m-bg-secondary, rgba(0,0,0,0.05));
  padding: 1px 5px;
  border-radius: 4px;
  font-family: 'SF Mono', monospace;
  font-size: 12px;
}
.set-edit-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin-top: 10px;
  padding: 6px 14px;
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-md);
  background: var(--m-bg-card);
  color: var(--m-primary);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.set-edit-btn .ic { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
.set-readonly-hint {
  margin: 8px 0 0;
  font-size: 11px;
  color: var(--m-text-hint);
}
</style>
```

- [ ] **Step 2: 构建验证**

Run: `npm run build`
Expected: 通过。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/views/agents/MobileSettingSection.vue
git commit -m "feat(mobile): 新建设定区组件（折叠卡片+markdown预览+全屏编辑）"
```

---

## Task 6: MobileAgentEditPage 集成编排

**Files:**
- Modify: `src/mobile/views/agents/MobileAgentEditPage.vue`

- [ ] **Step 1: 重写 `<script setup>`（状态 + 数据流）**

将 `src/mobile/views/agents/MobileAgentEditPage.vue` 第 1-112 行（整个 `<script setup>` 块）替换为：

```ts
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import { useAuthStore } from '@/stores/auth'
import { getAllTemplates, getTemplateById } from '@/config/agent-templates'
import type { AgentTemplate } from '@/api/types/agent-team'
import { apiPath } from '@/utils/api-path'
import MobileTemplatePicker from './MobileTemplatePicker.vue'
import MobileSettingSection from './MobileSettingSection.vue'

const route = useRoute()
const router = useRouter()
const { t } = useI18n()
const agentTeamStore = useAgentTeamStore()
const wsStore = useWebSocketStore()
const authStore = useAuthStore()

const isEdit = computed(() => route.name === 'MobileAgentEdit')
const agentId = computed(() => route.params.id as string)
const loading = ref(false)
const submitting = ref(false)
const error = ref('')

const selectedTemplateId = ref('')
const name = ref('')
const description = ref('')
const model = ref('')

/** 设定文件内容：create 态由选中模板预填（只读预览），edit 态由 Gateway 读取 */
const settingFiles = ref<Record<string, string>>({})

const selectedTemplate = computed((): AgentTemplate | undefined => {
  return getTemplateById(selectedTemplateId.value)
})

/** create 态：模板自带的 4 文件内容随选中模板变化（响应式预览） */
const createFiles = computed<Record<string, string>>(() => {
  const tpl = selectedTemplate.value
  if (!tpl) return {}
  return {
    'SOUL.md': tpl.soulMd || '',
    'AGENTS.md': tpl.agentsMd || '',
    'IDENTITY.md': tpl.identityMd || '',
    'USER.md': tpl.userMd || '',
  }
})

/** 设定区绑定：create 用模板预填，edit 用 Gateway 读取结果 */
const settingSource = computed<Record<string, string>>(() =>
  isEdit.value ? settingFiles.value : createFiles.value,
)

/** Hero 光晕强调色：编辑态取员工分类，创建态取选中模板分类，否则主色。 */
const heroAccent = computed(() => {
  if (isEdit.value) {
    const extra = agentTeamStore.currentAgent as Record<string, unknown> | undefined
    return categoryAccentOf((extra?.category as string) || '')
  }
  return categoryAccentOf(selectedTemplate.value?.category || '')
})

function categoryAccentOf(category: string) {
  // 复用 categoryAccent，避免在模板内重复 import
  return categoryAccent(category || '')
}

function onTemplateSelect(template: AgentTemplate) {
  selectedTemplateId.value = template.id
  name.value = name.value || template.name
  description.value = description.value || template.description
}

/** 编辑态：从 Gateway 读取 4 个设定文件 */
async function loadSettingFiles() {
  const id = agentId.value
  if (!id) return
  const token = authStore.getToken()
  try {
    const res = await fetch(apiPath(`/api/agent-team/${id}/files`), {
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    })
    if (res.ok) {
      const data = await res.json()
      if (data.ok && data.files) {
        settingFiles.value = { ...(data.files as Record<string, string>) }
      }
    }
  } catch (err) {
    // 不静默吞错：记录但不阻塞页面（设定区降级为空内容）
    console.error('[MobileAgentEdit] load setting files failed:', err)
  }
}

/** 编辑态：保存单个设定文件到 Gateway */
async function onSettingEdit(payload: { file: string; content: string }) {
  const id = agentId.value
  if (!id) return
  try {
    await wsStore.rpc.setAgentFile(id, payload.file, payload.content)
    // 本地刷新，避免再次请求
    settingFiles.value = { ...settingFiles.value, [payload.file]: payload.content }
  } catch (err) {
    error.value = err instanceof Error ? err.message : String(err)
  }
}

onMounted(async () => {
  if (isEdit.value) {
    loading.value = true
    try {
      await agentTeamStore.fetchAgent(agentId.value)
      const agent = agentTeamStore.currentAgent
      if (agent) {
        name.value = agent.name || ''
        description.value = agent.description || ''
        model.value = agent.model || ''
        const extra = agent as Record<string, unknown>
        selectedTemplateId.value = (extra.templateId as string) || ''
      }
      await loadSettingFiles()
    } finally {
      loading.value = false
    }
  }
})

async function handleSubmit() {
  if (!name.value.trim()) return
  submitting.value = true
  try {
    error.value = ''
    if (isEdit.value) {
      const updates: Record<string, unknown> = {
        name: name.value,
        description: description.value,
        model: model.value,
      }
      if (selectedTemplateId.value) updates.templateId = selectedTemplateId.value
      await agentTeamStore.updateAgent(agentId.value, updates)
    } else {
      // 决策 1：创建态不提交设定（后端 create 不持久化设定，设定经编辑态 Gateway 文件生效）
      await agentTeamStore.createAgent({
        name: name.value,
        description: description.value,
        model: model.value,
        templateId: selectedTemplateId.value,
        avatar: selectedTemplate.value?.avatar || '🤖',
        category: selectedTemplate.value?.category || '',
      })
    }
    router.push('/m/agents')
  } catch (err) {
    error.value = err instanceof Error ? err.message : String(err)
  } finally {
    submitting.value = false
  }
}
</script>
```

- [ ] **Step 2: 引入 categoryAccent 工具**

上一步已用 `categoryAccentOf` 包装。需在 `<script setup>` import 区补充（紧跟 `apiPath` import 之后）：

```ts
import { categoryAccent } from '@/mobile/utils/category-accent'
```

> 同时删除原文件不再使用的 import：`getAllTemplates`（仍用，保留）、`isImageAvatar`、`resolveAgentAvatar`、`categoryAccent`（旧直接引用）、`soulMd` ref 等。最终 import 区保留：`getAllTemplates`(实际可删，改用 getTemplateById；但保留无害)、`getTemplateById`、`categoryAccent`、`apiPath`、`useAuthStore`、`useWebSocketStore`、两个子组件。

- [ ] **Step 3: 替换模板选择 section（创建态）为 MobileTemplatePicker**

模板 `<template>` 内，将原「Template selection」整个 `<section v-if="!isEdit">...</section>`（含 `.tpl-grid` 内联）替换为：

```vue
        <section v-if="!isEdit" class="sec" style="animation-delay: 40ms">
          <div class="sec-head">
            <span class="sec-bar" :style="{ background: heroAccent.bar }" />
            <h2>{{ t('pages.mobile.agents.selectTemplate') }}</h2>
            <span class="sec-hint">{{ t('pages.mobile.agents.templateHint') }}</span>
          </div>
          <MobileTemplatePicker
            :selected-id="selectedTemplateId"
            @select="onTemplateSelect"
          />
        </section>
```

- [ ] **Step 4: 替换「角色配置」section 为「设定」+ MobileSettingSection**

将原「Role config (optional)」整个 `<section>...</section>`（含 soulMd textarea）替换为：

```vue
        <section class="sec" :style="{ animationDelay: isEdit ? '90ms' : '140ms' }">
          <div class="sec-head">
            <span class="sec-bar" :style="{ background: heroAccent.bar }" />
            <h2>{{ t('pages.mobile.agents.setting') }}</h2>
            <span v-if="!isEdit" class="sec-hint">{{ t('pages.mobile.agents.templateHint') }}</span>
          </div>
          <MobileSettingSection
            :mode="isEdit ? 'edit' : 'create'"
            :files="settingSource"
            @edit="onSettingEdit"
          />
        </section>
```

- [ ] **Step 5: 删除不再使用的旧样式**

`<style scoped>` 中删除仅服务于内联模板网格的 `.tpl-grid` / `.tpl` / `.tpl-accent` / `.tpl-avatar` / `.tpl-avatar.image` / `.tpl-avatar-img` / `.tpl-name` / `.tpl-check` / `.tpl.selected*` 规则块（已迁移到 `MobileTemplatePicker.vue`）。保留 `.sec` / `.sec-head` / `.sec-bar` / `.field*` / `.submit-*` / `@keyframes` 等通用样式。

- [ ] **Step 6: 构建验证**

Run: `npm run build`
Expected: 通过（vue-tsc 无未使用变量/类型错误；删除的 import 已清理）。

- [ ] **Step 7: 手动验证要点**

启动 `./start.sh`，手机端 `/m/agents` 进入：

1. **创建态**：
   - 点创建 → 模板区有「精选/全部」两个 chip tab，切换列表变化；精选 11 个、全部 30 个（不再只有 12 个）。
   - 选模板 → 名称/描述自动填；展开任一设定卡片，内容为模板自带的 markdown 渲染预览，**无「编辑」按钮**（只读）。
   - 提交 → 跳回列表，新员工出现。
2. **编辑态**：
   - 进编辑 → 无模板区；设定卡片可展开预览，**有「编辑」按钮**。
   - 点编辑 → 全屏覆盖层滑入，textarea 显示原内容；改后点保存 → 覆盖层关闭，卡片预览刷新为新内容。
   - 重新进入编辑页 → 确认上次保存的内容已持久（Gateway 文件）。
3. **设定标题**显示为「设定」（非「角色配置」）。

- [ ] **Step 8: Commit**

```bash
git add src/mobile/views/agents/MobileAgentEditPage.vue
git commit -m "feat(mobile): 编辑页接入模板选择/设定区，对齐网页端能力"
```

---

## Self-Review（计划 vs Spec 覆盖核对）

**Spec 需求覆盖：**
- 需求 1（模板补齐 + 精选/全部分类）→ Task 4（组件）+ Task 6 Step 3（接入），删除 `slice(0,12)`。✓
- 需求 2（设定四文件 + 改名「设定」+ 描述）→ Task 1（常量含 label/desc）+ Task 5（渲染 4 卡片 + 描述）+ Task 2（`setting` key）+ Task 6 Step 4（标题用 `setting`）。✓
- 需求 3（markdown 预览 + 编辑模式 + 可展开）→ Task 3（覆盖层）+ Task 5（折叠卡片 + renderMarkdown 预览 + 编辑调起）+ Task 6 Step 7（手动验证三态）。✓
- 架构决策 1（创建只读/编辑可改）→ Task 5 `mode` prop + Task 6 `settingSource`/`onSettingEdit`/createAgent 不提交设定。✓
- 架构决策 2（只精选/全部）→ Task 4 `tab` 仅 featured/all。✓
- 架构决策 3（折叠 + 全屏覆盖层）→ Task 3 + Task 5。✓
- 共享常量单一权威 → Task 1 + Task 5 复用。✓
- 边界（不动后端）→ Task 6 createAgent 仅传既有字段，无后端改动。✓

**类型/命名一致性：**
- `AGENT_SETTING_FILES` / `AGENT_SETTING_BY_FILE`（Task 1 定义）= Task 5 引用名。✓
- `MobileMarkdownEditorOverlay` props `{visible,title,value}` emit `{save,cancel}`（Task 3 定义）= Task 5 使用。✓
- `MobileSettingSection` props `{mode,files}` emit `{edit}`（Task 5 定义）= Task 6 使用。✓
- `MobileTemplatePicker` props `{selectedId}` emit `{select}`（Task 4 定义）= Task 6 使用。✓
- `settingSource` / `settingFiles` / `createFiles` / `onSettingEdit` / `onTemplateSelect`（Task 6 定义）= 模板引用。✓

**Placeholder 扫描：** 无 TBD/TODO/"添加适当错误处理"等；每个代码步骤含完整可执行代码。✓

**遗留项说明：**
- Task 2 新增 key 后，原 `roleConfig` / `soulLabel` 在 Task 6 后无引用。删除它们属可选清理（执行者可顺手删，或单独 commit），非阻塞。
- `common.featured` / `common.all` 假定已存在（网页端 `CATEGORY_CONFIGS` 在用）；若 build 报缺失，Task 4 前需先在 `common` 命名空间补这两个 key。
