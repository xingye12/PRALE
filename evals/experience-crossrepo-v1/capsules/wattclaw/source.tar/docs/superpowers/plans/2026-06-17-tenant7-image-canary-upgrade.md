# tenant-7 镜像原位灰度升级 实施计划

> **本计划为运维 Runbook,由用户(任鸣)在测试服务器 `/home/wattman/wattclaw-test` 上手动逐 Task 执行。**
> 计划作者(Claude)**不执行任何写/破坏性操作**(cp / docker rm / docker run / restart / 改 .env),仅产出可执行命令。
> 所有 checkbox(`- [ ]`)供用户逐步勾选。
> 关联设计:`docs/superpowers/specs/2026-06-17-tenant7-image-canary-upgrade-design.md`。
> **2026-06-17 修订**:基于 ssh 勘察实测修正(entrypoint/网络/lark patch 三处),已标注 `[实测]`。

**Goal:** 把 tenant-7 容器从 `ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64` 原位灰度替换为 `alpine/openclaw:2026.6.6-browser`,挂载数据副本 `tenant-7-v2` 实现**数据隔离**,在 web(WattClaw)+ 飞书双渠道验证镜像兼容,失败可秒回滚。

**Architecture:** 方案 C —— 手动起同名容器 `openclaw-tenant-7`(新镜像 + 挂 `tenant-7-v2` 副本 + **不带 `openclaw.gateway.managed` label**)。Manager(`server/core/multi-tenant-gateway.js`)在 `shouldRecreateTenantContainer:746` 检测到无 managed label → 不重建(数据隔离不被漂移),但 `ensureTenantContainer:682` 仍调 `ensureLarkPluginForTenantContainer:754`(**不查 label**)→ lark patch 自动注入(实测自带 `/app` 回退命中)。原位 + 隔离 + 自动 patch 三者兼得。

**Tech Stack:** Docker、bind mount、`docker inspect` + `jq` + `sed`(从原容器存档动态生成新容器启动参数)、Manager 多租户代码逃生口。

---

## 执行约定(务必先读)

1. **谁执行**:全部写操作由用户在服务器手动跑;Claude 只给命令、不跑。
2. **数据源单一**:Task 0 把原容器完整 inspect 存到 `/tmp/tenant7-original-inspect.json`,后续 Task 3(起 v2)与 Task 7B(回滚)都从这一份存档 `jq` 提取 → DRY,避免手工抄错。
3. **脱敏**:`openclaw.json` 含模型 token / 飞书 account 凭据。本计划**从不打印其内容**(只 `cp` 整文件、`docker inspect` 看路径不看值)。任何 `cat openclaw.json` / 日志贴回会话前,用户自行打码。
4. **`.env` 零改动**:方案 C 全程不碰 `.env`(见 spec §10)。lark patch 经实测(spec §7.2)`buildLarkPatchCommand` 自带 `/app` 回退,新镜像已命中 monitor 文件,**无需碰环境变量**。
5. **路径无空格假设**:`$VOLS`/`$ENVS` 用 bash 数组展开,bind/env 元素含 `:` 安全;若发现 env 值含空格,数组版已处理(见 Task 3)。

## 前置事实(已 ssh 勘察实测确认)

| 项 | 值 |
|---|---|
| 容器名 | `openclaw-tenant-7` |
| data_source | `/home/wattman/wattclaw-test/tenants/tenant-7` |
| 副本目标 | `/home/wattman/wattclaw-test/tenants/tenant-7-v2` |
| CPU 亲和 | 核 6(`cpuset-cpus=6`)[实测] |
| 内存 / 配额 | 8 GiB / 4 CPU(`NanoCpus=4e9`)[实测] |
| 网络 | `multi-openclaw-net`(ip 172.66.0.9,容器名寻址 `http://openclaw-tenant-7:18789`)[实测] |
| Entrypoint | `["tini","-s","--"]`[实测;新镜像 2026.6.6 **同为** `tini -s --`] |
| Cmd | `node openclaw.mjs gateway --allow-unconfigured`[实测;新镜像默认 Cmd **少** `--allow-unconfigured`,必须显式传] |
| Labels | `openclaw.gateway.managed=true`、`openclaw.gateway.tenant-id=tenant-7`[实测] |
| 当前镜像 | `ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64` |
| 目标镜像 | `alpine/openclaw:2026.6.6-browser` |
| 绑定账户 | 任鸣(`19892815440`,20 满载用户,测试数据) |
| jq | 服务器有 `/usr/bin/jq`[实测] |

## 挂载映射核对基准(spec §5,已实测 10 条逐字一致)

**A 类(tenant-7 专属,8 条,宿主源含 `/tenants/tenant-7` 前缀 → sed 换成 `/tenants/tenant-7-v2`)**
`/home/node/.openclaw`、`/home/wattman/.openclaw`、`/home/node/openclaw.json`、`/home/node/.config`、`/home/node/.cache`、`/home/node/.local/share`、`/home/node/.local/state`、`/tmp/openclaw`

**B 类(全局共享,2 条,宿主源不含 `/tenants/tenant-7` → sed 不动)**
`/home/wattman/.openclaw/agents` → `/home/node/.openclaw/agents`;`/home/wattman/.wattclaw` → `/home/wattman/.wattclaw`

> 替换规则安全性:A 类源均以 `/home/wattman/wattclaw-test/tenants/tenant-7` 开头;B 类共享源与所有容器内目标(`/home/node/...`)均**不含** `/tenants/tenant-7` 子串 → 全局 `sed 's|/tenants/tenant-7|/tenants/tenant-7-v2|g'` 精确只换 A 类,不误伤。

---

## Task 0:前置勘察 + 存档原容器配置 + 预检新镜像

**受影响对象**:只读(无写操作);产出 `/tmp/tenant7-original-inspect.json` 存档。
> **[实测] 本 Task 已由 Claude ssh `openclaw` 代为勘察完成**(见会话记录),结论已并入「前置事实」表与 spec §7.2。用户若要复核,按下列步骤重跑(全只读)。

- [ ] **Step 0.1:确认服务器路径与容器状态**

```bash
cd /home/wattman/wattclaw-test
docker ps --filter name=openclaw-tenant-7 --format '{{.Names}}\t{{.Image}}\t{{.Status}}'
```
预期:`openclaw-tenant-7   ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64   Up ... (healthy)`[实测 Up 17h healthy]

- [ ] **Step 0.2:确认 jq 可用**

```bash
command -v jq || echo "JQ_MISSING"
```
预期:`/usr/bin/jq`[实测已存在]。若 `JQ_MISSING`:`sudo apt-get install -y jq`,无 jq 不要继续。

- [ ] **Step 0.3:拉取新镜像(用户已完成)**

```bash
docker image ls alpine/openclaw:2026.6.6-browser
```
预期:镜像存在(用户已放到服务器)。

- [ ] **Step 0.4:存档原容器完整配置(单一数据源)**

```bash
docker inspect openclaw-tenant-7 > /tmp/tenant7-original-inspect.json
ls -l /tmp/tenant7-original-inspect.json
jq '.[0].Name, .[0].Config.Image' /tmp/tenant7-original-inspect.json
```
预期:文件存在;Name=`/openclaw-tenant-7`,Image=`ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64`。

- [ ] **Step 0.5:从存档核对关键字段(对照「前置事实」表)**

```bash
echo "== Binds =="; jq -r '.[0].HostConfig.Binds[]' /tmp/tenant7-original-inspect.json
echo "== Env(只看KEY,脱敏值)=="; jq -r '.[0].Config.Env[]' /tmp/tenant7-original-inspect.json | cut -d= -f1
echo "== Entrypoint =="; jq '.[0].Config.Entrypoint' /tmp/tenant7-original-inspect.json
echo "== Cmd =="; jq -r '.[0].Config.Cmd | join(" ")' /tmp/tenant7-original-inspect.json
echo "== 资源 =="; jq '{CpusetCpus:.HostConfig.CpusetCpus, Memory:.HostConfig.Memory, NanoCpus:.HostConfig.NanoCpus, NetworkMode_field:.HostConfig.NetworkMode, RealNetworks:(.NetworkSettings.Networks|keys), RestartPolicy:.HostConfig.RestartPolicy}' /tmp/tenant7-original-inspect.json
echo "== Labels =="; jq '.[0].Config.Labels' /tmp/tenant7-original-inspect.json
```
预期核对[实测值]:
- Binds = 10 条(8 条 `/tenants/tenant-7` A 类 + 2 条共享 B 类),逐字匹配「挂载映射」。
- Entrypoint = `["tini","-s","--"]`(非 null)。Cmd = `node openclaw.mjs gateway --allow-unconfigured`。
- 资源:CpusetCpus=`"6"`,Memory≈8589934592(8GiB),NanoCpus=`4000000000`(4核),**`NetworkMode_field`=`bridge`(误导!真实 `RealNetworks`=`["multi-openclaw-net"]`)**,RestartPolicy.Name=`unless-stopped`。
- Labels 含 `openclaw.gateway.managed=true`、`openclaw.gateway.tenant-id=tenant-7`(回滚时需还原这两个;其余 `org.opencontainers.image.*` 是镜像自带,新镜像会自带新值,不手动还原)。
- Env KEY 无 tenant-7 路径引用(路径只在 binds,env 逐字复制安全)。

- [ ] **Step 0.6:预检新镜像 lark dist 定位(实测:回退命中,无需改环境)**

```bash
docker run --rm --entrypoint sh alpine/openclaw:2026.6.6-browser -c '
ROOT=$(npm root -g 2>/dev/null); echo "npm_root=$ROOT (注意新镜像 dist 实际在 /app/node_modules/openclaw/dist)";
echo "=== 模拟 buildLarkPatchCommand 回退 find+grep(定位飞书 monitor)===";
found="$(find /home/node/.npm-global/lib/node_modules /usr/local/lib/node_modules /app -type f -path "*/dist/monitor-*.js" 2>/dev/null | while IFS= read -r f; do
  if grep -qE "monitorFeishuProvider|extensions/feishu/src/monitor.ts|feishu: starting" "$f"; then echo "$f"; break; fi
done)"; echo "命中: ${found:-(未命中)}"'
```
预期[实测]:命中 `/app/node_modules/openclaw/dist/monitor-B5WoSBtp.js` → **patch 回退能定位飞书 monitor,会执行覆盖,无需改 `OPENCLAW_DIST_MONITOR_TARGET`**(详见 spec §7.2)。若命中为空才需进 Task 4.3 评估。

**✅ Task 0 检查点**:`/tmp/tenant7-original-inspect.json` 存在;字段核对通过;新镜像 patch 回退命中 monitor 文件。

---

## Task 1:创建数据副本 tenant-7-v2(数据隔离的核心)

**受影响对象**:`/home/wattman/wattclaw-test/tenants/tenant-7-v2/`(新建副本);原 `tenant-7/` 不动。

- [ ] **Step 1.1:确认磁盘空间足够容纳第二份副本**

```bash
SRC=/home/wattman/wattclaw-test/tenants/tenant-7
du -sh "$SRC"; df -h /home/wattman/wattclaw-test
```
预期:`du` 给出 tenant-7 体积;`df` 的 Avail 至少 ≥ 该体积(留 20% 余量)。不够先清空间。

- [ ] **Step 1.2:完整副本(保留权限/属主/符号链接/时间)**

```bash
SRC=/home/wattman/wattclaw-test/tenants/tenant-7
DST=/home/wattman/wattclaw-test/tenants/tenant-7-v2
cp -a "$SRC" "$DST"
```
`-a` = 归档模式(递归 + 保留权限/属主/链接/时间)。**原目录纹丝不动**。

- [ ] **Step 1.3:验证副本完整性(条目数 + 体积一致)**

```bash
SRC=/home/wattman/wattclaw-test/tenants/tenant-7
DST=/home/wattman/wattclaw-test/tenants/tenant-7-v2
echo "源条目数:$(find "$SRC" | wc -l)  副本条目数:$(find "$DST" | wc -l)"
echo "源大小:$(du -sb "$SRC" | cut -f1)  副本大小:$(du -sb "$DST" | cut -f1)"
ls -l "$DST/openclaw.json"
```
预期:源/副本条目数相等;字节数相等(或差异极小,可接受);`tenant-7-v2/openclaw.json` 存在。

**✅ Task 1 检查点**:`tenant-7-v2/` 存在且与源体积/条目一致;`tenant-7-v2/openclaw.json` 存在。

---

## Task 2:停止并删除原容器(bind mount 数据不丢)

**受影响对象**:容器 `openclaw-tenant-7`(删除);宿主目录 `tenant-7/` 数据完好。

- [ ] **Step 2.1:删除原容器(数据在 bind mount 宿主目录,不受影响)**

```bash
docker rm -f openclaw-tenant-7
docker ps -a --filter name=openclaw-tenant-7 --format '{{.Names}}'
```
预期:第二条**无输出**(容器已不存在)。

- [ ] **Step 2.2:确认原数据目录完好**

```bash
ls -ld /home/wattman/wattclaw-test/tenants/tenant-7
du -sh /home/wattman/wattclaw-test/tenants/tenant-7
```
预期:目录仍在,体积与 Task 1.1 一致(bind mount 删容器不碰宿主文件)。

**✅ Task 2 检查点**:原容器已删;`tenant-7/` 原数据完好(回滚的底气)。

---

## Task 3:启动新容器(新镜像 + 挂 tenant-7-v2 副本 + 无 managed label)

**受影响对象**:新建容器 `openclaw-tenant-7`(同名顶替,网络/控制面/飞书寻址不变)。
**核心**:binds/env/cmd/资源**全部从 Task 0 存档 `jq` 提取逐字复制**;entrypoint 用新镜像自带(实测与 beta.2 一致 `tini -s --`,不显式传);只改 ① Image→新镜像 ② A 类 binds 源 `tenant-7`→`tenant-7-v2`(sed)③ NET 从 `NetworkSettings.Networks` 取(非误导的 `HostConfig.NetworkMode`)④ **不加** managed label。

- [ ] **Step 3.1:生成启动命令并 dry-run 预览(先看后跑)**

```bash
ORIG=/tmp/tenant7-original-inspect.json

# --- 资源(NET 从 NetworkSettings 取真实网络;HostConfig.NetworkMode=bridge 是误导)---
CPUSET=$(jq -r '.[0].HostConfig.CpusetCpus // empty' "$ORIG")
MEM=$(jq -r '.[0].HostConfig.Memory // 0' "$ORIG")
NANOCPU=$(jq -r '.[0].HostConfig.NanoCpus // 0' "$ORIG")
CPUS=$(awk "BEGIN{printf \"%g\", $NANOCPU/1e9}")
NET=$(jq -r '.[0].NetworkSettings.Networks | keys[0] // "bridge"' "$ORIG")  # 实测=multi-openclaw-net

# --- Cmd(用原容器值,带 --allow-unconfigured;新镜像默认 Cmd 少此 flag 必须显式传)---
# Entrypoint 不取:新镜像 entrypoint 实测 = ["tini","-s","--"],与 beta.2 一致 → 用镜像自带,不传 --entrypoint
CMD=$(jq -r '.[0].Config.Cmd | join(" ")"' "$ORIG")

# --- Binds:A 类源换 tenant-7-v2,B 类共享不动 ---
mapfile -t VOL_ARR < <(jq -r '.[0].HostConfig.Binds[]' "$ORIG" | sed 's|/tenants/tenant-7|/tenants/tenant-7-v2|g')

# --- Env:逐字取自原容器(脱敏,只预览 KEY)---
mapfile -t ENV_ARR < <(jq -r '.[0].Config.Env[]' "$ORIG")

echo "== 预览 binds(已换源;应全部指向 tenant-7-v2,共享项除外)==" 
printf '%s\n' "${VOL_ARR[@]}"
echo "== 预览资源 =="; echo "cpuset=$CPUSET mem=$MEM cpus=$CPUS net=$NET"
echo "== 预览 cmd=[$CMD](entrypoint 用镜像自带 tini -s --,实测一致) =="
echo "== 预览 env KEY =="; printf '%s\n' "${ENV_ARR[@]}" | cut -d= -f1
```
预期核对:
- VOL_ARR 中 A 类源全部变 `/tenants/tenant-7-v2/...`;B 类(`/home/wattman/.openclaw/agents`、`/home/wattman/.wattclaw`)保持原样。
- 资源 `cpuset=6 mem=8589934592 cpus=4 net=multi-openclaw-net`。
- CMD=`node openclaw.mjs gateway --allow-unconfigured`。

> **校验脚本(确认无 managed label 残留 + A 类全换源 + B 类未误伤):**
```bash
echo "残留旧源(应为空):"; printf '%s\n' "${VOL_ARR[@]}" | grep '/tenants/tenant-7:' || echo "OK 无残留"
echo "共享项是否被误改(应原样):"; printf '%s\n' "${VOL_ARR[@]}" | grep -E '\.openclaw/agents|\.wattclaw'
```
预期:第一段输出 `OK 无残留`;第二段显示两条共享挂载源仍是 `/home/wattman/...`(未被 sed 改动)。

- [ ] **Step 3.2:执行启动(确认预览无误后)**

```bash
ORIG=/tmp/tenant7-original-inspect.json
CPUSET=$(jq -r '.[0].HostConfig.CpusetCpus // empty' "$ORIG")
MEM=$(jq -r '.[0].HostConfig.Memory // 0' "$ORIG")
NANOCPU=$(jq -r '.[0].HostConfig.NanoCpus // 0' "$ORIG")
CPUS=$(awk "BEGIN{printf \"%g\", $NANOCPU/1e9}")
NET=$(jq -r '.[0].NetworkSettings.Networks | keys[0] // "bridge"' "$ORIG")  # 实测=multi-openclaw-net(不用误导的 HostConfig.NetworkMode)
CMD=$(jq -r '.[0].Config.Cmd | join(" ")"' "$ORIG")  # node openclaw.mjs gateway --allow-unconfigured
mapfile -t VOL_ARR < <(jq -r '.[0].HostConfig.Binds[]' "$ORIG" | sed 's|/tenants/tenant-7|/tenants/tenant-7-v2|g')
mapfile -t ENV_ARR < <(jq -r '.[0].Config.Env[]' "$ORIG")

docker run -d \
  --name openclaw-tenant-7 \
  --restart unless-stopped \
  ${CPUSET:+--cpuset-cpus "$CPUSET"} \
  --memory "$MEM" \
  --cpus "$CPUS" \
  --network "$NET" \
  "${VOL_ARR[@]/#/-v }" \
  "${ENV_ARR[@]/#/-e }" \
  alpine/openclaw:2026.6.6-browser \
  $CMD
```
> 关键差异(相对原容器,逐项确认):① 镜像 `alpine/openclaw:2026.6.6-browser`;② binds 源 `tenant-7`→`tenant-7-v2`;③ **不加** `--label openclaw.gateway.managed=true` / `openclaw.gateway.tenant-id=tenant-7` → Manager 视为非托管,不漂移重建(spec §3.4 / `shouldRecreateTenantContainer:746`)。其余逐字复制原容器。
> Entrypoint:新镜像 2026.6.6 自带 `["tini","-s","--"]`(实测,与 beta.2 一致),故**不传 `--entrypoint`**,用镜像自带。CMD 显式传原值 `node openclaw.mjs gateway --allow-unconfigured`(新镜像默认 Cmd 少此 flag,必须显式)。

- [ ] **Step 3.3:健康检查(容器运行 + 入网 + 端口监听 + 启动日志无致命错)**

```bash
docker ps --filter name=openclaw-tenant-7 --format '{{.Names}}\t{{.Image}}\t{{.Status}}'
docker inspect openclaw-tenant-7 --format '网络={{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}'  # 应为 multi-openclaw-net
docker logs --tail 50 openclaw-tenant-7
# 容器名寻址可达(从同网络 multi-openclaw-net 的 openclaw-web 容器内探测)
docker exec openclaw-web sh -c 'wget -qO- http://openclaw-tenant-7:18789/ 2>&1 | head -c 200 || echo "端口未就绪或路径 404(正常,看是否 TCP 通)"'
```
预期:`docker ps` 显示新镜像 + `Up`;网络=`multi-openclaw-net`;日志无 panic/退出栈、无 openclaw.json schema 解析致命错(spec §7.1);端口探测有响应(200 或 404 都算 TCP 通;连接拒绝=网络/启动问题)。
> 若日志报 openclaw.json schema 错(spec §7.1):**改的是副本** `tenant-7-v2/openclaw.json`(原文件不动)。按报错/OpenClaw changelog 修副本后 `docker restart openclaw-tenant-7`。

**✅ Task 3 检查点**:新容器 `openclaw-tenant-7` 运行(新镜像),网络=multi-openclaw-net,挂载源全部 `tenant-7-v2`,无 managed label,端口可达,启动日志干净。

---

## Task 4:触发并验证 lark patch 自动注入

**受影响对象**:Manager 进程(`openclaw-web` 容器内)对 tenant-7 的 patch 注入。
**机制**:`ensureTenantContainer:682` → `ensureLarkPluginForTenantContainer:754`,**不检查 managed label**,故非托管容器也注入(spec §3.4)。
**实测前提(spec §7.2)**:`buildLarkPatchCommand`(`:1141`)对 dist monitor 自带 `/app` 回退 + feishu 特征 grep,新镜像已**实测命中** `/app/node_modules/openclaw/dist/monitor-B5WoSBtp.js` → patch 会执行覆盖,无需改环境变量。

- [ ] **Step 4.1:触发 Manager 重新 reconcile tenant-7(最可靠=重启 openclaw-web)**

```bash
docker restart openclaw-web
docker logs --tail 5 openclaw-web  # 确认重启完成
```
> 影响:openclaw-web 重启时 `_bootstrap:156-167` 遍历全量租户(含 tenant-7),对每个调 `ensureTenantContainer`。对 tenant-7:容器已存在 + 无 managed label → `shouldRecreateTenantContainer` 返回 false(不重建)→ 但仍执行 `:682` 注入 lark patch。测试环境其余 8 租户同样 reconcile,短暂无感。

- [ ] **Step 4.2:确认 lark patch 注入成功(关注 dist 覆盖目标 + 插件层)**

```bash
docker logs --tail 300 openclaw-web 2>&1 | grep -iE 'lark|patch|tenant-7|monitor' | tail -40
```
预期[实测命中后]:出现两条关键日志:
- `[lark] patched OpenClaw dist: /app/node_modules/openclaw/dist/monitor-B5WoSBtp.js`(回退命中,dist 覆盖成功)
- `[lark] plugin patches applied`(插件层 owner-policy/oauth/onboarding-auth/channel/monitor.js 覆盖成功)
> 若**只有** `plugin patches applied` **无** dist 行 → dist 覆盖未命中(双 monitor 文件场景:含 feishu 特征的有 `monitor-B5WoSBtp.js` 与 `/app/dist/monitor-BFQGKXpb.js`,patch `find break` 取第一个,运行时可能加载另一个)。此时飞书**定制功能**可能受影响,但**不阻塞 web(Task 5)**,留 Task 6 飞书验证定论。

- [ ] **Step 4.3(条件分支):飞书定制功能运行时验证(在 Task 6 一并判定)**

patch 已注入(回退命中)后:
- **飞书基础收发不依赖 patch**(OpenClaw 原生支持飞书)→ 大概率通。
- **WattClaw 飞书定制**(owner 多租户归属 / onboarding / OAuth)依赖 patch → 需 Task 6 实测。
  - 收发正常 + 定制功能符合预期 → patch 适配 OK,升级通过。
  - 基础收发通但定制异常 → patch 的 dist 覆盖(旧 `monitor-Bog7UNtj.js` 覆盖新 `monitor-B5WoSBtp.js`)版本不兼容。适配点:更新 `openclaw-lark-patches/monitor-Bog7UNtj.js` 到 2026.6.6 兼容版,或调整 `buildLarkPatchCommand` 的 find 选择(改代码,非运维,本次灰度外,记技术债)。

**✅ Task 4 检查点**:Manager 已 reconcile tenant-7;lark patch 日志出现 dist 覆盖 + plugin applied;若 dist 未命中已记录,留 Task 6 飞书验证定论。

---

## Task 5:web 渠道(WattClaw)验证

**受影响对象**:无(纯功能验证)。验证路由 `WattClaw → openclaw-tenant-7:18789 → 新容器(挂 v2)`。

- [ ] **Step 5.1:任鸣(`19892815440`)登录 WattClaw**

浏览器开 WattClaw,用任鸣账户登录。预期:登录成功,能看到该租户下的会话/agent 列表。

- [ ] **Step 5.2:发消息收流式回复**

新建/打开一个会话,发一条测试消息(如"你好,确认连通")。预期:收到**正常流式回复**(非空、非报错、非卡死)。

- [ ] **Step 5.3:历史会话回读**

打开一条历史会话。预期:历史消息能正常回读(证明 2026.6.6 能读 beta.2 生成的会话数据,spec §7.3)。

- [ ] **Step 5.4:agent / skill 调用正常**

触发一个 agent 或 skill 调用。预期:调用链路正常,结果返回。

**✅ Task 5 检查点**:web 渠道发消息/流式/历史回读/agent-skill 四项全过。

---

## Task 6:飞书渠道验证

**受影响对象**:无(纯功能验证)。account 配置在 `tenant-7-v2/openclaw.json` 副本,容器名不变 → 飞书 bot 寻址无缝。

- [ ] **Step 6.1:任鸣在原飞书 bot 发消息**

在 tenant-7 绑定的原飞书 bot 会话里发一条测试消息。预期:bot 正常收发(消息进、流式/文本回复出)。

- [ ] **Step 6.2:确认飞书侧无 bot 冲突/失联 + 定制功能**

预期:无"bot 失联""account 配置错误"类报错;容器名未变,飞书 webhook 回调地址无缝命中新容器。同时确认 WattClaw 飞书定制(onboarding / owner 多租户隔离)行为符合预期。

> 若**基础收发失败** → 查 `tenant-7-v2/openclaw.json` 飞书 account 配置是否随副本完整迁移(Task 1.3 已验文件存在,此处验内容生效),或容器名/webhook 寻址问题。
> 若**基础收发通但定制异常** → 回 Task 4.3,属 patch dist 覆盖版本兼容问题(spec §7.2),非运维可解,需更新 patch 源(技术债)。

**✅ Task 6 检查点**:飞书 bot 基础收发 + WattClaw 定制功能均符合预期。

---

## Task 7:收尾(成功归档)或回滚(失败还原)

### 7A. 成功路径(双渠道均过)

- [ ] **Step 7A.1:记录验证结论**

记录:tenant-7 在 `alpine/openclaw:2026.6.6-browser` + v2 副本下,web + 飞书双渠道通过 → 镜像兼容,可作批量升级依据。

- [ ] **Step 7A.2:原 tenant-7 目录处置(后续决策,非本步必做)**

原 `tenant-7/`(旧数据)此刻未被任何容器挂载(v2 副本在跑)。**不要立即删** —— 先保留作为回滚兜底,待批量升级稳定后再归档/清理。是否后续把新容器正式交还 Manager 托管(迁移 dataSource / 加回 managed label)属后续架构决策(spec §10 风险项),不在本 Runbook。

### 7B. 失败回滚(秒回滚:挂回原 tenant-7 + beta.2 + 加回 managed label)

**受影响对象**:删 v2 容器 → 起回 beta.2 容器挂原目录 + 恢复 Manager 托管。

- [ ] **Step 7B.1:删除新容器(挂 v2 的)**

```bash
docker rm -f openclaw-tenant-7
```

- [ ] **Step 7B.2:用 Task 0 存档还原原容器(挂回原 tenant-7 + beta.2 + 加回 managed label)**

```bash
ORIG=/tmp/tenant7-original-inspect.json
CPUSET=$(jq -r '.[0].HostConfig.CpusetCpus // empty' "$ORIG")
MEM=$(jq -r '.[0].HostConfig.Memory // 0' "$ORIG")
NANOCPU=$(jq -r '.[0].HostConfig.NanoCpus // 0' "$ORIG")
CPUS=$(awk "BEGIN{printf \"%g\", $NANOCPU/1e9}")
NET=$(jq -r '.[0].NetworkSettings.Networks | keys[0] // "bridge"' "$ORIG")  # multi-openclaw-net
CMD=$(jq -r '.[0].Config.Cmd | join(" ")"' "$ORIG")  # node openclaw.mjs gateway --allow-unconfigured
# 回滚:binds 用【原始】(不 sed,挂回 tenant-7 原目录);entrypoint 用镜像自带(beta.2 同 tini -s --)
mapfile -t VOL_ARR < <(jq -r '.[0].HostConfig.Binds[]' "$ORIG")
mapfile -t ENV_ARR < <(jq -r '.[0].Config.Env[]' "$ORIG")
IMG=$(jq -r '.[0].Config.Image' "$ORIG")  # beta.2
TID=$(jq -r '.[0].Config.Labels["openclaw.gateway.tenant-id"] // "tenant-7"' "$ORIG")  # 实测键名+值

docker run -d \
  --name openclaw-tenant-7 \
  --restart unless-stopped \
  ${CPUSET:+--cpuset-cpus "$CPUSET"} \
  --memory "$MEM" --cpus "$CPUS" --network "$NET" \
  --label openclaw.gateway.managed=true \
  --label "openclaw.gateway.tenant-id=$TID" \
  "${VOL_ARR[@]/#/-v }" \
  "${ENV_ARR[@]/#/-e }" \
  "$IMG" \
  $CMD
```
> 与 Task 3.2 的差异:① binds **不 sed**(挂回原 `tenant-7`);② 镜像用存档原镜像(`$IMG`=beta.2);③ **加回** `--label openclaw.gateway.managed=true` + `--label openclaw.gateway.tenant-id=<存档值=tenant-7>`(恢复 Manager 托管)。entrypoint 仍用镜像自带(不传 `--entrypoint`)。其余逐字。

- [ ] **Step 7B.3:回滚后健康检查 + Manager 托管恢复**

```bash
docker ps --filter name=openclaw-tenant-7 --format '{{.Names}}\t{{.Image}}\t{{.Status}}'
docker inspect openclaw-tenant-7 --format '{{.Config.Labels}}'
docker restart openclaw-web   # 让 Manager 重新 reconcile,确认托管正常
docker logs --tail 30 openclaw-web 2>&1 | grep -i tenant-7
```
预期:容器 Up + 镜像=beta.2 + Labels 含 `openclaw.gateway.managed=true` / `openclaw.gateway.tenant-id=tenant-7`;Manager 日志显示 tenant-7 正常托管、无重建异常。

**✅ Task 7B 检查点**:已回滚到 beta.2 + 原 tenant-7 数据 + Manager 托管恢复,等同升级前状态。原数据 bind mount 全程未动,零损失。

---

## 附录 A:数据流一览(执行时心里有数)

```
原态:  openclaw-tenant-7(beta.2) ─挂─> tenant-7/   ← Manager 托管(managed=true)
Task1: cp -a tenant-7 → tenant-7-v2/
Task2: rm -f 旧容器   (tenant-7/ 数据不动)
Task3: openclaw-tenant-7(2026.6.6) ─挂─> tenant-7-v2/  ← 无 managed label(Manager 不重建,仍注入 lark)
Task4: Manager reconcile → 自动注入 lark patch(回退命中 monitor-B5WoSBtp.js)
Task5/6: web + 飞书双渠道验证
Task7A: 成功归档         Task7B: 失败 → rm v2容器 → beta.2 挂 tenant-7 + 加回 managed label
```

## 附录 B:风险与红线回顾(spec §10)

- **数据隔离兜底**:最坏 v2 副本读不了 / 写坏,**不影响原 tenant-7**,不阻塞其余 8 租户。
- **不带 managed label 的副作用**:Manager 视新容器为非托管,不会漂移重建(预期);后续若要正式托管需迁移 dataSource(本次不做)。
- **`.env` 零改动**:方案 C 全程不碰 `.env`;lark patch 实测自带 `/app` 回退命中(spec §7.2),**无需碰环境变量**。
- **lark patch 真实风险(spec §7.2 实测)**:旧 `monitor-Bog7UNtj.js` 覆盖新 `monitor-B5WoSBtp.js` 的版本兼容 + 双 monitor 文件只 patch 一个 → 影响飞书**定制功能**,非基础收发。需 Task 6 运行时验证;若异常,记技术债更新 patch 源。
- **openclaw.json 含 token**:全程只 `cp` 不 `cat`;日志/导出贴回会话前用户自行打码。
