# 移动端语音转文字输入（STT）实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 移动端 `/m` 聊天输入支持「切换语音模式 → 按住说话 → 实时转写 → 三选一（直接发送/转文字保留/取消）」。

**Architecture:** 移动端独立 composable（`useMobileVoiceInput`）封装状态机 + AudioWorklet 采集 + 攒批 + WS 推送 + window 级三向手势；纯展示组件 `VoiceRecordingPanel` 消费状态；`ChatInputBar` 输入区多态 + window touch 分发。后端仅在 `/api/config` 加 `features.voiceStt` 派生字段，讯飞代理零改动复用（pgs 合并/帧序列/鉴权均在后端）。

**Tech Stack:** Vue 3 `<script setup lang="ts">` / Pinia / AudioWorklet + AnalyserNode / 讯飞 IAT v2（经 `/api/speech/xfyun` WS 代理）/ vitest（纯函数单测）/ vue-tsc + vite build（类型与编译验证）。

## Global Constraints

（从 spec 抄录，每个 task 隐含遵守）
- **后端**：仅 `server/handlers/system.js` 的 `GET /api/config` 加 `features.voiceStt` 字段；`xfyun-speech.js` **零改动**（pgs 合并、首/中/终帧、checkAuth 鉴权均已在后端）。
- **音频契约**：前端发 **16kHz Int16 PCM raw binary**（攒批 ~3200 样本/批），录音结束发字符串 `'end'`；后端自动转讯飞帧序列。
- **iOS**：`audioContext.resume()` **必须先于** `getUserMedia()`；AudioWorkletNode `connect(destination)` 保 process 触发、processor 不写 outputs（静音）。
- **draftText 覆盖式**：后端已 pgs 合并下发完整文本，前端 `draftText.value = text`（非 append）。
- **window 级 touch**：touchmove/touchend/touchcancel 绑 `window`（idle→listening DOM 切换不丢手势），finish/cancel 后 removeEventListener。
- **i18n**：仅 `src/i18n/messages/zh-CN.ts`（项目无 `en-US.ts`）；文案 key 前缀 `pages.mobile.chat.voice*`。
- **代码规范**：`<script setup lang="ts">`；`defineProps<{}>()`；`import type`；`shallowRef` 大对象/非响应式资源；**无 `console.log`**；immutable 更新（spread）。
- **验证**：纯函数 `npx vitest run <path>`；其余 `npx vue-tsc --noEmit` + `npm run build`；最终手动手机验证。
- **提交**：每个 task 结束 `git commit <具体文件> -m`，pathspec 隔离单文件，**禁止 `git add .`**；amend/rebase 前先 `git log -1` 确认 HEAD。

### 相对 spec 的落地修正（已核实）

1. **`configStore.fetchConfig` 走 Gateway RPC（`wsStore.rpc.getConfig()`），不走 REST `/api/config`**（config.ts:18）——RPC 响应是 `OpenClawConfig`，不含 REST 派生的 `features`。故 features 前端不依赖 configStore，改由 **composable 模块级 inflight 缓存自取 REST `/api/config`**（避免多实例惊群，对齐 [[feedback-shared-data-loading-pitfalls]]）。
2. **`getXfyunConfig` 未 export**（xfyun-speech.js:8，内部函数）——`/api/config` handler 作用域已有 `parseEnvFile` 的 `config` 对象，直接判三字段，**不碰 xfyun-speech.js**（真零改动）。
3. **去 `errorMessage` ref**：错误类型已由 `VoiceStatus`（`permission-denied`/`unsupported`/`error`/`service-unavailable`）表达，Panel 按 status 映射 i18n 文案，无需额外 errorMessage。
4. **纯函数测试可用 vitest**（package.json:74 有 `vitest@^4.0.18`），非 spec 所述"无框架"——voice-utils 走真 TDD。

---

## Task 1: 后端能力探测 features.voiceStt

**Files:**
- Modify: `server/handlers/system.js:182-193`

**Interfaces:**
- Produces: `GET /api/config` 响应新增 `features: { voiceStt: boolean }`，供 Task 5 composable 消费。

- [ ] **Step 1: 修改 /api/config handler**

将 `server/handlers/system.js:182-193` 的 handler 替换为：

```javascript
  app.get('/api/config', authMiddleware, (_req, res) => {
    try {
      if (!existsSync(envPath)) {
        return res.json({ ok: true, config: {}, features: { voiceStt: false } })
      }
      const content = readFileSync(envPath, 'utf-8')
      const config = parseEnvFile(content)
      const voiceStt = Boolean(config.XFYUN_APP_ID && config.XFYUN_API_KEY && config.XFYUN_API_SECRET)
      res.json({ ok: true, config, features: { voiceStt } })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
```

> 用 handler 已有的 `parseEnvFile` config 判定三字段（与 `getXfyunConfig`/connection handler 三处逻辑等价），不 import 未导出的 `getXfyunConfig`，xfyun-speech.js 零改动。

- [ ] **Step 2: 验证后端响应**

启动后端（`npm run dev:server`），用浏览器 devtools 或 curl（替换 `<TOKEN>` 为登录后的 `auth_token`）：

```bash
curl -s -H "Authorization: Bearer <TOKEN>" http://localhost:3001/api/config | grep -o '"voiceStt":[a-z]*'
```

Expected: `"voiceStt":true`（若 .env 配齐讯飞三字段）或 `"voiceStt":false`（未配）。

- [ ] **Step 3: Commit**

```bash
git add server/handlers/system.js
git commit server/handlers/system.js -m "feat: /api/config 增加 features.voiceStt 能力探测字段"
```

---

## Task 2: 纯函数 voice-utils + vitest TDD

**Files:**
- Create: `src/mobile/composables/voice-utils.ts`
- Test: `src/mobile/composables/voice-utils.test.ts`

**Interfaces:**
- Produces: `downsampleTo16k(input: Float32Array, inputSampleRate: number): Int16Array`、`resolveDragZone(offsetX: number, width: number): DragZone`、`type DragZone = 'send'|'text'|'cancel'`，供 Task 5 composable 消费。

- [ ] **Step 1: 写失败测试**

创建 `src/mobile/composables/voice-utils.test.ts`：

```typescript
import { describe, it, expect } from 'vitest'
import { downsampleTo16k, resolveDragZone } from './voice-utils'

describe('resolveDragZone', () => {
  it('左 1/3 → cancel', () => {
    expect(resolveDragZone(10, 300)).toBe('cancel')
  })
  it('中 1/3 → send', () => {
    expect(resolveDragZone(150, 300)).toBe('send')
  })
  it('右 1/3 → text', () => {
    expect(resolveDragZone(250, 300)).toBe('text')
  })
  it('边界：恰好 1/3 → send', () => {
    expect(resolveDragZone(100, 300)).toBe('send')
  })
})

describe('downsampleTo16k', () => {
  it('44100 → 16000 下采样长度正确（0.1s）', () => {
    const input = new Float32Array(4410) // 0.1s @44.1k
    const out = downsampleTo16k(input, 44100)
    expect(out.length).toBe(1600) // 0.1s @16k
    expect(out).toBeInstanceOf(Int16Array)
  })
  it('已是 16k → 直接转 Int16', () => {
    const input = new Float32Array([0, 0.5, 1, -1])
    const out = downsampleTo16k(input, 16000)
    expect(out.length).toBe(4)
    expect(out[0]).toBe(0)
    expect(out[2]).toBeGreaterThan(32000) // 1.0 → ~32767
    expect(out[3]).toBeLessThan(-32000) // -1.0 → ~-32767
  })
  it('clamps 超界样本', () => {
    const input = new Float32Array([2, -2]) // 超界
    const out = downsampleTo16k(input, 16000)
    expect(out[0]).toBeLessThanOrEqual(32767)
    expect(out[1]).toBeGreaterThanOrEqual(-32768)
  })
})
```

- [ ] **Step 2: 运行测试确认失败**

```bash
npx vitest run src/mobile/composables/voice-utils.test.ts
```

Expected: FAIL —— `Cannot find module './voice-utils'`。

- [ ] **Step 3: 实现纯函数**

创建 `src/mobile/composables/voice-utils.ts`：

```typescript
export type DragZone = 'send' | 'text' | 'cancel'

/**
 * 由手指在触发区的水平偏移判定三向手势区。
 * offsetX: clientX - rect.left（0 ~ width）
 * 左 1/3 = cancel，中 1/3 = send，右 1/3 = text
 */
export function resolveDragZone(offsetX: number, width: number): DragZone {
  if (offsetX < width / 3) return 'cancel'
  if (offsetX < (width * 2) / 3) return 'send'
  return 'text'
}

/** Float32 → Int16 单样本转换（clamps 到 [-1,1]） */
function float32ToInt16Sample(sample: number): number {
  const clamped = Math.max(-1, Math.min(1, sample))
  return clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff
}

/**
 * 线性插值下采样到 16kHz + Float32→Int16 PCM。
 * input 是攒批后的整段（非单 128 帧），inputSampleRate 取自 audioContext.sampleRate。
 */
export function downsampleTo16k(input: Float32Array, inputSampleRate: number): Int16Array {
  if (inputSampleRate === 16000) {
    const out = new Int16Array(input.length)
    for (let i = 0; i < input.length; i++) out[i] = float32ToInt16Sample(input[i])
    return out
  }
  const ratio = inputSampleRate / 16000
  const outLen = Math.max(0, Math.floor(input.length / ratio))
  const out = new Int16Array(outLen)
  for (let i = 0; i < outLen; i++) {
    const srcIdx = i * ratio
    const lo = Math.floor(srcIdx)
    const hi = Math.min(lo + 1, input.length - 1)
    const frac = srcIdx - lo
    const sample = input[lo] * (1 - frac) + input[hi] * frac
    out[i] = float32ToInt16Sample(sample)
  }
  return out
}
```

- [ ] **Step 4: 运行测试确认通过**

```bash
npx vitest run src/mobile/composables/voice-utils.test.ts
```

Expected: PASS（所有用例通过）。

- [ ] **Step 5: Commit**

```bash
git add src/mobile/composables/voice-utils.ts src/mobile/composables/voice-utils.test.ts
git commit src/mobile/composables/voice-utils.ts src/mobile/composables/voice-utils.test.ts -m "feat: 移动端语音纯函数 downsampleTo16k/resolveDragZone + vitest 单测"
```

---

## Task 3: AudioWorklet PCM processor

**Files:**
- Create: `public/voice-pcm-processor.js`

**Interfaces:**
- Produces: AudioWorklet processor 注册名 `'voice-pcm-processor'`，经 `audioWorklet.addModule('/voice-pcm-processor.js')` 加载；`process` 转发 Float32 PCM 帧到 `node.port`，供 Task 5 composable 接收。

- [ ] **Step 1: 创建 worklet processor**

创建 `public/voice-pcm-processor.js`：

```javascript
// AudioWorklet processor：主线程外运行，仅转发原始 Float32 PCM 帧。
// 攒批与下采样在主线程 composable 完成（便于单测）。
// process 不写入 outputs（静音），避免麦克风回放/回声。
class VoicePcmProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const channel = inputs[0] && inputs[0][0]
    if (channel && channel.length) {
      this.port.postMessage(channel)
    }
    return true
  }
}

registerProcessor('voice-pcm-processor', VoicePcmProcessor)
```

- [ ] **Step 2: 验证构建含该静态文件**

```bash
npm run build
```

Expected: 构建成功，`dist/voice-pcm-processor.js` 存在（`public/` 被 vite 复制到 dist 根）。确认：

```bash
ls dist/voice-pcm-processor.js
```

Expected: 文件路径输出（存在）。

- [ ] **Step 3: Commit**

```bash
git add public/voice-pcm-processor.js
git commit public/voice-pcm-processor.js -m "feat: 新增 voice-pcm-processor AudioWorklet 处理器"
```

---

## Task 4: i18n 文案（zh-CN）

**Files:**
- Modify: `src/i18n/messages/zh-CN.ts`（在 `pages.mobile.chat` 对象内，约 :3160 起）

**Interfaces:**
- Produces: `pages.mobile.chat.voice*` 一组文案 key，供 Task 5/6/7 `t()` 引用。

- [ ] **Step 1: 在 mobile.chat 对象内追加 voice 文案**

在 `src/i18n/messages/zh-CN.ts` 的 `pages.mobile.chat` 对象内（`aiDisclaimer` 行 :3182 附近，与现有 key 同级）追加：

```typescript
        voiceToggle: '切换语音输入',
        keyboardToggle: '切换键盘输入',
        holdToSpeak: '按住说话',
        releaseToSend: '松开 发送',
        slideToText: '滑到这里 转文字',
        cancelRecord: '取消',
        requestingMic: '请求麦克风权限…',
        connectingVoice: '连接中…',
        transcribing: '转写中…',
        voiceEmpty: '没有听到声音，请重试',
        voiceTimeout: '已达时长上限',
        voicePermissionDenied: '麦克风权限被拒，请在设置中开启',
        voiceNoMic: '未检测到麦克风',
        voiceUnavailable: '语音转文字暂不可用',
```

- [ ] **Step 2: 类型检查 + 构建验证**

```bash
npx vue-tsc --noEmit && npm run build
```

Expected: 通过（无类型错误，无重复 key）。

- [ ] **Step 3: Commit**

```bash
git add src/i18n/messages/zh-CN.ts
git commit src/i18n/messages/zh-CN.ts -m "feat: 移动端聊天 voice* i18n 文案(zh-CN)"
```

---

## Task 5: useMobileVoiceInput composable

**Files:**
- Create: `src/mobile/composables/useMobileVoiceInput.ts`

**Interfaces:**
- Consumes: `downsampleTo16k`/`resolveDragZone`/`DragZone`（Task 2）；REST `GET /api/config`（Task 1）；`localStorage.auth_token`（WS 鉴权 query）。
- Produces: `useMobileVoiceInput()` 返回 `{ status, voiceMode, volume, duration, draftText, dragZone, enabled, analyser, isSupported, toggleVoiceMode, start, setDragZone, finish, cancel, resolveDragZone }`，供 Task 6/7 消费。

- [ ] **Step 1: 创建 composable 完整实现**

创建 `src/mobile/composables/useMobileVoiceInput.ts`：

```typescript
import { ref, shallowRef, onUnmounted } from 'vue'
import { downsampleTo16k, resolveDragZone, type DragZone } from './voice-utils'

export type VoiceStatus =
  | 'idle' | 'requesting' | 'connecting'
  | 'listening' | 'stopping'
  | 'permission-denied' | 'unsupported' | 'error' | 'service-unavailable'

export type FinishMode = 'send' | 'keep' | 'cancel'
export interface FinishResult { mode: FinishMode; text: string }

const SPEECH_WS_PATH = '/api/speech/xfyun'
const WORKLET_URL = '/voice-pcm-processor.js'
const BATCH_SAMPLE_TARGET = 3200   // ~72ms @44.1k
const STOP_TIMEOUT_MS = 800
const MAX_RECORD_MS = 60_000
const ERROR_RESET_MS = 2000

// 模块级能力缓存（inflight 去重，多实例共享，避免惊群）
let featureInflight: Promise<boolean> | null = null
let featureCache: boolean | null = null
async function loadVoiceSttEnabled(): Promise<boolean> {
  if (featureCache !== null) return featureCache
  if (featureInflight) return featureInflight
  featureInflight = (async () => {
    try {
      const token = localStorage.getItem('auth_token')
      const resp = await fetch('/api/config', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      const data = await resp.json()
      featureCache = Boolean(data?.features?.voiceStt)
    } catch {
      featureCache = false
    } finally {
      featureInflight = null
    }
    return featureCache
  })()
  return featureInflight
}

function isBrowserSupported(): boolean {
  return (
    typeof navigator !== 'undefined' &&
    !!navigator.mediaDevices?.getUserMedia &&
    typeof AudioContext !== 'undefined' &&
    !!AudioContext.prototype?.audioWorklet
  )
}

export function useMobileVoiceInput() {
  const status = ref<VoiceStatus>('idle')
  const voiceMode = ref(false)
  const volume = ref(0)
  const duration = ref(0)
  const draftText = ref('')
  const dragZone = ref<DragZone | null>(null)
  const enabled = ref(false)

  const audioCtx = shallowRef<AudioContext | null>(null)
  const mediaStream = shallowRef<MediaStream | null>(null)
  const workletNode = shallowRef<AudioWorkletNode | null>(null)
  const analyser = shallowRef<AnalyserNode | null>(null)
  const source = shallowRef<MediaStreamAudioSourceNode | null>(null)
  const socket = shallowRef<WebSocket | null>(null)
  const batchParts = shallowRef<Float32Array[]>([])

  let cancelled = false
  let finalReceived = false
  let stopTimer: ReturnType<typeof setTimeout> | null = null
  let stopCheck: ReturnType<typeof setInterval> | null = null
  let maxTimer: ReturnType<typeof setTimeout> | null = null
  let errorResetTimer: ReturnType<typeof setTimeout> | null = null
  let rafId: number | null = null
  let durationTimer: ReturnType<typeof setInterval> | null = null
  let recordStartTs = 0

  function clearAllTimers() {
    if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
    if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
    if (maxTimer) { clearTimeout(maxTimer); maxTimer = null }
    if (errorResetTimer) { clearTimeout(errorResetTimer); errorResetTimer = null }
    if (durationTimer) { clearInterval(durationTimer); durationTimer = null }
    if (rafId) { cancelAnimationFrame(rafId); rafId = null }
  }

  function releaseResources() {
    clearAllTimers()
    try { mediaStream.value?.getTracks().forEach((t) => t.stop()) } catch { /* noop */ }
    try { workletNode.value?.disconnect() } catch { /* noop */ }
    try { analyser.value?.disconnect() } catch { /* noop */ }
    try { source.value?.disconnect() } catch { /* noop */ }
    try { audioCtx.value?.close() } catch { /* noop */ }
    try { socket.value?.close() } catch { /* noop */ }
    audioCtx.value = null
    mediaStream.value = null
    workletNode.value = null
    analyser.value = null
    source.value = null
    socket.value = null
    batchParts.value = []
    dragZone.value = null
    volume.value = 0
    duration.value = 0
  }

  function cleanup() {
    cancelled = true
    releaseResources()
    status.value = 'idle'
  }

  function setErrorStatus(s: VoiceStatus) {
    releaseResources()
    status.value = s
    errorResetTimer = setTimeout(() => {
      if (['permission-denied', 'unsupported', 'error', 'service-unavailable'].includes(status.value)) {
        status.value = 'idle'
      }
    }, ERROR_RESET_MS)
  }

  function isSupported() {
    return enabled.value && isBrowserSupported()
  }

  async function ensureEnabled() {
    if (featureCache === null) {
      enabled.value = await loadVoiceSttEnabled()
    } else {
      enabled.value = featureCache
    }
  }
  void ensureEnabled()

  function toggleVoiceMode() {
    if (!isSupported()) return
    voiceMode.value = !voiceMode.value
    if (!voiceMode.value && status.value !== 'idle') cleanup()
  }

  function setDragZone(zone: DragZone | null) {
    dragZone.value = zone
  }

  function onPcmFrame(frame: Float32Array, sampleRate: number) {
    if (status.value !== 'listening') return
    batchParts.value.push(frame)
    let total = 0
    for (const p of batchParts.value) total += p.length
    if (total >= BATCH_SAMPLE_TARGET) {
      const merged = new Float32Array(total)
      let off = 0
      for (const p of batchParts.value) { merged.set(p, off); off += p.length }
      batchParts.value = []
      const pcm = downsampleTo16k(merged, sampleRate)
      const ws = socket.value
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(pcm.buffer.slice(pcm.byteOffset, pcm.byteOffset + pcm.byteLength))
      }
    }
  }

  function onSocketMessage(ev: MessageEvent) {
    let payload: { type?: string; text?: string; isFinal?: boolean; message?: string }
    try {
      payload = JSON.parse(typeof ev.data === 'string' ? ev.data : '')
    } catch {
      return
    }
    if (payload.type === 'error') {
      setErrorStatus('service-unavailable')
      return
    }
    if (payload.type === 'result' && typeof payload.text === 'string') {
      draftText.value = payload.text // 覆盖式（后端已 pgs 合并）
      if (payload.isFinal) finalReceived = true
    }
  }

  function startDurationAndVolume() {
    const an = analyser.value
    if (!an) return
    const data = new Uint8Array(an.frequencyBinCount)
    const tick = () => {
      if (status.value !== 'listening' || !analyser.value) return
      analyser.value.getByteFrequencyData(data)
      let sum = 0
      for (let i = 0; i < data.length; i++) sum += data[i]
      volume.value = Math.min(1, sum / data.length / 128)
      rafId = requestAnimationFrame(tick)
    }
    rafId = requestAnimationFrame(tick)
    durationTimer = setInterval(() => {
      if (status.value === 'listening') {
        duration.value = Math.floor((Date.now() - recordStartTs) / 1000)
      }
    }, 250)
  }

  async function start() {
    if (status.value !== 'idle') return // H6 重复防护
    draftText.value = ''
    dragZone.value = null
    cancelled = false
    finalReceived = false
    recordStartTs = Date.now()

    // C4: resume 先于 getUserMedia
    status.value = 'requesting'
    let ctx: AudioContext
    try {
      ctx = new AudioContext()
      audioCtx.value = ctx
      if (ctx.state === 'suspended') await ctx.resume()
    } catch {
      setErrorStatus('unsupported')
      return
    }

    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (e) {
      const err = e as DOMException
      if (err.name === 'NotAllowedError') setErrorStatus('permission-denied')
      else if (err.name === 'NotFoundError') setErrorStatus('unsupported')
      else setErrorStatus('error')
      return
    }
    if (cancelled) { // H2: 取消后 getUM 延迟 resolve
      stream.getTracks().forEach((t) => t.stop())
      return
    }
    mediaStream.value = stream

    status.value = 'connecting'
    try {
      await ctx.audioWorklet.addModule(WORKLET_URL)
    } catch {
      setErrorStatus('error')
      return
    }
    if (cancelled) { cleanup(); return }

    const node = new AudioWorkletNode(ctx, 'voice-pcm-processor')
    const an = ctx.createAnalyser()
    an.fftSize = 256
    const src = ctx.createMediaStreamSource(stream)
    src.connect(node)
    src.connect(an)
    node.connect(ctx.destination) // iOS 保 process 触发；processor 不写 outputs 静音
    workletNode.value = node
    analyser.value = an
    source.value = src
    node.port.onmessage = (ev: MessageEvent) => onPcmFrame(ev.data as Float32Array, ctx.sampleRate)

    const token = localStorage.getItem('auth_token') || ''
    const url = `${SPEECH_WS_PATH}?token=${encodeURIComponent(token)}`
    let ws: WebSocket
    try {
      ws = new WebSocket(url)
      ws.binaryType = 'arraybuffer'
    } catch {
      setErrorStatus('service-unavailable')
      return
    }
    socket.value = ws
    ws.onopen = () => {
      if (cancelled || !socket.value) return
      status.value = 'listening'
      startDurationAndVolume()
      maxTimer = setTimeout(() => {
        // M4: 超时保守 cancel（不误发）
        setErrorStatus('error')
      }, MAX_RECORD_MS)
    }
    ws.onmessage = (ev: MessageEvent) => onSocketMessage(ev)
    ws.onerror = () => {
      if (status.value === 'connecting' || status.value === 'listening') {
        setErrorStatus('service-unavailable')
      }
    }
    ws.onclose = (ev: CloseEvent) => {
      if (status.value === 'stopping' && finalReceived) return // 正常收尾
      if (!ev.wasClean && status.value !== 'idle' && status.value !== 'stopping') {
        setErrorStatus('service-unavailable')
      }
    }
  }

  function finish(): Promise<FinishResult | null> {
    return new Promise((resolve) => {
      // H4: 非 listening 直接 cancel
      if (status.value !== 'listening') {
        cleanup()
        resolve(null)
        return
      }
      status.value = 'stopping'
      if (maxTimer) { clearTimeout(maxTimer); maxTimer = null }
      if (rafId) { cancelAnimationFrame(rafId); rafId = null }
      const ws = socket.value
      if (ws && ws.readyState === WebSocket.OPEN) {
        try { ws.send('end') } catch { /* noop */ }
      }
      const text = draftText.value
      const zone = dragZone.value

      stopTimer = setTimeout(() => {
        finalReceived = true
        finalize()
      }, STOP_TIMEOUT_MS)
      stopCheck = setInterval(() => {
        const s = socket.value
        if (finalReceived || !s || s.readyState >= WebSocket.CLOSING) {
          if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
          if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
          finalize()
        }
      }, 50)

      function finalize() {
        if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
        if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
        const mode: FinishMode = zone === 'cancel' ? 'cancel' : zone === 'text' ? 'keep' : 'send'
        cleanup()
        resolve({ mode, text: mode === 'cancel' ? '' : text })
      }
    })
  }

  function cancel() {
    cleanup()
  }

  onUnmounted(() => {
    if (status.value !== 'idle') cleanup()
  })

  return {
    status,
    voiceMode,
    volume,
    duration,
    draftText,
    dragZone,
    enabled,
    analyser,
    isSupported,
    toggleVoiceMode,
    start,
    setDragZone,
    finish,
    cancel,
    resolveDragZone,
  }
}
```

- [ ] **Step 2: 类型检查 + 构建验证**

```bash
npx vue-tsc --noEmit && npm run build
```

Expected: 通过（无类型错误）。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/composables/useMobileVoiceInput.ts
git commit src/mobile/composables/useMobileVoiceInput.ts -m "feat: 移动端 useMobileVoiceInput 状态机 composable(AudioWorklet采集+攒批+WS+window手势)"
```

---

## Task 6: VoiceRecordingPanel 展示组件

**Files:**
- Create: `src/mobile/views/chat/VoiceRecordingPanel.vue`

**Interfaces:**
- Consumes: `VoiceStatus`/`DragZone`（Task 5）；`analyser`（rAF 直绘波形，绕过 reactivity）；i18n key（Task 4）。
- Produces: `<VoiceRecordingPanel :status :volume :duration :draft-text :drag-zone :analyser />`，嵌入 ChatInputBar 输入区。

- [ ] **Step 1: 创建 Panel 组件**

创建 `src/mobile/views/chat/VoiceRecordingPanel.vue`：

```vue
<script setup lang="ts">
import { ref, watch, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import type { VoiceStatus, DragZone } from '@/mobile/composables/useMobileVoiceInput'

interface Props {
  status: VoiceStatus
  volume: number
  duration: number
  draftText: string
  dragZone: DragZone | null
  analyser: AnalyserNode | null
}

const props = defineProps<Props>()
const { t } = useI18n()

const canvasRef = ref<HTMLCanvasElement | null>(null)
let rafId: number | null = null

function fmtDuration(sec: number): string {
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

function statusText(): string {
  switch (props.status) {
    case 'requesting': return t('pages.mobile.chat.requestingMic')
    case 'connecting': return t('pages.mobile.chat.connectingVoice')
    case 'stopping': return t('pages.mobile.chat.transcribing')
    case 'permission-denied': return t('pages.mobile.chat.voicePermissionDenied')
    case 'unsupported': return t('pages.mobile.chat.voiceNoMic')
    case 'error': return t('pages.mobile.chat.voiceTimeout')
    case 'service-unavailable': return t('pages.mobile.chat.voiceUnavailable')
    default: return ''
  }
}

function isListening(): boolean {
  return props.status === 'listening'
}

function drawWave() {
  const canvas = canvasRef.value
  const an = props.analyser
  if (!canvas || !an || !isListening()) {
    if (rafId) { cancelAnimationFrame(rafId); rafId = null }
    return
  }
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const data = new Uint8Array(an.frequencyBinCount)
  an.getByteFrequencyData(data)
  const w = canvas.width
  const h = canvas.height
  ctx.clearRect(0, 0, w, h)
  ctx.fillStyle = '#ffffff'
  const bars = 24
  const step = Math.floor(data.length / bars)
  const barW = w / bars
  for (let i = 0; i < bars; i++) {
    const v = data[i * step] / 255
    const barH = Math.max(2, v * h)
    ctx.fillRect(i * barW + 1, (h - barH) / 2, barW - 2, barH)
  }
  rafId = requestAnimationFrame(drawWave)
}

watch(
  () => [props.status, props.analyser] as const,
  ([s]) => {
    if (s === 'listening' && props.analyser) {
      if (rafId) cancelAnimationFrame(rafId)
      rafId = requestAnimationFrame(drawWave)
    }
  },
)

onUnmounted(() => {
  if (rafId) cancelAnimationFrame(rafId)
})
</script>

<template>
  <div class="voice-panel">
    <div class="voice-bubble" :class="`is-${status}`">
      <div v-if="isListening" class="voice-bubble__wave">
        <canvas ref="canvasRef" width="240" height="40" />
        <span class="voice-bubble__dur">{{ fmtDuration(duration) }}</span>
      </div>
      <div v-else class="voice-bubble__text">{{ statusText() }}</div>
      <div v-if="isListening && draftText" class="voice-bubble__draft">{{ draftText }}</div>
    </div>

    <div v-if="isListening" class="voice-actions">
      <button
        class="voice-action"
        type="button"
        :class="{ active: dragZone === 'cancel' }"
      >
        {{ t('pages.mobile.chat.cancelRecord') }}
      </button>
      <button
        class="voice-action voice-action--primary"
        type="button"
        :class="{ active: dragZone === null || dragZone === 'send' }"
      >
        {{ t('pages.mobile.chat.releaseToSend') }}
      </button>
      <button
        class="voice-action"
        type="button"
        :class="{ active: dragZone === 'text' }"
      >
        {{ t('pages.mobile.chat.slideToText') }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.voice-panel {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  width: 100%;
}
.voice-bubble {
  min-width: 180px;
  max-width: 80%;
  padding: 10px 16px;
  border-radius: 16px;
  background: #4cd964;
  color: #fff;
  font-size: 13px;
  text-align: center;
  box-shadow: 0 6px 16px rgba(76, 217, 100, 0.3);
}
.voice-bubble.is-permission-denied,
.voice-bubble.is-unsupported,
.voice-bubble.is-error,
.voice-bubble.is-service-unavailable {
  background: var(--m-danger, #ef4444);
  box-shadow: 0 6px 16px rgba(239, 68, 68, 0.25);
}
.voice-bubble__wave {
  display: flex;
  align-items: center;
  gap: 8px;
  justify-content: center;
}
.voice-bubble__wave canvas {
  width: 120px;
  height: 20px;
}
.voice-bubble__dur {
  font-variant-numeric: tabular-nums;
  font-size: 12px;
  opacity: 0.9;
}
.voice-bubble__draft {
  margin-top: 6px;
  font-size: 12px;
  opacity: 0.85;
  word-break: break-all;
}
.voice-actions {
  display: flex;
  width: 100%;
  gap: 8px;
}
.voice-action {
  flex: 1;
  padding: 12px 6px;
  border: 1px solid var(--m-border);
  border-radius: 12px;
  background: var(--m-bg-elevated);
  color: var(--m-text-secondary);
  font-size: 12px;
  text-align: center;
  transition: background 0.12s ease, color 0.12s ease, border-color 0.12s ease;
  -webkit-tap-highlight-color: transparent;
}
.voice-action.active {
  border-color: var(--m-primary);
  background: color-mix(in srgb, var(--m-primary) 14%, transparent);
  color: var(--m-primary);
}
.voice-action--primary.active {
  background: var(--m-primary);
  color: #fff;
}
.voice-action:nth-child(1).active {
  border-color: var(--m-danger, #ef4444);
  background: color-mix(in srgb, var(--m-danger, #ef4444) 14%, transparent);
  color: var(--m-danger, #ef4444);
}
</style>
```

- [ ] **Step 2: 类型检查 + 构建验证**

```bash
npx vue-tsc --noEmit && npm run build
```

Expected: 通过。

- [ ] **Step 3: Commit**

```bash
git add src/mobile/views/chat/VoiceRecordingPanel.vue
git commit src/mobile/views/chat/VoiceRecordingPanel.vue -m "feat: 移动端 VoiceRecordingPanel 录音气泡+三按钮展示组件"
```

---

## Task 7: ChatInputBar 接入

**Files:**
- Modify: `src/mobile/views/chat/ChatInputBar.vue`（script :1-143 + template :172-251 + style 末尾）

**Interfaces:**
- Consumes: `useMobileVoiceInput`（Task 5）、`VoiceRecordingPanel`（Task 6）、`resolveDragZone`（Task 5 re-export）、i18n（Task 4）。
- Produces: 输入区多态（文本框 / 按住说话条 / Panel）+ 切换语音键 + window 级 touch + finish 三态分发。

- [ ] **Step 1: script setup 新增导入与 composable**

在 `src/mobile/views/chat/ChatInputBar.vue` 的 `<script setup lang="ts">` 顶部 import 区（:2-5 附近）追加：

```typescript
import { useMobileVoiceInput } from '@/mobile/composables/useMobileVoiceInput'
import VoiceRecordingPanel from './VoiceRecordingPanel.vue'
```

在 `const { t } = useI18n()`（:22）之后追加 composable 实例与 window touch 处理：

```typescript
const voice = useMobileVoiceInput()
const voiceBarRef = ref<HTMLElement | null>(null)

function appendInput(text: string) {
  const cur = inputText.value
  if (!cur) {
    inputText.value = text
  } else {
    inputText.value = `${cur.replace(/\s+$/, '')} ${text}`
  }
}

function onVoiceTouchStart(e: TouchEvent) {
  e.preventDefault()
  void voice.start()
  window.addEventListener('touchmove', onVoiceTouchMove, { passive: false })
  window.addEventListener('touchend', onVoiceTouchEnd)
  window.addEventListener('touchcancel', onVoiceTouchCancel)
}

function onVoiceTouchMove(e: TouchEvent) {
  e.preventDefault()
  const bar = voiceBarRef.value
  if (!bar) return
  const touch = e.touches[0]
  const rect = bar.getBoundingClientRect()
  // 手指 clientX 相对触发区左边缘（含 Panel 三按钮区宽度）
  const offsetX = touch.clientX - rect.left
  const zone = voice.resolveDragZone(offsetX, rect.width)
  voice.setDragZone(zone)
}

async function onVoiceTouchEnd() {
  removeVoiceListeners()
  const r = await voice.finish()
  if (!r || r.mode === 'cancel') return
  if (!r.text.trim()) return // H5 空转写不发
  appendInput(r.text)
  if (r.mode === 'send') handleSend()
}

function onVoiceTouchCancel() {
  removeVoiceListeners()
  voice.cancel()
}

function removeVoiceListeners() {
  window.removeEventListener('touchmove', onVoiceTouchMove)
  window.removeEventListener('touchend', onVoiceTouchEnd)
  window.removeEventListener('touchcancel', onVoiceTouchCancel)
}
```

并在现有 `onUnmounted`（:139-142）内追加清理：

```typescript
onUnmounted(() => {
  document.removeEventListener('click', onDocumentClick, true)
  document.removeEventListener('keydown', onDocumentKeydown)
  removeVoiceListeners()
})
```

- [ ] **Step 2: template 输入区多态 + 切换语音键**

在 `src/mobile/views/chat/ChatInputBar.vue` 的 `input-wrapper`（:172-245）做如下改造：

**a)** 在 `<div class="input-wrapper">` 内、`file-input` 之前插入「切换语音键」（仅 `voice.enabled` 且支持时显示）：

```html
      <button
        v-if="voice.enabled && voice.isSupported()"
        class="voice-toggle"
        type="button"
        :aria-label="voice.voiceMode ? t('pages.mobile.chat.keyboardToggle') : t('pages.mobile.chat.voiceToggle')"
        :disabled="sending"
        @click="voice.toggleVoiceMode()"
      >
        <svg v-if="!voice.voiceMode" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <rect x="9" y="3" width="6" height="11" rx="3" />
          <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
        </svg>
        <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <rect x="2" y="6" width="20" height="12" rx="2" />
          <path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10" />
        </svg>
      </button>
```

**b)** 将现有的 `<textarea ... />`（:194-201）包进 `v-if="!voice.voiceMode"`；并在其后新增 `v-else` 分支（按住说话条 / Panel）：

```html
      <textarea
        v-if="!voice.voiceMode"
        v-model="inputText"
        class="chat-textarea"
        :placeholder="t('pages.mobile.chat.inputPlaceholder')"
        :disabled="sending"
        rows="1"
        @keydown="handleKeydown"
      />
      <template v-else>
        <div
          v-if="voice.status === 'idle'"
          ref="voiceBarRef"
          class="hold-bar"
          @touchstart.passive="onVoiceTouchStart"
        >
          {{ t('pages.mobile.chat.holdToSpeak') }}
        </div>
        <div
          v-else
          ref="voiceBarRef"
          class="voice-panel-slot"
        >
          <VoiceRecordingPanel
            :status="voice.status"
            :volume="voice.volume"
            :duration="voice.duration"
            :draft-text="voice.draftText"
            :drag-zone="voice.dragZone"
            :analyser="voice.analyser"
          />
        </div>
      </template>
```

> 注：`voiceBarRef` 同时绑在「按住说话」条（idle）与 Panel 容器（录音中），二者等宽且位置稳定，`getBoundingClientRect()` 在 window touchmove 时给出统一坐标系，三向手势分段连续。

- [ ] **Step 3: style 追加 voice 样式**

在 `src/mobile/views/chat/ChatInputBar.vue` 的 `<style scoped>` 末尾（`</style>` 前）追加：

```css
.voice-toggle {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  flex-shrink: 0;
  align-self: center;
  border: 1px solid color-mix(in srgb, var(--m-primary) 14%, transparent);
  border-radius: 50%;
  background: color-mix(in srgb, var(--m-primary) 6%, transparent);
  color: var(--m-primary);
  cursor: pointer;
  box-shadow: inset 0 1px 1px rgba(255, 255, 255, 0.35);
  -webkit-tap-highlight-color: transparent;
}
.voice-toggle:disabled { opacity: 0.5; }
.voice-toggle:active { transform: scale(0.92); }
.voice-toggle svg { width: 16px; height: 16px; }

.hold-bar {
  flex: 1;
  min-height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 7px 4px;
  border-radius: 12px;
  background: color-mix(in srgb, var(--m-primary) 8%, var(--m-bg-input, transparent));
  color: var(--m-text-secondary);
  font-size: 15px;
  text-align: center;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  -webkit-appearance: none;
  appearance: none;
}
.hold-bar:active {
  background: color-mix(in srgb, var(--m-primary) 16%, transparent);
}
.voice-panel-slot {
  flex: 1;
  min-height: 34px;
  display: flex;
  align-items: center;
}
```

- [ ] **Step 4: 类型检查 + 构建验证**

```bash
npx vue-tsc --noEmit && npm run build
```

Expected: 通过。

- [ ] **Step 5: Commit**

```bash
git add src/mobile/views/chat/ChatInputBar.vue
git commit src/mobile/views/chat/ChatInputBar.vue -m "feat: ChatInputBar 接入语音输入(切换键+多态输入区+window touch+finish三态分发)"
```

---

## Task 8: 端到端手动验收

**Files:**
- 无（验证 task）

**Interfaces:**
- 按 spec 第 13 节验收清单逐项手动验证。

- [ ] **Step 1: 启动全栈**

```bash
./start.sh
```

确认前端（:3000）+ 后端（:3001）就绪。

- [ ] **Step 2: 逐项验收（手机端 iOS Safari / 飞书内置浏览器 / 安卓 Chrome）**

- [ ] 输入区左侧「切换语音」键：点一次→输入框变「按住说话」条；再点→回文本输入框
- [ ] `features.voiceStt=false`（.env 未配讯飞）→ 切换键隐藏
- [ ] 按住「按住说话」→ requesting/connecting 气泡反馈 → listening 绿色波形气泡 + 底部三按钮，聊天内容可见
- [ ] 录音中手指左滑→「取消」高亮；右滑→「转文字」高亮；回中→「松开发送」高亮（DOM 切换不丢手势）
- [ ] 中间松开 → 转写文字追加 inputText 后立即发送一条消息
- [ ] 右滑松开 → 转写文字追加 inputText，不发送
- [ ] 左滑松开 → 丢弃，不回填不发送
- [ ] 按住不说话 → 松开不发空消息
- [ ] 松开后 ≤800ms 显示「转写中…」，完成后按上述分发
- [ ] iOS Safari：AudioContext 正常 resume（非 suspended），录音有波形
- [ ] 录音超 60s → 自动取消 + 提示，不误发
- [ ] 权限拒绝 / 无麦克风 / 服务不可用 / worklet 加载失败 → 气泡明确提示并回 idle
- [ ] 组件切换/卸载不泄漏（无残留 audio track / WS / timer / window listener / rAF）

- [ ] **Step 3: 修复验收中发现的问题（如有），补充 commit**

逐个问题定位修复，单独 commit（pathspec 隔离）。

- [ ] **Step 4: 最终全量验证**

```bash
npx vitest run src/mobile/composables/voice-utils.test.ts && npx vue-tsc --noEmit && npm run build
```

Expected: 全绿。

---

## Self-Review

**1. Spec coverage:**
- §1 目标（三选一）→ Task 7 finish 分发 + Task 8 验收 ✓
- §2.1 核实结论（pgs 后端/帧协议/鉴权/判定一致/16k Int16/isFinal）→ Task 5 onSocketMessage 覆盖式 + send PCM/'end' + Task 1 判定 ✓
- §3 文件清单（3 新建 + 4 修改）→ Task 1/3/5/6（新建 system 改 / processor / composable / Panel）+ Task 2/4/7（utils / i18n / ChatInputBar）✓；注：voice-utils.ts 为 Task 2 拆出的纯函数文件（spec 未单列，plan 拆分便于单测，合理细化）
- §4 状态机（resume 先/C3 攒批/H2 取消/H3 connecting 失败/H4 非 listening finish/H5 空/H6 重复/M4 超时 cancel）→ Task 5 ✓
- §5.1 composable 契约 → Task 5 ✓（去 errorMessage，按 status 映射，落地修正 3）
- §5.2 Panel → Task 6 ✓（含 requesting/connecting/stopping/错误态反馈，rAF 直绘）
- §5.3 worklet → Task 3 ✓
- §5.4 ChatInputBar 多态/window touch/空保护 → Task 7 ✓
- §5.5 i18n key → Task 4 ✓（connecting key 名 `connectingVoice` 避免与潜在全局冲突）
- §6 能力探测 → Task 1 + Task 5 模块级缓存（落地修正 1/2）✓
- §7 iOS（resume 顺序/connect destination/public worklet）→ Task 5 ✓
- §8 资源清理（幂等/cancelled flag/removeEventListener/rAF）→ Task 5 releaseResources/cleanup + Task 7 removeVoiceListeners ✓
- §9 错误处理 → Task 5 setErrorStatus 全覆盖 ✓
- §10 测试 → Task 2 vitest + 各 task build ✓
- §13 验收清单 → Task 8 ✓

**2. Placeholder scan:** 无 TBD/TODO；每步含完整代码或精确命令。✓

**3. Type consistency:**
- `VoiceStatus`/`DragZone`/`FinishMode`/`FinishResult`：Task 5 定义，Task 6 `import type` 消费，Task 7 经 `voice.*` 消费，命名一致 ✓
- `downsampleTo16k`/`resolveDragZone`：Task 2 定义导出，Task 5 import + re-export resolveDragZone，Task 7 经 `voice.resolveDragZone` 调用 ✓
- composable 返回字段名（status/voiceMode/volume/duration/draftText/dragZone/enabled/analyser/isSupported/toggleVoiceMode/start/setDragZone/finish/cancel/resolveDragZone）：Task 5 return 与 Task 7 消费逐一对齐 ✓
- Panel props（status/volume/duration/draftText/dragZone/analyser）：Task 6 defineProps 与 Task 7 模板绑定一致 ✓
