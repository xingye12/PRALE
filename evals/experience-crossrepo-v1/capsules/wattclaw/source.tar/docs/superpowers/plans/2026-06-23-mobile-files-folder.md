# 移动端文件管理 面包屑文件夹层级 + 默认最活跃员工 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 移动端 `/m/files` 文件按文件夹层级(面包屑导航)显示,且数字员工筛选默认选中会话最近活动的员工;网页端建树逻辑抽为网页+移动共享 SSOT。

**Architecture:** 从网页端 `FileManagerPage.vue` 把纯建树逻辑(`normalizeEntries`/`flattenFiles`/`AgentFileTree`)抽到 `src/utils/file-classify.ts`,store/i18n 依赖上移到调用方使函数纯化;新增面包屑专用 `listDirLevel`/`splitPathSegments`;`session-time.ts` 新增 `pickMostActiveAgentId` 复用 `workspaceStore.agents` 自带 sessions。移动端 `MobileFilesPage` 改双状态(`currentAgentId`+`currentPath`)+ 面包屑,每员工独立树(对齐网页端 `agentTrees`,不跨员工合并)。

**Tech Stack:** Vue 3 `<script setup lang="ts">`、Pinia、Naive UI、TypeScript、Vite。

## Global Constraints

- 项目无测试框架,验证靠 `npm run build`(vue-tsc + Vite)类型检查 + 手机手动,不靠裸 `vue-tsc`(会漏过类型回归)。
- i18n 仅 `zh-CN` 单 locale(`en-US.ts` 不存在),新增 key 只加 `src/i18n/zh-CN.ts`。
- Git 提交 pathspec 隔离:`git add <具体文件>`,禁止 `git add .`;多窗口并行,提交前 `git log -1` 确认 HEAD。
- 网页端 `FileManagerPage.vue` 抽取后**行为必须等价**(关键回归点):树展开/关键字搜索/类型筛选/下载/删除不回归。
- workspace 隔离红线:文件归属按 `agentId`/`workspace`,**不跨员工合并 path**。
- 每员工独立树(`AgentFileTree[]`),移动端「全部」模式顶层是员工列表(可进入),进入后该员工文件夹树。

---

## File Structure

| 文件 | 责任 | 改动类型 |
|---|---|---|
| `src/utils/file-classify.ts` | 网页+移动共享的文件分类/建树纯函数 SSOT | 追加 `AgentFileTree`/`normalizeEntries`/`flattenFiles`/`listDirLevel`/`splitPathSegments`/`findNodeByPath` |
| `src/views/files/FileManagerPage.vue` | 网页端文件管理 | 删本地 3 个定义,改 import;调用点传 ownerUserName/unknownLabel |
| `src/utils/session-time.ts` | 会话时间/活跃度 SSOT | 追加 `pickMostActiveAgentId` |
| `src/mobile/views/files/MobileFilesPage.vue` | 移动端文件管理 | 删本地 flattenFiles;agentTrees+双状态+面包屑;默认最活跃员工 |
| `src/i18n/zh-CN.ts` | 中文文案 | 追加 breadcrumb/空状态/员工分组 key |

---

## Task 1: file-classify.ts 抽入共享建树逻辑

**Files:**
- Modify: `src/utils/file-classify.ts`(末尾追加)

**Interfaces:**
- Consumes: 已有 `FileEntry`/`normalizePath`/`createFileNodeId`/`getExt`/`shouldHideFile`(同文件)
- Produces: `AgentFileTree`(type)、`flattenFiles(nodes)`、`normalizeEntries(entries, agent, workspace, unknownLabel)`、`listDirLevel(root, path)`、`splitPathSegments(path)`、`findNodeByPath(root, path)`

- [ ] **Step 1: 追加 AgentFileTree 类型 + flattenFiles(从网页端 :77/:404 原样移入,纯)**

在 `file-classify.ts` 末尾追加:

```ts
/** 单个数字员工的文件树(网页+移动共享) */
export interface AgentFileTree {
  agentId: string
  agentName: string
  workspace: string
  root: FileEntry
}

/** 树 → 扁平文件列表(递归收集非目录节点) */
export function flattenFiles(nodes: FileEntry[]): FileEntry[] {
  const result: FileEntry[] = []
  for (const node of nodes) {
    if (node.isDirectory) {
      result.push(...flattenFiles(node.children || []))
    } else {
      result.push(node)
    }
  }
  return result
}
```

- [ ] **Step 2: 追加 normalizeEntries(从网页端 :526-608 移入并纯函数化)**

依赖上移:`t(unknownLabel)` → 参数 `unknownLabel`;`getAgentName`/`getAgentOwnerName` → 调用方解析后塞进 `agent.name`/`agent.ownerUserName`。继续追加:

```ts
/**
 * batch-list 的扁平文件列表 → 带 children 的 FileEntry 树。
 * 纯函数:store/i18n 依赖由调用方通过 agent 对象 + unknownLabel 注入。
 */
export function normalizeEntries(
  entries: Array<Record<string, unknown>>,
  agent: { agentId: string; name: string; ownerUserName: string },
  workspace: string,
  unknownLabel: string,
): FileEntry[] {
  // Step 1: 扁平化(含嵌套 children)
  const flatRaw: Array<Record<string, unknown>> = []
  const collect = (list: Array<Record<string, unknown>>) => {
    for (const item of list) {
      flatRaw.push(item)
      const kids = item.children as Array<Record<string, unknown>> | undefined
      if (kids?.length) collect(kids)
    }
  }
  collect(entries)

  // Step 2: 归一 + 按 path 去重
  const seen = new Set<string>()
  const all: FileEntry[] = []
  for (const entry of flatRaw) {
    const path = String(entry.path || '')
    if (seen.has(path)) continue
    seen.add(path)
    const name = String(entry.name || path.split('/').pop() || unknownLabel)
    const isDirectory = Boolean(entry.isDirectory ?? entry.type === 'directory')
    all.push({
      id: createFileNodeId(agent.agentId, workspace, path),
      name,
      path,
      type: isDirectory ? 'directory' : 'file',
      isDirectory,
      size: typeof entry.size === 'number' ? entry.size : undefined,
      modifiedAt: typeof entry.updatedAtMs === 'number' ? new Date(entry.updatedAtMs).toISOString() : String(entry.modified || ''),
      extension: String(entry.extension || getExt({ name })),
      agentId: agent.agentId,
      agentName: agent.name,
      ownerUserName: agent.ownerUserName,
      workspace,
      children: [],
      loaded: false,
      expanded: false,
      loading: false,
    })
  }

  // Step 3: path prefix 建树
  const root: FileEntry[] = []
  const byPath = new Map<string, FileEntry>()
  for (const node of all) byPath.set(node.path, node)
  for (const node of all) {
    if (!node.path.includes('/')) {
      root.push(node)
      continue
    }
    let parent: FileEntry | undefined
    const parts = node.path.split('/')
    for (let i = parts.length - 1; i > 0; i--) {
      const candidate = byPath.get(parts.slice(0, i).join('/'))
      if (candidate?.isDirectory) { parent = candidate; break }
    }
    if (parent) {
      parent.children = parent.children || []
      parent.children.push(node)
    } else {
      root.push(node)
    }
  }

  // Step 4: 过滤隐藏 + 递归排序(目录在前,再按名)
  const filterAndSort = (nodes: FileEntry[]): FileEntry[] => {
    const filtered = nodes.filter((e) => e.name && !shouldHideFile(e))
    filtered.sort((a, b) => Number(b.isDirectory) - Number(a.isDirectory) || a.name.localeCompare(b.name, 'zh-Hans-CN'))
    for (const node of filtered) if (node.children?.length) node.children = filterAndSort(node.children)
    return filtered
  }
  return filterAndSort(root)
}
```

- [ ] **Step 3: 追加面包屑专用 findNodeByPath / listDirLevel / splitPathSegments(新增)**

```ts
/** 在树中按 path 查节点(广度优先即可,path 唯一) */
export function findNodeByPath(root: FileEntry, path: string): FileEntry | undefined {
  const normalized = normalizePath(path)
  if (!normalized) return root
  const stack: FileEntry[] = [root]
  while (stack.length) {
    const node = stack.pop()!
    if (node.path === normalized) return node
    for (const c of node.children || []) stack.push(c)
  }
  return undefined
}

/** 取当前路径下一层的子目录 + 文件(目录在前;目录按名,文件按 modifiedAt 降序) */
export function listDirLevel(root: FileEntry, currentPath: string): { dirs: FileEntry[]; files: FileEntry[] } {
  const node = findNodeByPath(root, currentPath)
  if (!node) return { dirs: [], files: [] }
  const children = node.children || []
  const toTs = (f: FileEntry): number => {
    const m = f.modifiedAt ? Date.parse(f.modifiedAt) : NaN
    return Number.isNaN(m) ? 0 : m
  }
  const dirs = children.filter((c) => c.isDirectory).sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN'))
  const files = children.filter((c) => !c.isDirectory).sort((a, b) => toTs(b) - toTs(a))
  return { dirs, files }
}

/** 路径分段(面包屑渲染) */
export function splitPathSegments(path: string): string[] {
  const n = normalizePath(path)
  return n ? n.split('/') : []
}
```

- [ ] **Step 4: 类型检查**

Run: `npm run build`
Expected: 通过(仅有 chunk-size warning)。新增代码此时未被引用,但类型须正确。

- [ ] **Step 5: Commit**

```bash
git add src/utils/file-classify.ts
git commit -m "refactor: file-classify 抽入共享建树逻辑 normalizeEntries/flattenFiles/listDirLevel(网页+移动 SSOT)"
```

---

## Task 2: 网页端 FileManagerPage 改用 SSOT(行为等价)

**Files:**
- Modify: `src/views/files/FileManagerPage.vue`(:77 删 AgentFileTree、:370 保留 getAgentDisplayName、:404 删 flattenFiles、:526-608 删 normalizeEntries、:626 和 :751 调用点改参)

**Interfaces:**
- Consumes: Task 1 的 `AgentFileTree`/`flattenFiles`/`normalizeEntries`(from `@/utils/file-classify`)
- Produces: 网页端行为不变的文件管理(回归基线)

- [ ] **Step 1: import 改造**

在 FileManagerPage.vue 的 import 区(已有 `import { ... } from '@/utils/file-classify'`),把 `AgentFileTree`/`flattenFiles`/`normalizeEntries` 加入该 import 列表(若已 import `classifyFile`/`shouldHideFile` 等则合并到同一行)。

- [ ] **Step 2: 删本地三个定义**

- 删 `export interface AgentFileTree { ... }`(:77-82)
- 删 `interface VisibleAgentFileTree { ... }`(:84-89)**保留**(它是网页端视图层私有类型,不入 SSOT)
- 删 `function flattenFiles(...)`(:404-414)
- 删 `function normalizeEntries(...)`(:526-608)

> 注:`getAgentDisplayName`(:370)/`getAgentName`/`getAgentOwnerName` **保留**(网页端视图层,含 `authStore.isAdmin` 逻辑),它们的查询结果将作为参数传给 normalizeEntries。

- [ ] **Step 3: 改调用点 :626(buildTrees 循环内)**

原:
```ts
const agent = workspaceStore.agents.find(a => a.agentId === agentId)
const children = normalizeEntries(info.files || [], agent || { agentId, name: info.name || agentId }, info.workspace)
```
改为(把 name/ownerUserName 解析后注入):
```ts
const agent = workspaceStore.agents.find(a => a.agentId === agentId)
const resolvedName = (agent && getAgentName(agentId)) || info.name || agentId
const children = normalizeEntries(
  info.files || [],
  { agentId, name: resolvedName, ownerUserName: getAgentOwnerName(agentId) },
  info.workspace,
  t('pages.fileManager.unknownFile'),
)
```

- [ ] **Step 4: 改调用点 :751(单文件刷新)**

原:
```ts
normalizeEntries(data.files || [], { agentId: target.agentId, name: target.agentName }, target.workspace)
```
改为:
```ts
normalizeEntries(
  data.files || [],
  { agentId: target.agentId, name: target.agentName, ownerUserName: getAgentOwnerName(target.agentId) },
  target.workspace,
  t('pages.fileManager.unknownFile'),
)
```

- [ ] **Step 5: 类型检查**

Run: `npm run build`
Expected: 通过。

- [ ] **Step 6: 网页端手动回归(关键)**

启动前端,在网页文件管理页验证不回归:
- 员工树正常展开/折叠
- 关键字搜索过滤
- 类型筛选(文档/图片/...)计数正确
- 单文件下载、删除
- admin 用户看到 `owner / name` 显示名

Expected: 全部与抽取前一致。

- [ ] **Step 7: Commit**

```bash
git add src/views/files/FileManagerPage.vue
git commit -m "refactor: FileManagerPage 改用 file-classify 共享建树 SSOT(行为等价)"
```

---

## Task 3: session-time.ts 新增 pickMostActiveAgentId

**Files:**
- Modify: `src/utils/session-time.ts`(末尾追加)

**Interfaces:**
- Consumes: 同文件 `sessionEffectiveTs(session: SessionLike)`、`SessionLike`
- Produces: `pickMostActiveAgentId(agents): string`

- [ ] **Step 1: 追加 pickMostActiveAgentId**

在 `session-time.ts` 末尾追加(`AgentWithSessions` 的 `sessions` 字段对齐 `SessionLike`,用结构类型避免硬依赖 workspace store):

```ts
/**
 * 在给定 agent 集合内,按其会话最近活动(sessionEffectiveTs)取最大者。
 * 无会话者 ts=0 沉底;全部无会话返回首个;空数组返回 ''。
 * 数据源单一(workspaceStore.agents 自带 sessions),零跨 store。
 */
export function pickMostActiveAgentId<T extends { agentId: string; sessions?: SessionLike[] }>(
  agents: T[],
): string {
  if (agents.length === 0) return ''
  let best = agents[0]!
  let bestTs = -Infinity
  for (const a of agents) {
    let max = 0
    for (const s of a.sessions || []) {
      const ts = sessionEffectiveTs(s)
      if (ts > max) max = ts
    }
    if (max > bestTs) { bestTs = max; best = a }
  }
  return best.agentId
}
```

- [ ] **Step 2: 类型检查**

Run: `npm run build`
Expected: 通过。

> 若 `SessionLike` 的字段(workspace agent.sessions 实际形状)与 `sessionEffectiveTs` 入参不完全匹配,补 `SessionLike` 的可选字段(lastActivity/updatedAt 均为可选)——参照同文件既有定义,保持结构类型宽松。

- [ ] **Step 3: Commit**

```bash
git add src/utils/session-time.ts
git commit -m "feat: session-time 新增 pickMostActiveAgentId(会话最近活动选默认员工)"
```

---

## Task 4: MobileFilesPage 改造(面包屑 + 默认最活跃员工)

**Files:**
- Modify: `src/mobile/views/files/MobileFilesPage.vue`(script + template)

**Interfaces:**
- Consumes: Task 1 `normalizeEntries`/`listDirLevel`/`splitPathSegments`/`AgentFileTree`/`flattenFiles`;Task 3 `pickMostActiveAgentId`;已有 `classifyFile`/`createFileNodeId`/`getExt`
- Produces: 文件夹层级(面包屑)+ 默认最活跃员工的移动端文件管理

- [ ] **Step 1: import 与类型调整**

import 区:从 `@/utils/file-classify` 增加 `normalizeEntries`、`listDirLevel`、`splitPathSegments`、`AgentFileTree`(保留已有 `FileEntry`/`FileTypeFilter`/`classifyFile`/`getExt`/`shouldHideFile`/`createFileNodeId`/`formatSize`)。删去仅服务于旧 `flattenFiles` 的 `BatchAgentInfo` 对 files 的强依赖(类型保留用于 batch-list 解析)。

从 `@/utils/session-time` 增加 `pickMostActiveAgentId`。

- [ ] **Step 2: 删旧 flattenFiles,改 state**

删 `function flattenFiles(...)`(:129-175)。state 区改为:

```ts
const agentTrees = shallowRef<AgentFileTree[]>([])
const currentAgentId = ref<string>('')        // '' = 全部
const currentPath = ref<string>('')           // 员工树内路径,'' = 根
```
保留 `loading`/`errorMsg`/`currentType`/各 Drawer/show 状态。

- [ ] **Step 3: loadFiles 建 agentTrees + 默认员工**

替换 `loadFiles`(:176-)中 `allFiles.value = flattenFiles(data.agents || {})` 为:

```ts
const trees: AgentFileTree[] = []
for (const [agentId, info] of Object.entries(data.agents || {})) {
  const agent = workspaceStore.agents.find((a) => a.agentId === agentId) as unknown as WorkspaceAgentLike | undefined
  const name = agent?.identity?.name || agent?.name || info.name || agentId
  const ownerUserName = agent?.ownerName || ''
  const root: FileEntry = {
    id: createFileNodeId(agentId, info.workspace, ''),
    name,
    path: '',
    type: 'directory',
    isDirectory: true,
    agentId,
    agentName: name,
    ownerUserName,
    workspace: info.workspace,
    children: normalizeEntries(info.files || [], { agentId, name, ownerUserName }, info.workspace, t('pages.fileManager.unknownFile')),
    loaded: true,
    expanded: true,
    loading: false,
  }
  trees.push({ agentId, agentName: name, workspace: info.workspace, root })
}
trees.sort((a, b) => a.agentName.localeCompare(b.agentName, 'zh-Hans-CN'))
agentTrees.value = trees
// 默认选最活跃员工(仅首次加载;用户已手动切换则不覆盖)
if (!currentAgentId.value) {
  currentAgentId.value = pickMostActiveAgentId(workspaceStore.agents)
}
```
错误分支 `allFiles.value = []` 改 `agentTrees.value = []`。

- [ ] **Step 4: 新增 computed(当前树/层/面包屑/全部模式列表/计数)**

```ts
const currentTree = computed<AgentFileTree | undefined>(() =>
  agentTrees.value.find((t) => t.agentId === currentAgentId.value),
)
const isAllMode = computed(() => currentAgentId.value === '')

// 单员工:当前层目录 + 文件(类型筛选作用于文件)
const currentLevel = computed(() => {
  if (!currentTree.value) return { dirs: [] as FileEntry[], files: [] as FileEntry[] }
  const level = listDirLevel(currentTree.value.root, currentPath.value)
  const type = currentType.value
  const files = type === 'all' ? level.files : level.files.filter((f) => classifyFile(f) === type)
  return { dirs: level.dirs, files }
})

// 全部模式:顶层员工条目(复用既有 agentOptions 的 avatar/name,join 文件数)
const agentListEntries = computed(() =>
  agentOptions.value
    .map((opt) => {
      const tree = agentTrees.value.find((t) => t.agentId === opt.agentId)
      return tree ? { opt, tree, count: flattenFiles(tree.root.children || []).length } : null
    })
    .filter((x): x is { opt: AgentOption; tree: AgentFileTree; count: number } => Boolean(x)),
)

// 计数(hero 用):当前可见范围文件总数
const visibleFileCount = computed(() =>
  isAllMode.value
    ? agentTrees.value.reduce((n, t) => n + flattenFiles(t.root.children || []).length, 0)
    : flattenFiles(currentTree.value?.root.children || []).length,
)

// 面包屑
const breadcrumb = computed(() => {
  const segs = splitPathSegments(currentPath.value)
  const head = isAllMode.value ? t('pages.mobile.files.allAgents') : (currentTree.value?.agentName || '')
  return { head, segs }
})
```

- [ ] **Step 5: 导航函数 + 切员工/类型重置**

```ts
function enterDir(dir: FileEntry) { currentPath.value = dir.path }
function goUp() {
  const segs = splitPathSegments(currentPath.value)
  segs.pop()
  currentPath.value = segs.join('/')
}
function enterAgent(agentId: string) { currentAgentId.value = agentId; currentPath.value = '' }
function backToAll() { currentAgentId.value = ''; currentPath.value = '' }

function pickAgent(agentId: string) { currentAgentId.value = agentId; currentPath.value = '' }   // 替换原 :283
function pickType(type: FileTypeFilter) { currentType.value = type; currentPath.value = '' }     // 替换原 :279,加 reset
```
> 原有 `pickType`/`pickAgent`(`:279`/`:283`)签名替换为上面两行(均加 `currentPath.value = ''`)。

- [ ] **Step 6: 数据刷新后路径失效兜底**

在 `loadFiles` 末尾(构建 trees 后)加:
```ts
// 若 currentPath 在新当前树中不存在,回退根
if (currentPath.value && currentTree.value && !listDirLevel(currentTree.value.root, currentPath.value).dirs.length && !listDirLevel(currentTree.value.root, currentPath.value).files.length && currentPath.value !== '') {
  // 仅当该路径既无子目录也无文件才视为失效
  const exists = findNodeByPath(currentTree.value.root, currentPath.value)
  if (!exists) currentPath.value = ''
}
```
(import `findNodeByPath` from `@/utils/file-classify`)

- [ ] **Step 7: template 改造——面包屑条 + 列表分支**

在 `.filters`(:303)与列表区(:329)之间插入面包屑条(仅单员工且非根时显示):

```html
<div v-if="!isAllMode && breadcrumb.segs.length" class="breadcrumb fade-up" style="--d: 120ms">
  <button class="breadcrumb__crumb" type="button" @click="currentPath = ''">{{ breadcrumb.head }}</button>
  <template v-for="(seg, i) in breadcrumb.segs" :key="i">
    <span class="breadcrumb__sep">/</span>
    <button
      v-if="i < breadcrumb.segs.length - 1"
      class="breadcrumb__crumb"
      type="button"
      @click="currentPath = breadcrumb.segs.slice(0, i + 1).join('/')"
    >{{ seg }}</button>
    <span v-else class="breadcrumb__current">{{ seg }}</span>
  </template>
</div>
```

列表区(:329-347)改为双分支(全部模式 = 员工列表;单员工 = 当前层 dirs+files):

```html
<div v-if="loading" class="state-hint">{{ t('pages.mobile.files.loading') }}</div>
<div v-else-if="errorMsg" class="state-hint state-hint--error">{{ errorMsg }}</div>

<!-- 全部模式:员工列表 -->
<template v-else-if="isAllMode">
  <EmptyState v-if="agentListEntries.length === 0" :description="t('pages.mobile.files.empty')" />
  <div v-else class="file-list fade-up" style="--d: 150ms">
    <div
      v-for="entry in agentListEntries"
      :key="entry.tree.agentId"
      class="file-item agent-item"
      @click="enterAgent(entry.tree.agentId)"
    >
      <img
        v-if="isImageAvatar(agentDisplayAvatar(entry.opt))"
        class="agent-item__avatar"
        :src="agentDisplayAvatar(entry.opt)"
      />
      <span v-else class="agent-item__avatar">{{ agentDisplayAvatar(entry.opt) }}</span>
      <div class="file-item__body">
        <div class="file-item__name">{{ entry.tree.agentName }}</div>
        <div class="file-item__meta">{{ t('pages.mobile.files.countLabel', { n: entry.count }) }}</div>
      </div>
      <span class="material-symbols-outlined file-item__more">chevron_right</span>
    </div>
  </div>
</template>

<!-- 单员工:当前层目录 + 文件 -->
<template v-else>
  <EmptyState
    v-if="currentLevel.dirs.length === 0 && currentLevel.files.length === 0"
    :description="t('pages.mobile.files.empty')"
  />
  <div v-else class="file-list fade-up" style="--d: 150ms">
    <!-- 目录 -->
    <div
      v-for="dir in currentLevel.dirs"
      :key="dir.id"
      class="file-item"
      @click="enterDir(dir)"
    >
      <span class="material-symbols-outlined file-item__icon">folder</span>
      <div class="file-item__body">
        <div class="file-item__name">{{ dir.name }}</div>
      </div>
      <span class="material-symbols-outlined file-item__more">chevron_right</span>
    </div>
    <!-- 文件(沿用原 file-item 结构,openPreview/openAction 不变) -->
    <div
      v-for="f in currentLevel.files"
      :key="f.id"
      class="file-item"
      @click="openPreview(f)"
    >
      <span class="material-symbols-outlined file-item__icon">{{ fileIcon(f.name) }}</span>
      <div class="file-item__body">
        <div class="file-item__name">{{ f.name }}</div>
        <div class="file-item__meta">{{ f.agentName }} · {{ formatRelative(f.modifiedAt) }} · {{ formatSize(f.size) }}</div>
      </div>
      <span class="material-symbols-outlined file-item__more" @click.stop="openAction(f)">more_vert</span>
    </div>
  </div>
</template>
```

> 文件段(`currentLevel.files` 的 v-for)的 `file-item` 内部结构(图标 helper / meta 格式 / `openPreview` / `openAction`)**原样复用原 :334-347 模板**——执行者打开文件比对原渲染,保留其图标函数与 meta 拼接方式,仅把 `v-for` 数据源由 `filteredFiles` 换成 `currentLevel.files`。原 `filteredFiles` v-for 块整体替换为上面 dirs+files 双段。

- [ ] **Step 8: 删旧 filteredFiles / currentAgentLabel 等不再需要的 computed**

删 `filteredFiles`(:97)、`typeCounts`/`allFiles` 相关引用(:43/:88/:90/:299 hero countLabel 改 `visibleFileCount`)。hero 计数(:299)由 `allFiles.length` 改 `visibleFileCount`。`currentAgentLabel`/`currentAgentOption`(:107-112)保留(员工胶囊仍用)。

- [ ] **Step 9: 类型检查**

Run: `npm run build`
Expected: 通过。

- [ ] **Step 10: 手机手动验收**

- 默认进入 = 最活跃员工的根层文件/目录
- 点文件夹进入,面包屑出现,逐级返回正确
- 「全部」员工胶囊 → 顶层员工列表,点员工进入其树
- 切员工/切类型 → 面包屑回根
- 最活跃员工无文件 → 空状态(不回退全部)
- 文件预览/下载/删除(⋮)不回归

- [ ] **Step 11: Commit**

```bash
git add src/mobile/views/files/MobileFilesPage.vue
git commit -m "feat: 移动端文件管理面包屑文件夹层级+默认最活跃员工(每员工独立树)"
```

---

## Task 5: i18n 文案补全

**Files:**
- Modify: `src/i18n/zh-CN.ts`(`pages.mobile.files` 段)

**Interfaces:**
- Consumes: Task 4 引用的 i18n key
- Produces: 完整中文文案

- [ ] **Step 1: 追加 key**

在 `pages.mobile.files` 段补齐(已有 `allAgents`/`countLabel`/`empty`/`loading` 等保留):

```ts
breadcrumb: {
  root: '根目录',
  back: '返回上层',
},
agentGroup: '数字员工',
emptyAgent: '该员工暂无文件',
```
(Task 4 template 实际引用的 key 以最终代码为准,确保每个 `t('pages.mobile.files.*')` 都有对应条目。)

- [ ] **Step 2: 类型检查 + Commit**

Run: `npm run build` → Expected: 通过。

```bash
git add src/i18n/zh-CN.ts
git commit -m "feat: 移动端文件管理补面包屑/员工分组 i18n(zh-CN)"
```

---

## 验收清单(对齐 spec §8)

- [ ] 每员工独立树,面包屑逐级进入/返回(Task 4)
- [ ] 默认选会话最近活动员工(Task 3+4)
- [ ] 全部模式顶层员工列表,可进入(Task 4)
- [ ] 切员工/类型回根(Task 4)
- [ ] 最活跃无文件空状态不回退(Task 4)
- [ ] **网页端不回归**(Task 2 手动)
- [ ] 文件预览/下载/删除不回归(Task 4 手动)
- [ ] `npm run build` 绿(每 Task)
