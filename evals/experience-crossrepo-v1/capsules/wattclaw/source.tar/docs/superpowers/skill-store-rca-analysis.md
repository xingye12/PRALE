# 技能商店模块 GAP Analysis（根因分析报告）

> 生成时间：2026-05-18
> 分析范围：`skill-store-module.md` 技术文档 vs 当前代码实现

---

## 一、文档与代码交叉对比结论

| 维度 | `skill-store-module.md` 规约 | 当前代码实际状态 | 偏差等级 |
|------|---------------------------|---------------|---------|
| **Store State** | `activeTab: 'store' \| 'manage'` 等 10 项 state | 完全对齐 | 🟢 |
| **Store Actions** | `scanGateway` / `installSkill` / `toggleSkill` / `deleteSkill` | 完全对齐 | 🟢 |
| **Store Tab UI** | Grid 卡片、分类 Pill、搜索、扫描、全局折叠区 | 功能存在，视觉严重不达标 | 🟡 |
| **Manage Tab UI** | 表格/列表视图、统计栏、Switch 开关、Agent Tag 列表 | 仅有简陋 grid，像素级缺失 | 🔴 |
| **组件拆分** | Store / Manage / Detail / AgentSelect 独立子组件 | 全部 inline 在 921 行的单文件中 | 🔴 |
| **类型定义** | `SkillStoreSkill` + `isGlobal` 扩展 | 运行时断言 `(skill as any).isGlobal` | 🟡 |

**核心结论：数据层（Store + API）已经是完备的，灾难完全集中在视图层。当前 `SkillStorePage.vue` 是一个 921 行的单文件组件，同时承担了商店展示、管理列表、详情弹窗、Agent 选择四个独立视图的职责，且 Manage Tab 的 UI 是临时拼凑的 grid 布局，与目标截图差距极大。**

> **重要校准**：本重构严格以 `skill-store-module.md` 的数据模型与 API 为唯一真理源。截图仅提供布局、排版、色彩等视觉规范。所有后端不支持的伪需求（如创建技能、更新技能）已全部抹杀。

---

## 二、精确缺失清单（按层级）

### 2.1 Pinia Store 层缺失

当前 Store 实际上**已包含**文档要求的全部 state 和 action，无需新增。但存在以下**使用侧缺口**：

| 缺失项 | 说明 |
|-------|------|
| `manageSearch` 隔离 | 当前 `search` 在 Manage Tab 未生效，且 Store/Manage 共享同一搜索词不合理 |
| `stats` 计算属性 | 管理页顶部的"共 X 个技能，已启用 Y 个"需要前端聚合计算（仅使用已有数据，无新 API） |

### 2.2 SkillStorePage.vue 层缺失

| 缺失项 | 截图参考 | 当前代码 |
|-------|---------|---------|
| **页面级搜索栏** | 位于 Tab 切换下方，全局共享 | 仅放在 Store Tab 内部 |
| **分类 Pill 标签栏** | 横向可滚动标签（精选/生产力/AI技术...） | 仅有 `NSelect` 下拉框 |
| **统计信息栏** | "共有 93 个技能，已启用 33 个" | 完全缺失 |
| **Manage 表格视图** | 标准列表：Icon+名称+类型+版本+Agent Tags+Switch+删除 | 仅有 grid 拼凑 |
| **Agent Tag 折叠** | 当绑定 Agent 过多时显示 "+5" 等折叠 | 缺失 |
| **管理页 Switch 开关** | 每行最右侧独立启用/停用 | 有逻辑但布局错误（嵌套在 grid 里） |

> **伪需求抹杀声明**：以下截图元素因后端无对应 API/数据模型支持，已彻底排除：
> - "+ 创建技能"按钮（无 `/skills/create` 接口）
> - "可更新 N 个"统计与"更新..."操作（无版本对比与更新端点）

### 2.3 子组件拆分缺失

当前所有视图 inline 在 `SkillStorePage.vue`（921 行）。必须拆分为：

1. **`SkillStoreTab.vue`** — 商店主视图（分类 Pill + Grid + 全局折叠区）
2. **`SkillManageTab.vue`** — 管理视图（统计栏 + 列表/表格 + Switch）
3. **`SkillDetailModal.vue`** — 详情弹窗（从当前 inline 提取）
4. **`AgentSelectModal.vue`** — Agent 选择弹窗（从当前 inline 提取）
5. **`SkillStorePage.vue`** — 仅保留容器职责（Tab 切换、数据加载、弹窗状态管理）

### 2.4 TypeScript 类型缺口

| 问题 | 位置 |
|------|------|
| `isGlobal` 运行时扩展未声明 | `allSkills.value` 返回 `(SkillStoreSkill & { isGlobal: boolean })[]`，但多处模板用 `(store.selectedSkill as any).isGlobal` 绕过类型检查 |
| `agents` 数组元素字段不一致 | 后端返回 `agent_id` / `agent_name`（snake_case），但文档中的类型定义混用了 camelCase，当前代码使用时靠运行时容错 |

### 2.5 i18n 缺失键

| 键 | 用途 |
|---|------|
| `pages.skillStore.stats.total` | "共有 {count} 个技能" |
| `pages.skillStore.stats.enabled` | "已启用 {count} 个" |
| `pages.skillStore.searchPlaceholder` | 需更新为截图文案（含 ↵ 提示） |

---

## 三、UI 布局结构拆解（基于截图）

### 3.1 技能商店 (img.jpg)

```
┌─────────────────────────────────────────────────────────────┐
│ [技能商店] [技能管理]      [🔍 搜索技能，按 ↵ 搜索]              │
├─────────────────────────────────────────────────────────────┤
│ [精选] [生产力] [AI技术] [办公提效] [学术教育] ...（横向Pills） │
├─────────────────────────────────────────────────────────────┤
│ ┌──────────┐ ┌──────────┐ ┌──────────┐                     │
│ │ [Icon]   │ │ [Icon]   │ │ [Icon]   │   ... Grid 布局      │
│ │ 标题     │ │ 标题     │ │ 标题     │                     │
│ │ 描述     │ │ 描述     │ │ 描述     │                     │
│ │      [已安装]                        │                     │
│ └──────────┘ └──────────┘ └──────────┘                     │
├─────────────────────────────────────────────────────────────┤
│ ▼ 已全局内置 (12)                                           │
│ ┌──────────┐ ┌──────────┐                                  │
│ │ [Icon] 标题 │ │ [Icon] 标题 │   （dashed border 卡片）      │
│ └──────────┘ └──────────┘                                  │
└─────────────────────────────────────────────────────────────┘
```

**关键布局规则：**
- 搜索栏 + 创建按钮在 Tab 切换下方，**全局共享**
- 分类 Pill 是横向按钮组，非下拉选择器
- 卡片 Grid：`grid-template-columns: repeat(auto-fill, minmax(280px, 1fr))`
- 卡片内：左侧 44×44 圆角色块+Icon，中间标题（15px/600）+ 描述（13px/secondary，2行截断），右侧 action slot
- 悬浮：`transform: translateY(-3px)` + `box-shadow` 过渡

### 3.2 技能管理 (img_1.jpg)

```
┌─────────────────────────────────────────────────────────────┐
│ [技能商店] [技能管理]      [🔍 搜索技能，按 ↵ 搜索]              │
├─────────────────────────────────────────────────────────────┤
│ 共有 93 个技能，已启用 33 个                                   │
├─────────────────────────────────────────────────────────────┤
│ 技能名称      类型    版本    使用的数字员工        状态   操作 │
├─────────────────────────────────────────────────────────────┤
│ [Icon] 名称   [私有]  1.0.0   [股票大师] [公众号]   [🟢]  [删除] │
│ 描述...                      +5                     Switch  │
│ ─────────────────────────────────────────────────────────── │
│ [Icon] 名称   [内置]  10.0.0  [主龙虾] [公众号]    [🟢]  [删除] │
│                               +5                   Switch  │
└─────────────────────────────────────────────────────────────┘
```

**关键布局规则：**
- 统计栏独立一行，文案灰色，数字高亮
- 列表/表格混合布局：每条是一个水平 flex/card 行
- 左侧：Icon（36px）+ 名称（15px/600）+ 描述（12px/secondary）
- 中间：类型 Tag（small/info|warning）+ 版本（monospace）+ Agent Tag 列表（small/success|default）
- 右侧：状态 NSwitch（绿色=启用）+ 操作按钮组
- Agent 过多时折叠为 "+N" Tag
- 行高亮：hover 时边框色变化

---

## 四、重构范围界定

### 保留不动（红线内）
1. `src/stores/skill-store.ts` — State/Action 逻辑完备，仅可能补充 `stats` computed（或留在视图层）
2. `server/index.js` / 数据库 Schema — 零修改
3. `store.scanGateway()` 扫描逻辑 — 原样调用
4. `isGlobal = s.source !== 'store'` 判断 — 原样保留
5. Agent Select Modal 数据流 + `installSkill` 调用链 — 原样保留
6. Detail Modal 的 `isGlobal` 分支逻辑（删除/安装 vs 只读标签）— 原样保留

### 必须重写
1. `SkillStorePage.vue` — 瘦身至 150 行以内，仅保留容器骨架
2. 新建 `SkillStoreTab.vue` — 商店视图（Pill + Grid + 全局折叠）
3. 新建 `SkillManageTab.vue` — 管理视图（统计 + 列表 + Switch）
4. 可选提取 `SkillDetailModal.vue` / `AgentSelectModal.vue`（视 Page 瘦身情况）
5. `SkillCard.vue` — 基于截图优化样式（当前已较接近，可复用并微调）
6. i18n 补充缺失键

### 类型修复
1. 声明 `SkillStoreSkill & { isGlobal: boolean }` 的正式类型别名，消灭所有 `as any`
