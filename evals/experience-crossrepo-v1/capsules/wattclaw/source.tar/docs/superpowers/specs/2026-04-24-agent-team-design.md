# 数字员工团队功能设计

## 概述

在 WattClaw 中新增"数字员工团队"模块，参考飞书 AI 智能体界面的设计风格，实现 Agent 的创建、编辑和管理功能。数据存储在本地 SQLite，前端采用独立路由页面。

## 设计风格

参考飞书界面设计，核心视觉特征：
- 背景：浅灰白 (#F5F7FA)，使用现有 CSS 变量
- 卡片：白色、圆角 12px、轻微阴影
- 按钮：圆角 8px，深色主操作 / 浅灰次操作
- 文字：深灰主色 (#1F2937) / 浅灰辅色 (#6B7280)，使用现有 CSS 变量
- 间距：模块间距 16-24px
- 组件圆角：按钮 4-8px，卡片 12px

## 路由

在 `src/router/routes.ts` 的 `'/'` children 数组中添加：

| 路由 | name | 页面 | 说明 |
|------|------|------|------|
| `agents-team` | AgentTeam | AgentTeamPage.vue | 团队主页：Agent 卡片列表 |
| `agents-team/:id` | AgentTeamEdit | AgentEditPage.vue | Agent 编辑页：左右分栏 |

创建弹窗（模板选择 + 自定义创建）在团队主页中以 Modal 形式展示。

## 与现有系统集成

### 与现有 `user_agents` 表的关系

现有 `user_agents` 表（定义在 `server/database.js:165`，CRUD 在 `server/user-manager.js:166-211`，API 在 `server/index.js:390-419`）：
- 关联 `gateway_agent_id`，是 Gateway agent 到用户的映射（运维级）
- 有 `system_prompt`、`config`（JSON）等简单配置

新 `agent_team` 表：
- 无 `gateway_agent_id`，是用户级数字员工人设（业务级）
- 有 `soul_md` / `agents_md` / `identity_md` / `user_md` 深度角色配置

两者独立但互补：
- `/agents`（现有）— 展示 Gateway 层注册的 agent（系统级，运维视角）
- `/agents-team`（新增）— 用户级数字员工（业务视角，面向普通用户）
- 后续 v2 实现"去对话"时，可在 `agent_team` 表中增加 `user_agent_id` 字段关联到 `user_agents`，实现从数字员工到聊天 session 的链路

### 用户隔离

WattClaw 是多用户系统。遵循现有 `/api/user/agents` 的模式（`server/index.js:390-419`）：
- 每条记录通过 `created_by` 字段关联到 `users` 表
- 查询时用 `WHERE created_by = ?` 过滤当前用户的数据
- 更新/删除时先查当前用户的列表确认所有权
- 管理员（`req.currentUser.role === 'admin'`）可操作任何人的数据

### 数据库集成

新表添加到现有 `server/database.js` 的第二个 `db.exec()` 块中（第138-216行区域），遵循现有模式：
- `INTEGER DEFAULT (strftime('%s', 'now') * 1000)` 时间戳（毫秒）
- `FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE`
- `CREATE INDEX IF NOT EXISTS` 索引
- CRUD 函数导出为 named exports（如 `getAgentTeamList`、`createAgentTeam` 等）

### 模型选择

编辑页的模型下拉复用 `useModelStore`（`src/stores/model.ts`），数据来自 Gateway RPC（`wsStore.rpc.listModels()`）。Store 已有 `models: ModelInfo[]` 列表和 `fetchModels()` 方法，直接在编辑页中调用。`ModelInfo` 类型包含 `id`、`label`、`provider`、`available` 等字段。

### 聊天预留

v1 不实现"去对话"，但数据模型预留：
- 后续实现时，可通过 session key 格式 `agent:agentTeamId:sessionKey` 接入现有 Chat 系统（`src/stores/chat.ts`，`setSessionKey()` 方法）
- 编辑页"去对话"按钮 v1 显示为灰色禁用状态
- v2 可在表中增加 `user_agent_id` 字段关联到 `user_agents`，建立数字员工与 Gateway agent 的连接

### 侧边栏

侧边栏菜单从路由 `meta` 自动生成（`src/components/layout/AppSidebar.vue:46-58`）。只需在 `routes.ts` 中添加带 `meta.titleKey` 和 `meta.icon` 的路由配置，无需手动修改 `AppSidebar.vue`。

图标映射在 `AppSidebar.vue:20-39` 的 `materialIconMap` 中。现有 `PeopleOutline` 已被 `/agents`（第113行）和 `/users`（第149行）使用。新页面使用 `SmartToyOutline`，需要在 `materialIconMap` 中新增映射：`SmartToyOutline: 'smart_toy'`。

### i18n

遵循现有模式：
- 路由翻译：`routes.agentTeam` / `routes.agentTeamEdit`
- 页面翻译：`pages.agentTeam.*` 层级（如 `pages.agentTeam.title`、`pages.agentTeam.create.title`）
- 同时更新 `src/i18n/messages/zh-CN.ts` 和 `src/i18n/messages/en-US.ts`

## 数据模型

### SQLite 表 `agent_team`

在 `server/database.js` 的第二个 `db.exec()` 块（第138-216行区域）中添加：

```sql
CREATE TABLE IF NOT EXISTS agent_team (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  avatar TEXT,
  model TEXT,
  status TEXT DEFAULT 'idle',
  soul_md TEXT,
  agents_md TEXT,
  identity_md TEXT,
  user_md TEXT,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_agent_team_created_by ON agent_team(created_by);
```

### CRUD 函数（添加到 `server/database.js`）

遵循现有 `createBackupRecord` / `getUserAgents` 等函数的导出模式：

- `getAgentTeamList(userId)` — `SELECT * FROM agent_team WHERE created_by = ? ORDER BY created_at DESC`
- `getAgentTeamById(id)` — `SELECT * FROM agent_team WHERE id = ?`
- `createAgentTeam(userId, data)` — INSERT 并返回新记录
- `updateAgentTeam(id, data)` — UPDATE 动态字段并更新 `updated_at`
- `deleteAgentTeam(id)` — DELETE BY id
- `getAgentTeamStats(userId)` — 聚合统计（COUNT、最早创建时间等）

## 后端 API

在 `server/index.js` 中添加路由，遵循现有 `/api/user/agents` 的内联路由模式（第390-419行）。

关键实现细节：
- 认证：使用现有 `authMiddleware`，通过 `req.currentUser.id` 获取当前用户 ID
- 响应格式：`{ ok: true, data }` 或 `{ ok: false, error: 'message' }`
- 权限校验：参照 `server/index.js:400-418` 的模式，先获取用户列表再校验所有权

| 方法 | 路径 | 说明 | 响应 |
|------|------|------|------|
| GET | `/api/agent-team/list` | 获取当前用户的 Agent 列表 | `{ ok: true, list: [...] }` |
| GET | `/api/agent-team/:id` | 获取单个 Agent 详情 | `{ ok: true, agent: {...} }` |
| POST | `/api/agent-team/create` | 创建新 Agent | `{ ok: true, agent: {...} }` |
| PUT | `/api/agent-team/:id` | 更新 Agent | `{ ok: true, agent: {...} }` |
| DELETE | `/api/agent-team/:id` | 删除 Agent | `{ ok: true }` |

## 预设模板

8 个预设角色，硬编码在前端常量中：

1. 全栈开发工程师 — 精通前后端技术栈，快速交付高质量代码与架构方案
2. 招投标助手 — 全网扫描招投标中标数据与政府采购信息，确保不遗漏任何商机线索
3. HR招聘助手 — 智能化人才筛选与简历分析，助力高效精准招聘
4. 数据分析师 — 深度数据挖掘与可视化报告，驱动业务决策优化
5. 产品经理助手 — 需求分析、竞品调研、PRD撰写，辅助产品全流程管理
6. 内容运营助手 — 文案创作、选题策划、社群运营，提升内容产出效率
7. 客服助手 — 智能问答、工单处理、用户反馈分析，提升客户满意度
8. 法务助手 — 合同审查、法律咨询、合规检查，降低企业法律风险

每个模板包含预设的 name、avatar、description、soulMd 默认值。

## 页面设计

### 团队主页 `AgentTeamPage.vue`

1. **顶部信息栏**：团队头像 + "数字员工团队" 标题 + 统计（成员数/最近消息/完成任务）+ "新建数字员工"按钮
2. **卡片网格**：响应式布局（桌面 2-3 列），每张卡片展示：
   - 头像（圆形，带彩色背景）
   - 名称 + 描述
   - 统计数据（陪伴天数/近期消息/完成任务）
   - "去对话"按钮（v1 禁用）
   - 更多菜单（编辑/删除）

### 创建弹窗 `CreateAgentModal.vue`

两层结构：
1. **模板选择弹窗**（默认展示）：3x3 网格，8 个预设模板 + 1 个"自定义创建"（虚线边框）
2. **自定义创建弹窗**（点击"自定义创建"后展示）：名称输入 + 头像 Emoji 选择（2 行网格）+ 描述文本框 + "创建"按钮

选择预设模板 → 自动填充模板数据 → 调用创建 API → 跳转编辑页
选择自定义 → 填写表单 → 调用创建 API → 跳转编辑页

### 编辑页 `AgentEditPage.vue`

左右分栏布局：
- **左侧栏**（~280px 固定宽度）：
  - 头像（圆形）+ 名称 + 描述 + 状态标签
  - 模型选择下拉（数据来自 `useModelStore`）
  - 统计数据（3 个数字卡片：陪伴天数/近期消息/完成任务）
  - "去对话"按钮（v1 禁用灰色）

- **右侧主区**（自适应宽度）：
  - Tab 导航：行为准则 | 工作流程 | 智能体档案 | 用户档案
  - 每个 Tab：标题说明 + textarea 编辑器（显示对应 Markdown 内容）
  - 右上角"保存"按钮
  - 自动保存（500ms 防抖）

## 前端文件结构

```
src/
├── views/agent-team/
│   ├── AgentTeamPage.vue          # 团队主页
│   ├── AgentEditPage.vue          # Agent 编辑页
│   ├── AgentCard.vue              # Agent 卡片组件
│   ├── CreateAgentModal.vue       # 创建弹窗（模板选择 + 自定义）
│   └── AgentTemplateGrid.vue      # 模板网格组件
├── stores/
│   └── agent-team.ts              # Pinia store
├── api/types/
│   └── agent-team.ts              # 类型定义（添加到 barrel export）
```

### 类型定义 `src/api/types/agent-team.ts`

```typescript
export interface AgentTeamMember {
  id: string
  name: string
  description: string
  avatar: string
  model: string
  status: 'idle' | 'active'
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  createdBy: string
  createdAt: number
  updatedAt: number
}
```

在 `src/api/types/index.ts` 中添加 `export * from './agent-team'`。

### Store 设计 `agent-team.ts`

遵循现有 Composition API 模式（如 `src/stores/model.ts`）：

状态：
- `agentList: ref&lt;AgentTeamMember[]&gt;([])`
- `currentAgent: ref&lt;AgentTeamMember | null&gt;(null)`
- `loading: ref(false)`

动作：
- `fetchAgents()` — GET `/api/agent-team/list`
- `fetchAgent(id)` — GET `/api/agent-team/:id`
- `createAgent(data)` — POST `/api/agent-team/create`
- `updateAgent(id, data)` — PUT `/api/agent-team/:id`
- `deleteAgent(id)` — DELETE `/api/agent-team/:id`

### 前端 API 调用模式

遵循 Dashboard 中的现有模式（直接 `fetch()` + `authStore.getToken()`），不通过 Gateway RPC：

```typescript
async function apiCall(path: string, options?: RequestInit) {
  const token = authStore.getToken()
  const res = await fetch(`/api/agent-team${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options?.headers,
    },
  })
  const data = await res.json()
  if (!data.ok) throw new Error(data.error || 'Request failed')
  return data
}
```

### 侧边栏集成

在 `routes.ts` 的 `'/'` children 数组中添加：

```typescript
{
  path: 'agents-team',
  name: 'AgentTeam',
  component: () => import('@/views/agent-team/AgentTeamPage.vue'),
  meta: { titleKey: 'routes.agentTeam', icon: 'SmartToyOutline' },
},
{
  path: 'agents-team/:id',
  name: 'AgentTeamEdit',
  component: () => import('@/views/agent-team/AgentEditPage.vue'),
  meta: { titleKey: 'routes.agentTeamEdit', hidden: true },
},
```

在 `AppSidebar.vue` 的 `materialIconMap` 中新增：`SmartToyOutline: 'smart_toy'`。

### 模型选择集成

编辑页的模型下拉复用 `useModelStore`：
- 数据源：`modelStore.models`（`ModelInfo[]`）
- 显示：`model.label || model.id`
- 值：`model.id`
- 初始化：`onMounted(() => modelStore.fetchModels())`

## 不在范围内

- "去对话"聊天功能（v2，数据模型已预留，v2 增加 `user_agent_id` 关联到 `user_agents`）
- 自定义模型配置（后续迭代）
- 对话统计数据热力图（后续迭代）
- 飞书渠道集成（不适用 WattClaw）
- 与 Gateway Agent 的双向同步（后续迭代）
