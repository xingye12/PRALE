# 数字员工 v2 设计方案

日期：2026-04-25

## 概述

对"数字员工"模块进行三项改进：
1. 智能体分类体系（12+ 类，30+ 模板）
2. md 默认值（即用型，四个 md 全部预填完整可用内容）
3. OpenClaw Gateway 集成（纯 Gateway 驱动，废弃 agent_team 表）

## 核心架构变更

### 现状

- `agent_team` 表独立于 OpenClaw Gateway，存储 md 字段，不与 Gateway 通信
- 创建的数字员工是"空壳"，无法对话
- 8 个平铺模板，无分类

### 新架构

**废弃 `agent_team` 表，复用 `user_agents` 表 + Gateway agent workspace。**

```
用户创建数字员工
  ↓
RPC agents.create → OpenClaw 创建 agent
  ↓
trackAgentForUser() → user_agents 记录关联（userId + gatewayAgentId）
  ↓
RPC setAgentFile × 4 → md 写入 OpenClaw agent workspace
```

wattclaw 服务只负责：
- 记录用户和 agent 的关联关系（user_agents 表）
- 记录分类和模板信息（user_agents 表新增字段）
- md 内容全部从 Gateway agent workspace 读写

## 一、数据库变更

### user_agents 表新增字段

```sql
ALTER TABLE user_agents ADD COLUMN category TEXT;
ALTER TABLE user_agents ADD COLUMN template_id TEXT;
ALTER TABLE user_agents ADD COLUMN description TEXT;
ALTER TABLE user_agents ADD COLUMN avatar TEXT;
```

- `category` — 智能体分类（编程开发、内容创作 等）
- `template_id` — 来源模板 ID（如 'code-assistant'）
- `description` — agent 描述
- `avatar` — agent 头像（emoji）

### agent_team 表

废弃，不再使用。迁移完成后可删除。

## 二、智能体分类体系

12 个分类，每个分类 2-3 个模板，总计 30+ 模板。

| 分类 | 模板数 | 模板列表 |
|------|--------|----------|
| 编程开发 | 3 | 代码助手、SQL 专家、代码审查员 |
| 内容创作 | 3 | 文案撰写、社媒运营、翻译官 |
| 办公效率 | 3 | 会议纪要、PPT 助手、邮件助手 |
| 数据分析 | 3 | 数据分析师、报表生成、BI 看板 |
| 市场营销 | 3 | 营销策划、竞品分析、SEO 优化 |
| 客户服务 | 2 | 智能客服、售后支持 |
| 人力资源 | 2 | 招聘助手、培训顾问 |
| 产品设计 | 2 | 产品经理、UX 设计师 |
| 项目管理 | 2 | 项目经理、敏捷教练 |
| 法律合规 | 2 | 法务顾问、合规审查 |
| 财务税务 | 2 | 财务分析、税务顾问 |
| 招投标 | 2 | 招投标分析师、标书撰写 |

### 前端展示

分类使用 Tab 或侧边筛选，类似飞书设计。每个分类下展示模板卡片网格。

## 三、md 默认值策略

每个模板预填四个 md 文件的完整内容，用户拿到即可用。

### 示例：代码助手

**soul.md:**
```
你是一个资深全栈工程师级别的编程助手。擅长 Go、TypeScript、Python、
Java 等主流语言，熟悉 Vue、React、Next.js 等前端框架，以及
Spring Boot、Express、go-zero 等后端框架。

核心能力：代码编写与重构、Bug 定位与修复、架构设计、性能优化、
代码审查、单元测试编写。

行为准则：
- 始终优先考虑代码安全性和可维护性
- 给出方案时说明 trade-off
- 遵循项目现有的代码风格和架构模式
- 不确定时主动说明而非猜测
```

**agents.md:**
```
你可以使用以下工具完成工作：
- Shell: 执行构建、测试、部署命令
- 文件系统: 读取和修改代码文件
- 数据库: 查询和调试数据库
- Git: 版本管理和代码提交

协作流程：
1. 理解需求 → 2. 定位相关代码 → 3. 编写/修改 → 4. 测试验证
```

**identity.md:**
```
名称: 代码助手
语气: 专业、简洁、务实
回复风格: 先给结论和核心代码，再解释原理。代码附带必要注释。
不使用emoji，保持工程师风格。
```

**user.md:**
```
技术栈: 以 Go + Vue 3 + TypeScript 为主
后端框架: go-zero / Express
前端框架: Vue 3 + Naive UI + Pinia
数据库: MySQL / SQLite
部署方式: Docker Compose + Kubernetes
代码规范: 遵循项目 CLAUDE.md 中的规范
偏好: 最小化改动，优先修改现有代码
```

每个模板的 user.md 根据领域预设典型使用场景和偏好。

## 四、OpenClaw Gateway 集成

### 创建流程

```
用户选择模板 → 填写名称/头像
  ↓
1. RPC agents.create → Gateway 创建 agent（name + workspace）
  ↓
2. 拿到返回的 agentId
  ↓
3. trackAgentForUser(userId, agentId, name) → user_agents 记录关联
   同时写入 category, template_id, description, avatar
  ↓
4. RPC setAgentFile(agentId, 'SOUL.md', template.soulMd)
   RPC setAgentFile(agentId, 'AGENTS.md', template.agentsMd)
   RPC setAgentFile(agentId, 'IDENTITY.md', template.identityMd)
   RPC setAgentFile(agentId, 'USER.md', template.userMd)
```

### 编辑流程

```
进入编辑页
  ↓
1. RPC getAgentFile(agentId, 'SOUL.md') × 4 → 读取 md 内容
  ↓
用户编辑（500ms 防抖）
  ↓
2. RPC setAgentFile(agentId, mdName, content) → 直接写入 Gateway
```

### 列表展示

```
agent-team/list → 读 user_agents 表拿关联（category, avatar, status）
同时 RPC agents.list → 拿 Gateway 侧名称、在线状态
合并展示
```

### 删除流程

```
1. RPC agents.delete → 删除 Gateway agent
2. DELETE user_agents 记录
```

### 离线处理

Gateway 离线时：
- 列表仍可展示（读 user_agents 本地元数据）
- 编辑/创建页显示"Gateway 未连接"提示，禁用编辑

## 五、前端变更

### 保留的页面

- AgentTeamPage — 列表页（数据源改为 user_agents + Gateway）
- AgentEditPage — 编辑页（数据源改为 Gateway RPC）
- CreateAgentModal — 创建弹窗（增加分类选择）
- AgentTemplateGrid — 模板网格（增加分类 Tab）

### 改动的组件

- CreateAgentModal — 增加分类 Tab 筛选，模板数量从 8 扩展到 30+
- AgentEditPage — 数据读写改为 RPC getAgentFile / setAgentFile
- AgentTeamPage — 列表数据合并 user_agents + Gateway agents.list
- AgentTemplateGrid — 按分类分组展示

### 废弃的组件

- 无。现有组件保留，修改数据源。

## 六、后端变更

### 新增/修改的 API

- `POST /api/agent-team/create` — 内部调用 trackAgentForUser + 写入分类信息
- `GET /api/agent-team/list` — 改为查 user_agents 表
- `GET /api/agent-team/:id` — 改为查 user_agents 表 + 可选的 Gateway RPC 读取 md
- `PUT /api/agent-team/:id` — 更新本地元数据（分类、描述等）
- `DELETE /api/agent-team/:id` — 同时调用 Gateway agents.delete

### 数据库迁移

- user_agents 表新增 category, template_id, description, avatar 字段
- agent_team 表标记废弃（可后续清理）

## 七、模板数据结构

```typescript
interface AgentTemplate {
  id: string                    // 'code-assistant'
  category: string              // '编程开发'
  name: string                  // '代码助手'
  avatar: string                // '🤖'
  description: string           // '专业的编程助手...'
  soulMd: string                // 完整的 soul.md 内容
  agentsMd: string              // 完整的 agents.md 内容
  identityMd: string            // 完整的 identity.md 内容
  userMd: string                // 完整的 user.md 内容
}

interface AgentCategory {
  id: string                    // 'coding'
  name: string                  // '编程开发'
  icon: string                  // '💻'
  templates: AgentTemplate[]
}
```

模板数据作为前端静态配置，不需要后端存储。
