# 同步领导代码功能设计

## 概述

将领导分支的两个核心功能同步到当前代码库：

1. **频道绑定智能体 + Gateway 同步** — 创建频道时必须选择智能体绑定，自动将配置同步到 Gateway
2. **会话权限隔离** — 完善会话归属检查，确保用户只能操作自己的会话

**前提**：数据库层（`agent_id` 字段、`createUserChannel` 接受 `agentId`、`getUserIdsByAgentId`、`getUserAgentsList`）已在当前代码中就绪，无需改动 `database.js` 和 `user-manager.js`。

---

## 一、频道绑定智能体 + Gateway 同步

### 1.1 后端：新增 Gateway 同步函数（server/index.js）

在 channel 路由之前添加两个函数：

**`syncChannelToGateway(channel)`**：
- 检查 Gateway 连接状态和 agentId
- 调用 `config.get` 获取当前配置
- 在 `channels.<channelType>.accounts` 中添加/更新 accountId 对应的配置（enabled: true, dmPolicy: 'open', groupPolicy: 'open'）
- 在 `bindings` 数组中添加/更新 `{ agentId, match: { channel, accountId } }`
- 调用 `config.patch` + `config.get` + `config.apply` 三步提交

**`removeChannelFromGateway(channel)`**：
- 从 `channels.<channelType>.accounts` 中删除对应 accountId
- 从 `bindings` 中过滤掉匹配项
- 同样三步提交

### 1.2 后端：修改频道 CRUD 路由（server/index.js）

**修改已有路由** `GET /api/user/agents`（已存在于 line 390）：
- 当前使用 `getUserAgents()`，改为调用 `getUserAgentsList(req.currentUser.id)`
- 返回 `{ gateway_agent_id, name }` 列表，供前端频道页面智能体下拉框使用

**POST /api/user/channels**：
- 校验 `agentId` 必填
- 校验 `agentId` 属于当前用户（`getUserOwnedAgentIds`）
- 创建频道后调用 `syncChannelToGateway`
- 根据 sync 结果更新频道状态（active / error）

**PUT /api/user/channels/:id**：
- 如果 body 含 `agentId`，校验归属
- 更新后调用 `syncChannelToGateway`
- 根据 sync 结果更新状态

**DELETE /api/user/channels/:id**：
- 删除前先调用 `removeChannelFromGateway`
- 然后执行数据库删除

### 1.3 前端：频道页面改造（UserChannelsPage.vue）

**类型定义（src/api/types/user.ts）**：
- `UserChannel.webhook_url` → `UserChannel.agent_id`
- `CreateUserChannelParams.webhookUrl` → `CreateUserChannelParams.agentId`（required）
- `UpdateUserChannelParams.webhookUrl` → `UpdateUserChannelParams.agentId`

**组件改造**：
- 表单字段：`webhookUrl` → `agentId`
- 新增 `agentOptions` ref + `agentSelectOptions` computed
- 新增 `loadAgents()` 函数，调用 `GET /api/user/agents`
- 创建/编辑弹窗中：webhook URL 输入框 → NSelect 智能体下拉框
- 表格列：Webhook URL 列 → "绑定智能体"列（显示智能体名称）
- 状态列：使用 i18n 标签（"已同步" / "同步失败"）
- 新增 `syncing` ref，保存时显示 loading
- 创建/更新成功时区分 sync 成功和部分失败，显示不同提示

### 1.4 i18n 新增 key

zh-CN / en-US 各新增 8 个 key：

| key | zh-CN | en-US |
|-----|-------|-------|
| `pages.userChannels.agentRequired` | 请选择要绑定的智能体 | Please select an agent to bind |
| `pages.userChannels.boundAgent` | 绑定智能体 | Bound Agent |
| `pages.userChannels.agentPlaceholder` | 请选择智能体 | Select agent |
| `pages.userChannels.synced` | 已同步 | Synced |
| `pages.userChannels.syncFailed` | 同步失败 | Sync Failed |
| `pages.userChannels.createSyncSuccess` | 频道创建成功，已同步到 Gateway | Channel created and synced to Gateway |
| `pages.userChannels.createSuccessButSyncFailed` | 频道已创建，但同步到 Gateway 失败：{error} | Channel created, but Gateway sync failed: {error} |
| `pages.userChannels.updateSyncSuccess` | 频道更新成功，已同步到 Gateway | Channel updated and synced to Gateway |
| `pages.userChannels.updateSuccessButSyncFailed` | 频道已更新，但同步到 Gateway 失败：{error} | Channel updated, but Gateway sync failed: {error} |

同时更新现有 key 的文案：
- `subtitle` → 管理您的消息渠道并与智能体绑定，实现消息双向转发
- `frameworkNote` → 添加频道时请选择要绑定的智能体...
- `confirmDelete` → 确定删除该频道吗？删除后将从 Gateway 移除对应配置。
- `deleteSuccess` → 频道已删除，已从 Gateway 移除配置

---

## 二、会话权限隔离

### 2.1 Gateway 事件追踪（server/index.js）

**gateway connected 事件**：
- 新增 `syncSessionsFromGateway()` 调用
- 该函数：调用 `sessions.list` → 遍历结果 → 从 sessionKey 提取 agentId → 用 `getUserIdsByAgentId` 找到用户 → `trackSessionForUser`

**gateway event 事件**：
- 从 payload 中提取 sessionKey（兼容 `sessionKey` / `session_key` / `key`）
- 从 sessionKey 提取 agentId
- 用 `getUserIdsByAgentId` 找到所有关联用户 → `trackSessionForUser`

### 2.2 SSE 广播改进（server/index.js broadcastSSE）

当前逻辑：只查 `ownedKeys`，不匹配则 skip。
改为：不匹配时，从 sessionKey 提取 agentId → 查用户是否拥有该 agent → 是则自动 `trackSessionForUser` 并推送。

### 2.3 RPC 代理：权限隔离函数（server/index.js）

在 RPC handler 内部新增两个闭包函数：

**`isSessionOwned(sessionKey)`**：
- 先查 `getUserOwnedSessionKeys` 是否包含
- 不包含则从 sessionKey 提取 agentId → 查 `getUserOwnedAgentIds`
- 如果用户拥有该 agent，自动 `trackSessionForUser` 并返回 true

**`filterOwnedSessions(list)`**：
- 用 `isSessionOwned` 过滤数组

### 2.4 RPC 代理：各 session 方法添加权限检查

| 方法 | 权限检查 | 未授权响应 |
|------|----------|------------|
| `sessions.list` | `filterOwnedSessions` 替代原 `filterByAgent` | 正常返回过滤后结果 |
| `sessions.reset` | `isSessionOwned` | 403 |
| `sessions.delete` | `isSessionOwned` | 403 |
| `sessions.get` / `sessions.history` | `isSessionOwned` | 返回空数组 `[]` |
| `chat.history` | `isSessionOwned` | 返回空数组 `[]` |
| `sessions.export` | `isSessionOwned` | 返回 `null` |
| `status` | `filterOwnedSessions` | 正常过滤 |
| `session.usage` | `filterOwnedSessions` | 正常过滤 |
| `usage.cost` | `filterOwnedSessions` | 正常过滤 |

### 2.5 会话操作自动追踪 agent

在 `session.spawn`、`session.send`、`chat.send`、`agent` 等 RPC 方法中：
- 检测到新 sessionKey 时自动 `trackSessionForUser`
- 如果 agentId 不在用户已拥有列表中，自动 `trackAgentForUser`

---

## 三、不改动的文件

- `server/database.js` — agent_id 已存在
- `server/user-manager.js` — createUserChannel/getUserIdsByAgentId/getUserAgentsList 已存在
- `src/stores/channel*.ts` — 无需改动
- Agent Team 相关文件 — 保留不动

---

## 四、文件变更清单

| 文件 | 变更类型 | 改动量 |
|------|----------|--------|
| `server/index.js` | 修改 | ~200 行 |
| `src/api/types/user.ts` | 修改 | ~15 行 |
| `src/views/channels/UserChannelsPage.vue` | 修改 | ~80 行 |
| `src/i18n/messages/zh-CN.ts` | 修改 | ~20 行 |
| `src/i18n/messages/en-US.ts` | 修改 | ~20 行 |
