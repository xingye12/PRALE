# AI 工作台（Workspace）设计文档

**日期：** 2026-04-27
**状态：** 待实现

---

## 1. 概述

新增"AI 工作台"功能模块，为用户提供基于数字员工的智能对话体验。与现有"在线对话"独立共存，复用 Gateway RPC 通信层。

### 核心功能

1. 从"数字员工"卡片点击"去对话"进入，自动创建新会话
2. 左侧栏显示用户所有数字员工（agent），点击展开历史会话列表
3. 支持切换模型（全局模型列表，从 Gateway config 获取）
4. 支持发送附件
5. AI 回复中的"思考过程"以可展开/收起状态栏显示
6. 与现有"在线对话"完全独立，互不影响

---

## 2. 架构方案

**方案：独立 Store + 复用 RPC 层**

- 新建 `stores/workspace.ts` 管理 AI 工作台状态
- 复用 `rpc-client.ts` 的 sendChatMessage / listChatHistory / sessions.list 等方法
- 复用 `server/index.js` 后端代理和权限过滤逻辑（无需修改）
- 抽取共享消息渲染组件，避免与 chatStore 重复

不选择扩展 chatStore 的原因：chatStore 已约 950 行，AI 工作台的"多 agent + 多会话"场景与现有单会话对话差异大，强耦合会互相干扰。

---

## 3. 页面结构

```
/workspace                    → WorkspacePage.vue（AI 工作台主页面）
  ├─ WorkspaceSidebar.vue     → 左侧栏
  │    ├─ agent 条目（展开/收起）
  │    └─ session 条目（agent 下的会话）
  ├─ ChatHeader.vue           → 顶栏（agent 名 + 会话名 + 消息数）
  ├─ MessageList.vue          → 消息列表
  │    └─ ThinkingBlock.vue   → 思考中 可展开/收起
  ├─ ChatInput.vue            → 底部输入区
  │    ├─ 模型选择器（胶囊下拉）
  │    ├─ 输入框
  │    ├─ 附件按钮
  │    └─ 发送按钮
  └─ WelcomeScreen.vue        → 未选 agent 时的欢迎页
```

---

## 4. 左侧栏设计

### Agent 列表

- 数据来源：`getDigitalEmployees(userId)` → `user_agents` 表（`category IS NOT NULL`）
- 每个用户只看自己的数字员工
- 显示：emoji + 名称 + 会话数量
- 点击 agent → 进入该 agent 的对话（无会话则新建），展开显示历史会话
- 展开/收起切换，当前选中 agent 高亮（蓝色左边框 + 蓝色背景）

### 会话列表

- 数据来源：`sessions.list` RPC → 按 agentId 过滤
- 显示：会话标题（label 或首条消息摘要）+ 时间 + 消息数
- 点击切换会话，当前选中会话高亮
- 顶部"新对话"按钮

### 搜索

- 顶部搜索框，搜索 agent 名称和会话标题

---

## 5. 数据流

### 从数字员工进入对话

```
AgentCard.vue "去对话" 点击
  → router.push({ name: 'Workspace', query: { agentId: 'xxx' } })
  → WorkspacePage 检测 query.agentId
  → workspaceStore.selectAgent(agentId)
  → RPC sessions.list → 按 agentId 过滤获取历史会话
  → 用户输入第一条消息 → Gateway 自动创建 session
  → 前端拿到 sessionKey 加入左侧会话列表
```

### 消息发送流程

```
用户输入 → ChatInput.emit('send', { content, model, attachments })
  → workspaceStore.sendMessage()
    → 构造 sessionKey：agent:{agentId}:{uuid}（如无活跃会话）
    → RPC chat.send({ sessionKey, message, model })
  → 后端代理 → Gateway
  → SSE 事件流返回
    → chat.delta → 流式更新消息（ThinkingBlock 显示"思考中"）
    → chat.final → 完成消息
    → chat.error → 错误提示
```

### 模型列表获取

```
RPC config.get → 提取 config.models 或 config.providers 中的模型列表
→ workspaceStore.availableModels
→ ChatInput 模型选择器下拉
```

### SSE 事件处理

```
后端 /api/events SSE → useEventStream composable
  → workspaceStore.handleEvent(payload)
    → 按 sessionKey 过滤，只处理当前活跃会话的事件
    → chat.delta → 追加流式内容
    → chat.final → 标记消息完成
```

---

## 6. 会话管理

| 操作 | 实现 |
|------|------|
| 新建会话 | 用户发第一条消息时，Gateway 自动创建 session，前端拿到 sessionKey 后加入列表 |
| 切换会话 | 点击左侧会话条目 → RPC chat.history 加载历史消息 → 更新 messages |
| 会话重命名 | 右键/更多菜单 → 更新会话 label（本地存储或 Gateway） |
| 删除会话 | RPC sessions.delete → 从列表移除 |

### sessionKey 格式

遵循现有格式：`agent:{agentId}:{uuid}`，前端生成。

---

## 7. 思考过程（ThinkingBlock）

### 显示逻辑

- AI 回复前，如果 Gateway 返回思考内容（通过消息特定字段区分），显示 ThinkingBlock
- **收起状态**：💡图标 + "思考中..." + 旋转动画 + "展开"按钮
- **展开状态**：💡图标 + "已思考 X 秒" + 思考内容 + "收起"按钮
- 思考完成后自动收起，用户可点击展开查看

### 数据来源

Gateway 返回消息中的思考内容字段（具体格式需实测确认，可能是 `role: 'assistant'` + 内容中 `<thinking>` 标签，或单独字段）。ThinkingBlock 组件预留灵活解析。

---

## 8. 附件功能

### v1 方案

- 底部输入区📎按钮 → 文件选择器
- 支持：图片、PDF、文本等常见文件类型
- 已选文件在输入框上方显示胶囊标签（文件名 + 删除按钮）
- 发送时：如果 Gateway chat.send 支持 attachments 参数则直接传；否则先上传到服务器，将 URL 嵌入消息体

### 附件预览

- 输入框上方显示已选文件列表
- 每个文件：图标 + 文件名 + ✕删除
- 发送后清除附件列表

---

## 9. 权限隔离

完全复用现有权限体系，无需额外修改后端：

- 数字员工列表：`getDigitalEmployees(userId)` 只返回当前用户的
- 会话列表：`filterOwnedSessions` 只返回用户拥有的会话
- chat.send：后端代理自动 trackSessionForUser
- chat.history：后端代理检查 isSessionOwned
- SSE 事件：后端按用户过滤广播

---

## 10. 路由与导航

### 路由

```typescript
{
  path: 'workspace',
  name: 'Workspace',
  component: () => import('@/views/workspace/WorkspacePage.vue'),
  meta: { titleKey: 'routes.workspace', icon: '...' },
}
```

### 侧边栏入口

在 `DefaultLayout.vue` 的侧边栏菜单中添加"AI 工作台"入口。

### 面包屑

AppHeader 面包屑：AI 工作台 > {agent名} > {会话名}

---

## 11. 文件清单

### 新建文件

| 文件 | 职责 |
|------|------|
| `src/views/workspace/WorkspacePage.vue` | 主页面（左右分栏布局） |
| `src/views/workspace/WorkspaceSidebar.vue` | 左侧栏（agent + 会话列表） |
| `src/views/workspace/ChatHeader.vue` | 顶栏 |
| `src/views/workspace/ChatInput.vue` | 底部输入区 |
| `src/views/workspace/ThinkingBlock.vue` | 思考中组件 |
| `src/views/workspace/WelcomeScreen.vue` | 欢迎页 |
| `src/components/chat/MessageBubble.vue` | 共享消息气泡组件 |
| `src/stores/workspace.ts` | 工作台状态管理 |

### 需修改的文件

| 文件 | 修改内容 |
|------|---------|
| `src/router/routes.ts` | 添加 `/workspace` 路由 |
| `src/i18n/messages/zh-CN.ts` | 添加工作台中文文案 |
| `src/i18n/messages/en-US.ts` | 添加工作台英文文案 |
| `src/views/agent-team/AgentCard.vue` | "去对话"按钮启用 + 路由跳转 |
| `src/layouts/DefaultLayout.vue` | 侧边栏添加"AI 工作台"入口（可能通过路由配置自动生成） |

### 不修改的文件

- `server/index.js` — 后端代理和权限过滤完全复用
- `src/stores/chat.ts` — 现有在线对话 store 不动
- `src/views/chat/ChatPage.vue` — 现有在线对话页面不动
- `src/api/rpc-client.ts` — 直接复用现有方法，无需新增

---

## 12. 实现注意事项

1. **sessionKey 格式一致** — 新对话的 sessionKey 必须遵循 `agent:{agentId}:{uuid}` 格式
2. **SSE 事件过滤** — workspaceStore 只处理当前活跃 sessionKey 的事件，忽略其他会话
3. **思考内容格式** — 需实测 Gateway 返回的思考内容字段，ThinkingBlock 做灵活适配
4. **附件支持** — 需验证 Gateway chat.send 是否支持 attachments 参数
5. **数字员工列表** — 左侧栏 agent 列表复用 agent-team store 的数据，不重复请求
6. **样式参考** — 参考 new/img.png 和 new/img_1.png 的布局风格，保持与现有代码风格一致
7. **i18n** — 所有用户可见文案走 i18n，zh-CN 和 en-US 同步更新
