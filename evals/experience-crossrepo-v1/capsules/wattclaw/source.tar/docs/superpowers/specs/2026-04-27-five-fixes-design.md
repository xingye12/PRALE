# Five Fixes Design — 2026-04-27

5 项修改/需求的设计文档。

---

## 1. 去掉"网关可视化管理系统"描述

纯文本替换，8 个文件：

| 文件 | 当前值 | 替换为 |
|------|--------|--------|
| `index.html:7` | `WattClaw 网关可视化管理系统` | `WattClaw` |
| `src/i18n/messages/zh-CN.ts:3` (app.title) | `WattClaw 网关可视化管理系统` | `WattClaw` |
| `src/i18n/messages/zh-CN.ts:102` (hero.title) | `WattClaw 网关可视化管理系统` | `WattClaw` |
| `src/i18n/messages/zh-CN.ts:104` (hero.description) | 含"网关可视化管理系统" | 简化为 AI 平台定位 |
| `src/i18n/messages/zh-CN.ts:165` (footer.copyright) | `© 2024 WattClaw 网关可视化管理系统` | `© 2026 WattClaw` |
| `src/views/Login.vue:140` | `网关可视化管理系统` | `WattClaw` |
| `src/components/layout/AppSidebar.vue:79` | `网关管理系统` | `WattClaw` |
| `src/i18n/messages/en-US.ts:110` (features.gateway.title) | `Gateway Management` | `AI Platform` |
| `src/i18n/messages/en-US.ts:1611` (aboutLine1) | `WattClaw Gateway Management System` | `WattClaw` |

风险：无，纯文本改动。

---

## 2. 模型管理用户隔离

### 目标

- admin 用户的渠道 CRUD 直接操作 Gateway 共享配置，对所有用户可见
- 非 admin 用户的渠道 CRUD 存本地 SQLite，同步到 Gateway，只对自己可见
- 非 admin 用户能看到共享渠道（只读）+ 私有渠道（可编辑），共享渠道操作按钮灰置
- 数据一致性以 Gateway 为准

### 数据模型

新建 `user_model_providers` 表：

```sql
CREATE TABLE IF NOT EXISTS user_model_providers (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  config TEXT NOT NULL DEFAULT '{}',
  is_primary BOOLEAN DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, provider_id)
);
```

`config` 字段存储 JSON，格式与 Gateway config 中的 provider 配置一致：`{ api, baseUrl, apiKey, models, ... }`。

### 后端 API

```
GET    /api/model-providers           — 列表：合并 Gateway 共享 + 用户私有
POST   /api/model-providers           — 创建
PUT    /api/model-providers/:id       — 编辑
DELETE /api/model-providers/:id       — 删除
PUT    /api/model-providers/default   — 设置默认模型
```

#### 列表逻辑（GET）

1. 从 Gateway config 读取所有 providers → 标记 `source: 'shared'`
2. 从 `user_model_providers` 读取当前用户的 providers → 标记 `source: 'private'`
3. 合并去重，以 Gateway 为准：
   - Gateway 有、本地也有 → 以 Gateway 数据为准，清理本地
   - Gateway 有、本地没有 → 保留为 shared
   - Gateway 没有、本地有 → 清理本地脏数据，不返回
4. admin 用户只返回 Gateway providers（无私有概念）

#### 创建逻辑（POST）

**非 admin**：
1. 写入 `user_model_providers` 表
2. 调用 Gateway `config.patch` 同步写入
3. 返回成功

**admin**：
1. 直接调用 Gateway `config.patch` 修改共享配置
2. 不写本地表

#### 编辑逻辑（PUT）

同创建逻辑：非 admin 改本地 + 同步 Gateway；admin 直接改 Gateway。

#### 删除逻辑（DELETE）

**非 admin**：
1. 只能删除 `source: 'private'` 的渠道
2. 从 `user_model_providers` 删除
3. 调用 Gateway `config.patch` 移除对应 provider

**admin**：
1. 直接从 Gateway config 移除

#### 设置默认模型（PUT /default）

**非 admin**：记录在 `user_model_providers` 的 `is_primary` 字段，同步到 Gateway config 的 `models.primary`（仅对当前用户的 Agent 生效）。

**admin**：直接设置 Gateway config 的 `models.primary`。

### 前端改动（ModelsPage.vue）

- 通过 `useAuthStore` 判断 `isAdmin`
- 非 admin：
  - 渠道列表显示 `source` 标签（共享/私有）
  - shared 渠道：编辑/删除按钮灰置，hover 提示"共享渠道，仅管理员可操作"
  - 新建渠道调用 `/api/model-providers`（不再直接调 `configStore.patchConfig()`）
  - 设置默认模型调用 `/api/model-providers/default`
- admin：保持现有 `configStore.patchConfig()` 逻辑不变

### 一致性保障

- 每次页面加载时做一致性校验
- 每次写操作后调用 Gateway `config.get` 验证同步结果

---

## 3. 创建数字员工默认模型

### 改动范围

`src/views/agent-team/AgentTeamPage.vue` — `handleCreated()` 方法

### 逻辑

1. 获取 Gateway 主模型：`configStore.config?.models?.primary`
2. 如果存在主模型，创建 Agent 时将其设为默认模型
3. 通过 Gateway RPC `config.patch` 在 agent 的 identity config 中设置 model 字段
4. 如果 Gateway 没有配置主模型，model 字段为空（不强求）

### 实现方式

在 `handleCreated()` 的 agent 创建流程中，`agents.create` RPC 之后，增加一步设置默认模型（与设置 display name 类似）。

---

## 4. 数字员工统计数据

### 后端新增 API

```
GET /api/agent-team/:id/stats → { messages: number, tasks: number }
```

### 实现逻辑

1. 根据 agent id 查找 `gateway_agent_id`（从 `user_agents` 表）
2. 通过 Gateway RPC `sessions.list` 获取该 Agent 的所有会话
3. 遍历会话，调用 `sessions.history` 获取消息：
   - **消息数**：role=assistant 的消息数量
   - **任务数**：含工具调用（tool_use / function_call）的消息数量
4. 返回统计结果

### 前端改动

- `AgentTeamPage.vue`：加载 agent 列表后，批量请求每个 agent 的 stats
- `AgentCard.vue`：
  - 新增 `stats` prop：`{ messages: number; tasks: number }`
  - 替换硬编码的 `0`
  - stats 加载中显示 `-` 或 loading spinner

### 性能考虑

- stats 接口可能较慢（需多次 RPC），考虑：
  - 前端并行请求（Promise.all）
  - 后端缓存结果（TTL 60s）
  - 如果 agent 数量多（>20），可做批量接口 `/api/agent-team/stats?ids=a,b,c`
