# AI 工作台修复设计文档

日期：2026-04-27

## 概述

AI 工作台模块的 7 项修复，涵盖路由顺序、会话计数、标题摘要、页面切换恢复、模型默认值、模型选择 UI、新会话即时显示。

## 修复清单

### 1. 路由顺序调整

**问题**：AI 工作台在侧边栏位于"在线对话"下方，应移到上方。

**方案**：
- `src/router/routes.ts`：将 workspace 路由定义移到 chat 路由之前
- 更换图标为 `RocketOutline`（避免与在线对话的 `ChatboxEllipsesOutline` 重复）

**影响文件**：`src/router/routes.ts`

### 2. 会话数默认显示为0

**问题**：未选中 agent 时，会话数显示为 0；选中后才加载真实数量。

**根因**：`loadAgents()` 初始化每个 agent 的 `sessions: []`，只有 `selectAgent()` 才触发 `loadAgentSessions()`。

**方案**：
- `loadAgents()` 完成后，对所有 agent 并行调用 `loadAgentSessions()`
- 使用 `Promise.allSettled` 容忍部分失败
- 每个 agent 单独管理 loadingSessions 状态

**影响文件**：`src/stores/workspace.ts`

### 3. LLM 生成会话标题

**问题**：会话标题一直显示为 `Openclaw Web Backend`，需要像 ChatGPT 一样根据首条消息自动生成摘要。

**方案**：

#### 后端
- 新增 `POST /api/workspace/generate-title` 端点
  - 接收 `{ sessionKey, messages: string }`（messages 为最近的用户消息文本，取前 200 字）
  - 构造 prompt："根据以下用户消息，生成一个4-6个字的中文标题，只返回标题本身，不要加引号：{messages}"
  - 通过 Gateway chat.send 发送到独立 session 获取摘要
  - 返回 `{ title: string }`
- 新增 `POST /api/workspace/update-session-label` 端点
  - 接收 `{ sessionKey, label }`
  - 调用 Gateway RPC 更新 session label（如果 Gateway 支持），否则仅前端本地更新

#### 前端
- workspace store 新增 `generateAndSetTitle()` 方法
- 在 `chat.final` 事件后，如果当前 session 没有 label，调用后端 API 生成标题
- 生成后更新 agent.sessions 中对应 session 的 label
- 防重复：标记 session 是否已生成过标题

**影响文件**：`server/index.js`、`src/stores/workspace.ts`、`src/views/workspace/WorkspaceSidebar.vue`

### 4. 切换页面后内容异常

**问题**：正常对话后切到别的页面再切回来，显示 `[Bootstrap pending]` 等 Bootstrap 内容。

**根因**：
- WorkspacePage `onUnmounted` 不清空 store（全局 store），但 `onMounted` 只在 query.agentId 时才 startNewChat
- 如果之前有 activeSession，重新挂载后 SSE 推送的 Bootstrap 系统消息被 mergeMessages 合并进来

**方案**：
- `onMounted` 中检查 `activeSessionKey` 是否存在
  - 有 activeSession → 调用 `selectSession(key)` 重新加载历史消息
  - 有 selectedAgentId 但无 activeSession → 保持当前状态
  - 都没有 → 正常初始化
- `onUnmounted` 时清空 `messages`，防止残留 Bootstrap 内容

**影响文件**：`src/views/workspace/WorkspacePage.vue`、`src/stores/workspace.ts`

### 5. 模型选择默认值

**问题**：模型选择器无默认值，显示空白。

**方案**：
- `loadModels()` 完成后，如果 `selectedModel` 为 null，取 `availableModels[0]` 作为默认值
- ChatInput 中 `selectedModel` 通过 watch 同步到 workspace store

**影响文件**：`src/stores/workspace.ts`、`src/views/workspace/ChatInput.vue`

### 6. 模型选择 UI 太长

**问题**：模型名称很长时（如 `deepseek-chat-v3-0324`），NSelect 被撑开。

**方案**：
- 设置 `max-width: 160px`
- 添加 `consistent-menu-width` 为 false
- 使用 NSelect 的 ellipsis 标签截断

**影响文件**：`src/views/workspace/ChatInput.vue`

### 7. 新会话不立即出现在左侧列表

**问题**：创建新会话后，左侧会话列表不显示，需要等到 `chat.final` 才刷新。

**根因**：`startNewChat()` 创建的 sessionKey 是本地生成的（`agent:xxx:uuid`），未注册到 Gateway，`loadAgentSessions()` 列表中不存在。

**方案**：
- `startNewChat()` 后，立即将新 session 插入对应 agent 的 `sessions` 数组
- 构造临时 Session 对象：`{ key: sessionKey, label: '', lastActivity: new Date().toISOString(), ... }`
- `chat.final` 后重新从 Gateway 刷新完整列表（替换临时 session）
- 如果用户未发送消息就切走，清理临时 session

**影响文件**：`src/stores/workspace.ts`

## 不在本次范围

- 附件上传功能（推迟到下次迭代）
- 消息 Markdown 渲染
- 会话重命名/删除 UI
- 错误重试机制

## 修改文件汇总

| 文件 | 修改内容 |
|------|----------|
| `src/router/routes.ts` | workspace 路由移到 chat 前，换图标 |
| `src/stores/workspace.ts` | 预加载会话数、新会话即时插入、模型默认值、页面恢复逻辑、标题生成 |
| `src/views/workspace/WorkspacePage.vue` | onMounted 恢复逻辑、onUnmounted 清空 messages |
| `src/views/workspace/ChatInput.vue` | 模型默认值同步、NSelect 样式调整 |
| `src/views/workspace/WorkspaceSidebar.vue` | 无需改动（标题更新通过 store reactive 自动生效） |
| `server/index.js` | 新增 generate-title 和 update-session-label 端点 |
