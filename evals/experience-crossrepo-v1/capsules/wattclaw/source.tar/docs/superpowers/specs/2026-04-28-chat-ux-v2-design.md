# Chat UX V2 Design Spec

**Date:** 2026-04-28
**Scope:** 附件功能接通、视觉风格全面参考 Hermes、Stop 按钮 stream_id 追踪
**Reference:** `/Users/renming/Desktop/wattman/openclaw/hermes-webui`

---

## 1. 附件功能

### 1.1 目标

ChatInput 已有文件选择 UI（选择、拖拽、标签显示），但 `handleSend()` 只发送文本。需要接通上传流程，参考 Hermes 的模式。

### 1.2 数据流

```
用户选择文件 → ChatInput 暂存到 attachments ref
→ 点击发送
→ 先调 uploadAttachments() 上传到 /api/workspace/upload (FormData)
→ 返回 [{ name, path, size, url }]
→ 拼接路径到消息文本: "[Attached files: url1, url2]\n\n用户消息"
→ 调 workspaceStore.sendMessage(拼接后的文本)
→ 清空 attachments
```

### 1.3 后端

- **新建** `/api/workspace/upload` — 聊天附件专用上传端点
  - 现有 `/api/files/upload` 是文件管理器用的（需要 workspace 路径参数），不适合聊天场景
  - multer memoryStorage，限制 10MB
  - 上传目录：`data/uploads/{sessionKey}/` 自动创建
  - 返回格式：`{ files: [{ name, path, size, url }] }`
  - url 为可访问的相对路径（如 `/api/workspace/uploads/{sessionKey}/{filename}`）

- **新建** `/api/workspace/uploads/:sessionKey/:filename` — 静态文件访问端点
  - 用于 AI 和用户访问已上传的附件

### 1.4 前端改动

**ChatInput.vue：**
- `handleSend()` 改为 async
- 发送前调 `uploadAttachments()` 逐个上传暂存文件
- 上传成功后拼接 `[Attached files: url1, url2]` 到消息文本
- 发送后清空 `attachments` ref，释放 blob URL（`URL.revokeObjectURL`）
- 上传过程中 composer 显示 "Uploading…" 状态文字（参考 Hermes `setComposerStatus`）
- 上传失败时 composer 显示 "Upload error: ..." 错误信息，不发送消息

**workspace.ts：**
- `sendMessage` 签名不变（仍接收 string），附件路径拼到消息文本里
- 无需修改 store 层

**空文本 fallback：**
- 如果只附加了文件但没有输入文字，自动生成消息：`I've uploaded N file(s): url1, url2`
- 参考 Hermes `messages.js:113` 的逻辑

### 1.5 附件标签 UI

参考 Hermes 的 chip 设计：
- 图片文件：56x56 缩略图（`URL.createObjectURL`），组件卸载时调用 `URL.revokeObjectURL` 清理
- 其他文件：paperclip 图标 + 文件名
- 每个 chip 有 X 删除按钮
- 拖拽到 composer 区域时显示 `.drag-over` 视觉提示（边框高亮）

### 1.6 限制

- 最多 5 个文件（现有逻辑保留）
- 单文件大小：10MB
- 图片类型：jpg/png/gif/webp
- 其他类型：pdf/txt/md/json/yaml/csv

---

## 2. 视觉风格

### 2.1 目标

保持 WattClaw 现有的深色/浅色双主题颜色体系，但布局、间距、字体、气泡样式、composer 样式全面参考 Hermes。

### 2.2 Token 映射

| Hermes token | WattClaw 映射 | 用途 |
|---|---|---|
| `--bg` | `--bg-primary` | 页面背景 |
| `--sidebar` | `--bg-sidebar` | 侧边栏背景 |
| `--text` | `--text-primary` | 主文字 |
| `--muted` | `--text-secondary` | 次要文字 |
| `--accent` | `--primary` | 主题色（保持现有） |
| `--surface` | `--bg-card` | 卡片/面板背景 |
| `--input-bg` | `--bg-input` | 输入框背景 |
| `--hover-bg` | `--bg-hover` | 悬停背景 |
| `--focus-ring` | `--border-focus` | 聚焦边框 |
| `--focus-glow` | `--shadow-focus` | 聚焦辉光 |

深色/浅色的具体色值保持 WattClaw 现有的，仅替换 token 结构和组件样式。

### 2.3 消息布局

参考 Hermes `.msg-row` / `.msg-body`：

- **用户消息：** 左侧 22px 圆形角色图标（`var(--accent)` 色），消息文字用 `var(--accent)` 色区分（参考 Hermes `.msg-role.user`）
- **助手消息：** 左对齐，`max-width: 680px`，`padding-left: 30px`，`line-height: 1.75`
- **角色图标：** 22px 圆形，用户用 accent 色，助手用 muted 色
- **消息间距：** `10px` 垂直间距
- **角色标识：** 通过 DOM 位置和样式区分，不用彩色气泡
- **时间戳：** 每条消息下方显示小号灰色时间（可选）

### 2.4 Composer（输入区域）

参考 Hermes `.composer-box`：

- `max-width: 780px`
- `border-radius: 16px`
- 聚焦时 accent 辉光：`box-shadow: 0 0 0 3px var(--accent-bg)`
- 字体 `16px`，textarea 自动增高到 `200px`
- 附件按钮、Stop 按钮位置与 Hermes 对齐
- 发送按钮样式参考 Hermes
- 拖拽文件时显示 `.drag-over` 视觉提示（边框高亮 + 背景色变化）

### 2.5 代码块

- `border-radius: 10px`
- 字体：`"SF Mono", "Fira Code", monospace`
- 复制按钮 hover 显示（现有逻辑保留）
- 语法高亮保持 highlight.js（现有）

### 2.6 Thinking 卡片

参考 Hermes 折叠式 thinking 卡片：
- 可折叠/展开，带 toggle 箭头
- `max-height: 260px`，超出可滚动
- monospace 字体显示思考内容
- 金色主题边框（保持现有 ThinkingBlock 风格）

### 2.7 滚动到底部按钮

参考 Hermes `.scroll-to-bottom-btn`：
- 当用户向上滚动时，显示浮动的"滚动到底部"按钮
- 粘性定位在消息区域右下角
- 点击平滑滚动到底部
- 阈值：距离底部超过 150px 时显示

### 2.8 主题切换过渡

参考 Hermes 全局过渡效果：
- 所有元素添加 `transition-property: background-color, border-color, color`
- `transition-duration: .15s`
- 深色/浅色切换时平滑过渡

### 2.9 ChatHeader 信息

参考 Hermes topbar：
- 显示当前模型名称（chip 样式）
- Gateway 连接状态指示点（绿/红，现有逻辑保留）
- 可选：workspace 信息、TPS 统计

### 2.10 侧边栏增强

参考 Hermes 侧边栏：
- 会话按日期分组（今天/昨天/更早，现有逻辑保留）
- 正在流式传输的会话显示动画 spinner 图标
- 会话项 hover 高亮

### 2.11 全局影响

- CSS 变量定义在 `src/assets/styles/main.css`
- workspace 组件样式全部重写：
  - MessageList.vue
  - ChatInput.vue
  - ChatHeader.vue
  - WorkspaceSidebar.vue
  - MarkdownRenderer.vue
  - ThinkingBlock.vue
  - ToolCallCard.vue
  - MessageActions.vue
  - WelcomeScreen.vue
- 非 workspace 页面（仪表盘、模型管理等）保持不变

---

## 3. Stop 按钮（stream_id 追踪）

### 3.1 目标

引入 stream_id 追踪机制，参考 Hermes 的生命周期管理，适配 WattClaw 的 Gateway 架构。

### 3.2 后端设计

**背景：** 当前发送消息走 WebSocket RPC（`wsStore.rpc.sendChatMessage`），前端无法获取 streamId。需要新增 REST 端点包装发送流程。

**新增 streamIdMap：**

```javascript
// server/index.js
const streamIdMap = new Map()  // streamId → { sessionKey, startTime }
```

**新增 REST 端点 `POST /api/workspace/send`：**

```javascript
app.post('/api/workspace/send', authMiddleware, async (req, res) => {
  const { sessionKey, message, idempotencyKey } = req.body
  const streamId = crypto.randomUUID()
  streamIdMap.set(streamId, { sessionKey, startTime: Date.now() })

  // 调用 Gateway RPC 发送消息
  const result = await gateway.call('chat.send', { sessionKey, message, idempotencyKey })

  res.json({ ok: true, streamId })
})
```

**前端 sendMessage 改用新 REST 端点：**

```typescript
// workspace.ts
const result = await httpPost('/api/workspace/send', { sessionKey, message, idempotencyKey })
activeStreamId.value = result.streamId
```

**SSE 事件增强：**

后端转发 Gateway SSE 事件时，附带 `stream_id`：

```json
{ "type": "chat.delta", "stream_id": "uuid-xxx", "payload": {...} }
```

关联机制：Gateway 的 SSE 事件包含 sessionKey，后端通过 streamIdMap 反查对应的 streamId，附加到事件中。如果找不到映射（过期或已取消），则不附带 streamId，前端忽略该事件。

**取消端点改造：**

```
POST /api/chat/cancel  { streamId }
→ 查 streamIdMap 找到 sessionKey
→ gateway.call('chat.cancel', { sessionKey })
→ 删除 map 条目
→ 返回 { ok: true }
```

**清理机制：**
- 定期清理超过 10 分钟的 streamIdMap 条目（防内存泄漏）
- SSE 连接断开时自动清理对应 stream

### 3.3 前端设计

**workspace.ts：**

```typescript
const activeStreamId = ref<string | null>(null)

async function sendMessage(content: string) {
  const idempotencyKey = `ws-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`

  // 本地消息立即显示
  const localMessage = { id: idempotencyKey, role: 'user', content, timestamp: new Date().toISOString() }
  messages.value = [...messages.value, localMessage]
  sending.value = true

  try {
    // 改用 REST 端点，获取 streamId
    const result = await httpPost('/api/workspace/send', {
      sessionKey: activeSessionKey.value,
      message: content,
      idempotencyKey
    })
    activeStreamId.value = result.streamId
  } catch (err) {
    sending.value = false
    // 错误处理...
  }
}

async function cancelCurrentRequest() {
  if (!activeStreamId.value) return
  try {
    await httpPost('/api/chat/cancel', { streamId: activeStreamId.value })
  } catch (e) { /* best-effort */ }
  activeStreamId.value = null
  sending.value = false
}
```

### 3.4 Stop 按钮 UI

参考 Hermes `.cancel-btn`：

- 34px 圆形按钮
- `background: var(--error)`（红色）
- 白色方形停止图标（SVG）
- hover: `transform: scale(1.1)`
- active: `transform: scale(0.95)`
- `box-shadow: 0 2px 10px rgba(0,0,0,.18)`
- 流式时显示，完成/取消后隐藏

### 3.5 SSE 事件分类处理

参考 Hermes 的 SSE 事件分类，前端需处理以下事件类型：

| 事件 | Hermes 参考 | 处理方式 |
|---|---|---|
| `chat.delta` (token) | `messages.js:771` | 追加到当前助手消息内容 |
| `chat.delta` (reasoning) | `messages.js:787` | 追加到 ThinkingBlock |
| `chat.delta` (tool) | `messages.js:799` | 显示 ToolCallCard |
| `chat.done` | `messages.js:819` | 设置 `sending=false`，清理 streamId |
| `chat.cancel` | `messages.js:966` | 重新加载 session，设置 `sending=false` |
| `chat.apperror` | `messages.js:886` | 显示错误（rate limit、quota、model not found） |
| `chat.stream_end` | `messages.js:819` | 流结束，但 session 可能还在处理 |

**SSE 重连策略：**
- 流式传输中 SSE 断开时，尝试一次重连（参考 Hermes `messages.js:945-961`）
- 重连失败则显示错误消息
- 页面刷新时先检查 session 状态再重连

### 3.6 Gateway 兼容性

- 如果 Gateway 不支持 `chat.cancel` RPC，后端 catch 错误但仍然返回 `{ ok: true }`
- 前端状态无论如何都会正确恢复（`sending = false`）
- 这是 best-effort 取消，与现有行为一致，但 stream_id 追踪使流程更清晰

---

## 4. 通用 UX 增强

参考 Hermes 的通用 UX 模式，以下功能在本次重构中一并实现：

### 4.1 自动滚动（pinned scroll）

参考 Hermes `scrollIfPinned()`（`ui.js:668-671`）：
- 新消息到达时，仅在用户未手动上滚时自动滚动到底部
- 距离底部超过 150px 时判定为"已上滚"，不自动滚动
- 用户点击"滚动到底部"按钮后恢复 pinned 状态

### 4.2 键盘快捷键

- `Enter` 发送消息
- `Shift + Enter` 换行
- `Escape` 取消当前编辑（如有）

### 4.3 拖拽上传视觉反馈

- 拖拽文件到 composer 区域时显示 `.drag-over` 状态（边框高亮 + 背景色变化）
- 松开后恢复原样，文件添加到附件列表

### 4.4 图片预览（lightbox）

- 聊天中的图片点击可放大查看
- `Escape` 关闭预览
- 参考 Hermes `ui.js:68-80`

### 4.5 以下功能暂不纳入

以下 Hermes 功能本次不实现（scope 控制）：
- 声音通知（WebAudio beep）
- 浏览器通知（Notification API）
- 消息队列（steer/interrupt/queue 模式）
- 流式 markdown 增量解析（现有 MarkdownRenderer 已够用）

---

## 5. 实现顺序

建议按以下顺序实现：

1. **视觉风格** — 先改 CSS 变量和组件样式，建立新的视觉基础
2. **Stop 按钮** — 引入 stream_id 追踪，改造前后端
3. **附件功能** — 接通上传流程，完善 chip UI
4. **通用 UX** — 自动滚动、键盘快捷键、拖拽反馈、图片预览

理由：视觉风格改动最大但风险最低（纯样式），Stop 按钮涉及前后端联调，附件功能依赖前两者的基础，通用 UX 是锦上添花。

---

## 6. 验证标准

### 附件
- [ ] 选择文件后显示 chip（缩略图/文件名）
- [ ] 拖拽文件到 composer 显示 drag-over 视觉反馈
- [ ] 发送时文件逐个上传成功
- [ ] 上传过程中 composer 显示 "Uploading…" 状态
- [ ] 上传失败时显示 "Upload error: ..." 错误信息
- [ ] 只附加文件无文字时自动生成 fallback 消息
- [ ] 消息文本包含 `[Attached files: ...]`
- [ ] 最多 5 个文件限制生效
- [ ] 超过 10MB 文件被拒绝
- [ ] blob URL 在组件卸载时正确释放

### 视觉风格
- [ ] 深色/浅色主题正常切换，过渡平滑（.15s）
- [ ] 消息布局符合 Hermes 风格（角色图标 + accent 色区分）
- [ ] Composer 样式与 Hermes 一致（圆角、辉光、自动增高）
- [ ] 代码块样式正确（圆角、字体、复制按钮）
- [ ] Thinking 卡片可折叠/展开，max-height 260px
- [ ] 滚动到底部按钮在上滚时显示
- [ ] ChatHeader 显示模型信息和连接状态
- [ ] 侧边栏流式会话显示 spinner
- [ ] 非 workspace 页面不受影响

### Stop 按钮
- [ ] 流式时 Stop 按钮显示（34px 圆形红色）
- [ ] 点击 Stop 后 UI 立即恢复
- [ ] 后端正确取消或静默失败
- [ ] stream_id 在 SSE 事件中正确附带
- [ ] SSE 事件按类型正确处理（token/reasoning/tool/done/cancel/apperror）
- [ ] SSE 断开时尝试一次重连
- [ ] 长时间运行后无内存泄漏（streamIdMap 定期清理）

### 通用 UX
- [ ] 自动滚动：未上滚时新消息自动滚动，上滚后不自动滚动
- [ ] Enter 发送，Shift+Enter 换行
- [ ] 图片点击放大预览，Escape 关闭
