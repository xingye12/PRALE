# Workspace Visual Redesign — Design Spec

**Date:** 2026-04-28
**Scope:** Visual-only redesign of the AI Workspace (工作台) UI. Business logic unchanged.
**Reference:** Hermes WebUI chat interface (hermes-chat-ui-extract.html)

---

## 1. Goals

- Make the workspace UI feel smooth and comfortable, matching Hermes's visual quality
- Two color themes: light (warm earth-tone) + dark (warm dark)
- Keep existing dual-column layout (sidebar + chat area)
- No changes to business logic, data flow, or component props/events

---

## 2. CSS Variable System

### Approach

Replace the current dual naming convention (`--on-surface` vs `--text-primary`) with a unified Hermes-inspired warm palette. Defined in `main.css`, consumed by all workspace components.

### Light Mode

| Variable | Value | Purpose |
|----------|-------|---------|
| `--bg` | `#FEFCF7` | Page background (warm off-white) |
| `--bg-sidebar` | `#FAF7F0` | Sidebar/panel background |
| `--bg-surface` | `#F3EEE3` | Card/panel surfaces |
| `--bg-input` | `rgba(0,0,0,.03)` | Input field background |
| `--bg-hover` | `rgba(0,0,0,.05)` | Hover state |
| `--bg-code` | `#F5F0E5` | Code block background |
| `--code-inline-bg` | `rgba(0,0,0,.06)` | Inline code background |
| `--border` | `#E0D8C8` | Primary border (warm gray) |
| `--border2` | `rgba(0,0,0,.15)` | Secondary border |
| `--text` | `#1A1610` | Primary text (warm near-black) |
| `--text-muted` | `#5C5344` | Secondary text (warm gray-brown) |
| `--text-strong` | `#0F0D08` | Bold text |
| `--accent` | `#B8860B` | Primary accent (dark gold) |
| `--accent-hover` | `#996F08` | Accent hover |
| `--accent-bg` | `rgba(184,134,11,.08)` | Accent background subtle |
| `--accent-bg-strong` | `rgba(184,134,11,.15)` | Accent background stronger |
| `--accent-text` | `#8B6508` | Text on accent backgrounds |
| `--blue` | `#0288A8` | Links, blockquote borders |
| `--error` | `#C62828` | Error/danger |
| `--success` | `#3D8B40` | Success |

### Dark Mode

| Variable | Value | Purpose |
|----------|-------|---------|
| `--bg` | `#1A1814` | Page background (warm dark brown) |
| `--bg-sidebar` | `#1E1C17` | Sidebar background |
| `--bg-surface` | `#252320` | Card surfaces |
| `--bg-input` | `rgba(255,255,255,.04)` | Input background |
| `--bg-hover` | `rgba(255,255,255,.06)` | Hover state |
| `--bg-code` | `#2A2722` | Code block background |
| `--code-inline-bg` | `rgba(255,255,255,.08)` | Inline code background |
| `--border` | `#3A3630` | Primary border |
| `--border2` | `rgba(255,255,255,.12)` | Secondary border |
| `--text` | `#E8E0D4` | Primary text (warm off-white) |
| `--text-muted` | `#9C9486` | Secondary text |
| `--text-strong` | `#F5EDE0` | Bold text |
| `--accent` | `#D4A017` | Primary accent (bright gold) |
| `--accent-hover` | `#B8860B` | Accent hover |
| `--accent-bg` | `rgba(212,160,23,.1)` | Accent background subtle |
| `--accent-bg-strong` | `rgba(212,160,23,.18)` | Accent background stronger |
| `--accent-text` | `#D4A017` | Accent text |
| `--blue` | `#4FC3F7` | Links, blockquotes |
| `--error` | `#EF5350` | Error |
| `--success` | `#66BB6A` | Success |

### Layout Constants

| Variable | Value | Purpose |
|----------|-------|---------|
| `--sidebar-width` | `280px` | Sidebar width (unchanged) |
| `--header-height` | `56px` | Top bar height (reduced from 64px) |
| `--msg-max` | `780px` | Message body max width |
| `--composer-max` | `780px` | Composer max width |

### Typography

```css
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
font-family (mono): "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
```

### Files Modified

- `src/assets/styles/main.css` — rewrite CSS variables, keep layout/utility classes

---

## 3. Message List (MessageList.vue)

### Layout

- `.messages-inner`: `max-width: 900px`, `margin: 0 auto`, `padding: 20px 24px 120px`
- Messages rendered as a flex column

### User Messages

- `align-self: flex-end`, `max-width: 60%`
- Bubble: `background: var(--accent)`, `color: #fff`, `border-radius: 14px`, `padding: 10px 14px`
- Role label above bubble: small circle icon (20px) + "You" + timestamp
- Code inside bubble: white text, `background: rgba(0,0,0,.1)`
- Entrance animation: `msg-in` (`opacity: 0→1`, `translateY(6px)→0`, `.25s ease`)

### Assistant Messages

- Left-aligned, `max-width: var(--msg-max)` (780px)
- No bubble — plain text on page background
- Role label: circle icon + agent name + timestamp, `font-size: 11px`, `opacity: .6`
- Body: `font-size: 14px`, `line-height: 1.75`, `overflow-wrap: anywhere`
- Paragraphs: `margin-bottom: 10px`, last child no margin
- Lists: `margin: 6px 0 10px 20px`
- Headings: h1=18px, h2=16px, h3=14px, `font-weight: 600`

### Streaming Cursor

- `::after` pseudo-element: `width: 7px`, `height: 1em`, `background: var(--accent)`, `border-radius: 1px`
- `animation: blink .9s step-end infinite`
- Applied via `.streaming-cursor` class, removed when streaming completes

### Scroll-to-bottom Button

- Change from `position: fixed` to `position: absolute` (relative to messages container)
- Style with warm accent colors

### Files Modified

- `src/views/workspace/MessageList.vue`
- `src/assets/styles/main.css`

---

## 4. Composer (ChatInput.vue)

### Container

- `.composer-wrap`: `background: var(--bg-sidebar)`, `border-top: 1px solid var(--border)`, `padding: 10px 20px 14px`
- `.composer-box`: `max-width: 780px`, `margin: 0 auto`, `background: var(--bg)`, `border-radius: 16px`, `border: 1px solid var(--border2)` (light: `rgba(0,0,0,.12)`, dark: `rgba(255,255,255,.12)`)
- Focus ring: `:focus-within` → `border-color: var(--accent)` + `box-shadow: 0 0 0 3px var(--accent-bg)`

### Textarea

- `font-size: 16px` (larger than message body for comfortable input)
- `min-height: 24px`, `max-height: 200px`, auto-resize
- No border, no background, `resize: none`, `outline: none`
- Placeholder: `color: var(--text-muted)`, `opacity: .6`

### Footer Toolbar

Left side:
- Attach button: 32px circle, transparent, hover `var(--bg-hover)`
- Divider: 1px vertical line
- Slash command trigger (keep existing functionality)

Right side:
- Status text: `font-size: 11px`, `color: var(--text-muted)`
- Cancel button: 34px circle, `background: var(--error)`, white icon, `box-shadow: 0 2px 8px rgba(198,40,40,.2)`
- Send button: 34px circle, `background: var(--accent)`, white icon, `box-shadow: 0 2px 8px var(--accent-bg-strong)`, hover `transform: scale(1.08)`
- Disabled: `opacity: .35`, `cursor: not-allowed`

### Attachment Chips

- `background: var(--accent-bg)`, `border: 1px solid var(--accent-bg-strong)`, `border-radius: 6px`, `padding: 4px 9px`, `font-size: 12px`, `color: var(--accent-text)`

### Slash Command Menu

- `background: var(--bg-surface)`, `border: 1px solid var(--border2)`, `border-radius: 10px`
- `box-shadow: 0 -4px 20px rgba(0,0,0,.1)`

### Files Modified

- `src/views/workspace/ChatInput.vue`
- `src/assets/styles/main.css`

---

## 5. Thinking Block (ThinkingBlock.vue)

### Card Style

- `background: var(--accent-bg)`, `border: 1px solid var(--accent-bg-strong)`
- `border-radius: 8px`, `margin: 6px 0`, `max-width: var(--msg-max)`
- `animation: msg-in .2s ease`

### Header

- Clickable, `font-size: 12px`, `color: var(--accent-text)`
- Chevron rotates 90° on toggle: `transform: rotate(90deg)`, `transition: transform .18s`

### Body (Collapsible)

- Multi-property coordinated transition:
  - `max-height: 0 → 500px`
  - `opacity: 0 → 1`
  - `padding: 0 → 8px 12px`
  - `border-top-color: transparent → var(--accent-bg-strong)`
- `transition: max-height .25s ease, opacity .18s ease, padding .2s ease, border-top-color .2s ease`
- Content: `pre`, `font-size: 11px`, monospace, `color: var(--text-muted)`, `white-space: pre-wrap`

### Files Modified

- `src/views/workspace/ThinkingBlock.vue`

---

## 6. Tool Call Card (ToolCallCard.vue)

### Card Style

- Default: `background: rgba(0,0,0,.02)`, `border: 1px solid rgba(0,0,0,.08)`
- Running: `background: var(--accent-bg)`, `border-color: var(--accent-bg-strong)`
- `border-radius: 8px`, `margin: 4px 0`, `max-width: var(--msg-max)`
- `animation: msg-in .2s ease`

### Header

- Running dot: 6px circle, `background: var(--accent)`, `animation: pulse 1.2s ease-in-out infinite`
- Tool name: monospace, `font-size: 11px`, `font-weight: 600`, `color: var(--text-muted)`
- Preview: `text-overflow: ellipsis`, `font-size: 11px`
- Toggle chevron: rotates 90°

### Body (Collapsible)

- Same transition pattern as ThinkingBlock
- `word-break: break-word` (replace current `break-all`)
- Result `pre`: `max-height: 300px`, `overflow-y: auto`

### Error State

- Red border using `var(--error)` color

### Files Modified

- `src/views/workspace/ToolCallCard.vue`

---

## 7. Sidebar (WorkspaceSidebar.vue)

### Container

- `background: var(--bg-sidebar)`, `border-right: 1px solid var(--border)`
- Remove `backdrop-filter` / `glass-effect`, use solid background

### Header

- Title: `font-size: 16px`, `font-weight: 600`, `color: var(--text)`
- "New Chat" button: `background: var(--accent)`, `color: #fff`, `border-radius: 8px`

### Search

- `background: var(--bg-input)`, `border: 1px solid var(--border)`, `border-radius: 8px`
- Focus: `border-color: var(--accent)`

### Agent Items

- `padding: 10px 12px`, `border-radius: 8px`
- Hover: `background: var(--bg-hover)`
- Selected: `background: var(--accent-bg)`, left 3px `var(--accent)` border
- Expand arrow: rotate animation `.18s`

### Session Items

- `padding: 8px 12px 8px 28px` (indented)
- Title: `font-size: 13px`, `color: var(--text)`
- Time: `font-size: 11px`, `color: var(--text-muted)`
- Hover: `background: var(--bg-hover)`
- Active: `background: var(--accent-bg)`
- Streaming: pulse dot (same as Tool Call)

### Time Group Labels

- `font-size: 11px`, `font-weight: 600`, `color: var(--text-muted)`
- `text-transform: uppercase`, `letter-spacing: .04em`
- `padding: 8px 12px 3px`

### Context Menu

- `background: var(--bg-surface)`, `border: 1px solid var(--border2)`
- `border-radius: 10px`, `box-shadow: 0 4px 20px rgba(0,0,0,.1)`

### Scrollbar

- `width: 6px`, track transparent
- Thumb: `rgba(0,0,0,.12)`, hover: `rgba(0,0,0,.25)`

### Files Modified

- `src/views/workspace/WorkspaceSidebar.vue`

---

## 8. Header (ChatHeader.vue)

### Style

- Height: 56px (from 64px)
- `background: var(--bg-sidebar)`, `border-bottom: 1px solid var(--border)`
- `padding: 0 20px`
- Connection dot: online `var(--success)`, offline `var(--error)`
- Model chip: `background: var(--accent-bg)`, `border: 1px solid var(--accent-bg-strong)`, `border-radius: 999px`, `font-size: 12px`, `color: var(--accent-text)`

### Files Modified

- `src/views/workspace/ChatHeader.vue`

---

## 9. Welcome Screen (WelcomeScreen.vue)

### Style

- Centered via `flex: 1` + `align-items: center; justify-content: center`
- Logo: project pets icon, 72×72, `filter: drop-shadow(0 2px 8px rgba(184,134,11,.2))`
- Title: `font-size: 22px`, `font-weight: 600`, `color: var(--text)`
- Subtitle: `font-size: 14px`, `color: var(--text-muted)`
- `user-select: none`
- Remove `opacity: 0.6` from icon

### Files Modified

- `src/views/workspace/WelcomeScreen.vue`

---

## 10. Markdown Renderer (MarkdownRenderer.vue)

### Code Blocks

- `background: var(--bg-code)`, `border: 1px solid var(--border)`, `border-radius: 10px`
- `padding: 14px 16px`
- Monospace, `font-size: 13px`, `line-height: 1.6`
- Copy button: hover reveal, `background: var(--bg-hover)`, `border-radius: 6px`

### Inline Code

- `background: var(--code-inline-bg)` (light: `rgba(0,0,0,.06)`, dark: `rgba(255,255,255,.08)`)
- `padding: 1px 5px`, `border-radius: 4px`, `font-size: 12.5px`
- Add `--code-inline-bg` to CSS variable system

### Streaming Cursor

- 7px wide gold block via `::after`
- `animation: blink .9s step-end infinite`

### Syntax Highlighting

- Light mode: `highlight.js` github theme
- Dark mode: `highlight.js` github-dark theme

### Files Modified

- `src/views/workspace/components/MarkdownRenderer.vue`
- `src/composables/useMarkdownIt.ts`

---

## 11. Message Actions (MessageActions.vue)

### Style

- Hover reveal on `.msg-row:hover`
- `background: var(--bg-hover)`, `border-radius: 6px`
- Icon `color: var(--text-muted)`
- Fix scoped style dependency on parent `.msg-row` class

### Files Modified

- `src/views/workspace/components/MessageActions.vue`

---

## 12. Animations Summary

| Name | Definition | Usage |
|------|-----------|-------|
| `msg-in` | `opacity: 0→1`, `translateY(6px)→0`, `.25s ease` | Every message, thinking card, tool card |
| `pulse` | `opacity: .4↔1`, `1.2s ease-in-out infinite` | Tool card running dot, streaming session dot |
| `blink` | `opacity: 1↔0`, `.9s step-end infinite` | Streaming cursor |

### Transition Durations

| Context | Duration |
|---------|----------|
| Hover micro-interactions | `.12s` |
| Suggestion/chip hover | `.15s` |
| State changes (collapse, toggle) | `.18s`–`.25s` |
| Context ring / progress | `.4s` |

---

## 13. Implementation Order

1. **main.css** — CSS variables (light + dark), global resets, scrollbar, utility classes
2. **MessageList.vue** — message bubbles, layout, streaming cursor
3. **ChatInput.vue** — composer box, footer toolbar, buttons
4. **ThinkingBlock.vue** — accent-tinted collapsible card
5. **ToolCallCard.vue** — running state, collapsible detail
6. **WorkspaceSidebar.vue** — warm palette integration
7. **ChatHeader.vue** — height, colors, model chip
8. **WelcomeScreen.vue** — icon, colors
9. **MarkdownRenderer.vue** — code blocks, syntax highlighting theme
10. **MessageActions.vue** — hover style fix
11. **SlashCommandMenu.vue** — warm palette
12. **ImageLightbox.vue** — warm palette overlay

---

## 14. Out of Scope

- Business logic (send, receive, streaming, session management)
- Component props/events/interface changes
- New features (context ring, profile/workspace/model chips)
- Performance optimizations (virtualization, pagination)
- i18n fixes (hardcoded Chinese strings) — separate task
- Bug fixes (streaming merge edge cases, drag-leave flicker) — separate task
