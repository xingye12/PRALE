# 修改密码功能设计

**日期:** 2026-04-29
**状态:** 已批准

---

## 目标

1. 所有用户可通过右上角头像菜单进入"修改密码"
2. 未改过密码的新用户登录后被强制引导修改密码，完成后才能使用系统

## 前提

- 后端 `PUT /api/auth/password` 端点已存在（验证旧密码 + 设置新密码）
- 前端 `authStore.changePassword()` 方法已存在
- 缺少：UI 入口 + 密码修改追踪机制

---

## 数据库层

在 `users` 表新增字段：

```sql
ALTER TABLE users ADD COLUMN password_changed_at INTEGER DEFAULT NULL;
```

- `NULL` = 从未改过密码（新建用户默认值）
- 有值 = 最后一次改密码的时间戳（毫秒）

**admin 初始化处理：** `initDefaultAdmin` 创建/更新 admin 时设置 `password_changed_at` 为当前时间戳，admin 不需要强制改密码。

**现有用户处理：** 已有用户的 `password_changed_at` 为 NULL，首次登录时会被要求改密码。如果需要豁免现有用户，迁移时可批量设置为当前时间戳。

---

## 后端 API

### 修改 `PUT /api/auth/password`

在密码修改成功后，额外执行：

```sql
UPDATE users SET password_changed_at = ? WHERE id = ?
```

值为 `Date.now()`。

### 修改 `updateUser` 函数

在 `user-manager.js` 的 `updateUser` 中，当 `updates.password` 存在时，同时更新 `password_changed_at`。

### `GET /api/auth/check` / `POST /api/auth/login`

返回的 `user` 对象通过 `sanitizeUser` 透传，`password_changed_at` 字段自动包含在返回值中（`sanitizeUser` 只排除 `password_hash`）。

### `initDefaultAdmin`

创建 admin 时设置 `password_changed_at = Date.now()`。

---

## 前端

### User 类型扩展

`src/api/types/user.ts` 的 `User` 接口新增：

```typescript
password_changed_at: number | null
```

### 路由守卫

`src/router/index.ts` 的 `beforeEach` 中增加逻辑：

```
if (authenticated && user.password_changed_at === null && to.name !== 'ForceChangePassword') {
  → redirect to { name: 'ForceChangePassword', query: { redirect: to.fullPath } }
}
```

### 新路由

`src/router/routes.ts` 在 `/login` 同级添加：

```typescript
{
  path: '/force-change-password',
  name: 'ForceChangePassword',
  component: () => import('@/views/ForceChangePasswordPage.vue'),
  meta: { public: true },
}
```

注：`public: true` 跳过登录检查，但路由守卫中会验证 token 有效性。

### 强制改密页 `ForceChangePasswordPage.vue`

独立全屏页面，视觉风格与登录页一致：
- 顶部显示欢迎语："欢迎加入 WattClaw" + 副标题"为了您的账户安全，请为自己设置一个新密码"
- 表单字段：旧密码、新密码、确认密码
- 前端校验：新密码 ≥ 6 位、两次输入一致
- 提交：调用 `authStore.changePassword()`
- 成功后：调用 `authStore.checkAuth()` 刷新 user 对象（含新 `password_changed_at`），跳转 `redirect` 参数或首页
- 无"跳过"按钮，必须完成
- 显示当前用户名/显示名称

### 头像菜单"修改密码"

`AppHeader.vue` 的 `userDropdownOptions` 新增菜单项：

```typescript
{ label: t('common.changePassword'), key: 'changePassword' }
```

放在 settings 和 logout 之间，所有用户可见。

`handleUserAction` 新增 `changePassword` case，打开修改密码 Modal。

### 修改密码 Modal

可复用组件或内联在 AppHeader 中：
- 表单：旧密码、新密码、确认密码
- 校验：同强制改密页
- 成功后：提示"密码已修改"，关闭弹窗

---

## i18n 新增 key

```
common.changePassword: '修改密码' / 'Change Password'
pages.forceChangePassword.title: '欢迎加入 WattClaw' / 'Welcome to WattClaw'
pages.forceChangePassword.subtitle: '为了您的账户安全，请为自己设置一个新密码' / 'For your account security, please set a new password'
pages.forceChangePassword.currentPassword: '当前密码' / 'Current Password'
pages.forceChangePassword.newPassword: '新密码' / 'New Password'
pages.forceChangePassword.confirmPassword: '确认新密码' / 'Confirm New Password'
pages.forceChangePassword.submit: '确认修改' / 'Confirm'
pages.forceChangePassword.success: '密码修改成功' / 'Password changed successfully'
pages.forceChangePassword.passwordMismatch: '两次输入的密码不一致' / 'Passwords do not match'
pages.forceChangePassword.passwordTooShort: '密码长度至少6位' / 'Password must be at least 6 characters'
```

---

## 修改文件清单

| 文件 | 改动 |
|------|------|
| `server/database.js` | users 表新增 `password_changed_at` 字段 |
| `server/user-manager.js` | `updateUser` 更新 `password_changed_at`；`initDefaultAdmin` 设置初始值 |
| `src/api/types/user.ts` | `User` 接口新增字段 |
| `src/router/routes.ts` | 新增 ForceChangePassword 路由 |
| `src/router/index.ts` | beforeEach 增加强制改密检查 |
| `src/views/ForceChangePasswordPage.vue` | 新建强制改密页面 |
| `src/components/layout/AppHeader.vue` | 头像菜单新增"修改密码" + Modal |
| `src/i18n/messages/zh-CN.ts` | 新增 i18n key |
| `src/i18n/messages/en-US.ts` | 新增 i18n key |
