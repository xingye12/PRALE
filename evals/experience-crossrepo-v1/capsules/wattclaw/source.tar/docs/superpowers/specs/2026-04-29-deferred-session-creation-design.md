# Deferred Session Creation

**Date:** 2026-04-29
**Status:** Approved

---

## Problem

When navigating to the AI workspace from other pages (e.g., "去对话" button on agent cards), `startNewChat` is called immediately on page mount. This generates a session key like `agent:xxx:mok7f3pe-ovbaofsw` and optimistically inserts it into the sidebar session list. The user sees an empty session with a random ID before typing anything.

## Goal

Session creation should be deferred until the user sends their first message. The sidebar should only show sessions that actually exist (have been persisted to the Gateway).

## Design

### State Model

`activeSessionKey` lifecycle changes:
- **Before:** Generated immediately on `selectAgent`
- **After:** `null` until `sendMessage` is called for the first time

The chat interface (ChatHeader + MessageList + ChatInput) is shown whenever a `selectedAgent` exists, regardless of `activeSessionKey`. With no messages, MessageList renders an empty state naturally.

### Store Method Changes

#### `selectAgent(agentId)` — Pure selection, no session creation

- Set `selectedAgentId = agentId`
- Set `activeSessionKey = null`
- Set `messages = []`
- Read `selectedModel` from agent config
- Load agent's existing sessions from Gateway (via `listSessions`)

#### `startNewChat(agentId)` — Unchanged, but called later

- Generate session key: `agent:{agentId}:{timestamp}-{random}`
- Set `activeSessionKey`
- Optimistically insert session into agent's session list
- Only called from `sendMessage` fallback or explicitly by user action

#### `sendMessage` — No changes needed

Already has fallback at lines 365-368:
```typescript
if (!activeSessionKey.value) {
  const agentId = selectedAgentId.value || 'main'
  startNewChat(agentId)
}
```

This is the only place where session creation happens during normal chat flow.

#### `handleNewChat()` — New behavior

- Calls `selectAgent(currentAgentId)` instead of `startNewChat`
- Clears current chat, returns to "ready to chat" state
- Does NOT create a new session

### Component Changes

#### WorkspacePage.vue

**Mount logic (onMounted):**
```
if (agentId from route query) {
  selectAgent(agentId)     // was: selectAgent + startNewChat
} else if (activeSessionKey) {
  selectSession(sessionKey)
}
// else: show welcome screen (no agent selected)
```

**Route watcher:**
```
watch(route.query.agentId) {
  selectAgent(newAgentId)  // was: selectAgent + startNewChat
}
```

**Template:** No changes needed. `v-if="workspaceStore.selectedAgent"` already shows the chat interface when an agent is selected.

#### WorkspaceSidebar.vue

**`handleAgentClick(agent)`:**
```
selectAgent(agent.agentId)  // was: selectAgent + startNewChat
agent.expanded = true
```

**`handleNewChat(agentId)`:**
```
selectAgent(agentId)  // was: startNewChat
```

### User Flow

1. User clicks "去对话" on agent card → navigates to `?agentId=xxx`
2. WorkspacePage mounts → `selectAgent(agentId)` → agent selected, empty chat, no session
3. Sidebar shows agent's existing sessions (from Gateway), no new empty session
4. User types message and sends → `sendMessage` detects `activeSessionKey === null` → calls `startNewChat` → session created and message sent
5. Session appears in sidebar with label from `generate-title`

### Edge Cases

- **Switch agent before sending:** Just switches agent, no orphan session created
- **Click existing session:** `selectSession` works as before, loads history
- **Refresh page with no active session:** Welcome screen shown (no agent selected)
- **Multiple rapid sends:** First send creates session, subsequent sends use existing `activeSessionKey`

### Files to Modify

1. `src/stores/workspace.ts` — `selectAgent` method, `handleNewChat` method
2. `src/views/workspace/WorkspacePage.vue` — mount and watcher logic
3. `src/views/workspace/WorkspaceSidebar.vue` — `handleAgentClick` and `handleNewChat`
