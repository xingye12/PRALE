# Chat Bugs Fix Design

Date: 2026-04-30

## Overview

Fix 5 bugs in the workspace chat: attachment display, thinking block, loading indicator, IME input, and auto-scroll.

## Bug 1 & 2: Attachment Display (filename garbled + 0 B size)

### Root Cause

When sending, local `fileInfos = [{ name, size }]` is available but only in memory. After session switch, `parseFileBlocks` extracts filename from `[File: /path]` in Gateway history — the path has corrupted encoding for non-ASCII filenames, and the format contains no size info (size defaults to 0).

### Solution: localStorage Metadata Storage

**Storage**: `localStorage` key = `wc_files_${sessionKey}_${msgIndex}`

```typescript
// At send time
const key = `wc_files_${sessionKey}_${msgIndex}`
localStorage.setItem(key, JSON.stringify(fileInfos))
```

**Restore on load**: In `selectSession`, after `parseFileBlocks`, match stored metadata by index:

```typescript
messages.value = filtered.map((m, idx) => {
  if (m.role !== 'user') return m
  const { files, cleanedContent } = RPCClient.parseFileBlocks(m.content)
  if (!files) return m
  const stored = localStorage.getItem(`wc_files_${sessionKey}_${idx}`)
  if (stored) {
    const meta = JSON.parse(stored)
    files.forEach((f, i) => {
      if (meta[i]) { f.name = meta[i].name; f.size = meta[i].size }
    })
  }
  return { ...m, content: cleanedContent, files }
})
```

**Cleanup**: Prune oldest entries when localStorage exceeds 500 items.

### Files Changed

- `src/stores/workspace.ts` — store metadata on send, restore on selectSession
- `src/views/workspace/ChatInput.vue` — pass sessionKey to store on send

## Bug 3: Thinking Block Not Displaying

### Root Cause

Two sub-issues:

1. **Live streaming**: `normalizeRealtimeMessage` flattens all content into plain `content: string`. If Gateway sends thinking as structured blocks (not `<thinking>` tags), `getThinkingContent` regex fails to match.
2. **After session switch**: `_renderedHtml` is rendered from `m.content` which includes thinking text. ThinkingBlock also shows thinking content → duplicate/conflicting display.

### Solution

- **Live streaming**: In `normalizeRealtimeMessage`, if delta contains thinking-type content blocks, wrap them in `<thinking>...</thinking>` before flattening into content string.
- **History loading**: Strip `<thinking>...</thinking>` from content before rendering `_renderedHtml`, so ThinkingBlock is the sole display of thinking content.
- **Bootstrap thinking**: `filterBootstrapMessages` already filters bootstrap messages — ensure associated thinking content is also cleared.

### Files Changed

- `src/stores/workspace.ts` — normalizeRealtimeMessage thinking extraction, _renderedHtml stripping
- `src/views/workspace/MessageList.vue` — getThinkingContent robustness

## Bug 4: Loading Blank Period

### Root Cause

When `sending` becomes false, the agent may still be in thinking/tool phase. The assistant message has no content yet, and the user sees a blank area with no indication of processing.

### Solution

Show a "processing" indicator when the last assistant message is empty and agent is still working:

- **Condition**: Last message is assistant with empty content, or `sending` just ended but no content received yet
- **Display**: Pulsing dot animation + "Agent is thinking..." text (i18n)
- **Dismiss**: Automatically replaced when actual content arrives

### Files Changed

- `src/views/workspace/MessageList.vue` — add processing indicator component
- `src/i18n/zh-CN.ts` + `en-US.ts` — add i18n keys

## Bug 5: IME Input Sends Prematurely

### Root Cause

`ChatInput.vue` line 123 checks `e.key === 'Enter' && !e.shiftKey` but does not check `e.isComposing`. During IME composition (Chinese/Japanese/Korean), pressing Enter to confirm the character fires keydown with `isComposing: true`, which triggers send.

### Solution

One-line fix — add `!e.isComposing`:

```typescript
if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
```

Consistent with `AgentChatPanel.vue` (line 692) and `ChatPage.vue` (line 2300).

### Files Changed

- `src/views/workspace/ChatInput.vue` — line 123

## Bug 6: Auto-Scroll Not Working During Streaming

### Root Cause

The scroll watcher only triggers on `messages.length` changes (new messages). During streaming, content is appended to the last existing message — length doesn't change, so `scrollToBottom()` is never called. Relies entirely on browser native behavior which is unreliable.

### Solution

Add a watcher on the last message's content length:

```typescript
watch(
  () => {
    const msgs = workspaceStore.messages
    if (!msgs.length) return ''
    const last = msgs[msgs.length - 1]
    return last.content || ''
  },
  () => {
    if (isPinned.value) {
      nextTick(() => scrollToBottom())
    }
  }
)
```

Shallow watch on string (length change triggers). `nextTick` ensures DOM updates before scrolling.

### Files Changed

- `src/views/workspace/MessageList.vue` — add content watcher
