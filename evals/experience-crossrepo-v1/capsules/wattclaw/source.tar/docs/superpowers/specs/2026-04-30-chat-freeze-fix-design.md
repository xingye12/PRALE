# Chat Freeze Fix Design

**Date:** 2026-04-30
**Status:** Approved
**Scope:** Workspace chat (online conversation) freeze when switching models and re-entering sessions

---

## Problem Statement

When using the workspace chat ("在线对话"):

1. User sends a message → works fine
2. User switches model via ChatInput dropdown → UI still responsive
3. User sends another message → entire interface freezes
4. User closes browser, reopens, enters the same session → freezes immediately

The freeze is caused by `sending` state being stuck as `true` permanently, because the safety timeout is never armed when no SSE events arrive.

---

## Root Causes

### 1. Backend swallows gateway errors (Critical)

`server/index.js:2641-2649` — The `/api/workspace/send` endpoint always returns `{ ok: true, streamId }` even when `gateway.call('chat.send')` throws. The frontend receives success, sets `sending = true`, and waits for SSE events that will never come.

### 2. Stream timeout only armed on SSE events (Critical)

`src/stores/workspace.ts:504-510` — `resetStreamTimeout()` is only called inside `handleEvent` when a `chat.delta` or `agent.lifecycle.start` event arrives. If no events arrive (gateway error, SSE disconnect, session key mismatch), the 15-second idle timeout is never armed, and `sending` stays `true` permanently.

### 3. Cancel does not clean up timeouts (Medium)

`src/stores/workspace.ts:633-647` — `cancelCurrentRequest` sets `sending = false` but does not clear `streamTimeout`. A stale `forceStopStreaming` can fire later and corrupt state.

### 4. Model dropdown is cosmetic only (Medium)

`src/stores/workspace.ts:365-401` — `sendMessage` does not pass `selectedModel` to the backend. The model dropdown change has no effect on the actual gateway call. OpenClaw Gateway's `chat.send` does not support a `model` parameter (removed in commit `66fdf06`).

---

## Solution: Defense in Depth

### Fix 1: Backend error propagation

**File:** `server/index.js`

Change the `/api/workspace/send` endpoint to return an error when `gateway.call` fails:

```javascript
// Before:
try {
  await gateway.call('chat.send', { sessionKey, message, idempotencyKey })
} catch (err) {
  streamIdMap.delete(streamId)
  console.error('[Workspace] Gateway chat.send error:', err.message)
}
res.json({ ok: true, streamId })

// After:
try {
  await gateway.call('chat.send', { sessionKey, message, idempotencyKey })
} catch (err) {
  streamIdMap.delete(streamId)
  console.error('[Workspace] Gateway chat.send error:', err.message)
  return res.status(502).json({ ok: false, error: { message: err.message } })
}
res.json({ ok: true, streamId })
```

The frontend's existing `catch` block handles HTTP errors (sets `sending = false`, `lastError`).

### Fix 2: Frontend timeout safety net

**File:** `src/stores/workspace.ts`

a) In `sendMessage`, arm the timeout immediately after HTTP POST returns successfully:

```typescript
// After POST success:
activeStreamId.value = (result.streamId as string) || null
resetStreamTimeout()  // NEW: arm timeout immediately
```

b) Add a maximum stream duration (5 minutes):

```typescript
let maxStreamTimeout: ReturnType<typeof setTimeout> | null = null

// In sendMessage, after POST success:
if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
maxStreamTimeout = setTimeout(forceStopStreaming, 300_000)
```

### Fix 3: Cancel cleanup

**File:** `src/stores/workspace.ts`

In `cancelCurrentRequest`, clear all timeouts:

```typescript
async function cancelCurrentRequest() {
  if (!activeStreamId.value && !sending.value) return
  try {
    await httpPost('/api/chat/cancel', { ... })
  } catch { /* best-effort */ }

  if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
  if (maxStreamTimeout) { clearTimeout(maxStreamTimeout); maxStreamTimeout = null }
  activeStreamId.value = null
  sending.value = false
}
```

In `forceStopStreaming`, also clear `maxStreamTimeout`:

```typescript
function forceStopStreaming() {
  if (!sending.value) return
  if (streamTimeout) { clearTimeout(streamTimeout); streamTimeout = null }
  if (maxStreamTimeout) { clearTimeout(maxStreamTimeout); maxStreamTimeout = null }
  // ... rest unchanged
}
```

### Fix 4: Pass selectedModel via sessions.patch

**File:** `src/stores/workspace.ts`

Before sending the message, set the session's model via `sessions.patch`:

```typescript
async function sendMessage(content: string, displayContent?: string, files?: Array<{ name: string; size: number }>) {
  const text = content.trim()
  if (!text) return

  if (!activeSessionKey.value) {
    const agentId = selectedAgentId.value || 'main'
    startNewChat(agentId)
  }

  // NEW: Apply selected model to session before sending
  if (selectedModel.value && activeSessionKey.value) {
    try {
      await wsStore.rpc.patchSession({
        sessionKey: activeSessionKey.value,
        model: selectedModel.value,
      })
    } catch {
      // best-effort, don't block send
    }
  }

  // ... rest of sendMessage unchanged
}
```

---

## Files Changed

| File | Change |
|------|--------|
| `server/index.js` | Return 502 on gateway.call failure (~3 lines) |
| `src/stores/workspace.ts` | Timeout safety net + cancel cleanup + model passing (~20 lines) |

---

## Verification

1. **Backend error propagation**: Kill the gateway, send a message → should see error message, not freeze
2. **Timeout safety net**: Send a message, disconnect SSE → UI should recover within 15 seconds
3. **Cancel cleanup**: Send a message, cancel it → no stale timeout firing
4. **Model passing**: Switch model, send message → gateway should use the new model for the session
5. **Re-enter session**: Send a message that fails, close browser, reopen → session should load normally
