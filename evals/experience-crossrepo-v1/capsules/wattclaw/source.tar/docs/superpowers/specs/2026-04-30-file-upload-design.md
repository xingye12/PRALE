# 文件上传支持设计

**日期：** 2026-04-30
**状态：** 待实现
**范围：** WattClaw 工作台文件上传功能

---

## 问题陈述

WattClaw 工作台目前只支持文本文件（md/txt/json 等 <100KB）的附件功能。二进制文件（PDF、图片、docx 等）无法被 Agent 读取，存在三个问题：

1. **页面卡死** — 大文件用 `readAsText()` 阻塞主线程
2. **内容丢失** — 二进制文件只发送文件名，Agent 无法读取内容
3. **会话切换异常** — 历史消息中文件引用失效

## 设计目标

- 支持所有常见文件类型（PDF、docx、图片、文本等）上传到 Agent
- 与飞书等渠道的文件处理行为一致
- 不修改 Gateway 代码
- 上传过程不阻塞 UI

## 架构方案

### 核心思路

WattClaw 后端充当文件上传代理，通过 SSH 将文件传输到 Gateway 的 `media/inbound/` 目录，然后在消息中引用文件路径。这与飞书渠道的处理方式完全一致。

### 数据流

```
用户选择文件
    ↓
ChatInput.vue: File → FormData
    ↓
HTTP POST /api/workspace/upload (multipart/form-data)
    ↓
server/index.js: 接收文件 buffer (multer)
    ↓
SSH (ssh2 npm 包) → SCP 到 Gateway
  ~/.openclaw/media/inbound/{sanitized-name}---{uuid}.{ext}
    ↓
返回 { path, fileName, size }
    ↓
前端 sendMessage: "[File: /path/to/file.pdf]\n\n用户消息"
    ↓
Gateway chat.send → Agent 收到消息 + 文件路径
    ↓
Agent 用内置工具读取文件内容
```

### 消息格式

与飞书渠道一致：

```
[File: /home/wattman/.openclaw/media/inbound/dzfp_xxx---a1b2c3d4.pdf]

帮我分析一下这个发票
```

Agent 收到消息后，识别 `[File: path]` 格式，用内置文件读取工具获取内容。

---

## 详细设计

### 1. 后端：新增 `/api/workspace/upload` 端点

**位置：** `server/index.js`

**请求格式：**
```
POST /api/workspace/upload
Authorization: Bearer <token>
Content-Type: multipart/form-data

file: <binary file data>
```

使用 multipart/form-data 而非 JSON base64，避免浏览器端大 base64 字符串占用额外内存。

**响应格式：**
```json
{
  "ok": true,
  "path": "/home/wattman/.openclaw/media/inbound/document---a1b2c3d4.pdf",
  "fileName": "document.pdf",
  "size": 12345
}
```

**处理逻辑：**
1. 验证认证 token
2. 解码 base64 内容
3. 生成安全文件名：`{sanitized-original}---{uuid}.{ext}`
4. 通过 SSH 传输到 Gateway 的 `~/.openclaw/media/inbound/` 目录
5. 返回文件路径

### 2. 后端：SSH 文件传输模块

**新文件：** `server/gateway-file-transfer.js`

**职责：**
- 管理 SSH 连接（连接池/单连接复用）
- 提供 `uploadToGateway(buffer, fileName)` 方法
- 处理 SSH 连接错误和重试

**依赖：** `ssh2` npm 包（纯 JavaScript SSH2 客户端）

**SSH 配置（环境变量）：**
```env
GATEWAY_SSH_HOST=192.168.10.12
GATEWAY_SSH_USER=wattman
GATEWAY_SSH_KEY_PATH=/path/to/private/key  # 或用密码
GATEWAY_SSH_PASSWORD=                       # 如果用密码认证
GATEWAY_MEDIA_DIR=/home/wattman/.openclaw/media/inbound
```

**文件命名规则：**
```
{sanitized-filename}---{uuid}.{ext}
```
- `sanitized-filename`：移除不安全字符，保留中文/字母/数字/点/连字符/下划线，最大 60 字符
- `uuid`：`crypto.randomUUID()`
- 与 Gateway 的 `saveMediaBuffer` 格式一致

### 3. 前端：ChatInput.vue 改造

**当前流程：**
```
选择文件 → readAsText (文本) 或 只发文件名 (二进制) → sendMessage
```

**新流程：**
```
选择文件 → 上传到后端 → 获取文件路径 → sendMessage "[File: path]\n\n用户消息"
```

**改动点：**

1. **移除 `isTextFile` 和 `readAsText` 的核心地位** — 所有文件都走上传流程
2. **新增 `uploadFile(file)` 函数**：
   - 用 `FormData` 包装文件，直接 POST 到 `/api/workspace/upload`
   - 不在浏览器端读取文件内容，避免内存占用
   - 返回文件路径
3. **修改 `doSend` 函数**：
   - 有附件时，先上传所有文件
   - 用 `[File: path]` 格式构建消息
   - 显示上传进度（可选）
4. **上传进度 UI**：
   - 上传中显示 spinner 或进度条
   - 上传失败显示错误提示

**大文件处理：**
- `readAsDataURL` 是异步的，不会阻塞 UI
- 后端 SSH 传输也是异步的
- 建议限制文件大小为 30MB（与飞书一致）

### 4. 前端：文件附件显示

**当前：** 文件芯片显示文件名和大小
**新增：** 上传状态指示（上传中/已完成/失败）

---

## 环境变量

```env
# Gateway SSH 配置（用于文件上传）
GATEWAY_SSH_HOST=192.168.10.12
GATEWAY_SSH_USER=wattman
GATEWAY_SSH_KEY_PATH=/home/renming/.ssh/id_rsa
GATEWAY_MEDIA_DIR=/home/wattman/.openclaw/media/inbound
```

---

## 错误处理

| 错误场景 | 处理方式 |
|---------|---------|
| SSH 连接失败 | 返回 502，提示"Gateway 连接失败" |
| 文件过大 (>30MB) | 返回 413，提示文件大小限制 |
| base64 解码失败 | 返回 400，提示文件格式错误 |
| 目标目录不存在 | 自动创建目录 (mkdir -p) |
| SSH 认证失败 | 返回 500，日志记录认证错误 |

---

## 安全考虑

1. **文件名安全** — 移除路径分隔符、特殊字符，防止路径遍历
2. **大小限制** — 前后端都检查，防止 OOM
3. **SSH 密钥** — 使用密钥认证，不存储密码
4. **认证** — 上传端点需要 JWT 认证
5. **所有权** — 上传的文件关联到当前用户的 session

---

## 不在范围内

- 图片预览/缩略图（后续优化）
- 文件拖拽上传（后续优化）
- 多文件同时上传（当前一次一个）
- 文件下载功能（Agent 生成的文件）

---

## 依赖

- `ssh2` npm 包 — 纯 JavaScript SSH2 客户端
- `multer` npm 包 — Express multipart/form-data 文件上传中间件
- Gateway SSH 密钥认证 — 已在 server2 上配置完成

---

## 验证方式

1. 上传 PDF 文件，Agent 能读取并分析内容
2. 上传 md 文件，行为与当前一致
3. 上传大文件 (>5MB)，页面不卡死
4. 切换会话后，文件引用仍然有效
5. SSH 连接失败时有友好错误提示
