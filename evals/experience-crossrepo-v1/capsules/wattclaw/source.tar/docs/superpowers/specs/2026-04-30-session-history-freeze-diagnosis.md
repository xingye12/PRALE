# 会话历史加载卡死诊断

## 问题描述

在 AI 工作台（/workspace）点击会话加载历史聊天记录时，前端页面卡死。

目标会话数据：45 条消息，91KB，数据量不大。

## 已排除的原因

- **数据量**：45 条消息 / 91KB，远低于卡死阈值
- **深 watcher**：workspace 模块无 `deep: true` watcher
- **无限递归**：所有 `asText` 变体都有深度保护（rpc-client 版本无保护但数据结构不会触发深递归）
- **无限循环**：`parseFileBlocks`、`filterBootstrapMessages` 都有明确终止条件
- **Vue reactivity 循环**：computed 和 watcher 之间无循环依赖

## 可疑点（需诊断确认）

### 1. RPC Fallback 串行超时
`listChatHistory` 用 `callWithMethodAndParamsFallback`，5 方法 × 3 参数 = 15 种组合。
如果 Gateway 对第一个 `chat.history` 返回非标准错误（不匹配 `shouldFallbackOnError`），
会立即抛出。但如果返回 "unknown method"，会继续尝试下一个组合。

### 2. `normalizeChatMessageItem` 序列化开销
每条 toolCall 消息执行 `JSON.stringify(arguments, null, 2)`。
本会话有 8 个 toolCall，3 个 write 操作 arguments 含完整 Python 文件（5-6KB）。

### 3. Markdown 渲染累积
`content` 字段合并了 thinking + text + toolCall arguments。
assistant 消息 content 最长 5.6KB，markdown-it + highlight.js 渲染可能较慢。

### 4. `callWithMethodAndParamsFallback` 的 WebSocket 路径
前端 RPC 实际走 HTTP POST `/api/rpc`（ApiClient.rpc），不走原生 WebSocket。
但 `websocket.ts` 的 `send` 方法包装了这个调用，可能存在额外开销。

## 诊断方案

在 `selectSession` 各阶段加 `performance.now()` 计时，输出到 console：

```
[Perf] listChatHistory: 1234ms
[Perf] filterBootstrap: 2ms
[Perf] parseFileBlocks: 5ms
[Perf] total selectSession: 1241ms
```

同时在 `listChatHistory` 内部记录：
- 实际使用的方法名和参数格式
- normalizeChatHistoryPayload 耗时
- normalizeChatMessageItem 总耗时

## 实现步骤

1. 在 `workspace.ts` 的 `selectSession` 中加性能计时
2. 在 `rpc-client.ts` 的 `listChatHistory` 中加详细计时
3. 在 `rpc-client.ts` 的 `callWithMethodAndParamsFallback` 中记录成功的方法名
4. 让用户在浏览器 console 查看日志，确认瓶颈
