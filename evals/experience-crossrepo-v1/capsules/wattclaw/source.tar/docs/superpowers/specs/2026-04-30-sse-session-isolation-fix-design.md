# SSE Session Isolation Fix Design

**Date:** 2026-04-30
**Status:** Approved
**Scope:** Bug fix — cross-user message leak in multi-user scenarios

---

## Problem

When multiple users are online simultaneously, messages from User B's agent conversation can appear in User A's chat view. After page refresh, the leaked messages disappear.

### Root Cause 1 — Frontend: `chat.ts` missing session-key filtering

`src/stores/chat.ts` `handleRealtimeEvent()` (line 590-635):

- **No session-key check before merging messages.** Messages from ANY session are merged into the current view without verifying the event's sessionKey matches the active session.
- **Empty sessionKey auto-adoption.** When `sessionKey` is empty, the store adopts the sessionKey from any incoming event (line 599-603), causing all subsequent messages to flow to another user's session.

Contrast: `workspace.ts` `handleEvent()` (line 487-489) correctly drops events where `keyInEvent !== activeSessionKey`.

### Root Cause 2 — Server: `broadcastSSE` fallthrough for events without sessionKey

`server/index.js` `broadcastSSE()` (line 257-296):

- Events with `data.type === 'event'` but no `sessionKey` in payload bypass the ownership filter and are delivered to ALL connected SSE clients.
- The `continue` statement is inside `if (sk)`, so empty-sk events fall through to `client.res.write(message)` unconditionally.

### Why refresh fixes it

`fetchHistory()` calls `listChatHistory(sessionKey)` which returns only messages belonging to that specific session from the server. The frontend re-renders with correct data.

---

## Fix Design

### Frontend Fix — `src/stores/chat.ts`

**Change 1: Add session-key filter before merging messages**

```typescript
function handleRealtimeEvent(payload: unknown, options?) {
  const keyInEvent = extractSessionKey(payload)

  // Drop events for other sessions (mirrors workspace.ts pattern)
  if (sessionKey.value.trim() && keyInEvent && keyInEvent !== sessionKey.value) {
    return
  }

  // ... rest of function
}
```

**Change 2: Remove empty sessionKey auto-adoption**

Delete lines 599-603:
```typescript
// REMOVE:
if (!sessionKey.value.trim() && keyInEvent) {
  sessionKey.value = keyInEvent
}
```

This prevents a foreign event from hijacking the store's sessionKey.

### Backend Fix — `server/index.js`

**Change: Move `continue` to end of the event-filtering block**

Before:
```javascript
if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
  const sk = rawPayload.sessionKey || ...
  if (sk) {
    // ... ownership checks ...
    continue  // only skips when sk is non-empty and not owned
  }
  // sk is empty → falls through to deliver to ALL
}
client.res.write(message)
```

After:
```javascript
if (data.type === 'event' && rawPayload && client.userId && !client.isAdmin) {
  const sk = rawPayload.sessionKey || ...
  if (sk) {
    // ... ownership checks (unchanged) ...
  }
  continue  // ALL event-type messages for non-admin go through filter, no fallthrough
}
client.res.write(message)  // only admin or non-event types reach here
```

---

## Impact

- **Non-admin users:** Will no longer receive events without sessionKey. Events with sessionKey are filtered by ownership (unchanged behavior).
- **Admin users:** Continue to receive all events (unchanged).
- **gatewayState / backupProgress:** These use `data.type !== 'event'`, so they are unaffected and continue to broadcast to all.

## Verification

1. Open two browser windows with different non-admin users
2. User A starts a chat session with an agent
3. User B starts a different chat session
4. Verify User A does NOT see User B's messages in real-time
5. Verify User B does NOT see User A's messages in real-time
6. Verify admin user still sees all events
7. Verify page refresh still loads correct history
