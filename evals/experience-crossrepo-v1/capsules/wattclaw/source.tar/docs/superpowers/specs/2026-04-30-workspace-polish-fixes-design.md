# Workspace Polish Fixes Design

**Date:** 2026-04-30
**Scope:** 3 independent bug fixes for workspace UX

---

## Problem Statement

After the session history freeze fix (pre-rendered markdown + progressive rendering), three new issues emerged:

1. **History messages lack styling** — Agent replies loaded from history render with browser defaults instead of the styled markdown theme used by streaming messages.
2. **Agent name doesn't update on session switch** — Clicking a session belonging to a different agent doesn't update the ChatHeader agent name.
3. **Copy adds trailing newlines** — Copying agent replies via the copy button appends 2 extra blank lines.

---

## Fix 1: History Message Markdown Styling

### Root Cause

`.markdown-body` CSS rules are defined inside `MarkdownRenderer.vue`'s `<style scoped>`. When `MessageList.vue` renders history messages via `v-html` with `class="markdown-body"`, the scoped styles don't apply across component boundaries. Streaming messages (which use `<MarkdownRenderer>` directly) get full styling; history messages get browser defaults.

### Design

Extract all `.markdown-body` typography styles from `MarkdownRenderer.vue` into a new global CSS file `src/assets/styles/markdown.css`. Import it from `src/assets/styles/main.css`.

**Move to `markdown.css`:**
- `.markdown-body` base styles (font-size, line-height, color, word-break)
- All child selectors: `p`, headings, `pre.hljs`, inline `code`, `blockquote`, `ul/ol`, `table`, `hr`, `img`
- Code block styling (background, border, copy button)

**Keep in `MarkdownRenderer.vue` scoped styles:**
- `.streaming-cursor` (streaming-specific)
- `.image-lightbox` references (component-specific)

### Safety Analysis

CSS extraction does NOT risk the previous freeze because:
- The freeze was caused by **Vue component instantiation** (18+ MarkdownRenderer instances each creating markdown-it + highlight.js). CSS extraction does not change the rendering path.
- `v-html` stays `v-html` (zero component overhead). MarkdownRenderer stays MarkdownRenderer.
- All CSS variables (`--bg-code`, `--border`, `--text`, etc.) are already defined globally in `main.css`.
- Removing `:deep()` lowers specificity, won't affect other elements.
- No new JavaScript execution, no additional rendering.

### Files Modified

- `src/assets/styles/markdown.css` (new)
- `src/assets/styles/main.css` (add import)
- `src/views/workspace/components/MarkdownRenderer.vue` (remove extracted styles)

---

## Fix 2: Agent Name Sync on Session Switch

### Root Cause

`selectSession()` in `workspace.ts` sets `activeSessionKey` and loads chat history but never updates `selectedAgentId`. The ChatHeader computed chain (`selectedAgentId` → `selectedAgent` → `currentAgentName`) stays on the previous agent.

### Design

Add agent lookup logic at the start of `selectSession()`:

```typescript
// Find which agent owns this session and sync selectedAgentId
for (const agent of agents.value) {
  if (agent.sessions.some(s => s.key === sessionKey)) {
    if (selectedAgentId.value !== agent.agentId) {
      selectedAgentId.value = agent.agentId
      selectedModel.value = agent.model || selectedModel.value
    }
    break
  }
}
```

This keeps the fix centralized in the store — any caller of `selectSession` benefits automatically.

### Files Modified

- `src/stores/workspace.ts` (add agent lookup in `selectSession`)

---

## Fix 3: Copy Trailing Newlines

### Root Cause

`MessageList.vue:217` passes `:content="msg._thinking.answer || msg.content"` to `MessageActions`. When `_thinking.answer` is empty/falsy, the raw `msg.content` (which carries LLM trailing `\n\n`) is used untrimmed. `MessageActions.handleCopy()` calls `.trimEnd()` but receives already-untrimmed content through the prop.

### Design

Change the content binding to trim the fallback:

```html
:content="msg._thinking.answer || msg.content.trimEnd()"
```

### Files Modified

- `src/views/workspace/MessageList.vue` (line 217)

---

## Verification

1. **Fix 1:** Switch between sessions — history messages should have identical styling to streaming messages (code blocks with dark background/highlighting, proper heading sizes, list indentation).
2. **Fix 2:** Click a session belonging to a different agent — ChatHeader should show that agent's name immediately.
3. **Fix 3:** Copy an agent reply — pasted content should have no trailing blank lines.
