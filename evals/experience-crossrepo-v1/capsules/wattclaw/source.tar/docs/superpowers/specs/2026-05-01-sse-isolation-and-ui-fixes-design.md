# SSE Session Isolation + UI Fixes Design

**Date:** 2026-05-01
**Status:** Draft
**Scope:** Bug fix — cross-user message leakage + thinking/dots UI overlap

---

## Problem 1: Cross-user SSE message leakage (CRITICAL)

When multiple users are online, User A can see messages from User B's agent sessions appearing in their workspace. The existing fix (2026-04-30) only partially addressed this.

### Root Causes

**1. `chat.ts` `handleAgentStatusEvent` has NO sessionKey filter (lines 641-910)**

The function intentionally skips sessionKey filtering with comment "处理所有智能体的会话事件，不局限于当前 sessionKey". Agent status, tool progress, and partial assistant content from other sessions leak into the UI.

**2. Weak conjunction filter in `handleRealtimeEvent` and `handleEvent`**

Both functions use:
```ts
if (sessionKey.value && keyInEvent && keyInEvent !== sessionKey.value) {
  return
}
```

This only works when ALL three conditions are true. When `sessionKey` is empty (before session selected, after `clearMessages()`), ALL events pass through unfiltered.

**3. Server-side `broadcastSSE` admin bypass**

Admin users receive ALL events unfiltered. Agent-level ownership is overly broad — two users who both own agent "main" see each other's sessions.

**4. `useEventStream.ts` has zero sessionKey filtering**

Every SSE event is unconditionally added to `monitorStore.events` regardless of session ownership.

---

## Problem 2: Thinking + bouncing dots overlap

Agent 回复时，思考块（ThinkingBlock）和打字动画（三个省略号）同时显示。

### Root Cause

`isStreaming` computed in `MessageList.vue` returns `false` when `last.stopReason` is truthy. `mergeMessages` uses `{ ...last, ...next }` spread, so a delta carrying `stopReason` gets merged into the assistant message. When this happens mid-stream with thinking content, both indicators show simultaneously.

---

## Fix Design

### Fix 1: SSE 严格 session 归属隔离

**原则：所有用户（包括 admin）只接收自己拥有的 session 事件。**

#### Server-side: `server/index.js` `broadcastSSE`

移除 `!client.isAdmin` 条件，所有用户走同一套 sessionKey ownership 过滤：

```javascript
if (data.type === 'event' && rawPayload && client.userId) {
  // 所有用户（含 admin）都做 session 归属检查
  const sk = rawPayload.sessionKey || ...
  if (!sk) {
    continue  // 没有 sessionKey 的事件丢弃
  }
  const ownedKeys = getUserOwnedSessionKeys(client.userId)
  if (!ownedKeys.has(sk)) {
    continue  // 不属于该用户的 session 事件丢弃（不做 agentId fallback）
  }
  client.res.write(message)
  continue
}
client.res.write(message)  // 非 event 类型正常发送
```

#### Frontend: `src/stores/workspace.ts` `handleEvent`

强化过滤逻辑：

```ts
function handleEvent(payload: unknown) {
  const keyInEvent = extractSessionKey(payload)

  // 没有 activeSessionKey 时丢弃所有事件
  if (!activeSessionKey.value) return

  // 有 activeSessionKey 时：事件必须有 sessionKey 且匹配
  if (keyInEvent && keyInEvent !== activeSessionKey.value) return

  // ... 处理事件
}
```

#### Frontend: `src/stores/chat.ts` `handleRealtimeEvent`

同样强化：

```ts
function handleRealtimeEvent(payload: unknown) {
  const keyInEvent = extractSessionKey(payload)

  // 没有 sessionKey 时丢弃所有事件
  if (!sessionKey.value.trim()) return

  // 事件 sessionKey 不匹配时丢弃
  if (keyInEvent && keyInEvent !== sessionKey.value) return

  // ... 处理事件
}
```

#### Frontend: `src/stores/chat.ts` `handleAgentStatusEvent`

添加 sessionKey 过滤（当前完全没有）：

```ts
function handleAgentStatusEvent(payload: unknown) {
  const keyInEvent = extractSessionKey(payload)

  // 添加 sessionKey 过滤
  if (!sessionKey.value.trim()) return
  if (keyInEvent && keyInEvent !== sessionKey.value) return

  // ... 处理 agent 状态事件
}
```

#### Frontend: `src/composables/useEventStream.ts`

添加 sessionKey 过滤：

```ts
onMounted(() => {
  cleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as RPCEvent
    const payload = rpcEvent.payload as Record<string, unknown>
    const keyInEvent = extractSessionKey(payload)

    // 只处理当前会话的事件
    if (workspaceStore.activeSessionKey && keyInEvent && keyInEvent !== workspaceStore.activeSessionKey) {
      return
    }

    monitorStore.addEvent(agentEvent)
  })
})
```

### Fix 2: 打字动画与 ThinkingBlock 互斥

**改动文件：** `src/views/workspace/MessageList.vue`

#### Change 1: `isStreaming` 移除 `stopReason` 检查

```ts
const isStreaming = computed(() => {
  if (!workspaceStore.sending) return false
  const msgs = workspaceStore.messages
  if (msgs.length === 0) return true
  const last = msgs[msgs.length - 1]
  if (!last) return true
  // 移除 stopReason 检查 — sending 期间只要最后一条是 assistant/tool 就算 streaming
  return last.role === 'assistant' || last.role === 'tool'
})
```

#### Change 2: ThinkingBlock 始终折叠态

```html
<ThinkingBlock
  v-if="msg._thinking.isThinking && msg._thinking.thinking"
  :content="msg._thinking.thinking"
  :thinking="false"
/>
```

效果：
- agent 开始回复前 → 打字动画三个省略号
- agent 有思考内容时 → ThinkingBlock 卡片（折叠态，无"正在思考..."文字）
- agent 开始输出正文 → MarkdownRenderer 渲染
- 三者不会同时出现

---

## Impact

- **所有用户（含 admin）：** 只接收自己拥有的 session 事件，不再看到其他用户的实时消息
- **Admin 管理页面：** 不受影响（历史数据通过 API 查询，不依赖 SSE 实时事件）
- **Monitor store：** 只记录当前会话的事件
- **打字动画：** 不再与 ThinkingBlock 重叠

## Verification

1. 打开两个浏览器窗口，用不同非 admin 用户登录
2. User A 开始一个 agent 对话
3. User B 开始另一个 agent 对话
4. 验证 User A 看不到 User B 的实时消息
5. 验证 User B 看不到 User A 的实时消息
6. 用 admin 账号验证：admin 也只看到自己的 session 事件
7. 验证 ThinkingBlock 和打字动画不同时显示
8. 验证切换会话后历史消息正常加载
