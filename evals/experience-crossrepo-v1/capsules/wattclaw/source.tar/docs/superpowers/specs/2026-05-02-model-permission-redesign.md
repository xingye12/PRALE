# 模型管理权限重构设计

## 背景

模型管理页面被改动后权限逻辑混乱，需要重新梳理 admin/非 admin 用户的 Provider 可见性和操作权限。

## 需求规则

1. Admin 可看到所有用户的 Provider（含非 admin 用户的私有 Provider），但只能编辑/删除自己创建的
2. 非 admin 创建的 Provider 只对自己可见，其他非 admin 用户完全不可见
3. 非 admin 可以看到 admin 创建的 Provider，但只读（不可编辑/删除）
4. 非 admin 的渠道操作（新建/编辑/设默认/删除）只影响自己；admin 的操作影响所有用户
5. 非 admin 新增的模型/渠道只在当前用户生效；admin 新增的全局共享

## 数据模型

### user_model_providers 表（已存在，需加字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | TEXT PK | 主键 |
| user_id | TEXT FK | 创建者 ID（关联 users 表） |
| provider_id | TEXT | Provider 标识 |
| config | TEXT (JSON) | 完整配置（apiKey, baseUrl, models 等） |
| is_primary | BOOLEAN | 是否为该用户的默认 Provider |
| remark | TEXT | 备注（新增） |
| description | TEXT | 说明（新增） |
| created_at | INTEGER | 创建时间 |
| updated_at | INTEGER | 更新时间 |

### 可见性查询逻辑

```sql
-- 非 admin 用户 X：
SELECT * FROM user_model_providers
WHERE user_id = X
   OR user_id IN (SELECT id FROM users WHERE role = 'admin')

-- Admin 用户：
SELECT * FROM user_model_providers
```

### 操作权限矩阵

| 操作 | 自己创建的 | admin 创建的（非 admin 视角） | 非自己非 admin 创建的（admin 视角） |
|------|-----------|------------------------------|--------------------------------------|
| 查看 | ✅ | ✅（只读） | ✅（只读） |
| 编辑 | ✅ | ❌ | ❌ |
| 删除 | ✅ | ❌ | ❌ |
| 设默认 | ✅ | ✅（只设自己的默认） | N/A |

### 默认 Provider

用户级默认，每人独立的 `is_primary`，不影响其他用户。

## 存储策略

所有 Provider 统一写入：
1. **SQLite** `user_model_providers` 表 — 存储所有权和配置
2. **Gateway config** — 同步写入，使模型实际可用

删除时同步从两处移除。

## 删除 model_remarks

彻底删除 `model_remarks` 表及相关代码（后端接口、前端备注输入框）。Provider 级别的 `remark` + `description` 字段替代。

## 后端 API

### GET /api/model-providers

按可见性查询逻辑返回列表。每条记录附带 `ownerName`（创建者用户名）和 `readOnly` 标记。

### POST /api/model-providers

写入 SQLite + Gateway config。`user_id` = 当前用户。

### PUT /api/model-providers/:id

验证 `user_id` 匹配当前用户。更新 SQLite + Gateway config。

### DELETE /api/model-providers/:id

验证 `user_id` 匹配当前用户。删除 SQLite 记录 + 从 Gateway config 移除。

### PUT /api/model-providers/default

只更新当前用户的 `is_primary`。不影响 Gateway config。

### DELETE /api/model-remarks/:providerId 及 GET /api/model-remarks

删除这两个端点。

## 前端 ModelsPage 交互

### 非 admin 视角

- Admin 创建的 Provider：显示详情但隐藏编辑/删除按钮
- 自己创建的 Provider：完整操作权限
- 新建弹窗：含备注和说明输入框
- 设默认：只影响自己

### Admin 视角

- 自己创建的 Provider：完整操作权限
- 非 admin 创建的 Provider：显示但隐藏编辑/删除按钮，显示创建者名称

## 改动范围

1. `server/database.js` — 表加 remark/description 字段，删除 model_remarks 建表语句
2. `server/user-manager.js` — 删除 model_remarks 相关函数，更新 Provider CRUD 函数
3. `server/index.js` — 重写 Provider 相关路由，删除 model-remarks 路由，更新 Gateway 同步逻辑
4. `src/views/models/ModelsPage.vue` — 适配新 API 响应，只读 Provider 隐藏操作按钮，新建/编辑弹窗加备注说明字段，删除模型级备注 UI
