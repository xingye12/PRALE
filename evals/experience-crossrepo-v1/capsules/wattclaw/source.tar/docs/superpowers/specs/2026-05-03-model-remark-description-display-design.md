# 模型备注与说明显示设计

日期：2026-05-03

## 目标

在聊天界面（ChatInput）和数字员工创建/编辑页（AgentEditPage）的模型选择下拉框中，显示模型的备注（remark）和说明（description），与模型管理页（ModelsPage）的显示逻辑保持一致。

## 现状

- ChatInput.vue 和 AgentEditPage.vue 当前通过 `modelStore.models`（Gateway `listModels`）获取模型列表
- 备注通过 `localStorage` (`wattclaw:model-remarks`) 读取，格式为 `modelId → remark` 的扁平映射
- 说明（description）完全没有在模型选择中使用
- 模型管理页（ModelsPage）通过 `GET /api/model-providers` 获取 Provider 数据，备注和描述存储在 Provider 级别

## 设计

### 数据源

模型选择下拉框的数据源与 ModelsPage 保持一致：

1. 调用 `GET /api/model-providers` 获取用户可见的 Providers
2. 从每个 Provider 的 `config.models[]` 提取模型列表
3. 每个 Provider 的 `remark`（备注）和 `description`（说明）关联到该 Provider 下的所有模型
4. 移除 `wattclaw:model-remarks` localStorage 读取逻辑

### 数据层：useModelProviders composable

新建 `src/composables/useModelProviders.ts`：

- 调用 `GET /api/model-providers` 获取 Provider 列表
- 遍历每个 Provider 的 `config.models[]`，构建：
  - `modelList: Ref<Array<{ id, label, providerId, remark, description }>>` — 扁平化的模型列表
  - `getModelRemark(modelId): string` — 获取备注
  - `getModelDescription(modelId): string` — 获取说明
- 模型 label 优先级：`config.models[i].name` > `config.models[i].id`
- 备注优先级：`config.models[i].remark` > Provider 级别 `remark`
- 说明来源：Provider 级别 `description`
- 组件挂载时自动加载一次

### UI 组件：ModelDropdown.vue

新建 `src/components/ModelDropdown.vue`，通用模型选择组件。

#### Props & Emits

- Props: `modelValue: string`（v-model）
- Emits: `update:modelValue`

#### 下拉框布局

```
触发器（可配置外观：chip 样式 / select 样式）
└── 下拉面板
    ├── 模型项 1:  [模型名]        [备注(淡色)]  ✓
    ├── 模型项 2:  [模型名]        [备注(淡色)]
    └── 右侧描述弹出卡片（绝对定位）
        ├── 模型名（粗体）
        └── 描述文字（多行）
```

#### 备注显示

- 模型名和备注在同一行，flex 布局
- 模型名左对齐，备注右对齐
- 备注颜色：`var(--text-secondary)`，字号略小
- 下拉框宽度自适应：min-width 280px，max-width 420px
- 备注过长时 `text-overflow: ellipsis`

#### 说明弹出卡片

- 触发：鼠标悬停在有 description 的模型项上
- 位置：绝对定位在 hover 模型项的右侧，8px 间距
- 样式：
  - 圆角 8px
  - 背景 `var(--bg-card)`
  - 阴影 `0 4px 16px rgba(0,0,0,.12)`
  - 宽度 240-300px
  - 内部：模型名（粗体）+ 分隔线 + 描述文字
- 交互时序：
  - 鼠标进入模型项 → 100ms 延迟 → 显示卡片
  - 鼠标在模型项+卡片区域内 → 卡片保持
  - 鼠标离开区域 → 200ms 延迟 → 隐藏卡片
- 没有 description 的模型项不触发弹出
- 使用 CSS 变量，自然适配深浅模式

#### 两种触发器样式

- **ChatInput 模式**：chip 样式（现有样式，图标+模型名+下拉箭头）
- **AgentEditPage 模式**：select 样式（带边框的下拉框外观，和现有 NSelect 视觉一致）
- 通过 prop `variant: 'chip' | 'select'` 切换

### 页面适配

#### ChatInput.vue

- 替换 lines 346-364 的自定义 dropdown
- 使用 `<ModelDropdown variant="chip" />`
- 移除 localStorage 相关代码（modelRemarks, getModelRemark, getModelDisplayName）
- 移除 `MODEL_REMARKS_STORAGE_KEY` 和相关函数

#### AgentEditPage.vue

- 替换 line 197 的 `<NSelect>`
- 使用 `<ModelDropdown variant="select" />`
- 移除 `readModelRemark`、`MODEL_REMARKS_STORAGE_KEY` 和相关 localStorage 代码
- 移除 `modelOptions` computed

### i18n

新增文案：
- `zh-CN`: 模型说明弹出框标题（直接用模型名，无需额外文案）
- `en-US`: 同上

文案量极少，可能不需要新增 i18n key。

## 变更范围

| 文件 | 操作 |
|------|------|
| `src/composables/useModelProviders.ts` | 新建 |
| `src/components/ModelDropdown.vue` | 新建 |
| `src/views/workspace/ChatInput.vue` | 修改 — 替换模型选择 UI |
| `src/views/agent-team/AgentEditPage.vue` | 修改 — 替换 NSelect |

## 不变的部分

- 后端 API（已支持 remark/description）
- ModelsPage.vue（已有完整的 remark/description 编辑功能）
- model store（`src/stores/model.ts`）— ModelDropdown 不再依赖它
