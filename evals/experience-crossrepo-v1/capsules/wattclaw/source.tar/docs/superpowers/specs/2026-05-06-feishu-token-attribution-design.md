# 飞书 Session Token 归因设计

**日期**: 2026-05-06
**状态**: Approved

## 问题

用户通过飞书机器人交互时，Gateway 在对应 Agent 下创建 session 并消耗 token，但这些 session 和 token 用量没有归因到 WattClaw 中绑定该频道的用户账户。

## 根因

Gateway 的 session 存储按 Agent 隔离：

```
~/.openclaw/agents/
├── main/sessions/                    ← sessions.list() 默认查这里
├── agent-1778035964169/sessions/     ← 飞书 agent 的 sessions 在这里
└── ...
```

WattClaw 调用 `gateway.call('sessions.list', {})` 不传 agentId 参数，Gateway 只返回 main agent 的 sessions。飞书产生的 sessions 在其他 agent 目录下，因此：

1. `syncSessionsFromGateway()` 看不到飞书 sessions → 无法归属用户
2. `sessions.usage` 拿不到飞书 token 数据 → 用量统计缺失
3. `sessions.list` 前端请求同理 → 会话列表看不到飞书对话

## 解决方案

修改 `server/index.js` 中 3 个关键位置，对用户拥有的所有 Agent 分别查询 sessions。

### 1. syncSessionsFromGateway() — 多 Agent 同步

```js
async function syncSessionsFromGateway() {
  // 1. 查 main agent sessions（原有逻辑）
  // 2. 从 user_agents 表获取所有已知的 agent IDs
  // 3. 对每个 agent 调用 sessions.list({ agentId })
  // 4. 合并所有 sessions，统一执行 trackSessionForUser
}
```

数据源：
- `user_agents` 表中 `gateway_agent_id` 列（WattClaw 已知的 agent）
- `agents.list` RPC（可选，作为补充发现新 agent）

### 2. sessions.usage RPC proxy — 多 Agent usage 合并

```js
// 在 sessions.usage 处理中：
// 1. 调用 sessions.usage() 获取 main agent usage
// 2. 获取所有已知 agent IDs（admin: 全部，普通用户: 自己拥有的）
// 3. 对每个 agent 调用 sessions.usage({ agentId })
// 4. 合并 sessions 数组
// 5. 普通用户: filterOwnedSessions + recomputeUsageFromSessions
//    Admin: 合并所有 agent usage 后 recomputeUsageFromSessions（不过滤）
```

### 3. sessions.list RPC proxy — 多 Agent session 合并

```js
// 当前端不传 agentId 时：
// 1. 调用 sessions.list() 获取 main sessions
// 2. 获取所有已知 agent IDs（admin: 全部，普通用户: 自己拥有的）
// 3. 对每个 agent 调用 sessions.list({ agentId })
// 4. 合并结果
// 5. 普通用户: filterOwnedSessions
//    Admin: 直接返回（不过滤）
```

### 权限模型

| 角色 | sessions.list/usage 行为 |
|------|-------------------------|
| Admin | 查询所有 agent 的 sessions/usage，不过滤，全部返回 |
| 普通用户 | 查询所有 agent 的 sessions/usage，按 ownership 过滤后返回 |

**当前问题**：Admin 虽然不做 ownership 过滤，但也只拿到 main agent 的数据（因为 `sessions.list` 空参数只返回 main）。修复后 Admin 能看到所有 agent（包括飞书）的完整数据。

### SSE 实时事件

SSE 事件处理（index.js:232-247）已经能正确处理飞书事件：
- 从 session key 中提取 agentId
- 通过 getUserIdsByAgentId 找到用户
- 调用 trackSessionForUser 归属

这部分无需修改。

## 改动范围

| 文件 | 改动点 | 预计行数 |
|------|--------|---------|
| server/index.js | syncSessionsFromGateway 多 Agent 查询 | ~20行 |
| server/index.js | sessions.usage proxy 多 Agent 合并 | ~25行 |
| server/index.js | sessions.list proxy 多 Agent 合并 | ~15行 |

总计约 60 行改动，只修改 `server/index.js`。

## 验证方式

1. 在飞书上发消息触发对话
2. 普通用户：在 WattClaw 的会话列表和用量统计中能看到飞书的 session 和 token
3. Admin 用户：能看到所有用户（包括飞书）的 session 和 token
4. token 归因到绑定飞书频道的用户账户
