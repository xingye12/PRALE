# Agent Workspace 隔离改造设计

## 目标

为每个 agent 建立按用户隔离的 workspace 目录，注入文件路径规则到 BOOTSTRAP.md，并将用户上传的文件定向到 agent workspace 的 uploads/ 子目录。

仅影响新创建的 agent，旧 agent 的 workspace 路径保持不变。

## 1. 统一 workspace 路径格式

### 数字员工（AgentTeamPage.vue handleCreated）

路径格式：`~/.wattclaw/{username}/{agentname-timestamp}`

- `username` = `authStore.currentUser.username`（sanitize 后）
- `agentname` = agent 显示名称（sanitize 后）
- `timestamp` = `YYYYMMDDHHmmss` 格式

当前代码（行 89-98）生成 `~/.openclaw/{display_name || username}-{agentname}-{timestamp}`，改为：
- 基础目录从 `~/.openclaw/` 改为 `~/.wattclaw/`
- 去掉 `display_name` 优先级，统一用 `username`
- 路径格式从扁平改为两级：`{username}/{agentname-timestamp}`

### 低级 agent（agent.ts addAgent）

路径格式：`~/.wattclaw/agents/workspace-{id}`

当前代码（行 133）默认 `~/.openclaw/workspace-${params.id}`，改为 `~/.wattclaw/agents/workspace-${params.id}`。

## 2. BOOTSTRAP.md 注入 workspace 文件路径规则

### 新增函数（agent-templates.ts）

`generateBootstrapWithWorkspaceRules(bootstrapMd: string, workspacePath: string): string`

- 查找 `<!-- WORKSPACE_RULES -->` 标记替换为规则内容
- 无标记则追加到末尾
- 规则内容：

```markdown
## 文件路径规则
你的 workspace 根目录为: `{workspacePath}`
1. **所有中间文件**必须写到当前 workspace 目录下，禁止写入 `/tmp/`（工具临时文件除外）
2. **用户上传的文件**存放在: `{workspacePath}/uploads/`
3. **交付文件/会话生成的文件**写到: `{workspacePath}/downloads/`
4. **临时工作文件**写到: `{workspacePath}/tmp/`
5. **禁止写入用户 home 目录**（除非用户明确指定路径）
6. **使用相对路径或显式 workspace 路径**，不要依赖 shell cwd
7. 需要时在 `downloads/` 下创建子目录以组织输出文件
8. 如果 workspace 子目录不存在，先创建再写入
```

### 29 个 bootstrap 模板文件

每个 `src/bootstrap/*.md` 文件末尾追加 `\n\n<!-- WORKSPACE_RULES -->` 标记。

### AgentTeamPage.vue handleCreated

写入 BOOTSTRAP.md 时，先通过 `generateBootstrapWithWorkspaceRules()` 包装 bootstrap 内容再写入 Gateway。传入实际 workspace 路径。

## 3. 文件上传路径改造

### 后端（server/index.js）

`POST /api/workspace/upload-to-gateway` 路由改造：

1. 从 FormData 读取 `agentId` 字段
2. 调用 Gateway RPC `agents.get` 或从 config 查询 agent 的 workspace 路径
3. `expandHomePath()` 展开 `~`，拼接 `/uploads`
4. 构建自定义 `uploadConfig`，将 `GATEWAY_MEDIA_DIR` 设为该路径
5. 传给 `uploadToGateway()` 使用

`uploadToGateway()` 函数需支持传入自定义目标目录（覆盖 envConfig 中的 `GATEWAY_MEDIA_DIR`）。

### 前端（ChatInput.vue uploadFile）

`uploadFile()` 函数改造：

1. 从 `workspaceStore.selectedAgentId` 获取当前 agentId
2. FormData 中追加 `agentId` 字段

## 涉及文件

| 文件 | 改动 |
|------|------|
| `src/views/agent-team/AgentTeamPage.vue` | workspace 路径格式 + bootstrap 注入 |
| `src/stores/agent.ts` | 低级 agent workspace 路径 |
| `src/config/agent-templates.ts` | 新增 `generateBootstrapWithWorkspaceRules()` |
| `src/bootstrap/*.md` (29 files) | 追加 `<!-- WORKSPACE_RULES -->` 标记 |
| `server/index.js` | upload 路由支持 agentId |
| `server/gateway-file-transfer.js` | `uploadToGateway()` 支持自定义目录 |
| `src/views/workspace/ChatInput.vue` | FormData 附带 agentId |

## 技术约束

- `erasableSyntaxOnly: true`，用 `interface` 不用 `enum`
- 2 空格缩进、单引号、尾逗号、无分号、无注释
- `<script setup lang="ts">`，Composition API
- 验证：`npx vue-tsc --noEmit`

## 不做的事

- 不迁移旧 agent 的 workspace 路径
- 不修改 Gateway 源码
- 不改变 agent 的 workspace 运行时行为（隔离由路径本身保证）
