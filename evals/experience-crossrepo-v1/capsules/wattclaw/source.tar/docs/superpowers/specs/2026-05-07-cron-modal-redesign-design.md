# 定时任务配置弹窗重构设计

**日期：** 2026-05-07
**状态：** 设计完成，待实现
**范围：** 仅 CronPage.vue 中的创建/编辑弹窗（showModal）

---

## 背景

当前定时任务配置弹窗直接暴露 cron 表达式、AgentId 文本输入、sessionTarget/wakeMode/payloadKind 等技术字段，对非技术用户不友好。参考 EasyClaw 的设计，将配置弹窗改为可视化、用户友好的交互方式。

---

## 实现方案

**方案 A：就地改造** — 在现有 `CronPage.vue` 中直接改造弹窗 template 和相关逻辑，不拆分文件。

---

## 弹窗结构

```
┌─────────────────────────────────────────┐
│ 配置定时任务                        [X] │
├─────────────────────────────────────────┤
│ 任务名称 [______________]               │
│ 执行员工 [▼ 数字员工名称 ]              │
│ 描  述   [______________]               │
│ 启  用   [●/○]                          │
├─────────────────────────────────────────┤
│ 执行时间                                │
│ [每日] [每月] [间隔]                     │
│ (按选中 Tab 展示对应控件)                │
│ 中文预览: "每周一至周五 08:00 执行"      │
├─────────────────────────────────────────┤
│ AI 指令 (Prompt)        [▶ 测试指令]    │
│ ┌─────────────────────────────────────┐ │
│ │ 输入 AI 指令...                      │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ 任务结果与通知 [●开关]                   │
│ (开关开启时展示:)                        │
│ 接收应用 [▼ 选择渠道 ]                   │
│ 发 送 至 [▼ 选择目标 ]                   │
├─────────────────────────────────────────┤
│ ▶ 高级设置                               │
│   会话目标: [isolated/main]              │
│   唤醒模式: [next-heartbeat/now]         │
│   模型覆盖: [▼ 选择模型 ]               │
│   超时时间: [120] 秒                     │
│   思考模式: [输入框]                      │
│   运行后删除: [●/○]                      │
├─────────────────────────────────────────┤
│ [取消]                      [保存]       │
└─────────────────────────────────────────┘
```

---

## 详细设计

### 1. 调度配置（可视化替代 cron 表达式）

#### Tab 结构

用 `NTabs` 组件替代当前的 `NSelect`（cron/every/at）：

- **每日 Tab** — 对应 scheduleKind `cron`，按星期筛选
- **每月 Tab** — 对应 scheduleKind `cron`，按日期筛选
- **间隔 Tab** — 对应 scheduleKind `every`

`scheduleKind: 'at'`（一次性任务）移入高级设置。

#### 每日 Tab

- **时间选择器：** `NTimePicker`，格式 HH:mm，默认 08:00
- **星期按钮组：** 7 个可多选按钮（周一～周日），默认全选
  - 全选 → cron `*`（每天）
  - 选周一到周五 → cron `1-5`
  - 任意组合 → cron `1,3,5` 格式
- 映射示例：周一至周五 08:00 → `0 8 * * 1-5`

#### 每月 Tab

- **时间选择器：** 同上
- **日期选择：** 31 个可多选按钮（1～31），风格与每日的星期按钮一致
- 映射示例：每月 1 号和 15 号 08:00 → `0 8 1,15 * *`

#### 间隔 Tab

- **数值输入：** `NInputNumber`，min=1
- **单位下拉框：** 分钟/小时/天
- 映射到 `everyMs`：每 30 分钟 → `everyMs: 1800000`

#### 中文预览

在调度控件下方显示一句中文描述，如：
- "每周一至周五 08:00 执行"
- "每月 1 日、15 日 08:00 执行"
- "每 30 分钟执行一次"

复用现有的 `formatCronAsCn` 函数。

#### 反向解析（编辑模式）

打开编辑弹窗时，从 cron 表达式反向解析出：
1. Tab 类型（每日/每月/间隔）
2. 时间
3. 星期/日期选择

规则：
- `everyMs` 存在 → 间隔 Tab
- cron 的 dayOfMonth 为 `*`、dayOfWeek 不为 `*` → 每日 Tab
- cron 的 dayOfWeek 为 `*`、dayOfMonth 不为 `*` → 每月 Tab
- cron 全为 `*`（每天） → 每日 Tab，全选星期
- 无法解析 → 回退到高级设置中显示原始 cron 表达式

### 2. 执行员工下拉框

- **数据源：** 从 `agent_team` 表读取（API `/api/agent-team`）
- **引入方式：** 在 CronPage.vue 中引入 agent team 相关 store 或 API
- **显示：** 员工名称（agent_team.name）
- **值：** 映射到 form.agentId（agent_team.agent_id 或标识符）
- **默认选项：** "默认（不指定）"，对应 agentId 为空

### 3. AI 指令 + 测试按钮

- **布局：** label 行右侧放 "测试指令" 按钮（参考图片）
- **测试按钮行为：**
  1. 先保存当前表单状态到临时变量
  2. 调用 `cronStore.run()` 或等效方法触发一次性执行
  3. 按钮显示 loading 状态
  4. 成功后 toast 提示 "测试指令已发送"
- **输入框：** 保持 NInput textarea，autosize

### 4. 通知简化

- **开关：** 一个 `NSwitch` 控制 `form.deliveryMode`（on='announce', off='none'）
- **渠道选择：** `NSelect`，复用现有 `deliveryChannelOptions`，标签改为友好名称
- **发送目标：** `NSelect`，复用现有 `deliveryTargetOptions`，保留 filterable + tag
- **bestEffort：** 移入高级设置

### 5. 高级设置（折叠区）

使用 `NCollapse` 或自定义折叠区，默认折叠，包含：

| 字段 | 控件 | 默认值 |
|------|------|--------|
| 会话目标 (sessionTarget) | NSelect: 独立会话/主会话 | isolated |
| 唤醒模式 (wakeMode) | NSelect: 下次心跳/立即 | next-heartbeat |
| 模型覆盖 (model) | NSelect (filterable, tag, clearable) | 空（用默认） |
| 思考模式 (thinking) | NInput | 空 |
| 超时时间 (timeoutSeconds) | NInputNumber | 120 |
| 运行后删除 (deleteAfterRun) | NSwitch | false |
| 时区 (cronTz) | NInput | 空（服务器时区） |
| 一次性执行时间 (atTime) | datetime-local input | — |

### 6. 移除的内容

- **JSON 预览区：** 底部的 `<NCode :code="previewPayload">` 移除
- **直接 cron 输入：** 被 Tab 可视化控件替代
- **AgentId 文本框：** 被员工下拉框替代
- **底部的 footerHint：** 技术提示文案移除

---

## 数据流

### 可视化 → cron 映射

```typescript
// 每日 Tab → cron
function dailyToCron(hour: number, minute: number, weekdays: number[]): string {
  const dow = weekdays.length === 7 ? '*' : weekdays.sort().join(',')
  return `${minute} ${hour} * * ${dow}`
}

// 每月 Tab → cron
function monthlyToCron(hour: number, minute: number, days: number[]): string {
  const dom = days.sort().join(',')
  return `${minute} ${hour} ${dom} * *`
}

// 间隔 Tab → everyMs
function intervalToEveryMs(value: number, unit: 'minutes'|'hours'|'days'): number {
  const multiplier = unit === 'days' ? 86400000 : unit === 'hours' ? 3600000 : 60000
  return value * multiplier
}
```

### cron → 可视化 反向解析

```typescript
function parseCronToVisual(expr: string): {
  tab: 'daily' | 'monthly',
  hour: number,
  minute: number,
  weekdays?: number[],
  days?: number[],
} | null {
  // 解析 5 段 cron 表达式
  // 根据字段特征判断 daily/monthly
  // 提取时间、星期、日期信息
}
```

### buildSchedule() 修改

现有 `buildSchedule()` 函数需要适配新的可视化状态：
- 每日/每月 Tab → 构建 `kind: 'cron'` 的 schedule
- 间隔 Tab → 构建 `kind: 'every'` 的 schedule
- 一次性执行 → 从高级设置中读取，构建 `kind: 'at'` 的 schedule

---

## 表单状态扩展

在 `form` reactive 对象中新增字段：

```typescript
// 调度可视化状态
scheduleTab: 'daily' as 'daily' | 'monthly' | 'interval',
scheduleHour: 8,
scheduleMinute: 0,
scheduleWeekdays: [1, 2, 3, 4, 5] as number[],  // 周一到周五
scheduleMonthDays: [1] as number[],               // 每月1号

// 通知开关
notifyEnabled: true,

// 高级设置折叠
showAdvanced: false,
```

---

## 不变的部分

- 任务列表表格（NDataTable）
- 运行历史表格
- 任务详情弹窗（showDetailModal）
- 运行详情弹窗（showRunDetailModal）
- cron store（`src/stores/cron.ts`）
- 后端路由和 Gateway 代理逻辑
- i18n key 结构（只新增/修改弹窗相关的 key）

---

## 实现步骤

1. **引入 agent team 数据** — 在 CronPage.vue 中引入 agent team store 或 API 调用
2. **扩展 form 状态** — 添加 scheduleTab、scheduleHour、scheduleMinute 等可视化字段
3. **改造弹窗 template** — 替换 NForm+NDivider 为分区式布局
4. **实现调度可视化** — NTabs + NTimePicker + 星期按钮组 + 日期选择
5. **实现反向解析** — 编辑模式从 cron 表达式回填可视化控件
6. **改造通知配置** — NSwitch + 简化下拉框
7. **实现测试指令按钮** — 复用 run 逻辑
8. **添加高级设置折叠区** — NCollapse 包裹技术字段
9. **移除 JSON 预览** — 删除 previewPayload 相关代码
10. **更新 i18n** — 新增/修改弹窗相关的翻译 key
11. **验证** — 创建/编辑/测试指令全流程验证
