# Session Title Localization Design

Date: 2026-05-07

## Problem Statement

在线对话左侧栏会话列表存在三个问题：

1. **重复标题导致 UUID 显示** — 两个会话首条消息相同时，第二个 `patchSession({ label })` 因 Gateway 全局唯一约束失败，本地 label 保留但刷新后丢失，显示为 UUID
2. **刷新后标题带后缀** — 历史遗留的 `-suffix` 标题在刷新后仍然显示
3. **不必要的会话列表刷新** — 每次 agent 回复完成后 `forceStopStreaming()` 调用 `loadAgentSessions()`，整个列表重新拉取替换

**根因：** 显示标题依赖 Gateway label（有全局唯一约束），而非本地存储。

## Solution Overview

**核心思路：显示标题与 Gateway label 彻底解耦。**

```
显示标题 → user_sessions.label（SQLite，无唯一约束，可重复）
Gateway label → title + timestamp（保证唯一，仅用于 Gateway 内部标识）
会话列表 → 从 Gateway 缓存获取，但 label 字段由 user_sessions 覆盖
```

## Data Model

### user_sessions 表（已有，无 schema 变更）

```sql
user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  session_key TEXT NOT NULL,
  agent_id TEXT,
  label TEXT,           -- 现在作为「显示标题」，而非 Gateway label 的副本
  channel TEXT,
  created_at INTEGER,
  updated_at INTEGER
)
```

不需要新增表或字段。`label` 的语义从「Gateway label 同步」变为「本地显示标题」。

### trackSessionForUser 修改

```javascript
// 之前：总是覆盖
UPDATE user_sessions SET updated_at = ?, agent_id = ?, label = ? WHERE id = ?

// 之后：保留已有标题（COALESCE）
UPDATE user_sessions SET updated_at = ?, agent_id = ?, label = COALESCE(label, ?) WHERE id = ?
```

- WattClaw 设了标题 → 保留，不被 sync 覆盖
- 外部渠道首次同步 → Gateway label 作为 fallback 写入
- 后续 sync → 本地标题已存在，不再覆盖

## Backend Changes

### 1. /api/workspace/send 增加 title 参数

请求体新增 `title` 字段（可选）：

```javascript
// server/index.js — /api/workspace/send handler
const { sessionKey, message, idempotencyKey, title } = req.body

// 发送消息到 Gateway（不变）
await gateway.call('chat.send', { sessionKey, message, idempotencyKey })

// 保存显示标题到本地数据库
if (title && sessionKey) {
  // agentId 从 session key 解析：格式 "agent:agent-xxx:yyy" → "agent-xxx"
  const parts = sessionKey.split(':')
  const agentId = parts.length >= 2 ? parts[1] : null
  trackSessionForUser(req.userId, sessionKey, agentId, title, null)
}

// 设置 Gateway label（fire-and-forget，title + timestamp 保证唯一）
if (title && sessionKey) {
  const gatewayLabel = `${title}-${Date.now()}`
  gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
}
```

### 2. /api/rpc sessions.list 返回时合并本地标题

```javascript
// 非 admin sessions.list
const allSessions = await getCachedAllSessions()
const ownedSessions = filterOwnedSessions(allSessions)

// 合并本地显示标题
const localTitles = getLocalSessionTitles(userId)  // 新增函数
const sessionsWithTitles = ownedSessions.map(s => ({
  ...s,
  label: localTitles.get(s.key || s.sessionKey) || s.label || ''
}))

return res.json({
  ok: true,
  payload: {
    sessions: sessionsWithTitles,
    total: sessionsWithTitles.length,
    page: 1,
    limit: sessionsWithTitles.length,
    hasMore: false
  }
})
```

`getLocalSessionTitles(userId)` 实现：

```javascript
function getLocalSessionTitles(userId) {
  const rows = db.prepare('SELECT session_key, label FROM user_sessions WHERE user_id = ? AND label IS NOT NULL').all(userId)
  return new Map(rows.map(r => [r.session_key, r.label]))
}
```

Admin 路径同理，合并本地标题但不做 filterOwnedSessions：

```javascript
// admin sessions.list
const allSessions = await getCachedAllSessions()

// admin 查看全部用户的标题
const allTitles = getAllSessionTitles()  // 新增函数，不按 user 过滤
const sessionsWithTitles = allSessions.map(s => ({
  ...s,
  label: allTitles.get(s.key || s.sessionKey) || s.label || ''
}))

return res.json({
  ok: true,
  payload: {
    sessions: sessionsWithTitles,
    total: sessionsWithTitles.length,
    page: 1,
    limit: sessionsWithTitles.length,
    hasMore: false
  }
})
```

`getAllSessionTitles()` 实现：

```javascript
function getAllSessionTitles() {
  const rows = db.prepare('SELECT session_key, label FROM user_sessions WHERE label IS NOT NULL').all()
  return new Map(rows.map(r => [r.session_key, r.label]))
}
```

### 3. trackSessionForUser 使用 COALESCE

```javascript
export function trackSessionForUser(userId, sessionKey, agentId, label, channel) {
  const existing = db.prepare('SELECT id FROM user_sessions WHERE user_id = ? AND session_key = ?').get(userId, sessionKey)
  if (existing) {
    db.prepare('UPDATE user_sessions SET updated_at = ?, agent_id = ?, label = COALESCE(label, ?) WHERE id = ?')
      .run(Date.now(), agentId || null, label || null, existing.id)
    return db.prepare('SELECT * FROM user_sessions WHERE id = ?').get(existing.id)
  }
  // INSERT 不变（id 存变量，避免未定义引用）
  const id = crypto.randomUUID()
  db.prepare(`INSERT INTO user_sessions (id, user_id, session_key, agent_id, label, channel)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(id, userId, sessionKey, agentId || null, label || null, channel || null)
  return db.prepare('SELECT * FROM user_sessions WHERE id = ?').get(id)
}
```

## Frontend Changes

### 1. workspace.ts — sendMessage

```typescript
// 标题生成 — 用局部变量传递给 send body
let titleToSend: string | undefined
if (activeSessionKey.value && !titleGeneratedKeys.has(activeSessionKey.value)) {
  titleGeneratedKeys.add(activeSessionKey.value)
  const title = text.length > 32 ? text.slice(0, 32) + '...' : text
  titleToSend = title

  // 本地状态立即更新（不变）
  const agent = agents.value.find(a => a.agentId === selectedAgentId.value)
  if (agent) {
    agent.sessions = agent.sessions.map(s =>
      s.key === activeSessionKey.value ? { ...s, label: title } : s
    )
  }

  // 不再直接调 patchSession(label)
  // 标题通过 /api/workspace/send 的 title 参数传给后端
}
```

`/api/workspace/send` 调用时增加 `title` 参数：

```typescript
// titleToSend 只在首条消息时有值
const body: Record<string, string> = {
  sessionKey: activeSessionKey.value!,
  message: text,
  idempotencyKey,
  ...(titleToSend ? { title: titleToSend } : {})
}
```

### 2. workspace.ts — forceStopStreaming

```typescript
function forceStopStreaming() {
  // ... 停止流式状态的逻辑不变 ...

  // 删除以下两行：
  // invalidateSessionCache()
  // loadAgentSessions(selectedAgentId.value)
}
```

agent 完成回复后不再刷新会话列表。

### 3. workspace.ts — loadAgentSessions 清理

删除 `localLabels` Map 合并逻辑：

```typescript
// 删除：
// const localLabels = new Map(agent.sessions.map((s) => [s.key, s.label]))
// agent.sessions = newSessions.map((s) => {
//   if (!s.label && localLabels.get(s.key)) {
//     return { ...s, label: localLabels.get(s.key) }
//   }
//   return s
// })

// 简化为直接赋值（后端已合并好标题）：
agent.sessions = newSessions
```

### 4. workspace.ts — renameSession 改走本地 DB

当前 `renameSession` 直接调 `patchSession({ label })`，受 Gateway 唯一约束影响。改为：

```typescript
async function renameSession(sessionKey: string, label: string) {
  try {
    // 更新本地 DB（通过后端 API）
    await httpPost('/api/workspace/rename-session', { sessionKey, label })

    // Gateway label 用 label + timestamp 保证唯一（fire-and-forget）
    const gatewayLabel = `${label}-${Date.now()}`
    wsStore.rpc.patchSession({ sessionKey, label: gatewayLabel }).catch(() => {})

    // 本地状态立即更新
    for (const agent of agents.value) {
      agent.sessions = agent.sessions.map(s =>
        s.key === sessionKey ? { ...s, label } : s
      )
    }
  } catch (error) {
    lastError.value = error instanceof Error ? error.message : String(error)
  }
}
```

后端新增 `/api/workspace/rename-session`：

```javascript
app.post('/api/workspace/rename-session', authMiddleware, async (req, res) => {
  const { sessionKey, label } = req.body
  if (!sessionKey || !label) return res.status(400).json({ ok: false, error: 'Missing params' })

  const row = db.prepare('SELECT id, user_id FROM user_sessions WHERE session_key = ?').get(sessionKey)
  if (!row || (row.user_id !== req.userId && !req.isAdmin)) {
    return res.status(403).json({ ok: false, error: 'Access denied' })
  }

  db.prepare('UPDATE user_sessions SET label = ? WHERE session_key = ?').run(label, sessionKey)
  res.json({ ok: true })
})
```

注意：重命名时用 `UPDATE SET label = ?`（直接赋值，不用 COALESCE），因为用户明确想改标题。

## Data Migration

**一次性同步：** 服务启动连接 Gateway 时，`syncSessionsFromGateway()` 已有逻辑同步全量 sessions。

需确保：
1. `syncSessionsFromGateway` 对每个 session 调用 `trackSessionForUser`（已有）
2. `trackSessionForUser` 对新行 INSERT 时写入 Gateway label（已有）
3. 对已有行 UPDATE 时用 COALESCE 不覆盖（新增）

**历史数据：** 已有的丑标题（如 `你好-mov5ldpg`）保持不变，不做清理。新会话不再产生此类问题。

## What Gets Removed

| 代码 | 位置 | 原因 |
|------|------|------|
| `localLabels` Map 合并逻辑 | workspace.ts loadAgentSessions | 后端已合并标题 |
| `patchSession({ label })` 前端调用 | workspace.ts sendMessage | 标题由后端写入 |
| `loadAgentSessions()` in forceStopStreaming | workspace.ts forceStopStreaming | 不需要刷新列表 |
| `invalidateSessionCache()` in forceStopStreaming | workspace.ts forceStopStreaming | 不需要刷新缓存 |
| `renameSession` 中直接调 patchSession | workspace.ts renameSession | 改走本地 DB + 后端 API |

`titleGeneratedKeys` Set 保留 — 前端仍需追踪哪些 session 已设过标题，避免重复传 title 参数。

## Verification

1. 新建两个会话，首条消息都是「你好」→ 两个都显示「你好」，无 UUID
2. 刷新页面 → 标题仍显示「你好」，无后缀
3. agent 回复完成 → 会话列表不闪烁不刷新
4. 外部渠道（飞书）会话 → 标题正常显示 Gateway label
5. 切换 agent → 会话列表正常加载（标题来自本地数据库）
6. 重命名会话 → 标题立即更新，刷新后保持新名称
7. 重命名为已有标题 → 不报错，两个会话显示相同标题
