# Session Sharing Design

**Date:** 2026-05-08
**Status:** Approved

---

## Overview

Add session sharing functionality to WattClaw, allowing users to select chat messages and generate a public static HTML page that can be shared via link. Inspired by Doubao's (豆包) sharing flow.

---

## User Flow

1. User clicks share button (forward icon) in `ChatHeader.vue`
2. `ShareModal` opens showing all messages in current session with checkboxes
3. User selects messages (or clicks "全选" for all)
4. User clicks "生成链接"
5. Frontend POSTs selected message data to `POST /api/share`
6. Backend generates self-contained HTML file, saves to `data/shared/{id}.html`
7. Backend returns share URL `/shared/{id}.html`
8. Modal displays link with "复制链接" button
9. Anyone with the link can view the shared page (no auth required)

---

## Architecture

### Components

#### Frontend

| Component | File | Purpose |
|-----------|------|---------|
| ShareButton | `ChatHeader.vue` | Share icon button in chat header |
| ShareModal | `src/views/workspace/components/ShareModal.vue` | Message selection + link generation |

#### Backend

| Component | File | Purpose |
|-----------|------|---------|
| Share API | `server/index.js` | `POST /api/share` endpoint |
| Static serving | `server/index.js` | `app.use('/shared', express.static('data/shared'))` |
| HTML generator | `server/share-generator.js` | Generates self-contained HTML from messages |

### Dependencies

- `marked` — markdown to HTML rendering
- `nanoid` — short unique ID generation

---

## Detailed Design

### 1. Share Button (ChatHeader.vue)

Add a share/forward icon button next to the existing header actions (file panel toggle, etc.). Only visible when there are messages in the current session.

```html
<n-button quaternary circle @click="openShareModal">
  <template #icon><ShareIcon /></template>
</n-button>
```

### 2. ShareModal Component

**Props:**
- `visible: boolean` — modal visibility
- `messages: ChatMessage[]` — current session messages
- `sessionLabel: string` — session title

**State:**
- `selectedIndices: Set<number>` — selected message indices
- `shareUrl: string | null` — generated share URL
- `loading: boolean` — generating state

**Layout:**
- Header: "分享会话" + close button
- Body: scrollable message list with checkboxes
  - User messages: right-aligned blue bubbles, full content
  - Assistant messages: left-aligned gray bubbles, full content
  - Each message has a checkbox on the left
- Footer:
  - Left: "全选" / "取消全选" toggle
  - Right: selected count + "生成链接" button
- After generation: show URL + "复制链接" button

**Events:**
- `@close` — close modal
- `@share` — emit selected indices

### 3. Share API (POST /api/share)

**Request:**
```json
{
  "sessionKey": "agent:main:webchat-1234:dm:user-abc",
  "messageIndices": [0, 1, 2, 3],
  "title": "可选的自定义标题"
}
```

**Response:**
```json
{
  "url": "/shared/abc123.html",
  "id": "abc123"
}
```

**Logic:**
1. Validate JWT token (user must be logged in to share)
2. Validate user owns the session (`isSessionOwned`)
3. Fetch session transcript from Gateway via `chat.history`
4. Filter messages by `messageIndices`
5. Generate HTML via `share-generator.js`
6. Save to `data/shared/{id}.html`
7. Return share URL

### 4. HTML Generator (server/share-generator.js)

Generates a self-contained HTML file with:

**Structure:**
```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{sessionLabel} - WattClaw</title>
  <style>/* embedded CSS */</style>
</head>
<body>
  <div class="container">
    <header>
      <h1>{sessionLabel}</h1>
      <div class="meta">{date} • 内容由 AI 生成，仅供参考</div>
    </header>
    <div class="messages">
      <!-- rendered messages -->
    </div>
    <footer>由 WattClaw 生成</footer>
  </div>
</body>
</html>
```

**CSS (embedded):**
- Max-width 900px centered layout
- Light background, rounded cards
- User messages: right-aligned, blue bubble (#E3F2FD)
- Assistant messages: left-aligned, gray bubble (#F5F5F5)
- Markdown styles: headings, lists, code blocks, tables, links
- File attachment cards with icon
- Dark mode via `@media (prefers-color-scheme: dark)`
- Responsive design

**Markdown rendering:**
- Use `marked` library to render message content
- Sanitize HTML output for security
- Support: headers, bold, italic, lists, code blocks (with syntax highlighting via inline styles), tables, links, images

**File attachments:**
- Display as small cards with file icon + filename
- Below the message content

### 5. Static File Serving

In `server/index.js`, add static file serving for the shared directory:

```js
const sharedDir = path.join(__dirname, '..', 'data', 'shared')
fs.mkdirSync(sharedDir, { recursive: true })
app.use('/shared', express.static(sharedDir))
```

---

## File Changes

| File | Change |
|------|--------|
| `src/views/workspace/ChatHeader.vue` | Add share button |
| `src/views/workspace/components/ShareModal.vue` | New component |
| `src/stores/workspace.ts` | Add `shareSession()` method |
| `src/api/http-client.ts` | Add `shareSession()` API call |
| `src/i18n/messages/zh-CN.ts` | Add share-related i18n keys |
| `src/i18n/messages/en-US.ts` | Add share-related i18n keys |
| `server/index.js` | Add `POST /api/share` endpoint + static serving |
| `server/share-generator.js` | New file: HTML generation logic |
| `package.json` | Add `marked` and `nanoid` dependencies |

---

## Security Considerations

1. **Auth required to share:** Only logged-in users can generate share links
2. **Session ownership:** Users can only share sessions they own
3. **No auth to view:** Shared pages are public (by design)
4. **HTML sanitization:** Use `marked` with sanitization to prevent XSS in shared content
5. **No sensitive data:** Shared HTML contains only message text, no API keys or tokens
6. **File naming:** Use nanoid (collision-resistant) for file names

---

## Edge Cases

1. **Empty selection:** Disable "生成链接" button when no messages selected
2. **Long messages:** No truncation, render full content
3. **Special characters:** Proper HTML escaping in generated content
4. **File size:** For very long conversations, HTML file could be large — acceptable for v1
5. **Concurrent shares:** nanoid ensures unique filenames
6. **Server restart:** Shared files persist in `data/shared/` (gitignored)

---

## Future Enhancements (Out of Scope for v1)

- Share link expiration (auto-delete after N days)
- Share link management page (list/delete shares)
- Password-protected shares
- Share to social media (WeChat, etc.)
- View count tracking
