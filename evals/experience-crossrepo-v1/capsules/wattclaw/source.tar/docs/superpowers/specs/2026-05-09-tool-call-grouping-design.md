# 工具调用分组折叠设计

**日期：** 2026-05-09
**状态：** 已确认

## 背景

当前在线对话中，每个工具调用（activity type='tool'）渲染为独立的卡片。当 agent 连续调用多个工具时，聊天界面被大量工具卡片刷屏，用户体验差。

## 目标

将连续的工具调用分组到一个可折叠容器中，减少视觉噪音。assistant 消息作为分隔线，将工具调用拆分为不同组。

## 方案：computed 分组 + 折叠容器组件

在 `unifiedTimeline` 和模板之间增加分组层，不改变现有数据结构和交织算法。

### 数据结构

```typescript
interface ToolGroupEntry {
  _key: string            // 'tg-' + 首个工具/消息 id
  type: 'tool-group'
  tools: AgentActivity[] | ProcessedMessage[]  // 连续的 tool 条目
  isActive: boolean       // 任一工具未完成即为 true（仅 activity 有效）
}
```

### 分组算法 — groupedTimeline computed

遍历 `displayedItems`，将连续的 tool 条目合并为一个 `ToolGroupEntry`：

- **流式活动：** 连续的 `type === 'activity' && act.type === 'tool'` 合并
- **历史消息：** 连续的 `type === 'message' && msg.role === 'tool'` 合并
- **分隔条件：** 遇到非 tool 条目（message、thinking、command_output）时 flush 当前组
- **单工具也包装成组** — 保持视觉一致性

示例：
```
input:  [user_msg, tool1, tool2, tool3, assistant_msg, thinking, tool4, tool5, assistant_msg]
output: [user_msg, ToolGroup(3), assistant_msg, thinking, ToolGroup(2), assistant_msg]
```

### 流式兼容

`groupedTimeline` 是 computed 属性，每次 `currentActivities` 变化时自动重算。

流式过程中工具逐个到达，分组自然增长：
```
时刻1: 第1个工具 → [工具调用 (1)]
时刻2: 第2个工具 → [工具调用 (2)]
时刻3: 第3个工具 → [工具调用 (3) ...运行中]
时刻4: assistant → 分组完成，显示消息
时刻5: 新工具 → 新的 [工具调用 (1)]
```

用户从头到尾看到的是分组容器，不会出现独立卡片再变分组的闪烁。

### 新组件 — ToolGroupCard.vue

**Props：**
- `tools: AgentActivity[] | ProcessedMessage[]` — 工具列表
- `isActive: boolean` — 是否有工具还在运行

**内部状态：**
- `expanded: ref(false)` — 默认折叠
- `watch(isActive)` 从 true→false 时自动折叠

**渲染结构：**

折叠状态 — 只显示 header：
```
▶ 🔧 工具调用  [5]     全部已完成 ✓
```

展开状态 — header + 工具列表：
```
▼ 🔧 工具调用  [5]     全部已完成 ✓
─────────────────────────────────
  🔧 ssh_exec              ✓
  🔧 docker_ps             ✓
  🔧 docker_logs           ✓
  🔧 docker_inspect        ✓
  🔧 systemctl_status      ✓
```

每个工具项可点击展开查看参数/结果（复用 `expandedActivities` Set）。

### 交互细节

| 场景 | 行为 |
|------|------|
| 默认状态 | 折叠，只显示 header |
| 点击 header | 切换展开/折叠 |
| 运行中 | header 显示脉冲点 + "运行中..."，工具项旁脉冲点/✓ |
| 全部完成 | 自动折叠 |
| 单工具 | 也用分组容器，显示 "工具调用 [1]" |

### 不受影响的部分

- `ThinkingBlock` — 保持独立渲染，不参与分组
- `command_output` — 保持独立渲染，不参与分组
- 分享功能（ShareModal） — 从 store.messages 取数据，不涉及 activity
- `unifiedTimeline` — 交织算法不变，`_msgCount` 逻辑不变
- store 数据结构 — `currentActivities`、`AgentActivity` 不变

### 涉及文件

| 文件 | 改动 |
|------|------|
| `src/views/workspace/components/ToolGroupCard.vue` | 新建 — 折叠容器组件 |
| `src/views/workspace/MessageList.vue` | 改造 — 新增 `groupedTimeline` computed，模板增加 `tool-group` 分支 |
