# 未读消息通知功能设计

## 需求概述

在在线对话中，当数字员工回复消息后，需要实现以下通知机制：

1. **侧边栏红点**：用户在其他页面时，侧边栏"在线对话"菜单项显示红点，进入工作台后消失
2. **会话置顶**：收到新消息的会话在该数字员工的会话列表中置顶（包括正在查看的会话）
3. **数字员工置顶**：对应的数字员工在员工列表中也置顶
4. **未读红点**：切换到其他会话后，原数字员工的新消息在会话和员工条目上显示红点

### 范围与约束

- 仅针对当前用户在在线对话中自己发起的会话，不包括飞书/钉钉等外部渠道
- 置顶行为：每次收到新消息都重新置顶（包括正在查看的会话）
- 红点消失采用两级机制：侧边栏红点进入工作台即消失，会话红点需点击具体会话才消失
- 不持久化：刷新页面后未读状态不保留（可后续迭代）

## 技术方案：双层 Map + 全局通知监听

### 核心思路

"置顶"和"红点"是两个独立关注点：
- **置顶**：所有会话的新消息都更新排序时间戳（包括正在查看的会话）
- **红点**：只有非活跃会话才标记为未读

### 架构问题：事件监听的全局性

**现状**：`WorkspacePage.vue` 在 `onMounted` 中订阅 WebSocket 事件，在 `onUnmounted` 中取消订阅。用户离开工作台页面后，store 收不到任何事件。

**影响**：如果只在 WorkspacePage 内处理通知，用户在其他页面时无法感知新消息。

**解决方案**：将通知监听提升到 `DefaultLayout.vue`（全局布局组件，所有页面都挂载）。WorkspacePage 的消息处理订阅保持不变，通知逻辑完全解耦。

### 数据层

在 `workspace.ts` store 中新增以下响应式状态：

```typescript
// 排序用：所有会话的最新活动时间戳（lifecycle end 时写入，不区分是否活跃会话）
activityTimestamps: ref<Map<string, number>>

// 红点用：仅非活跃会话的未读消息计数
unreadMap: ref<Map<string, number>>

// 侧边栏红点用：需要在侧边栏菜单显示红点的会话集合
sidebarNotified: ref<Set<string>>
```

### 全局通知监听（DefaultLayout.vue）

在 `DefaultLayout.vue` 中新增一个独立的 WebSocket 事件订阅，只处理 lifecycle end 事件：

```typescript
// DefaultLayout.vue
onMounted(() => {
  wsStore.connect()

  // 全局通知监听：不依赖 WorkspacePage 的生命周期
  notificationCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as { event: string; payload: unknown }
    const payload = rpcEvent.payload as Record<string, unknown>
    if (isLifecycleEndEvent(rpcEvent.event, payload)) {
      const sessionKey = extractSessionKey(payload)
      workspaceStore.handleNotification(sessionKey)
    }
  })
})

onUnmounted(() => {
  wsStore.disconnect()
  notificationCleanup?.()
})
```

`isLifecycleEndEvent` 判断逻辑：
- 事件包含 `agent` 类型，payload 中 `stream === 'lifecycle'` 且 `data.phase` 为 `end`/`stop`/`completed`/`error`
- 或事件为 `agent.done`

`extractSessionKey` 复用 `useEventStream.ts` 中已有的同名函数，可提取为共享工具函数。

### handleNotification 实现

```typescript
function handleNotification(sessionKey: string) {
  if (!sessionKey) return

  const isWorkspaceRoute = router.currentRoute.value.name === 'Workspace'
  const isActiveSession = sessionKey === activeSessionKey.value

  // 1. 置顶：所有消息都更新活动时间戳（包括活跃会话）
  activityTimestamps.value = new Map(activityTimestamps.value).set(sessionKey, Date.now())

  // 2. 红点：仅非活跃会话 或 用户不在工作台页面 时标记未读
  if (!isActiveSession || !isWorkspaceRoute) {
    const prev = unreadMap.value.get(sessionKey) || 0
    unreadMap.value = new Map(unreadMap.value).set(sessionKey, prev + 1)
    sidebarNotified.value = new Set(sidebarNotified.value).add(sessionKey)
  }
}
```

注意 Map 和 Set 的响应式触发：每次写入必须创建新引用（`new Map().set()` / `new Set().add()`），否则 Vue 不检测变更。参见 memory 中 "Map ref 触发变更模式"。

### 不修改 handleEvent

WorkspacePage 中的 `handleEvent` 保持原有逻辑不变，不需要添加前置拦截。通知逻辑完全由全局监听处理，消息处理逻辑由 WorkspacePage 订阅处理。两条路径互不干扰。

### 清除规则

#### 会话级清除（点击会话时）

在 `selectSession(key)` 中追加：

```typescript
const newUnread = new Map(unreadMap.value)
newUnread.delete(key)
unreadMap.value = newUnread
```

#### 侧边栏级清除（进入工作台时）

监听路由变化，当路由切换到 `Workspace` 时清除：

```typescript
// workspace.ts 中
watch(() => router.currentRoute.value.name, (name) => {
  if (name === 'Workspace') {
    sidebarNotified.value = new Set()
  }
})
```

不使用 `onMounted`，因为 WorkspacePage 可能已经挂载（keep-alive 或从子路由返回），`onMounted` 不会重新触发。

### 暴露给 UI 的接口

```typescript
// 侧边栏菜单是否有红点
const hasSidebarNotification = computed(() => sidebarNotified.value.size > 0)

// 某个会话是否有未读消息
function isSessionUnread(sessionKey: string): boolean {
  return unreadMap.value.has(sessionKey)
}

// 某个 agent 是否有未读会话
function hasAgentUnread(agentId: string): boolean {
  for (const [key] of unreadMap.value) {
    if (key.startsWith(`agent:${agentId}:`)) return true
  }
  return false
}

// 获取会话的活动时间戳（用于排序）
function getSessionActivityTs(sessionKey: string): number {
  return activityTimestamps.value.get(sessionKey) || 0
}
```

### 排序逻辑

#### 会话排序

在 `WorkspaceSidebar.vue` 中，每个 agent 的 sessions 用 computed 排序：

```
排序规则：
1. 有 activityTimestamp 的会话按 timestamp 降序
2. 无 activityTimestamp 的会话按原有 lastActivity 降序
```

#### 数字员工排序

在 `WorkspaceSidebar.vue` 中新增 `sortedAgents` computed：

```
排序规则：
1. 有未读会话的 agent 排前面（按该 agent 下最新 activityTimestamp 降序）
2. 无未读会话的 agent 按原顺序
```

不修改 store 的 `filteredAgents`，只在 UI 层用 computed 计算排序。

### UI 渲染

#### 侧边栏菜单红点（AppSidebar.vue）

- 读取 `workspaceStore.hasSidebarNotification`
- 在"在线对话"菜单项（路由名 `Workspace`，图标 `RocketOutline`）右上角渲染红色小圆点
- 8px 圆形，`position: absolute` 定位在图标右上角
- NMenu 的菜单项通过 `renderIcon` 渲染图标，需要在 icon 渲染函数中包裹红点标记

#### 会话红点（WorkspaceSidebar.vue）

- 每个会话条目渲染时调用 `workspaceStore.isSessionUnread(session.key)`
- 有未读时在会话标题右侧显示红色小圆点

#### 数字员工红点（WorkspaceSidebar.vue）

- 每个 agent 条目渲染时调用 `workspaceStore.hasAgentUnread(agent.agentId)`
- 有未读时在 agent 名称右侧显示红色小圆点

## 涉及文件

| 文件 | 修改内容 |
|------|---------|
| `src/stores/workspace.ts` | 新增 activityTimestamps/unreadMap/sidebarNotified、handleNotification、路由 watch、暴露 computed 接口 |
| `src/layouts/DefaultLayout.vue` | 新增全局通知事件订阅 |
| `src/composables/useEventStream.ts` | 提取 extractSessionKey 为共享导出 |
| `src/components/layout/AppSidebar.vue` | "在线对话"菜单项红点渲染 |
| `src/views/workspace/components/WorkspaceSidebar.vue` | 会话/员工红点 + sortedAgents computed |
| `src/views/workspace/WorkspacePage.vue` | selectSession 中清除 unreadMap |

## 关键设计决策

1. **全局监听 vs 页面内监听**：通知监听放在 DefaultLayout（全局），不受 WorkspacePage 生命周期影响
2. **双层 Map 而非单层**：activityTimestamps 驱动排序（所有会话），unreadMap 驱动红点（仅非活跃会话），避免逻辑耦合
3. **不修改 handleEvent**：通知和消息处理完全解耦，两条路径互不干扰，降低回归风险
4. **路由 watch 清除 sidebarNotified**：不依赖 onMounted，兼容 keep-alive 场景
5. **computed 派生排序**：不修改 store 原始 agents/sessions 数组，只在 UI 层计算排序
6. **Vue Map/Set 响应式**：每次写入创建新引用触发追踪

## 不在范围内

- 外部渠道（飞书/钉钉）消息通知
- 未读消息数数字显示（只做红点，不显示数字）
- 消息推送（浏览器通知）
- 持久化（刷新页面后未读状态不保留）
