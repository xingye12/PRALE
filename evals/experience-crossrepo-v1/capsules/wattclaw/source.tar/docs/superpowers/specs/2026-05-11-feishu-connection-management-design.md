# 数字员工"连接"功能优化设计

> 日期：2026-05-11
> 状态：待实现

## 背景

数字员工编辑页的"连接"tab 用于接入飞书渠道，但存在三个问题：

1. **按钮文字不明确**："添加配置" 用户不理解是做什么
2. **删除 agent 后 Gateway config 残留**：飞书 channel account 和 binding 未被清理，飞书仍能正常聊天
3. **已接入状态无感知**：绑定了飞书的 agent，进入"连接"tab 看不出已接入，也没有解绑功能

## 改动范围

### 1. 按钮文字调整

**前端 `AgentEditPage.vue`：**

| 位置 | 原文字 | 新文字 |
|------|--------|--------|
| 飞书卡片 header 按钮 | "添加配置" | "接入飞书"（未绑定时） |
| 飞书卡片 header 按钮 | — | "解除连接"（已绑定时） |

仅文字变更，无逻辑改动。

### 2. 已接入状态展示

**前端 `AgentEditPage.vue`：**

- 新增 `feishuChannel` ref（类型：Channel | null）
- 页面加载时（或切到连接 tab 时）调 `GET /api/user/channels`，过滤 `agent_id === agentId` 且 `channel_type === 'feishu'` 的记录
- 连接 tab 模板增加条件渲染：

**未接入状态（feishuChannel === null）：**
- 保持现有飞书卡片 UI
- 按钮文字改为"接入飞书"
- 点击打开飞书绑定弹窗（现有逻辑不变）

**已接入状态（feishuChannel !== null）：**
- 飞书卡片变为"已接入"样式：
  - 卡片标题旁显示绿色"已接入"标签（NTag type="success"）
  - 卡片内容显示渠道名称 + 绑定时间（`created_at` 格式化）
  - header 按钮变为"解除连接"（NButton type="error" dashed）
- 点击"解除连接"弹出确认对话框："确定要解除飞书连接吗？解除后飞书消息将不再触发回复。"
- 确认后调 `DELETE /api/user/channels/:id`（后端会先调 `channels.logout` 再清理）
- 成功后设 `feishuChannel = null`，UI 切回未接入状态

### 3. 解绑实现：使用 `channels.logout` RPC

**核心变更：解绑使用 OpenClaw Gateway 的 `channels.logout` RPC 方法。**

OpenClaw Gateway 提供 `channels.logout` 方法（v2026.4.21 确认），参数：

```json
{
  "channel": "feishu",
  "accountId": "agent-xxx"
}
```

该方法会：
1. 调 `context.stopChannel(channelId, accountId)` 停止运行中的飞书 WebSocket 连接
2. 调飞书插件的 `logoutAccount()` 清除凭证（如 token）
3. 标记该 account 为 logged out

**后端改动 `server/index.js`：**

修改 `DELETE /api/user/channels/:id` 端点，在 `removeChannelFromGateway` 之前增加 `channels.logout` 调用：

```
原流程：removeChannelFromGateway(channel) → deleteUserChannel(id)
新流程：channels.logout → removeChannelFromGateway(channel) → deleteUserChannel(id)
```

新增辅助函数 `logoutChannelFromGateway(channel)`：
```javascript
async function logoutChannelFromGateway(channel) {
  if (!gateway.isConnected) return
  try {
    await gateway.call('channels.logout', {
      channel: channel.channel_type,  // 'feishu'
      accountId: channel.agent_id,
    })
  } catch (err) {
    console.error('[ChannelSync] logout failed:', err.message)
    // logout 失败不阻塞，继续清理 config
  }
}
```

同样，`DELETE /api/agent-team/:id` 级联删除时，也先 logout 再 remove。

### 4. 删除可靠性增强（A）

**后端 `server/index.js` `DELETE /api/agent-team/:id`：**

现状：`removeChannelFromGateway` 的 catch 只 console.error，不抛异常。如果 Gateway 断连或 config.patch 失败，channel 残留但不阻塞 agent 删除。

增强：
- 每个 channel 清理前先调 `logoutChannelFromGateway(channel)` 断开运行时连接
- `removeChannelFromGateway` 失败时记录详细日志（含 channel.id、agentId、错误信息），但继续删除流程不阻塞
- 删除 agent 后（`removeAgentForUser` 之后），增加一步 Gateway config 残留检查：
  1. 调 `config.get` 获取当前 config
  2. 遍历 `channels.feishu.accounts`，检查是否有 key 等于该 agentId 的 entry
  3. 检查 `bindings` 数组中是否有匹配的 binding
  4. 如有残留，执行清理（删除 account + 过滤 binding + patch + apply）
- 此检查只在 agent 删除后执行一次，不影响正常流程

### 5. 编辑页一致性修复（B）

**新增后端端点：`POST /api/user/channels/sync-from-gateway`**

用途：前端发现 DB 无渠道记录但 Gateway 有 channel account 时，调用此端点修复 DB。

参数：
```json
{ "agentId": "agent-xxx" }
```

逻辑：
1. 权限校验：当前用户是否拥有该 agent
2. 调 Gateway `config.get` 获取 config
3. 检查 `channels.feishu.accounts[agentId]` 是否存在
4. 检查 `bindings` 中是否有 `{ match: { channel: "feishu", accountId: agentId } }`
5. 如果 Gateway 有记录但 DB 无（`getChannelsByAgentId(agentId)` 为空），创建 `user_channels` 记录
6. 返回 `{ ok: true, channel: {...} }` 或 `{ ok: true, channel: null }`

**前端调用时机：**
- 加载 `feishuChannel` 时，如果 `GET /api/user/channels` 过滤结果为空，额外调此端点检查
- 如果返回 channel，更新 `feishuChannel` ref，UI 显示已接入状态
- 不需要每次都调，只在 DB 查询结果为空时作为 fallback

## 文件改动清单

| 文件 | 改动 |
|------|------|
| `src/views/agent-team/AgentEditPage.vue` | 新增 feishuChannel 状态、条件渲染、解绑逻辑、按钮文字 |
| `src/locales/zh-CN.ts` | 新增 i18n key（如需） |
| `server/index.js` | 新增 `logoutChannelFromGateway` 函数、修改 DELETE 路由增加 logout 调用、增强删除后残留检查、新增 sync-from-gateway 端点 |

## 验证方式

1. 创建数字员工 → 接入飞书 → 进入"连接"tab → 确认显示"已接入"状态
2. 点击"解除连接" → 确认 → 验证飞书发消息不再触发回复
3. 删除已接入飞书的数字员工 → 验证 Gateway config 无残留
4. 模拟 DB 无记录但 Gateway 有残留的场景 → 进入编辑页 → 确认自动修复并展示已接入状态
