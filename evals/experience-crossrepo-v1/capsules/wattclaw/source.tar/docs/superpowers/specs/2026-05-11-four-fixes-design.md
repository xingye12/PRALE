# 四项修复设计文档（2026-05-11）

## 需求 1：飞书绑定残留 — 级联删除

### 根因
`DELETE /api/agent-team/:id` 只删除 `user_agents` + `user_sessions`，没有清理 `user_channels` 表和 Gateway config 中的 channel accounts/bindings。

### 方案
在 `server/index.js` 的 `DELETE /api/agent-team/:id` 路由中，删除 DB 记录之前：
1. 查询该 agent 绑定的所有 channel（`user_channels` 表按 `agent_id` 查询）
2. 逐个调用已有的 `removeChannelFromGateway(channel)` 清理 Gateway config
3. 删除 `user_channels` 中对应的 DB 记录
4. 再执行原有的 `removeAgentForUser()` 逻辑

### 涉及文件
- `server/index.js` — DELETE `/api/agent-team/:id` 路由
- `server/user-manager.js` — 可能需要新增 `getChannelsByAgentId()` 查询函数

---

## 需求 2：深色模式文件管理颜色

### 根因
`FileManagerPage.vue` 代码预览区域使用硬编码 GitHub Dark 配色（`#0d1117`、`#161b22`、`#79c0ff`、`#8b949e`、`#6e7681`），浅色模式下也显示深色背景。

### 方案
1. 将硬编码颜色替换为 CSS 变量（`var(--bg-code)`、`var(--text-muted)`、`var(--text-tertiary)` 等）
2. 在 `main.css` 中补充缺失变量定义（如 `--bg-code-toolbar`）

### 涉及文件
- `src/views/files/FileManagerPage.vue` — 替换硬编码颜色为 CSS 变量
- `src/assets/styles/main.css` — 补充缺失变量

---

## 需求 3：飞书绑定 UI 简化

### 根因
`AgentEditPage.vue` 飞书弹窗中 NSelect 下拉框让用户选择 agent，但已默认选中当前编辑的 agent，在数字员工编辑场景下不应绑定其他 agent。

### 方案
1. 删除"绑定 Agent"整个区块（NSelect + 说明文字，模板第 443-457 行）
2. 删除 `agentSelectOptions` computed（第 38-43 行）、`agentOptions` ref（第 37 行）、`fetchAgents()` 函数
3. `feishuAgentId` 直接从 `agentId`（路由参数）取值，`handleAddFeishuConfig` 中已有的 `feishuAgentId.value = agentId.value` 保持不变
4. `handleManualBind` 中 `feishuAgentId.value` 已引用 `agentId.value`，无需改动

### 涉及文件
- `src/views/agent-team/AgentEditPage.vue`

---

## 需求 4：仪表盘去掉 cost 统计

### 根因
cost 作为一等公民深度集成在仪表盘中 — mode switcher、独立 API、computed 属性、多处条件渲染。

### 方案
1. 移除 `usageMode` ref（第 43 行），所有 `usageMode === 'tokens'` 条件直接取 tokens 逻辑，`usageMode === 'cost'` 分支删除
2. 移除 mode switcher 按钮组（模板第 879-882 行、1001-1002 行）
3. 移除 `usageCostSummary` ref（第 55 行）、`getUsageCost()` RPC 调用（第 515 行）
4. 移除 `formatUsd()` 函数（第 751 行）、`costTotalDisplay` computed（第 121 行）
5. 移除 `CostUsageSummary` 类型引用
6. 所有 computed 中删除 cost 分支：`dailyChartData`、`usageSegments`、`usageMetric()` 等
7. 移除 bento card 中的 cost 展示（如有独立 cost 卡片）
8. `userUsageData` 中移除 `totalCost` 字段
9. 保留 token 相关统计不变

### 涉及文件
- `src/views/Dashboard.vue` — 主要改动
- `src/api/types/index.ts` — 可能需清理 `CostUsageSummary` 类型（如无其他引用）
