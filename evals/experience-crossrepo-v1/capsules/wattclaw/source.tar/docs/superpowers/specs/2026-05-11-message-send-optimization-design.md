# 消息发送体验优化

## 问题

1. **3s 延迟**：每次发送消息都无条件 `await sessions.patch(model)`，即使 model 没变也调。这个 RPC 到 Gateway 往返 ~3s，用户按 Enter 后要等 3s 才看到消息发出。
2. **重复发送**：`sending = true` 在 `sessions.patch` 之后才设置，连按 Enter 能穿透 `canSend` 检查，导致消息重复发送。

## 根因分析

### 3s 延迟

`sendMessage()` 流程（workspace.ts:703-732）：

```
sendMessage()
  → await sessions.patch(model)   // 每次 send 都调，~3s，即使 model 没变
  → sending = true                // 锁太晚
  → httpPost('/api/workspace/send')
```

`sessions.patch(model)` 做了：model catalog 加载 → 验证 → 写入 session override → 设 `liveModelSwitchPending`。这是 Gateway 侧的正常处理时间，问题在于 WattClaw 每次都调。

### 重复发送

`canSend` 检查 `!workspaceStore.sending`，但 `sending` 在第 732 行才设 `true`（patchSession 之后）。在 patchSession 等待的 ~3s 内，`sending` 仍是 `false`，用户连按 Enter 会多次触发 `doSend`。

### Gateway model 机制（源码确认）

- `chat.send` **不接受** model 参数（schema 中无 model 字段）
- `sessions.patch(model)` 是唯一设置 model 的方式
- 模型解析优先级：session override → runtime model → agent default → global default
- 因此无法通过 `chat.send` 透传 model 绕过 `sessions.patch`

## 方案：预加载 patch + 按需 await

### 核心思路

利用用户切 model 和实际发消息之间的时间差，提前完成 `sessions.patch`。

### 流程

**用户切换 model 时（onModelChange）：**
1. 立即发 `sessions.patch`（异步，不阻塞 UI）
2. 存储 pending promise 和 patched model 值

**用户发送消息时（sendMessage）：**
1. `sending = true`（立即锁住，防止重复）
2. 检查 model 是否已 patch：
   - `selectedModel === patchedModel` → 跳过，零延迟
   - 有 `pendingModelPatch` 且 model 匹配 → await 那个 promise
   - 否则 → 发起新 patch 并 await
3. 发送消息

**99% 场景**：用户切 model → 打字 2-5s → 发消息。此时 patch 早已完成，零额外延迟。

**极端场景**：切 model → 立刻 Enter。await pending patch，~3s。但这很罕见且合理（用户刚做了 model 切换操作）。

### 重复发送防护

1. `sending = true` 提到 `sendMessage` 最前面（参数校验后、任何 await 前）
2. `ChatInput.vue` 的 `handleSend()` 加 `if (!canSend.value) return` 守卫

## 改动清单

### 文件 1：`src/stores/workspace.ts`

**新增状态：**
```typescript
const patchedModel = ref<string | null>(null)      // 已确认 patch 到 Gateway 的 model
const pendingModelPatch = ref<Promise<void> | null>(null)  // 正在进行的 patch promise
```

**新增方法 `ensureModelPatched()`：**
```typescript
async function ensureModelPatched() {
  const model = selectedModel.value
  const key = activeSessionKey.value
  if (!model || !key) return

  // 已 patch，跳过
  if (patchedModel.value === model) return

  // 有进行中的 patch，等它完成
  if (pendingModelPatch.value) {
    await pendingModelPatch.value
    if (patchedModel.value === model) return
  }

  // 需要新 patch
  await wsStore.rpc.patchSession({ sessionKey: key, model })
  patchedModel.value = model
}
```

**新增方法 `previewModelChange(model)`：**
```typescript
function previewModelChange(model: string) {
  selectedModel.value = model
  const key = activeSessionKey.value
  if (!key || patchedModel.value === model) return
  // 无 activeSessionKey 时只更新本地 ref，不 patch（等 sendMessage 时 ensureModelPatched 处理）

  pendingModelPatch.value = wsStore.rpc
    .patchSession({ sessionKey: key, model })
    .then(() => { patchedModel.value = model })
    .catch(() => {})  // best-effort，失败不阻塞；下次 ensureModelPatched 会重试
    .finally(() => { pendingModelPatch.value = null })
}
```

**修改 `sendMessage()`：**
- `sending = true` 移到函数最前面（紧接参数校验后，在 `startNewChat` 之前）
- 替换原来的 `await wsStore.rpc.patchSession()` 为 `await ensureModelPatched()`

**导出：**
- `previewModelChange` 需要加入 store return 对象

**session 切换时重置 `patchedModel = null`：**
- `selectAgent()`（第 425 行附近）
- `selectSession()`（第 584 行附近）— 注意 `selectSession` 会更新 `selectedModel`（第 595 行），如果 `patchedModel` 不重置，`ensureModelPatched` 会误判为已 patch
- `startNewChat()`（第 648 行附近）— 新 session 的 model 状态未知

**新增 session 重置辅助：**
```typescript
function resetPatchedModel() {
  patchedModel.value = null
  pendingModelPatch.value = null
}
```

**`sendMessage()` 重构后完整流程：**
```
1. 参数校验
2. sending = true              // 立即锁定（在 startNewChat 之前）
3. if (!activeSessionKey) → startNewChat()  // 同步，设好 key
4. 设置 title（同步）
5. await ensureModelPatched()  // 此时 activeSessionKey 已有值
6. 本地消息加入 messages
7. httpPost('/api/workspace/send')
```

### 文件 2：`src/views/workspace/ChatInput.vue`

**修改 `handleSend()`：**
```typescript
function handleSend() {
  if (!canSend.value) return  // 新增：防护重复发送
  const text = inputText.value.trim()
  // ... 其余不变
}
```

**修改 `onModelChange()`：**
```typescript
function onModelChange(modelId: string) {
  workspaceStore.previewModelChange(modelId)  // 替换原来的直接赋值
}
```

### 不需要改动的文件

- `server/index.js` — 后端无需改动，`chat.send` 不传 model
- `rpc-client.ts` — 无需改动

## 效果对比

| 场景 | 改前 | 改后 |
|------|------|------|
| 同 model 连续发消息 | ~3s（每次 patch） | 0ms（跳过 patch） |
| 切 model → 打字 → 发送 | ~3s | 0ms（打字期间已完成 patch） |
| 切 model → 立刻发送 | ~3s | ~3s（await pending patch，罕见场景） |
| 连按 Enter | 重复发送 | 锁住，不重复 |
