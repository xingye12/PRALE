# Token 消耗展示设计方案

**日期**: 2026-05-11
**状态**: 已确认

---

## 概述

两个子功能：

1. **会话 Token Badge** — 在对话页 ChatHeader 的 model chip 右侧，实时显示当前会话的 token 消耗
2. **仪表盘 Agent 排行** — 在仪表盘排行榜区域新增 Top Agent 卡片，展示每个 Agent 的 token 消耗排名

---

## 功能 1：会话 Token Badge

### 位置

`src/views/workspace/ChatHeader.vue` — `header-right` 区域，model chip 右侧新增独立 token badge。

### UI 设计

- 样式：绿色 pill badge，显示如 `12.4K tokens`
- hover 时展示 tooltip，包含输入/输出拆分（输入 4.2K / 输出 8.2K）
- 无 token 数据时（新会话、无 usage）不显示
- 格式化函数：ChatHeader 内部实现一个轻量 `formatTokenCount(n)` 函数（参考 Dashboard.vue 的 `formatCompactNumber` 逻辑），避免引入不必要的依赖

### 数据更新机制

Gateway 流式事件不含 token 数据，采用 **后端代理推送** 方案。

**完整事件链路**（已逐行验证）：

```
1. Gateway → 后端: chat.done / agent.done / lifecycle end 事件
2. 后端 server/index.js:511 gateway.on('event') 拦截
3. 后端不阻塞，立即 broadcastSSE 转发原始事件给前端
4. 后端异步调用 pushTokenUpdate(sessionKey):
   a. gateway.call('sessions.usage', { key: sessionKey })
   b. 从返回 sessions 数组中找到匹配 session 的 usage
   c. broadcastSSE({ type: 'event', event: 'token_update',
        payload: { sessionKey, tokenUsage: { totalInput, totalOutput } }
      }, { sessionKey })
5. 前端 http-client.ts:126-132 case 'event' → emit('event', rpcEvent)
6. 前端 WorkspacePage.vue:99-102 wsStore.subscribe('event') 回调
7. workspaceStore.handleEvent('token_update', payload) 被调用
8. handleEvent 内更新 activeSession.tokenUsage + sessionStore 同步
9. ChatHeader 的 computed 响应式更新 badge 显示
```

**关键设计决策**：

- 后端使用 `{ type: 'event', event: 'token_update' }` 格式（而非独立的 `type: 'token_update'`），原因是：
  1. 复用 `broadcastSSE` 已有的 sessionKey 所有权过滤逻辑（line 623-634 只对 `type === 'event'` 做过滤）
  2. 复用前端已有的 `http-client.ts → case 'event' → emit('event')` 路由路径
  3. 复用 `WorkspacePage.vue` 已有的 `wsStore.subscribe('event')` → `handleEvent()` 调用链
  4. **不需要修改 http-client.ts**，不需要新增 subscribe

### 事件触发时机

后端在以下任一事件触发时异步推送 token 更新（复用 `tryAutoTitleForChannelSession` 相同的拦截条件）：

- `chat.done` 事件
- `agent.done` 事件
- `agent` 事件中 `stream === 'lifecycle' && phase === 'end'`

以上三个条件已在 `server/index.js:524-528` 判断，可以直接复用同一条件分支。

### 后端改动（server/index.js）

1. 在 `gateway.on('event')` 处理器（line 511）中，在 `tryAutoTitleForChannelSession` 调用旁新增 `pushTokenUpdate(sk)` 调用
2. 新增 `pushTokenUpdate(sessionKey)` 异步函数：
   - 使用 `_tokenUpdateInFlight` Set 防止同一 session 并发请求（复用 `_autoTitleInFlight` 模式）
   - 调用 `gateway.call('sessions.usage', { key: sessionKey })`
   - 从返回的 `sessions` 数组中查找匹配 sessionKey 的项的 `usage` 字段
   - 兼容多种字段名：`input`/`inputTokens`/`promptTokens`、`output`/`outputTokens`/`completionTokens`
   - 调用 `broadcastSSE({ type: 'event', event: 'token_update', payload: { sessionKey, tokenUsage: { totalInput, totalOutput } } }, { sessionKey })`

### 前端改动

1. **`src/stores/workspace.ts`** — 在 `handleEvent` 函数中新增 `token_update` 事件类型处理：
   - 在 line 925-926 附近（现有 `isDelta`/`isFinal` 判断区域后）添加 `normalizedEvent === 'token_update'` 判断
   - 解析 payload 中的 `{ sessionKey, tokenUsage: { totalInput, totalOutput } }`
   - 更新 activeSession 的 tokenUsage（直接赋值，因为 activeSession 是 computed，需修改 sessions 数组中对应项）
   - 同时调用 session store 的方法更新对应 session 的 tokenUsage

2. **`src/stores/session.ts`** — 新增 `updateSessionTokenUsage(sessionKey, tokenUsage)` 方法：
   - 在 sessions 数组中找到 key 匹配的 session
   - 更新其 `tokenUsage` 字段（创建新对象，保持不可变更新模式）
   - 触发 sessions ref 的响应式更新

3. **`src/views/workspace/ChatHeader.vue`** — 新增 token badge：
   - 从 workspace store 读取 `activeSession?.tokenUsage`
   - 计算总 token = `totalInput + totalOutput`
   - 内部实现 `formatTokenCount()` 函数
   - hover tooltip 展示输入/输出拆分

### 错误处理

- `sessions.usage` 调用失败时静默忽略（`try/catch`），不影响会话流
- token 数据可能比实际消耗延迟几秒（取决于 Gateway 的 usage 更新时机），这是可接受的
- 使用 `_tokenUpdateInFlight` Set 防止同一 session 并发多次 token 更新请求

---

## 功能 2：仪表盘 Agent 排行

### 位置

`src/views/Dashboard.vue` — 现有排行榜区域从 `cols="1 m:3"` 改为 `cols="1 m:2 l:4"`，新增 Top Agent 卡片。

### UI 设计

- 与现有 rank-card 样式一致（glass-effect 卡片 + 水平进度条）
- 绿色主题（区别于模型的蓝色、Provider 的蓝色、工具的橙色）
- 显示：Agent 名称 + token 总量 + 水平进度条
- 展示 Top 5 Agent

### 数据来源

复用 `src/stores/agent.ts` 中已有的 `agentStats` computed 和 `getAgentById()` 方法：

```typescript
// agent.ts 已有的 computed
const agentStats = computed(() => {
  const stats: Record<string, { sessions: number; input: number; output: number }> = {}
  for (const session of sessionStore.sessions) {
    const agentId = session.agentId || "main"
    if (!stats[agentId]) stats[agentId] = { sessions: 0, input: 0, output: 0 }
    stats[agentId].sessions++
    if (session.tokenUsage) {
      stats[agentId].input += session.tokenUsage.totalInput
      stats[agentId].output += session.tokenUsage.totalOutput
    }
  }
  return stats
})

// agent.ts 已有的方法
getAgentById(id: string) → AgentInfo | undefined
```

Dashboard 新增 `topAgents` computed：从 agentStats 按 token 总量排序取 Top 5，通过 `getAgentById` 获取显示名称。

### 改动范围

1. `src/views/Dashboard.vue`：
   - 引入 `useAgentStore`（当前未引入）
   - 新增 `topAgents` computed
   - NGrid 从 `cols="1 m:3"` 改为 `cols="1 m:2 l:4"`
   - 新增第 4 个 NGridItem rank-card（Top Agent），使用 `bg-success` / 绿色主题

2. i18n 文件 — 新增 Agent 排行相关翻译 key

---

## 可复用的现有代码

| 模块 | 复用内容 |
|------|---------|
| `stores/agent.ts` | `agentStats` computed + `getAgentById()` — 按 agentId 聚合 token 并获取名称 |
| `stores/session.ts` | sessions ref 的不可变更新模式 |
| `server/index.js:511-531` | 事件拦截点 — 已有 sessionKey 提取和触发条件 |
| `server/index.js:608-640` | `broadcastSSE()` — 使用 `type: 'event'` 复用所有权过滤 |
| `server/index.js:534` | `_autoTitleInFlight` 防并发 Set 模式 |
| `src/api/http-client.ts:126-132` | `case 'event'` 路由 — token_update 自动走此路径 |
| `WorkspacePage.vue:99-102` | `wsStore.subscribe('event')` → `handleEvent()` 调用链 |
| `Dashboard.vue` | rank-card 样式、`formatCompactNumber()`、`topBarWidth()` |

---

## 文件改动清单

### 后端
- `server/index.js` — 新增 `pushTokenUpdate()` 函数 + 在事件拦截点调用

### 前端
- `src/stores/workspace.ts` — handleEvent 新增 token_update 处理
- `src/stores/session.ts` — 新增 `updateSessionTokenUsage()` 方法
- `src/views/workspace/ChatHeader.vue` — 新增 token badge + tooltip
- `src/views/Dashboard.vue` — 引入 agent store，新增 topAgents computed + Agent 排行卡片
- `src/i18n/messages/zh-CN.ts` — 新增翻译
- `src/i18n/messages/en-US.ts` — 新增翻译

**不需要改动的文件**：
- `src/api/http-client.ts` — token_update 走已有 `case 'event'` 路径
- `src/composables/useEventStream.ts` — 监控面板不需要感知 token 事件
- `src/stores/websocket.ts` — subscribe 机制不变

---

## 不在范围内

- 不实现按 Agent 维度的每日趋势图（未来可扩展）
- 不实现 token 成本（cost）展示（当前只展示 token 数量）
- 不修改 Gateway 本身（纯 WattClaw 前后端改动）
