# 延迟 Token 加载优化

**日期**: 2026-05-12
**状态**: 已确认
**影响文件**: `src/stores/workspace.ts`

## 问题

进入在线对话（Workspace）页面时，`fetchAllSessionsCached()` 调用 `getSessionsUsage({limit: 200})` 获取所有 session 的 token 用量数据。该接口穿透到 Gateway 需要 2-9 秒，导致页面加载卡顿。

**根因链**:
1. 前端 `fetchAllSessionsCached()` 在 `loadAgents()` 中被调用，给所有 session 批量 enrich token 数据
2. 前端传 `limit: 200`，后端 polling cache 要求 `limit >= 1000` 才命中，导致每次穿透到 Gateway
3. Token 数据在页面加载时根本没人看——只在选中 session 后 ChatHeader 的 badge 才显示

## 方案

去掉页面加载时的全量 token enrich，改为选中 session 时按需获取。

## 改动

### 1. `fetchAllSessionsCached()` — 删除 usage enrich

删除 `getSessionsUsage()` 调用（第 396-419 行），只保留 `listSessions()`。

页面加载从"等 listSessions + getSessionsUsage"变成"只等 listSessions"。

### 2. 新增 `fetchSingleSessionUsage(sessionKey)` 辅助函数

调 `getSessionsUsage({key: sessionKey})` 只查一条 session 的 usage。更新 `agents[].sessions` 中对应 session 的 `tokenUsage` 字段。Fire-and-forget，失败静默。

### 3. `selectSession()` — 按需加载 token

选中 session 时，检查该 session 是否缺少 tokenUsage 且有消息记录（`messageCount > 0`）。满足条件则调用 `fetchSingleSessionUsage`。

空 session（messageCount = 0）不发请求。

### 不改的部分

- SSE `token_update` handler — 实时对话完成后后端推送，workspace store 已有 handler 更新 session token，不动
- `sendMessage` — 不依赖也不设置 tokenUsage，不动
- session store 的 `fetchSessions` — Dashboard 页面用自己的加载方式，不动
- 后端 — 不动

## 数据流对比

| 阶段 | 现在 | 改后 |
|------|------|------|
| 页面加载 | listSessions + getSessionsUsage(全量, 2-9s) | 只 listSessions |
| 点击 agent | fetchAllSessionsCached (15s cache) | 不变 |
| 点击 session | 无额外调用 | getSessionsUsage({key}) 只查一条 (~200ms) |
| 对话完成 | SSE token_update 推送 | 不变 |

## 校验结论

所有 `tokenUsage` 消费方（ChatHeader、agent.ts、office.ts、session.ts、SessionsPage、OfficePage）都做了 null safe 处理（optional chaining、`if (!tokenUsage)` 守卫、`?? 0` fallback）。初始 `undefined` 不会破坏任何功能。

ChatHeader badge 用 `v-if="totalTokens > 0"` 守卫，`tokenUsage` 为 `undefined` 时 badge 不渲染，数据到达后自动显示。
