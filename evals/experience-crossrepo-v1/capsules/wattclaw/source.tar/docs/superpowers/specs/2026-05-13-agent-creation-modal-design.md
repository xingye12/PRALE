# 数字员工创建与添加模块设计文档

**日期**: 2026-05-13
**范围**: 两个弹窗组件（自定义创建 + 推荐添加）+ 跨页面自动发消息
**状态**: 已修正（6 处自检问题已修复）

---

## 1. 概述

为 WattClaw 的"数字员工"模块开发两个弹窗：

1. **自定义创建弹窗** (`CreateAgentModal`)：用户填写信息创建专属数字员工，带模拟进度条，成功后自动跳转到对话页并发送问候语。
2. **推荐添加弹窗** (`AgentAddDetailModal`)：展示推荐数字员工的详情，点击添加后走相同的创建流程。

**核心原则**：零后端改动，完全复用现有组件和 API 流程。

---

## 2. 组件架构

```
AgentTeamPage.vue
├── CreateAgentModal.vue          ← 自定义创建（重写 UI，内部调用 useAgentCreation）
│   ├── AvatarSelector            ← 复用现有 emoji 数组
│   ├── ModelDropdown.vue         ← 复用（variant="select"）
│   └── CreateProgressBar.vue     ← 新增共用进度条
│
├── AgentAddDetailModal.vue       ← 推荐添加详情（新增，内部调用 useAgentCreation）
│   └── CreateProgressBar.vue     ← 共用
│
└── useAgentCreation() composable ← 新增：封装 Gateway create → setAgentFile → backend API 的完整流程

AgentMarketPage.vue / AgentTemplateGrid.vue  ← 修改：点击模板卡片打开 AgentAddDetailModal

WorkspacePage.vue                 ← 小幅改造
└── 检测 route.query.greet → 自动发消息
```

---

## 3. useAgentCreation Composable（新增）

### 3.1 职责

将原本分散在 `AgentTeamPage.vue` `handleCreated` 中的创建逻辑提取为独立的 composable，供两个弹窗直接调用。

### 3.2 接口设计

```ts
// src/composables/useAgentCreation.ts
export interface CreateAgentParams {
  name: string
  avatar: string
  description: string
  category: string
  templateId: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  workStyle?: string        // 新增：工作风格（自定义创建时传入）
  model?: string            // 新增：用户选择的模型，默认用 Gateway 配置中的 primary
}

export interface CreateAgentResult {
  agentId: string           // 后端 DB 中的 agent ID
  gatewayAgentId: string    // Gateway 返回的 agent ID
  workspacePath: string
}

export function useAgentCreation() {
  async function createAgent(
    params: CreateAgentParams,
    onProgress?: (progress: number, stage: string) => void
  ): Promise<CreateAgentResult>

  return { createAgent }
}
```

### 3.3 内部流程

```
Stage 1: Gateway agents.create
  onProgress?.(20, '创建中...')
  ↓
Stage 2: setAgentFile(SOUL.md)
  onProgress?.(35, '配置资源')
  ↓
Stage 3: setAgentFile(AGENTS.md)
  onProgress?.(50, '初始化知识库')
  ↓
Stage 4: setAgentFile(IDENTITY.md)
  onProgress?.(65, '初始化知识库')
  ↓
Stage 5: setAgentFile(USER.md)
  onProgress?.(80, '下载资源')
  ↓
Stage 6: POST /api/agent-team/create
  onProgress?.(100, '完成')
  ↓
返回 { agentId, gatewayAgentId, workspacePath }
```

### 3.4 与现有 handleCreated 的差异

| 现有 `handleCreated` | `useAgentCreation` |
|---|---|
| 内联在 `AgentTeamPage.vue` 中 | 独立 composable，两个弹窗共用 |
| 无进度反馈 | 支持 `onProgress` 回调 |
| 最后跳转到 `AgentManagementDetail` | 调用方自行决定跳转目标 |
| `identityMd` 内部拼接 | `identityMd` 由调用方传入（弹窗根据 workStyle/description 生成） |

---

## 4. CreateAgentModal 详细设计

### 4.1 UI 布局（参考 img_6.png）

- **头部**：标题"欢迎创建你的专属数字员工" + 说明文字 + 右上角关闭图标
- **头像选择**：左侧展示默认头像（emoji），支持点击切换。复用现有 `avatarOptions` 数组（12 个 emoji）。
- **员工名称**：单行输入框，placeholder "请输入名字"，右侧字数统计 `0 / 15`。
- **核心职责**：多行文本框，placeholder "请简要描述该员工的核心职责"，右侧字数统计 `0 / 100`。
- **高级设置**：折叠面板（`n-collapse`），默认收起。
  - **工作风格**：单行输入框，placeholder "例如：专业严谨、幽默风趣、温暖贴心..."
  - **模型选择**：`ModelDropdown.vue`（`variant="select"`），默认选中 Gateway 配置中的默认模型。

### 4.2 状态管理

```ts
const isCreating = ref(false)       // 控制按钮禁用 + 进度条显示
const progress = ref(0)             // 0-100
const stageText = ref('')           // 左侧文案
const subText = ref('下载资源')      // 右侧文案，固定
let progressTimer: ReturnType<typeof setInterval> | null = null
```

### 4.3 交互状态机

```
[空闲态]
  ↓ 用户填写表单
  ↓ 点击"创建"
[创建中态]
  - 按钮禁用，文字变为"创建中..."
  - 显示 CreateProgressBar
  - 启动 setInterval：progress 从 0% 缓慢推进到 85%（每 100ms +2%）
  - 同时调用 useAgentCreation().createAgent(data, onProgress)
  ↓ 最后一个接口返回（onProgress 收到 100）
[完成态]
  - clearInterval
  - progress 强制设为 100%
  - 弹窗关闭
  - router.push({ name: 'Workspace', query: { agentId, greet: '1' } })
```

### 4.4 表单校验

- `name`：必填，1-15 字
- `description`：可选，0-100 字
- `workStyle`：可选
- `model`：必填，有默认值（从 Gateway config 读取 primary）

### 4.5 identityMd / soulMd 生成逻辑

自定义创建时，弹窗根据用户输入动态生成 markdown：

```ts
// soulMd
`# ${name}

${description || '帮助用户完成指定工作'}

## 初始化规则
你已经知道自己是${name}，不要反复确认身份。直接处理用户任务。`

// identityMd
`名称: ${name}
${workStyle ? `工作风格: ${workStyle}` : ''}
语气: 清晰、自然、高效
回复风格: 直接围绕用户任务工作，避免重复身份初始化。`
```

> `workStyle` 会合并到 `identityMd` 中，确保用户设置的工作风格生效。

---

## 5. AgentAddDetailModal 详细设计

### 5.1 UI 布局（参考 img_7.png）

- **顶部悬浮区**：员工头像（居中圆形）+ 员工名称（加粗标题）
- **员工介绍**：带 sparkle 图标的小标题 + `description` 描述文本
- **怎么使用？**：带文档图标的小标题 + 无序列表（ul/li）展示 `prompts`
- **底部区域**：
  - 深色背景"添加"按钮
  - 下方绿盾安全提示："已通过安全合规验证，无恶意代码或数据泄露风险。"

### 5.2 数据来源（复用现有模板系统）

复用 `src/config/agent-templates.ts` 中的模板数据。每个模板字段映射：

| UI 位置 | 模板字段 | 说明 |
|---------|----------|------|
| 头像 + 名称 | `avatar`, `name` | 直接展示 |
| 员工介绍 | `description` | 直接展示 |
| 怎么使用？ | `prompts` | 字符串数组，渲染为 ul/li |

> **修正说明**：模板中没有 `usageTips` 字段，用现有的 `prompts` 代替。`prompts` 是示例提示词（如"帮我写一个 REST API 接口"），语义上与"怎么使用？"的使用场景列表一致。

### 5.3 添加流程

点击"添加"后：
1. 按钮置灰显示"创建中..."
2. 显示 `CreateProgressBar`（左侧"创建中..."，右侧"下载资源"）
3. 调用 `useAgentCreation().createAgent(templateData, onProgress)`
4. 完成后关闭弹窗，跳转 Workspace

### 5.4 触发位置

`AgentMarketPage.vue`（或 `AgentTemplateGrid.vue`）中点击模板卡片时，不再直接创建，而是：

```ts
// AgentTemplateGrid.vue 中
function handleCardClick(template: AgentTemplate) {
  selectedTemplate.value = template
  showAddDetailModal.value = true
}
```

> 这意味着 `CreateAgentModal.vue` 的第一步"模板选择"需要调整：点击模板卡片不再直接 emit `created`，而是打开 `AgentAddDetailModal`。

---

## 6. CreateProgressBar 组件设计

### 6.1 Props

```ts
interface Props {
  progress: number        // 0-100
  statusText: string      // 左侧文字，如"创建中..."
  subText: string         // 右侧文字，如"下载资源"
}
```

### 6.2 UI

- 进度条容器：圆角灰色背景条（`var(--border-color)`）
- 进度填充：蓝色渐变（参考 img_8.png），圆角，宽度绑定 `progress%`
- 文案行：flex 两端对齐，左侧 `statusText`，右侧 `subText`
- 过渡：`transition: width 0.3s ease`

---

## 7. 跨页面数据流：自动发消息

### 7.1 路由跳转

创建/添加成功后，调用：

```ts
router.push({
  name: 'Workspace',
  query: {
    agentId: newAgentId,
    greet: '1'
  }
})
```

### 7.2 WorkspacePage 消费

修改 `WorkspacePage.vue` 的 `onMounted`：

```ts
onMounted(async () => {
  await workspaceStore.loadAgents()
  await workspaceStore.loadModels()

  const agentId = route.query.agentId as string | undefined
  const sessionKey = route.query.session as string | undefined

  if (sessionKey) {
    // ... 现有逻辑不变
  } else if (agentId) {
    await workspaceStore.selectAgent(agentId)

    // 新增：自动发问候语
    if (route.query.greet === '1') {
      const agent = workspaceStore.selectedAgent
      if (agent) {
        const greeting = buildGreeting(agent)
        await workspaceStore.sendMessage(greeting)
      }
      // 清除参数，防止刷新重复发送
      router.replace({ query: { ...route.query, greet: undefined } })
    }
  } else if (workspaceStore.activeSessionKey) {
    // ... 现有逻辑
  }
})
```

### 7.3 问候语来源（修正后）

> **修正说明**：现有 `AgentTemplate` 和 agent 对象中**没有** `greeting` 字段。问候语统一**动态生成**：

| 场景 | 问候语生成规则 |
|------|----------------|
| 模板创建 | `"你好，我是${template.name}，${template.description}，有什么可以帮你的？"` |
| 自定义创建 | `"你好，我是${name}，${description}，有什么可以帮你的？"` |
| description 为空时 | `"你好，我是${name}，有什么可以帮你的？"` |

问候语在 `useAgentCreation` 返回的 result 中一并带回（或通过 agentId 在 WorkspacePage 中读取 agent 信息生成）。

---

## 8. 核心流程：useAgentCreation 详细实现

### 8.1 伪代码

```ts
async function createAgent(
  params: CreateAgentParams,
  onProgress?: (progress: number, stage: string) => void
): Promise<CreateAgentResult> {
  const wsStore = useWebSocketStore()
  const authStore = useAuthStore()
  const store = useAgentTeamStore()

  // Stage 1: Gateway createAgent
  const config = await wsStore.rpc.getConfig()
  const defaultModel = config?.models?.primary || ''
  const model = params.model || defaultModel

  const agentSlug = `agent-${Date.now()}`
  const workspacePath = buildWorkspacePath(params.name) // 复用现有 sanitize/format 逻辑

  const createResult = await wsStore.rpc.createAgent({
    name: agentSlug,
    workspace: workspacePath,
    ...(model ? { model } : {}),
    emoji: params.avatar,
  })
  onProgress?.(20, '创建中...')

  const gatewayAgentId = createResult.agentId || createResult.name || agentSlug

  // Stage 2-5: setAgentFile
  const mdFiles = [
    ['SOUL.md', params.soulMd],
    ['AGENTS.md', params.agentsMd],
    ['IDENTITY.md', params.identityMd],
    ['USER.md', buildUserMdWithWorkspaceRules(params.userMd, workspacePath)],
  ].filter(([, content]) => content) as [string, string][]

  for (let i = 0; i < mdFiles.length; i++) {
    const [name, content] = mdFiles[i]!
    await wsStore.rpc.setAgentFile(gatewayAgentId, name, content)
    const progressMap = [35, 50, 65, 80]
    const stageMap = ['配置资源', '初始化知识库', '初始化知识库', '下载资源']
    onProgress?.(progressMap[i]!, stageMap[i]!)
  }

  // Stage 6: complete-bootstrap (fire-and-forget)
  const token = authStore.getToken()
  if (token) {
    fetch('/api/agent-team/complete-bootstrap', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspacePath }),
    }).catch(() => {})
  }

  // Stage 7: Backend DB create
  const dbAgent = await store.createAgent({
    name: params.name,
    avatar: params.avatar,
    description: params.description,
    category: params.category,
    templateId: params.templateId,
    gatewayAgentId,
    model,
  })
  onProgress?.(100, '完成')

  return {
    agentId: dbAgent.id,
    gatewayAgentId,
    workspacePath,
  }
}
```

### 8.2 错误处理

```ts
try {
  const result = await createAgent(params, onProgress)
  return result
} catch (err) {
  // 回滚：删除已创建的 Gateway agent
  if (gatewayAgentId) {
    try { await wsStore.rpc.deleteAgent(gatewayAgentId) } catch {}
  }
  throw err
}
```

---

## 9. 复用清单

| 能力 | 现有文件 | 复用方式 |
|------|----------|----------|
| 模型选择下拉框 | `src/components/ModelDropdown.vue` | `<ModelDropdown variant="select" />` |
| 头像 emoji 池 | `CreateAgentModal.vue` 中的 `avatarOptions` | 提取为常量或复用现有数组 |
| 头像渲染工具 | `src/utils/agent-avatar.ts` | `isImageAvatar()`, `resolveAgentAvatar()` |
| 模板数据 | `src/config/agent-templates.ts` | 直接 import，`prompts` 字段映射为"怎么使用？" |
| 创建 API 流程 | `AgentTeamPage.vue` `handleCreated` | 提取为 `useAgentCreation` composable |
| 路由跳转 | `src/router/routes.ts` | `router.push({ name: 'Workspace', query: {...} })` |
| 发送消息 | `src/stores/workspace.ts` `sendMessage()` | 直接调用 |
| 用户消息 markdown 渲染 | `MarkdownRenderer.vue` | 已全局复用 |

---

## 10. 文件变更清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/composables/useAgentCreation.ts` | **新增** | 封装完整的创建流程，支持 onProgress 回调 |
| `src/components/CreateProgressBar.vue` | **新增** | 共用进度条组件（img_8.png） |
| `src/views/agent-team/AgentAddDetailModal.vue` | **新增** | 推荐员工详情弹窗（img_7.png） |
| `src/views/agent-team/CreateAgentModal.vue` | **重写** | 按 img_6.png 重新设计 UI 和交互，内部调用 useAgentCreation |
| `src/views/agent-team/AgentTeamPage.vue` | **修改** | 移除内联 handleCreated，改为控制弹窗显示；集成两个弹窗 |
| `src/views/agent-market/AgentTemplateGrid.vue` | **修改** | 点击模板卡片打开 AgentAddDetailModal，不再直接创建 |
| `src/views/workspace/WorkspacePage.vue` | **修改** | 在 selectAgent 后检测 greet 参数，自动发消息并清除参数 |
| `src/i18n/zh-CN.ts` | **修改** | 新增弹窗相关文案 |
| `src/i18n/en-US.ts` | **修改** | 新增弹窗相关英文文案 |

---

## 11. 边界情况

| 场景 | 处理 |
|------|------|
| 创建过程中用户关闭弹窗 | 弹窗在 `isCreating` 期间设 `mask-closable="false"`，关闭按钮可点击但提示"创建中，是否取消？"；如确认取消，中止后续请求（AbortController 或 flag），已创建的 Gateway agent 通过 `deleteAgent` 回滚 |
| 创建接口失败 | `catch` 中 `clearInterval`，进度条隐藏，按钮恢复可用，`n-message.error` 显示错误。已创建的 Gateway agent 自动回滚（useAgentCreation 内部处理） |
| 用户快速连续点击创建 | 按钮在 `isCreating` 期间禁用，防止重复提交 |
| Workspace 页面刷新 | `greet` 参数在自动发消息后被 `router.replace` 清除，刷新不会重复发送 |
| 模型下拉框加载慢 | `ModelDropdown.vue` 内部已有 loading 状态，等待加载完成后再允许提交 |
| 接口极快（< 500ms） | 进度条从当前值瞬间跳到 100%，用户感知为"瞬间完成"，无问题 |
| 接口较慢（> 5s） | 进度条在 85% 停留，文案保持"下载资源"，这是可接受的（真实进度感） |

---

## 12. 自检记录

### 已修正的问题

1. ✅ **模板字段缺失**：原假设 `usageTips` / `greeting` 存在，实际用 `prompts` + 动态生成代替。
2. ✅ **创建逻辑耦合**：原方案尝试通过 emit 回调传递进度，不可行。已提取为 `useAgentCreation` composable，两个弹窗直接调用。
3. ✅ **自动发消息时序**：原方案未精确描述执行位置。已明确在 `onMounted` 的 `else if (agentId)` 分支末尾、`await selectAgent` 之后执行。
4. ✅ **跳转目标未指明变更**：原 `handleCreated` 跳到 `AgentManagementDetail`，已明确改为 `Workspace`。
5. ✅ **文件清单遗漏 composable**：已新增 `src/composables/useAgentCreation.ts`。
6. ✅ **AgentAddDetailModal 触发位置未说明**：已明确从 `AgentTemplateGrid.vue` 的模板卡片点击触发。
