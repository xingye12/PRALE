# 模型选择下拉框优化设计文档

## 背景

当前 `ModelDropdown.vue` 组件存在两个问题：
1. 模型列表显示顺序混乱，同一家供应商的模型分散在不同位置
2. 下拉选项缺少供应商图标，用户无法快速识别模型归属

本次优化通过引入供应商图标和固定优先级排序，提升下拉框的可读性和用户体验。

## 目标

1. 为每个供应商准备高质量 SVG 图标
2. 按供应商固定优先级对模型列表排序
3. 下拉选项渲染与设计图对齐（图标 + 模型名称 + 现有右侧标签）

## 决策记录

| 问题 | 决策 |
|---|---|
| 图标风格 | 官方品牌 SVG（用户选择方案 B） |
| 排序规则 | 固定优先级：MiniMax → DeepSeek → GPT → Claude → 智谱 → Ollama → 小米 |
| 同供应商内排序 | 按模型名称字母升序 |
| 实现方案 | 最小改动（方案 1），仅修改 3 个现有文件 + 新增图标资源 |

## 供应商图标映射

| providerId | 图标文件 | 品牌标识 |
|---|---|---|
| `minimax` | `minimax.svg` | MiniMax 波形 |
| `deepseek` | `deepseek.svg` | DeepSeek 蓝鲸 |
| `gpt` | `gpt.svg` | OpenAI 螺旋花 |
| `claude` | `claude.svg` | Claude 标志 |
| `zai` | `zai.svg` | 智谱 GLM 标识 |
| `ollama` | `ollama.svg` | Ollama 羊驼 |
| `xiaomi` | `xiaomi.svg` | 小米官方图标 |

## 排序优先级

```typescript
const PROVIDER_PRIORITY: Record<string, number> = {
  minimax: 1,
  deepseek: 2,
  gpt: 3,
  claude: 4,
  zai: 5,
  ollama: 6,
  xiaomi: 7,
}
```

排序逻辑：
1. 按 `providerId` 在 `PROVIDER_PRIORITY` 中的优先级升序排列
2. 未匹配的 `providerId` 排在最后
3. 同一供应商内按 `label`（模型显示名称）字母升序排列

## 架构变更

### 新增文件

- `src/assets/icons/providers/{claude,deepseek,gpt,minimax,ollama,xiaomi,zai}.svg`
- `src/utils/provider-icon.ts` — `getProviderIconUrl(providerId: string): string`

### 修改文件

- `src/composables/useModelProviders.ts`
  - 在 `modelList` computed 中添加排序逻辑
  - 引入 `PROVIDER_PRIORITY` 常量

- `src/components/ModelDropdown.vue`
  - 在 `dd-item` 模板中插入供应商图标 `<img>`
  - 添加 `.provider-icon` CSS 样式（20×20px，与文字居中对齐）
  - **保留现有右侧标签逻辑**：`dd-remark`（积分/备注）、`dd-overloaded`（爆满）、`dd-check`（选中勾号）

## UI 渲染结构

每个下拉选项的行结构：

```
┌──────────────────────────────────────────────────────┐
│ [图标 20×20]  模型名称          [remark] [爆满] [✓]  │
└──────────────────────────────────────────────────────┘
```

- 最左侧：20×20px 供应商图标，使用 `object-fit: contain`
- 左侧主内容：模型名称（`model.label || model.id`）
- 右侧：保留现有逻辑，显示 remark、爆满标签（红色）、选中勾号

## 兼容性

- 暗色模式：SVG 图标需使用 `currentColor` 或提供反色版本，确保在 `[data-theme='dark']` 下可见
- 未知供应商：如果 `providerId` 不在映射表中，不显示图标（或显示默认占位），不影响功能
- 现有交互：hover 效果、描述卡片弹出、点击选择等行为完全保留

## 验收标准

- [ ] `src/assets/icons/providers/` 目录下存在 7 个有效的 SVG 文件
- [ ] 下拉框中同供应商模型相邻显示，顺序符合固定优先级
- [ ] 每个选项行左侧显示对应供应商图标
- [ ] 图标尺寸适中，与文字垂直居中对齐
- [ ] 暗色模式下图标清晰可见
- [ ] 现有右侧标签（remark、爆满、选中勾号）功能正常
- [ ] 构建通过，无类型错误
