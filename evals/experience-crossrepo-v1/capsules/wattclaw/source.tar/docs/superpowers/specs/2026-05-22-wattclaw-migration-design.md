# WattClaw 迁移方案：server2_l → openclaw（同节点 Docker 化部署）

**日期**: 2026-05-22
**作者**: Claude Code (WattClaw Team)
**状态**: Design Approved

---

## 一、背景与目标

### 1.1 现状
- **源服务器**: `server2_l`（192.168.10.12）
  - WattClaw 以 screen 运行（非 systemd）
  - SSH/SCP 跨机文件传输（代码硬编码 `host: '192.168.10.12'`）
  - Node.js 24 裸进程，`PORT=3001`
- **目标服务器**: `openclaw`（192.168.10.19）
  - 已运行 OpenClaw Gateway（端口 18789）
  - Docker 可用（需 sudo）
  - 端口空闲：3001（WattClaw）

### 1.2 目标
- **同节点共存**: WattClaw 与 Gateway 在同一物理机，通过 Docker 隔离
- **预部署验证**: 先在 openclaw 部署完整实例，内网校验通过后再切换流量
- **I/O 降维**: SSH/SCP → 本地文件操作（`fs.writeFile`/`fs.unlink`）
- **环境沙盒化**: 独立容器、独立网络、挂载 Gateway 配置与 Agent workspace
- **权限对齐**: 容器内使用 `wattman` 用户，UID/GID 与宿主机一致

### 1.3 严格红线（不可触碰）
- **禁止**执行 `openclaw gateway restart`
- **禁止**修改 `server2_l` 上的任何配置/服务
- **禁止**全局依赖污染（如修改 `/usr/local/node`）
- **禁止**字符串截取打补丁

---

## 二、部署流程（三步走）

```
Step 1: 预部署（openclaw）
  ├── 构建 Docker 镜像
  ├── 启动 WattClaw 容器
  └── 内网直接访问校验（http://openclaw:3001）

Step 2: 验证
  ├── 登录测试
  ├── Agent 创建测试（含中文名）
  ├── 技能安装测试
  └── Gateway RPC 连通性测试

Step 3: 切换流量
  ├── 停止 server2_l 上的 WattClaw
  ├── 修改 Nginx upstream 指向 openclaw
  └── 外网验证
```

---

## 三、I/O 重构：SSH/SCP → 本地文件操作

### 3.1 环境变量双模式切换

新增环境变量（`.env` 或 `docker-compose.yml`）：
```bash
# 部署模式：distributed（跨机SSH）| colocated（同节点本地）
GATEWAY_DEPLOY_MODE=colocated

# 文件传输模式：sftp（SSH上传）| local（本地文件操作）
GATEWAY_FILE_TRANSFER_MODE=local
```

### 3.2 代码变更点

#### A. `server/index.js` — SSH 执行降级

**现状**（第 2619-2657 行）：
```javascript
const SSH_CONFIG = {
  host: '192.168.10.12',    // ← 硬编码
  port: 22,
  username: 'wattman',
  privateKeyPath: '/home/wattman/.ssh/id_rsa'
}

async function sshExec(command) {
  const ssh = new NodeSSH()
  await ssh.connect(SSH_CONFIG)
  const result = await ssh.execCommand(command)
  await ssh.dispose()
  return result
}
```

**改造后**：
```javascript
const { spawn } = require('child_process')
const DEPLOY_MODE = process.env.GATEWAY_DEPLOY_MODE || 'distributed'

async function localExec(command, args = []) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'pipe' })
    let stdout = '', stderr = ''
    child.stdout.on('data', (d) => { stdout += d })
    child.stderr.on('data', (d) => { stderr += d })
    child.on('close', (code) => {
      resolve({ code, stdout, stderr })
    })
    child.on('error', reject)
  })
}

async function gatewayExec(command) {
  if (DEPLOY_MODE === 'colocated') {
    // 同节点：本地执行（命令来自系统内部，无用户输入）
    const [cmd, ...args] = command.split(' ')
    return localExec(cmd, args)
  }
  // 跨机：保持 SSH
  const ssh = new NodeSSH()
  await ssh.connect(SSH_CONFIG)
  const result = await ssh.execCommand(command)
  await ssh.dispose()
  return result
}
```

#### B. `server/gateway-file-transfer.js` — 文件操作降级

**改造后**：
```javascript
const fs = require('fs').promises
const path = require('path')

const TRANSFER_MODE = process.env.GATEWAY_FILE_TRANSFER_MODE || 'sftp'
const GATEWAY_CONFIG_DIR = process.env.GATEWAY_CONFIG_DIR || '/host/openclaw'

async function uploadToGateway(localPath, remotePath) {
  if (TRANSFER_MODE === 'local') {
    const dest = path.join(GATEWAY_CONFIG_DIR, remotePath)
    await fs.mkdir(path.dirname(dest), { recursive: true })
    await fs.copyFile(localPath, dest)
    return { success: true }
  }
  // SFTP 分支保持原逻辑...
}

async function deleteRemoteFile(remotePath) {
  if (TRANSFER_MODE === 'local') {
    const target = path.join(GATEWAY_CONFIG_DIR, remotePath)
    await fs.unlink(target).catch(() => {})
    return { success: true }
  }
  // SFTP 分支...
}

async function writeRemoteFile(remotePath, content) {
  if (TRANSFER_MODE === 'local') {
    const dest = path.join(GATEWAY_CONFIG_DIR, remotePath)
    await fs.mkdir(path.dirname(dest), { recursive: true })
    await fs.writeFile(dest, content, 'utf-8')
    return { success: true }
  }
  // SFTP 分支...
}
```

### 3.3 依赖降级

| 依赖 | 原用途 | 新状态 |
|------|--------|--------|
| `node-ssh` | SSH 连接/执行 | 保留（distributed 模式仍需） |
| `ssh2-sftp-client` | SFTP 文件传输 | 保留（distributed 模式仍需） |
| `fs` (内置) | 本地文件操作 | 新增使用 |
| `child_process` (内置) | 本地命令执行 | 新增使用 |

---

## 四、Docker 容器化隔离

### 4.1 独立网络

```bash
sudo docker network create wattclaw-net \
  --driver bridge \
  --subnet 172.28.0.0/16 \
  --gateway 172.28.0.1
```

### 4.2 容器用户权限对齐（关键）

Gateway 以 `wattman` 用户运行，创建的 workspace 文件属主是 `wattman`。如果容器内以 `root` 运行，虽然能读写，但**容器内创建的文件会变成 `root` 属主**，导致 Gateway 侧无法访问。

**解决方案**：容器内使用与宿主机一致的 `wattman` 用户。

### 4.3 Dockerfile.wattclaw

**`Dockerfile.wattclaw`**（独立文件，不修改原 Dockerfile）：
```dockerfile
# syntax=docker/dockerfile:1
FROM node:24-alpine

# 创建与宿主机一致的 wattman 用户（UID/GID 需与宿主机对齐）
ARG WATTMAN_UID=1000
ARG WATTMAN_GID=1000

RUN addgroup -g ${WATTMAN_GID} wattman && \
    adduser -u ${WATTMAN_UID} -G wattman -s /bin/sh -D wattman

WORKDIR /app

# 安装生产依赖
COPY --chown=wattman:wattman package*.json ./
RUN npm ci --only=production

# 复制构建产物
COPY --chown=wattman:wattman dist ./dist
COPY --chown=wattman:wattman server ./server

# 数据目录权限
RUN mkdir -p /app/data /app/uploads && \
    chown -R wattman:wattman /app

USER wattman

ENV NODE_ENV=production
ENV PORT=3001
ENV HOME=/home/wattman
ENV GATEWAY_DEPLOY_MODE=colocated
ENV GATEWAY_FILE_TRANSFER_MODE=local
ENV GATEWAY_CONFIG_DIR=/host/openclaw

EXPOSE 3001

CMD ["node", "server/index.js"]
```

构建时传入宿主机实际 UID：
```bash
# 探测宿主机 wattman 的 UID/GID
WATTMAN_UID=$(id -u wattman)
WATTMAN_GID=$(id -g wattman)

sudo docker build \
  --build-arg WATTMAN_UID=${WATTMAN_UID} \
  --build-arg WATTMAN_GID=${WATTMAN_GID} \
  -f Dockerfile.wattclaw -t wattclaw:latest .
```

### 4.4 挂载清单（四大目录）

| 宿主机路径 | 容器内路径 | 权限 | 用途 |
|-----------|-----------|------|------|
| `/home/wattman/.openclaw` | `/host/openclaw` | `rw` | Gateway 配置（技能安装源 + 配置同步） |
| `/home/wattman/.wattclaw` | `/home/wattman/.wattclaw` | `rw` | **Agent workspace 工作目录** |
| `/home/wattman/wattclaw/data` | `/app/data` | `rw` | SQLite 数据库 + device-identity.json |
| `/home/wattman/wattclaw/uploads` | `/app/uploads` | `rw` | 用户上传文件 |

**关于 `.wattclaw` 挂载的说明**：
- Gateway 创建 Agent workspace 时以 `wattman` 用户写入 `/home/wattman/.wattclaw`
- WattClaw 的文件管理、终端、远程桌面等功能需要直接读写该目录
- 容器内 `HOME=/home/wattman`，`~/.wattclaw` 自然映射到宿主机同路径

### 4.5 docker-compose.wattclaw.yml

```yaml
version: '3.8'

services:
  wattclaw:
    build:
      context: .
      dockerfile: Dockerfile.wattclaw
      args:
        - WATTMAN_UID=${WATTMAN_UID:-1000}
        - WATTMAN_GID=${WATTMAN_GID:-1000}
    container_name: wattclaw
    user: "${WATTMAN_UID:-1000}:${WATTMAN_GID:-1000}"
    networks:
      - wattclaw-net
    ports:
      - "127.0.0.1:3001:3001"
    environment:
      - NODE_ENV=production
      - PORT=3001
      - HOME=/home/wattman
      - GATEWAY_DEPLOY_MODE=colocated
      - GATEWAY_FILE_TRANSFER_MODE=local
      - GATEWAY_CONFIG_DIR=/host/openclaw
      - OPENCLAW_WS_URL=ws://host.docker.internal:18789
    volumes:
      # Gateway 配置：技能安装源 + 配置读取
      - /home/wattman/.openclaw:/host/openclaw:rw
      
      # Agent workspace：数字员工工作目录
      - /home/wattman/.wattclaw:/home/wattman/.wattclaw:rw
      
      # WattClaw 自有数据
      - /home/wattman/wattclaw/data:/app/data:rw
      - /home/wattman/wattclaw/uploads:/app/uploads:rw
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3001/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

networks:
  wattclaw-net:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16
```

### 4.6 网络连接

容器内访问宿主机的 Gateway：
```bash
# 方案 A：host.docker.internal（Docker 18.03+，Linux 需额外配置）
OPENCLAW_WS_URL=ws://host.docker.internal:18789

# 方案 B：宿主机 IP（Linux 默认推荐）
OPENCLAW_WS_URL=ws://172.17.0.1:18789
```

**注意**：Linux 宿主机上 `host.docker.internal` 默认不解析，需在 `docker-compose.wattclaw.yml` 中补充：
```yaml
extra_hosts:
  - "host.docker.internal:host-gateway"
```
或直接使用方案 B（桥接网关 IP）。

不需要 `--network host`，保持容器网络隔离。

---

## 五、Nginx 切换（验证通过后执行）

### 5.1 当前配置（server2_l 上的 Nginx）

```nginx
# /etc/nginx/conf.d/wattclaw.conf
location /wattclaw/ {
    proxy_pass http://192.168.10.12:3001/;   # ← server2_l 上的 WattClaw
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

### 5.2 切换操作

```bash
# 1. 确认 server2_l 上的 WattClaw 已停止
ssh wattman@192.168.10.12 "sudo systemctl stop wattclaw"

# 2. 修改 Nginx upstream 指向 openclaw
sudo sed -i 's|http://192.168.10.12:3001/|http://192.168.10.19:3001/|' /etc/nginx/conf.d/wattclaw.conf

# 3. 验证配置语法
sudo nginx -t

# 4. 平滑 reload
sudo nginx -s reload
```

### 5.3 回滚策略（< 5 秒）

```bash
# 如果切过去发现有问题
# 1. Nginx 指回旧实例
sudo sed -i 's|http://192.168.10.19:3001/|http://192.168.10.12:3001/|' /etc/nginx/conf.d/wattclaw.conf
sudo nginx -t && sudo nginx -s reload

# 2. 启动旧实例
ssh wattman@192.168.10.12 "sudo systemctl start wattclaw"
```

---

## 六、部署 Playbook

### 6.1 Step 1：预部署（openclaw）

```bash
# ===== 在 openclaw 服务器上执行 =====

# 1. 端口检查
ss -tlnp | grep -E '3001|18789'

# 2. Docker 状态
sudo docker info

# 3. 拉取代码并构建
mkdir -p /home/wattman/wattclaw
cd /home/wattman/wattclaw
git clone <仓库地址> .
npm install
npm run build            # 生成 dist/ 目录

# 4. 创建数据目录
mkdir -p /home/wattman/wattclaw/data
mkdir -p /home/wattman/wattclaw/uploads

# 5. 数据库迁移（仅 SQLite，其他数据不迁移）
# 从 server2_l 复制 data/wattclaw.db
scp wattman@192.168.10.12:/home/wattman/wattclaw/data/wattclaw.db \
  /home/wattman/wattclaw/data/

# 6. 探测 UID/GID
WATTMAN_UID=$(id -u wattman)
WATTMAN_GID=$(id -g wattman)

# 7. 创建 Docker 网络
sudo docker network create wattclaw-net \
  --driver bridge \
  --subnet 172.28.0.0/16

# 8. 构建镜像
sudo docker build \
  --build-arg WATTMAN_UID=${WATTMAN_UID} \
  --build-arg WATTMAN_GID=${WATTMAN_GID} \
  -f Dockerfile.wattclaw -t wattclaw:latest .

# 9. 启动容器
sudo docker-compose -f docker-compose.wattclaw.yml up -d

# 10. 查看日志
sudo docker logs -f wattclaw
```

### 6.2 Step 2：内网验证

```bash
# 在 openclaw 本地直接访问（不经过 Nginx）
curl -s http://127.0.0.1:3001/api/health

# 或通过内网 IP 从其他机器访问
curl -s http://192.168.10.19:3001/api/health
```

**验证清单**：
- [ ] 容器启动成功，`docker ps` 显示 wattclaw Up
- [ ] 健康检查接口 `/api/health` 返回 200
- [ ] Gateway WebSocket 连接成功（日志无 ERROR）
- [ ] 登录测试：JWT Token 正常发放，用户数据与旧实例一致（SQLite 迁移验证）
- [ ] Agent 创建测试：中文名 Agent 创建成功
- [ ] 技能安装测试：安装后 `/host/openclaw/skills` 出现文件
- [ ] 文件管理测试：能读取 `/home/wattman/.wattclaw` 下的 workspace
- [ ] 权限验证：容器内创建的文件，宿主机侧属主为 `wattman`

### 6.3 Step 3：切换流量

```bash
# ===== 在 Nginx 服务器上执行 =====

# 1. 停止 server2_l 上的 WattClaw（screen 会话）
ssh wattman@192.168.10.12 "screen -S wattclaw -X quit"

# 2. 修改 Nginx 指向 openclaw
sudo sed -i 's|http://192.168.10.12:3001/|http://192.168.10.19:3001/|' /etc/nginx/conf.d/wattclaw.conf

# 3. 验证并重载
sudo nginx -t && sudo nginx -s reload

# 4. 验证流量
sudo tail -f /var/log/nginx/access.log | grep wattclaw

# 5. 外网功能验证
# 访问 https://your-domain.com/wattclaw/ 确认正常
```

### 6.4 回滚策略（如需回切到 server2_l）

```bash
# 1. Nginx 指回旧实例
sudo sed -i 's|http://192.168.10.19:3001/|http://192.168.10.12:3001/|' /etc/nginx/conf.d/wattclaw.conf
sudo nginx -t && sudo nginx -s reload

# 2. 在 server2_l 重新启动 WattClaw（screen）
ssh wattman@192.168.10.12 "cd /path/to/wattclaw && screen -dmS wattclaw npm start"
```

---

## 七、风险矩阵与应对

| 风险 | 概率 | 影响 | 应对 |
|------|------|------|------|
| Gateway 配置挂载失败 | 低 | 高 | 启动前验证 `/host/openclaw` 可读；fallback 到空配置 |
| `.wattclaw` workspace 权限冲突 | 中 | 高 | UID/GID 对齐；启动前 `chown -R wattman:wattman` |
| SQLite 数据迁移丢失 | 低 | 高 | 迁移前完整备份；迁移后校验行数 |
| Nginx reload 失败 | 极低 | 中 | `nginx -t` 预检；保留回滚命令 |
| 容器网络隔离导致 Gateway 不可达 | 低 | 高 | 使用 `host.docker.internal` 访问宿主机 Gateway |
| 旧实例未完全停止导致端口冲突 | 低 | 高 | 预检 `ss -tlnp | grep 3001`；确保单实例运行 |
| 中文 Agent 创建失败 | 低 | 中 | 验证 `generateSemanticAgentId` 使用 displayName |

---

## 八、文件变更清单

| 文件 | 变更类型 | 说明 |
|------|----------|------|
| `server/index.js` | 修改 | SSH 执行增加 `colocated` 分支 |
| `server/gateway-file-transfer.js` | 修改 | SFTP 操作增加 `local` 分支 |
| `Dockerfile.wattclaw` | 新增 | 独立容器镜像（node:24-alpine） |
| `docker-compose.wattclaw.yml` | 新增 | 容器编排配置（含 4 大挂载点） |
| `.env.example` | 修改 | 增加 `GATEWAY_DEPLOY_MODE`、`GATEWAY_FILE_TRANSFER_MODE` |
| `docs/superpowers/specs/2026-05-22-wattclaw-migration-design.md` | 新增 | 本文档 |

---

## 九、环境变量参考

```bash
# 必需
GATEWAY_DEPLOY_MODE=colocated        # distributed | colocated
GATEWAY_FILE_TRANSFER_MODE=local     # sftp | local
GATEWAY_CONFIG_DIR=/host/openclaw    # 容器内挂载路径

# 可选
OPENCLAW_WS_URL=ws://host.docker.internal:18789
PORT=3001
NODE_ENV=production
HOME=/home/wattman
```

---

## 十、相关 Memory

- [[project-workspace-isolation]] — Workspace 路径隔离与 bootstrap 注入
- [[feedback-gateway-patterns]] — Gateway RPC 调用约束与生命周期
- [[feedback-openclaw-normalize-agent-id]] — Agent ID 生成规范（displayName 修复）
