# 三层接入模型与 HTTP REST 化设计文档

> **日期**：2026-05-25
> **性质**：Architecture Design Spec
> **范围**：WattClaw 前后端 Gateway 接入层重构
> **关联文档**：`docs/cqrs-evaluation-for-ttft.md`

---

## 1. 设计目标

将 WattClaw 当前混乱的接入层改造为清晰的三层架构：

1. **控制面 REST 化**：`sessions.list`、`config.patch`、`chat.history` 从统一 RPC 代理端点拆分为独立 HTTP REST API
2. **chat.history 分页**：利用 OpenClaw Gateway 原生 HTTP 游标分页能力，实现前端无限滚动
3. **数据面 SSE 优化**：保留透传但注入心跳保活，解决代理超时问题
4. **事件面保留**：`/api/events` SSE 通道继续承担 Gateway 生命周期事件推送

---

## 2. 总体架构

```
Frontend (Browser)
├── 控制面：HTTP REST → WattClaw Backend 鉴权 → Gateway WS RPC
│   ├── GET /api/sessions
│   ├── PATCH /api/config
│   └── GET /api/chat/history?sessionKey=&limit=&cursor=
├── 数据面：WattClaw Backend SSE 透传+心跳 → Gateway HTTP SSE
│   └── POST /api/workspace/send
└── 事件面：SSE /api/events → WattClaw Backend 过滤聚合 → Gateway WS 事件
```

---

## 3. 控制面 REST API 设计

### 3.1 GET /api/sessions

**来源**：从 `server/index.js` `/api/rpc` 代理中的 `sessions.list` 分支提取

**后端逻辑**：
- Admin：返回 `allSessionsPolling` 缓存全部 sessions，合并全部本地 title
- 普通用户：`filterOwnedSessions` 过滤后，合并该用户的本地 SQLite title

**响应格式**：
```json
{
  "ok": true,
  "payload": {
    "sessions": [...],
    "total": 42,
    "page": 1,
    "limit": 42,
    "hasMore": false
  }
}
```

**复用组件**：`getCachedAllSessions()`、`filterOwnedSessions()`、`getLocalSessionTitles()`、`getAllSessionTitles()`

---

### 3.2 PATCH /api/config

**来源**：从 `server/index.js` `/api/rpc` 代理中的 `config.patch` 分支提取并简化

**关键发现**（源码校验）：
- 前端 `rpc-client.ts` 计算 `baseHash` 并随请求发送
- 后端 `/api/rpc` 处理**完全不使用 `params.baseHash`**，只读取 `params.raw`
- 后端 `ConfigQueue` 内部重新调用 `config.get`、自己计算 hash、处理 OCC

**结论**：前端 hash 计算在 WattClaw 场景下是**彻底无效的冗余操作**。

**后端逻辑**：
1. 接收 Body：`{ patches: ConfigPatch[] }`
2. 调用 `gateway.call('config.get', {})` 获取当前 snapshot
3. 应用 patches，计算 baseHash
4. 通过 `ConfigQueue` 序列化执行 `config.patch` + `config.apply`
5. `configGetPolling.refresh()`

**响应格式**：
```json
{ "ok": true, "payload": {} }
```

**复用组件**：`ConfigQueue` / `configQueueExecute`

---

### 3.3 GET /api/chat/history?sessionKey=&limit=&cursor=

**来源**：全新设计，替代 `/api/rpc` 中的 `chat.history` 代理

**OpenClaw Gateway 原生能力**（源码依据：`src/gateway/sessions-history-http.ts`）：
- Gateway 暴露 `GET /sessions/{sessionKey}/history?limit=N&cursor=xxx`
- 支持 **游标分页**（cursor-based pagination）
- 支持 `?limit` 参数（上限 1000）
- 首次请求（无 cursor）：`readRecentSessionMessagesWithStatsAsync` 高效读取尾部 N 条
- 翻页请求（有 cursor）：`buildSessionHistorySnapshot` 处理游标定位
- 使用 shared-secret bearer token 认证（和 `/v1/chat/completions` 一致）
- 支持 JSON 响应和 SSE 流式响应

**WattClaw 透传+适配逻辑**：
1. `authMiddleware` 鉴权
2. `isSessionOwned(sessionKey)` 权限检查，未拥有返回 `[]`
3. Backend 用 shared-secret `fetch` Gateway HTTP：
   ```
   GET https://gateway-host/sessions/{sessionKey}/history?limit=50&cursor=xxx
   Authorization: Bearer {gatewayAuthToken}
   ```
4. **轻量格式适配**（非无脑透传）：
   - Gateway 返回：`{ sessionKey, messages, cursor, hasMore }`
   - WattClaw 响应：
     ```json
     {
       "ok": true,
       "payload": {
         "messages": [...],
         "cursor": "...",
         "hasMore": true
       }
     }
     ```

**复用组件**：`isSessionOwned`

**前端分页策略**：
- 首次加载：`GET /api/chat/history?sessionKey=xxx&limit=50`（无 cursor）
- 向上滚动加载更早消息：`GET /api/chat/history?sessionKey=xxx&limit=50&cursor={cursor}`
- 前端维护 `messages[]`、`nextCursor`、`hasMore`

---

## 4. 数据面 SSE（分阶段实现）

### 第一阶段（本次实现）：透传 + 心跳保活

**现状问题**：双层 SSE 透传是反模式，但当前功能正常。直接改造为逐帧解析的 Smart Proxy SSE 存在风险：
- 需要维护 SSE parser 状态（buffer、帧边界）
- 每帧 JSON parse + stringify 的 CPU 开销
- 前端 parser 需要同步改造

**第一阶段目标**：
- 保持 `stream.pipeline()` 透传 Gateway OpenAI SSE
- 在 `ChatStreamHandleImpl` 中新增心跳机制：
  - 15s 无 upstream `data` 事件时，向 `res` 写入 `:keepalive\n\n`
  - 每次收到 `data` 时重置心跳计时器
- pipeline error 时，发送 `event: error\ndata: {...}\n\n` 后优雅关闭

**影响范围**：`server/services/chat-stream-proxy.ts` 中的 `ChatStreamHandleImpl`

### 第二阶段（未来）：Smart Proxy SSE Protocol

当需要注入 thinking/tool 事件时，再替换 pipeline 为逐帧 parser：
- 解析 Gateway OpenAI SSE 帧
- 翻译为 WattClaw Semantic Protocol
- 注入 `event: status`、`event: thinking`、`event: tool`

---

## 5. 事件面：/api/events 保留现状

Backend 订阅 Gateway WS 事件 → 按 session 所有权过滤 → 通过 SSE `/api/events` 推送给 Frontend。

此通道在本次改造中**完全不变**。

---

## 6. 前端改动清单

| Store | 当前调用 | 改为 |
|-------|---------|------|
| `src/stores/session.ts` | `wsStore.rpc.listSessions()` | `fetch GET /api/sessions` |
| `src/stores/workspace.ts` | `wsStore.rpc.listSessions()` | `fetch GET /api/sessions` |
| `src/stores/workspace.ts` | `wsStore.rpc.listChatHistory(sessionKey)` | `fetch GET /api/chat/history?sessionKey=&limit=50&cursor=` |
| `src/stores/chat.ts` | `wsStore.rpc.listChatHistory(normalizedKey)` | `fetch GET /api/chat/history?sessionKey=&limit=50&cursor=` |
| `src/stores/config.ts` | `wsStore.rpc.patchConfig(patches)` | `fetch PATCH /api/config`，Body: `{ patches }` |

**chat.ts / workspace.ts 额外改动**：
- 消费响应格式从 `ChatMessage[]` 改为 `{ messages, cursor, hasMore }`
- 实现无限滚动加载逻辑

---

## 7. 后端改动清单

| 文件 | 改动内容 |
|------|---------|
| `server/index.js` | 新增 `GET /api/sessions`、`PATCH /api/config`、`GET /api/chat/history` 三个路由；清理 `/api/rpc` switch 中对应代理分支 |
| `server/services/chat-stream-proxy.ts` | `ChatStreamHandleImpl` 新增心跳计时器（第一阶段） |

---

## 8. 关键设计决策

| 决策 | 选择 | 依据 |
|------|------|------|
| chat.history 分页方式 | **透传 Gateway HTTP 游标分页** | Gateway `sessions-history-http.ts` 原生支持 `?limit` + `?cursor` |
| chat.history 响应格式 | **轻量适配**（提取 messages + cursor + hasMore） | Gateway 返回对象含 sessionKey，前端期望数组，需 Backend 做格式映射 |
| config.patch hash 计算 | **下沉到 Backend** | 前端计算的 baseHash 在 WattClaw `/api/rpc` 处理中**完全未被使用**，ConfigQueue 内部重新计算 |
| 聊天流 SSE 改造 | **分阶段**：第一阶段仅注入心跳 | 逐帧解析有性能和稳定性风险，心跳可独立解决代理超时问题 |
| Gateway HTTP URL 构建 | 复用 `ChatStreamProxyService` 逻辑 | `wsUrl.protocol === 'wss:' ? 'https' : 'http'` + `wsUrl.host` |

---

## 9. 源码校验记录

| 校验项 | 源码位置 | 结论 |
|-------|---------|------|
| Gateway HTTP history 分页 | `src/gateway/sessions-history-http.ts:67-77` (resolveLimit) | 支持 `?limit`，上限 1000 |
| Gateway HTTP history 游标 | `src/gateway/sessions-history-http.ts:153` (cursor param) | 支持 `?cursor` 游标分页 |
| Gateway HTTP history 响应 | `src/gateway/sessions-history-http.ts:187-192` | 返回 `{ sessionKey, ...history }`，含 messages/cursor/hasMore |
| Gateway HTTP history 认证 | `src/gateway/sessions-history-http.ts:121-133` | 使用 shared-secret bearer token，WattClaw Backend 已持有 |
| RPC chat.history 参数 | `src/gateway/server-methods/chat.ts:2003-2007` | 支持 `sessionKey`、`limit`（默认 200，上限 1000）、`maxChars` |
| RPC config.patch 参数 | `src/gateway/server-methods/...` (via ConfigQueue) | 要求 `{ raw, baseHash? }`，WattClaw Backend ConfigQueue 内部处理 |
| 前端 patchConfig hash | `src/api/rpc-client.ts:2164-2177` | 前端计算 baseHash 并发送 |
| 后端 /api/rpc config.patch | `server/index.js:3543-3559` | **只使用 params.raw，不使用 params.baseHash** |

---

## 10. 后续行动

1. 调用 `writing-plans` skill 生成实施计划
2. 按 Phase 1（后端路由）→ Phase 2（前端 stores）→ Phase 3（验证）顺序执行
3. 设计文档归档至 `docs/decisions.md`
