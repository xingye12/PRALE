# History Local Store Design: PostgreSQL Message Store

## Overview

Store chat messages in WattClaw's own PostgreSQL database. Read from local store instead of calling OpenClaw Gateway for every history request. Messages are captured from the existing SSE event stream and user send endpoints. Lazy backfill for existing sessions.

## Problem

- Cross-agent session switching triggers Gateway cache miss → ~10s TTFB
- Gateway is single-threaded Node.js; `chat.history` handler is CPU-intensive (message projection) + disk I/O
- WattClaw has no control over Gateway internals; caching only treats the symptom

## Design Goals

- Chat history reads from local PostgreSQL → <10ms regardless of total data volume
- Write path captures every message that passes through WattClaw
- Lazy backfill for existing sessions (no one-time full migration)
- Zero frontend changes (API contract unchanged)
- Existing SQLite data (users, agents, sessions metadata) stays unchanged

---

## 1. Storage Architecture

### 1.1 Database Responsibility Split

| Database | Stores | Reason |
|----------|--------|--------|
| **SQLite** (existing) | Users, agents, sessions metadata, channels, backup records | Small data (150 users), read-heavy, already stable |
| **PostgreSQL** (new) | Chat messages (`session_messages` table) | High write volume (150K/day), JSONB queries, future partitioning |

Clear separation: SQLite answers "whose session is this?" PostgreSQL answers "what was said in this session?"

### 1.2 Table Schema

```sql
CREATE TABLE session_messages (
  id            BIGSERIAL PRIMARY KEY,
  session_key   TEXT NOT NULL,
  seq           INTEGER NOT NULL,
  msg_id        TEXT,                    -- Gateway message ID for dedup
  role          TEXT NOT NULL,
  content       TEXT NOT NULL DEFAULT '',
  raw_content   JSONB,                   -- Gateway chat.history 返回的单条消息，原样存储
  model         TEXT,
  status        TEXT NOT NULL DEFAULT 'confirmed',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  UNIQUE(session_key, seq)
);

CREATE INDEX idx_msg_session_seq ON session_messages (session_key, seq DESC);
CREATE INDEX idx_msg_session_status ON session_messages (session_key, status);
```

| Field | Purpose |
|-------|---------|
| `session_key` | Session identifier (e.g., `agent:ops:main:dm:user1`) |
| `seq` | Per-session auto-increment sequence number |
| `msg_id` | Gateway message ID (if available), used for dedup across Phase 1/2/backfill writes |
| `role` | `user` / `assistant` / `tool` / `system` |
| `content` | Message text for quick display |
| `raw_content` | Gateway `chat.history` 返回的单条消息元素，经过 `extractMessagesFromHistoryPayload` 提取后原样存入。不做额外转换，前端解析逻辑完全不变。 |
| `model` | Model used for this message |
| `status` | `pending`（已写入但未确认）/ `confirmed`（Gateway 已确认）/ `orphaned`（Gateway 拒绝，已作废）。读取路径只返回 `confirmed` 状态的消息。 |

### 1.3 Upsert 语义

所有写入（用户消息、事件捕获、Phase 1、Phase 2、回填）统一使用 upsert：

```sql
INSERT INTO session_messages (session_key, seq, msg_id, role, content, raw_content, model, status)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
ON CONFLICT (session_key, seq) DO UPDATE SET
  content = CASE
    WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.content
    ELSE session_messages.content
  END,
  raw_content = CASE
    WHEN EXCLUDED.created_at >= session_messages.created_at THEN EXCLUDED.raw_content
    ELSE session_messages.raw_content
  END,
  status = EXCLUDED.status,
  msg_id = COALESCE(EXCLUDED.msg_id, session_messages.msg_id)
```

冲突时：**更旧的数据不覆盖更新的数据**。Phase 2 回填写入不会冲掉用户刚发的新消息。

### 1.4 Seq 分配（无竞态）

为每个 session_key 使用 advisory lock 保护 seq 分配：

```sql
-- 获取会话级锁
SELECT pg_advisory_xact_lock(hashtext($sessionKey));
-- 在锁内分配 seq
SELECT COALESCE(MAX(seq), 0) + 1 FROM session_messages WHERE session_key = $sessionKey;
-- INSERT（锁在同一事务内自动释放）
```

同一会话的并发写入被串行化，不同会话的写入互不阻塞。

---

## 2. Write Path (Message Capture)

### 2.1 User Message

用户消息在发送时以 `status='pending'` 写入，Gateway 确认接受后更新为 `confirmed`：

```
POST /api/chat/send or POST /api/workspace/send
  → Write to PostgreSQL (role='user', status='pending')
  → Forward to Gateway
  → Gateway accepts → update status to 'confirmed'
  → Gateway rejects → update status to 'orphaned' (不返回给用户)
```

**孤儿消息处理**：如果 Gateway 返回错误（认证失败、session 不存在等），将该条消息标记为 `orphaned`。读取路径只返回 `status='confirmed'` 的消息，用户永远不会看到幽灵消息。

### 2.2 Assistant / Tool Messages

Gateway SSE 事件到达时，直接以 `status='confirmed'` 写入（因为 Gateway 已处理完成）：

```
Gateway SSE event (chat.done / chat.final)
  → Extract complete assistant message
  → Write to PostgreSQL (role='assistant', status='confirmed', raw_content=full JSONB)
  → If event contains tool_call / tool_result → write separately (role='tool')
```

### 2.3 Write Failure Handling

Write failure does NOT block normal flow (sending messages, streaming replies). Log error and continue. Local store is best-effort; Gateway remains the authoritative source.

---

## 3. Read Path (History Query)

### 3.1 Primary Flow

```
GET /api/chat/history?sessionKey=A&limit=50
  ↓
① Query PostgreSQL
   SELECT * FROM session_messages
   WHERE session_key = 'A' AND status = 'confirmed'
   ORDER BY seq DESC LIMIT 50
  ↓
② 本地 confirmed 消息数量 ≥ limit?
  ├─ YES → Return immediately (<10ms)
  └─ NO  → Continue to Phase 1 backfill
```

**关键**：不只判断"有/无"，而是判断"confirmed 消息数是否 ≥ 请求的 limit"。本地只有 3 条旧消息时仍触发回填，保证用户看到完整数据。

### 3.2 Phase 1: Immediate Response (Lazy Backfill — First Access)

```
③ Fetch from Gateway (limit=50)
   → Return to frontend (same latency as before, no regression)
   → Upsert 50 messages to PostgreSQL (status='confirmed')
  ↓
④ Trigger Phase 2 background backfill (non-blocking)
```

### 3.3 Phase 2: Background Full Backfill

```
Background job:
  → Fetch from Gateway (limit=1000)
  → Upsert ALL returned messages to PostgreSQL
  → Global queue: max 2 concurrent, 500ms interval between batches
  → User is already viewing messages, backfill is silent
```

Upsert 语义保证：Phase 2 的 1000 条和 Phase 1 的 50 条有重叠时不会冲突，更旧的数据不覆盖更新的数据。

### 3.4 loadMore (Scroll Up)

```
User scrolls to top → loadMoreMessages()
  ↓
Query PostgreSQL for older messages (WHERE seq < oldestLoadedSeq ORDER BY seq DESC LIMIT 50)
  ├─ Has older data (≥50) → Return from local (<10ms)
  └─ No older data (or <50)
      → Fetch from Gateway with cursor → Upsert to PostgreSQL → Return
```

### 3.5 API Contract Unchanged

Response format remains: `{ ok: true, payload: { messages, cursor, hasMore } }`. Frontend requires zero changes.

---

## 4. Session Lifecycle Cleanup

### 4.1 Session Reset

当会话被重置时，PostgreSQL 中的消息必须清除，否则用户会看到重置前的旧数据：

```
RPC sessions.reset / sessions.delete / REST endpoint
  → DELETE FROM session_messages WHERE session_key = ?
  → 也在 Gateway SSE 事件中监听 reset 信号触发清理
```

触发点：
- RPC `sessions.reset`（`POST /api/rpc` 中的 `sessions.reset` 方法）
- RPC `sessions.delete`
- REST `POST /api/sessions/:key/reset`
- Gateway SSE 事件中的 reset 信号

### 4.2 Session Delete

会话删除时级联清理消息：

```
RPC sessions.delete or REST endpoint
  → DELETE FROM session_messages WHERE session_key = ?
```

---

## 5. Data Consistency

### 5.1 Layer 1: Write Path Coverage

All messages pass through WattClaw backend:
- User messages: captured at send time (pending → confirmed)
- Assistant messages: captured on Gateway event arrival (confirmed)
- Messages during Gateway reconnection: filled by Phase 2 backfill on next access

### 5.2 Layer 2: Periodic Count Reconciliation

```
Every 30 minutes:
  SELECT session_key, COUNT(*) FROM session_messages
  WHERE status = 'confirmed'
  GROUP BY session_key
  → Compare with user_sessions.messageCount (from Gateway sessions.list)
  → Sessions with difference ≥ 5 → flag for backfill on next user access
  → Does NOT proactively call Gateway (avoids timer-driven load spikes)
```

### 5.3 Layer 3: On-Access Count Check

```
User accesses session A:
  → Return from PostgreSQL immediately (don't block)
  → Background: compare local confirmed count vs user_sessions.messageCount
  → Difference ≥ 5 → enqueue backfill job
```

### 5.4 What We Don't Do

- No per-message content comparison (too expensive, unnecessary)
- No real-time bidirectional sync (WattClaw is a read replica, not a co-primary)
- No proactive Gateway calls from cron jobs (only user-triggered backfill)

---

## 6. Preloading (Active Users)

### 6.1 Active User Definition

SSE connection exists = active. Disconnected = inactive.

Already tracked via `sseClients` Map in `server/index.js`.

### 6.2 Preload Strategy（轻量级，仅覆盖热路径）

预加载只拉 limit=50（不全量回填），只对 PostgreSQL 中没有数据的会话执行：

```
SSE connected for user U
  ↓
① Query user_sessions for user U, ordered by updated_at DESC
  ↓
② Group by agent_id, take top 4 per agent
   Example: 5 agents × 4 = up to 20 sessions
  ↓
③ Filter: skip sessions that already have data in PostgreSQL
   SELECT session_key, COUNT(*) FROM session_messages
   WHERE session_key = ANY($keys) AND status = 'confirmed'
   GROUP BY session_key
   → 只对 count = 0 的会话入队
  ↓
④ Enqueue to global backfill queue
  → 2 concurrent, 500ms interval
  → Each job fetches limit=50 from Gateway → upsert to PostgreSQL
```

**为什么不预加载 1000 条**：
- 20 会话 × limit=50 = 1000 条（合理）
- 20 会话 × limit=1000 = 20,000 条（冲击 Gateway）
- 全量回填留给用户主动访问时的懒加载 Phase 2

### 6.3 Skip Conditions

- Gateway not connected
- Queue already at capacity (max pending jobs = 50)
- User has no sessions in `user_sessions`

---

## 7. PostgreSQL Connection Pool

### 7.1 Configuration

```javascript
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,                    // max connections
  min: 2,                     // min idle connections
  idleTimeoutMillis: 30000,   // idle connection timeout
  connectionTimeoutMillis: 5000,
})
```

### 7.2 Process-Level Singleton

`message-store.js` 导出一个 pool 实例。整个进程共享同一个连接池，避免连接耗尽。

### 7.3 Connection Error Handling

Pool 级别的 `error` 事件监听，防止未捕获异常导致进程崩溃。写入失败时 log + continue，不阻塞主流程。

---

## 8. Data Lifecycle Management

### 8.1 规则

| 事件 | 操作 |
|------|------|
| 会话重置 | `DELETE FROM session_messages WHERE session_key = ?` |
| 会话删除 | `DELETE FROM session_messages WHERE session_key = ?` |
| 用户删除 | `DELETE FROM session_messages WHERE session_key IN (SELECT session_key FROM user_sessions WHERE user_id = ?)` |

### 8.2 未来扩展点（当前不实现，预留设计）

- 按 `created_at` 归档超过 1 年的已关闭会话消息
- 分区表（`PARTITION BY RANGE (created_at)` 按月分区）
- 当 `session_messages` 表超过 5000 万条时启动归档策略

---

## 9. Architecture Diagram

```
┌────────────────── Read Path ──────────────────────────────┐
│                                                              │
│  Frontend GET /api/chat/history                              │
│    ├─ PostgreSQL confirmed ≥ limit → return (<10ms)          │
│    └─ PostgreSQL confirmed < limit → Gateway → return        │
│       ├─ Phase 1: upsert 50 msgs (confirmed)                 │
│       └─ Phase 2: background upsert up to 1000 msgs          │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌────────────────── Write Path ──────────────────────────────┐
│                                                              │
│  User sends message (POST /api/chat/send)                    │
│    → Upsert to PostgreSQL (user message, status=pending)     │
│    → Forward to Gateway                                      │
│    → Gateway accepts → status=confirmed                      │
│    → Gateway rejects → status=orphaned                       │
│                                                              │
│  Gateway SSE event (chat.done/final)                         │
│    → Upsert to PostgreSQL (assistant/tool, status=confirmed)  │
│    → Forward SSE to frontend                                 │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌────────────────── Session Lifecycle ────────────────────────┐
│                                                              │
│  Session reset/delete → DELETE FROM session_messages         │
│  User delete → cascade DELETE on all user's sessions         │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌────────────────── Backfill ────────────────────────────────┐
│                                                              │
│  Triggers: lazy access / preload / reconcile                 │
│  Execution: global queue (2 concurrent, 500ms interval)      │
│  All writes: upsert (older data never overwrites newer)      │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## 10. Implementation Scope

### New Files

| File | Responsibility | Lines |
|------|---------------|-------|
| `server/message-store.js` | PostgreSQL pool, message CRUD, upsert, seq with advisory lock, lifecycle cleanup | ~150 |
| `server/backfill-queue.js` | Queue processor, preload scheduling, reconciliation | ~100 |

### Modified Files

| File | Changes | Lines |
|------|---------|-------|
| `server/index.js` | Write path capture (send endpoints + event handler), read path switch, preload trigger, session reset/delete cleanup | ~180 |
| `package.json` | Add `pg` dependency | 1 |
| `.env` | Add `DATABASE_URL` | 1 |
| `docker-compose.yml` | Add PostgreSQL service | ~15 |

### Total: ~450 lines of new code.

### Unchanged

- All frontend code (API contract unchanged)
- OpenClaw Gateway source
- Existing SQLite tables and queries
- SSE event forwarding mechanism
- `pushTokenUpdate` / `autoTitle` logic

---

## 11. Out of Scope

- No migration of existing SQLite data to PostgreSQL
- No frontend changes
- No OpenClaw Gateway changes
- No Redis or other external services
- No real-time bidirectional sync
- No startup warm-up (accept cold start, lazy backfill handles it)

---

## 12. Verification

1. **Write path**: Send a message → check PostgreSQL has user row (pending → confirmed) and assistant row (confirmed)
2. **Read path (local hit)**: Revisit the same session → APM shows PostgreSQL query (<10ms), no Gateway call
3. **Read path (lazy backfill)**: Visit an old session not in PostgreSQL → APM shows Gateway call + Phase 1 upsert → Phase 2 background backfill → check PostgreSQL has ~1000 rows
4. **Preload**: Open browser → SSE connect → check backfill queue starts → PostgreSQL populates for recent sessions (limit=50 each)
5. **loadMore**: Scroll up in a session with >50 messages → older messages load from PostgreSQL
6. **Consistency**: Send message → check PostgreSQL has new row → refresh page → message appears
7. **Multi-user**: Different users access各自 sessions → data isolated by session_key
8. **Session reset**: Reset a session → check PostgreSQL has 0 rows for that session_key → view history → triggers fresh backfill from Gateway
9. **Session delete**: Delete a session → check PostgreSQL cleaned up
10. **Orphan message**: Send message to invalid session → check row has status='orphaned' → view history → orphaned message NOT returned
11. **Upsert dedup**: Phase 1 writes 50 msgs → Phase 2 writes 1000 msgs → check PostgreSQL has no duplicate seq entries for same session_key
12. **Seq race**: Send two messages rapidly → both appear in PostgreSQL with correct sequential seq, no UNIQUE violation
13. **Count check**: Session with 3 local rows (limit=50 requested) → triggers backfill instead of returning incomplete data

---

## 13. Effect Estimate

| Scenario | Before | After |
|----------|--------|-------|
| Same-agent switch | Fast | Faster (<10ms from PostgreSQL) |
| Cross-agent switch (first time) | ~10s | ~10s (Gateway backfill, one-time) |
| Cross-agent switch (2nd time+) | ~10s | <10ms (PostgreSQL) |
| After sending message | ~10s | <10ms (write happened at send time) |
| Next day return | ~10s | <10ms (PostgreSQL is persistent) |
| loadMore (scroll up) | ~10s | <10ms (if backfilled) or ~10s (if not yet) |
| After server restart | ~10s | <10ms (PostgreSQL is persistent) |
| Session reset → view history | ~10s | ~10s (fresh backfill from Gateway) |

---

*Design date: 2026-05-28*
*Reviewed and revised: 2026-05-28 — fixed seq race, upsert semantics, session lifecycle cleanup, connection pool, orphan messages, preload pressure*
*Prerequisite analysis: [history-fetch-chain-analysis.md](../../docs/chat-flow/history-fetch-chain-analysis.md)*
