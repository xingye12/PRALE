# 设计文档：Gateway 流与前端连接解耦

> 日期：2026-05-29 | 分支：test/http-ws-separation
> 状态：待实现

---

## 一、问题

当数字员工执行复杂长耗时任务时，出现三个连锁 Bug：

1. **前端 60s 超时误杀**：`resetStreamTimeout()` 在 60s 无 SSE 事件时触发 `forceStopStreaming()`，前端停止显示动画，但后端和 Gateway 仍在处理
2. **刷新后消息消失**：前端消息只存内存，刷新后 Pinia store 重置。PG 中的数据可能不完整
3. **Agent 被终止**：前端断开（超时或刷新）→ 后端 `req.close` 触发 → `finalize('abort')` → Gateway upstream 被销毁 → Agent 执行被强行终止

**根因**：Gateway HTTP SSE 连接的生命周期与前端 HTTP 请求绑定。`pipeline(upstream, res)` 和 `req.once('close', () => finalize('abort'))` 导致前端断开时 Gateway 连接被关闭。

---

## 二、设计目标

1. **Gateway 连接独立于前端**：前端断开（刷新、关闭、超时）不影响后端到 Gateway 的连接
2. **后端是唯一安全网**：600s idle timeout 控制连接生命周期
3. **用户主动取消才终止 Agent**：点击"停止"按钮时，后端主动断开 Gateway 连接
4. **消息不丢失**：通过 Channel A → PG 的捕获路径保证刷新后数据可恢复
5. **前端兜底**：1 小时绝对上限 timeout 防止极端异常

---

## 三、架构变更

### 3.1 当前架构（耦合）

```
前端 fetch ←──pipeline──→ 后端 res ←──pipe──→ Gateway upstream

前端断开 → pipeline ERR_STREAM_PREMATURE_CLOSE → upstream 销毁 → Agent 终止
前端断开 → req.once('close') → finalize('abort') → 同上
```

两个耦合点：
- `req.once('close', onClientClose)` → `finalize('abort')`
- `pipeline(upstream, res)` → res 关闭时自动销毁 upstream

### 3.2 目标架构（解耦）

```
前端 fetch ──→ 后端 res（前端在就写，不在就丢弃）
                    │
                    ↓
              Gateway upstream（独立生命周期）
                    │
                    ├── data → 重置 idle timer，尝试写 res
                    ├── end → finalize('end')
                    ├── error → finalize('error')
                    ├── 600s idle → finalize('timeout')
                    └── abort()（外部调用）→ finalize('abort')
```

---

## 四、具体变更

### 4.1 后端 `server/services/chat-stream-proxy.js`

**`bind()` 方法重写**（~30 行）：

```javascript
bind(req, res) {
    this.res = res
    this.transition(StreamPhase.Streaming)

    // 前端断开 → 只分离 res，不终止 upstream
    req.once('close', () => {
        this.res = null
    })

    // 手动读取 upstream 数据
    this.upstream.on('data', (chunk) => {
        // 重置 idle timer
        this.disarmIdleTimer()
        this.armIdleTimer()

        // 如果前端还在，写入数据
        if (this.res && !this.res.writableEnded && !this.res.destroyed) {
            try { this.res.write(chunk) } catch { /* ignore write errors */ }
        }
        // 前端不在：静默丢弃
    })

    this.upstream.on('end', () => this.finalize('end'))
    this.upstream.on('error', (err) => this.finalize('error', err))

    // RAII: destroy upstream on cleanup
    this.registerCleanup(() => {
        if (!this.upstream.destroyed) this.upstream.destroy()
    })

    this.armIdleTimer()
}
```

**关键改变：**
- 去掉 `pipeline()`，改为手动 `upstream.on('data')` + `res.write()`
- `req.close` 只置空 `this.res`，不调用 `finalize()`
- upstream 的 end/error/idle 自然触发 `finalize()`

**`finalize()` 不变**，只是触发路径变了：
- `upstream end` → finalize('end')
- `upstream error` → finalize('error')
- `idle timer 600s` → finalize('timeout')
- `abort()` 外部调用 → finalize('abort')（用户取消）

**注意：** 去掉 `pipeline()` 意味着失去自动背压控制。SSE 数据块很小（几十到几百字节），TCP 缓冲区满在实践中不可能发生，可接受。

### 4.2 前端 `src/stores/workspace.ts`

**删除：**
- `resetStreamTimeout()` 函数及所有调用点（~8 处）
- `streamTimeout` 变量
- `maxStreamTimeout` 变量及 300s 定时器
- `sendMessage()` 中 line 1667-1669 的 timeout 设置
- `handleRealtimeEvent()` 中各 stream handler 的 `resetStreamTimeout()` 调用

**新增：**
- `sendMessage()` 中设置一个 1 小时兜底 timeout：
  ```javascript
  const maxTimeout = setTimeout(() => {
      lastError.value = '响应超时，请重试'
      forceStopStreaming(sessionKey)
  }, 3_600_000) // 1 hour absolute ceiling
  ```
- `forceStopStreaming()` 中清理 `maxTimeout`

**保留：**
- `forceStopStreaming()` — 正常完成时清理前端状态
- `cancelCurrentRequest()` — 用户主动取消入口

### 4.3 `server/index.js` — 用户消息持久化

**当前缺陷**：`/api/workspace/send` 路由不将用户消息写入 PG，刷新后用户消息丢失。`/api/chat/send` 有完整的 pending → confirmed/orphaned 生命周期，但 workspace 路径跳过了这一步。

**修复**：在 `chatProxy.connect()` 之前，同步写入用户消息到 PG：

```javascript
// 在 chatProxy.connect() 之前
const userMsgSeq = await getNextSeq(sessionKey)
if (userMsgSeq) {
    await upsertMessage({
        sessionKey,
        seq: userMsgSeq,
        role: 'user',
        content: message,
        status: 'confirmed',  // 直接 confirmed（connect 成功则消息已发出）
    })
}
```

用 `confirmed` 而非 `pending`：如果 `connect()` 成功，消息一定已发出；如果 `connect()` 失败，catch 返回错误给前端，PG 中的 orphaned 用户消息无害。

### 4.4 `server/index.js` — 取消路径

**新增 `activeStreamHandles` Map：**

```javascript
const activeStreamHandles = new Map() // sessionKey → ChatStreamHandle
```

**在 `/api/workspace/send` 路由中注册和清理：**

```javascript
handle.bind(req, res)
activeStreamHandles.set(sessionKey, handle)
handle.settled.then(() => activeStreamHandles.delete(sessionKey))
```

**在 `/api/chat/cancel` 中调用 `handle.abort()`：**

```javascript
const handle = activeStreamHandles.get(sessionKey)
if (handle) handle.abort('user cancelled')
await gateway.call('chat.abort', { sessionKey })
```

---

## 五、消息不丢失保证

### 5.1 数据流（刷新场景）

```
1. 用户发送消息 → POST /api/workspace/send
   → 用户消息同步写入 PG（confirmed）           ← 新增
   → chatProxy.connect() → Gateway 开始处理
2. Gateway 处理中:
   → Channel B (HTTP SSE): text delta → 前端实时显示
   → Channel A (WS event): captureEventMessage() → PG
3. 用户刷新 → 前端 fetch 断开
4. 后端: req.close → this.res = null, upstream 继续
5. Gateway 继续 → upstream 收到数据（丢弃）
                  → Channel A 事件继续写入 PG
6. Gateway 完成 → chat.final → captureEventMessage() → PG（完整 assistant 消息）
                → upstream end → finalize('end')
7. 新页面加载 → GET /api/chat/history → PG 有完整数据 → 显示
```

### 5.2 已有机制

- **用户消息**：`/api/workspace/send` 同步写入 PG（本次新增）
- **Assistant 消息**：`captureEventMessage()` 在 `gateway.on('event')` 中捕获 `chat.final` 事件（index.js:979）
- **读取路径**：`localCount > 0` 即返回 PG 数据（本次会话已修改）
- **SSE 重连**：`handleEvent()` 继续处理后续事件

### 5.3 刷新后的 UX 限制

刷新后新页面没有 `streamStates`，因此：
- 中间 thinking/tool 动画可能不完整
- 但 `chat.final` 到达时消息正常合并
- 最终结果完整保存在 PG

这是可接受的 UX 代价。

---

## 六、变更文件清单

| 文件 | 变更 | 行数估计 |
|------|------|---------|
| `server/services/chat-stream-proxy.js` | `bind()` 重写 | ~30 行 |
| `src/stores/workspace.ts` | 删除 timeout 机制，新增 1h 兜底 | ~25 行 |
| `server/index.js` | `activeStreamHandles` + cancel 路径 + 用户消息 PG 写入 | ~25 行 |

总计：~80 行变更。

---

## 七、触发条件矩阵

| 事件 | 当前行为 | 新行为 |
|------|---------|--------|
| 前端 60s 无 SSE 事件 | forceStopStreaming → 动画消失 | 不触发（已删除） |
| 前端 300s max timeout | forceStopStreaming → 动画消失 | 不触发（已删除） |
| 前端 1h 兜底 | 不存在 | forceStopStreaming → 提示超时 |
| 前端刷新 | upstream 销毁 → Agent 终止 | upstream 继续 → Agent 继续执行 |
| 前端关闭浏览器 | upstream 销毁 → Agent 终止 | upstream 继续 → Agent 继续执行 |
| 后端 600s idle | finalize → upstream 销毁 | 不变 |
| Gateway 完成 | upstream end → finalize | 不变 |
| 用户点击"停止" | 只发 chat.abort RPC | chat.abort RPC + handle.abort() |
