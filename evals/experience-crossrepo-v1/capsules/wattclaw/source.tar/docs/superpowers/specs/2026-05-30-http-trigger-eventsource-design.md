# HTTP 触发 + EventSource 数据方案设计文档

> 日期：2026-05-30  
> 分支：test/http-ws-separation  
> 作者：AI Engineering Agent  
> 状态：待审批

---

## 一、问题背景

### 1.1 现象

在 WattClaw → OpenClaw Gateway 的聊天流程中：

- **简单任务**（如"你好"）：HTTP SSE 流正常返回完整文本 ✅
- **复杂任务**（如"写坦克大战"）：HTTP SSE 流在第一个 agent turn 结束时就关闭，后续 continuation turn 的数据只通过 WebSocket 事件广播 ❌

### 1.2 根因

OpenClaw Gateway 的 `/v1/chat/completions` HTTP SSE 端点设计：

```
一个 HTTP 请求 = 一个 agent turn = 一次 SSE 流
```

复杂任务的实际流程：

```
HTTP 请求到达
  → agentCommandFromIngress() 开始
  → Turn 1: Agent 推理（无可见输出）
  → runTurn() resolve → emitAcpLifecycleEnd
  → HTTP SSE 流关闭（finish_reason: stop, 0 chars）
  → HTTP 响应结束

Gateway 内部自动启动 Turn 2:
  → Agent 调用工具（shell、写文件...）
  → Agent 生成最终回复
  → 所有事件通过 WebSocket 广播（HTTP 已经关了）
```

**约束：不能修改 OpenClaw Gateway 代码。**

### 1.3 当前架构

```
前端 ──HTTP SSE──→ 后端 ──HTTP SSE──→ Gateway /v1/chat/completions
  ↑                                              │
  └────────────── WebSocket 事件 ←───────────────┘
```

- **数据面**：`POST /api/workspace/send` → Gateway HTTP SSE（聊天文本流）
- **事件面**：Gateway WS → 后端 SSE → 前端 EventSource（实时事件）

**问题：前端 `sendMessage()` 只从 HTTP SSE 读取，但 Gateway 的数据分布在两个通道。**

---

## 二、方案对比

### 方案 A：后端合并两路数据

**思路**：后端把 Gateway HTTP SSE 和 Gateway WS 事件合并成一路 SSE 发给前端。

**问题**：
- 后端需要维护复杂的流合并状态机
- HTTP SSE 关闭后，后端如何继续把 WS 事件注入已关闭的响应？
- 需要新的"虚拟 SSE"机制，复杂度极高

** verdict：过度设计，不推荐。**

### 方案 B：前端合并两路数据

**思路**：前端同时监听 HTTP SSE 和 EventSource，把两路数据写入同一个 anchor message。

**问题**：
- HTTP SSE 关闭后会调用 `finalizeStreaming` → `forceStopStreaming`，把 `sending` 设为 false
- EventSource 的后续数据到达时，前端认为「不在发送中」，不会合并到 anchor
- 需要引入「等待 EventSource 模式」，状态机极其复杂
- 同一 tool call 可能从两路各创建一次

** verdict：状态机过于复杂，边界条件极易出错。**

### 方案 C：HTTP 触发 + EventSource 数据（推荐）

**思路**：
- HTTP SSE 只负责「点火」触发 Agent 执行
- 所有展示数据统一从 EventSource 获取
- `handleRealtimeEvent` 成为唯一数据写入路径

**优势**：
- 单一数据源，无合并逻辑
- 代码改动范围小
- 回滚简单
- 与现有 PG 回填机制兼容

** verdict：推荐。**

---

## 三、推荐方案详细设计

### 3.1 架构

```
用户发送消息
  ↓
前端 POST /api/workspace/send
  ↓
后端转发到 Gateway HTTP（触发 Agent）
  ↓
Gateway 执行 Agent workflow（多 turn）
  ↓
Gateway WS 事件 → 后端 broadcastSSE → 前端 EventSource
  ↓
前端 handleEvent() → handleRealtimeEvent() → 更新 anchor message
  ↓
chat.final / agent.done → forceStopStreaming()
```

### 3.2 后端改动

**文件**：`server/index.js`

**变更**：

```javascript
// 当前逻辑（第 3924-3932 行）
res.setHeader('Content-Type', 'text/event-stream')
res.setHeader('Cache-Control', 'no-cache')
res.setHeader('Connection', 'keep-alive')
res.setHeader('X-Accel-Buffering', 'no')
res.flushHeaders()
handle.bind(req, res)  // ← 改为不绑定到 res

// 新逻辑
res.json({ ok: true, sessionKey })  // ← 直接返回 JSON
```

**保留**：
- `chatProxy.connect()`（需要触发 Gateway）
- `handle.settled` 等待（需要知道 Gateway 执行结束）
- `handle.getCollectedContent()` 和 PG 写入（需要持久化）
- `activeStreamHandles` 注册（用于取消路径）
- `trackSessionForUser`（用于权限过滤）

**PG 写入调整**：

当前逻辑（第 3958-3971 行）只在 `collected.text || collected.toolCalls.length > 0` 时写入。

新逻辑：总是写入（包括空内容），因为复杂任务的 Turn 1 可能 0 字符。

```javascript
// 新逻辑
if (isMessageStoreReady()) {
  const assistantSeq = await getNextSeq(sessionKey)
  if (assistantSeq) {
    await upsertMessage({
      sessionKey,
      seq: assistantSeq,
      role: 'assistant',
      content: collected.text,
      rawContent: collected.rawContent,
      model: model || null,
      status: 'confirmed',
    }).catch(err => console.error(`[${reqId}] [MessageStore] assistant msg write error:`, err.message))
  }
}
```

### 3.3 前端改动

**文件**：`src/stores/workspace.ts`

**删除**：
- SSE 解析循环（`reader.read()` 循环，第 1673-1721 行）
- `appendStreamingContent()`（第 1753-1807 行）
- `appendStreamingToolCall()`（第 1809-1837 行）
- `finalizeStreaming()` 中的 SSE 相关逻辑

**新增**：

```typescript
// 新增状态
const waitingForEventSource = ref(false)
const eventSourceTimeout = ref<ReturnType<typeof setTimeout> | null>(null)

// sendMessage() 中
const response = await fetch(apiPath('/api/workspace/send'), {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', ... },
  body: JSON.stringify({ sessionKey, message: text, model: getActiveSessionModel(), ... }),
  signal: abortController.signal,
})

if (!response.ok) {
  const err = await response.json().catch(() => ({ error: 'Send failed' }))
  throw new Error(err.error || 'Send failed')
}

// 收到 200 后，设置等待状态
waitingForEventSource.value = true

// 启动兜底超时
eventSourceTimeout.value = setTimeout(() => {
  if (waitingForEventSource.value) {
    lastError.value = '响应超时，请重试'
    forceStopStreaming(sessionKey)
    waitingForEventSource.value = false
  }
}, 300_000) // 5 分钟
```

**handleEvent() 调整**：

```typescript
function handleEvent(event: string, payload: unknown) {
  // ... 现有逻辑 ...

  // 新增：处理 chat.error
  if (normalizedEvent === 'chat.error') {
    lastError.value = payloadRow?.message || 'Gateway error'
    waitingForEventSource.value = false
    if (eventSourceTimeout.value) {
      clearTimeout(eventSourceTimeout.value)
      eventSourceTimeout.value = null
    }
    forceStopStreaming(targetKey)
    return
  }

  // 现有 completion 逻辑（第 2462 行）
  if (isFinal || isError || hasPayloadStop || isAgentDone) {
    // ... 现有合并逻辑 ...

    // 新增：清除等待状态
    if (targetKey === activeSessionKey.value) {
      waitingForEventSource.value = false
      if (eventSourceTimeout.value) {
        clearTimeout(eventSourceTimeout.value)
        eventSourceTimeout.value = null
      }
    }

    forceStopStreaming(targetKey)
    return
  }
}
```

**forceStopStreaming() 调整**：

```typescript
function forceStopStreaming(sessionKey?: string | null) {
  const key = sessionKey || activeSessionKey.value
  if (!key) return

  // 新增：清除等待状态
  if (key === activeSessionKey.value) {
    waitingForEventSource.value = false
    if (eventSourceTimeout.value) {
      clearTimeout(eventSourceTimeout.value)
      eventSourceTimeout.value = null
    }
  }

  // ... 现有逻辑 ...
}
```

### 3.4 状态机

```
[Idle] --sendMessage()--> [Sending]
[Sending] --POST 200--> [WaitingForEvents]
[WaitingForEvents] --chat.final/agent.done--> [Idle]
[WaitingForEvents] --chat.error--> [Idle]
[WaitingForEvents] --5min timeout--> [Idle]
[WaitingForEvents] --user cancel--> [Idle]
```

### 3.5 错误处理

| 场景 | 行为 |
|------|------|
| Gateway HTTP 连接失败 | POST 返回 502/504，前端 catch，显示错误 |
| Gateway 执行错误 | EventSource `chat.error` 事件，前端显示错误 |
| EventSource 5 分钟无事件 | 兜底超时，前端显示"响应超时" |
| 用户取消 | 调用 `/api/chat/cancel`，前端清理状态 |
| WebSocket 断开 | 前端刷新后从 PG 读取完整历史 |

### 3.6 取消路径

**当前逻辑**：
- 用户点击取消 → `activeAbortController.abort()`（中断前端 fetch）
- 同时调用 `/api/chat/cancel` → 后端调用 `gateway.call('chat.abort')`

**新逻辑**：
- 用户点击取消 → `activeAbortController.abort()`（仍然需要，中断前端等待）
- 同时调用 `/api/chat/cancel` → 后端调用 `gateway.call('chat.abort')`
- 清除 `waitingForEventSource` 状态

**无变化。**

---

## 四、风险评估

| 风险 | 严重程度 | 缓解措施 |
|------|----------|----------|
| 文本流式体验变差 | 低 | `assistant` stream 事件已是增量推送，与 SSE 体验一致 |
| EventSource 事件丢失 | 低 | 后端 `broadcastSSE` 同步转发，无队列缓冲；PG 回填兜底 |
| 多用户权限过滤漏事件 | 低 | `/api/workspace/send` 中已调用 `trackSessionForUser` |
| 取消机制失效 | 低 | 取消走 WS RPC `chat.abort`，不依赖 HTTP SSE |
| 回滚困难 | 低 | 改动范围小，后端恢复 `handle.bind(req, res)`，前端恢复 SSE 解析即可 |
| 新状态机 Bug | 中 | 状态转换简单（Idle → Waiting → Idle），边界条件少 |

---

## 五、回滚策略

1. **后端**：恢复 `handle.bind(req, res)`，恢复 SSE 响应头设置
2. **前端**：恢复 SSE 解析循环，恢复 `appendStreamingContent()` 和 `appendStreamingToolCall()`
3. **删除**：`waitingForEventSource` 状态和相关逻辑

**预计回滚时间：10 分钟。**

---

## 六、测试验证清单

- [ ] 简单任务（"你好"）正常返回文本
- [ ] 复杂任务（"写坦克大战"）正常返回文本和工具调用
- [ ] 工具调用 UI 正确显示（start → update → result）
- [ ] 用户取消后状态正确清理
- [ ] 5 分钟超时兜底生效
- [ ] 刷新页面后消息不丢失（PG 回填）
- [ ] 多会话切换正常
- [ ] 回滚测试（验证回滚后 SSE 方案仍然工作）

---

## 七、结论

**推荐方案：HTTP 触发 + EventSource 数据。**

核心原则：
- HTTP SSE 只负责「点火」触发 Agent 执行
- 所有展示数据统一从 EventSource 获取
- `handleRealtimeEvent` 成为唯一数据写入路径

这个方案消除了两路数据合并的复杂度，代码改动范围小，风险可控。
