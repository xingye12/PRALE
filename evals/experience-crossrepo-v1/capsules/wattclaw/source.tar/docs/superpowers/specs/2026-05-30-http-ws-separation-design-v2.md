# HTTP+WS 分离架构设计文档 V2

> 日期：2026-05-30
> 分支：`test/http-ws-separation`
> 目标：解决复杂任务断流 + 多用户并发性能

---

## 一、设计目标

1. **聊天功能完整**：必须收到 lifecycle/thinking/tool/command_output 等全部 Agent 事件
2. **多用户不卡顿**：非聊天接口不阻塞，多用户并发性能好
3. **根本性解决**：不打补丁，从架构层面分离两种通信模式
4. **改动最小化**：复用主分支成熟代码，只改必要部分

---

## 二、架构决策

### 核心原则

```
所有前端接口统一使用 HTTP：
├── 聊天接口（chat.send / chat.history / chat.cancel）→ HTTP
├── 会话接口（sessions.list）→ HTTP ✅ 已改
├── 模型接口（models.list）→ HTTP ✅ 已改
├── 配置接口（config.get）→ HTTP
├── 用量接口（usage.get）→ HTTP
└── 其他所有接口 → HTTP

后端到 Gateway：
├── chat.send 触发 → WS RPC（获取完整 lifecycle 事件）
└── 其他接口 → Gateway HTTP REST
```

### 为什么这样设计

| 维度 | 前端 HTTP + EventSource | 后端 Gateway WS RPC（仅 chat.send） |
|------|------------------------|-----------------------------------|
| **事件完整性** | ✅ EventSource 推送 lifecycle/thinking/tool | ✅ WS RPC 触发完整事件流 |
| **时序正确性** | ✅ 单一后端事件源，严格有序 | ✅ 异步处理，不阻塞 HTTP 响应 |
| **并发性能** | ✅ HTTP 天然不阻塞 | ✅ `gateway.call` 立即返回 streamId |
| **实现复杂度** | 低（已有代码） | 低（已有代码） |

### 关键澄清

**前端所有接口统一使用 HTTP**：
- `POST /api/workspace/send` → 后端
- `GET /api/chat/history` → 后端
- `GET /api/sessions` → 后端
- EventSource `/api/events` ← 后端 SSE

**不存在前端 WebSocket**，前端与后端通信全部为 HTTP。

**后端到 Gateway 分层**：
- `chat.send` 触发：使用 WS RPC（必要，获取完整 lifecycle 事件）
- 其他接口：使用 Gateway HTTP REST

---

## 三、系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                        前端 (Vue 3)                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ Workspace   │  │ ChatPage    │  │ 管理页面 (Admin)     │  │
│  │ (聊天)       │  │ (聊天)      │  │ (会话列表/模型/配置)  │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         ▼                ▼                    ▼             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              API 客户端层                            │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ HTTP POST   │  │ EventSource │  │ HTTP Client │  │   │
│  │  │ (/api/*)    │  │ (/api/events)│  │ (REST API)  │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
└────────────┼────────────────┼────────────────┼─────────────┘
             │                │                │
             ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│                      WattClaw 后端 (Express)                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              REST 路由层                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ /api/workspace│  │ /api/chat/* │  │ /api/admin/*│  │   │
│  │  │ /send (HTTP)  │  │ /history    │  │ /sessions   │  │   │
│  │  │ /cancel       │  │ /cancel     │  │ /models     │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
│            │                │                │             │
│            ▼                ▼                ▼             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Gateway 通信层                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ WebSocket   │  │ WebSocket   │  │ HTTP Client │  │   │
│  │  │ (RPC 调用)   │  │ (事件接收)   │  │ (REST API)  │  │   │
│  │  │ chat.send    │  │ lifecycle   │  │ /v1/*       │  │   │
│  │  │ chat.history │  │ chat.done   │  │ /sessions/* │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
└────────────┼────────────────┼────────────────┼─────────────┘
             │                │                │
             ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw Gateway                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ WebSocket   │  │ WebSocket   │  │ HTTP Server         │
│  │ (RPC 请求)   │  │ (事件推送)   │  │ /v1/chat/completions│  │
│  │ chat.send    │  │ lifecycle   │  │ /sessions/{key}/*   │  │
│  │ chat.history │  │ thinking    │  │ /models             │  │
│  │ chat.cancel  │  │ tool        │  │ /config             │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 四、接口分类

### 4.1 聊天接口（全部 HTTP）

| 接口 | 方法 | 说明 |
|------|------|------|
| `POST /api/workspace/send` | HTTP | 触发聊天，返回 `{streamId}` |
| `EventSource /api/events` | SSE | 接收 lifecycle/thinking/tool/assistant 事件 |
| `POST /api/chat/cancel` | HTTP | 取消推理 |
| `GET /api/chat/history` | HTTP | 获取历史记录 ✅ 已改 |

**后端到 Gateway**：`chat.send` 触发使用 WS RPC（获取完整事件），其他聊天接口使用 Gateway HTTP

**事件流**：
```
用户发送消息
  → POST /api/workspace/send → 返回 {streamId}
  → Gateway 异步处理
  → lifecycle:start → thinking → assistant(text) → tool → command_output → assistant(text) → lifecycle:end
  → 后端 broadcastSSE → 前端 EventSource 接收 → handleEvent() 处理
```

### 4.2 HTTP REST（其他全部）

| 接口 | 方法 | 说明 |
|------|------|------|
| `GET /api/sessions` | HTTP | 会话列表 |
| `GET /api/models` | HTTP | 模型列表 |
| `GET /api/config` | HTTP | 配置获取 |
| `GET /api/usage` | HTTP | 用量统计 |
| `GET /api/cron` | HTTP | 定时任务 |
| `GET /api/skills` | HTTP | 技能状态 |

### 4.3 WattClaw 内部 REST（管理接口）

| 接口 | 说明 |
|------|------|
| `/api/users/*` | 用户管理 |
| `/api/agents/*` | Agent 管理 |
| `/api/channels/*` | 频道管理 |
| `/api/backup/*` | 备份管理 |

---

## 五、前端改造

### 5.1 workspace.ts（聊天 Store）回退主分支

```typescript
// 改回主分支方式
async function sendMessage(content, ...) {
  const result = await httpPost('/api/workspace/send', {
    sessionKey,
    message: text,
    idempotencyKey,
    ...(titleToSend ? { title: titleToSend } : {}),
  }) as Record<string, unknown>
  
  const sid = (result.streamId as string) || null
  streamState.streamId = sid
  activeStreamId.value = sid
  
  // 启动超时保护
  resetStreamTimeout()
  if (maxStreamTimeout) clearTimeout(maxStreamTimeout)
  maxStreamTimeout = setTimeout(() => forceStopStreaming(sessionKey), 300_000)
}

// 删除当前分支的 fetch SSE 解析代码
// - activeAbortController
// - reader.read() 循环
// - appendStreamingContent
// - SSE 逐行解析
```

### 5.2 事件处理恢复（主分支 handleEvent）

```typescript
// 通过 EventSource /api/events 接收，已有 handleEvent 处理
function handleEvent(event) {
  switch (event.stream) {
    case 'lifecycle':
      handleLifecycle(event)
      break
    case 'thinking':
      handleThinking(event)
      break
    case 'tool':
      handleTool(event)
      break
    case 'command_output':
      handleCommandOutput(event)
      break
    case 'assistant':
      handleAssistant(event)  // 文本增量
      break
  }
}
```

### 5.3 其他 Store（保持当前分支 HTTP 化）

```typescript
// session.ts - 保持当前分支 HTTP
async function listSessions() {
  const resp = await fetch('/api/sessions', { headers })
  const data = await resp.json()
  return data.payload
}

// model.ts - 保持当前分支 HTTP
async function listModels() {
  const resp = await fetch('/api/models', { headers })
  const data = await resp.json()
  return data.payload
}
```

---

## 六、后端改造

### 6.1 server/index.js 回退聊天路由

```javascript
// 回退到主分支：WS RPC 触发，返回 streamId
app.post('/api/workspace/send', async (req, res) => {
  const { sessionKey, message, idempotencyKey } = req.body
  
  try {
    // 使用 Gateway WS RPC 触发（非阻塞，立即返回）
    const result = await gateway.call('chat.send', {
      sessionKey,
      message,
      idempotencyKey,
    })
    
    // 返回 streamId，前端通过 EventSource 接收事件
    res.json({ streamId: result.streamId })
    
    // 追踪会话
    trackSessionForUser(sessionKey, req.userId)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
```

### 6.2 保留 HTTP 代理路由（其他接口）

```javascript
// 保持当前分支：HTTP 代理
app.get('/api/sessions', async (req, res) => {
  const response = await fetch(`${gatewayHttpUrl}/sessions`, {
    headers: { Authorization: `Bearer ${token}` }
  })
  res.json(await response.json())
})
```

### 6.3 Gateway HTTP 代理层（保持当前分支）

```javascript
// server/services/gateway-http-client.js
class GatewayHttpClient {
  constructor(baseUrl, authToken) {
    this.baseUrl = baseUrl
    this.authToken = authToken
  }
  
  async get(path) {
    return fetch(`${this.baseUrl}${path}`, {
      headers: { Authorization: `Bearer ${this.authToken}` }
    })
  }
  
  async post(path, body) {
    return fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.authToken}`
      },
      body: JSON.stringify(body)
    })
  }
}
```

---

## 七、数据流对比

### 7.1 聊天（HTTP + EventSource）

```
用户发送消息
  → 前端 httpPost('/api/workspace/send')
  → 后端 gateway.call('chat.send') 触发 Gateway
  → 后端立即返回 {streamId}
  → Gateway 异步处理
  → Gateway WS 推送事件到后端
  → 后端 broadcastSSE 到前端 EventSource
  → 前端 handleEvent() 处理 lifecycle/thinking/tool/assistant

特点：HTTP 触发，SSE 接收，单一事件源，严格有序
```

### 7.2 查询历史（HTTP）

```
用户切换会话
  → 前端 fetch('/api/chat/history')
  → 后端 fetch Gateway HTTP /sessions/{key}/history
  → 后端返回 JSON
  → 前端渲染

特点：请求-响应，无状态，不阻塞
```

### 7.3 获取会话列表（HTTP）

```
用户打开页面
  → 前端 fetch('/api/sessions')
  → 后端 fetch Gateway HTTP /sessions
  → 后端返回 JSON
  → 前端渲染

特点：请求-响应，无状态，不阻塞
```

---

## 八、风险评估

| 风险 | 等级 | 缓解措施 |
|------|------|----------|
| 聊天队头阻塞 | 低 | `gateway.call` 立即返回 streamId，处理异步 |
| EventSource 断开 | 中 | 自动重连机制（已有） |
| HTTP 接口兼容性 | 低 | Gateway HTTP API 已验证 |
| 前端改动量 | 低 | 回退主分支代码 |
| 后端改动量 | 低 | 回退聊天路由，保留其他 HTTP 路由 |

---

## 九、实施步骤

### Phase 1：聊天回退主分支
1. `src/stores/workspace.ts`：`sendMessage` 改回 `httpPost('/api/workspace/send')`
2. `src/stores/workspace.ts`：删除 `activeAbortController`、fetch SSE 解析代码
3. `src/stores/workspace.ts`：恢复 `handleEvent()` 完整处理（已有）
4. `server/index.js`：`/api/workspace/send` 改回 `gateway.call('chat.send')` 触发

### Phase 2：保留当前分支 HTTP 优化（已改）
1. `src/stores/workspace.ts`：`fetchChatHistory` 保持 HTTP ✅ 已改
2. `src/stores/session.ts`：`listSessions` 保持 HTTP ✅ 已改
3. `src/stores/model.ts`：`listModels` 保持 HTTP ✅ 已改
4. `server/index.js`：保留 `/api/chat/history`、`/api/sessions`、`/api/models` 等 HTTP 代理路由
5. `server/utils.js`：保留轮询优化（惰性刷新）

### Phase 3：清理
1. 删除 `server/services/chat-stream-proxy.js`（如不再使用）
2. 删除前端 SSE 解析 helper（`appendStreamingContent` 等）
3. 验证所有接口正常工作

---

## 十、验证清单

- [ ] 聊天正常收发，能收到 lifecycle 事件
- [ ] 复杂任务（工具调用）正常，不丢失中间过程
- [ ] 历史记录加载正常（HTTP）✅ 已改
- [ ] 会话列表加载正常（HTTP）✅ 已改
- [ ] 模型列表加载正常（HTTP）✅ 已改
- [ ] 配置获取正常（HTTP）
- [ ] 空闲时无轮询 RPC ✅ 已改
- [ ] 取消按钮正常
- [ ] 新建会话正常
- [ ] ScenarioWizard 正常（可保留 HTTP SSE）
- [ ] 多用户并发，非聊天接口不阻塞

---

## 十一、参考文档

- [HTTP+WS 分离分析](../../chat-flow-v2/http-ws-separation-analysis.md)
- [当前流式链路梳理](../../chat-flow-v2/current-streaming-linkage-analysis.md)
- [设计文档 V1（已废弃）](./2026-05-30-http-ws-separation-design.md)
