# HTTP+WS 分离架构设计文档

> 日期：2026-05-30
> 分支：`test/http-ws-separation`
> 目标：解决复杂任务断流 + 多用户并发性能

---

## 一、设计目标

1. **聊天功能完整**：必须收到 lifecycle/thinking/tool/command_output 等全部 Agent 事件
2. **多用户不卡顿**：非聊天接口不阻塞，多用户并发性能好
3. **根本性解决**：不打补丁，从架构层面分离两种通信模式

---

## 二、架构决策

### 核心原则

```
聊天（chat.send / chat.history / chat.cancel）
  └── WebSocket RPC（单一连接，完整事件流）

其他所有接口（sessions.list / config.get / models.list / usage.get / cron.list 等）
  └── HTTP REST API（独立连接，不阻塞）
```

### 为什么这样设计

| 维度 | 聊天用 WS | 其他用 HTTP |
|------|-----------|-------------|
| **事件完整性** | ✅ 需要 lifecycle/thinking/tool | ❌ 不需要 |
| **时序要求** | ✅ 严格有序 | ❌ 无特殊要求 |
| **并发性能** | ⚠️ 轻微队头阻塞 | ✅ 天然不阻塞 |
| **实现复杂度** | 低（已有代码） | 低（标准 REST） |

### 队头阻塞评估

- **实际场景**：单用户单会话，一次只发一条消息等回复
- **30用户并发**：30条消息排队，Gateway 处理速度快，延迟可接受
- **风险**：低。如未来成为瓶颈，可演进为多 device identity 连接池

---

## 三、系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                        前端 (Vue 3)                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ Workspace   │  │ ChatPage    │  │ 管理页面 (Admin)     │  │
│  │ (聊天)       │  │ (聊天)      │  │ (会话列表/模型/配置)  │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         ▼                ▼                    ▼             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              API 客户端层                            │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ WebSocket   │  │ EventSource │  │ HTTP Client │  │   │
│  │  │ (websocket) │  │ (SSE 事件)   │  │ (REST API)  │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
└────────────┼────────────────┼────────────────┼─────────────┘
             │                │                │
             ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│                      WattClaw 后端 (Express)                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              REST 路由层                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ /api/workspace│  │ /api/chat/* │  │ /api/admin/*│  │   │
│  │  │ /send (HTTP)  │  │ /history    │  │ /sessions   │  │   │
│  │  │ /cancel       │  │ /cancel     │  │ /models     │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
│            │                │                │             │
│            ▼                ▼                ▼             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Gateway 通信层                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │ WebSocket   │  │ WebSocket   │  │ HTTP Client │  │   │
│  │  │ (聊天 RPC)   │  │ (事件接收)   │  │ (REST API)  │  │   │
│  │  │ chat.send    │  │ lifecycle   │  │ /v1/*       │  │   │
│  │  │ chat.history │  │ chat.done   │  │ /sessions/* │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │   │
│  └─────────┼────────────────┼────────────────┼─────────┘   │
└────────────┼────────────────┼────────────────┼─────────────┘
             │                │                │
             ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw Gateway                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ WebSocket   │  │ WebSocket   │  │ HTTP Server         │  │
│  │ (RPC 请求)   │  │ (事件推送)   │  │ /v1/chat/completions│  │
│  │ chat.send    │  │ lifecycle   │  │ /sessions/{key}/*   │  │
│  │ chat.history │  │ thinking    │  │ /models             │  │
│  │ chat.cancel  │  │ tool        │  │ /config             │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 四、接口分类

### 4.1 WebSocket RPC（聊天专用）

| 接口 | 方法 | 说明 |
|------|------|------|
| `chat.send` | RPC | 发送消息，返回完整事件流 |
| `chat.history` | RPC | 获取历史记录 |
| `chat.cancel` | RPC | 取消推理 |

**事件流**：
```
lifecycle:start → thinking → assistant(text) → tool → command_output → assistant(text) → lifecycle:end
```

### 4.2 HTTP REST（其他全部）

| 接口 | 方法 | 说明 |
|------|------|------|
| `POST /v1/chat/completions` | HTTP SSE | 仅用于非聊天场景（如 Wizard） |
| `GET /sessions/{key}/history` | HTTP | 历史记录查询 |
| `GET /models` | HTTP | 模型列表 |
| `GET /config` | HTTP | 配置获取 |
| `GET /sessions` | HTTP | 会话列表 |
| `GET /usage` | HTTP | 用量统计 |
| `GET /cron` | HTTP | 定时任务 |
| `GET /skills` | HTTP | 技能状态 |

### 4.3 WattClaw 内部 REST（管理接口）

| 接口 | 说明 |
|------|------|
| `/api/users/*` | 用户管理 |
| `/api/agents/*` | Agent 管理 |
| `/api/channels/*` | 频道管理 |
| `/api/backup/*` | 备份管理 |

---

## 五、前端改造

### 5.1 workspace.ts（聊天 Store）

```typescript
// 改造前（当前分支 - HTTP SSE）
async function sendMessage(content, ...) {
  const response = await fetch('/api/workspace/send', {...})
  const reader = response.body.getReader()
  // 只解析文本增量，丢失 lifecycle
}

// 改造后（WebSocket RPC）
async function sendMessage(content, ...) {
  const result = await gateway.call('chat.send', {
    agentId, sessionKey, message: content, model
  })
  // result 是 AsyncIterable，按顺序产出全部事件
  for await (const event of result) {
    handleEvent(event)  // 处理 lifecycle/thinking/tool/assistant
  }
}
```

### 5.2 事件处理恢复

```typescript
function handleEvent(event) {
  switch (event.stream) {
    case 'lifecycle':
      handleLifecycle(event)
      break
    case 'thinking':
      handleThinking(event)
      break
    case 'tool':
      handleTool(event)
      break
    case 'command_output':
      handleCommandOutput(event)
      break
    case 'assistant':
      handleAssistant(event)  // 文本增量
      break
  }
}
```

### 5.3 其他 Store（改 HTTP）

```typescript
// session.ts
async function listSessions() {
  // 改造前：gateway.call('sessions.list')
  // 改造后：
  return httpClient.get('/api/sessions')
}

// model.ts
async function listModels() {
  // 改造前：gateway.call('models.list')
  // 改造后：
  return httpClient.get('/api/models')
}
```

---

## 六、后端改造

### 6.1 server/index.js

```javascript
// 聊天接口：WebSocket RPC 代理
app.post('/api/workspace/send', async (req, res) => {
  const { sessionKey, message, model } = req.body
  
  // 使用 WebSocket RPC
  const result = await gateway.call('chat.send', {
    sessionKey, message, model
  })
  
  // 返回流式响应（SSE 或 WebSocket 桥接）
  // ...
})

// 其他接口：HTTP 代理
app.get('/api/sessions', async (req, res) => {
  // 直接转发到 Gateway HTTP
  const response = await fetch(`${gatewayHttpUrl}/sessions`, {
    headers: { Authorization: `Bearer ${token}` }
  })
  res.json(await response.json())
})
```

### 6.2 Gateway HTTP 代理层

新增 `server/services/gateway-http-client.js`：

```javascript
class GatewayHttpClient {
  constructor(baseUrl, authToken) {
    this.baseUrl = baseUrl
    this.authToken = authToken
  }
  
  async get(path) {
    return fetch(`${this.baseUrl}${path}`, {
      headers: { Authorization: `Bearer ${this.authToken}` }
    })
  }
  
  async post(path, body) {
    return fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.authToken}`
      },
      body: JSON.stringify(body)
    })
  }
}
```

---

## 七、数据流对比

### 7.1 聊天（WebSocket）

```
用户发送消息
  → 前端 wsStore.call('chat.send')
  → 后端 gateway.call('chat.send')
  → Gateway WS
  → Gateway 处理
  → Gateway WS 返回事件流
  → 后端转发
  → 前端 handleEvent() 处理
  
特点：单一通道，严格有序，完整事件
```

### 7.2 查询历史（HTTP）

```
用户切换会话
  → 前端 httpClient.get('/api/chat/history')
  → 后端 fetch Gateway HTTP /sessions/{key}/history
  → Gateway 返回 JSON
  → 后端返回 JSON
  → 前端渲染
  
特点：请求-响应，无状态，不阻塞
```

---

## 八、风险评估

| 风险 | 等级 | 缓解措施 |
|------|------|----------|
| 聊天队头阻塞 | 低 | 实际场景阻塞不明显，可接受 |
| WS 连接断开 | 中 | 自动重连机制（已有） |
| HTTP 接口兼容性 | 低 | Gateway HTTP API 已验证 |
| 前端改动量 | 中 | 逐步迁移，保留 fallback |
| 后端改动量 | 中 | 新增 HTTP 代理层 |

---

## 九、实施步骤

### Phase 1：聊天回退 WebSocket
1. `src/stores/workspace.ts`：`sendMessage` 改回 `gateway.call('chat.send')`
2. `src/stores/workspace.ts`：恢复 `handleEvent()` 完整处理
3. `server/index.js`：`/api/workspace/send` 改回 WS RPC 代理

### Phase 2：其他接口 HTTP 化
1. `src/stores/session.ts`：`listSessions` 改 HTTP
2. `src/stores/model.ts`：`listModels` 改 HTTP
3. `server/index.js`：新增 HTTP 代理路由

### Phase 3：清理
1. 删除 `server/services/chat-stream-proxy.js`（如不再使用）
2. 清理前端 SSE 解析代码（如不再使用）
3. 验证所有接口正常工作

---

## 十、验证清单

- [ ] 聊天正常收发，能收到 lifecycle 事件
- [ ] 复杂任务（工具调用）正常，不丢失中间过程
- [ ] 会话列表加载正常（HTTP）
- [ ] 模型列表加载正常（HTTP）
- [ ] 配置获取正常（HTTP）
- [ ] 多用户并发，非聊天接口不阻塞
- [ ] 取消按钮正常（WS RPC）
- [ ] 新建会话正常
- [ ] ScenarioWizard 正常（可保留 HTTP SSE）

---

## 十一、参考文档

- [HTTP+WS 分离分析](../../chat-flow-v2/http-ws-separation-analysis.md)
- [Gateway HTTP SSE 端点分析](../../chat-flow-v2/http-ws-separation-analysis.md#三根因确认)
- [当前流式链路梳理](../../chat-flow-v2/current-streaming-linkage-analysis.md)
