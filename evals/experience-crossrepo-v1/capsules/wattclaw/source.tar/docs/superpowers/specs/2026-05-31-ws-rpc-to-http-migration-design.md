# WS RPC → HTTP 迁移设计（方案 A+admin-http-rpc）

> 日期：2026-05-31
> 状态：已批准
> 分支：`test/http-ws-separation`

## Context

WattClaw 后端通过单条 WebSocket 连接与 OpenClaw Gateway 通信。WS RPC 是阻塞式的——所有调用共享同一条连接，Gateway 的同步处理会阻塞后续请求，多用户场景下出现队头阻塞。

本方案利用两条路径将 WS RPC 调用迁移到 HTTP：
1. **Gateway 原生 HTTP 端点**（`/v1/models`、`/sessions/:id/history` 等）
2. **`admin-http-rpc` 插件**（`POST /api/v1/admin/rpc`，HTTP 方式调用 Gateway RPC 方法）

**不涉及聊天模块**（`chat.send` 继续走 WS RPC fire-and-forget）。

## 前提条件

### 已确认

- ✅ Gateway HTTP 服务默认启用（`fetchHistoryFromGateway()` 已在正常调用 `GET /sessions/:id/history`）
- ✅ `Authorization: Bearer` 认证已通
- ✅ URL 推导逻辑正确（`ws://` → `http://`，`wss://` → `https://`）
- ✅ Gateway 配置了 `gateway.http.endpoints.chatCompletions.enabled: true`
- ✅ Gateway auth 使用 token 模式
- ✅ **`admin-http-rpc` 插件已启用**（服务器已配置）
- ✅ admin-http-rpc 端点 `POST /api/v1/admin/rpc` 可用（Bearer token 认证，与 WS 一致）
- ✅ admin-http-rpc 响应格式与 WS RPC 完全一致（共用 `dispatchGatewayMethod()`）

## 迁移范围

### 第一层：admin-http-rpc 插件（POST /api/v1/admin/rpc）

启用插件后，以下 WS RPC 方法改为 HTTP 调用。请求/响应格式为 JSON-RPC，与 WS RPC 完全一致，**无需格式转换**。

#### Config 管理

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `config.get` | ✅ | 轮询缓存 fetcher |
| `config.patch` | ✅ | ConfigQueue 内部调用 |
| `config.apply` | ✅ | ConfigQueue 内部调用 |
| `config.set` | ✅ | ConfigQueue 内部调用 |

#### Agent 管理

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `agents.list` | ✅ | 轮询缓存 fetcher、agent-team 模块、workspace 路径解析 |

#### Model 管理

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `models.list` | ✅ | 轮询缓存 fetcher |

#### Cron 定时任务

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `cron.list` | ✅ | 轮询缓存 fetcher |
| `cron.add` / `cron.create` | ✅ | 创建定时任务 |
| `cron.update` | ✅ | 更新定时任务 |
| `cron.remove` / `cron.delete` | ✅ | 删除定时任务 |
| `cron.run` / `cron.trigger` | ✅ | 手动触发 |
| `cron.runs` / `cron.history` | ✅ | 运行记录查询 |

#### 系统状态

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `health` | ✅ | 系统监控页面 |
| `status` | ✅ | Gateway 状态 |

#### Channels

| WS RPC | HTTP 可替换 | 说明 |
|--------|-----------|------|
| `channels.status` | ✅ | 频道状态查询 |
| `channels.logout` | ✅ | 频道登出 |

### 第二层：Gateway 原生 HTTP 端点（已验证源码）

| 端点 | 方法 | 替代 WS RPC | 源码位置 |
|------|------|------------|---------|
| `/sessions/:id/history` | GET | `chat.history`（已迁移） | `sessions-history-http.ts` |
| `/v1/models` | GET | 可替代 `models.list`（但 admin-http-rpc 也能覆盖） | `models-http.ts` |

> `GET /v1/models` 返回 OpenAI 格式 `{ object: "list", data: [...] }`，需要格式转换。
> `admin-http-rpc` 的 `models.list` 返回原始 Gateway 格式，无需转换。**优先使用 admin-http-rpc**。

### 不可迁移（继续走 WS RPC）

| WS RPC | 原因 |
|--------|------|
| `sessions.list` | 不在 admin-http-rpc 白名单中 |
| `sessions.get` | 同上 |
| `sessions.reset` / `sessions.delete` / `sessions.patch` | 同上 |
| `chat.send` | 用户要求不迁移聊天模块 |
| `chat.abort` | 无 HTTP 等价（`/sessions/:id/kill` 是 subagent 专用） |
| `skills.status` | 不在 admin-http-rpc 白名单中 |
| `agents.files.get` / `agents.files.set` / `agents.files.list` | 不在 admin-http-rpc 白名单中 |
| `system-presence` | 不在 admin-http-rpc 白名单中 |
| `session.spawn` | 不在 admin-http-rpc 白名单中 |

### 迁移后通信分布

| 通信方式 | 迁移前 | 迁移后 |
|---------|--------|--------|
| WS RPC | **~95%** | **~15%** |
| HTTP（admin-http-rpc） | 0% | **~70%** |
| HTTP（Gateway 原生） | ~5% | ~15% |

---

## 设计

### 1. admin-http-rpc 插件

已在服务器上启用。端点 `POST /api/v1/admin/rpc`，Bearer token 认证，与 WS 一致。

### 2. 通用 HTTP 工具函数（3 个）

所有 HTTP 工具函数共享 URL 推导和认证逻辑，提取为内部辅助函数：

```javascript
/**
 * 内部：构建 Gateway HTTP 请求的公共选项
 */
function _buildGatewayHttpOptions() {
  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
  const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
  return {
    baseUrl: `${protocol}://${wsUrl.host}`,
    headers: {
      Authorization: `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN || ''}`,
    },
  }
}
```

#### 2.1 `gatewayAdminRpc(method, params, timeoutMs)` — admin-http-rpc 插件调用

通过 `POST /api/v1/admin/rpc` 以 HTTP 方式调用 Gateway RPC 方法。响应格式 `{ ok, payload }` 与 WS RPC 的 payload 等价（`result.payload` 等同于 `gateway.call()` 的返回值）。

```javascript
/**
 * @param {string} method - RPC 方法名（如 'agents.list'）
 * @param {object} params - RPC 参数
 * @param {number} timeoutMs - 超时时间（默认 15s）
 * @returns {Promise<{ok: boolean, payload?: any, error?: string}>}
 */
async function gatewayAdminRpc(method, params = {}, timeoutMs = 15_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL('/api/v1/admin/rpc', baseUrl)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: `rpc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        method,
        params,
      }),
      signal: controller.signal,
    })

    if (!res.ok) {
      return { ok: false, error: `Gateway admin RPC HTTP ${res.status}` }
    }

    const data = await res.json()
    if (data.ok) {
      return { ok: true, payload: data.payload }
    }
    return { ok: false, error: data.error?.message || 'Gateway admin RPC error' }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}
```

#### 2.2 `gatewayHttpGet(path, params)` — Gateway 原生 HTTP GET

用于 Gateway 原生 HTTP 端点（如 `GET /sessions/:id/history`）。重构 `fetchHistoryFromGateway()` 和 `GET /api/chat/history` 中的内联 fetch 代码，复用 URL 推导和认证逻辑。

```javascript
/**
 * @param {string} path - HTTP 路径（如 '/sessions/xxx/history'）
 * @param {object} params - URL 查询参数
 * @param {number} timeoutMs - 超时时间（默认 30s）
 * @returns {Promise<{ok: boolean, data?: any, error?: string}>}
 */
async function gatewayHttpGet(path, params = {}, timeoutMs = 30_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL(path, baseUrl)
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, String(v))
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      headers,
      signal: controller.signal,
    })
    if (!res.ok) return { ok: false, error: `Gateway HTTP ${res.status}` }
    const data = await res.json()
    return { ok: true, data }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}
```

#### 2.3 `gatewayHttpPost(path, body)` — Gateway 原生 HTTP POST

预留，用于未来可能的 Gateway 原生 POST 端点（如 `/v1/chat/completions`）。当前迁移不涉及。

```javascript
/**
 * @param {string} path - HTTP 路径
 * @param {object} body - 请求体
 * @param {number} timeoutMs - 超时时间（默认 30s）
 * @returns {Promise<{ok: boolean, data?: any, error?: string}>}
 */
async function gatewayHttpPost(path, body = {}, timeoutMs = 30_000) {
  const { baseUrl, headers } = _buildGatewayHttpOptions()
  const url = new URL(path, baseUrl)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const res = await fetch(url.toString(), {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    if (!res.ok) return { ok: false, error: `Gateway HTTP ${res.status}` }
    const data = await res.json()
    return { ok: true, data }
  } catch (err) {
    return { ok: false, error: err.message }
  } finally {
    clearTimeout(timer)
  }
}
```

#### 2.4 重构 `fetchHistoryFromGateway()`

将 `fetchHistoryFromGateway()` 中的内联 fetch 替换为 `gatewayHttpGet`，消除 URL 推导和认证逻辑的重复代码。

**改前**（line 356-395）：
```javascript
const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
const gatewayUrl = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, `${protocol}://${wsUrl.host}`)
gatewayUrl.searchParams.set('limit', String(limit))
// ... 手动 fetch
```

**改后**：
```javascript
const result = await gatewayHttpGet(
  `/sessions/${encodeURIComponent(sessionKey)}/history`,
  { limit }
)
if (!result.ok) return []
const messages = extractMessagesFromHistoryPayload(result.data)
```

### 3. 逐个替换 WS RPC 调用

#### 3.1 轮询缓存替换（5 处）

**改前**（以 `configGetPolling` 为例）：
```javascript
const configGetPolling = createPollingCache(19_000, async () => {
  if (!gateway.isConnected) return configGetPolling?.getData() || null
  return gateway.call('config.get', {})
})
```

**改后**：
```javascript
const configGetPolling = createPollingCache(19_000, async () => {
  const result = await gatewayAdminRpc('config.get', {})
  if (!result.ok) return configGetPolling?.getData() || null
  return result.payload
})
```

同样的模式应用于：
- `allSessionsPolling` → **不替换**（`sessions.list` 不在白名单）
- `cronListPolling` → `gatewayAdminRpc('cron.list', { includeDisabled: true })`
- `modelsListPolling` → `gatewayAdminRpc('models.list', {})`
- `skillsStatusPolling` → **不替换**（不在白名单）
- `configGetPolling` → `gatewayAdminRpc('config.get', {})`

#### 3.2 ConfigQueue 替换

ConfigQueue 的 `_execute` 方法内部串行调用 4 次 `gateway.call`：

```
1. gateway.call('config.get', {})          → 拿 sourceConfig + baseHash
2. gateway.call(method, { raw, baseHash }) → config.patch（带 OCC hash）
3. gateway.call('config.get', {})          → 再次拿最新 config + baseHash
4. gateway.call('config.apply', { raw, baseHash }) → apply（带新 hash）
```

全部替换为 `gatewayAdminRpc`。

**⚠️ 关键：错误处理差异**。`gateway.call` 失败时抛异常（ConfigQueue 的 catch 块捕获后判断 OCC/rateLimit 并重试），但 `gatewayAdminRpc` 返回 `{ ok: false, error: "..." }` 不抛异常。直接替换会导致重试逻辑失效。

**替换模式**：每次 `gatewayAdminRpc` 调用后检查 `ok`，失败时 throw 保留 catch 链：

```javascript
// 改前
const payload = await gateway.call('config.get', {})

// 改后
const rpcResult = await gatewayAdminRpc('config.get', {})
if (!rpcResult.ok) throw new Error(rpcResult.error)
const payload = rpcResult.payload
```

这样 ConfigQueue 的 OCC 重试和 rate limit 重试逻辑完整保留。

迁移后 ConfigQueue 的 4 次串行调用变为 **4 次独立 HTTP 请求**，不再占用 WS 连接，不阻塞其他操作。

同时需要去掉 `configQueueExecute` 开头的 `gateway.isConnected` 检查（HTTP 不依赖 WS 连接状态）。

#### 3.3 REST 端点中的直接调用替换

| 后端端点/函数 | 行号 | 当前 WS RPC | 改后 |
|---------|------|------------|------|
| `GET /api/system-info` | 2753 | `gateway.call('health')` | `gatewayAdminRpc('health')` |
| `GET /api/system-info` | 2741 | `gateway.call('system-presence')` | **不替换**（不在白名单） |
| `GET /api/status` | 3399 | `gateway.call('status')` | `gatewayAdminRpc('status')` |
| `GET /api/agents/workspace` | 2849 | `gateway.call('agents.list')` | `gatewayAdminRpc('agents.list')` |
| `POST /api/user/channels/sync-from-gateway` | 2437 | `gateway.call('config.get')` | `gatewayAdminRpc('config.get')`（缓存优先） |
| Channel CRUD | 2209+ | `configQueueExecute` 内部调用 | `gatewayAdminRpc`（通过 ConfigQueue） |
| `logoutChannelFromGateway()` | 2316 | `gateway.call('channels.logout')` | `gatewayAdminRpc('channels.logout')` |
| `backfillAgentModels()` | 225 | `gateway.call('config.get')`（缓存 fallback） | `gatewayAdminRpc('config.get')`（缓存 fallback） |

#### 3.4 Agent Team 模块替换

| 后端端点 | 当前 WS RPC | 改后 |
|---------|------------|------|
| `POST /api/agent-team/migrate-bootstrap` | `gateway.call('agents.list')` | `gatewayAdminRpc('agents.list')` |
| 同上 | `gateway.call('agents.files.get')` | **不替换**（不在白名单） |
| 同上 | `gateway.call('agents.files.set')` | **不替换**（不在白名单） |

#### 3.5 `/api/rpc` 代理端点替换

`POST /api/rpc` 中已迁移方法的分支改为调用 `gatewayAdminRpc`：

**⚠️ 全局守卫改造（line 3413）**：

当前代码在 `/api/rpc` 入口有 `if (!gateway.isConnected) return 503` 全局守卫。迁移后，部分方法走 HTTP 不依赖 WS 连接。需要将全局守卫改为方法级别判断：

```javascript
// 改前（line 3413）
if (!gateway.isConnected) {
  return res.status(503).json({ error: 'Gateway not connected' })
}

// 改后：HTTP 方法不需要 WS 连接
const httpAvailableMethods = new Set([
  'agents.list', 'agents.create', 'agents.update', 'agents.delete',
  'channels.status', 'channels.start', 'channels.stop', 'channels.logout',
  'config.get', 'config.patch', 'config.set', 'config.apply',
  'config.schema', 'config.schema.lookup',
  'cron.list', 'cron.add', 'cron.update', 'cron.remove', 'cron.run', 'cron.runs',
  'cron.status', 'cron.get',
  'models.list', 'models.authStatus',
  'health', 'status',
  // ... 与 adminRpcMethods 合并为统一 Set（见 3.5 末尾）
])

if (!gateway.isConnected && !httpAvailableMethods.has(normMethod)) {
  return res.status(503).json({ error: 'Gateway not connected' })
}
```

> 实际实现时可将 `httpAvailableMethods` 与 `adminRpcMethods` 合并为一个统一的 `HTTP_METHODS` Set，在全局守卫和透传段复用。

**已处理的特定分支（非管理员 + 管理员缓存返回）：**

| 方法 | 改为 |
|------|------|
| `agents.list` | `gatewayAdminRpc('agents.list')`（过滤后返回） |
| `config.get` | 返回 `configGetPolling.getData()`（已通过 HTTP 缓存） |
| `cron.list` | 返回 `cronListPolling.getData()`（已通过 HTTP 缓存） |
| `models.list` | 返回 `modelsListPolling.getData()`（已通过 HTTP 缓存） |
| `cron.add/update/delete/run` | `gatewayAdminRpc(...)` |
| `health / status` | `gatewayAdminRpc(...)` |

**管理员透传段（管理员未匹配方法兜底）：**

当前代码在管理员段末尾直接 `gateway.call(method, params)` 透传。需要加判断：如果方法在 admin-http-rpc 白名单中，走 `gatewayAdminRpc`，否则走 WS RPC：

```javascript
// 管理员透传段
const adminRpcMethods = new Set([
  'agents.create', 'agents.update', 'agents.delete',
  'channels.status', 'channels.start', 'channels.stop', 'channels.logout',
  'config.schema', 'config.schema.lookup',
  'cron.status', 'cron.get',
  'exec.approvals.get', 'exec.approvals.set',
  'exec.approvals.node.get', 'exec.approvals.node.set',
  'models.authStatus',
  'node.list', 'node.describe', 'node.pair.list', 'node.pair.approve', 'node.pair.reject', 'node.pair.remove', 'node.rename',
  'tasks.list', 'tasks.get', 'tasks.cancel',
  'usage.status', 'usage.cost',
  'logs.tail', 'gateway.restart.request',
  'device.pair.list', 'device.pair.approve', 'device.pair.reject', 'device.pair.remove',
  'doctor.memory.status', 'update.status',
])
if (adminRpcMethods.has(normMethod)) {
  const rpcResult = await gatewayAdminRpc(method, params)
  if (!rpcResult.ok) throw new Error(rpcResult.error)
  return res.json({ ok: true, payload: rpcResult.payload })
}
// 不在白名单中的方法仍走 WS RPC
const result = await gateway.call(method, params)
return res.json({ ok: true, payload: result })
```

这样 `agents.create/update/delete`、`channels.*`、`node.*`、`tasks.*` 等写操作也走 HTTP。

**管理员 config 直通段（line 3822）**：

管理员分支中有 `config.patch` / `config.set` / `config.apply` 的直接透传（不经过 ConfigQueue）。当前代码：

```javascript
const isUsage = (normMethod === 'session.usage' || ...)
const result = isUsage
  ? await callGatewayUsage(params)
  : await gateway.call(method, params)
```

这段代码在缓存分支（cron.list / agents.list / config.get / models.list）之后，处理所有未匹配的方法。迁移后，`config.patch/set/apply` 会被 `adminRpcMethods` Set 捕获走 HTTP，但 `sessions.usage`（`isUsage` 分支）仍走 WS RPC 的 `callGatewayUsage()`。需要在 `adminRpcMethods` Set 匹配前保留 `isUsage` 判断：

```javascript
// 优先处理 usage（不走 HTTP，不在白名单）
if (isUsage) {
  const result = await callGatewayUsage(params)
  // ... usage 重建逻辑不变
  return res.json({ ok: true, payload: result })
}

// 然后走 adminRpcMethods 白名单判断（config/agents/channels 等走 HTTP）
if (adminRpcMethods.has(normMethod)) {
  const rpcResult = await gatewayAdminRpc(method, params)
  if (!rpcResult.ok) throw new Error(rpcResult.error)
  return res.json({ ok: true, payload: rpcResult.payload })
}

// 最终 fallback 走 WS RPC
const result = await gateway.call(method, params)
return res.json({ ok: true, payload: result })
```

#### 3.6 后台辅助函数替换

| 函数 | 当前 WS RPC | 改后 |
|------|------------|------|
| `getAgentWorkspace()` | `gateway.call('agents.list')` | `gatewayAdminRpc('agents.list')` |
| `fetchAllAgentSessions()` | `gateway.call('sessions.list', { agentId })` | **不替换**（不在白名单） |
| `autoTitle()` | `gateway.call('chat.history')` / `gateway.call('sessions.history')` | `gatewayHttpGet('/sessions/:key/history')`（详见下方） |
| `backfillAgentModels()` | `configGetPolling.getData() \|\| gateway.call('config.get')` | `configGetPolling.getData() \|\| gatewayAdminRpc('config.get')`（缓存 fallback 走 HTTP） |
| Agent session 批量历史 (line 1904) | `gateway.call('chat.history')` 等 5 种候选方法循环 | `gatewayHttpGet('/sessions/:key/history')`（同 autoTitle 模式） |
| `logoutChannelFromGateway()` | `gateway.call('channels.logout')` | `gatewayAdminRpc('channels.logout')` |

**`autoTitle()` 详细迁移方案**（line 1060-1118）：

当前代码通过 WS RPC `chat.history` / `sessions.history` 获取消息，解析逻辑：
```javascript
// line 1074-1092
historyResult = await gateway.call('chat.history', { sessionKey })
// 解析：Array.isArray(historyResult) 或 historyResult.messages || historyResult.history
```

改用 `gatewayHttpGet('/sessions/:key/history')` 后，HTTP 端点返回的原始格式与 WS RPC 不同。需要自行适配响应格式（不复用 `fetchHistoryFromGateway()` 的标准化逻辑，因为 `autoTitle()` 只需要 `role` + `content`，不需要 `seq`、`msgId` 等字段）：

```javascript
// 改后
const httpResult = await gatewayHttpGet(
  `/sessions/${encodeURIComponent(sessionKey)}/history`,
  { limit: 10 }
)
if (!httpResult.ok) return

// 适配 HTTP 原始响应格式
let messages
const data = httpResult.data
if (Array.isArray(data)) {
  messages = data
} else if (data && typeof data === 'object') {
  messages = data.messages || data.history || data.items || []
}
if (!Array.isArray(messages)) return

// 后续逻辑不变：遍历 messages 找第一条 user message 生成 title
```

**Agent session 批量历史查询迁移方案**（line 1895-1934）：

与 `autoTitle()` 类似，这段代码循环尝试 5 种 WS RPC 候选方法获取 session 历史。全部不在 admin-http-rpc 白名单，但可以用 `gatewayHttpGet('/sessions/:key/history')` 替代：

```javascript
// 改前：循环尝试 5 种 WS RPC 方法
const candidates = [
  { method: 'chat.history', params: { sessionKey } },
  { method: 'sessions.history', params: { sessionKey } },
  // ... 更多候选
]
for (const c of candidates) {
  historyResult = await gateway.call(c.method, c.params)
  if (historyResult) break
}

// 改后：直接用 HTTP
const httpResult = await gatewayHttpGet(
  `/sessions/${encodeURIComponent(sessionKey)}/history`,
  { limit: 50 }
)
if (!httpResult.ok) continue
let messages
const data = httpResult.data
if (Array.isArray(data)) {
  messages = data
} else if (data && typeof data === 'object') {
  messages = data.messages || data.history || data.items || []
}
if (!Array.isArray(messages)) continue
// 后续统计逻辑不变
```

**`logoutChannelFromGateway()` 迁移方案**（line 2313-2324）：

```javascript
// 改前
if (!gateway.isConnected) return
await gateway.call('channels.logout', { channel: channel.channel_type, accountId: channel.agent_id })

// 改后：去掉 isConnected 守卫，改用 HTTP
const rpcResult = await gatewayAdminRpc('channels.logout', {
  channel: channel.channel_type,
  accountId: channel.agent_id,
})
if (!rpcResult.ok) throw new Error(rpcResult.error)
```

**`backfillAgentModels()` fallback 迁移方案**（line 225）：

```javascript
// 改前
const cfgResult = configGetPolling.getData() || await gateway.call('config.get', {})

// 改后：缓存未命中时走 HTTP
let cfgResult = configGetPolling.getData()
if (!cfgResult) {
  const rpcResult = await gatewayAdminRpc('config.get', {})
  cfgResult = rpcResult.ok ? rpcResult.payload : null
}
```

同时需要去掉 `autoTitle()` 入口的 `gateway.isConnected` 守卫（line 1009）：

```javascript
// 改前
if (!sessionKey || !gateway.isConnected) return

// 改后
if (!sessionKey) return
```

#### 3.7 `gateway.isConnected` 清理清单

迁移到 HTTP 的位置需要去掉 `gateway.isConnected` 守卫（HTTP 不依赖 WS 连接状态）。以下为全文件 **25 处**检查的完整处理方案：

| 行号 | 位置 | 处理 |
|------|------|------|
| 219 | `backfillAgentModels()` 入口 | **去掉**（→ `gatewayAdminRpc('config.get')` fallback） |
| 717 | `allSessionsPolling` fetcher | **保留**（`sessions.list` 不迁移） |
| 737 | `cronListPolling` fetcher | **去掉**（→ `gatewayAdminRpc`） |
| 742 | `modelsListPolling` fetcher | **去掉**（→ `gatewayAdminRpc`） |
| 747 | `skillsStatusPolling` fetcher | **保留**（`skills.status` 不迁移） |
| 752 | `configGetPolling` fetcher | **去掉**（→ `gatewayAdminRpc`） |
| 859 | `configQueueExecute()` | **去掉**（ConfigQueue → `gatewayAdminRpc`） |
| 1009 | `_doPushTokenUpdate` 入口 | **保留**（依赖 `sessions.usage` WS RPC） |
| 1547 | agent-team 模块 | **保留**（`agents.files.get/set` 不迁移） |
| 1867 | agent-team 文件列表 | **保留**（`agents.files.list` 不迁移） |
| 1971 | agent-team 修复 | **保留**（`agents.files.get` 不迁移） |
| 2209 | `syncChannelToGateway` | **去掉**（通过 ConfigQueue → `gatewayAdminRpc`） |
| 2278 | `removeChannelFromGateway` | **去掉**（通过 ConfigQueue → `gatewayAdminRpc`） |
| 2314 | `logoutChannelFromGateway` | **去掉**（→ `gatewayAdminRpc('channels.logout')`） |
| 2433 | `sync-from-gateway` 端点 | **去掉**（→ `gatewayAdminRpc('config.get')`） |
| 2567 | 状态展示字符串 | **保留**（纯展示，非守卫） |
| 2740 | `system-presence` 调用 | **保留**（不在白名单） |
| **2752** | **`health` 调用** | **去掉**（→ `gatewayAdminRpc('health')`） |
| **2844** | **`getAgentWorkspace`** | **去掉**（→ `gatewayAdminRpc('agents.list')`） |
| 2867 | agent workspace 端点 | **去掉**（内部调用 `getAgentWorkspace`） |
| **3396** | **`GET /api/status` 端点守卫** | **去掉**（→ `gatewayAdminRpc('status')`） |
| **3413** | **`POST /api/rpc` 全局守卫** | **改为方法级别**（HTTP 方法跳过检查，WS 方法保留，见 3.5 节） |
| 4228 | `POST /api/chat/send` 守卫 | **保留**（`chat.send` 不迁移） |
| 4299 | `POST /api/chat/abort` 守卫 | **保留**（`chat.abort` 不迁移） |
| 4571 | 初始状态赋值 | **保留**（纯展示） |

**统计**：25 处中 **去掉 12 处**，改为方法级别 1 处，保留 12 处（仍依赖 WS RPC 或纯展示）。

---

## 最终迁移统计

### 可以迁移到 HTTP 的（约 70% WS RPC 调用量）

- `config.get` / `config.patch` / `config.apply` / `config.set`
- `agents.list` / `agents.create` / `agents.update` / `agents.delete`
- `models.list` / `models.authStatus`
- `cron.list` / `cron.add` / `cron.update` / `cron.remove` / `cron.run` / `cron.runs` / `cron.get`
- `health` / `status`
- `channels.status` / `channels.logout`
- `node.list` / `node.describe`

### 必须继续走 WS RPC 的（约 15%）

- `sessions.list` / `sessions.get` / `sessions.reset` / `sessions.delete` / `sessions.patch` / `sessions.spawn`
- `chat.send` / `chat.abort`（用户要求不迁移聊天）
- `skills.status`
- `agents.files.get` / `agents.files.set` / `agents.files.list`
- `system-presence`

### 已是 HTTP 的（约 15%）

- `GET /sessions/:id/history`（聊天历史，已迁移）

---

## 验证计划

### Phase 1：验证插件可用 ✅ 已完成（2026-05-31）

```bash
# 已验证通过的方法：
health       → ok: true，返回完整 Gateway 健康状态
agents.list  → ok: true，返回 424 个 Agent
config.get   → ok: true，返回含 raw 字段
models.list  → ok: true，返回含 models 字段
```

### Phase 2：后端代码迁移

1. 添加 `gatewayAdminRpc()` 工具函数
2. 替换轮询缓存 fetcher（config、cron、models）
3. 替换 ConfigQueue 内部调用
4. 替换 REST 端点中的直接 `gateway.call()` 调用
5. 重构 `fetchHistoryFromGateway()` 复用 HTTP 工具函数

### Phase 3：功能验证

1. 启动后端，观察轮询缓存日志，确认从 HTTP 拿到数据
2. 打开模型管理，确认模型列表正常
3. 打开定时任务，确认 CRUD 正常
4. 打开系统监控，确认 health 数据正常
5. 打开工作台对话，确认会话列表正常（仍走 WS RPC）
6. 发送消息并取消，确认聊天功能正常（仍走 WS RPC）

## 风险

| 风险 | 缓解 |
|------|------|
| admin-http-rpc 响应格式与 WS RPC 不一致 | 两者共用 `dispatchGatewayMethod()`，返回值完全一致 |
| ConfigQueue OCC hash 透传异常 | `gatewayAdminRpc` 直接透传 params 和 payload，hash 字段不变，已确认 |
| ConfigQueue 重试逻辑失效 | `gatewayAdminRpc` 返回 `{ ok: false }` 不抛异常，替换时需检查 `ok` 并 throw，保留 catch 链 |
| Gateway 重启影响用户 | 安排低峰期操作 |

## 文件变更

| 文件 | 变更 |
|------|------|
| `server/index.js` | 新增 `_buildGatewayHttpOptions`、`gatewayAdminRpc`、`gatewayHttpGet`、`gatewayHttpPost`；替换 ~25 处 `gateway.call()` 调用（47 处中迁移 25 处，22 处保留 WS RPC）；重构 `fetchHistoryFromGateway()` 复用 `gatewayHttpGet`；去掉 12 处 + 改造 1 处 `gateway.isConnected` 检查（共 25 处）；`autoTitle()` 和 agent session 批量历史改用 `gatewayHttpGet` 并适配响应格式；`logoutChannelFromGateway()` 改用 `gatewayAdminRpc`；`backfillAgentModels()` fallback 改用 `gatewayAdminRpc`；`GET /api/status` 改用 `gatewayAdminRpc`；`adminRpcMethods` 白名单补齐 `exec.approvals.*` 并修正 `models.authStatus` 大小写；`/api/rpc` 全局守卫改为方法级别判断 |
| `docs/gateway-communication-audit/README.md` | 更新审计报告 |
