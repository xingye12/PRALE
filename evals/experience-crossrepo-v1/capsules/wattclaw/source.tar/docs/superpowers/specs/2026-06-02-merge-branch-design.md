# WattClaw 双轨分支合并设计文档

> 日期：2026-06-02
> 分支：`feature/wattclaw-ultimate-merge`
> 方案：A（B 底座 + A 功能移植）
> 审阅：对抗性审阅 v2（已修正 3 项错误假设）

---

## 1. 背景

WattClaw 项目存在两个分叉分支：

- **wattclaw-main**（A）：包含最新的业务功能，使用传统 WS RPC 通信架构
- **wattclaw-http**（B）：从 main 分叉后将通信层重构为 HTTP REST + WS 混合架构，包含 12 个性能优化锚点和 PostgreSQL 本地消息存储

两套代码的通信架构完全异构，禁止盲目 git merge。

## 2. 合并策略

**以 B（wattclaw-http）为代码底座**，增量移植 A 的独有业务功能到 B 的 HTTP 架构上。

核心理由：
1. B 的 12 个性能优化锚点是最难重建的部分，原生保留零风险
2. B 的 HTTP REST 通信架构已完整，不需要重写
3. A 的独有功能多数是纯 UI 组件，与通信层解耦，移植成本极低

## 3. 分层策略

### 3.1 不动层（B 原生保留）

以下代码不做任何修改：

| 模块 | 文件 | 说明 |
|------|------|------|
| PG 消息存储 | `server/message-store.js` | Advisory lock + batchReplace + upsert |
| 回填队列 | `server/backfill-queue.js` | 两阶段回填 + preload |
| Chat HTTP 客户端 | `src/api/chat-client.ts` | send/abort/history |
| Usage HTTP 客户端 | `src/api/usage-client.ts` | getSessionsUsage |
| Chat 类型契约 | `src/api/types/chat-contract.ts` | Gateway Chat API 类型 |
| 通信层 | `server/index.js` 的 gatewayAdminRpc / HTTP_RPC_METHODS / REST 端点 | HTTP REST 架构 |
| 缓存机制 | createPollingCache / allSessionsPolling / ConfigQueue / Token Debounce | 性能优化 |
| 流式消息 | `workspace.ts` StreamState / completion 重建 blocks / PG 兜底 | 消息系统 |

### 3.2 移植层（A → B）

#### P0 批次：基础设施

| # | 功能 | 类型 | 通信依赖 | 改动文件 |
|---|------|------|---------|---------|
| I1 | i18n keys（19 个文件面板文案） | 新功能 | ❌ | `src/i18n/messages/zh-CN.ts` |

#### P1 批次：纯 UI 组件（零适配）

| # | 功能 | 类型 | 通信依赖 | 改动文件 |
|---|------|------|---------|---------|
| F4 | Avatar fallback 指令（v-avatar-fallback） | 新功能 | ❌ | 追加到 B 的 `src/utils/agent-avatar.ts`（~14 行）+ `src/main.ts` 注册（1 行）。A 在 14 个组件中使用此指令，移植时需在这些组件的 `<img>` 标签添加 `v-avatar-fallback` |
| F5 | AI 内容甄别提示 | 新功能 | ❌ | `src/views/workspace/WorkspacePage.vue` |
| F9 | Agent 模板 soul_md 文件清单指令 | 新功能 | ❌ | `src/views/agent-team/agent-templates.ts` |
| F7 | 侧边栏样式覆盖 | UI 改进 | ❌ | `src/components/layout/DefaultLayout.vue` |
| F8 | 创建数字员工按钮样式 | UI 改进 | ❌ | `src/views/agent-team/AgentTeamPage.vue` |
| F13 | SkillsTab/AgentEditPage 懒加载技能 | 优化 | ❌ | `SkillsTab.vue` + `AgentEditPage.vue` |
| F14 | SkillPickerPopover 宽度 | UI 改进 | ❌ | `SkillPickerPopover.vue` |

#### P2 批次：需注意的前端功能

| # | 功能 | 类型 | 通信依赖 | 注意事项 | 改动文件 |
|---|------|------|---------|---------|---------|
| F2 | 执行计时器（elapsedMs + localStorage） | 新功能 | ⚠️ 条件 | 依赖 `workspaceStore.sending` 的触发时机。B 的 `sending` 是基于 `sessionSendingMap` 的 computed，已验证签名一致。需确认 B 的 HTTP 架构下 `sending` 的 true→false 时序与 A 相同 | `src/views/workspace/MessageList.vue`（~65 行内联） |
| F12 | 文件面板自动打开 + 刷新 | 新功能 | ❌ | B 已有 `filePanelRef` 和 `filePanelAutoOpen`，但只打开不刷新。需额外加 `refreshTree()` 调用 | `src/views/workspace/WorkspacePage.vue` |
| F1 | ChatFilePanel 完整文件管理 | 新功能 | ⚠️ REST | **不是零通信依赖**：有 11 个 REST API 调用（/api/files/*），但 B 后端已有全部 7 个匹配端点。目录下载格式差异（A: tar.gz vs B: zip）需确认是否影响。需同时移植 `ChatFileTreeNode.vue` 的 contextmenu + drag 事件 | `ChatFilePanel.vue`（~569 行）+ `ChatFileTreeNode.vue` |

#### P3 批次：需 store 层联动适配

| # | 功能 | 类型 | 通信依赖 | 适配说明 | 改动文件 |
|---|------|------|---------|---------|---------|
| F3 | Token cacheRead/cacheWrite 详情展示 | 新功能 | ⚠️ Store | **不是"只移植 UI"**。B 的 `session.ts` `refreshSessionTokenUsage` 只提取 input/output，**主动丢弃** cacheRead/cacheWrite。需三层联动：(1) Store 层扩展 `refreshSessionTokenUsage` (~15 行) (2) ChatPage 类型扩展 (~5 行) (3) UI 增加展示行 (~30 行) | `src/stores/session.ts` + `ChatPage.vue` |
| F11 | Cron 多 agentId 获取 | 新功能 | ⚠️ 轻量 | B 的 `cron.ts` 已支持 `{agentIds?}` 参数，且 B 是 A 的超集。只需在 `CronPage.vue` 传入 agentIds | `src/views/cron/CronPage.vue` |

### 3.3 忽略层（B 有更优替代）

| A 的功能 | B 的替代方案 | 原因 |
|---------|------------|------|
| `_adminSessionsCache`（手动 Map） | `allSessionsPolling`（9s TTL stale-while-revalidate） | B 自动刷新，无过期风险 |
| `_sessionKeysCache`（内存 Set） | 直接 DB 查询 `getUserOwnedSessionKeys()` | 无缓存一致性问题 |
| SSH 远程执行模式（ssh2） | 本地执行（colocated） | 用户确认不需要 |
| History messageLimit 截断（slice） | PG SQL LIMIT + Gateway HTTP limit 参数 | 数据库级分页更优 |
| `fetchUsageForAgentIds` 多 Agent 聚合 | B 无状态 `callGatewayUsage()` 单次调用 | B 的 BFF 代理更简洁 |

### 3.4 技术债记录

以下不兼容点不影响本次移植，但应记录供未来参考：

| 接口 | 差异 | 影响 |
|------|------|------|
| `session.ts fetchSessions()` | A 接受 `{agentId?}` 过滤，B 不接受参数 | 本次移植的 13 个功能无调用方，但未来如有按 agent 过滤 session 的需求需适配 |
| `cron.ts fetchJobs()` | B 已支持 `{agentIds?}`，A 不支持 | B 是超集，正向兼容 |

## 4. 关键适配设计

### 4.1 Token cacheRead/cacheWrite（F3）— 三层联动

**对抗性审阅发现**：B 的 `session.ts` store 中 `refreshSessionTokenUsage` 只提取 `input` + `output`，主动丢弃 `cacheRead`/`cacheWrite`。

**修正方案**：

```
层次 1: Store 层（session.ts）
  → refreshSessionTokenUsage 扩展提取 cacheRead/cacheWrite/cacheReadCost/cacheWriteCost
  → updateSessionTokenUsage 的 payload 增加这 4 个字段

层次 2: 类型层（ChatPage.vue 内部或独立文件）
  → tokenUsage 类型增加 cacheRead/cacheWrite/cacheReadCost/cacheWriteCost

层次 3: UI 层（ChatPage.vue tokenBreakdown 模板）
  → 增加 cacheRead + cacheWrite 两行展示
```

**后端无需修改**：`callGatewayUsage()` 已透传完整数据，`recomputeUsageFromSessions()` 已累加 cacheRead/cacheWrite。

**注意点**：
- Dashboard 和 ModelsPage 不需要改动（两边已对等）
- precomputed 格式下 `byModel` 中的 cacheRead/cacheWrite 为 0（Gateway `modelDaily` 数据源限制），不影响 ChatHeader 的单会话展示

### 4.2 ChatFilePanel 完整文件管理（F1）

**对抗性审阅发现**：不是"零通信依赖"，有 11 个 REST API 调用。

**但 B 后端已完全兼容**：

| 端点 | A | B | 差异 |
|------|---|---|------|
| GET /api/files/list | ✅ | ✅ | 无 |
| POST /api/files/upload | ✅ | ✅ | 无 |
| POST /api/files/delete | ✅ | ✅ | 无 |
| POST /api/files/rename | ✅ | ✅ | 无 |
| POST /api/files/mkdir | ✅ | ✅ | 无 |
| GET /api/files/get | ✅ | ✅ | ⚠️ 目录下载 A:tar.gz B:zip |
| GET /api/agents/workspace | ✅ | ✅ | 无 |

**移植操作**：
1. 将 A 的 `ChatFilePanel.vue` 完整覆盖 B 的（B 是只读版本）
2. 移植 `ChatFileTreeNode.vue` 的 contextmenu + drag/drop 事件处理
3. 确认 B 的 `apiPath()` 工具函数存在（已确认存在）
4. 注意目录下载格式差异：合并后使用 B 的 zip 格式（更通用）

### 4.3 Cron 多 agentId（F11）

**方案**：B 的 `cron.ts` 已支持 `{agentIds?}` 参数，只需在 `CronPage.vue` 传入。

```typescript
// CronPage.vue
const agentIds = computed(() =>
  agentTeamStore.agentList.map(a => a.agentId).filter(Boolean)
)

// 调用时传入
await cronStore.fetchJobs({ agentIds: agentIds.value })
```

**无后端修改**：B 的 `gatewayAdminRpc('cron.list')` 已在 HTTP_RPC_METHODS 白名单中。

### 4.4 执行计时器（F2）— 触发时序验证

**关键依赖**：`workspaceStore.sending` 的 true→false 时序。

**已验证**：两边的 `sending` 都是 `computed(() => sessionSendingMap.value.get(activeSessionKey.value) ?? false)`。B 在 HTTP 架构下通过 SSE 事件设置 sending 状态（fire-and-forget 后立即设置 sending=true，收到 lifecycle end 时设 false），时序逻辑与 A 一致。

**移植操作**：
1. 将 A 的 `elapsedMs` 相关代码（~65 行）移植到 B 的 `MessageList.vue`
2. 保留 `onUnmounted(() => pauseTimer())` 清理逻辑
3. `localStorage` key `wattclaw:send-start:${sessionKey}` 保持不变

## 5. 执行计划

### Phase 1：验证 B 底座完整性

1. 启动 wattclaw-http 分支
2. 验证核心功能：发送消息、历史加载、会话切换、Token 显示
3. 确认所有性能优化锚点正常工作

### Phase 2：移植 P0 + P1（纯 UI，零风险）

4. 移植 i18n keys（19 个）
5. 移植 Avatar fallback 指令（追加到 B 的 agent-avatar.ts + main.ts 注册）
6. 移植 AI 免责声明（WorkspacePage.vue）
7. 移植 Agent 模板 prompt（agent-templates.ts）
8. 移植侧边栏样式（DefaultLayout.vue）
9. 移植创建按钮样式（AgentTeamPage.vue）
10. 移植 SkillsTab 懒加载（SkillsTab.vue + AgentEditPage.vue）
11. 移植 SkillPickerPopover 宽度（SkillPickerPopover.vue）

### Phase 3：移植 P2（需注意的前端功能）

12. 移植执行计时器（MessageList.vue，~65 行，验证 sending 时序）
13. 移植文件面板自动打开 + 刷新（WorkspacePage.vue）
14. 移植 ChatFilePanel 完整文件管理（ChatFilePanel.vue + ChatFileTreeNode.vue）

### Phase 4：移植 P3（需 store 层联动）

15. 移植 Token cacheRead/cacheWrite 详情（session.ts store 扩展 + ChatPage.vue 类型+UI）
16. 移植 Cron 多 agentId 获取（CronPage.vue）

### Phase 5：验证

17. TypeScript 类型检查（零 Error）
18. 功能验证：每个移植功能逐一测试
19. 性能验证：确保 12 个性能锚点无回退
20. 视觉回归检查

## 6. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| ChatFilePanel 目录下载格式差异（tar.gz vs zip） | 低 | 低 | 统一使用 B 的 zip 格式，前端无需适配 |
| 执行计时器 sending 时序在 HTTP 下不一致 | 低 | 中 | 移植后实际测试发送→完成流程，验证计时正确停止 |
| Token store 扩展引入类型错误 | 低 | 中 | TypeScript 编译验证 + 手动检查 cacheRead/cacheWrite 值 |
| Cron 并行请求触发 Gateway 限流 | 低 | 中 | Promise.allSettled 容错 + 50ms 间隔 |
| Avatar fallback 指令在 B 组件中遗漏 | 低 | 低 | grep `v-avatar-fallback` 确认所有 A 使用点 |
| 移植遗漏导致功能缺失 | 低 | 低 | 逐项核对移植清单 + 功能测试 |

## 7. 成功标准

1. **性能不回退**：12 个性能锚点行为不变
2. **功能完整**：A 的 13 个独有功能全部可用
3. **通信统一**：不存在 RPC/HTTP 平行异构代码
4. **类型安全**：TypeScript 编译零 Error，无 `any` 类型断言
5. **代码收敛**：相同功能无重复实现

## 8. 对抗性审阅修正记录

| 修正项 | 原假设 | 审阅结论 | 修正措施 |
|--------|--------|---------|---------|
| ChatFilePanel 通信依赖 | ❌ 零通信依赖 | ⚠️ 11 个 REST API 调用，但 B 后端已完全兼容 | 修正描述，标注 REST 依赖 |
| Token cacheRead/cacheWrite | ❌ 只移植 UI | ⚠️ B store 主动丢弃 cacheRead/cacheWrite，需 store 层扩展 | 修正为三层联动方案 |
| 执行计时器 | ❌ 零依赖 | ⚠️ 条件通过：依赖 `sending` 触发时序一致 | 修正为条件通过，标注验证要求 |
| session.ts fetchSessions 签名 | 未分析 | A 接受 `{agentId?}`，B 不接受 | 记录为技术债，不影响本次移植 |

## 9. 关联记忆

- [[project-http-ws-separation-v2]] — HTTP+WS 分离重构最终方案
- [[project-postgresql-message-store]] — PG 本地消息存储架构
- [[feedback-streaming-text-block-duplication]] — 流式消息系统 Bug 修复
- [[feedback-gateway-patterns]] — Gateway RPC 调用约束
