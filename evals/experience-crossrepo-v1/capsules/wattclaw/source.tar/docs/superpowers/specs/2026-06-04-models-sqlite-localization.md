# 模型列表 SQLite 本地化重构设计

**日期**: 2026-06-04 | **状态**: 已确认设计

## 1. 背景

当前模型列表读取路径依赖 Gateway：

```text
前端 wsStore.rpc.listModels()
  → 后端 RPC proxy / models.list 拦截
  → getModelsList()
  → gatewayAdminRpc('models.list')
  → Gateway 返回模型列表
```

这条路径有三个问题：

1. 冷启动或缓存失效时会访问 Gateway，增加 100-500ms 延迟。
2. 前端存在多个模型状态源：`useModelStore` 和 `useAgentStore` 都维护 `models`。
3. 后端用 RPC 拦截续命旧路径，不是稳定的本地读模型能力。

本次重构目标是从根本上收敛模型数据流：**模型读取只走 SQLite，前端只保留一个模型 Store，Gateway 只作为同步来源。**

## 2. 目标

1. 新增 `models` 表，作为模型列表的本地 SSOT。
2. 废弃 `model_remarks`，将 `remark` 合并进 `models` 表。
3. 保留 `user_model_providers`，通过 `provider_id` 关联 `models.provider`。
4. 新增 REST API：`GET /api/models` 直接读 SQLite。
5. 新增 Admin 同步 API：`POST /api/models/sync` 从 Gateway 同步到 SQLite。
6. 前端 `useModelStore` 成为唯一模型状态源。
7. 删除 `useAgentStore` 内部模型状态。
8. 删除 `models.list` / `models.get` RPC 拦截与 `_modelsCache` 内存缓存。

## 3. DB Schema

### 3.1 新增 `models` 表

```sql
CREATE TABLE IF NOT EXISTS models (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  label TEXT DEFAULT '',
  family TEXT DEFAULT '',
  enabled INTEGER DEFAULT 1,
  available INTEGER DEFAULT 1,
  description TEXT DEFAULT '',
  context_window INTEGER DEFAULT 0,
  capabilities TEXT DEFAULT '[]',
  remark TEXT DEFAULT '',
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now')*1000)
);

CREATE INDEX IF NOT EXISTS idx_models_provider ON models(provider);
```

### 3.2 字段语义

| 字段 | 语义 |
|------|------|
| `id` | 模型唯一 ID，例如 `openai/gpt-4o` |
| `provider` | provider ID，例如 `openai` |
| `label` | 展示名 |
| `family` | 模型族 |
| `enabled` | 管理员是否启用，人工控制 |
| `available` | Gateway 当前是否返回，系统同步控制 |
| `description` | 描述 |
| `context_window` | 上下文窗口 |
| `capabilities` | JSON array |
| `remark` | 管理员备注，原 `model_remarks.remark` |
| `updated_at` | 本地更新时间 |

关键点：

- `enabled` 和 `available` 必须分开。
- Gateway 不再返回某模型时，只设置 `available = 0`。
- 不用 `enabled = 0` 表示 Gateway 不存在，避免混淆管理员禁用和运行时不可用。

### 3.3 迁移 `model_remarks`

`model_remarks` 不再作为独立表使用。迁移时将 remark 合并到 `models.remark`。

```sql
INSERT INTO models (id, provider, remark)
  SELECT model_id, provider_id, remark FROM model_remarks
  WHERE true
  ON CONFLICT(id) DO UPDATE SET remark = excluded.remark;
```

保守做法：不立即删除原表，先 rename 为 `model_remarks_deprecated`，保留一个版本观察。

```sql
ALTER TABLE model_remarks RENAME TO model_remarks_deprecated;
```

### 3.4 与 `user_model_providers` 的关系

```text
user_model_providers.provider_id  ──→ models.provider
```

`user_model_providers` 继续负责 provider 配置：API key、endpoint、remark、description、primary 等。`models` 负责 provider 下的模型清单。

## 4. 后端架构

### 4.1 分层原则

不把 SQLite 读写塞进 `gateway-client.js`。

```text
GatewayClient
  只负责 Gateway I/O

ModelManager
  只负责模型归一化、SQLite 读写、同步逻辑

ModelsHandler
  只负责 HTTP API
```

### 4.2 建议模块

```text
server/model-manager.js
server/handlers/models.js
```

### 4.3 `server/model-manager.js`

职责：

```text
listModelsFromDb()
normalizeModelItem()
normalizeModelList()
syncModelsFromGateway()
upsertModels()
markMissingModelsUnavailable()
```

核心逻辑：

```text
syncModelsFromGateway()
  → gatewayAdminRpc('models.list')
  → normalizeModelList(payload)
  → 读取现有 models.remark / models.enabled
  → 逐行 INSERT OR REPLACE / UPSERT
  → Gateway 返回的模型 available = 1
  → Gateway 未返回的旧模型 available = 0
  → 返回 { ok, count }
```

同步策略采用**轻量 upsert + 软失效**：

```text
不 DELETE 全表
不物理删除旧模型
不重置人工 remark
不重置管理员 enabled
```

### 4.4 `server/handlers/models.js`

新增路由：

```text
GET /api/models
  → authMiddleware
  → listModelsFromDb()
  → 返回 ModelInfo[]

POST /api/models/sync
  → authMiddleware + adminMiddleware
  → syncModelsFromGateway()
  → 返回同步数量
```

### 4.5 `server/core/gateway-client.js`

删除模型列表缓存职责：

```text
删除 _modelsCache
删除 getModelsList()
删除 invalidateModelsCache()
```

保留底层能力：

```text
gatewayAdminRpc(method, params)
```

### 4.6 `server/index.js`

修改：

1. 注册 `createModelRoutes(app)`。
2. Gateway connected 时调用 `syncModelsFromGateway()`。
3. 删除普通用户分支里的 `models.list` / `models.get` RPC 拦截。
4. 删除 admin 分支里的 `models.list` / `models.get` RPC 拦截。
5. 删除 `invalidateModelsCache()` import 和调用。

删除拦截是为了根治旧路径：模型读取必须通过正式 REST API，而不是 RPC proxy。

## 5. 数据流

### 5.1 旧读路径

```text
modelStore.fetchModels()
  → wsStore.rpc.listModels()
  → 后端 RPC proxy
  → models.list 拦截
  → getModelsList()
  → gatewayAdminRpc('models.list')
```

### 5.2 新读路径

```text
modelStore.fetchModels()
  → GET /api/models
  → handlers/models.js
  → model-manager.listModelsFromDb()
  → SELECT * FROM models
  → ModelInfo[]
```

### 5.3 Gateway 同步路径

```text
Gateway connected
  → model-manager.syncModelsFromGateway()
  → gatewayAdminRpc('models.list')
  → normalize
  → upsert models
  → mark missing as available = 0
```

### 5.4 Admin 手动同步路径

```text
Admin 点击「同步模型列表」
  → POST /api/models/sync
  → syncModelsFromGateway()
  → 返回同步结果
```

Provider 增删改不直接触发同步。原因：

- Provider config 同步到 Gateway 后，Gateway 动态发现模型需要时间。
- 立即 backfill 可能拿到旧模型列表。
- 手动同步按钮语义更清晰，避免异步时序补丁。

## 6. 前端架构

### 6.1 唯一模型 Store

只保留：

```text
src/stores/model.ts
  models
  loading
  lastError
  fetchModels()
```

`fetchModels()` 改为：

```text
GET /api/models
```

### 6.2 删除 `useAgentStore` 模型状态

从 `src/stores/agent.ts` 删除：

```text
models ref
fetchModels()
initialize() 中 await fetchModels()
return.models
return.fetchModels
```

`useAgentStore` 不再关心模型列表。

### 6.3 调用点收敛

| 文件 | 当前 | 改后 |
|------|------|------|
| `src/stores/model.ts` | `wsStore.rpc.listModels()` | `GET /api/models` |
| `src/stores/agent.ts` | 独立 `models` + `fetchModels()` | 删除，统一用 `useModelStore` |
| `src/views/agents/AgentsPage.vue` | `agentStore.fetchModels()` | `modelStore.fetchModels()` |
| `src/views/Dashboard.vue` | `wsStore.rpc.listModels()` | `modelStore.fetchModels()` 或 `GET /api/models` |
| `src/stores/workspace.ts` | 已经用 `useModelStore` | 保持 |
| `src/views/cron/CronPage.vue` | 已经用 `useModelStore` | 保持 |

全局原则：任何前端模型列表读取都不能再调用 `wsStore.rpc.listModels()`。

## 7. API 返回格式

`GET /api/models` 返回：

```json
{
  "ok": true,
  "models": [
    {
      "id": "openai/gpt-4o",
      "label": "GPT-4o",
      "provider": "openai",
      "family": "gpt-4o",
      "enabled": true,
      "available": true,
      "description": "",
      "contextWindow": 128000,
      "capabilities": ["text", "vision"],
      "remark": ""
    }
  ]
}
```

为了贴近现有 `ModelInfo`，后端读取时把 `context_window` 映射为 `contextWindow`，把 `capabilities` JSON 字符串解析为数组。

## 8. 改动清单

### 8.1 后端

| 文件 | 改动 |
|------|------|
| `server/database.js` | 新增 `models` 表；迁移 `model_remarks` |
| `server/model-manager.js` | 新增模型 SQLite 仓库与 Gateway 同步逻辑 |
| `server/handlers/models.js` | 新增 `GET /api/models` 和 `POST /api/models/sync` |
| `server/index.js` | 注册 models routes；Gateway connected 时同步；删除 `models.list` RPC 拦截 |
| `server/core/gateway-client.js` | 删除 `_modelsCache` / `getModelsList()` / `invalidateModelsCache()` |

### 8.2 前端

| 文件 | 改动 |
|------|------|
| `src/stores/model.ts` | 改为 HTTP REST 读取 `/api/models` |
| `src/stores/agent.ts` | 删除模型状态和 `fetchModels()` |
| `src/views/agents/AgentsPage.vue` | 改用 `useModelStore.fetchModels()` |
| `src/views/Dashboard.vue` | 删除 `wsStore.rpc.listModels()`，改走本地模型 API / store |

### 8.3 不改

- Gateway 协议不改。
- `user_model_providers` 表不改。
- `src/api/rpc-client.ts` 可保留 `listModels()` 兼容类型定义，但前端不再调用。

## 9. 验证标准

- [ ] `GET /api/models` 返回 < 10ms。
- [ ] 全局 grep 不再出现前端 `wsStore.rpc.listModels()` 调用。
- [ ] `useAgentStore` 不再维护 `models` 状态。
- [ ] `model_remarks` 数据迁移到 `models.remark`。
- [ ] Gateway connect 后自动同步模型表。
- [ ] Admin 可手动触发 `POST /api/models/sync`。
- [ ] Gateway 未返回的旧模型被标记 `available = 0`，不被物理删除。
- [ ] `enabled` 不被同步逻辑误改。
- [ ] 不破坏现有 WebSocket 连接和消息收发机制。
