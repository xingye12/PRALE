# Session Usage 本地缓存设计方案

> 日期: 2026-06-04
> 背景: P0 故障 — WebSocket RPC `sessions.usage` 导致 Gateway 宕机
> 目标: 将 `sessions.usage` 数据缓存到本地 SQLite，消除 WebSocket RPC 高频调用

---

## 一、问题分析

### 1.1 当前架构痛点

```
用户登录/刷新仪表盘 → 后端调用 callGatewayUsage() → WebSocket RPC → Gateway
                              ↓
                        每 17s skillsStatusPolling 也走 WebSocket
                              ↓
                        Gateway 单线程事件循环阻塞 → 宕机
```

### 1.2 `sessions.usage` 调用点

| 调用点 | 频率 | 风险 |
|--------|------|------|
| `/api/sessions/usage` | 页面加载时 | 高 |
| `/api/usage-totals` | 页面加载时 | 高 |
| `/api/admin/user-usage` | 管理员页面 | 中 |
| `_doPushTokenUpdate` | 每次聊天后（5s debounce） | 高 |
| `agent-team/stats` | 页面加载时 | 中 |

### 1.3 Gateway 限制

- `sessions.usage` **不在** `admin-http-rpc` 白名单中（已验证）
- 无法通过 HTTP RPC 调用，只能走 WebSocket RPC
- **不能修改 Gateway**（部署权限/版本限制）

---

## 二、设计目标

1. **消除高频 WebSocket RPC 调用** — 仪表盘/AgentTeam 等页面不再直接调用 Gateway
2. **保持数据最终一致性** — 聊天结束后同步更新本地缓存
3. **支持多用户隔离** — 利用现有 `user_sessions.user_id` 字段
4. **最小化改动** — 复用现有 `user_sessions` 表，不新建表

---

## 三、架构设计

### 3.1 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                        WattClaw 后端                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │   Dashboard  │  │  AgentTeam   │  │  _doPushTokenUpdate│  │
│  │    页面      │  │    页面      │  │    聊天结束后     │
│  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘  │
│         │                 │                    │            │
│         └─────────────────┼────────────────────┘            │
│                           ▼                                 │
│              ┌────────────────────────┐                     │
│              │   SessionUsageCache    │                     │
│              │   (内存缓存 + SQLite)   │                     │
│              └───────────┬────────────┘                     │
│                          │                                  │
│         ┌────────────────┼────────────────┐                │
│         ▼                ▼                ▼                │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │ user_sessions│  │  Gateway    │  │   SSE 事件   │       │
│  │  (SQLite)   │  │ (WebSocket) │  │   实时更新   │       │
│  └─────────────┘  └─────────────┘  └─────────────┘       │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 数据流

```
正常查询（仪表盘/AgentTeam）：
  前端请求 → 后端查询 SessionUsageCache → 返回本地数据（<10ms）

聊天结束同步：
  聊天结束 → _doPushTokenUpdate → callGatewayUsage → Gateway
                                        ↓
                                   解析返回结果
                                        ↓
                                   更新 user_sessions 表
                                        ↓
                                   更新内存缓存
```

---

## 四、数据库设计

### 4.1 表结构变更（`user_sessions`）

复用现有 `user_sessions` 表，增加以下字段：

```sql
-- Token 用量字段
ALTER TABLE user_sessions ADD COLUMN token_input INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN token_output INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN token_cache_read INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN token_cache_write INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN token_total INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN cost_total REAL DEFAULT 0;

-- 消息统计字段
ALTER TABLE user_sessions ADD COLUMN msg_total INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN msg_user INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN msg_assistant INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN msg_tool_calls INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN msg_tool_results INTEGER DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN msg_errors INTEGER DEFAULT 0;

-- 最后同步时间（用于缓存过期判断）
ALTER TABLE user_sessions ADD COLUMN usage_synced_at INTEGER;

-- 工具使用统计（JSON 格式，存储 tools 数组）
ALTER TABLE user_sessions ADD COLUMN tool_usage_json TEXT DEFAULT '{}';
```

### 4.2 索引优化

```sql
-- 按用户查询用量统计（仪表盘聚合）
CREATE INDEX IF NOT EXISTS idx_user_sessions_usage_user_id ON user_sessions(user_id, usage_synced_at);

-- 按 agent 查询用量统计（AgentTeam 页面）
CREATE INDEX IF NOT EXISTS idx_user_sessions_usage_agent_id ON user_sessions(agent_id, usage_synced_at);
```

### 4.3 完整表结构

```sql
CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  session_key TEXT NOT NULL,
  agent_id TEXT,
  label TEXT,
  channel TEXT,
  
  -- Token 用量
  token_input INTEGER DEFAULT 0,
  token_output INTEGER DEFAULT 0,
  token_cache_read INTEGER DEFAULT 0,
  token_cache_write INTEGER DEFAULT 0,
  token_total INTEGER DEFAULT 0,
  cost_total REAL DEFAULT 0,
  
  -- 消息统计
  msg_total INTEGER DEFAULT 0,
  msg_user INTEGER DEFAULT 0,
  msg_assistant INTEGER DEFAULT 0,
  msg_tool_calls INTEGER DEFAULT 0,
  msg_tool_results INTEGER DEFAULT 0,
  msg_errors INTEGER DEFAULT 0,
  
  -- 工具使用统计（JSON）
  tool_usage_json TEXT DEFAULT '{}',
  
  -- 同步时间戳
  usage_synced_at INTEGER,
  
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

---

## 五、核心模块设计

### 5.1 SessionUsageCache 模块

**职责：**
- 管理内存缓存和 SQLite 持久化
- 提供查询接口（按用户、按 Agent、按会话）
- 处理缓存过期和刷新

**接口设计：**

```javascript
// server/core/session-usage-cache.js

class SessionUsageCache {
  // 初始化：从数据库加载所有 usage 数据到内存
  async init()
  
  // 查询指定用户的所有会话用量（仪表盘用）
  getUserUsage(userId)
  
  // 查询指定 Agent 的所有会话用量（AgentTeam 用）
  getAgentUsage(agentId)
  
  // 查询指定会话的用量
  getSessionUsage(sessionKey)
  
  // 更新指定会话的用量（从 Gateway 同步后调用）
  updateSessionUsage(sessionKey, usageData)
  
  // 批量更新多个会话用量（_doPushTokenUpdate 用）
  batchUpdateUsage(usageResult)
  
  // 获取聚合统计（仪表盘 totals）
  getAggregatedUsage(userId, options)
  
  // 检查缓存是否过期
  isExpired(sessionKey, maxAgeMs = 300000)
}
```

### 5.2 数据同步模块

**职责：**
- 在 `_doPushTokenUpdate` 中同步 Gateway 数据到本地
- 解析 `sessions.usage` 返回格式

**同步流程：**

```javascript
async function syncSessionUsageToLocal(sessionKey) {
  // 1. 从 Gateway 获取最新用量（保留 WebSocket 调用，但降低频率）
  const result = await callGatewayUsage({ key: sessionKey })
  
  // 2. 解析返回数据
  const sessionData = result.sessions?.find(s => s.key === sessionKey)
  if (!sessionData) return
  
  // 3. 更新数据库
  db.prepare(`
    UPDATE user_sessions 
    SET token_input = ?,
        token_output = ?,
        token_cache_read = ?,
        token_cache_write = ?,
        token_total = ?,
        cost_total = ?,
        msg_total = ?,
        msg_user = ?,
        msg_assistant = ?,
        msg_tool_calls = ?,
        msg_tool_results = ?,
        msg_errors = ?,
        tool_usage_json = ?,
        usage_synced_at = ?
    WHERE session_key = ?
  `).run(
    sessionData.usage?.input || 0,
    sessionData.usage?.output || 0,
    sessionData.usage?.cacheRead || 0,
    sessionData.usage?.cacheWrite || 0,
    sessionData.usage?.totalTokens || 0,
    sessionData.usage?.totalCost || 0,
    sessionData.usage?.messageCounts?.total || 0,
    sessionData.usage?.messageCounts?.user || 0,
    sessionData.usage?.messageCounts?.assistant || 0,
    sessionData.usage?.messageCounts?.toolCalls || 0,
    sessionData.usage?.messageCounts?.toolResults || 0,
    sessionData.usage?.messageCounts?.errors || 0,
    JSON.stringify(sessionData.usage?.toolUsage?.tools || []),
    Date.now(),
    sessionKey
  )
  
  // 4. 更新内存缓存
  cache.set(sessionKey, sessionData)
}
```

### 5.3 聚合查询模块

**职责：**
- 从 `user_sessions` 表实时计算聚合数据
- 替代 `sessions.usage` 的 aggregates 字段

**聚合查询示例：**

```javascript
// 获取用户级别的 totals（替代 sessions.usage.totals）
function getUserTotals(userId) {
  return db.prepare(`
    SELECT 
      SUM(token_input) as input,
      SUM(token_output) as output,
      SUM(token_cache_read) as cacheRead,
      SUM(token_cache_write) as cacheWrite,
      SUM(token_total) as totalTokens,
      SUM(cost_total) as totalCost
    FROM user_sessions
    WHERE user_id = ? AND usage_synced_at IS NOT NULL
  `).get(userId)
}

// 获取 byAgent 聚合（替代 sessions.usage.aggregates.byAgent）
function getByAgentAggregation(userId) {
  return db.prepare(`
    SELECT 
      agent_id,
      SUM(token_input) as input,
      SUM(token_output) as output,
      SUM(token_total) as totalTokens,
      SUM(cost_total) as totalCost
    FROM user_sessions
    WHERE user_id = ? AND usage_synced_at IS NOT NULL
    GROUP BY agent_id
  `).all(userId)
}
```

---

## 六、API 路由变更

### 6.1 `/api/sessions/usage`

**原实现：**
```javascript
const result = await callGatewayUsage(params)
```

**新实现：**
```javascript
if (params.key) {
  // 单会话查询：优先从缓存获取
  const cached = sessionUsageCache.getSessionUsage(params.key)
  if (cached && !sessionUsageCache.isExpired(params.key)) {
    return cached
  }
  // 缓存未命中或过期：从 Gateway 获取并更新缓存
  const result = await callGatewayUsage(params)
  sessionUsageCache.updateSessionUsage(params.key, result)
  return result
} else {
  // 全量查询：从本地聚合数据构建响应
  return sessionUsageCache.getUserUsage(req.currentUser.id)
}
```

### 6.2 `/api/usage-totals`

**新实现：**
```javascript
const totals = sessionUsageCache.getAggregatedUsage(req.currentUser.id, { type: 'totals' })
return totals
```

### 6.3 `/api/admin/user-usage`

**新实现：**
```javascript
// 管理员查看所有用户用量：从本地聚合数据查询
const allUsage = sessionUsageCache.getAllUsersUsage()
return allUsage
```

---

## 七、缓存策略

### 7.1 内存缓存

```javascript
// 启动时从数据库加载
const cache = new Map()

function loadCacheFromDB() {
  const rows = db.prepare('SELECT * FROM user_sessions WHERE usage_synced_at IS NOT NULL').all()
  for (const row of rows) {
    cache.set(row.session_key, row)
  }
}
```

### 7.2 过期策略

| 场景 | 过期时间 | 处理方式 |
|------|----------|----------|
| 正常查询 | 5 分钟 | 返回缓存数据，后台异步刷新 |
| 聊天结束后 | 立即同步 | `_doPushTokenUpdate` 强制刷新 |
| 缓存未命中 | 立即 | 从 Gateway 获取并写入缓存 |

### 7.3 降级策略

```javascript
async function getUsageWithFallback(sessionKey) {
  try {
    // 优先从缓存获取
    const cached = sessionUsageCache.getSessionUsage(sessionKey)
    if (cached) return cached
    
    // 缓存未命中：从 Gateway 获取
    const result = await callGatewayUsage({ key: sessionKey })
    sessionUsageCache.updateSessionUsage(sessionKey, result)
    return result
  } catch (error) {
    // Gateway 不可用：返回缓存数据（即使过期）
    const stale = sessionUsageCache.getSessionUsage(sessionKey, { allowStale: true })
    if (stale) return stale
    
    // 完全无数据：返回空结果
    return { sessions: [], totals: {}, aggregates: {} }
  }
}
```

---

## 八、数据一致性保证

### 8.1 同步时机

1. **聊天结束后**：`_doPushTokenUpdate` 强制同步
2. **页面加载时**：如果缓存过期，后台异步刷新
3. **定时任务**：每 5 分钟批量刷新过期缓存（可选）

### 8.2 一致性级别

- **最终一致性**：聊天结束后 5-10s 内同步到本地
- **强一致性**：单会话查询时如果缓存过期，立即从 Gateway 刷新

---

## 九、错误处理

### 9.1 Gateway 不可用

```javascript
try {
  await callGatewayUsage(params)
} catch (error) {
  // 记录日志，但不影响用户
  console.error('[SessionUsageCache] Gateway sync failed:', error.message)
  // 返回缓存数据（即使过期）
  return cache.get(sessionKey)
}
```

### 9.2 数据库写入失败

```javascript
try {
  db.prepare('UPDATE user_sessions ...').run(...)
} catch (error) {
  console.error('[SessionUsageCache] DB update failed:', error.message)
  // 内存缓存仍然更新，下次启动时从 DB 加载
  cache.set(sessionKey, data)
}
```

---

## 十、性能预期

| 指标 | 原方案 | 新方案 | 提升 |
|------|--------|--------|------|
| 仪表盘加载 | 3-15s | <100ms | 30-150x |
| AgentTeam 加载 | 4-20s | <100ms | 40-200x |
| `_doPushTokenUpdate` | 3-15s | 3-15s | 无（但频率降低） |
| Gateway WebSocket 调用 | 高频 | 极低 | 90%+ 减少 |

---

## 十一、实施计划

### Phase 1：基础设施（今天）
- [ ] 数据库迁移：增加 `user_sessions` 字段
- [ ] 实现 `SessionUsageCache` 模块
- [ ] 实现数据同步逻辑

### Phase 2：API 改造（今天）
- [ ] 改造 `/api/sessions/usage`
- [ ] 改造 `/api/usage-totals`
- [ ] 改造 `agent-team/stats`

### Phase 3：验证（今天）
- [ ] 测试聊天结束后同步
- [ ] 测试仪表盘数据准确性
- [ ] 测试缓存过期和刷新

---

## 十二、风险评估

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| Gateway 数据格式变更 | 低 | 高 | 防御性解析，多字段兼容 |
| 本地数据与 Gateway 不一致 | 中 | 中 | 5 分钟过期策略，后台刷新 |
| 数据库写入性能瓶颈 | 低 | 中 | SQLite WAL 模式，批量更新 |
| 内存缓存占用过大 | 低 | 低 | 仅缓存 usage 字段，非全量会话 |

---

*设计人: AI Agent*
*关联文档: [Gateway 稳定性审计](../../performance-audit/2026-06-04-gateway-stability-audit.md)*
