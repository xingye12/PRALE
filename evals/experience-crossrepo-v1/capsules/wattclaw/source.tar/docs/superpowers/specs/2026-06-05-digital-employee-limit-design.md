# 数字员工创建数量上限设计

## 背景

数字员工当前运行链路由本地 SQLite 的 `user_agents` 表承载，`/api/agent-team/*` 路由也以 `user_agents` 为实际数据源。当前每个用户可以持续创建数字员工，缺少用户级数量上限。需要限制每个用户最多拥有 10 个数字员工，并在超过上限时给出友好的弹窗提示。

## 目标

- 每个用户最多拥有 10 个数字员工。
- 管理员和普通用户都受相同限制。
- 删除数字员工后释放名额。
- 达到上限时不创建 Gateway Agent，不写入本地 `user_agents`。
- 前端创建失败时展示友好弹窗提示。

## 非目标

- 不修改数据库 schema。
- 不修改数字员工删除逻辑。
- 不改 Gateway 协议。
- 不做前端入口禁用的增强。

## 数据源

数量判断以本地 SQLite `user_agents` 表为准。当前数字员工列表通过 `category IS NOT NULL` 识别数字员工，并且只展示 `status = 'active'` 的记录：

```sql
SELECT COUNT(*) FROM user_agents
WHERE user_id = ?
  AND status = 'active'
  AND category IS NOT NULL
```

当前删除逻辑是硬删除：

```sql
DELETE FROM user_agents WHERE user_id = ? AND gateway_agent_id = ?
```

所以被删除的数字员工不会继续占用创建名额。

## 后端设计

在数字员工创建接口最前面做用户级数量校验。

规则：

- `count < 10`：继续原创建流程。
- `count >= 10`：直接返回失败。

失败返回建议：

```json
{
  "success": false,
  "code": "AGENT_TEAM_LIMIT_REACHED",
  "message": "每个用户最多可以创建 10 个数字员工"
}
```

HTTP 状态使用 `409 Conflict`。该错误必须发生在 Gateway Agent 创建之前，避免出现远端创建成功、本地写入失败的脏数据。为满足这个顺序，前端创建编排需要在调用 `agents.create` 前先调用本地限额预检接口。后端仍必须在 `/api/agent-team/create` 再做一次硬校验，防止绕过预检直接调用创建接口。

## 前端设计

前端以后端错误为准，不单独依赖本地列表数量。

需要覆盖两个创建入口：

- 自定义创建弹窗。
- 模板创建弹窗。

当识别到 `AGENT_TEAM_LIMIT_REACHED` 时：

- 停止创建进度。
- 保持当前创建弹窗可见。
- 不跳转，不关闭弹窗。
- 展示弹窗提示。

提示文案：

> 你已经拥有 10 个数字员工啦。可以先删除一个暂时不需要的数字员工，再创建新的成员。

其他错误继续使用现有创建失败提示。

## 验证

- 当前用户已有 9 个数字员工时，可以创建第 10 个。
- 当前用户已有 10 个数字员工时，第 11 个创建失败。
- 删除 1 个数字员工后，可以再次创建。
- 自定义创建入口展示友好弹窗。
- 模板创建入口展示友好弹窗。
- 达到上限时不会调用 Gateway 创建 Agent。
- 管理员和普通用户都受限制。
- 构建或类型检查通过。
