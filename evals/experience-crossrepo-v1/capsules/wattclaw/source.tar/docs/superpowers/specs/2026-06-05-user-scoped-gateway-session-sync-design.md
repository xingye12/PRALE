# User-Scoped Gateway Session Sync Design

Date: 2026-06-05

## Context

WattClaw currently reads the online conversation session list from local SQLite `user_sessions`. The old Gateway-wide polling path that called `sessions.list` repeatedly was removed to avoid Gateway pressure and request storms. As a result, sessions created outside WattClaw, such as Feishu channel conversations handled directly by OpenClaw Gateway, may exist in Gateway but never appear in WattClaw because they are not present in local `user_sessions`.

The goal is to restore visibility for external-channel sessions without reintroducing global polling or blocking frontend requests.

## Goals

- Sync Feishu/OpenClaw-created sessions into WattClaw by user ownership.
- Keep `/api/sessions` fast by returning local SQLite results immediately.
- Avoid Gateway-wide `sessions.list({})` calls.
- Sync only session metadata in this phase.
- Keep message content lazy-loaded through existing `/api/chat/history` backfill when the user opens a specific session.
- Prevent request storms with singleflight, cooldown, per-agent limits, and timeouts.

## Non-Goals

- No bulk message history synchronization during session-list refresh.
- No token usage synchronization in this flow.
- No deletion of local sessions based on Gateway absence.
- No frontend-initiated manual sync request or blocking sync button.
- No revival of recently deleted sessions.

## Current Behavior

`GET /api/sessions` reads only local SQLite:

```text
/api/sessions
  -> user_sessions
  -> normalize local rows
  -> return sessions
```

The previous `syncSessionsFromGateway()` hook is now a no-op. The old backup logic used global polling and `sessions.list({})`; that approach must not return.

## Proposed Architecture

Use a hybrid design:

1. `GET /api/sessions` remains a fast local read.
2. After the response is sent, the backend schedules a user-scoped Gateway session reconcile.
3. Gateway events can still incrementally track sessions when they arrive.
4. Opening a concrete session continues to use `/api/chat/history` for lazy message backfill.

```text
User opens online conversation
  -> frontend calls /api/sessions
  -> backend returns local user_sessions immediately
  -> backend schedules syncUserSessionsFromGateway(userId)
  -> sync gets user-owned agentIds
  -> for each agentId, call sessions.list({ agentId, limit })
  -> normalize and ownership-check sessions
  -> upsert user_sessions metadata
  -> if changed, emit sessions.updated SSE
  -> frontend refreshes /api/sessions
  -> user opens one session
  -> /api/chat/history backfills message content if needed
```

## Components

### `server/handlers/sessions.js`

Keeps ownership of `/api/sessions`.

Responsibilities:

- Read `user_sessions` from SQLite.
- Return local sessions immediately.
- Schedule background user session sync after the response path is no longer blocked.
- Never await Gateway sync inside the request response path.

### `server/core/session-sync.js`

New focused module for session metadata reconciliation.

Public API:

```js
scheduleUserSessionSync({ userId, role, reason })
```

Internal responsibilities:

- Maintain per-user in-flight state.
- Maintain per-user cooldown.
- Resolve allowed agent IDs for the user.
- Call Gateway only with an explicit `agentId`.
- Normalize Gateway sessions.
- Diff/upsert local `user_sessions` metadata.
- Report changed count.
- Emit `sessions.updated` when data changed.
- Ignore refresh-triggered duplicate scheduling through singleflight/cooldown.

### Gateway Access

Only allowed call shape:

```js
sessions.list({ agentId, limit })
```

Forbidden call shape:

```js
sessions.list({})
```

The sync must never perform an unbounded Gateway-wide list. Admin users also sync by known local Gateway agent IDs, not by global session listing.

### SQLite Upsert

Use a dedicated metadata upsert helper rather than overloading message storage.

Suggested input:

```js
upsertSyncedUserSession({
  userId,
  sessionKey,
  agentId,
  channel,
  peer,
  label,
  lastActivity,
})
```

Rules:

- Insert missing session rows.
- Update existing rows with fresher metadata.
- Preserve existing custom labels; Gateway label is fallback only.
- Prefer Gateway `lastActivity` for `updated_at` when valid.
- Fall back to `Date.now()` only when Gateway has no valid activity timestamp.
- Do not delete local sessions that Gateway did not return.

### SSE Refresh

When sync changes rows, send one lightweight user-scoped event:

```json
{
  "type": "sessions.updated",
  "reason": "gateway-sync",
  "changed": 3
}
```

The event carries no full session list. The frontend reacts by reloading `/api/sessions`. That reload may schedule another sync, but the per-user cooldown must suppress it.

## Sync Scope

For a normal user:

```text
userId -> getUserOwnedAgentIds(userId) -> sessions.list({ agentId, limit })
```

For admin:

```text
known local gateway agent IDs -> sessions.list({ agentId, limit })
```

Default constants are fixed for the first implementation:

- `perAgentLimit = 50`
- `cooldownMs = 60_000`
- `overallTimeoutMs = 8_000`
- `gatewayConcurrency = 2`

These values can become environment-configurable later, but the initial implementation should avoid runtime configuration surface area.

## Diff Rules

| Gateway result | Local row | Action |
|---|---|---|
| Present | Missing | Insert |
| Present | Present | Update metadata if fresher |
| Missing | Present | No action |
| Belongs to another user | Any | Drop |
| Recently deleted | Any | Drop |
| Invalid session key | Any | Drop and debug-log |

## Message Content Flow

This design does not bulk-sync messages. Session sync only makes external sessions visible.

Message content remains lazy:

```text
User opens session
  -> GET /api/chat/history
  -> local message store first
  -> Gateway history backfill if local content is missing or stale
```

This avoids the expensive pattern of opening the online conversation page and pulling history for every session.

## Storm Protection

Default protections:

- Per-user singleflight: one sync per user at a time.
- Per-user cooldown: 60 seconds.
- Per-agent limit: 50 recent sessions.
- Overall sync timeout: 8 seconds.
- Gateway concurrency: 2 agents at a time.
- Soft failure: sync failure never breaks `/api/sessions`.

## Error Handling

| Scenario | Handling |
|---|---|
| Gateway disconnected | Skip sync and log once per attempt. |
| One agent fails | Continue other agents. |
| Gateway timeout | Stop this sync round. |
| Invalid payload shape | Drop invalid item and continue. |
| Agent not owned by user | Drop item. |
| Recently deleted session | Drop item. |
| SQLite upsert failure | Log error; do not affect already returned response. |
| SSE failure | Do not roll back database writes. |

## Frontend Behavior

The frontend keeps the existing `/api/sessions` loading path.

Required frontend change is minimal:

- Listen for the `sessions.updated` SSE event.
- Reload local session list when received.
- Do not call a dedicated sync endpoint.
- Do not show blocking sync UI.

If the SSE change is deferred, users will see synced sessions on the next refresh; however, the preferred behavior is automatic list refresh after the backend event.

## Testing and Verification

Manual verification checklist:

1. `/api/sessions` returns quickly from SQLite.
2. Opening online conversation schedules backend user sync after local response.
3. Logs show `sessions.list({ agentId })`, not `sessions.list({})`.
4. Only current user's owned agent IDs are queried.
5. Feishu-created Gateway session appears in `user_sessions`.
6. SSE `sessions.updated` causes the frontend list to refresh.
7. Opening the new session triggers existing `/api/chat/history` message backfill.
8. Repeated page opens within cooldown do not repeat Gateway calls.
9. Sessions for other users' agents are not inserted.
10. Recently deleted sessions are not reinserted.
11. Gateway disconnect does not break local session list loading.
12. No bulk history calls occur during session metadata sync.

Automated tests should cover:

- Agent-scoped Gateway calls only.
- Per-user singleflight and cooldown.
- Ownership filtering.
- Upsert preservation of custom labels.
- No delete-on-absence behavior.
- Recently deleted session filtering.

## Rollout Plan

1. Add the session-sync core module and metadata upsert helper.
2. Wire `/api/sessions` to schedule background sync after local response.
3. Add SSE notification for changed rows.
4. Add frontend listener to refresh sessions on the notification.
5. Verify with a Feishu-created session.
6. Confirm logs contain no Gateway-wide `sessions.list({})` calls.

## Fixed Initial Parameters

| Parameter | Value |
|---|---:|
| Per-agent session limit | 50 |
| Per-user cooldown | 60 seconds |
| Overall sync timeout | 8 seconds |
| Gateway agent concurrency | 2 |

These are intentionally conservative. Tuning comes after observing Gateway latency and Feishu session volume.
