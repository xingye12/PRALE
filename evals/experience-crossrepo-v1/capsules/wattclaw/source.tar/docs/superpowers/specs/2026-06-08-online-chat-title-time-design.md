# 在线对话标题与时间修复设计

日期：2026-06-08

## 背景

在线对话存在三个用户可见问题：

1. 飞书同步会话标题显示为 `ou_0b2e...` 这类内部用户 ID。
2. 当前会话中用户消息时间可见，但切换会话后消失；agent 回复历史一直没有时间。
3. 只点击进入旧会话、不发送消息，刷新后会话列表时间变成“刚刚”。

本设计只修复在线对话标题与时间语义，不做无关重构。

## 目标

- 飞书会话标题对普通用户可读。
- user 与 assistant 消息都稳定显示 `HH:mm`。
- 切换会话后历史消息时间不丢失。
- 会话列表时间只表示最后一条真实消息时间。
- 点击、加载历史、归属确认不得刷新会话列表时间。

## 非目标

- 不新增“最后查看时间”展示。
- 不引入新的会话详情页。
- 不重构整体消息存储架构。
- 不改动非在线对话模块。

## 当前问题定位

### 标题

会话标题展示在 `src/views/workspace/WorkspaceSidebar.vue`。
本地会话归一化在 `server/handlers/sessions.js`。
渠道会话自动标题在 `server/index.js` 的 `tryAutoTitleForChannelSession`。

当前兜底逻辑可能把 session key 末尾 peer 直接作为标题，因此飞书 `ou_...` 被展示给用户。

### 消息时间

消息时间展示在 `src/views/workspace/MessageList.vue`。
历史消息解析在 `src/stores/workspace-message-utils.ts` 的 `parseHistoryMessages`。

当前解析只稳定接受字符串形态的 `timestamp`。如果历史数据来自 PG/rawContent，且时间字段是数字、`createdAt`、`created_at`、`ts`、`time` 或 `msg_timestamp`，前端可能丢失时间。

assistant 历史消息合并时也需要保留可用 timestamp。

### 会话列表时间

会话列表时间展示在 `src/views/workspace/WorkspaceSidebar.vue`。
前端会优先读取 store 内临时 `activityTimestamps`。
后端 `server/user-manager.js` 的 `trackSessionForUser` 当前可能在归属确认路径更新 `updated_at`。

这会把“打开/同步/确认归属”误当成“真实消息活动”。

## 方案

采用“后端 SSOT 修正 + 前端展示防腐”。

后端负责收敛数据语义：

- 会话标题写入或返回前转为用户可读标题。
- 消息历史接口统一输出稳定 `timestamp`。
- `updated_at` 只表示最后一条真实消息时间。

前端负责防腐展示：

- 不展示 `ou_...`、`oc_...` 等内部 peer ID。
- 统一时间解析函数，user 与 assistant 共用。
- 点击会话不制造活动时间。

## 会话标题规则

渠道会话标题优先级：

1. `渠道名 · 用户昵称/群名`
2. `渠道名 · 首条用户消息摘要`
3. `飞书私聊` / `飞书群聊`
4. 其他渠道可读兜底

内部 ID 不进入用户可见标题：

- `ou_...`
- `oc_...`
- 其他明显平台内部 peer ID

飞书 peer ID 仅作为内部寻址字段保存。

## 消息时间规则

历史消息归一化后必须尽量携带：

```ts
timestamp: string // ISO string
```

时间来源优先级：

1. PG `msg_timestamp`
2. raw content `timestamp`
3. raw content `createdAt`
4. raw content `created_at`
5. raw content `ts`
6. raw content `time`

前端展示规则：

- 只显示 `HH:mm`。
- user 与 assistant 使用同一解析函数。
- 无可解析时间时不显示，不用当前时间伪造历史。

assistant 相邻历史块合并时：

- 保留已有 assistant 消息 timestamp。
- 如果已有 timestamp 为空，使用后续块的可用 timestamp。

## 会话列表时间规则

`lastActivity` 表示最后一条真实消息时间。

允许更新来源：

- 用户发送消息。
- agent 回复消息。
- 外部渠道同步到新消息。
- Gateway/SSE 明确携带真实消息事件时间。

禁止更新来源：

- 点击进入会话。
- 加载历史消息。
- 权限归属确认。
- `/api/sessions` 后台同步但没有真实消息时间。
- 本地 normalize 时使用 `new Date()` 兜底。

如果会话没有真实活动时间，列表不显示时间或保留原值。

## 代码落点

### `server/handlers/sessions.js`

- `normalizeLocalSession` 不再用当前时间兜底 `lastActivity`。
- 标题兜底过滤内部 ID。
- `/api/sessions` 返回本地 SQLite 的真实更新时间。

### `server/user-manager.js`

- `trackSessionForUser` 不因归属确认刷新 `updated_at`。
- 只有明确传入真实消息活动时间时才更新 `updated_at`。
- 保留 agent/channel/label 的补全能力。

### `server/index.js`

- 增强 `tryAutoTitleForChannelSession`。
- 标题生成顺序：渠道身份名 → 首条消息摘要 → 可读兜底。
- 飞书内部 peer ID 不作为 label。

### `server/handlers/chat.js`

- 本地消息读取时输出 `timestamp`。
- 优先使用 `msg_timestamp`，其次 raw content 内时间字段。
- Gateway 回填消息时保留原始时间并写入 `msgTimestamp`。

### `src/stores/workspace-message-utils.ts`

- `parseHistoryMessages` 支持多字段、多类型时间解析。
- assistant 合并时保留可用 timestamp。

### `src/views/workspace/MessageList.vue`

- 保持 `HH:mm` 展示。
- user 与 assistant 共用同一时间解析结果。

### `src/views/workspace/WorkspaceSidebar.vue`

- 会话列表继续显示 `lastActivity`。
- 前端 activity timestamp 只由真实消息事件写入。
- 点击会话不得刷新临时时间。

## 验证清单

1. 飞书同步会话标题不显示 `ou_...`。
2. 能拿到身份名时显示 `飞书 · 用户昵称/群名`。
3. 拿不到身份名时显示 `飞书 · 首条消息摘要`。
4. 当前会话新用户消息显示 `HH:mm`。
5. 切换会话再切回，用户消息时间仍显示。
6. agent 回复历史消息显示 `HH:mm`。
7. 点击旧会话但不发送消息，刷新后列表时间不变。
8. 发送新消息后，列表时间更新为“刚刚”。
9. 运行 `npx vue-tsc --noEmit` 或 `npm run build` 通过。

## 临时恢复逻辑退场计划

2026-06-09 线上修复后新增了一段启动恢复逻辑，用于处理重构上线前已经存在的历史脏数据。它不是长期业务路径。

### 必须长期保留

这些是防止问题再次发生的根因修复，不能随恢复逻辑一起删除：

- `server/services/session-title-service.js`
  - `stripGeneratedTitleSuffix`
  - `normalizeDisplayTitleCandidate`
  - `shouldBackfillDisplayTitle` 对污染标题的识别
- `server/user-manager.js`
  - `trackSessionForUser` 写入 `display_title` 前的净化
  - `upsertSyncedUserSession` 写入 `display_title` 前的净化
- `user_sessions.display_title`
- `user_sessions.peer_id`
- `user_sessions.last_message_at`

长期语义仍然是：

- `display_title`：唯一用户可见标题
- `peer_id`：平台内部身份锚点，不展示
- `last_message_at`：最后一条真实消息时间
- `updated_at`：SQLite 行更新时间，不用于会话列表展示

### 可以退场的恢复代码

以下代码只服务一次性历史数据修复，确认线上所有数据恢复完成后可以删除或改成版本化 migration：

- `server/services/session-activity-service.js`
  - `cleanGeneratedSessionTitles`
  - `backfillLegacySessionLastMessageAt`
  - `repairSessionTitleAndActivitySemantics`
- `server/message-store.js`
  - `readSessionMaxMessageTimestamps`，如果没有其他调用方
- `server/index.js`
  - `repairSessionTitleAndActivitySemantics` import
  - `initMessageStore().then(...)` 中触发 `[SessionRepair]` 的启动调用

### 删除前置条件

删除前必须同时满足：

1. 线上至少完成一次包含该恢复逻辑的发布。
2. 所有生产实例都重启并执行过 `[SessionRepair]`。
3. 连续重启或发布后日志稳定显示：
   - `titles=0`
   - `lastMessageAt=0`
4. 抽查旧会话：
   - 标题不再出现 `标题-13位时间戳`。
   - 老会话列表时间来自 `last_message_at`。
5. Gateway 同步路径不会再把原始 `label` 写进 `display_title`。

### 推荐处理顺序

1. 当前版本保留启动恢复逻辑，用于修复存量数据。
2. 下一版本改成版本化一次性 migration，执行后写入完成标记。
3. 再下一版本确认无增量修复后，删除启动恢复入口和无调用的恢复函数。

删除恢复逻辑时不能恢复前端 `lastActivity` fallback。老数据时间只能通过后端 `last_message_at` 补齐，不能在前端用当前时间或 `updated_at` 伪造。
