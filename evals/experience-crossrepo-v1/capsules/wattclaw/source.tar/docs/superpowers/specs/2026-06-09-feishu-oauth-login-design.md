# 飞书 OAuth 授权登录设计

> 状态：待实施 | 日期：2026-06-09 | 方案：A（最小侵入插件式）

## 1. 需求摘要

| 维度 | 决策 |
|------|------|
| 用户发现 | 仅绑定，无自动注册 |
| 绑定建立 | 后台脚本批量录入 union_id → user_id |
| 飞书应用 | 已创建，凭据齐全 |
| 锚点字段 | `union_id`（企业级唯一） |
| 回调页 | 独立 `/auth/feishu/callback` |
| 返回凭证 | WattClaw 内部 UUID Token（与现有一致） |

## 2. OAuth 授权码流时序图

```mermaid
sequenceDiagram
    participant U as 用户浏览器
    participant F as Login.vue
    participant S as WattClaw 后端
    participant FS as 飞书 OAuth 服务
    participant FU as 飞书用户信息 API

    U->>F: 1. 点击"飞书登录"按钮
    F->>S: 2. GET /api/auth/feishu/authorize
    Note over S: 生成随机 state<br/>写入 SQLite oauth_states 表<br/>构造完整授权 URL（含 state, redirect_uri, app_id）<br/>per-IP 速率限制 10次/分钟
    S-->>F: 3. { url: "https://open.feishu.cn/open-apis/authen/v1/authorize?..." }

    F->>U: 4. window.location.href = url（整页跳转飞书）

    U->>FS: 5. 飞书授权页（用户确认）
    FS-->>U: 6. 302 → /auth/feishu/callback?code=XYZ&state=abc123

    U->>F: 7. FeishuCallback.vue 加载
    Note over F: 从 URL 提取 code, state

    F->>S: 8. POST /api/auth/feishu/callback<br/>{ code: "XYZ", state: "abc123" }

    Note over S: 9. 校验 state 一致性 + 未过期（SQLite oauth_states 表）
    S->>FS: 10. POST /open-apis/authen/v2/oauth/token<br/>{ grant_type: "authorization_code"<br/>client_id, client_secret, code, redirect_uri }

    FS-->>S: 11. { code: 0, data: { access_token, token_type, expires_in } }

    S->>FU: 12. GET /open-apis/authen/v1/user_info<br/>Authorization: Bearer {access_token}

    FU-->>S: 13. { code: 0, data: { union_id, open_id, name, avatar_url } }

    Note over S: 14. SELECT user_id FROM user_oauth_bindings<br/>WHERE provider='feishu' AND union_id=?

    alt 绑定记录存在
        S->>S: 15a. createAuthToken(userId, ...)
        S-->>F: 16a. { ok: true, token, user, expiresAt }
        F->>F: 17a. setToken() + setCurrentUser()
        F->>U: 18a. router.push('/')
    else 绑定记录不存在
        S-->>F: 16b. { ok: false, error: "该飞书账号未绑定系统用户" }
        F->>U: 17b. 提示错误 + "返回登录"链接
    end
```

### 安全要点

- **State 参数**：后端生成 32 字节随机 hex，存 SQLite `oauth_states` 表 + 5min TTL，回调时严格校验，一次性消费（用完即焚）。不使用内存 Map，避免服务重启导致所有进行中的 OAuth 流程失败。
- **App Secret**：仅存在于 `feishu-oauth.js`，从 `process.env` 读取，永远不离开后端
- **飞书 access_token**：仅在回调处理期间使用，用完即弃，不持久化存储
- **redirect_uri**：授权 URL 和 token 交换中的 `redirect_uri` 均从 `process.env.FEISHU_REDIRECT_URI` 读取，由后端统一构造，前端不参与拼接，彻底消除不匹配风险

## 3. 数据模型

### 新增表：`user_oauth_bindings`

```sql
CREATE TABLE IF NOT EXISTS user_oauth_bindings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'feishu',
  union_id TEXT NOT NULL,
  open_id TEXT,
  display_name TEXT,
  avatar_url TEXT,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_oauth_provider_union
  ON user_oauth_bindings(provider, union_id);
CREATE INDEX IF NOT EXISTS idx_oauth_user_id
  ON user_oauth_bindings(user_id);
```

### 新增表：`oauth_states`（State 持久化，避免重启丢失）

```sql
CREATE TABLE IF NOT EXISTS oauth_states (
  state TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);
-- 过期清理：DELETE FROM oauth_states WHERE created_at < (now - 5min)
-- 一次性消费：验证后立即 DELETE
```

### 新增环境变量

```bash
FEISHU_APP_ID=cli_xxxxxxxxxxxxx
FEISHU_APP_SECRET=xxxxxxxxxxxxxxxxxxxx
FEISHU_REDIRECT_URI=https://your-domain.com/auth/feishu/callback  # 必须与飞书开发者后台配置一致
```

## 4. API 契约

### GET /api/auth/feishu/config

无认证。前端判断是否展示飞书登录按钮。

**响应 200：**
```json
{ "enabled": true }
```

### GET /api/auth/feishu/authorize

无认证。生成 state 并返回完整的飞书授权 URL。per-IP 速率限制 10 次/分钟。

**响应 200：**
```json
{
  "url": "https://open.feishu.cn/open-apis/authen/v1/authorize?app_id=...&redirect_uri=...&state=..."
}
```

**响应 429（触发速率限制）：**
```json
{ "error": "请求过于频繁，请稍后再试" }
```

**设计意图**：`redirect_uri`、`app_id`、`state` 全部由后端统一构造，前端只做 `window.location.href = url`，消除前后端 redirect_uri 不匹配的风险。

### POST /api/auth/feishu/callback

无认证。完成整个 OAuth 流程。

**请求体：**
```json
{ "code": "abcXYZ", "state": "a1b2c3d4..." }
```

**成功响应 200：**
```json
{
  "ok": true,
  "token": "wattclaw-uuid-token",
  "user": { "id": "...", "username": "...", "role": "user", ... },
  "expiresAt": 1718000000000
}
```

**失败响应（401/403/500）：**
```json
{ "ok": false, "error": "该飞书账号未绑定系统用户" }
```

错误码映射：401=未绑定/用户禁用，403=state 无效/过期/CSRF，500=飞书 API 错误，502=飞书不可用。

## 5. 前端 TypeScript 类型

```typescript
// src/api/types/feishu-auth.ts

export interface FeishuAuthConfig {
  enabled: boolean
}

export interface FeishuAuthorizeResponse {
  url: string
}

export interface FeishuCallbackRequest {
  code: string
  state: string
}

export interface FeishuCallbackResponse {
  ok: boolean
  token?: string
  user?: User
  expiresAt?: number
  error?: string
}
```

## 6. 模块职责矩阵

| 文件 | 职责 | 类型 |
|------|------|------|
| `server/core/feishu-oauth.js` | 飞书 API 交互：code→token, token→userinfo, state 管理 | 新建 |
| `server/handlers/feishu-auth.js` | 3 个 HTTP 端点（config/authorize/callback） | 新建 |
| `src/views/auth/FeishuCallback.vue` | 回调落地页：提取参数、发送请求、存储 Token | 新建 |
| `server/database.js` | 新增 `user_oauth_bindings` + `oauth_states` 建表 | 追加 |
| `server/index.js` | 注册 `feishu-auth` 路由 | 追加 1 行 |
| `src/views/Login.vue` | 添加飞书登录按钮 | 追加 |
| `src/router/index.ts` | 新增 `/auth/feishu/callback` 路由 | 追加 |
| `src/stores/auth.ts` | 新增 `loginWithFeishu` action | 追加 |
| `src/api/types/feishu-auth.ts` | 飞书认证类型定义 | 新建 |
| `src/api/types/index.ts` | barrel export | 追加 |
| `scripts/bind-feishu.js` | 后台绑定脚本 | 新建 |

### 冻结确认

`users` 表 ✅ | `auth_tokens` 表 ✅ | `user-manager.js` ✅ | `core/auth.js` ✅ — 均不修改。

## 7. 错误处理矩阵

| 阶段 | 错误 | HTTP 状态 | error 文案 | 前端行为 |
|------|------|-----------|-----------|---------|
| State 校验 | state 不存在/已过期/已使用 | 403 | "state 已过期，请重新登录" | 红色提示 + "返回登录" |
| State 校验 | 传入 state 与存储不匹配 | 403 | "state 校验失败" | 同上（CSRF 嫌疑） |
| Token 交换 | 飞书 API 超时/code 无效 | 502 | "飞书授权服务不可用" | 红色提示 + "重试" |
| 用户信息 | access_token 无效/网络抖动 | 502 | "获取飞书用户信息失败" | 同上 |
| 绑定查询 | union_id 不在绑定表 | 401 | "该飞书账号未绑定系统用户" | 红色提示 + 联系管理员 |
| 用户状态 | 绑定用户 status !== active | 403 | "账号已被禁用" | 红色提示 |
| Code 重放 | code 已被消费 | 502 | "授权码已失效" | 红色提示 + "返回登录" |

### State 生命周期管理

```javascript
import db from './database.js'

const STATE_TTL = 5 * 60 * 1000  // 5 分钟

// 生成 state：写入 SQLite
function generateState() {
  const state = randomBytes(32).toString('hex')
  const now = Date.now()
  db.prepare('INSERT INTO oauth_states (state, created_at) VALUES (?, ?)').run(state, now)
  return state
}

// 一次性消费：校验 + 删除（原子操作）
function consumeState(state) {
  const row = db.prepare('SELECT created_at FROM oauth_states WHERE state = ?').get(state)
  if (!row) return false
  db.prepare('DELETE FROM oauth_states WHERE state = ?').run(state)
  return Date.now() - row.created_at <= STATE_TTL
}

// 定期清理过期 state（防止表膨胀）
// 在应用启动时注册，每分钟执行一次
setInterval(() => {
  const cutoff = Date.now() - STATE_TTL
  db.prepare('DELETE FROM oauth_states WHERE created_at < ?').run(cutoff)
}, 60_000)
```

**为何不用内存 Map**：服务重启会导致所有进行中的 OAuth 流程失败（state 丢失），用户看到 "state 已过期" 错误。SQLite 持久化确保重启安全，且为未来多实例部署预留能力。

**速率限制**：`/api/auth/feishu/authorize` 端点无认证，需防止恶意刷 state 填充数据库。使用内存 per-IP 限流：

```javascript
const _authorizeRateLimit = new Map() // ip → { count, resetAt }
const AUTHORIZE_RATE_LIMIT = 10       // 每分钟最多 10 次

function checkAuthorizeRateLimit(ip) {
  const now = Date.now()
  const entry = _authorizeRateLimit.get(ip)
  if (!entry || now > entry.resetAt) {
    _authorizeRateLimit.set(ip, { count: 1, resetAt: now + 60_000 })
    return true
  }
  if (entry.count >= AUTHORIZE_RATE_LIMIT) return false
  entry.count++
  return true
}
```

## 8. 前端交互设计

### Login.vue 改动

在现有登录按钮下方追加飞书登录区域（仅当 `feishuConfig.enabled === true` 时显示）：

- 分割线 + "或" 文案
- 飞书 Logo + "飞书登录" 按钮
- 点击流程：请求 `/api/auth/feishu/authorize` → 拿到完整 URL → `window.location.href = url`（整页跳转飞书）

### FeishuCallback.vue 交互流

```
页面加载
  ↓ 检查 URL 参数
  ├─ 无 code/state → 显示"参数缺失"
  ├─ 有 code+state → loading "飞书登录中..."
  │   ↓ POST /api/auth/feishu/callback
  │   ├─ 成功 → setToken + setCurrentUser → router.push('/')
  │   └─ 失败 → 显示错误 + 操作按钮
  │       ├─ "未绑定" → "返回登录"
  │       ├─ "state过期" → "返回登录"
  │       └─ "服务不可用" → "重试"
```

## 9. 后台绑定脚本

```bash
# scripts/bind-feishu.js

# 绑定
# node scripts/bind-feishu.js --bind --user-id <UUID> --union-id <feishu_union_id>
# 逻辑：
# 1. 校验 user_id 在 users 表存在
# 2. 校验 union_id 未被绑定
# 3. INSERT INTO user_oauth_bindings
# 4. 输出绑定结果

# 解绑
# node scripts/bind-feishu.js --unbind --union-id <feishu_union_id>
# 逻辑：
# 1. DELETE FROM user_oauth_bindings WHERE provider='feishu' AND union_id=?
# 2. 输出解绑结果

# 重绑（变更 union_id）
# node scripts/bind-feishu.js --rebind --user-id <UUID> --union-id <new_union_id>
# 逻辑：
# 1. DELETE 旧绑定
# 2. INSERT 新绑定
# 3. 输出结果

# 批量绑定
# node scripts/bind-feishu.js --file bindings.csv
# CSV 格式: user_id,union_id
```

## 10. 飞书应用配置前提

在实施前，需确保飞书应用已完成以下配置：

1. **应用类型**：网页应用（Web App）
2. **重定向地址**：在飞书开发者后台 → 安全设置 中添加 `FEISHU_REDIRECT_URI` 对应的完整 URL（如 `https://wattclaw.company.com/auth/feishu/callback`）
3. **权限申请**：开通 `contact:user.base:readonly`（获取用户基本信息），否则 `/open-apis/authen/v1/user_info` 会返回权限不足
4. **应用发布**：应用需处于"已发布"状态，未发布的应用仅创建者可授权

## 11. 飞书 OAuth API 参考

### 获取授权码（浏览器跳转）

```
GET https://open.feishu.cn/open-apis/authen/v1/authorize
  ?redirect_uri={FEISHU_REDIRECT_URI}
  &app_id={FEISHU_APP_ID}
  &state={STATE}
```

### 用授权码换 User Access Token

```
POST https://open.feishu.cn/open-apis/authen/v2/oauth/token
Content-Type: application/json

{
  "grant_type": "authorization_code",
  "client_id": "{FEISHU_APP_ID}",
  "client_secret": "{FEISHU_APP_SECRET}",
  "code": "{CODE}",
  "redirect_uri": "{FEISHU_REDIRECT_URI}"
}
```

**注意：飞书响应有信封包裹，必须解析 `response.data`：**
```json
{
  "code": 0,
  "msg": "ok",
  "data": {
    "access_token": "...",
    "token_type": "Bearer",
    "expires_in": 3600,
    "refresh_token": "..."
  }
}
```

后端必须校验 `code === 0`，然后从 `data.access_token` 提取令牌。

### 获取用户信息

```
GET https://open.feishu.cn/open-apis/authen/v1/user_info
Authorization: Bearer {ACCESS_TOKEN}
```

**响应同样有信封包裹：**
```json
{
  "code": 0,
  "msg": "ok",
  "data": {
    "union_id": "...",
    "open_id": "...",
    "name": "...",
    "avatar_url": "...",
    "user_id": "..."
  }
}
```

后端从 `data` 中提取 `union_id` 作为绑定锚点。
