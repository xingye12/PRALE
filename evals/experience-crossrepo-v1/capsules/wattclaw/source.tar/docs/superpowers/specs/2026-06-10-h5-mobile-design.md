# H5 移动端设计方案

> 日期：2026-06-10
> 状态：Draft
> 范围：登录 + 对话 + 数字员工 + 我的（4 个模块）
> 设计参考：豆包（Doubao）移动端 AI 聊天应用

---

## 1. 目标

为 WattClaw 开发纯净隔离的 H5 移动端版本，覆盖"对话"和"数字员工"两个核心模块。

### 硬性约束

| 约束 | 说明 |
|------|------|
| 物理隔离 | 不修改任何现有 PC 端 `.vue`/`.tsx` 文件 |
| 逻辑复用 | 直接 import 现有 stores、api、utils、types |
| 视图重写 | 移动端 UI 全部在 `src/mobile/` 独立目录中实现 |
| 路由隔离 | `/m/` 前缀 + `MobileTabLayout` / 独立页面 |
| UA 自动跳转 | 移动端 UA 访问 PC 路由时自动重定向到 `/m/` 对应路由 |
| 登录强制 | 未登录用户无法使用任何功能，自动跳转登录页 |

---

## 2. 架构方案

**方案 A：纯独立目录 + 共享路由入口**（已确认）

```
src/
├── mobile/                    # H5 移动端隔离目录
│   ├── layout/
│   │   └── MobileTabLayout.vue   # Bottom Tab Bar 壳
│   ├── views/
│   │   ├── login/
│   │   ├── chat/
│   │   ├── agents/
│   │   └── profile/
│   ├── composables/
│   ├── router/
│   └── styles/
├── stores/                    # ✅ 复用，不修改
├── api/                       # ✅ 复用，不修改
└── utils/                     # ✅ 复用，不修改
```

---

## 3. 路由设计

### 3.1 路由表

```typescript
// src/mobile/router/mobile-routes.ts

// 登录页（独立，无 Layout 壳）
{
  path: '/m/login',
  component: MobileLoginPage,
  meta: { requiresAuth: false }
}

// Tab Bar 主壳（3 个 Tab 页面，使用 <keep-alive> 保持状态）
{
  path: '/m',
  component: MobileTabLayout,
  meta: { requiresAuth: true },
  children: [
    { path: '',             redirect: '/m/conversations' },
    { path: 'conversations', component: MobileConversationsPage },  // 对话 Tab
    { path: 'agents',       component: MobileAgentPage },            // 数字员工 Tab
    { path: 'profile',      component: MobileProfilePage },          // 我的 Tab
  ]
}

// 全屏子页面（无 Tab Bar）
// ⚠️ 路由顺序约束：create 必须在 :id 之前，否则 "create" 会被匹配为 id
{
  // 单条路由，sessionKey 可选。避免拆成两条路由导致组件 destroy → recreate
  // 新对话：/m/chat?agentId=xxx（无 sessionKey）
  // 历史会话：/m/chat/:sessionKey（有 sessionKey）
  path: '/m/chat/:sessionKey?',
  component: MobileChatPage,
  meta: { requiresAuth: true },
  props: true  // sessionKey 作为 prop 传入
},
{
  path: '/m/agents/create',              // ⚠️ 必须在 :id 之前
  component: MobileAgentEditPage,
  meta: { requiresAuth: true }
},
{
  path: '/m/agents/:id',
  component: MobileAgentDetailPage,
  meta: { requiresAuth: true }
},
{
  path: '/m/agents/:id/edit',
  component: MobileAgentEditPage,
  meta: { requiresAuth: true }
}
```

#### "新对话" 路由数据流

```
对话 Tab → 点击 Agent 展开区 "新对话"
  → router.push({ path: '/m/chat', query: { agentId: 'xxx' } })
  → MobileChatPage mount，route.params.sessionKey 为 undefined
  → 检测 route.query.agentId，调用后端创建 session
  → 获得 sessionKey
  → router.replace({ path: `/m/chat/${sessionKey}` })
  → 同一路由记录，组件不销毁，watch route.params.sessionKey 触发加载
  → 进入聊天状态
```

#### 历史会话路由数据流

```
对话 Tab → 点击历史会话项
  → router.push(`/m/chat/${sessionKey}`)
  → MobileChatPage mount，route.params.sessionKey 有值
  → chatClient.history(sessionKey) 加载消息
  → 渲染消息列表
```

#### 组件内路由区分逻辑

```typescript
// MobileChatPage.vue
const route = useRoute()
const sessionKey = computed(() => route.params.sessionKey as string | undefined)
const agentId = computed(() => route.query.agentId as string | undefined)

watch(sessionKey, (newKey) => {
  if (newKey) {
    // 有 sessionKey → 加载历史消息
    loadHistory(newKey)
  }
}, { immediate: true })

// 无 sessionKey + 有 agentId → 创建新 session
onMounted(async () => {
  if (!sessionKey.value && agentId.value) {
    const key = await createSession(agentId.value)
    router.replace({ path: `/m/chat/${key}` })
  }
})
```

### 3.2 登录守卫

```typescript
// router.beforeEach 中
// 1. 访问 /m/* 路由（/m/login 除外）且未认证 → 重定向 /m/login?redirect=当前路径
// 2. 已认证访问 /m/login → 重定向 /m/conversations
// 3. 登录成功后 → 跳转 redirect 参数指向的路径，默认 /m/conversations
```

### 3.3 UA 检测与自动跳转

在 `router.beforeEach` 全局守卫中增加移动端检测：

```typescript
// src/mobile/composables/useMobileRedirect.ts
const MOBILE_UA_REGEX = /iPhone|Android|Mobile/i

// PC 路由 → 移动端路由映射
const PC_TO_MOBILE_MAP: Record<string, string> = {
  '/': '/m/conversations',
  '/chat': '/m/conversations',
  '/agent-team': '/m/agents',
  '/sessions': '/m/conversations',
}

// router.beforeEach 中调用
// 1. 检测 UA 是否为移动端
// 2. 排除管理后台路由（/system, /settings, /terminal 等）
// 3. 重定向到 /m/ 对应路由
```

排除列表（不跳转移动端）：
- `/system/*` — 系统管理
- `/settings` — 全局设置
- `/terminal/*` — 终端
- `/remote-desktop/*` — 远程桌面
- `/files/*` — 文件管理
- `/backup/*` — 备份管理
- `/user-management` — 用户管理

---

## 4. 导航架构

采用 **Bottom Tab Bar（3 Tab）**，无侧边栏。Tab Bar 仅在 3 个一级页面显示，进入子页面时隐藏。

### 4.1 MobileTabLayout 壳组件

```
┌──────────────────────────┐
│                          │
│   子路由内容区域           │  flex: 1, overflow-y: auto
│   (conversations/agents/  │
│    profile)              │
│                          │
├──────────────────────────┤
│  💬 对话  🤖 员工  👤 我的 │  Bottom Tab Bar（固定底部）
└──────────────────────────┘
```

**Tab 状态保持**：使用 `<keep-alive>` 包裹 `<router-view>`，切换 Tab 时组件不会 unmount。

```vue
<!-- MobileTabLayout.vue -->
<keep-alive>
  <router-view />
</keep-alive>
```

保持的状态包括：
- 对话 Tab：展开的 Agent ID、滚动位置、已加载的会话数据
- 员工 Tab：滚动位置
- 我的 Tab：无状态需保持

**顶部安全区**：MobileTabLayout 统一处理刘海/灵动岛适配：

```css
.mobile-tab-layout .content-area {
  padding-top: env(safe-area-inset-top);
}
```

全屏子页面（聊天页、详情页、编辑页、登录页）各自处理顶部安全区，不依赖 Layout。

### 4.2 Bottom Tab Bar（MobileTabBar）

```
┌──────────┬──────────┬──────────┐
│  💬       │  🤖       │  👤       │
│  对话     │  数字员工  │  我的     │
│  (活跃)   │          │          │
└──────────┴──────────┴──────────┘
```

**3 个 Tab**：

| Tab | 图标 | 路由 | 说明 |
|-----|------|------|------|
| 对话 | chat | `/m/conversations` | Agent 手风琴列表 + 会话入口 |
| 数字员工 | robot | `/m/agents` | 员工管理（列表/详情/创建/编辑） |
| 我的 | person | `/m/profile` | 用户信息 + 退出登录 |

**Tab Bar 规格**：
- 高度：50px + `env(safe-area-inset-bottom)` 安全区
- 当前 Tab：主题色图标 + 文字
- 非 active：灰色图标 + 文字
- 底部安全区域背景色与 Tab Bar 一致

**隐藏规则**：路由不在 MobileTabLayout children 中时，Tab Bar 自动隐藏。具体：
- `/m/chat/*` → 全屏聊天页，无 Tab Bar
- `/m/agents/create`、`/m/agents/:id`、`/m/agents/:id/edit` → 子页面，无 Tab Bar

---

## 5. 登录页设计（MobileLoginPage）

独立页面，无 MobileTabLayout 壳，无 Bottom Tab。

```
┌──────────────────────────┐
│                          │
│                          │
│       ┌─────────┐       │
│       │  🦞 Logo │       │  应用 Logo / 图标
│       └─────────┘       │
│                          │
│     WattClaw              │  应用名称
│     企业 AI 平台          │  副标题
│                          │
│  ┌──────────────────┐   │
│  │  👤 用户名         │   │  输入框
│  └──────────────────┘   │
│  ┌──────────────────┐   │
│  │  🔒 密码           │   │  密码框（可切换显示）
│  └──────────────────┘   │
│                          │
│  ┌──────────────────┐   │
│  │      登录           │   │  主按钮（主题色，圆角）
│  └──────────────────┘   │
│                          │
│  ⚠️ 用户名或密码错误      │  错误提示（红色，仅失败时显示）
│                          │
└──────────────────────────┘
```

**数据流**：
- 调用 `authStore.login(username, password)` → 后端 `/api/auth/login` → JWT
- 登录成功 → `router.push(redirect || '/m/conversations')`
- 登录失败 → 显示错误提示，不清空输入

**交互细节**：
- 密码框右侧有"眼睛"图标，切换明文/密文
- 登录按钮 loading 态：按钮禁用 + 转圈
- Enter 键提交
- 页面打开时自动聚焦用户名输入框

**与 PC 端对齐**：
- 复用 `useAuthStore.login()` 逻辑
- 复用后端 `/api/auth/login` 接口
- 飞书 OAuth 登录：首期不实现，后续迭代

---

## 6. 对话 Tab 设计（MobileConversationsPage）

### 6.1 页面结构

无顶部导航栏，直接展示 Agent 手风琴列表。

```
┌──────────────────────────┐
│                          │  ← 无顶部栏
│  🤖 代码助手              │  ← Agent 项（折叠态）
│     全栈编程助手          │
│  ──────────────────────  │
│  📊 数据分析              │  ← Agent 项（展开态）
│     SQL 查询与数据报表     │
│  ┌──────────────────┐   │
│  │  ＋ 新对话         │   │  ← 蓝色按钮
│  └──────────────────┘   │
│  ┌──────────────────┐   │
│  │  如何优化查询... 3m │   │  ← 历史会话
│  └──────────────────┘   │
│  ┌──────────────────┐   │
│  │  报表已生成    1h  │   │  ← 历史会话
│  └──────────────────┘   │
│  ──────────────────────  │
│  🛠️ DevOps               │  ← Agent 项（折叠态）
│     K8s 运维与部署        │
│                          │
├──────────────────────────┤
│  💬 对话  🤖 员工  👤 我的│  ← Bottom Tab Bar
└──────────────────────────┘
```

### 6.2 Agent 项（折叠态）

```
┌──────────────────────────┐
│  🤖  代码助手             │  头像 + 名称（粗体）
│       全栈编程助手         │  描述（灰色，单行截断）
└──────────────────────────┘
```

- 点击 → 展开该 Agent 的会话列表（手风琴）
- 同时只展开一个 Agent（互斥）
- 再次点击已展开的 Agent → 折叠

### 6.3 Agent 项（展开态）

```
┌──────────────────────────┐
│  📊  数据分析 ▼           │  头像 + 名称 + 展开箭头
│       SQL 查询与数据报表   │  描述
│  ┌──────────────────┐   │
│  │  ＋ 新对话         │   │  主题色按钮，宽度 100%
│  └──────────────────┘   │
│  ┌──────────────────┐   │
│  │  如何优化 SQL... 3m │   │  历史会话：摘要 + 时间
│  └──────────────────┘   │
│  ┌──────────────────┐   │
│  │  报表已生成    1h  │   │  历史会话
│  └──────────────────┘   │
└──────────────────────────┘
```

**"新对话" 按钮**：
- 始终显示在展开区顶部
- 点击 → 跳转 `/m/chat` → 创建新 session → 聊天页

**历史会话项**：
- 左侧：无头像（节省空间）
- 第一行：会话标题/最后一条消息摘要（32 字符截断）
- 右侧：相对时间（"3分钟前"、"1小时前"）
- 点击 → 跳转 `/m/chat/:sessionKey` → 加载历史消息

**无历史会话时**：
- 只显示 "新对话" 按钮，不显示空状态文案

### 6.4 展开状态持久化

- 使用 `localStorage` 记录上次展开的 Agent ID
- Key: `mobile_expanded_agent_id_${userId}`（用户隔离，避免切换账号后展开错误 Agent）
- 页面加载时自动展开上次记录的 Agent
- 无记录时全部折叠
- 退出登录时清除该用户的展开状态

**数据来源**：
- Agent 列表：`useAgentTeamStore.fetchAgents()` → `AgentTeamMember[]`
- 历史会话：按当前展开的 Agent ID 过滤 `useSessionStore.sessions`
- 会话排序：按 `lastActiveAt` 降序

### 6.5 交互流

```
对话 Tab (/m/conversations)
  │
  ├── 点击 Agent → 展开/折叠（手风琴）
  │     │
  │     ├── 点击 "新对话"
  │     │     → router.push({ path: '/m/chat', query: { agentId: 'xxx' } })
  │     │     → 全屏聊天页（无 Tab Bar）
  │     │
  │     └── 点击历史会话
  │           → router.push('/m/chat/:sessionKey')
  │           → 全屏聊天页（无 Tab Bar）
  │
  └── 聊天页 ← 安全返回 → 回到对话 Tab（展开状态保持）
```

### 6.6 数据加载策略

| 时机 | 动作 | 说明 |
|------|------|------|
| 页面首次 mount | `fetchAgents()` + `fetchSessions()` | 并行请求 |
| 展开某个 Agent | 从已加载的 sessions 中过滤 | 内存过滤，不发请求 |
| SSE 收到 session 事件 | `sessionStore` 自动更新 | 会话列表响应式刷新 |
| 从聊天页返回 | 不重新请求 | `<keep-alive>` 保持组件实例 |
| Tab 切换回来 | 不重新请求 | `<keep-alive>` 保持组件实例 |
| 页面从后台恢复 | 刷新 agents + sessions | `visibilitychange` 监听，防止长时间后台数据陈旧 |

**后台恢复刷新**：
```typescript
// MobileConversationsPage.vue
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    fetchAgents()
    fetchSessions()
  }
})
```

此监听在组件 unmount 时自动清理（`keep-alive` 的 `onDeactivated` 不触发，但组件不会 unmount，所以需要用 `onBeforeUnmount` 注册清理）。

### 6.7 加载态与空态

| 状态 | 展示 |
|------|------|
| Agent 列表加载中 | 3 个骨架屏矩形块（模拟 Agent 项） |
| Agent 列表为空 | 居中提示"暂无数字员工" + "去创建" 按钮（跳转 `/m/agents/create`） |
| 展开区会话加载中 | "新对话" 按钮下方显示 spinner |
| 会话列表为空 | 仅显示 "新对话" 按钮，无额外文案 |

---

## 7. 聊天页设计（MobileChatPage）

全屏页面，无 Bottom Tab Bar。

```
┌──────────────────────────┐
│  ←  代码助手              │  顶部栏：返回按钮 + Agent 名称
├──────────────────────────┤
│                          │
│  消息列表                 │  主内容区（flex:1, overflow-y:auto）
│  ...                     │
│                          │
├──────────────────────────┤
│  [  输入消息...      ] ➤ │  输入栏
└──────────────────────────┘
```

### 7.1 顶部栏

- `←` 返回按钮 → 安全返回（见下方）
- 中间：当前 Agent 名称
- 右侧：暂无操作（后续迭代可加更多按钮）

**安全返回逻辑**：
```typescript
// 判断是否有可回退的历史记录
// 防止书签/外部链接直接进入聊天页时 back() 无效
function handleBack() {
  if (window.history.length > 1) {
    router.back()
  } else {
    router.push('/m/conversations')
  }
}
```

### 7.2 空状态（WelcomeScreen）

无活跃会话或新对话时展示：

```
居中垂直布局：
  1. 圆形 Agent 头像（来自 AgentTeamMember.avatar）
  2. "Hi，我是 {name}" 欢迎语
  3. Agent 描述文字（description 字段）
  4. 3 个推荐问题卡片（圆角矩形，点击即发送）
```

**推荐问题来源**：复用 PC 端 `ChatPage` 中已有的欢迎语/推荐问题逻辑。若 Agent 模板有 `suggestedQuestions` 字段则使用，否则降级为 3 个通用问题（"你好，请介绍一下你自己"、"你能帮我做什么？"、"帮我分析一下最近的日志"）。

### 7.3 消息气泡

| 类型 | 背景 | 文字色 | 对齐 | 圆角 |
|------|------|--------|------|------|
| AI 消息 | `#F0F0F0` | `#000` | 靠左 | 12px |
| 用户消息 | `#1890FF` | `#FFF` | 靠右 | 12px |

每条气泡左侧显示 Agent 头像（AI）或用户头像（用户）。气泡间距 8-12px，与屏幕边缘 padding 16px。

### 7.4 消息渲染

完整支持，与 PC 端一致：

- **Markdown 渲染**：复用 `renderSimpleMarkdown()`（`@/utils/markdown.ts`）
- **工具调用展示**：完整展示工具名、参数、结果，可展开/折叠
- **图片/附件**：缩略图展示，点击放大预览

**复用链路**：
```
ChatClient.history() → useChatStore.messages
  → chat-message-utils.ts (parseStructuredMessage / parseRawContent / parseToolResultMessage)
    → RenderMessage[]
      → MobileChatPage.vue 模板
        → renderSimpleMarkdown() (文本)
        → MobileToolCallCard.vue (工具调用)
        → MobileImagePreview.vue (图片)
```

### 7.5 工具调用卡片（MobileToolCallCard）

```
┌─ 🔧 工具调用 ──────────────┐
│  shell_execute              │  工具名（粗体）+ 状态标签
│  $ kubectl get pods         │  命令/参数（等宽字体）
│  ✓ 完成  [展开详情 ▼]       │  状态 + 展开按钮
└────────────────────────────┘

展开后：
┌─ 🔧 shell_execute ─────────┐
│  $ kubectl get pods -n app  │
│  ── 结果 ──                 │
│  NAME    STATUS   RESTARTS  │
│  app-xx  Running  0         │  结果内容（可滚动）
│  [复制]                     │  操作按钮
└────────────────────────────┘
```

### 7.6 输入栏（ChatInputBar）

```
默认态：
┌──────────────────────────────────┐
│  ＋   [    输入消息...     ]   ➤ │
│  附件     输入框              发送 │
└──────────────────────────────────┘

AI 回复中：
┌──────────────────────────────────┐
│  [    输入消息...          ]   ⬛ │
│                              停止 │
└──────────────────────────────────┘
```

**交互**：
- Enter 或点击 ➤ → `chatClient.send()`
- AI 回复中 → ➤ 变为 ⬛ 停止按钮 → `chatClient.abort()`
- ＋ 按钮 → 附件上传（首期隐藏）
- 输入框聚焦 → 自动滚动到底部

### 7.7 聊天页加载态与错误处理

| 状态 | 展示 |
|------|------|
| 历史消息加载中 | 消息区显示 3 个骨架屏气泡 |
| 发送消息失败 | 页面顶部 toast "发送失败，请重试" + 失败气泡旁显示重试按钮 |
| 网络断开 | 顶部横幅 "网络连接已断开"（持续显示直到恢复） |
| Agent 回复超时 | 无特殊处理，用户可随时点击停止按钮 |

### 7.8 键盘适配

软键盘弹起时的布局响应：

```css
/* ChatInputBar 定位策略 */
.chat-input-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  /* iOS 安全区域 */
  padding-bottom: env(safe-area-inset-bottom);
}
```

```typescript
// 监听 visualViewport 变化，动态调整消息列表高度
// iOS Safari 中 100vh 不随键盘收缩，需用 visualViewport.height
useVisualViewportResize(() => {
  const viewport = window.visualViewport
  if (viewport) {
    messageListHeight.value = viewport.height - headerHeight - inputBarHeight
  }
})
```

**关键行为**：
- 键盘弹起 → 消息列表自动滚到底部
- 键盘收起 → 布局恢复原始高度
- iOS：使用 `visualViewport.resize` 事件
- Android：使用 `window.resize` 事件 + CSS `env(keyboard-inset-height)`

---

## 8. 数字员工 Tab 设计（MobileAgentPage）

### 8.1 员工列表

2 列网格卡片布局：

```
┌──────────────────────────┐
│  数字员工        ＋ 创建  │
├──────────────────────────┤
│                          │
│  ┌────────┐ ┌────────┐  │
│  │  🤖    │ │  📊    │  │
│  │ 代码助手│ │ 数据分析│  │
│  │ 全栈编程│ │ SQL查询 │  │
│  │ 在线 🟢 │ │ 离线 ⚪ │  │
│  └────────┘ └────────┘  │
│  ┌────────┐ ┌────────┐  │
│  │  🛠️    │ │  📝    │  │
│  │ DevOps │ │ 文档生成│  │
│  │ K8s运维 │ │ README │  │
│  │ 在线 🟢 │ │ 在线 🟢 │  │
│  └────────┘ └────────┘  │
├──────────────────────────┤
│  💬 对话  🤖 员工  👤 我的│
└──────────────────────────┘
```

**卡片信息**：
- 头像（`AgentTeamMember.avatar`）
- 名称（`name`）
- 描述（`description`，单行截断）
- 状态指示（基于 `lastActiveAt` 或 `status`）

**数据来源**：`useAgentTeamStore.fetchAgents()` → `AgentTeamMember[]`

**交互**：
- 点击卡片 → 进入详情页 `/m/agents/:id`
- 点击 ＋ 创建 → 进入创建页 `/m/agents/create`

**加载态与空态**：

| 状态 | 展示 |
|------|------|
| 加载中 | 4 个骨架屏卡片（2×2 网格） |
| 列表为空 | 居中提示"暂无数字员工" + "创建第一个" 按钮 |
| 创建已达上限 | ＋ 按钮灰显 + tooltip 提示"已达创建上限" |

### 8.2 员工详情页

全屏子页面，无 Tab Bar。

```
┌──────────────────────────┐
│  ←  员工详情              │
├──────────────────────────┤
│       ┌─────────┐       │
│       │  🤖 头像 │       │  大头像 80px
│       └─────────┘       │
│       代码助手            │
│       全栈编程助手...     │
│                          │
│  ┌──────────────────┐   │
│  │    💬 去对话       │   │  主按钮
│  └──────────────────┘   │
│                          │
│  ── 基本信息 ──────────  │
│  模型    deepseek-v3     │
│  分类    开发工具         │
│  创建时间 2026-06-01     │
│                          │
│  ── SOUL 配置 ──────────  │
│  你是一个全栈编程助手...   │  可展开
│                          │
│  ── 身份配置 ──────────  │
│  名称：代码助手           │  可展开
│  角色：高级开发工程师     │
│                          │
├──────────────────────────┤
│     [ 编辑 ]  [ 删除 ]   │  底部操作栏
└──────────────────────────┘
```

**"去对话"按钮逻辑**：
1. 从 `sessionStore.sessions` 中过滤该 Agent 的会话
2. 有会话 → 按 `lastActiveAt` 降序取最近一条 → 跳转 `/m/chat/${sessionKey}`
3. 无会话 → 走新对话流程：`router.push({ path: '/m/chat', query: { agentId } })`

**删除操作**：二次确认弹窗 → `useAgentTeamStore.deleteAgent(id)`

### 8.3 创建/编辑员工页

全屏子页面，无 Tab Bar。分步表单，单页滚动：

```
┌──────────────────────────┐
│  ←  创建数字员工          │
├──────────────────────────┤
│                          │
│  ① 选择模板               │
│  ┌──────┐ ┌──────┐      │
│  │ 开发  │ │ 运维  │      │  模板网格
│  │ 助手  │ │ 专家  │      │  来自 AgentTemplate
│  └──────┘ └──────┘      │
│  ┌──────┐ ┌──────┐      │
│  │ 数据  │ │ 文档  │      │
│  │ 分析  │ │ 生成  │      │
│  └──────┘ └──────┘      │
│                          │
│  ② 基本信息               │
│  名称: [________]         │
│  描述: [________]         │
│  模型: [deepseek-v3 ▾]    │  下拉选择
│                          │
│  ③ 角色配置（可选）        │
│  SOUL: [多行文本域]        │
│  身份: [多行文本域]        │
│                          │
│  ┌──────────────────┐   │
│  │      创建          │   │
│  └──────────────────┘   │
└──────────────────────────┘
```

**API 复用**：
- 模板列表：`useAgentTeamStore.fetchTemplates()`
- 创建上限：`useAgentTeamStore.checkCreateLimit()`
- 提交：`useAgentTeamStore.createAgent()` / `updateAgent()`

**编辑模式**：路由 `/m/agents/:id/edit`，预填已有数据。

---

## 9. 我的 Tab 设计（MobileProfilePage）

极简设计，仅展示用户信息 + 退出登录。

```
┌──────────────────────────┐
│                          │
│         🦞               │  WattClaw 图标（居中，64px）
│                          │
│       admin              │  用户名（居中，粗体，16px）
│                          │
│  ┌──────────────────┐   │
│  │    退出登录         │   │  红色按钮，宽度 100%
│  └──────────────────┘   │
│                          │
│                          │
│                          │
│                          │
├──────────────────────────┤
│  💬 对话  🤖 员工  👤 我的│
└──────────────────────────┘
```

**退出登录流程**：
1. 点击"退出登录" → 弹出确认弹窗"确定要退出登录吗？"
2. 确认 → `authStore.logout()` → 清理所有 Pinia store 状态 → 跳转 `/m/login`

**数据来源**：
- 用户名：`useAuthStore.user.username`

---

## 10. 组件文件清单

```
src/mobile/
├── layout/
│   └── MobileTabLayout.vue              # Tab Bar 壳 + 底部导航 (~120行)
├── components/
│   └── MobileTabBar.vue                 # 底部 Tab Bar 组件 (~100行)
├── views/
│   ├── login/
│   │   └── MobileLoginPage.vue          # 登录页 (~120行)
│   ├── chat/
│   │   ├── MobileConversationsPage.vue  # 对话 Tab：Agent 手风琴列表 (~250行)
│   │   ├── MobileChatPage.vue           # 全屏聊天页 (~500行)
│   │   ├── WelcomeScreen.vue            # 空状态欢迎页 (~100行)
│   │   ├── MessageBubble.vue            # 消息气泡 (~150行)
│   │   ├── MobileToolCallCard.vue       # 工具调用卡片 (~200行)
│   │   ├── MobileImagePreview.vue       # 图片预览 (~80行)
│   │   └── ChatInputBar.vue             # 底部输入栏 (~150行)
│   ├── agents/
│   │   ├── MobileAgentPage.vue          # 员工列表页 (~200行)
│   │   ├── MobileAgentDetailPage.vue    # 员工详情页 (~250行)
│   │   ├── MobileAgentEditPage.vue      # 创建/编辑页 (~300行)
│   │   └── AgentCard.vue                # 员工卡片 (~80行)
│   └── profile/
│       └── MobileProfilePage.vue        # 我的 Tab (~80行)
├── composables/
│   ├── useMobileRedirect.ts             # UA 检测 + 自动跳转 (~50行)
│   └── useVisualViewportResize.ts       # 键盘适配 visualViewport 监听 (~40行)
├── router/
│   └── mobile-routes.ts                 # 移动端路由定义 (~60行)
└── styles/
    └── mobile.css                       # 移动端 CSS 变量 (~100行)
```

**预估总量**：~2590 行移动端新增代码，0 行 PC 代码修改。

**与旧方案对比**：

| 删除 | 新增 |
|------|------|
| AppSidebar.vue (~150行) | MobileTabBar.vue (~100行) |
| SessionPicker.vue (~200行) | MobileConversationsPage.vue (~250行) |
| SettingsSheet（内嵌） | MobileProfilePage.vue (~80行) |

净增约 80 行，但交互更直接（Tab 直接切换，无需侧边栏抽屉 + SessionPicker 面板两步操作）。

---

## 11. 复用层清单

以下现有模块在移动端直接 import，不做任何修改：

| 模块 | 路径 | 用途 |
|------|------|------|
| Chat Store | `src/stores/chat.ts` | 消息状态、发送、历史加载 |
| Session Store | `src/stores/session.ts` | 会话列表、session CRUD |
| Agent Team Store | `src/stores/agent-team.ts` | 员工列表、创建、编辑、删除 |
| Auth Store | `src/stores/auth.ts` | JWT token、登录状态 |
| ChatClient | `src/api/chat-client.ts` | REST 发送/中断/历史 |
| HTTP Client | `src/api/http-client.ts` | REST 请求封装 |
| 消息解析工具 | `src/views/chat/chat-message-utils.ts` | parseStructuredMessage 等 |
| Markdown 渲染 | `src/utils/markdown.ts` | renderSimpleMarkdown |
| 事件流 | `src/composables/useEventStream.ts` | SSE 实时事件 |
| 类型定义 | `src/api/types/` | 所有接口类型 |

---

## 12. 配色与样式

### CSS 变量

```css
/* src/mobile/styles/mobile.css */
:root {
  /* 主题色 */
  --m-primary: #1890FF;
  --m-primary-light: #E6F7FF;

  /* 背景 */
  --m-bg-page: #F5F5F5;
  --m-bg-card: #FFFFFF;
  --m-bg-input: #F0F0F0;

  /* 消息气泡 */
  --m-bubble-ai-bg: #F0F0F0;
  --m-bubble-user-bg: #1890FF;
  --m-bubble-ai-text: #000000;
  --m-bubble-user-text: #FFFFFF;

  /* 文字 */
  --m-text-primary: #333333;
  --m-text-secondary: #666666;
  --m-text-hint: #999999;

  /* 边框/分割 */
  --m-border: #E8E8E8;
  --m-divider: #F0F0F0;

  /* 圆角 */
  --m-radius-sm: 8px;
  --m-radius-md: 12px;
  --m-radius-lg: 16px;

  /* Tab Bar */
  --m-tab-bar-bg: #FFFFFF;
  --m-tab-bar-active: #1890FF;
  --m-tab-bar-inactive: #999999;
}

[data-theme='dark'] {
  --m-bg-page: #1A1A1A;
  --m-bg-card: #2C2C2C;
  --m-bg-input: #333333;
  --m-bubble-ai-bg: #333333;
  --m-bubble-ai-text: #E8E8E8;
  --m-bubble-user-bg: #1890FF;
  --m-bubble-user-text: #FFFFFF;
  --m-text-primary: #E8E8E8;
  --m-text-secondary: #AAAAAA;
  --m-text-hint: #666666;
  --m-border: #3A3A3A;
  --m-divider: #2C2C2C;
  --m-tab-bar-bg: #1A1A1A;
  --m-tab-bar-active: #1890FF;
  --m-tab-bar-inactive: #666666;
}
```

### 设计规范

- 安全区域：`env(safe-area-inset-*)` 适配刘海/底部横条
- 触摸目标：最小 44px × 44px
- 字体：系统默认，正文 14px，标题 16-18px
- 间距：padding 16px，元素间距 8-12px
- 滚动：`-webkit-overflow-scrolling: touch`，弹性滚动

---

## 13. 首期范围

### ✅ 实现

| 功能 | 页面/组件 |
|------|----------|
| 移动端 UA 自动跳转 | useMobileRedirect |
| 登录页（用户名密码） | MobileLoginPage |
| 登录守卫（未登录拦截） | router meta + beforeEach |
| Bottom Tab Bar（3 Tab） | MobileTabBar + MobileTabLayout |
| 对话 Tab：Agent 手风琴列表 | MobileConversationsPage |
| 对话 Tab：展开状态持久化 | localStorage |
| 对话 Tab："新对话"入口 | MobileConversationsPage |
| 对话 Tab：历史会话列表 | MobileConversationsPage |
| 聊天页：全屏消息渲染 | MobileChatPage + MessageBubble |
| 聊天页：Markdown/代码块 | 复用 renderSimpleMarkdown |
| 聊天页：工具调用展示 | MobileToolCallCard |
| 聊天页：图片预览 | MobileImagePreview |
| 聊天页：输入/发送/中断 | ChatInputBar |
| 聊天页：空状态欢迎页 | WelcomeScreen |
| 数字员工：列表展示 | MobileAgentPage + AgentCard |
| 数字员工：详情查看 | MobileAgentDetailPage |
| 数字员工：创建/编辑 | MobileAgentEditPage |
| 数字员工：快捷"去对话" | MobileAgentDetailPage |
| 我的：用户信息 + 退出登录 | MobileProfilePage |

### 🔲 后续迭代

- 飞书 OAuth 登录
- 附件上传功能
- 语音输入
- 消息搜索
- 深色模式切换
- 推送通知
- PWA 离线支持
- 对话 Tab：左滑删除会话
- 对话 Tab：下拉刷新会话列表
- 聊天页：右滑返回（iOS 原生手势已支持，无需额外实现）

---

## 14. 技术约束

- `<script setup lang="ts">` only，禁止 Options API
- `defineProps<{ prop: Type }>()` 泛型语法
- `import type { ... }` 类型导入
- `<style scoped>` 所有组件
- 所有用户可见文字通过 `t('key')` i18n
- i18n key 命名空间：`pages.mobile.*`（如 `pages.mobile.login.title`、`pages.mobile.chat.send`）
- 新增约 60-80 个 i18n key，同步添加到 `src/i18n/zh-CN.ts` 和 `src/i18n/en-US.ts`
- `shallowRef` 用于大对象，避免深度响应式
- 不引入新 UI 框架，复用 Naive UI 组件 + 手写移动端样式
- viewport: `<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">`

### Naive UI 移动端使用策略

Naive UI 是桌面优先组件库，移动端需区分使用：

| 组件 | 策略 | 说明 |
|------|------|------|
| NInput | 复用 + CSS override | 移动端字体 ≥16px 防止 iOS 自动缩放 |
| NButton | 复用 + CSS override | 最小高度 44px |
| NSkeleton | 复用 | 骨架屏直接使用 |
| NSpin | 复用 | 加载指示器 |
| NModal / NDialog | 复用 + 全屏化 | 确认弹窗等 |
| NAlert | 复用 | 错误提示 |
| NSelect | ⚠️ 改用原生 `<select>` 或底部 ActionSheet | Naive UI 下拉在移动端体验差 |
| NDropdown | ⚠️ 改用底部 ActionSheet | 同上 |
| NInput (textarea) | 复用 + CSS override | 多行输入 |
| NForm / NFormItem | 不使用 | 移动端手写布局更灵活 |
