# Usage Cache 读写分离重构设计

日期：2026-06-11
状态：待用户审阅
范围：仪表盘 usage / 用户 Token 消耗统计 / Gateway usage 同步

## 1. 背景

当前仪表盘的“用户 Token 消耗统计”在 admin 账户下数据错误。根因不是前端展示单点问题，而是后端 usage 数据流把“读取统计”和“同步 Gateway usage”混在同一个接口里。

当前风险链路：

```text
Dashboard 请求 /api/sessions/usage
→ 后端调用 Gateway sessions.usage
→ batchUpdateFromGatewayUsage 写 SQLite
→ getUserAggregates 再从 SQLite 聚合返回
```

这个接口表面是读取，实际有写入副作用。更严重的是 usage cache 当前写入使用 `session_key` 作为唯一锚点：

```sql
WHERE session_key = ?
```

但 WattClaw 的本地归属模型是 `user_sessions.user_id + user_sessions.session_key`。两者边界不一致，会导致同名 `session_key` 跨用户更新，进而污染 admin 用户统计和普通用户会话 usage。

## 2. 设计目标

本次重构目标是把 usage 的展示读取和 Gateway 同步写入彻底拆开。

目标数据流：

```text
启动同步：
server listen
→ session/agent ownership sync 完成
→ user_sessions 归属补齐
→ enqueue startup usage sync
→ Gateway sessions.usage
→ 只更新已存在且唯一归属的 user_sessions 行
→ 输出 UsageSyncReport

仪表盘读取：
Dashboard
→ /api/sessions/usage
→ 只读 SQLite aggregates
→ 必要时只 enqueue 后台 sync，不 await Gateway

聊天完成：
chat.done / session done
→ scheduleSessionUsageSync(sessionKey)
→ per-session debounce / singleflight
→ 拉当前 session usage
→ 匹配本地唯一 owner
→ 按 user_id + session_key 写入 SQLite
```

核心原则：

1. `/api/sessions/usage` 必须是纯读接口。
2. Gateway usage 只能作为同步来源，不能在页面读取时被同步等待。
3. usage 写入必须带本地归属边界：`user_id + session_key`。
4. Gateway 返回的未归属 session 不允许猜测写入。
5. admin 的用户 Token 统计必须从 SQLite 按用户聚合。
6. 启动 usage sync 必须依赖 session ownership sync 完成。
7. usage sync 不负责创建 `user_sessions` 归属。
8. 聊天完成 usage sync 必须按 session 去重，避免 Gateway RPC 风暴。

## 3. 推荐方案

采用“SQLite 作为 usage 展示唯一读源 + Gateway 后台同步”的中等范围重构。

不建议只做止血版，因为只去掉 admin 写 cache 仍会保留 usage 同步时机混乱的问题。

不建议第一阶段新增独立 `session_usage_cache` 表，因为当前问题可以在现有 `user_sessions` schema 内解决，迁移成本更低。

## 4. 模块改动设计

### 4.1 `server/index.js`

#### 现状

`_handleUsageProxy(params, userId, isAdmin)` 会先调用 Gateway，再写 SQLite，最后读 SQLite。

#### 修改后

`_handleUsageProxy()` 改为纯 SQLite 读：

```text
if admin:
  result = getUserAggregates(null)
  if include=userUsage:
    userUsage = getAdminUserUsageAggregates()
else:
  result = getUserAggregates(userId)
```

返回结构保持兼容当前前端客户端：

```json
{
  "ok": true,
  "payload": { "sessions": [], "totals": {}, "aggregates": {} },
  "userUsage": []
}
```

其中 `userUsage` 仍放在顶层，因为 `src/api/usage-client.ts` 当前读取的是 `body.userUsage`，不是 `body.payload.userUsage`。

### 4.2 `server/core/session-usage-cache.js`

#### 现状问题

`_persistToDatabase(sessionKey, entry)` 只按 `session_key` 更新：

```sql
WHERE session_key = ?
```

这破坏多用户隔离。

#### 修改后

新增明确归属写入入口：

```text
updateSessionUsageForUser(userId, sessionKey, usageData)
```

内部只允许：

```sql
WHERE user_id = ? AND session_key = ?
```

如果更新 0 行，只记录告警，不创建新归属。

批量同步函数改为：

```text
batchUpdateMatchedGatewayUsage(gatewayResult)
```

它不接收“当前请求用户”，而是从本地 `user_sessions` 解析真实归属。

匹配规则：

1. 先按 `session_key` 查本地 `user_sessions`。
2. 如果只有一条匹配，更新该 `user_id + session_key`。
3. 如果多条匹配，视为冲突，跳过并记录日志。
4. 如果没有 `session_key` 匹配，跳过并记录为未归属。
5. `agent_id` 只用于诊断日志，不在 usage sync 中创建或补齐 session 归属。
6. 仍无法确定归属的 Gateway session 跳过。

禁止行为：

- 禁止按当前请求用户写入 Gateway 全量 usage。
- 禁止只按 `session_key` 更新 usage。
- 禁止为未匹配 Gateway session 自动创建 `user_sessions`。
- 禁止 usage sync 调用 `trackSessionForUser()` 补归属。

### 4.3 启动后台同步

在服务启动后增加一个后台 usage 同步入口：

```text
syncUsageFromGatewayOnStartup()
```

执行时机放在 server listen 后，但必须等待 session ownership sync 完成后再 enqueue usage sync。它可以异步后台执行，但不能和 session sync 并行抢跑。

推荐行为：

```text
server listen
→ syncSessionsFromGateway / ownership sync 完成
→ user_sessions 归属补齐
→ enqueue startup usage sync
→ Gateway 成功：只更新已存在且唯一归属的 session
→ Gateway 失败：记录错误，不影响页面
```

如果 session ownership sync 失败，startup usage sync 应跳过或延后，不应独立执行。原因是 usage sync 的安全前提是本地已经有可靠的 `user_sessions` 归属。

不要把它设计成“只首次重启”。更准确的定义是：

```text
每次服务启动后后台尝试同步一次。
```

原因：服务可能多次重启，也可能长期不重启；usage 的最终新鲜度应由“启动同步 + 聊天完成增量同步”共同保证。

### 4.4 聊天完成增量同步

在聊天完成事件后补充单 session usage 更新。该更新必须通过 per-session debounce / singleflight 调度，避免高频消息或重复 done 事件造成 Gateway RPC 风暴。

推荐触发点：

- `chat.done`
- `session.done`
- 或后端确认当前 session 消息最终落库之后

推荐流程：

```text
on chat done
→ scheduleSessionUsageSync(sessionKey, delayMs)
→ 同一 sessionKey 短窗口内只保留一个 pending sync
→ resolve userId + sessionKey
→ call Gateway usage for current session
→ updateSessionUsageForUser(userId, sessionKey, usage)
```

注意事项：

- 不要在流式中途同步 usage。
- 如果 Gateway usage 有延迟，可延后一次或短重试。
- 如果无法确认 owner，跳过并记录日志。
- 同一个 `sessionKey` 在短窗口内只能有一个同步任务。
- 后续触发应合并到已有 pending 任务，而不是重复发 Gateway RPC。

### 4.5 admin 用户 Token 消耗统计

admin 的用户 Token 消耗统计不再从 Gateway 全量结果临时计算。

改为 SQLite 聚合：

```sql
SELECT
  u.id AS userId,
  u.username,
  u.display_name,
  COUNT(us.id) AS sessionCount,
  COALESCE(SUM(us.token_total), 0) AS totalTokens,
  COALESCE(SUM(us.token_input), 0) AS inputTokens,
  COALESCE(SUM(us.token_output), 0) AS outputTokens,
  COALESCE(SUM(us.cost_total), 0) AS totalCost
FROM users u
LEFT JOIN user_sessions us ON us.user_id = u.id
GROUP BY u.id
ORDER BY totalTokens DESC
```

不建议第一版把未归属 Gateway session 混入 admin 榜单。未归属数据应该进入同步日志或诊断，不应该显示成业务用户。

`sessionCount` 定义为当前用户拥有的会话总数，不限于已产生 token 的会话。`totalTokens/inputTokens/outputTokens/totalCost` 定义为这些会话的累计 usage。

如果用户表存在状态字段，第一版仅展示仍存在且有效的用户；如果当前 schema 没有状态字段，则展示 `users` 表中仍存在的用户。被删除用户的历史 session 应由外键级联或现有删除逻辑处理，不在 admin 榜单中额外构造历史用户。

## 5. 逻辑风险与处理

### 5.1 启动同步慢

风险：Gateway usage 数据多时，启动同步耗时长。

处理：后台异步执行，不阻塞 server listen，不阻塞仪表盘读取。

### 5.2 Gateway 不可用

风险：启动时 Gateway 离线，无法同步最新 usage。

处理：页面继续读取 SQLite 旧值；日志记录同步失败。后续聊天完成时仍可增量刷新。

### 5.3 未归属 session 被跳过

风险：Gateway 有 usage，但本地没有 `user_sessions` 归属记录。

处理：跳过。安全优先，不猜 owner。后续由 session 同步补齐归属后，下一次 usage 同步再写入。

### 5.4 重复 session_key 脏数据

风险：同一个 `session_key` 出现在多个用户名下。

处理：第一阶段检测冲突并跳过 usage 写入，避免继续污染。后续可增加清理脚本或唯一约束。

### 5.5 聊天完成同步时机太早

风险：刚收到 done 事件时 Gateway usage 还未最终刷新。

处理：只在最终事件后同步；如发现仍有延迟，再加一次短延迟重试。

### 5.6 admin 页面数据延迟

风险：admin 不再实时查询 Gateway，看到的是 SQLite 中最后同步结果。

处理：保留 `usage_synced_at`。第一版可只用于后端判断，后续再考虑 UI 展示“最后同步时间”。

### 5.7 纯读接口遇到空 usage

风险：新环境或清库后 SQLite 没有任何 usage，仪表盘返回 0，用户可能误以为统计错误。

处理：`/api/sessions/usage` 仍然立即返回 SQLite 当前值；如果检测到全库或当前用户没有任何 `usage_synced_at`，可以 enqueue 一次后台 sync，但不能 await Gateway，也不能在请求栈内写 cache。

### 5.8 同步可观测性不足

风险：同步失败、跳过、冲突不可见，后续排查仍靠猜。

处理：每次 startup/batch/session usage sync 输出 `UsageSyncReport` 日志：

```text
UsageSyncReport {
  scanned
  updated
  skippedUnmatched
  skippedConflict
  failed
  durationMs
}
```

第一版只打日志，不落库。

### 5.9 历史污染不会自动修复

风险：切断未来污染后，历史已经写错的 `token_total` 仍可能影响 admin 榜单。

处理：本次只防止继续污染，不自动清洗历史 token。历史修复需要单独诊断脚本，按 Gateway usage 与本地唯一归属重新回填。

## 6. 推荐实施顺序

### 阶段一：切断读路径写副作用

1. 修改 `_handleUsageProxy()` 为 SQLite 纯读。
2. admin `include=userUsage` 改为 SQLite 用户聚合。
3. 保持前端 `UsageClient` 返回结构兼容。

### 阶段二：修正 usage 写入边界

1. 新增 `updateSessionUsageForUser(userId, sessionKey, usageData)`。
2. 禁止 `_persistToDatabase()` 只按 `session_key` 更新。
3. 批量 Gateway usage 同步改成先匹配本地归属。

### 阶段三：启动后台同步

1. 新增 `syncUsageFromGatewayOnStartup()`。
2. 确保 session ownership sync 完成后再 enqueue。
3. server listen 后异步触发，不阻塞启动。
4. 同步失败只记录日志。
5. 输出 `UsageSyncReport`。

### 阶段四：聊天完成增量同步

1. 找到 chat done / session done 后端事件入口。
2. 新增 `scheduleSessionUsageSync(sessionKey)`。
3. 对同一 sessionKey 做 debounce / singleflight。
4. 对当前 session 拉 usage。
5. 按 `user_id + session_key` 更新 SQLite。

### 阶段五：验证与清理

1. 验证 admin userUsage 聚合正确。
2. 验证普通用户只看到自己的 usage。
3. 验证 `/api/sessions/usage` 不再触发 Gateway RPC。
4. 验证重复 session_key 不会被跨用户更新。
5. 验证启动同步失败不影响服务启动。

## 7. 验证计划

### 后端行为验证

- admin 调用 `/api/sessions/usage?include=userUsage`：
  - 返回 `payload.totals`
  - 返回顶层 `userUsage`
  - 不调用 Gateway usage

- 普通用户调用 `/api/sessions/usage`：
  - 只聚合当前 `user_id`
  - 不返回其他用户数据

- Gateway 批量同步：
  - 已归属 session 更新成功
  - 未归属 session 跳过
  - 重复 session_key 跳过并告警
  - 输出 `UsageSyncReport`

- 纯读接口空数据场景：
  - 立即返回 SQLite 当前值
  - 可以 enqueue 后台 sync
  - 不 await Gateway
  - 不在请求栈内写 cache

- 聊天完成增量同步：
  - 同一 sessionKey 多次触发只产生一个 pending sync
  - sync 执行时按 `user_id + session_key` 更新
  - 无唯一 owner 时跳过并告警

### 数据安全验证

构造同一个 `session_key` 属于两个用户的脏数据：

```text
user A + session X
user B + session X
```

同步 Gateway usage 后预期：

```text
不更新任意一方
记录冲突日志
```

### 构建验证

执行基础构建：

```bash
npm run build
```

如只改后端 JS，也仍需跑构建，确保前端类型未受返回结构影响。

## 8. 不在本次范围内

以下内容不纳入第一阶段：

1. 新建独立 `session_usage_cache` 表。
2. 前端新增“最后同步时间”展示。
3. 周期性全量 usage 同步调度。
4. 自动修复所有历史重复 session_key 数据。
5. 自动清洗历史已污染 token_total。
6. 大规模拆分 `server/index.js`。

这些可以作为后续优化，但不应阻塞当前 bug 修复。长期看，独立 `session_usage_cache` 表仍是更清晰的演进方向；本次只是为了降低迁移成本，先在现有 `user_sessions` schema 内收敛读写边界。

## 9. 最终设计摘要

本次重构应把 usage 系统改成：

```text
SQLite 是唯一展示读源。
Gateway 是后台同步来源。
读接口不写数据。
写入必须携带 user_id + session_key。
admin 用户统计从 SQLite GROUP BY user_id 得出。
```

这能同时解决：

- admin 用户 Token 消耗统计错误；
- 仪表盘读接口污染 usage cache；
- `session_key` 跨用户更新；
- Gateway 全局 usage 与本地用户归属边界不一致；
- usage 同步时机不可控。
