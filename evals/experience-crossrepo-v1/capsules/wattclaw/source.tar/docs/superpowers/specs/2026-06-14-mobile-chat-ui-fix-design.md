# 移动端对话模块 UI 与实时流修复设计

- 日期：2026-06-14
- 模块：移动端 `/m` 对话（聊天）
- 状态：根因已从代码确认，待实现
- 方案选型：A（移动端新建/改造展示组件，复用 `chat.ts` 与网页端 markdown 工具，不改动网页端）

## 1. 目标

集中修复移动端 `/m` 对话模块的 5 个 UI/Bug 问题，使移动端行为与网页端 `ChatPage` 一致：

1. 新会话标题错误显示为 `uuid · 消息内容`（如 `mqduxlsh-xzzxg8rl · 你好…`）
2. 发送消息后无 agent 思考过程
3. AI 消息未渲染 markdown，样式异常
4. 收不到实时推送，只能从历史会话看结果
5. 不显示工具调用

## 2. 范围

- 仅移动端 `src/mobile/` 展示层 + 必要的 server 标题生成修正
- 复用现有 `chat.ts` store（数据层已完整）与网页端 `MarkdownRenderer`
- 不重构网页端，不改动 Gateway 协议

## 3. 根因分析（代码确认）

### 3.1 标题错误（uuid · 消息）

- 前端 `generateSafeTitle`（`src/utils/session-title.ts`）只产出截断 32 字符的纯标题，不拼接 uuid；`chat.ts:548 updateCurrentSessionTitle` 与 `session.ts` label 同步均走它，前端干净。
- 标题格式来自 server `session-title-service.js:84 resolveSessionDisplayTitle`，产出 `{channelLabel} · {summary}`。
- 网页端 session channel 正确（`webchat`/`main`）→ channelLabel = 「在线对话」→ 标题「在线对话 · 你好」。**注意：网页端标题本身也非纯标题，而是「渠道·摘要」格式。**
- 移动端 session 的 channel 异常（`createNewSession` 传 `channel: ''`，server 侧渠道解析落入 uuid 兜底）→ channelLabel 位变成 sessionKey 的 uuid（`mqduxlsh-xzzxg8rl`）→ 标题「uuid · 你好」。
- 网页端 `/api/workspace/send` 发消息时会以 `${safeTitle}-${Date.now()}` patch label（`chat.js:137`），但 `safeTitle` 来自 `req.body.title`，而 `chat.ts sendMessage` 不传 title（网页端 `ChatPage.vue:1078` 同样只传 content），故此 patch 路径对两端均不生效；标题实际由 server 在 session 创建/活动回填时经 `resolveSessionDisplayTitle` 生成。
- 用户已明确选择**纯标题**（「你好」，比网页端更纯），因此修复以前端剥离渠道前缀为主，不依赖 server channel 修正。
- `MobileConversationsPage.vue:182` 标题回退链 `displayTitle || label || session.key` 残留了 server 的 `{X} · {summary}`。

### 3.2 无思考过程

- `chat.ts` 已实现完整 agent 状态机：`agentStatuses`、`agentSteps`、`setAgentStatusPhase`、`handleAgentStatusEvent`。
- `MobileChatPage.vue` 模板仅渲染 `MessageBubble`，未读取/渲染 `agentStatuses` / `agentSteps`。数据就绪，纯展示层缺失。

### 3.3 消息样式异常

- `MessageBubble.vue:28` 使用 `{{ content }}` 文本插值，`white-space: pre-wrap`。
- AI 回复的 markdown（`##` / `###` / `-`）原样显示为纯文本。
- 网页端使用 `src/views/workspace/components/MarkdownRenderer.vue`（基于 `src/composables/useMarkdownIt.ts`）渲染。

### 3.4 收不到实时推送

- 实时通道为 SSE：`useWebSocketStore` → `OpenClawWebSocket` → `ApiClient`（EventSource），命名虽为 WebSocket，实际非真 WebSocket。
- `wsStore.connect()` 仅在 `src/layouts/DefaultLayout.vue:17`（网页端布局）onMounted 调用。
- `src/mobile/` 全目录 grep `wsStore|connect()` 零匹配：移动端 `MobileTabLayout.vue` 与 `/m/chat` 全屏页均未建立 SSE 连接。
- 因此 `chat.ts subscribeRealtimeEvents` 注册的 handler 永不触发，实时事件全丢，仅靠 `schedulePostSendRefreshes` 的 `fetchHistory` 轮询兜底。
- 架构差异：网页端 `ChatPage.vue:994` 直接 `wsStore.subscribe('event', ...)` 用自己的 handler 处理实时（依赖 DefaultLayout 的 connect）；移动端经 `chat.ts subscribeRealtimeEvents` 的 handler。故移动端是 `chat.ts` 实时逻辑（`handleRealtimeEvent` / `handleAgentStatusEvent`）的**首个消费者**，connect 建立后需端到端验证该 handler 正确性。

### 3.5 不显示工具调用

- 同 3.2，`MobileChatPage` 未渲染 `chat.ts` 的 `toolProgress`（工具名 / 参数 / 结果）。

## 4. 设计方案

### 4.1 标题 → 纯标题

前端（主修复，立竿见影）：

- `MobileConversationsPage.vue:182` 标题显示统一过剥离：对 `displayTitle`/`label` 按 ` · ` 分割取末段（摘要），再 `stripGeneratedTitleSuffix`，得到纯标题；此规则对渠道位是「在线对话」还是 uuid 均生效，直接达成用户要求的纯标题。
- 新会话无标题时显示 i18n 占位（`pages.mobile.chat.newConversation`），不再回退到含 uuid 的 `session.key`。
- 同步在 `zh-CN.ts` / `en-US.ts` 增补占位 key。

server / 创建侧（次要，源头治理）：

- 排查 `createNewSession` 传 `channel: ''` 后 server 为何把 sessionKey uuid 当渠道标签（实现时定位 `/api/user/sessions` 创建与 `resolveSessionDisplayTitle` 调用处），改为传 `channel: 'webchat'` 从源头避免。
- 该项为次要优化；前端剥离已能独立达成纯标题目标，server 修正不阻塞前端修复。

### 4.2 思考过程 + 工具调用 → 消息流内嵌

新增 `src/mobile/views/chat/AgentStatusBlock.vue`：

- props：`agentId: string`
- 从 `chat.ts` 读取：`agentStatuses.get(agentId)`、`agentSteps.get(agentId)`、`toolProgress.get(agentId)`。
- 渲染：
  - 思考时间线：`agentSteps` 的 phase 序列（thinking / tool / replying 等）。
  - 工具块：`toolProgress` 的 `name` / `argsPreview` / `resultPreview`，可折叠展开。
- 仅当当前 agent 处于活跃 phase（非 idle/done/aborted/error）时显示。

`MobileChatPage.vue`：

- 在消息列表末尾插入 `AgentStatusBlock`（绑定当前 agentId，从 sessionKey 解析 `agent:([^:]+):`）。
- 复用网页端 `ChatPage` / `AgentChatPanel` 的状态展示形态，移动端适配紧凑布局。

### 4.3 消息 markdown 渲染

`MessageBubble.vue`：

- `role === 'assistant'`：用 `MarkdownRenderer`（或 `useMarkdownIt`）渲染 `content`。
- `role === 'user'`：保持纯文本（用户输入不渲染 markdown，防注入与排版失控）。
- 调整 assistant 气泡样式，使 markdown 块（代码块 / 列表 / 标题）正常排版。

### 4.4 实时推送 → 建立 SSE 连接

- `src/mobile/layout/MobileTabLayout.vue` onMounted 调 `wsStore.connect()`，对齐 `DefaultLayout.vue`。
- `/m/chat` 全屏页（`MobileChatPage.vue`）位于 MobileTabLayout 之外，onMounted 检查 `wsStore.state`，未连接则 `wsStore.connect()` 兜底，覆盖深链直进聊天页场景。
- 保持 `chat.ts subscribeRealtimeEvents` 现有逻辑；连接建立后事件即可到达，sessionKey 过滤（`chat.ts:724`）无需改动（fetchHistory 已证明 sessionKey 正确）。
- 实现时需端到端验证 `chat.ts` 的 `handleRealtimeEvent` / `handleAgentStatusEvent` 在 SSE 连通后能正确合并增量消息与更新 agent 状态（首个消费者，网页端未走此路径）。

## 5. 架构原则

- 单一权威实现：复用 `chat.ts` 与 `MarkdownRenderer`，不新增重复状态机或 markdown 解析。
- 移动端页面级隔离：新增组件置于 `src/mobile/views/chat/`，不污染网页端。
- SSE 连接策略移动端对齐网页端（layout 级 connect，store 单例幂等）。
- 遵守 `.claude/rules/mobile-ui.md`、`typescript-vue.md`、`node-express.md`。

## 6. 涉及文件

新增：

- `src/mobile/views/chat/AgentStatusBlock.vue`

修改：

- `src/mobile/views/chat/MobileConversationsPage.vue`（标题显示）
- `src/mobile/views/chat/MessageBubble.vue`（markdown 渲染）
- `src/mobile/views/chat/MobileChatPage.vue`（AgentStatusBlock 接入、createNewSession channel、ws 兜底连接）
- `src/mobile/layout/MobileTabLayout.vue`（wsStore.connect）
- `server/services/session-title-service.js` 或 session 创建 handler（channel 兜底）
- `src/i18n/zh-CN.ts`、`src/i18n/en-US.ts`（新对话占位 key）

## 7. 验证

- `npx vue-tsc --noEmit` 类型检查通过。
- `npm run build` 通过（仅 Vite chunk-size warning 可接受）。
- 手动验证（移动端 `/m`）：
  1. 新会话发消息 → 标题为纯消息内容，无 uuid 前缀。
  2. 发送后 → 思考过程时间线实时出现。
  3. AI 回复 → markdown（标题 / 列表 / 代码块）正确渲染。
  4. 发送后 → 实时收到增量回复，无需刷新或进历史。
  5. 调用工具 → 工具名 / 参数 / 结果出现并可折叠。
- 网页端 `ChatPage` 回归：标题、实时流、markdown 不受影响。

## 8. 风险与回滚

- server 标题生成修正是共享逻辑，需确保不影响网页端与其他渠道（网页端 channel 正常，回归风险低；改动需聚焦移动端 channel 兜底分支）。
- `wsStore.connect()` 在移动端新增：确认与网页端连接不冲突（同一 pinia store 单例，connect 重建 ApiClient，需避免重复 connect 导致重连风暴——实现时检查 `wsStore.state`）。
- 各修复点相互独立，可按问题单独回退。

## 9. 非目标（YAGNI）

- 不重构网页端聊天组件为共享组件。
- 不引入真 WebSocket 替换 SSE。
- 不新增 agent 状态数据逻辑（store 已完整）。
- 不做消息编辑 / 重发等新功能。
