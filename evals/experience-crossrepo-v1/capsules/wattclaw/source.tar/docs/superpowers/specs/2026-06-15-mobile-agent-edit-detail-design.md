# 移动端数字员工创建/编辑细节优化 — 设计

> 日期：2026-06-15
> 范围：`/m` 移动端数字员工创建/编辑页（`MobileAgentEditPage.vue`）对齐网页端能力
> 状态：待复审

## 一、背景与问题

移动端数字员工创建/编辑页相比网页端（`AgentMarketPage.vue` + `SettingsTab.vue`）存在三处缺失：

1. **模板不全且无分类**：`MobileAgentEditPage.vue` 用 `templates.slice(0, 12)` 硬截断前 12 个模板，30 个模板缺大半，且无任何分类筛选。
2. **设定只有一个字段**：仅 `soulMd` 单 textarea，标题「角色配置」；网页端是 `SOUL/AGENTS/IDENTITY/USER` 四文件完整映射（行为准则/工作流程/身份档案/用户档案 + 各自描述）。
3. **无 markdown 预览、无编辑模式**：设定内容以纯文本 textarea 展示，不可折叠，手机端编辑大段文本空间不足。

## 二、目标

- 模板全量可见，提供「精选 / 全部」筛选。
- 设定补齐为四文件分组，标题改「设定」，与网页端一致。
- 设定支持 markdown 预览 + 全屏编辑 + 可折叠，适配竖屏。
- 复用现有 API / Store / 工具，不发明新业务流。

## 三、关键架构决策（已与用户确认）

### 决策 1：设定的创建/编辑定位

**创建态**：选模板后，模板自带的 4 文件内容预填到「设定」区做**只读 markdown 预览**，不可编辑、不参与 `createAgent` 提交。

**编辑态**：4 文件从 **Gateway 文件系统**读取（`GET /api/agent-team/:id/files`），支持 markdown 预览 + 全屏编辑 + 保存（`setAgentFile` → `agents.files.set`）。

> 选此方案的理由：后端 `POST /api/agent-team/create` 当前不持久化设定字段（且强制要 `gatewayAgentId`），创建态持久化设定需改后端、超出本次需求范围。设定真相源是 Gateway 文件，编辑态直接读写 Gateway 与网页端 `SettingsTab` 同源。

### 决策 2：模板分类只做「精选 + 全部」

不照搬网页端 13 个 tab（精选/全部 + 11 分类）。手机端横向滑动 13 项过于拥挤，移动场景用户多为快速挑选。

- **精选**（默认）：`FEATURED_TEMPLATE_IDS`（11 个高频模板）。
- **全部**：`getAllTemplates()`（30 个）。

> 损失：「全部」里 30 个不分门类。若后续需要，可加搜索（`AgentMarketPage` 已支持 `searchQuery`）或分类下拉 sheet，本次不做（YAGNI）。

### 决策 3：编辑交互 = 可折叠卡片列表 + 全屏编辑覆盖层

- 设定 4 文件渲染为**可折叠卡片列表**（默认折叠，省空间）。
- 展开看 markdown 预览（复用 `renderMarkdown`）。
- 编辑态卡片有「编辑」按钮 → 调起**近全屏覆盖层**：顶栏（✕ 标题 ✓）+ textarea 占满 + 底部安全区，Aurora 风格。

## 四、数据流

| 维度 | 创建态 | 编辑态 |
|---|---|---|
| 模板区 | 精选/全部 tab + 模板网格（全量，复用 `categoryAccent` 分类色） | 不显示 |
| 设定来源 | 选模板预填本地 ref（`soulMd/agentsMd/identityMd/userMd`） | `GET /api/agent-team/:id/files`（Gateway 文件） |
| 设定可编辑 | ❌ 只读预览，无编辑按钮 | ✅ markdown 预览 + 全屏编辑 + 保存 |
| 设定提交 | 不提交（`createAgent` 仅传 name/description/model/templateId/avatar/category） | 保存即写 Gateway 文件 |
| 设定 section 标题 | 「设定」 | 「设定」 |

## 五、组件拆分（many-small-files，现有 566 行需瘦身）

| 文件 | 动作 | 职责 |
|---|---|---|
| `src/mobile/views/agents/MobileAgentEditPage.vue` | 改（瘦身编排） | hero + 编排「模板选择 / 基本信息 / 设定」三 section + 提交栏；按 isEdit 分支设定来源 |
| `src/mobile/views/agents/MobileTemplatePicker.vue` | **新建** | 创建态：精选/全部 tab + 模板网格（复刻 AgentMarketPage 过滤，移动端 `.tpl` 样式 + `categoryAccent`） |
| `src/mobile/views/agents/MobileSettingSection.vue` | **新建** | 设定 section：4 个可折叠卡片（v-loop `AGENT_SETTING_FILES`），创建态只读 / 编辑态可编辑，emit 调起全屏编辑 |
| `src/mobile/components/MobileMarkdownEditorOverlay.vue` | **新建** | 近全屏覆盖层：顶栏(✕ 标题 ✓) + textarea 占满 + 安全区；props: title/value；emit save/cancel |
| `src/config/agent-settings.ts` | **新建** | 设定文件映射常量（单一权威，网页+移动共用） |
| `src/views/agent-management/tabs/SettingsTab.vue` | 改 | 改用共享常量，去掉内联 `FILE_LABELS` |
| `src/i18n/messages/zh-CN.ts` | 改 | 新增 key：`setting` / `preview` / `edit` / `save` / `cancel` / 折叠提示等 |

## 六、共享常量（单一权威实现）

新建 `src/config/agent-settings.ts`：

```ts
export type AgentSettingFileName = 'SOUL.md' | 'AGENTS.md' | 'IDENTITY.md' | 'USER.md'
export type AgentSettingField = 'soulMd' | 'agentsMd' | 'identityMd' | 'userMd'

export interface AgentSettingFile {
  file: AgentSettingFileName
  field: AgentSettingField
  label: string
  desc: string
}

export const AGENT_SETTING_FILES: AgentSettingFile[] = [
  { file: 'SOUL.md',     field: 'soulMd',     label: '行为准则', desc: '定义核心行为规范、安全边界和不可逾越的底线' },
  { file: 'AGENTS.md',   field: 'agentsMd',   label: '工作流程', desc: '定义工作流程、协作方式和工具使用规则' },
  { file: 'IDENTITY.md', field: 'identityMd', label: '身份档案', desc: '定义身份信息、专业领域、技能特长和沟通风格' },
  { file: 'USER.md',     field: 'userMd',     label: '用户档案', desc: '记录用户的信息偏好、使用习惯和个性化需求' },
]
```

- `file`：Gateway 文件名（编辑态 `setAgentFile` / `/files` 用）。
- `field`：模板数据字段名（创建态从 `getAllTemplates()` 取预填内容）。
- `label` / `desc`：业务领域固定文案，网页端 `SettingsTab` 本就硬编码中文，共享常量保持一致，不强加 i18n。

## 七、三块需求落点

### 需求 1：模板补齐 + 精选/全部
- `MobileTemplatePicker` 用 `getAllTemplates()` + `FEATURED_TEMPLATE_IDS`，默认 tab=精选。
- 彻底删除 `slice(0, 12)`。
- 复用现有 `.tpl-grid` / `.tpl` / `categoryAccent` / `templateAvatar` / `isImageAvatar` 样式与工具。

### 需求 2：设定补齐 + 改名
- `MobileSettingSection` 用 `AGENT_SETTING_FILES` 渲染 4 卡片（图标 + label + desc + 折叠箭头）。
- section 标题 i18n key 由 `pages.mobile.agents.roleConfig`（角色配置）改用新 key `pages.mobile.agents.setting`（设定），与网页端 tab `agentManagement.tabs.settings`（设定）对齐。

### 需求 3：markdown 预览 + 全屏编辑 + 折叠
- 折叠卡片列表（默认折叠）→ 展开看 markdown 预览（`renderMarkdown` from `@/utils/render-markdown`，移动端 `MessageBubble` 已用）。
- 编辑态卡片「编辑」按钮 → `MobileMarkdownEditorOverlay` 全屏 textarea → 保存调 `wsStore.rpc.setAgentFile(id, file, content)` → 刷新该卡片内容。

## 八、复用清单（不新增传输路径）

| 能力 | 复用来源 |
|---|---|
| 模板分类/精选 | `getAllTemplates` / `FEATURED_TEMPLATE_IDS` / `CATEGORY_CONFIGS`（`agent-templates.ts`） |
| 分类色 | `categoryAccent`（`src/mobile/utils/category-accent.ts`） |
| 头像解析 | `resolveAgentAvatar` / `isImageAvatar`（`@/utils/agent-avatar`） |
| markdown 渲染 | `renderMarkdown`（`@/utils/render-markdown`，markdown-it） |
| 设定读取 | `GET /api/agent-team/:id/files`（`apiPath` + fetch，与 `SettingsTab` 同） |
| 设定保存 | `wsStore.rpc.setAgentFile`（rpc-client:2676 → `agents.files.set`） |
| 设定映射 | `AGENT_SETTING_FILES`（本次新建共享常量） |

## 九、i18n 新增（zh-CN.ts）

```
pages.mobile.agents.setting: '设定'        # 取代现有 roleConfig（角色配置）
pages.mobile.agents.preview: '预览'
pages.mobile.agents.edit: '编辑'
pages.mobile.agents.save: '保存'
pages.mobile.agents.cancel: '取消'
pages.mobile.agents.collapseHint: '点击展开/收起'
```

> 精选/全部标签**复用** `common.featured` / `common.all`（网页端 `CATEGORY_CONFIGS` 已用，见 `agent-templates.ts:907-908`），不新建 key。
> 项目仅 zh-CN 单 locale（`en-US.ts` 不存在），只改 zh-CN。
> 原 `pages.mobile.agents.roleConfig` / `soulLabel` 在实现后移除（确认无其他引用）。

## 十、边界（明确不动）

- ❌ 不动后端 `POST /api/agent-team/create`（gatewayAgentId 约束 + 不持久化设定）——决策 1 已排除创建态持久化，后端无需改。
- ❌ 不动数据库 `agent_team.soul_md` 等字段（设定真相源是 Gateway 文件）。
- ❌ 不动 Gateway agent 创建流程（模板设定如何初始写入 Gateway 属既有逻辑，不在本次范围）。
- ✅ 模板自带设定在创建态仅作预览；员工创建后通过编辑态读写 Gateway 文件生效。

## 十一、验证

- `npm run build`（vue-tsc + Vite）通过，仅有 Vite chunk-size warning。
- 手动验证：
  - 创建态：精选/全部切换正常，选模板后设定区只读预览 4 文件 markdown。
  - 编辑态：从 Gateway 读 4 文件，折叠/展开、全屏编辑、保存后内容持久化。

## 十二、风险

1. **编辑态 Gateway 文件读取失败**：`/api/agent-team/:id/files` 异常时降级为空内容 + 不阻塞页面，遵循「不静默吞错」原则（console.error + UI 提示）。
2. **移动端编辑页 `onMounted` 当前只 `fetchAgent`**：需扩展为 `fetchAgent` + 读 files（编辑态），注意加载态与错误兜底。
3. **`SettingsTab` 改用共享常量**属顺带重构，需保证网页端行为不变（仅数据源从内联改为 import，渲染逻辑不动）。
