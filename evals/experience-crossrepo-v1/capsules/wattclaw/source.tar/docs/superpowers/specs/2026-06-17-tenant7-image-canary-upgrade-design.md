# 单租户原位灰度镜像升级验证(tenant-7)

> 设计日期:2026-06-17
> 状态:待实现
> 关联:`docs/multi-tenant/`(多租户机制 / 部署现状)、分支 `feat/multi-tenant-merge`(HEAD `0e94900`)
> 代码行号基于 `server/core/multi-tenant-gateway.js`

## 1. 背景与目标

线上 9 个租户容器(`openclaw-tenant-1..9`)运行 `ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64`。需升级到 `alpine/openclaw:2026.6.6-browser`。

采用 **单租户原位灰度**:挑 tenant-7 先换镜像验证,其余 8 个不动,验证通过再批量;失败可回滚。

环境为 **测试环境**(无真实用户),断服 / 回滚无生产顾虑。

验证用 **真实账户任鸣(`19892815440`,绑定 tenant-7)**,在真实多租户链路下验证 **web(WattClaw)+ 飞书** 两个渠道。

**目标**:确认 2026.6.6 新镜像能读 beta.2 生成的数据(配置 / agents / 飞书),并在 web + 飞书双渠道跑通,为批量升级提供依据。

## 2. tenant-7 现状(只读勘察事实)

| 项 | 值 |
|---|---|
| 绑定账户 | 任鸣(username=`19892815440`,user_id=`1c0950da-...`) |
| 容器名 | `openclaw-tenant-7` |
| 数据目录(data_source) | `/home/wattman/wattclaw-test/tenants/tenant-7` |
| CPU 亲和 | 核 6(`cpuset_cpus=6`) |
| 该租户用户数 | 20(满载;测试数据,非真实用户) |
| 网络寻址 | `http://openclaw-tenant-7:18789`(容器名,不映射宿主端口) |
| 当前镜像 | `ghcr.io/openclaw/openclaw:2026.6.1-beta.2-browser-amd64` |
| 目标镜像 | `alpine/openclaw:2026.6.6-browser` |

## 3. 核心策略

### 3.1 为什么是"原位替换"而非"蓝绿并行"
- 蓝绿(独立新控制面 + 新前缀容器)工作量过大,且测试环境无需零停机
- 原位替换:新容器用 **同名** `openclaw-tenant-7` 顶替,网络寻址 / 控制面 tenant 记录 / 用户绑定 / 飞书 account 配置 **全不变** → 控制面与用户无感,飞书 bot 无缝
- 单租户灰度:只 tenant-7 换,其余 8 个不动,风险隔离

### 3.2 为什么必须"数据隔离"
bind mount 是读写的。若新容器直接挂原 `tenant-7/` 目录:
- 新镜像(2026.6.6)启动可能 **改写** openclaw.json(格式迁移)或写坏 → 污染原数据
- 一旦写坏,回滚时 beta.2 读不了新格式 → **回滚失败**

→ 必须:新容器挂载 **数据副本**,原 tenant-7 纹丝不动。

### 3.3 为什么不能靠 Manager 自动重建(方案 B 被否)
Manager 重建必然挂原目录(`buildBinds` 用 `resolveTenantDataSource(id)` 计算的 dataSource = tenant-7),**无数据隔离**。且 `ensureTenantRecord`(:440 / :451 / :455)用计算值覆盖表 `data_source`,手动改表指向副本无效。

### 3.4 方案 C:手动起容器挂副本 + 利用 managed label 让 Manager 不重建
代码逃生口:`shouldRecreateTenantContainer`(:746)—— 容器无 `openclaw.gateway.managed=true` label 则直接 `return false`(不重建)。而 `ensureTenantContainer` 已存在分支(:682)仍调 `ensureLarkPluginForTenantContainer`(**不检查 label**)→ lark patch 照样自动注入。

→ 手动起 `openclaw-tenant-7`(新镜像,挂 `tenant-7-v2` 副本,**不带 managed label**):Manager 检测"非托管"不重建,但自动注入 lark patch。**数据隔离 + 原位 + 自动 patch** 三者兼得。

## 4. 关键代码依据

| 机制 | 位置 | 说明 |
|---|---|---|
| bootstrap 遍历全量 tenant | `_bootstrap:156-167` | 重启后遍历所有 tenant 记录,触发 ensureTenantContainer |
| image 进程读死 | `resolveConfig:1042` `image: envConfig.OPENCLAW_IMAGE` | Manager 启动时读,进程内不变;改 .env 必须重启 |
| 无后台 reconcile | 全文无 `setInterval` | "自动检测"靠 bootstrap(重启)或请求懒触发 |
| **无 managed label 不重建** | `shouldRecreateTenantContainer:746` | 方案 C 核心:手动容器不带 label → Manager 不漂移重建 |
| lark patch 自动注入(不查 label) | `ensureTenantContainer:682` + `ensureLarkPluginForTenantContainer:754` | 即使非托管容器也注入 |
| data_source 被计算覆盖 | `ensureTenantRecord:440 / :451 / :455` | 改表 data_source 无效,只能靠手动起容器挂副本 |
| 挂载构造 | `buildBinds:991` + `extraPersistentMounts:29` | 10 个挂载的来源 |

## 5. 数据隔离边界(tenant-7 挂载表)

### A. tenant-7 专属(源自 `/home/wattman/wattclaw-test/tenants/tenant-7/`,拷贝时换源)

| 容器内 | 宿主源 | 作用 |
|---|---|---|
| `/home/node/.openclaw` | `tenant-7/` | Gateway home(memory / workspace / plugins / state / 会话) |
| `/home/wattman/.openclaw` | `tenant-7/` | 同上,另一访问路径 |
| `/home/node/openclaw.json` | `tenant-7/openclaw.json` | 主配置(模型 token / 飞书 channels.accounts / agents 声明 / bindings) |
| `/home/node/.config` | `tenant-7/container/home-node/.config` | home 配置持久化 |
| `/home/node/.cache` | `tenant-7/container/home-node/.cache` | 缓存 |
| `/home/node/.local/share` | `tenant-7/container/home-node/.local/share` | 本地数据 |
| `/home/node/.local/state` | `tenant-7/container/home-node/.local/state` | 本地状态 |
| `/tmp/openclaw` | `tenant-7/container/tmp` | 临时 |

### B. 全局共享(所有 tenant 共用,**不拷贝**)

| 容器内 | 宿主源 | 作用 |
|---|---|---|
| `/home/node/.openclaw/agents` | `/home/wattman/.openclaw/agents` | 共享 agents(子路径挂载覆盖 home 内 agents) |
| `/home/wattman/.wattclaw` | `/home/wattman/.wattclaw` | 共享 WattClaw 工作区 |

**拷贝边界**:`cp -a tenant-7/ tenant-7-v2/` 整个目录,A 类 8 挂载换源到 `tenant-7-v2`,B 类 2 挂载不动。openclaw.json 随目录拷贝(`tenant-7-v2/openclaw.json`)。

## 6. 方案 C 执行流程

| 步骤 | 操作 | 注意 |
|---|---|---|
| 0 前置 | `docker pull alpine/openclaw:2026.6.6-browser`;`docker inspect openclaw-tenant-7` 导出原 binds/env/cmd/资源 | 只读 |
| 1 拷贝 | `cp -a /home/wattman/wattclaw-test/tenants/tenant-7 /home/wattman/wattclaw-test/tenants/tenant-7-v2` | 完整副本 |
| 2 停旧 | `docker rm -f openclaw-tenant-7` | 原目录数据不丢 |
| 3 起新 | `docker run` 同名 `openclaw-tenant-7`,新镜像,A 类挂载源换 `tenant-7-v2` + B 类共享挂载不变 + env/cpuset=6/8G/4CPU/`multi-openclaw-net` + **不带 managed label** | binds/env 除 dataSource 外逐字复制原容器 |
| 4 lark patch | Manager(重启 `openclaw-web` 或请求触发)inspect 到新容器 → 无 managed label → 不重建 → `:682` 自动注入 lark patch | 见 §7.2 |
| 5 验 web | 任鸣在 WattClaw 登录 → 发消息收流式回复 → 历史回读 → agent/skill | 路由到 `openclaw-tenant-7:18789` → 新容器(挂 v2) |
| 6 验飞书 | 任鸣在原飞书 bot 发消息 | account 配置在 v2 副本 openclaw.json,容器名不变 → 无缝 |
| 7 回滚(若败) | `docker rm -f` 新容器 → 手动起 beta.2 + 挂**原 tenant-7** + 加回 managed label | 原数据完好,秒回滚 |

> 步骤 3 的完整 `docker run` 命令在 writing-plans 阶段给出可直接执行版本(从步骤 0 导出的 binds/env 自动生成)。

## 7. 版本兼容验证点(2 个)

### 7.1 openclaw.json 配置 schema(唯一可能要改配置文件)
新镜像启动必读 openclaw.json(beta.2 生成)。2026.6.6 若 schema 变化,可能启动失败 / 行为异常。
- 具体改什么:新镜像起来看报错 / 查 OpenClaw changelog
- 改的是 `tenant-7-v2/openclaw.json` 副本,原文件不动

### 7.2 lark patch dist 定位(buildLarkPatchCommand 自带路径回退,实测命中)

`buildLarkPatchCommand`(`:1141`)对 dist monitor **非单一硬编码路径**:dist_target(larkDistTarget 默认 `/home/node/.npm-global/.../monitor-Bog7UNtj.js`,`:1067`)若不存在,走 else 回退 —— `find /home/node/.npm-global/lib/node_modules /usr/local/lib/node_modules /app -path "*/dist/monitor-*.js"` + grep 飞书特征(`monitorFeishuProvider|extensions/feishu/src/monitor.ts|feishu: starting`)定位真正的飞书 monitor,再 `cp monitor-Bog7UNtj.js` 覆盖。最终兜底 `:1170` warning「plugin patches still applied」(插件层 patch 照常)。

**实测(2026-06-17 ssh 勘察新镜像 alpine/openclaw:2026.6.6-browser)**:
- 旧 dist_target 路径不存在(预期;新镜像 workdir=`/app`,dist 在 `/app/node_modules/openclaw/dist/`)
- 回退 find+grep **成功命中** `/app/node_modules/openclaw/dist/monitor-B5WoSBtp.js`(4 处 feishu 特征)→ patch 会执行覆盖,**不需要改 `OPENCLAW_DIST_MONITOR_TARGET`**

**真正风险(非原设"找不到",而是"覆盖")**:
1. **旧版覆盖新版**:用 beta.2 的 `monitor-Bog7UNtj.js` 覆盖 2026.6.6 的 `monitor-B5WoSBtp.js`;跨版本 monitor 内部 API 若变,覆盖后可能运行异常
2. **双 monitor 文件**:含 feishu 特征的有**两个**(`/app/node_modules/.../monitor-B5WoSBtp.js` + `/app/dist/monitor-BFQGKXpb.js`),patch 的 `find ... break` 只覆盖第一个;若运行时加载第二个,patch 不生效
3. patch 改的是 WattClaw 定制(`core/owner-policy.js` 多租户归属 / `tools/oauth.js` / `tools/onboarding-auth.js` / `channel/monitor.js`),**非 OpenClaw 原生飞书收发** → 飞书基础收发大概率通,WattClaw 飞书定制功能需运行时验证

**结论**:dist 路径迁移**不阻塞升级**(回退已命中),风险从「🔴 阻塞」降级为「🟡 需运行时验证飞书定制功能」。若实测异常,适配点在 `openclaw-lark-patches/monitor-Bog7UNtj.js`(更新到 2026.6.6 兼容版)或 `buildLarkPatchCommand` 的 find 选择逻辑,中等工作量,不阻塞 web 渠道验证。

### 7.3 其余数据(agents / skills / memory / 会话)
不用手动改。数据隔离兜底:最坏副本读不了,不影响原 tenant-7,不阻塞启动。

## 8. 验证标准(任鸣双渠道亲验)

- **web**:发消息收正常流式回复 + 历史会话可回读 + agent/skill 调用正常
- **飞书**:bot 收发正常(account 配置不变,无缝)
- 两渠道均通过 → 镜像兼容,可批量升级

## 9. 回滚方案

`docker rm -f openclaw-tenant-7`(新)→ 手动起 beta.2 + 挂**原 tenant-7** + 加回 `openclaw.gateway.managed=true` label(恢复 Manager 托管)。原数据 bind mount 未动,秒回滚。

## 10. 风险与注意

- **tenant-7 满 20 用户**:原位替换期间短暂断服(测试环境无虑)
- **不带 managed label**:Manager 视新容器为"非托管",不漂移重建(预期行为);验证 OK 后若要 Manager 正式托管该容器,需迁移 / 调整 dataSource(后续决策,非本次范围)
- **不改全局 OPENCLAW_IMAGE**:方案 C 不改 .env(手动起容器),其余 8 个 tenant 无被波及风险
- **.env 零改动**:方案 C 全程不碰 .env,无 token 泄露 / 提交风险
