# 移动端语音转文字输入（STT）设计

> 日期：2026-06-22
> 范围：移动端聊天页 `/m` 新增「切换语音模式 → 按住说话 → 实时转写 → 三选一（直接发送 / 转文字保留 / 取消）」
> 对齐：网页端既有 STT 功能形态，讯飞 IAT 后端代理零改动复用；交互参照微信语音输入（底部三按钮 + 录音气泡）

## 1. 目标与非范围

**目标**：移动端聊天输入支持语音转文字。用户点切换键进入语音模式，按住「按住说话」录音并实时转写，松开时手指位置决定结果——中间松开=转写后直接发送文字，滑到右侧「转文字」=转写保留到输入框，滑到左侧「取消」=丢弃。

**非范围**：
- 网页端 `ChatInput.vue` 语音逻辑重构（技术债，第 12 节）
- 语音消息（录音频文件、音频气泡播放）——明确排除，本功能仅 STT 文字输入
- 后端讯飞代理任何业务逻辑改动（已核实复用即可，见第 2.1 节）

## 2. 决策摘要

| 维度 | 决策 |
|---|---|
| 功能形态 | STT 语音转文字（讯飞 IAT，后端业务零改动复用 `/api/speech/xfyun`）|
| 进入方式 | 点「切换语音」键 toggle 语音模式：输入区在「文本输入框」与「按住说话」条间切换 |
| 录音触发 | 按住「按住说话」条开始（touchstart），松开结束（touchend）|
| 录音中 UI | 底部三按钮区 `[取消 \| 松开发送 \| 滑到这里转文字]` + 上方绿色波形气泡（聊天内容可见，非全屏遮挡，参照微信）|
| 松开后行为 | 三向手势决定：中=转写直接发送 / 右=转写保留输入框 / 左=取消丢弃 |
| 音频采集 | AudioWorklet（现代 API，主线程外处理）+ 前端攒批发送 |
| 代码组织 | 移动端独立 composable，网页端不动 |
| 能力探测 | 后端 `/api/config` 增加 `features.voiceStt` 派生字段，启动即知 |

> **STT 适配说明**：微信「松开发送」原义是发送语音消息；本功能是 STT 无语音文件，故「松开发送」=转写文字后直接发送文字消息（松开后有 ≤800ms 转写收尾延迟，期间显示「转写中」）。「转文字」=转写后保留到输入框不直接发。两者都转文字，区别仅在是否触发发送。

### 2.1 关键核实结论（基于后端实证，避免实现者重复踩坑）

核实 `server/handlers/xfyun-speech.js` 与 `src/views/workspace/ChatInput.vue` 后确认：

1. **pgs 流式合并已在后端完成**：讯飞 IAT 的 `pgs='apd'/'rpl'` 增量替换语义由后端 `resultTextTemp`/`resultText` 处理（xfyun-speech.js:115-126），下发给前端的是**已合并的完整文本** `{type:'result', text:<完整文本>, isFinal}`。**前端无需处理 pgs/rg**，`draftText` 直接覆盖为最新 `text`（与网页端 `appendVoiceText` 实际语义一致——它名为 append 实为 `voiceResultText.value = text` 覆盖）。
2. **讯飞协议帧序列在后端**：首帧（status:0+business 参数）、中帧（status:1+PCM）、终帧（status:2）全由后端 `sendInitialFrame/sendAudioFrame/sendFinalFrame` 自动处理。**前端 WS 契约极简**：发 PCM 二进制帧（后端转 status:1）+ 录音结束发字符串 `'end'`（后端转 status:2 终帧）。
3. **后端已鉴权**：`/api/speech/xfyun` 在 HTTP upgrade 时 `checkAuth(req)`（xfyun-speech.js:58，import 自 `core/auth.js` 同源鉴权），失败返 401。多用户隔离满足（token 有效=已认证用户），无需前端额外处理。
4. **能力判定三处一致**：`getXfyunConfig`（三字段空串兜底）、connection handler（三字段非空校验 closeWithError）、`features.voiceStt`（三字段非空）逻辑同源，不会出现 features=true 但路由未挂的不一致。
5. **音频格式契约**：后端 `format='audio/L16;rate=16000'` + `encoding='raw'`，前端必须发 **16kHz Int16 PCM raw** 二进制。
6. **isFinal 完成信号**：后端在讯飞返回 `status=2` 时下发 `{isFinal:true}` 并主动 close(1000)；前端据此知转写收尾完成。

## 3. 架构与文件清单

### 新增（3 个文件）

| 文件 | 职责 |
|---|---|
| `src/mobile/composables/useMobileVoiceInput.ts` | 纯逻辑：语音模式 toggle + 状态机 + AudioWorklet 采集 + **攒批** + WS（发 PCM+'end'，覆盖式 draftText）+ window 级三向手势 + iOS resume + 幂等清理 |
| `src/mobile/views/chat/VoiceRecordingPanel.vue` | 纯展示：录音气泡（绿色波形+时长+转写预览）+ 底部三按钮（取消/松开发送/转文字），按 dragZone 高亮；波形用 rAF 直绘绕过 reactivity |
| `public/voice-pcm-processor.js` | AudioWorklet processor：转发 Float32 PCM 帧回主线程（攒批在主线程做）|

### 修改

| 文件 | 改动 |
|---|---|
| `src/mobile/views/chat/ChatInputBar.vue` | 切换语音键 + 输入区多态（textarea / 按住说话条 / 挂 Panel，含 requesting/connecting 反馈）+ window 级 touch + finish 三态分发 + 空转写保护 |
| `src/i18n/messages/zh-CN.ts` | 加 `pages.mobile.chat.voice*` 一组文案（key 清单见 5.5）|
| `server/handlers/system.js` | `GET /api/config` 增加 `features.voiceStt` 派生字段（复用 `getXfyunConfig`）|
| `src/stores/config.ts` | 透出 `features.voiceStt` |

### 复用（零改动，已核实）

- `server/handlers/xfyun-speech.js`（讯飞 IAT v2 WebSocket 反向代理，含 pgs 合并/帧序列/鉴权）
- `server/handlers/xfyun-speech.js` 的 `getXfyunConfig`（system.js 调用判定能力）

> **i18n**：当前仅 `zh-CN`（记忆 [[project-i18n-single-locale]]），文案只加 zh-CN；若实现时发现 `en-US.ts` 已补齐则双份。

## 4. 状态机

```
两个独立维度：
  voiceMode: boolean   —— 语音输入模式开关（toggle，独立于录音状态）
  status:    录音状态机

status：idle → requesting → connecting → listening → stopping → idle
异常：permission-denied / unsupported / error / service-unavailable

── 进入录音（start 入口守卫：status!==idle 直接 return，H6） ──
按住「按住说话」条 touchstart → start()
  idle → requesting   : 【C4 顺序】先 new AudioContext() + 同步 await resume()（iOS 手势内）
                        再 await getUserMedia({audio:true})
                        （cancelled flag 置位检查：H2，若中途 cancel/cancelled，getUM resolve
                         时立即 stopTracks 丢弃，不进 connecting）
  requesting → connecting : audioWorklet.addModule('/voice-pcm-processor.js')
                        + AudioWorkletNode（connect destination 保 iOS process 触发，process 不写 outputs 静音）
                        + AnalyserNode 接入 mediaStreamSource
                        + new WebSocket('/api/speech/xfyun?token=<auth_token>')
  connecting → listening  : WS onopen
  【connecting 失败回退 H3】addModule 抛错 → status='error' + cleanup；
                        WS onerror（onopen 前）→ status='service-unavailable' + cleanup

── listening 期间（并行四路） ──
  ① worklet.port.onmessage(Float32 PCM 帧, 128 样本/帧)
     → 攒批缓冲（C3，攒到 ~3200 样本 ≈ 44.1k 下 72ms）
     → 攒满后 downsampleTo16k(batch, audioContext.sampleRate) → socket.send(int16Buffer) 二进制
       （后端转 status:1 帧透传讯飞）
  ② socket.onmessage({type:'result', text, isFinal})  【draftText 覆盖式，C2 推翻后的正确做法】
     → draftText.value = text   （覆盖，非追加；后端已 pgs 合并）
     → isFinal===true 标记转写完成
     socket.onmessage({type:'error', message}) → status='service-unavailable' + errorMessage + cancel
  ③ AnalyserNode（rAF 直绘，M3，不走 ref reactivity）
     → 直接写 Panel canvas/柱高 + duration 计时
  ④ window 级 touchmove（C1）追踪手指 x 分段 → dragZone ∈ {send(中), text(右), cancel(左)}
     → Panel 按 dragZone 高亮对应按钮

── 松开结束（finish，三态由 dragZone 决定） ──
window touchend → finish()  【H4：status!==listening 时 finish→cancel】
  listening → stopping : socket.send('end')  （后端转 status:2 终帧）
              → 等最后 result(isFinal) 或 onclose，≤800ms 超时用已累积 draftText 兜底
  → 得到完整 text → 返回 {mode, text}：
     dragZone=send/null → {mode:'send',  text} ：ChatInputBar 追加 inputText 后 emit send
     dragZone=text      → {mode:'keep',  text} ：ChatInputBar 追加 inputText，不发送
     dragZone=cancel    → {mode:'cancel',text:''}：丢弃
  stopping → idle + cleanup()
  【空转写保护 H5】若 text.trim()==='' 且 mode==='send' → 降级为无操作（不发空消息），轻提示

── 异常退出 ──
touchcancel / 组件 onUnmounted → cancel() : 丢弃 → cleanup() → idle
录音超 60s（M4）→ cancel() + 提示「已达时长上限」（保守不误发，非 send）
stopping 超时（>800ms）→ 用已累积 draftText 兜底 finish
```

## 5. 组件设计

### 5.1 useMobileVoiceInput.ts

纯逻辑，不碰 UI。对外契约：

```ts
type VoiceStatus =
  | 'idle' | 'requesting' | 'connecting'
  | 'listening' | 'stopping'
  | 'permission-denied' | 'unsupported' | 'error' | 'service-unavailable'

type DragZone = 'send' | 'text' | 'cancel'   // 三向手势区
type FinishMode = 'send' | 'keep' | 'cancel'

interface FinishResult { mode: FinishMode; text: string }  // cancel 时 text=''

interface UseMobileVoiceInput {
  status: Ref<VoiceStatus>
  voiceMode: Ref<boolean>         // 语音输入模式开关
  volume: Ref<number>             // 0-1，仅供 Panel 初始化参考；实时波形走 rAF 直绘
  duration: Ref<number>           // 秒
  draftText: Ref<string>          // 实时转写（覆盖式，来自后端完整文本）
  dragZone: Ref<DragZone | null>  // listening 期间手指悬停区，null=默认中(send)
  errorMessage: Ref<string | null>

  toggleVoiceMode(): void                       // 切换语音/文本输入模式
  start(): Promise<void>                        // 按住「按住说话」开始（入口 status!==idle 守卫）
  setDragZone(zone: DragZone | null): void      // window touchmove 时由 ChatInputBar 调用
  finish(): Promise<FinishResult | null>        // window touchend，按 dragZone 决定 mode
  cancel(): void                                // 异常/卸载/超时丢弃
}
```

**纯函数（可独立单测，不依赖 DOM）**：
- `downsampleTo16k(input: Float32Array, inputSampleRate: number): Int16Array` —— 线性插值下采样到 16kHz + Float32→Int16 PCM（输入是攒批后的整段，非单帧，M5）
- `resolveDragZone(deltaX: number, width: number): DragZone` —— 由 touchmove x 偏移与触发区宽度算三段（左/中/右）

> **不再有 `appendVoiceText`/`mergeIatResult`**：pgs 合并在后端（核实结论 1），前端 `socket.onmessage` 收到 result 直接 `draftText.value = payload.text` 覆盖。

**依赖**：`configStore.features.voiceStt`（能力判断）、`authStore` 的 token（WS 鉴权 query，后端 checkAuth 校验）。

**关键内部状态**：
- `cancelled: boolean` —— getUM 取消标志（H2）
- `sampleAccumulator: Float32Array` —— PCM 攒批缓冲（C3）
- `finalReceived: boolean` —— isFinal 收到标志（finish 收尾判定）

**生命周期**：`onUnmounted` → 若 `status !== 'idle'` 调 `cancel()` + `cleanup()`；`voiceMode` 不持久化。

**finish() 的 mode 解析**：读 `dragZone`，null 或 'send' → 'send'，'text' → 'keep'，'cancel' → 'cancel'。send/keep 的 text 都是完整 draftText；cancel 返回 text=''。

### 5.2 VoiceRecordingPanel.vue

纯展示组件，嵌入 ChatInputBar 输入区（非全屏遮罩），status ∈ {requesting, connecting, listening, stopping} 时渲染。

```ts
interface Props {
  visible: boolean
  status: VoiceStatus
  volume: number
  duration: number
  draftText: string
  dragZone: DragZone | null
  errorMessage: string | null
  analyser: AnalyserNode | null   // rAF 直绘波形用，避免 volume 走 reactivity
}
```

- **录音气泡**（浮于输入区上方）：绿色（`#4CD964` 参照微信）圆角
  - `listening`：rAF 读 `analyser.getByteFrequencyData()` 直接绘波形柱 + 时长 `mm:ss` + 转写预览 `draftText`（**M3：绕过 Vue reactivity，canvas/DOM 直绘**）
  - `requesting`：「请求麦克风权限…」
  - `connecting`：「连接中…」
  - `stopping`：「转写中…」
  - `errorMessage` 非空：显错误文案
- **底部三按钮**（横向均分，仅 listening 显示）：`[取消 | 松开发送 | 滑到这里转文字]`
  - 按 `dragZone` 高亮（cancel=左变红，text=右，send/null=中间主色加深）
  - 非 listening（requesting/connecting/stopping）三按钮隐藏或禁用
- **不含任何采集/手势逻辑**，仅消费 props；手势分段由 ChatInputBar 的 window touchmove handler 计算

### 5.3 public/voice-pcm-processor.js

AudioWorklet processor，主线程外运行，仅转发原始 Float32 帧（攒批在主线程做，便于单测下采样）：

```js
class VoicePcmProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const channel = inputs[0]?.[0]
    if (channel && channel.length) this.port.postMessage(channel)
    return true
  }
}
registerProcessor('voice-pcm-processor', VoicePcmProcessor)
```

放 `public/` 静态服务（iOS 友好，blob URL 在 iOS AudioWorklet 不稳定）。

### 5.4 ChatInputBar.vue 改动

输入区按 `voiceMode` + `status` 多态：

| voiceMode | status | 输入区渲染 |
|---|---|---|
| false | * | 现状：ext-btn + textarea + send-btn（不变）|
| true  | idle | 「按住说话」长条 |
| true  | requesting/connecting/listening/stopping | `<VoiceRecordingPanel>`（气泡反馈当前阶段 + listening 时三按钮）|

- **切换语音键**：输入区左侧 toggle 键（语音/键盘图标），`@click="voice.toggleVoiceMode()"`。`features.voiceStt=false` 或浏览器不支持 getUserMedia/AudioWorklet 时隐藏
- **【C1 关键】window 级 touch**：touchstart 绑在「按住说话」条上触发 `start()`；**touchmove/touchend 绑 `window`**（touchstart 时 addEventListener，finish/cancel 后 removeEventListener），避免 idle→listening DOM 切换丢失 touch target：
  ```ts
  // touchstart
  voice.start()
  window.addEventListener('touchmove', onMove, { passive: false })
  window.addEventListener('touchend', onEnd)
  window.addEventListener('touchcancel', onCancel)
  // onMove: resolveDragZone(deltaX, width) → voice.setDragZone(zone)
  // onEnd: const r = await voice.finish(); dispatch(r); removeEventListener(...)
  // onCancel: voice.cancel(); removeEventListener(...)
  ```
- **finish 三态分发 + 空转写保护**：
  ```ts
  const r = await voice.finish()
  if (!r || r.mode === 'cancel') return          // 丢弃
  if (!r.text.trim()) { toast(t('...voiceEmpty')); return }  // H5 空转写不发
  appendInput(r.text)                             // send 与 keep 都先追加 inputText（不覆盖，补尾空格）
  if (r.mode === 'send') handleSend()             // send 再触发发送
  ```
- **【M6】stopping 期间新 touchstart 忽略**：start() 入口 status!==idle 守卫已在 composable，UI 层可不额外处理
- 从 `configStore` 读 `features.voiceStt`：`false` 时切换键隐藏，强制 `voiceMode=false`

### 5.5 i18n key 清单（`pages.mobile.chat.voice*`，仅 zh-CN）

| key | 文案 | 用途 |
|---|---|---|
| `voiceToggle` | 切换语音输入 | toggle 键 aria-label |
| `keyboardToggle` | 切换键盘输入 | toggle 回键盘 aria-label |
| `holdToSpeak` | 按住说话 | 语音模式空态条文字 |
| `releaseToSend` | 松开 发送 | 中间按钮 |
| `slideToText` | 滑到这里 转文字 | 右侧按钮 |
| `cancelRecord` | 取消 | 左侧按钮 |
| `requestingMic` | 请求麦克风权限… | requesting 气泡 |
| `connecting` | 连接中… | connecting 气泡 |
| `transcribing` | 转写中… | stopping 收尾占位 |
| `voiceEmpty` | 没有听到声音，请重试 | H5 空转写提示 |
| `voiceTimeout` | 已达时长上限 | M4 超时提示 |
| `voicePermissionDenied` | 麦克风权限被拒，请在设置中开启 | 权限引导 |
| `voiceNoMic` | 未检测到麦克风 | 无设备 |
| `voiceUnavailable` | 语音转文字暂不可用 | 服务不可用 |

## 6. 能力探测

- 后端 `system.js GET /api/config`：调用既有 `getXfyunConfig(envConfig)`，响应增加 `features: { voiceStt: Boolean(xfyun.appId && xfyun.apiKey && xfyun.apiSecret) }`
- `configStore`（已 `fetchConfig`，移动端 `MobileChatPage.vue:168` 已在用）透出 `features.voiceStt`
- composable 初始化读 `configStore.features.voiceStt` → 切换键可用性
- 运行时兜底：WS `onerror` / 后端 `closeWithError` → `status='service-unavailable'` + `errorMessage`，Panel 提示后回 idle

**为何如此**：复用既有 `/api/config` 通道、复用既有 `getXfyunConfig` 判定（SSOT）、只下发能力布尔（不暴露讯飞密钥）。

> **已核实（M1/M2）**：`/api/speech/xfyun` 路由 upgrade 时 `checkAuth` 同源鉴权（多用户隔离满足）；`getXfyunConfig` 判定条件与后端 connection handler、本字段三处一致，无双悬/漏挂风险。

## 7. iOS 兼容

1. **【C4 关键】AudioContext.resume() 必须在 getUserMedia 之前**：start() 内先 `new AudioContext()` + 同步 `await resume()`，再 `await getUserMedia()`。iOS 要求 resume 在用户手势同步链内，getUM 的 await 之后 resume 常被判脱离手势 → 永久 suspended（这正是网页端的坑，顺序必须排对）
2. 生产 HTTPS 已就绪（getUserMedia 前置条件，[[project-wattclaw-https-migration]]）
3. worklet 模块放 `public/`（blob URL 在 iOS AudioWorklet 不稳定）
4. `audioWorklet.addModule` 是 async，在 `resume()` 后再 addModule + 创建 AudioWorkletNode
5. AudioWorkletNode 必须 `connect(audioContext.destination)` 保证 `process` 持续触发（iOS Safari 否则可能优化掉未连终端的节点）；processor 的 `process` 不写入 `outputs`（静音），避免麦克风回放/回声

## 8. 资源清理

统一 `cleanup()`，幂等（状态守卫防重复），依次：
- `cancelled = true`（先置位，H2 防 getUM 延迟 resolve 泄漏）
- `mediaStream?.getTracks().forEach(t => t.stop())`
- `audioContext?.close()`（已 close 容错）
- `workletNode?.disconnect()` / `analyser?.disconnect()` / `source?.disconnect()`
- `socket?.close()`
- `clearTimeout` 所有 timer（stop 超时、60s 超时、关闭延迟）
- `removeEventListener` window touchmove/touchend/touchcancel（C1）
- 取消 rAF（M3 波形动画）
- 清空 `sampleAccumulator`（C3 攒批缓冲）
- 置空引用，`status → idle`，`dragZone → null`

修网页端遗留的 timer 泄漏模式（`voiceSocketCloseTimer` 未 `clearTimeout`）——本设计从零实现，不复刻此问题。

## 9. 错误处理

| 场景 | 处理 |
|---|---|
| `NotAllowedError` | `permission-denied` + 引导设置开启麦克风 |
| `NotFoundError` | `unsupported` + "未检测到麦克风" |
| 浏览器不支持 getUserMedia / AudioWorklet | 切换键隐藏 |
| addModule 抛错（worklet 404 等，H3） | `error` + cleanup |
| WS onerror/onclose 非 1000（H3） | `service-unavailable` + "语音转文字暂不可用" |
| 后端下发 `{type:'error'}`（config 缺失/讯飞失败） | `service-unavailable` + errorMessage + cancel |
| 录音超 60s（M4） | `cancel()` + 提示「已达时长上限」（保守不误发）|
| stopping 超时（>800ms 未收尾） | 用已累积 draftText 兜底 finish |
| 空转写（H5，draftText.trim()==='' 且 send） | 降级无操作 + 轻提示 |
| 组件卸载时录音中 | `onUnmounted` → `cancel()` + `cleanup()` |

## 10. 测试策略

项目无测试框架（`CLAUDE.md` 确认）。策略：
- composable 纯函数（`downsampleTo16k`、`resolveDragZone`）设计为可独立单测，待框架引入补
- 当前验收：`npm run build` + `vue-tsc --noEmit` 通过 + 手动手机验证（iOS Safari / 飞书内置浏览器 / 安卓 Chrome）

## 11. 核实与决策记录

实现前已核实后端 `server/handlers/xfyun-speech.js`（核实结论见 2.1）：
- pgs 流式合并、讯飞协议帧序列、鉴权、能力判定均在后端，前端契约简化为「发 PCM 二进制 + 'end'，收完整文本覆盖 draftText」
- 网页端 `appendVoiceText` 实为覆盖（命名误导），语义正确，移动端照搬覆盖语义

## 12. 技术债

网页端 `src/views/workspace/ChatInput.vue` 语音逻辑（1289 行巨型文件内联、废弃 `createScriptProcessor`、iOS `resume()` 缺失、`voiceSocketCloseTimer` 泄漏）未来统一到共享 composable。本次不动；本设计的 `useMobileVoiceInput` 为未来统一预留接口形态（命名空间隔离，便于后续抽取为跨端共享层）。

> auth_token 进 WS URL query 是既有代理鉴权约束（后端 checkAuth 需要），属既有设计非本次引入。

## 13. 验收清单

- [ ] 输入区左侧「切换语音」键：点一次→输入框变「按住说话」条；再点→回文本输入框
- [ ] `features.voiceStt=false` 或浏览器不支持 → 切换键隐藏
- [ ] 按住「按住说话」→ requesting/connecting 气泡有反馈 → listening 绿色波形气泡 + 底部三按钮，聊天内容可见
- [ ] 录音中手指左滑→「取消」高亮；右滑→「转文字」高亮；回中→「松开发送」高亮（window 级 touch，DOM 切换不丢手势）
- [ ] 中间松开 → 转写文字追加 inputText 后立即发送一条消息
- [ ] 右滑松开 → 转写文字追加 inputText，不发送
- [ ] 左滑松开 → 丢弃，不回填不发送
- [ ] 按住不说话 → 松开不发空消息，轻提示
- [ ] 松开后 ≤800ms 转写收尾期间显示「转写中…」，完成后按上述分发
- [ ] iOS Safari：AudioContext 正常 resume（非 suspended），录音有波形
- [ ] 录音超 60s → 自动取消 + 提示，不误发
- [ ] 权限拒绝 / 无麦克风 / 服务不可用 / worklet 加载失败 → Panel 明确提示并回 idle
- [ ] 组件切换/卸载不泄漏（无残留 audio track / WS / timer / window listener / rAF）
- [ ] `npm run build` + `vue-tsc --noEmit` 通过
