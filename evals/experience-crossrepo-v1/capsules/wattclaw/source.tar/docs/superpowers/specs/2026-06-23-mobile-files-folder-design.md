# 移动端文件管理 — 面包屑文件夹层级 + 默认最活跃员工(修订版)

- 日期:2026-06-23
- 范围:移动端 `/m/files` + 网页端建树逻辑 SSOT 抽取
- 状态:设计已批准;本版经架构师审查修订(每员工独立树 / 数据源收敛 / 真 SSOT 抽取)

## 1. 背景与问题

移动端 `MobileFilesPage.vue` 的 `flattenFiles()`(:128)把 `/api/files/batch-list` 数据**递归拍平成纯文件列表,丢弃文件夹结构**,所有文件平铺一列。网页端 `FileManagerPage.vue` 用 `agentTrees: AgentFileTree[]`(每员工一棵可展开树)正常按文件夹组织。另:数字员工筛选胶囊默认 `currentAgentId = ''`(全部),所有员工文件混在一起。

> **初版 spec 的两个错误(已修正)**:① 曾设计「跨员工按 path 合并一棵树」,但查证网页端是**每员工独立树**(`FileManagerPage:104`),合并不但偏离网页端,还破坏 workspace 隔离 + 丢失 `workspace` 归属(下载/删除契约 `{path, workspace}`)。② 曾让 `pickMostActiveAgentId` 跨 store 传 sessions,但查证 `workspaceStore.agents` 是 `AgentWithSessions[]`(`workspace.ts:34/458`),**自带 sessions**,无需跨 store。

## 2. 目标

1. **文件夹层级(面包屑导航)**:与员工筛选独立。点文件夹进入,面包屑逐级返回,一次只看一层。
2. **默认最活跃数字员工**:筛选胶囊初始值从「全部」改为「会话最近活动」。

## 3. 非目标(YAGNI)

- 文件夹节点的下载/删除(文件夹仅可进入)。
- 引入测试框架(项目无 vitest,不扩张 scope;纯函数列边界用例清单待测)。
- 网页端展示形态改动(只抽共享建树逻辑,网页端 UI/交互不变)。
- 移动端树形缩进展示(已选面包屑)。

## 4. 设计

### 4.1 数据源(零后端改动)

`/api/files/batch-list` 已返回带 `path` 的文件,文件夹区分纯前端从 `path` 重建树,不动后端。

### 4.2 SSOT 抽取(真单一权威)

从网页端 `FileManagerPage.vue` 抽取纯建树逻辑到 `src/utils/file-classify.ts`,网页+移动共享:

**移入(从网页端,纯函数/纯类型,行为等价)**:
- `AgentFileTree`(interface,自 `FileManagerPage:77`)
- `normalizeEntries(entries, agent: {agentId; name}, workspace): FileEntry[]`(自 `:526`,纯建树核心:扁平文件列表 → 带 `children` 的 `FileEntry` 树)
- `flattenFiles(nodes): FileEntry[]`(自 `:404`,树 → 扁平)

**新增(面包屑专用)**:
- `listDirLevel(root, currentPath): { dirs: FileEntry[]; files: FileEntry[] }` — 取当前层子项,目录在前;**目录按名、文件按 `modifiedAt` 降序**
- `splitPathSegments(path): string[]` — 路径分段,面包屑渲染

网页端 `FileManagerPage.vue` 删本地 `AgentFileTree`/`normalizeEntries`/`flattenFiles`,改 `import` 自 file-classify.ts;外层循环(员工筛选/admin 空跳过/expanded 视图状态/排序)原样保留。行为等价,参照 `session-time.ts`、`file-classify.ts` 既有抽取先例。

`src/utils/session-time.ts` 新增:
- `pickMostActiveAgentId(agents: AgentWithSessions[]): string` — 用 `agent.sessions` + `sessionEffectiveTs` 取最近活动最大者;无会话者 ts=0 沉底;全无会话返回首个。**数据源单一(workspaceStore.agents),零跨 store**。

### 4.3 MobileFilesPage 改造

- 删本地 `flattenFiles`(:128),改用 `normalizeEntries` 为每个员工建 `AgentFileTree` → `agentTrees: AgentFileTree[]`。
- **双状态**:`currentAgentId`(默认最活跃;`''`=全部) + `currentPath`(员工树内路径;`''`=根)。
- computed:
  - 单员工:`currentEntries = listDirLevel(agentTree.root, currentPath)` → `{ dirs, files }`
  - 全部模式:`agentTrees` 作为顶层员工条目(头像 + 名 + 文件数,可进入)
  - `breadcrumb`:全部模式 `[全部]`;单员工 `[员工名, ...path 段]`
- 交互:`enterDir(dir)` → `currentPath = dir.path`;`goUp()` 截断末段;`goRoot()` → `''`;点员工条目 → `currentAgentId = id, currentPath = ''`;返回全部 → `currentAgentId = ''`。
- 文件类型筛选:作用于 `currentEntries.files`(`classifyFile`)。
- **切员工/类型:`currentPath` 重置 `''`**。
- 默认员工:`loadFiles` 成功后 `currentAgentId = pickMostActiveAgentId(workspaceStore.agents)`。

### 4.4 数据流

```
batch-list → normalizeEntries(每 agent) → agentTrees: AgentFileTree[]
currentAgentId 具体 → listDirLevel(root, currentPath) → currentEntries{dirs, files}
currentAgentId='' (全部) → agentTrees 顶层员工列表
breadcrumb ← [currentAgentId 名?, ...splitPathSegments(currentPath)]
默认 ← pickMostActiveAgentId(workspaceStore.agents)
```

### 4.5 错误处理

- batch-list 失败:沿用现有 `errorMsg`。
- 最活跃员工无文件:`currentEntries` 空 → 空状态文案,**不回退全部**(诚实降级)。
- loadFiles 重建后:`currentPath` 在新树**仍存在→保持原目录**;不存在→回退根 + 轻提示。
- `currentAgentId` 无对应树(数据缺失):回退全部。
- 异常 path(空/重复/大小写):`normalizePath` + `createFileNodeId` 去重防御。

### 4.6 i18n

单 locale `zh-CN`(`en-US.ts` 不存在,项目仅 zh-CN)。新增 `pages.mobile.files.breadcrumb.*`(全部/根/返回/分隔)、空状态、员工分组标题、路径失效提示。

## 5. 边界决策(修订)

1. **每员工独立树**(对齐网页端 `agentTrees`),**不跨员工 path 合并**(workspace 隔离红线)。
2. **全部模式**:顶层员工列表(可进入),进入后该员工文件夹树——满足「全部也按文件夹层级」。
3. **最活跃员工无文件**:空状态,不回退全部。
4. **文件夹节点**:仅可进入,不挂 ⋮ 下载/删除。
5. **切员工/类型**:`currentPath` 重置根。
6. **根目录散文件**(无文件夹):直接列根层。

## 6. 实现锚点(文件清单)

| 文件 | 改动 |
|---|---|
| `src/utils/file-classify.ts` | +`AgentFileTree` / `normalizeEntries` / `flattenFiles`(从网页端移入)+ `listDirLevel` / `splitPathSegments`(新增) |
| `src/views/files/FileManagerPage.vue` | 删本地 `AgentFileTree`/`normalizeEntries`/`flattenFiles`,改 import;外层循环原样保留;行为等价 |
| `src/utils/session-time.ts` | +`pickMostActiveAgentId(agents)` |
| `src/mobile/views/files/MobileFilesPage.vue` | 删本地 `flattenFiles`;`normalizeEntries` 建 `agentTrees`;`currentAgentId`+`currentPath` 双状态 + 面包屑;默认最活跃员工 |
| `src/i18n/zh-CN.ts` | +面包屑 / 空状态 / 员工分组 key |

## 7. 测试策略

项目无测试框架,本次不引入。新增纯函数无副作用,列关键边界用例清单(未来框架就绪即测):

- `normalizeEntries`:空 files / 单文件 / 多层嵌套 / **跨员工同名路径各自独立** / 隐藏文件过滤 / path 大小写归一 / 重复 path 去重
- `listDirLevel`:根层 / 深层 / 空目录 / 目录与文件混合排序(目录在前,文件按 modifiedAt 降序)
- `splitPathSegments`:空 / 单段 / 多段 / 尾部斜杠
- `pickMostActiveAgentId`:全无会话 / 单员工多会话 / 时间平局

靠 `npm run build`(vue-tsc)类型检查 + 手机手动验证(不靠裸 vue-tsc,会漏过类型回归)。

## 8. 验收标准

- [ ] 每员工独立树,面包屑可逐级进入 / 返回。
- [ ] 默认选中会话最近活动的员工(非「全部」)。
- [ ] 全部模式顶层员工列表,可进入各员工文件夹树。
- [ ] 切员工 / 类型后面包屑回根。
- [ ] 最活跃员工无文件显示空状态,不回退全部。
- [ ] **网页端文件管理不回归**(SSOT 抽取后行为等价)— 关键回归点。
- [ ] 移动端文件预览 / 下载 / 删除(现有 ⋮ 菜单)不回归。
- [ ] `npm run build` 绿。
