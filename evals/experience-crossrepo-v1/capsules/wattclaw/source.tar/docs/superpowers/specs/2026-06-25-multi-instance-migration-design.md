# 多 OpenClaw 实例部署 + 单实例数据迁移设计 v3

> 状态:Draft v3.1(2026-06-25)· 基于 8 轮生产实勘 + 代码调研 + gateway 接口实测
> v3 变更:明确**两阶段(全新部署校验 → 数据迁移)**;采用**全新 PG + 复用 tenant 映射 + gateway 历史回填**(取消 gateway 存储迁移层)。
> v3.1 变更:§11.1 四项决策闭环(单实例 wattclaw 库精确交叉:268 匹配 / 262 未匹配 / 5 无映射 user)。原 v3 的"126 匹配 / 315 未匹配"为旧口径误值,已全文修正。
> **镜像版本:稳定版 `alpine/openclaw:2026.6.9-browser`(非 beta)**
> **部署方式:本地服务器执行(无需 SSH)**

---

## 1. 背景与目标

### 1.1 现状(实勘)
- **单实例(当前生产,在用)**:`nginx(806/SSL) → wattclaw(3001, 单实例Admin) → gateway(pid 2132452, :18789, npm openclaw@2026.6.1)`。
- **现有 openclaw-web 多实例(仅测试参考)**:`OPENCLAW_MULTI_TENANT=true` + 9 个 tenant 容器(GHCR `2026.6.1-beta.2`)。**不会上线,仅作挂载设计/拆分产物参考**。
- 另 5 组 `tini+node gateway` 孤儿进程(含 93.8% CPU 那个)不监听端口,旁路清理。

### 1.2 目标
**全新部署一套 WattClaw + openclaw 多实例(v2026.6.9-browser)**,把单实例完整数据迁移过去,用户无感、数据不丢失,每阶段可回滚。

### 1.3 关键决策(已拍板)
1. **全新 PG**(干净隔离):不复用 wattclaw-postgres,新多实例用独立 PG。
2. **复用 `user_tenant_assignments`(173 行)**:user→tenant 映射直接迁入新库,省去重新规划。
3. **gateway 历史回填 PG**(实测可行):用 gateway `/sessions/{key}/history` 接口把历史灌进新 PG,**取消 gateway 存储文件迁移**(物理存储不在文件系统已知位置,HTTP 接口替代)。
4. **允许短暂停机**;先空跑校验再迁数据。

### 1.4 非目标
- 不重构 docker.sock 多实例架构(复用 `server/core/multi-tenant-gateway.js`)。
- 不清理孤儿 gateway 进程(旁路)。

---

## 2. 生产现状盘点(实勘事实)

### 2.1 入口链路
```
用户 → my_nginx(806→80, SSL, wattclaw.wattman.cn)
     → wattclaw(3001, 单实例Admin, OPENCLAW_WS_URL=ws://192.168.10.12:18789)
     → 单实例 gateway(pid 2132452, npm openclaw@2026.6.1)
```

### 2.2 数据四层模型 + 关联链

| 层 | 内容 | 存储 | 单实例量 |
|---|---|---|---|
| **L1 管理数据** | users/agents/sessions/channels/cron/team | `wizard.db`(SQLite) | 177 / 272 / 1265 / 67 / 16 / 3 |
| **L2 消息历史** | 会话消息 | `wattclaw-postgres · session_messages`(PG) | 15461 条 / 855 sessions |
| **L3 gateway 配置** | agent 定义 | `~/.openclaw/openclaw.json`(832KB) | 530 agents(268 匹配 user_agents / 262 未匹配) |
| **L4 agent 身体** | SOUL/memory/data/.git | `~/.openclaw/agents/`(659)+ 顶层 49 Web 工作区 | 3.1G |

**关联链**:`PG.session_messages.session_key ↔ wizard.user_sessions.session_key → user_id → user_tenant_assignments.tenant_id → openclaw_tenants`

**gateway 历史机制(代码调研 + 实测)**:
- gateway 持有完整历史,经 `GET /sessions/{key}/history` 暴露(`fetchHistoryFromGateway`)。
- WattClaw 写 PG 用 `mergeSessionMessages`(**幂等**:msg_id `ON CONFLICT` + role+content+ts 指纹去重)。
- 现有 `catchUpMissedMessages` 只追**外部渠道 + 24h**,不够全量,需新写回填脚本。
- **实测**:3 个内部 Web 会话 gateway 返回 246/317/142 条(status 200),与 wizard msg_total 吻合 → **gateway 是权威源,比旧 PG 更全**(旧 PG 15461 是其缓存子集)。

### 2.3 版本矩阵
| 组件 | 当前 | 升级 |
|---|---|---|
| 单实例 | `2026.6.1`(npm stable) | `npm i -g alpine/openclaw@2026.6.9-browser` |
| 新多实例 | — | `alpine/openclaw:2026.6.9-browser` |
| 目标 | **`2026.6.9-browser`** | 待验证 npm 与 GHCR 镜像内核等价(§11.2) |

---

## 3. 目标架构(全新一套)

```
用户 → nginx(806/SSL) → 【新】WattClaw Admin(OPENCLAW_MULTI_TENANT=true)
                             │ docker.sock
                             ↓
                      【新】openclaw-tenant-1..N (alpine/openclaw:2026.6.9-browser)
                             │ bind mount
                      【新】tenants/tenant-N/ + 共享 ~/.openclaw/agents
                             │
                      【新】PG(new-postgres): session_messages ← 回填灌满
```
- 全新 WattClaw Admin(本项目代码 build,`MULTI_TENANT=true`)+ 全新 PG + 全新 openclaw 多实例容器(v2026.6.9-browser)。
- 切换后:nginx 806 上游 `3001 → 新 Admin`;单实例 wattclaw + gateway **仅保留承载 finance-faq**(finance-faq 通过飞书直连 gateway,不经过 nginx,见 §6.3)。

---

## 4. 数据迁移范围(回填 PG 方案)

> gateway 历史存储层**不迁**(HTTP 回填替代)。迁移 L1/L3/L4 + 新 PG 灌满(L2)。

### 4.1 L1 wizard.db:全量灌新空库
- 目标是新 Admin 的**空 wizard.db**,直接全量导入(v2 的方案A/B 二选一自然消解为目标空库)。
- 同步表:users / user_agents / user_sessions / user_channels / cron_jobs / agent_team / auth_tokens / user_model_providers / models。
- **复用并迁入** `openclaw_tenants`(9)+ `user_tenant_assignments`(173)(从现有 openclaw-web wizard.db 导出)。
- user_id 体系两库同构,无冲突。**5 个无 tenant 映射的 user** → §11.1 决策(test1/2/3 测试号丢弃;万伯阳、张亚辉 2 个真实手机号用户归默认 tenant-1)。

### 4.2 L2 新 PG:迁旧 PG(白名单)+ gateway 回填
新 PG 空,两步灌满(mergeSessionMessages 幂等合并):
1. **迁旧 PG**:`INSERT INTO 新PG.session_messages SELECT * FROM wattclaw-postgres.session_messages WHERE session_key IN (wattclaw wizard.user_sessions 的 1265 keys)`。白名单自动排除 openclaw-web 测试数据(其 session 不在单实例 wizard)。
2. **gateway 全量回填**:遍历 `wizard.user_sessions(1265) ∪ gateway sessions.list` 的 session_key → `fetchHistoryFromGateway(key, 大limit)` → `mergeSessionMessages` 写新 PG。补齐旧 PG 缺的 32%,且 gateway 为权威源。
- 结果:新 PG = `旧PG ∪ gateway历史`,最完整。
- **残留风险**:gateway 也已清理的老会话(旧 PG 亦无缓存)永久丢失;回填后统计覆盖率量化。
- **时序**:回填必须在单实例 gateway(:18789)下线前完成。

### 4.3 L3 openclaw.json:按 tenant 拆分(见 §6)
### 4.4 L4 agent 工作区文件(见 §7)

---

## 5. 全新部署设计

### 5.1 容器拓扑
| 容器 | 镜像/角色 |
|---|---|
| 新 WattClaw Admin | 本项目 build,`OPENCLAW_MULTI_TENANT=true`,`OPENCLAW_WS_URL` 指向多实例管理 |
| new-postgres | 全新 PG(session_messages) |
| openclaw-tenant-1..N | `alpine/openclaw:2026.6.9-browser` |

### 5.2 挂载设计(参考现有 tenant-1 + 补 state/memory)
现有 tenant-1 实证挂载:`tenants/tenant-N → /home/node/.openclaw`(私有)+ `~/.openclaw/agents → /home/node/.openclaw/agents`(共享)+ `openclaw.json`(file)+ XDG(`.config/.cache/.local/share/.local/state`)+ `~/.wattclaw`(共享凭据)。
**补充**:确保 tenant 私有 `state/` + `memory/` 持久化(新 gateway 运行态 + per-agent RAG 库),否则新对话重启丢失。

### 5.3 tenant 划分
复用现有 9 tenant + `user_tenant_assignments`(173)映射,迁入新库。

---

## 6. openclaw.json 拆分规则(L3)

### 6.1 数据流
```
单实例 openclaw.json (agents.list=530, 268 匹配 user_agents.gateway_agent_id / 262 未匹配)
   → user_id → user_tenant_assignments.tenant_id
   → N 份 tenant-N/openclaw.json (上次拆出 215: t1:31/t2:23/t3:40/t4:14/t5:23/t6:25/t7:13/t8:25/t9:21)
```

### 6.2 字段分类
| 保留(带进每份) | 丢弃 |
|---|---|
| agents(按tenant拆)、channels、bindings(跟agent)、auth、models、tools、plugins、secrets、meta、commands、session、messages | skills、gateway、wizard |

> 上次残留:skills 留 tenant-2/5/9、gateway 留 tenant-9,脚本显式剔除。

### 6.3 特殊处理
- `finance-faq`:**留单实例**(连同 bindings)。实勘它不在 `user_agents`(非 WattClaw 管理的数字员工,是 gateway 层独立服务),用户已定不迁。**finance-faq 通过飞书直连 gateway,不经过 nginx**——其余数据迁走后,单实例降级为 finance-faq 专用,nginx 无感,无需双上游。
- 262 个未匹配 agent:丢弃(51 IM 数字前缀 + 211 非数字,含 `user1-bot`/`user2-bot`/`u1-test`/`zhaotoubiaotest` 测试 bot、`main`/`sql` 系统、`agent-17771…` 已删 agent 遗留配置)。finance-faq 除外。迁移脚本执行前再跑一次活跃度核对(近 N 天有无会话)防误删。
- 顶层 49 Web agent 工作区:**已澄清**——即 `user_agents` 中 web 渠道子集(Administrator 建约 25 个 + 各真人用户),每条 `user_agents` 有 `owner`,迁移时按 owner→tenant 归属,**无需独立"共享源/私有卷"决策**。

---

## 7. agent 工作区文件(L4)
- **IM agent(659,`agents/`)**:已共享挂载源,新多实例直接挂载,**免拷**。
- **顶层 Web agent(49)**:含 SOUL/memory/data/reports/bids/.git,按归属拷入 tenant 卷;归属 §11.1。
- 路径硬编码:`/home/wattman/` → `/home/node/`,抽查 agent 配置内路径。

---

## 8. 版本对齐
单实例先原地升级 6.9-browser(OpenClaw 按 `meta.lastTouchedVersion` 自动 migrate 自己数据)→ 验证 → 回滚成本最低。验证通过后数据为 6.9-browser 格式,再迁/回填 = 同版本操作。npm 与 GHCR 镜像等价性 §11.2 待验证。

---

## 9. 两阶段执行

### Phase 1:全新部署 + 空跑校验(不碰生产数据)
1. 部署新 WattClaw Admin + new-postgres + openclaw 多实例(v2026.6.9-browser),挂载按 §5.2。
2. 迁入 `openclaw_tenants` + `user_tenant_assignments`(空 wizard.db 建结构)。
3. **校验**:多租户路由、tenant 隔离、空 agent 可创建可用、PG 连接、gateway 容器健康、state/memory 持久化。
4. 通过后才进 Phase 2。

### Phase 2:数据迁移

**阶段 0:全量备份**
- tar 单实例 `~/.openclaw/`;`pg_dump` wattclaw-postgres;`.backup` 两份 wizard.db;tar 新环境 tenants 卷。保留至切换稳定 7 天。

**阶段 1:单实例原地升级 6.9-browser**
- 停 gateway 写 → `npm i -g alpine/openclaw@2026.6.9-browser` → 重启 migrate → 验证(user_agents 272 / sessions 1265 完整、抽检历史会话、finance-faq、web 搜索)→ 失败回滚 6.1 + 备份。

**阶段 1.5:新 PG 灌满(迁旧 PG + gateway 回填)**
1. 迁旧 PG 白名单(§4.2 步骤1)。
2. gateway 全量回填脚本遍历 session_key 写新 PG(§4.2 步骤2)。
3. 校验:新 PG distinct session_key 覆盖率、消息总量、抽样完整;统计无法回填的老会话清单。

**阶段 2:数据灌入新环境**
1. L1 wizard.db 全量导入新 Admin(§4.1)。
2. L3 openclaw.json 拆分脚本生成 N 份 → review → 部署到各 tenant。
3. L4 工作区文件拷贝(顶层 Web agent 按 §7)。
4. 校验:行数对账、agent 可用、飞书通。

**阶段 3:切换 + 灰度**
1. 灰度:少量用户经新 Admin → tenant,验证**免重登(auth_tokens)+ 会话列表(L1)+ 历史消息(L2)+ agent 可用 + 飞书通**。
2. 全量:nginx 806 上游 `3001 → 新 Admin`,观察 24h。
3. 单实例保留承载 finance-faq(其余迁完,见 §6.3)。

---

## 10. 回滚预案
| 失败点 | 回滚 |
|---|---|
| Phase 1 校验 | 新环境废弃,生产未动 |
| 阶段 1 升级 | `npm i -g alpine/openclaw@2026.6.1` + 恢复 ~/.openclaw |
| 阶段 1.5 回填 | 新 PG 清空重灌;旧 PG + gateway 未动 |
| 阶段 2 灌入 | 新 wizard.db 恢复空库备份;单实例数据未删 |
| 阶段 3 切换 | nginx 806 切回 3001;单实例仍全量服务 |

---

## 11. 待确认与风险

### 11.1 决策(已拍板,基于 2026-06-25 单实例 wattclaw 库精确交叉)
1. **顶层 49 Web agent 工作区** → 即 `user_agents` 的 web 渠道子集,按 owner→tenant 归属,不单列。
2. **finance-faq** → 留单实例;单实例永久保留(降级为 finance-faq 专用),**不全面下线**。
3. **5 个无 tenant 映射 user** → test1/test2/test3 丢弃;**万伯阳(13504417350)、张亚辉(15538862800)** 2 个真实手机号用户归默认 tenant-1。
4. **262 个未匹配 agent** → 丢弃(finance-faq 除外);迁移脚本执行前再跑一次活跃度核对(近 N 天有无会话)防误删。

### 11.2 风险
| 风险 | 等级 | 缓解 |
|---|---|---|
| gateway 回填漏老会话(已清理) | 中 | 迁旧PG∪回填取并集;回填后统计覆盖率 |
| L1 wizard.db 灌入出错 | 高 | 全量备份;脚本只读源写目标分步;行数对账 |
| auth_tokens 不同步致重登 | 中 | 同步 auth_tokens;阶段3灰度验证 |
| 跨版本 migrate 失败 | 中 | 阶段1先原地验证,失败即回滚 |
| npm vs GHCR 镜像不等价 | 中 | §11.2 升级后对比 wizard.db schema |
| 新 gateway state/memory 未持久化 | 中 | §5.2 挂载显式包含;Phase1 校验 |
| 路径硬编码 | 中 | 阶段2抽查 agent 配置路径 |

---

## 12. 实现计划入口(writing-plans)
- **Task A**:`scripts/backfill-pg-history.mjs` gateway 全量回填脚本(复用 fetchHistoryFromGateway + mergeSessionMessages,并发+幂等)。
- **Task B**:`scripts/migrate-pg-whitelist.sql` 旧 PG 白名单迁新 PG。
- **Task C**:`scripts/sync-wizard-db.mjs` L1 全量灌新空库 + tenant 映射。
- **Task D**:`scripts/split-openclaw-json.mjs` L3 拆分 + 报告。
- **Task E**:阶段0 备份脚本(tar + pg_dump + sqlite .backup)+ 体积评估。
- **Task F**:Phase1 全新部署 + 校验 runbook。
- **Task G**:阶段1/1.5/2/3 迁移与切换 runbook。

> §11.1 四项已闭环(见上),Task A–G 细节可定稿。
