# 团队模板与 Agent 复用：第一阶段实施总结

> 文档版本：v1.0  
> 编写日期：2026-08-21  
> 适用范围：WattClaw 管理面板、Express 服务端、WattClaw Team Project Builder 协作插件  
> 实施状态：第一阶段代码已完成，构建和自动化测试已通过

## 1. 摘要

第一阶段已经把“每次创建团队都从零开始规划和创建不可复用 Agent”的流程，改造成了一个可逐步沉淀的闭环：

1. 服务端维护版本化团队模板。
2. 创建项目时，服务端先对任务意图做归一化，并从可用模板中计算相似度。
3. 达到自动应用阈值时，匹配到的模板会作为 Manager 的内部上下文，指导团队角色、边界和工作流。
4. 创建团队时优先寻找用户已有的、可复用的 Agent Profile，并把其角色、能力、技能和模型配置传给 Manager。
5. 复用的是“Agent Profile 和配置”，不是把另一个项目的运行时 Agent、会话或工作目录直接搬进当前项目。当前项目仍然创建独立的运行时 Agent 和独立 workspace。
6. 成功完成但尚未匹配模板的项目会生成候选模板。相同功能的团队不会重复积累；候选模板需要达到成功证据阈值，并由管理员审核后才能成为 active 模板。

这样既缩短了相似项目的团队创建时间，又保留了项目级隔离，同时为后续的模板治理、人工审核和更智能的匹配留下了明确接口。

## 2. 背景与目标

### 2.1 原有问题

此前团队协作项目的创建过程主要依赖 Manager 临时规划：

- 每个项目都要重新分析需求、决定角色和工作流。
- 项目中的 Agent 具有项目专属身份，配置和经验不能直接作为下一次创建的输入。
- 项目结束后，无法区分“这套团队配置只是一次性尝试”还是“已经被证明适合某类任务”。
- 相似团队可能因为名称不同、自然语言表述不同而被重复创建。
- 如果直接复用运行时 Agent，容易跨项目共享 workspace、会话或上下文，带来数据泄漏和并发冲突风险。

### 2.2 第一阶段目标

- 建立可版本化、可审计、可启停的团队模板存储模型。
- 在 `project.build` 前完成确定性的模板匹配。
- 将匹配结果传给 Manager，并保持现有 Gateway project build 流程兼容。
- 把已有的普通用户 Agent 映射成可复用的 Agent Profile。
- 提供按角色和能力选择 Profile、租约、容量检查和释放机制。
- 对成功项目自动提取候选模板，支持去重和证据累计。
- 让候选配置不会未经审核直接污染生产模板库。
- 不改变当前项目 Agent 的隔离 workspace 和运行时生命周期。

### 2.3 第一阶段非目标

以下能力没有在第一阶段直接实现：

- 不复用另一个项目中的 live Gateway Agent ID、session 或 workspace。
- 不把项目的完整对话、原始输出、凭据或 workspace 内容写入模板。
- 不自动把候选模板提升为 active 并立即影响所有新项目。
- 不新增专门的前端模板管理页面；本阶段先提供 RPC 和服务端能力。
- 不改变 Gateway 的核心 Agent 协议，也不引入未确认的 Gateway RPC 分支。

## 3. 总体架构

第一阶段采用四层结构，职责边界如下：

```text
用户任务描述
    |
    v
Express / project.build
    |
    +--> Team Template Service
    |       - 意图归一化
    |       - 候选模板匹配
    |       - 版本、状态、权限和相似度治理
    |
    +--> Agent Profile Service
    |       - 同步已有 user_agents
    |       - 按角色/能力筛选
    |       - 租约和并发容量
    |
    +--> Gateway project.build
            - 创建当前项目的隔离运行时 Agent
            - 将模板和 Profile 作为 Manager 内部上下文
            |
            v
        项目运行、完成、归档或删除
            |
            +--> 成功项目提取候选模板
            +--> 释放 Profile binding
            +--> 管理员审核/发布模板
```

这里有两个容易混淆的概念：

- **Agent Profile**：可复用的角色配置，包含角色、能力、技能、模型和复用策略。
- **Runtime Agent**：某一个项目内实际运行的 Agent，拥有独立 runtime ID、session 和 workspace。

Profile 可以跨项目复用；Runtime Agent 必须继续按项目隔离。

## 4. 团队模板的形式

### 4.1 模板实体

模板采用“逻辑模板 ID + 版本号”的形式，数据库中通过 `template_key = template_id@version` 唯一标识一个版本。一个模板的版本更新不会覆盖历史版本，方便回滚、审计和比较。

核心字段如下：

| 字段 | 说明 |
| --- | --- |
| `templateId` | 稳定的逻辑 ID，例如 `web-product-delivery` |
| `version` | 语义化版本，例如 `1.0.0` |
| `scope` | 当前定义为 `global` 或 `user`；内置模板是 global。普通用户提交的模板会保存为 user/candidate，当前匹配阶段只读取 active 模板，实际作用域规则见“安全、权限与兼容性”章节 |
| `name` | 人类可读的模板名称 |
| `description` | 模板用途说明 |
| `status` | `candidate`、`validated`、`active`、`archived` |
| `intent` | 必需标签、偏好标签、排除标签 |
| `capabilities` | 此类任务通常需要的能力集合 |
| `slots` | 角色槽位、职责、技能要求和能力要求 |
| `workflow` | 阶段及阶段之间的工作关系 |
| `createdBy` | 创建者用户 ID |
| `metadata` | 预留的扩展字段 |

模板的最小合法条件：

- 必须有 `id`、`name`。
- 必须至少有一个 slot。
- slot ID 必须唯一。
- 保存时会校验所有者和管理员权限。

### 4.2 模板示例

下面是一个简化后的 Web 产品交付模板。实际存储在 `definition_json` 中，数据库行另外保存模板 ID、版本、作用域、状态和时间戳。

```json
{
  "id": "web-product-delivery",
  "version": "1.0.0",
  "name": "Web 产品交付",
  "description": "适用于网站、Web 应用和 MVP 产品交付",
  "intent": {
    "required": ["web_app"],
    "preferred": ["mvp", "frontend", "product"],
    "excluded": ["video_only"]
  },
  "capabilities": [
    "requirements_analysis",
    "ux_design",
    "frontend_implementation",
    "qa_validation"
  ],
  "slots": [
    {
      "id": "manager",
      "roleId": "project_manager",
      "name": "项目经理",
      "selector": { "capabilities": ["planning", "delegation"] },
      "defaultProfile": {
        "role": "manager",
        "soul": "负责拆解目标、分配任务、汇总进展和控制交付边界",
        "skills": ["planning", "delegation"]
      }
    },
    {
      "id": "frontend",
      "roleId": "frontend_engineer",
      "name": "前端工程师",
      "selector": { "capabilities": ["frontend_implementation"] }
    },
    {
      "id": "qa",
      "roleId": "qa_engineer",
      "name": "质量验证",
      "selector": { "capabilities": ["qa_validation"] }
    }
  ],
  "workflow": [
    { "id": "requirements", "ownerSlotId": "manager" },
    { "id": "design", "ownerSlotId": "manager" },
    { "id": "implementation", "ownerSlotId": "frontend" },
    { "id": "validation", "ownerSlotId": "qa" }
  ]
}
```

### 4.3 当前内置模板

第一阶段内置并自动初始化了三类全局 active 模板：

| 模板 | 典型任务 | 主要槽位 |
| --- | --- | --- |
| `web-product-delivery@1.0.0` | 网站、Web 应用、MVP | manager、product、frontend、qa |
| `content-campaign@1.0.0` | 内容营销、社交媒体活动、文案活动 | manager、strategist、writer、designer |
| `data-insight@1.0.0` | 数据分析、报表、洞察 | manager、analyst、reviewer |

初始化使用 `INSERT OR IGNORE`，因此服务重启不会重复插入，也不会覆盖管理员已经修改过的同版本定义。

## 5. 任务意图归一化与模板匹配

### 5.1 为什么需要归一化

用户可能用中文、英文或混合表达同一件事，例如：

- “做一个带登录和报表页面的 MVP 网站”
- “build a web app with auth and analytics dashboard”

如果直接比较原始字符串，无法稳定识别这两种表述的功能相似性。因此服务端先把任务名称、描述和初始提示词组合起来，映射成结构化意图：

```ts
{
  prompt: string,
  tags: string[],
  capabilities: string[],
  deliverables: string[]
}
```

当前识别的领域信号包括：`web_app`、`content_campaign`、`data_analysis`、`video_production`、`mvp`、`frontend`、`product`、`marketing`、`copywriting`、`social_media`、`analytics`、`report` 等。归一化结果始终包含基础的 `planning` 和 `delegation` 能力，确保 Manager 槽位有稳定的基础能力。

### 5.2 匹配流程

对每个 active 模板执行以下步骤：

1. 如果任务命中模板 `intent.excluded` 中的任意标签，直接淘汰。
2. 如果模板定义了 `intent.required`，且任务没有全部满足，直接淘汰。
3. 计算意图匹配度。
4. 计算模板能力集合与任务能力集合的覆盖率。
5. 根据可推断的交付物计算 deliverable score。
6. 使用加权公式得到总分。
7. 对候选排序，并根据阈值生成决策。

### 5.3 评分公式

当前总分为：

```text
finalScore = intentScore * 0.55
           + capabilityScore * 0.30
           + deliverableScore * 0.15
```

当模板的 required tags 均满足时，意图分数为：

```text
intentScore = 0.75 + preferredTagCoverage * 0.25
```

各分数均限制在 `[0, 1]`，最终结果保留四位小数。

### 5.4 决策阈值

| 分数 | 决策 | 行为 |
| --- | --- | --- |
| `>= 0.85` | `auto_apply` | 直接把该模板作为 Manager 的权威团队配置上下文 |
| `>= 0.65` 且 `< 0.85` | `recommend` | 返回推荐模板，但由上层决定是否采用 |
| `< 0.65` 或没有候选 | `fresh_plan` | 不套用模板，让 Manager 全新规划 |

当前 `project.build` 对 `auto_apply` 和 `recommend` 都会把最佳候选传入 Manager；`fresh_plan` 则明确告诉 Manager 没有可用模板，避免它误以为存在既有配置。

### 5.5 匹配结果的持久化

每个项目最多保存一条最新匹配记录，表为 `wattclaw_project_template_matches`。记录包含：

- 项目、用户和租户信息。
- 被选中的模板 ID 和版本。
- 分数和决策。
- 归一化后的意图。
- 完整候选结果。
- 创建时使用的模板快照。

保存快照的原因是：模板以后可能升级或归档，但仍然要能解释当时为什么选择了这套团队配置。

## 6. `project.build` 集成流程

当前端发起项目创建时，服务端执行以下顺序：

1. 读取 `name`、`description`、`initialPrompt`，组合成匹配文本。
2. 调用 Team Template Service 进行意图归一化和模板匹配。
3. 对选中模板的每个 slot 调用 Agent Profile Service，按 `roleId` 和能力要求寻找可用 Profile。
4. 生成给 Manager 的内部上下文，包含：
   - 模板决策和选中模板。
   - 模板中的角色槽位、能力边界和工作流。
   - 找到的可复用 Profile 的安全摘要。
5. 调用原有 Gateway `project.build`，创建当前项目的独立运行时 Agent。
6. 将精简的 `templateMatch` 写入 `draftSuggestion`，供后续前端、审计和 Manager 消息使用。
7. 尝试调用 Gateway `project.update` 写回项目草稿；旧 Gateway 不支持该方法时只记录 warning，不让项目创建失败。
8. 在本地数据库保存模板匹配和模板快照。

项目创建 RPC 还接收两个流程控制参数：

| 参数 | 作用 | 默认值 |
| --- | --- | --- |
| `teamCreationMode` | `template` 表示参考模板和 Profile，`manager` 表示完全由 Manager 自主规划 | `template` |
| `captureTeamTemplate` | 是否允许项目成功后沉淀候选团队模板 | `true` |

管理面板在协作页提供两个按钮控制这两个参数。按钮只在没有当前项目、准备创建新项目时显示；选择仅属于本次待创建项目，不作为跨项目的浏览器全局偏好。项目创建时设置会写入 `draftSuggestion.collaborationSettings`，之后已有项目和执行中的项目不再显示这两个按钮。服务端成功项目沉淀入口会同时读取项目草稿设置和本地项目匹配记录，因此即使 Gateway 的草稿回写失败，关闭沉淀仍然不会生成候选模板。

Profile 传给 Manager 的字段仅包括：

```text
id, roleId, name, gatewayAgentId, capabilityTags, skills,
model, reusePolicy, status
```

`baseWorkspace`、`metadata`、`userId` 等内部字段不会进入 Manager 上下文，避免暴露跨项目路径和租户信息。

### 6.1 离线兼容

模板和 Profile 查询属于本地 RPC，可以在 Gateway 暂时断开时执行。真正创建项目仍然依赖 Gateway；因此：

- 可以在 Gateway 断开时查看、匹配、保存模板和 Profile。
- Gateway 断开时不能完成真正的 runtime project build。
- 模板写回失败不会阻断已有项目创建流程。

## 7. Manager 如何感知模板

### 7.1 内部上下文注入

前端在向 Manager 发送创建后的任务消息时，会读取当前项目 `draftSuggestion.templateMatch`，在原有 builder/finalizer 指令前注入内部上下文。上下文包括：

```text
template_decision: auto_apply | recommend | fresh_plan
selected_team_template: <模板 JSON> | none
reusable_agent_profiles: <Profile 摘要 JSON> | none
```

这部分是内部协作上下文，不作为用户聊天内容展示。

### 7.2 Skill 约束

`wattclaw-team-project-builder` Skill 已增加以下规则：

- 如果 `selected_team_template` 存在，则模板是角色、能力边界和工作流的权威来源。
- 优先复用匹配到的 Profile 的角色和技能配置。
- 仍然为当前项目创建独立 runtime Agent。
- 只有在 `fresh_plan` 时才完全从零规划团队。

这样可以把“是否应用模板”的判断放在服务端，把“如何按模板协作”放在 Manager 的既有协作协议中，避免在前端重复实现一套团队规划逻辑。

## 8. Agent Profile 复用方案

### 8.1 Profile 数据模型

`agent_profiles` 表记录可复用配置：

| 字段 | 说明 |
| --- | --- |
| `id` | Profile ID |
| `user_id` / `tenant_id` | 所有者和租户边界 |
| `role_id` | 规范化角色，如 `frontend_engineer` |
| `name` | Profile 名称 |
| `gateway_agent_id` | 来源 Agent 的 Gateway ID；仅作为配置来源标识 |
| `base_workspace` | 来源 Agent 的基础 workspace，不能直接用于项目运行 |
| `capability_tags` | 能力标签 |
| `skills` | 技能列表 |
| `model` | 默认模型配置 |
| `reuse_policy` | 当前默认为 `profile` |
| `concurrency_limit` | 同时租用上限，默认 1 |
| `status` | `available`、`disabled` 等 |
| `metadata` | 来源和扩展信息 |

### 8.2 已有用户 Agent 的导入

调用 `list` 或 `find` Profile 时，服务端会先执行同步：

1. 查询当前用户已有的 active `user_agents`。
2. 排除没有 Gateway ID 的记录。
3. 排除以 `p-` 开头的项目专属 Agent。
4. 根据 Agent 的 category、template ID、名称和描述推断规范角色。
5. 如果相同 Gateway Agent ID 尚未有 Profile，则创建 `user-agent-<user_agent.id>` Profile。

因此原本可复用的普通用户 Agent 可以逐步进入 Profile 池，而项目专属 Agent 不会被误导入。

### 8.3 选择算法

给定模板 slot，服务端会按以下条件筛选：

- Profile 状态必须是 `available` 或符合租约释放条件。
- `roleId` 必须匹配；没有明确角色时可由能力匹配兜底。
- slot 的 required capabilities 必须是 Profile capability tags 的子集。
- 当前有效租约数必须小于 `concurrencyLimit`。

当前默认并发上限为 1，表示同一个 Profile 同时只服务一个项目，后续可以根据 Agent 是否支持并发进行调整。

### 8.4 租约与绑定

找到 Profile 后，项目成员绑定写入 `project_member_bindings`：

| 字段 | 说明 |
| --- | --- |
| `project_id` / `slot_id` | 当前项目和团队槽位 |
| `profile_id` | 被租用的 Profile |
| `runtime_agent_id` | 当前项目实际创建的 Agent ID |
| `session_key` | 当前项目会话标识 |
| `project_workspace` | 当前项目 workspace |
| `lease_until` | 租约结束时间，默认 30 分钟 |
| `status` | `leased`、`released` 等 |

绑定操作是项目和 slot 维度的幂等 upsert。同一个项目再次绑定同一 slot 时不会产生重复绑定。

项目成功、归档或删除时，服务端会释放全部 binding；过期租约在查询容量时视为不再占用。这样既能防止重复租用，也能在异常终止后恢复可用容量。

### 8.5 隔离边界

第一阶段明确采用“配置复用 + 运行时隔离”：

```text
可复用 Profile
    ├── 角色、技能、能力、模型配置
    └── 不能直接共享 workspace/session

项目 A Runtime Agent ── project-A workspace/session
项目 B Runtime Agent ── project-B workspace/session
```

也就是说，当前实现解决的是 Agent 配置和角色经验的复用，而不是跨项目复用同一个 live Agent 进程。这是为了避免：

- A 项目的文件被 B 项目读写。
- 两个项目抢占同一会话上下文。
- 一个项目的提示词、凭据或中间产物泄漏到另一个项目。
- Agent 并发状态不可控。

## 9. 成功项目如何自动沉淀为模板

### 9.1 触发条件

只有满足以下条件才会提取候选：

- 项目状态为 `success`。
- 项目至少有 2 个 worker member。
- 当前用户对项目有权访问。
- 该项目尚未被处理过。

管理员查看其他租户项目时不会把该项目写入管理员自己的模板证据；管理员自己创建的项目如果本地匹配记录属于当前管理员，则可以正常沉淀候选模板。

项目已有模板匹配记录时，只记录一次成功运行证据，不重复生成候选模板。

### 9.2 角色规范化

为了避免“前端”“前端开发”“frontend dev”被当成三个不同角色，服务端会把成员名称和 role 归一化为有限的 canonical role：

| Canonical role | 识别示例 |
| --- | --- |
| `project_manager` | manager、项目经理、管理、协调 |
| `frontend_engineer` | frontend、前端、网页 |
| `product_analyst` | product、产品、需求 |
| `qa_engineer` | qa、测试、质量、验证 |
| `visual_designer` | designer、设计、视觉、ui |
| `data_analyst` | data、数据、分析、analytics |
| `copywriter` | writer、文案、内容、copy |
| `video_editor` | video、视频、剪辑 |
| `domain_specialist` | 无法归入以上类别时的兜底角色 |

每个 canonical role 还会映射到稳定的 capability 集合，例如 `frontend_engineer` 对应 `frontend_implementation`，`qa_engineer` 对应 `qa_validation`。

### 9.3 功能指纹

候选模板不使用项目名称作为唯一依据，而是根据功能内容生成 SHA-256 指纹。指纹输入包括：

- 归一化任务标签。
- 规范化角色集合。
- 规范化能力集合。

排序后计算哈希并取前 16 位作为 fingerprint。项目名称、Agent ID、workspace、原始输出不参与指纹，因此同一功能的不同项目名称仍然可以归并。

### 9.4 候选 manifest

成功项目只提取可治理的结构化信息，不保存运行时敏感数据：

```json
{
  "normalizedIntent": {
    "tags": ["web_app", "mvp"],
    "capabilities": ["planning", "delegation", "frontend_implementation"]
  },
  "memberCount": 4,
  "roles": [
    {
      "roleId": "frontend_engineer",
      "role": "前端工程师",
      "skills": ["frontend_implementation"],
      "isLead": false
    }
  ],
  "outcome": "success",
  "fingerprint": "a1b2c3d4e5f60718",
  "promotionThreshold": 3
}
```

manifest 不包含：

- Gateway Agent ID。
- 项目 workspace 路径。
- session key。
- 原始对话和完整输出。
- 凭据、token 或其他项目数据。

### 9.5 状态机与晋级规则

候选的状态流转如下：

```text
成功项目
   |
   v
candidate（第一次证据）
   |
   | 相同 fingerprint 的成功项目累计达到 3 次
   v
validated（已验证，仍不自动生效）
   |
   | 管理员审核并发布
   v
active（可参与新项目匹配）
```

当前实现的关键安全点是：达到 3 次只会变成 `validated`，不会自动变成 `active`。管理员仍然需要通过模板 upsert/审核流程发布。

### 9.6 去重规则

去重分两个层次：

1. **同一项目幂等**：`team_template_runs` 以 `project_id + user_id` 唯一，重复事件不会重复计数。
2. **功能相似去重**：对新候选和已有模板计算功能相似度：

   ```text
   similarity = intentSimilarity * 0.35
               + capabilitySimilarity * 0.35
               + roleSimilarity * 0.20
               + workflowSimilarity * 0.10
   ```

   相同集合的 Jaccard 相似度为 1。总相似度达到 `0.85` 时，不创建新的功能模板，而是把这次成功记录归入已有功能配置。

模板名称不参与功能相似度计算，避免仅仅因为名称不同就产生重复模板。

## 10. 数据库变更

第一阶段在 `server/database.js` 中增加以下表。服务启动时自动创建，现有安装不需要手工迁移脚本。

### 10.1 `team_templates`

存储版本化模板定义。`template_id + version` 唯一；`template_key` 是实际主键。状态、scope 和更新时间建立了查询索引。

### 10.2 `wattclaw_project_template_matches`

存储项目创建时的匹配决策、分数、候选列表和模板快照。`project_id` 为主键，表示每个项目保留一份最新匹配。

### 10.3 `team_template_runs`

存储成功项目对候选模板的证据累计。记录 project、template、fingerprint、outcome 和脱敏后的 manifest；项目和用户组合唯一。

### 10.4 `agent_profiles`

存储跨项目可复用的 Agent 配置。通过 user/tenant、role、status 和 Gateway Agent ID 建立边界和检索条件。

### 10.5 `project_member_bindings`

存储项目 slot 到 Profile 和 runtime Agent 的绑定及租约。项目归档、删除或成功时会释放 binding。

## 11. 服务端 RPC

所有下面的本地 RPC 都由 Express 服务端处理，不要求 Gateway 在线；只有真正的 project build 仍然需要 Gateway。

### 11.1 团队模板 RPC

| RPC | 用途 |
| --- | --- |
| `wattclaw.team.template.list` | 列出当前可见模板；普通用户默认看到 active 模板，管理员可查看 inactive 模板 |
| `wattclaw.team.template.get` | 获取指定模板版本 |
| `wattclaw.team.template.match` | 输入任务名称/描述/提示词，返回归一化意图、候选、最佳模板和决策 |
| `wattclaw.team.template.upsert` | 保存或更新模板；普通用户只能保存自己的 candidate，管理员可管理 global/active |
| `wattclaw.team.template.project.get` | 获取项目的模板匹配记录和快照 |

### 11.2 Agent Profile RPC

| RPC | 用途 |
| --- | --- |
| `wattclaw.team.profile.list` | 同步并列出当前用户的 Profile |
| `wattclaw.team.profile.get` | 获取单个 Profile |
| `wattclaw.team.profile.find` | 按 roleId 和 capabilities 查找可租用 Profile |
| `wattclaw.team.profile.upsert` | 创建或更新 Profile，执行所有者校验 |
| `wattclaw.team.profile.bind` | 将 Profile 绑定到项目 slot，创建租约 |
| `wattclaw.team.profile.bindings` | 查看项目绑定 |
| `wattclaw.team.profile.release` | 释放一个绑定 |
| `wattclaw.team.profile.release_project` | 释放项目的全部绑定 |

模板 upsert 会执行所有者保护；普通用户不能把别人的 Profile 或模板改成自己的，也不能直接把模板设为全局 active。

## 12. 前端改动

### 12.1 类型

`src/api/types/wattclaw-team.ts` 增加了以下结构化类型：

- `WattClawTeamTemplate`
- `WattClawProjectTemplateMatch`
- `WattClawAgentProfile`
- `WattClawProjectMemberBinding`

### 12.2 RPC Client

`src/api/rpc-client.ts` 增加了模板和 Profile 的类型安全方法，覆盖 list、get、match、save、find、upsert、bind、bindings、release 等操作。页面和 Store 不需要直接调用 `/api/rpc`。

### 12.3 Collaboration Store

`src/stores/wattclaw-collaboration.ts` 在准备 Manager 消息时读取当前项目的 `draftSuggestion.templateMatch`，并把服务端已经确定的模板决策和 Profile 摘要注入内部消息。

协作页新增两个创建前控制按钮：

- “参考模板 / Manager 自主规划”：控制 `teamCreationMode`。关闭时服务端不执行模板匹配，Manager 收到明确的 autonomous planning 上下文。该按钮只在新项目创建前显示。
- “沉淀团队模板”：控制 `captureTeamTemplate`。关闭时成功项目仍然正常运行，但不会生成候选模板。该按钮只在新项目创建前显示。

当前阶段没有新增面向最终用户的模板编辑页面，避免在服务端契约尚未稳定前重复实现治理逻辑。后续 UI 可以直接复用现有 RPC 和类型。

## 13. Skill 改动

文件：`plugins/wattclaw-team/skills/wattclaw-team-project-builder/SKILL.md`

新增的协作约束重点是：

- `selected_team_template` 存在时，不得忽略模板的 slot、capability boundary 和 workflow。
- 匹配到的 reusable Agent Profile 是优先配置来源。
- Profile 只能复用配置，runtime Agent、session、workspace 必须属于当前项目。
- `fresh_plan` 才表示没有可用模板，需要完全重新规划。

这使模板复用不会绕过原有 Manager 的任务拆解和成员创建协议。

## 14. 安全、权限与兼容性

### 14.1 多租户和所有者隔离

- 所有模板和 Profile 查询都带当前用户上下文。
- global active 模板可被所有用户使用。
- 普通用户保存的模板会被强制设为 `scope=user`、`status=candidate`；在 `includeInactive=true` 的列表查询中，用户可以看到自己的 candidate。当前匹配函数只查询所有 active 模板，并没有按 `scope`、`user_id` 或 `tenant_id` 做过滤。
- 普通用户不能更新其他用户的实体，也不能把自己的实体直接发布为全局 active。

因此第一阶段当前的有效行为是：内置的 global active 模板进入所有项目的匹配池；普通用户创建的 candidate 不会自动参与匹配；如果管理员把某个 user 模板提升为 active，当前实现会把它放入全局 active 匹配池。`team_templates` 表目前没有 `tenant_id` 字段，项目匹配记录虽然保存了 `user_id` 和 `tenant_id`，但这两个字段目前主要用于审计和读取权限，不参与模板候选过滤。后续如果需要真正的租户/用户模板隔离，应让 match RPC 接收用户和租户上下文，并在 registry 查询中明确加入 scope 条件。
- Manager 上下文不会包含 Profile 的 workspace、metadata、user ID 等内部字段。

### 14.2 项目隔离

模板只描述角色、能力、技能、模型和流程；不携带项目文件和运行时上下文。每次项目仍通过原有 Gateway 流程创建独立 runtime Agent。

### 14.3 协议兼容

- 保留原有 `project.build` 参数和 Gateway 调用路径。
- 模板匹配和 Profile 同步失败时，会使用空匹配或 fresh plan 兜底，不阻断原有团队创建。
- `project.update` 写回属于 best effort，旧 Gateway 不支持时记录 warning。
- 本地模板/Profile RPC 在 Gateway 断开时仍可工作。

### 14.4 数据最小化

自动沉淀只写入结构化摘要和 fingerprint，不保存原始输出、凭据、session、Agent ID 或 workspace 路径，降低模板库成为跨项目数据泄漏面的风险。

## 15. 测试与验证结果

第一阶段新增了两组服务单元测试，并复用了项目运行时测试：

### 15.1 Team Template Service

覆盖：

- 中英文混合任务的意图归一化。
- Web 产品任务的自动模板选择。
- 未知任务返回 `fresh_plan`。
- 重复 slot ID 校验失败。
- 不同名称但相同功能的模板相似度为 1。
- 成功项目生成候选、重复事件幂等、manifest 不包含 Agent ID。

### 15.2 Agent Profile Service

覆盖：

- 按角色和能力查找 Profile。
- 并发容量达到上限时不再返回 Profile。
- binding 释放后恢复可用。
- 现有 user Agent 映射成 Profile。
- 测试事务回滚，避免污染共享 SQLite 数据。

### 15.3 命令结果

已执行并通过：

```bash
npm run build
npm run test:server
npx vitest run server/services/team-template-service.test.js server/services/agent-profile-service.test.js server/services/wattclaw-project-runtime.test.js
```

结果：

- `npm run build`：通过；仅有 Vite chunk size warning，没有 TypeScript 或构建错误。
- `npm run test:server`：35 个 Vitest 测试通过，另有 1 个 Node 测试通过。
- 定向三文件测试：16 个测试通过。

尚未在本阶段执行生产部署、Gateway 重启或真实用户数据迁移。

## 16. 代码变更清单

本阶段相关变更如下：

### 新增

- `server/services/team-template-service.js`
- `server/services/team-template-service.test.js`
- `server/services/agent-profile-service.js`
- `server/services/agent-profile-service.test.js`
- `docs/team-template-agent-reuse-phase-1.md`（本文档）

### 修改

- `server/database.js`：增加五张模板/Profile/绑定相关表。
- `server/index.js`：注册本地 RPC、接入 project build、项目完成/归档/删除后的沉淀与释放。
- `src/api/rpc-client.ts`：增加类型安全 RPC 方法。
- `src/api/types/wattclaw-team.ts`：增加模板、匹配、Profile、binding 类型。
- `src/stores/wattclaw-collaboration.ts`：将模板匹配结果和 Profile 摘要注入 Manager 内部消息。
- `plugins/wattclaw-team/skills/wattclaw-team-project-builder/SKILL.md`：增加模板权威性、Profile 复用和项目隔离规则。
- `plugins/wattclaw-team/skills/wattclaw-team-project-builder/scripts/create_team.py`：更新项目草稿时保留服务端写入的 `collaborationSettings`，避免 Manager 的团队规划草稿覆盖项目创建模式。

## 17. 端到端示例

假设用户创建任务：

```text
“做一个带登录、数据看板和基础测试的 Web MVP”
```

实际流程如下：

1. 服务端识别出 `web_app`、`mvp`、`analytics` 等标签。
2. `web-product-delivery@1.0.0` 满足 `intent.required`，并在 `intent.preferred`、能力和交付物上得到高分。
3. 决策为 `auto_apply`。
4. `frontend` slot 找到一个已有的 `frontend_engineer` Profile；该 Profile 当前没有有效租约。
5. Manager 收到模板槽位、工作流和 Profile 摘要。
6. Gateway 为当前项目创建新的 frontend runtime Agent，使用项目独立 workspace；Profile 的基础 workspace 不会被直接挂载。
7. 项目成功完成后，服务端记录一次 `web_app + frontend_engineer + qa_engineer ...` 的成功证据。
8. 如果这类功能此前没有模板，生成 `candidate-<fingerprint>@0.1.0`；重复项目只增加 evidence count。
9. 达到 3 次成功后候选状态改为 `validated`；管理员审核后再 upsert 为 active。
10. 以后同类任务直接匹配 active 模板，减少从零规划时间。

## 18. 当前限制与注意事项

1. **Profile 复用还不是 live Agent 复用**：当前复用配置，不复用运行时身份和 workspace。这是有意的安全边界，不是遗漏。
2. **模板匹配是规则型算法**：当前使用关键词归一化、集合覆盖率和固定权重，不是向量检索或大模型评审。复杂任务可能需要人工选择或 fresh plan。
3. **validated 不等于 active**：达到证据阈值后仍需管理员审核，防止低质量配置自动污染模板库。
4. **模板治理 UI 尚未提供**：可以先通过 RPC 或服务端管理流程操作；第二阶段应补充审核、版本比较、回滚和禁用页面。
5. **Manager 上下文依赖当前入口**：管理面板创建流程会注入匹配上下文；如果未来存在绕过该入口、直接向 Manager 发起构建的入口，需要复用同一套服务端匹配逻辑。
6. **插件运行时需要按部署方式更新**：Skill 源文件已更新，但生产 Gateway 是否立即加载新 Skill 取决于插件安装/打包流程；部署时应重新安装或刷新插件并重启相关服务。
7. **历史数据是渐进同步的**：已有 user Agent 在调用 Profile list/find 时按需投影，不会在数据库初始化时一次性复制全部历史 Agent。

## 19. 第二阶段建议

第一阶段已经形成可运行的闭环，后续建议按以下优先级演进：

### 19.1 模板治理界面

- 候选/validated/active/archived 状态筛选。
- 模板版本 diff、审核记录和回滚。
- 显示成功次数、最近使用时间、失败率和人工评价。
- 支持管理员把 validated 模板发布为 active。

### 19.2 更强的匹配能力

- 将规则匹配和 embedding 检索组合，提升自然语言表达差异下的召回率。
- 对高分但存在冲突的模板增加人工确认。
- 支持多个模板组合，而不是只选择一个最佳模板。
- 增加模板适用范围、成本、时延和模型约束。

### 19.3 Profile 生命周期

- Profile 健康度、成功率、平均耗时和最近失败记录。
- 根据项目结果自动调整 Profile 的能力置信度。
- 更细的并发策略、队列和租约续期。
- Profile 与 runtime Agent 的可控 warm start，但仍保持 workspace/session 隔离。

### 19.4 自动沉淀治理

- 将“3 次成功”扩展成按任务复杂度、用户评价和失败率加权的证据模型。
- 对功能相似但质量不同的模板保留版本关系，而不是简单合并。
- 增加模板冲突检测，例如相同任务标签却存在互斥模型、成本或交付边界。

### 19.5 可观测性

- 记录模板命中率、auto_apply/recommend/fresh_plan 比例。
- 记录 Profile 复用率、租约冲突率和释放延迟。
- 记录模板应用后项目成功率，用于决定模板是否继续 active。

## 20. 验收清单

- [x] 模板具有稳定 ID、版本、scope、状态和定义快照。
- [x] 项目创建前可归一化任务意图并返回候选模板。
- [x] 高分模板可作为 Manager 内部上下文。
- [x] 现有非项目 Agent 可按需映射成 Profile。
- [x] Profile 支持角色/能力查找、租约、容量和释放。
- [x] 项目 runtime Agent 仍使用独立 workspace/session。
- [x] 成功项目可以生成候选模板。
- [x] 同一项目重复事件幂等。
- [x] 功能相似团队按 fingerprint 和相似度去重。
- [x] 候选达到证据阈值后只变为 validated，不自动 active。
- [x] 模板、Profile 和匹配记录有权限边界。
- [x] 构建和相关自动化测试通过。
