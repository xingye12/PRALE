# HTTP+WS 分离分支验证清单

> 分支: `test/http-ws-separation`
> 验证环境: Docker `wattclaw-test` 容器

---

## 1. Gateway 通信迁移（WS → HTTP）

### 1.1 后端 HTTP RPC
- [ ] **系统监控页** `/api/system/metrics` — CPU/内存/在线状态正常显示
- [ ] **Gateway 状态** `/api/status` — 连接状态显示正常
- [ ] **配置读取** `config.get` — 模型管理页配置正常加载
- [ ] **Cron 列表** `cron.list` — 定时任务页正常显示
- [ ] **模型列表** `models.list` — 模型下拉框正常加载
- [ ] **技能状态** `skills.status` — 技能商店正常加载

### 1.2 前端 RPCClient HTTP 化
- [ ] **创建数字员工** — `agents.create` 通过 HTTP 成功创建
- [ ] **编辑数字员工** — `agents.update` 保存成功
- [ ] **删除数字员工** — `agents.delete` 删除成功
- [ ] **配置修改** — `config.patch/set/apply` 正常保存
- [ ] **节点配对审批** — `node.pair.approve` 正常工作

### 1.3 认证 Token
- [ ] **非 admin 用户登录** — 能正常使用，无 401
- [ ] **刷新页面** — Token 正确传递，无 Unauthorized 报错

---

## 2. 轮询缓存移除（按需拉取）

- [ ] **Cron 页面刷新** — 点击刷新按钮，数据立即更新（不再返回旧缓存）
- [ ] **模型管理页刷新** — 新增模型后刷新可见
- [ ] **配置修改后** — 修改后其他页面立即可见最新配置

---

## 3. 性能优化

### 3.1 sessions.list N+1 修复
- [ ] **在线对话页面** — 页面加载时间 < 3s（之前 30s+）
- [ ] **后端日志** — 只看到 1 次 `sessions.list` WS RPC 调用（之前 188 次）

### 3.2 文件管理批量接口
- [ ] **文件管理页面** — 页面加载时间 < 2s（之前 N+1 请求）
- [ ] **后端日志** — 只有 1 次 `batch-list` HTTP 请求
- [ ] **文件浏览** — 点击子目录能正常展开
- [ ] **文件上传** — 正常工作

---

## 4. SSH 清理

- [ ] **文件上传** — 上传文件到 Agent workspace 正常
- [ ] **文件删除** — 删除 Agent 文件正常
- [ ] **技能商店扫描** — `/api/skill-store/scan` 不再报 `exit code 1`
- [ ] **Docker 日志** — 无 `ssh2` 相关错误

---

## 5. 中文计时日志

- [ ] **后端日志** — 能看到 `[Gateway] HTTP POST 调用: /api/v1/admin/rpc (xxx)` 格式日志
- [ ] **后端日志** — WS RPC 调用也有中文格式日志
- [ ] **敏感参数** — apiKey/password/token 等字段显示为 `***`

---

## 6. 多用户权限

- [ ] **Admin 登录** — 所有功能正常
- [ ] **普通用户登录** — 只能看到自己的会话/Agent
- [ ] **普通用户创建 Agent** — 正常创建，无 401/403
- [ ] **普通用户查看模型** — 正常显示
- [ ] **登出后重新登录** — 数据正确，无跨账户泄漏

---

## 7. 聊天核心功能

- [ ] **发送消息** — `chat.send` 正常工作，流式回复正常
- [ ] **取消回复** — `chat.abort` 正常中断
- [ ] **历史记录加载** — 消息历史正常显示
- [ ] **多轮对话** — 上下文连贯
- [ ] **工具调用** — Agent 调用工具正常

---

## 8. 部署验证

- [ ] **`./deploy-test.sh`** — 一键部署成功
- [ ] **Docker 网络** — 只有 `wattclaw-net`，无多余网络
- [ ] **健康检查** — `http://服务器IP:3002/api/health` 返回 200
- [ ] **容器日志** — `docker logs wattclaw-test` 无致命错误
