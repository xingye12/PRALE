# WattClaw Agent 轨迹可视化功能 — 技术实现详解

> **分析日期**：2026-07-30
> **分析范围**：Gateway 插件 (wattclaw-prompt-capture) → SQLite → Gateway RPC → 后端透传 → 前端 RPC Client → Pinia Store → Vue3 Gantt 组件
> **核心设计**：Turn-centric 模型。一个 turn（runId）代表一次完整的 Agent 运行（用户消息 → 最终回复），包含有序的 modelCalls[] 和 toolCalls[]，每条记录带有绝对时间戳，用于甘特图 (Gantt) 可视化。

---

## 目录

1. [架构总览](#1-架构总览)
2. [数据模型](#2-数据模型)
3. [Gateway 插件：数据采集层](#3-gateway-插件数据采集层)
4. [消息重建算法](#4-消息重建算法)
5. [RPC 通信链路](#5-rpc-通信链路)
6. [前端：runId 持久化](#6-前端runid-持久化)
7. [前端：甘特图可视化](#7-前端甘特图可视化)
8. [完整调用链](#8-完整调用链)
9. [关键文件索引](#9-关键文件索引)

---

## 1. 架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                    Gateway 容器 (OpenClaw)                        │
│                                                                  │
│  Agent 运行时生命周期事件:                                         │
│    llm_input → model_call_started → llm_output                   │
│    → before_tool_call → after_tool_call → agent_end              │
│         │                                                        │
│         ▼                                                        │
│  plugins/wattclaw-prompt-capture-plugin/                         │
│    ├─ index.js    ← 注册 7 个事件钩子 + 3 个 Gateway RPC          │
│    ├─ hooks.js    ← 事件→存储的桥接层 (activeRuns Map)            │
│    ├─ storage.js  ← TraceStorage: SQLite 持久化 (turns 表)       │
│    ├─ trace-reconstruction.js ← 从 messages[] 重建 modelCalls     │
│    └─ native-trace.js ← 读取 Gateway 原生 .trajectory.jsonl      │
│         │                                                        │
│         ▼                                                        │
│  SQLite: ~/.openclaw/state/wattclaw-traces.db                    │
│    └─ turns 表 (run_id PK, model_calls/tool_calls JSON)          │
│                                                                  │
│  Gateway RPC (插件注册):                                          │
│    wattclawTrace.get   ← 单 turn 查询 + 自动修复                  │
│    wattclawTrace.list  ← 列表查询 (支持 sessionKey 过滤)          │
│    wattclawTrace.stats ← 聚合统计                                 │
└──────────────────────────┬──────────────────────────────────────┘
                           │ WebSocket RPC (Gateway WS)
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    后端 (Node.js/Express)                         │
│                                                                  │
│  server/index.js: /api/rpc handler                               │
│    wattclawTrace.* 无特殊处理 → 直接 gateway.call() 透传          │
│    （不匹配任何 isWattClawProject* / isAdmin 特殊路径）            │
└──────────────────────────┬──────────────────────────────────────┘
                           │ HTTP /api/rpc
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    前端 (Vue3 + TypeScript)                       │
│                                                                  │
│  src/api/rpc-client.ts                                           │
│    ├─ getAgentTrace(runId)       ← wattclawTrace.get             │
│    ├─ listAgentTraces({...})     ← wattclawTrace.list            │
│    ├─ normalizeAgentTurn()       ← 防御性字段规范化               │
│    ├─ normalizeModelCall()                                       │
│    └─ normalizeToolCall()                                        │
│                                                                  │
│  src/stores/workspace.ts                                         │
│    └─ enrichRunIds(sessionKey)  ← 刷新后回填 runId               │
│                                                                  │
│  src/views/workspace/components/                                 │
│    ├─ MessageActions.vue        ← timeline 按钮 (条件渲染)        │
│    └─ AgentTrajectoryDrawer.vue ← 甘特图 + 详情面板 (1013行)     │
└─────────────────────────────────────────────────────────────────┘
```

**关键设计决策**：
- 插件在 Gateway 内部运行，直接监听 Agent 生命周期事件，数据采集零延迟
- 存储使用 Gateway 本地的 SQLite（WAL 模式），不依赖 WattClaw 后端数据库
- 后端对 `wattclawTrace.*` 调用**完全透传**，不做任何权限校验或数据转换
- 前端通过 `enrichRunIds()` 解决页面刷新后 runId 丢失的问题（Gateway history API 不返回 runId）

---

## 2. 数据模型

### 2.1 SQLite 表结构

插件在 Gateway 容器内维护独立的 SQLite 数据库（默认路径 `~/.openclaw/state/wattclaw-traces.db`）：

```sql
CREATE TABLE IF NOT EXISTS turns (
  run_id TEXT PRIMARY KEY,          -- Agent 运行的唯一标识
  session_key TEXT NOT NULL,        -- 会话 Key (agent:{id}:main)
  agent_id TEXT,                    -- Agent ID
  started_at TEXT NOT NULL,         -- 开始时间 (ISO 8601)
  ended_at TEXT,                    -- 结束时间
  user_prompt TEXT,                 -- 用户输入
  assistant_output TEXT,            -- Agent 最终输出 (所有 assistant 回复拼接)
  model_calls TEXT,                 -- JSON 数组: ModelCallEntry[]
  tool_calls TEXT,                  -- JSON 数组: ToolCallEntry[]
  token_input INTEGER,              -- 聚合输入 token
  token_output INTEGER,             -- 聚合输出 token
  token_cache INTEGER,              -- 缓存命中 token
  duration_ms INTEGER,              -- 总耗时 (毫秒)
  status TEXT DEFAULT 'running',    -- running | completed | failed
  created_at INTEGER DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_key);
CREATE INDEX IF NOT EXISTS idx_turns_created ON turns(created_at);
```

配置参数（可在 `openclaw.plugin.json` 中配置）：
| 参数 | 默认值 | 说明 |
|------|--------|------|
| `dbPath` | `~/.openclaw/state/wattclaw-traces.db` | 数据库路径 |
| `maxPromptLength` | 1,000,000 | prompt 最大存储长度 |
| `maxHistoryMessages` | 200 | history 最大消息数 |
| `retentionDays` | 30 | 数据保留天数（启动时清理过期记录） |

### 2.2 TypeScript 类型定义

定义在 `src/api/types/agent-trace.ts`：

```typescript
interface ModelCallEntry {
  index: number                        // 在 turn 内的序号
  callId: string | null                // Gateway callId (去重用)
  startedAt: string                    // ISO 8601 开始时间
  endedAt: string | null               // ISO 8601 结束时间
  durationMs: number | null            // 耗时
  model: string | null                 // 模型名称
  provider: string | null              // 厂商
  systemPrompt: string | null          // 系统提示词
  prompt: string | null                // 当前输入
  historyMessages: Array<{ role: string; content: string | unknown }>
  toolCount: number | null             // 可用工具数
  output: string | null                // 模型输出
  tokenInput: number | null
  tokenOutput: number | null
  tokenCache: number | null
  finishReason: string | null          // stop | length | tool_calls | error | ...
  requestId: string | null
  apiType: string | null               // anthropic | openai | ...
  status: 'running' | 'completed' | 'failed'
}

interface ToolCallEntry {
  index: number
  toolName: string
  startedAt: string
  endedAt: string | null
  durationMs: number | null
  params: unknown
  result: unknown
  error: string | null
  status: 'running' | 'completed' | 'failed'
}

interface AgentTurnTrace {
  runId: string
  sessionKey: string
  agentId: string | null
  startedAt: string
  endedAt: string | null
  userPrompt: string | null
  assistantOutput: string | null
  modelCalls: ModelCallEntry[]
  toolCalls: ToolCallEntry[]
  tokenUsage: { input: number | null; output: number | null; cache: number | null }
  durationMs: number | null
  status: 'running' | 'completed' | 'failed'
  createdAt: number
}
```

### 2.3 ChatMessage 扩展

`ChatMessage` 接口（`src/api/types/index.ts`）有一个可选字段 `runId?: string`，用于将前端消息与轨迹 turn 关联。

---

## 3. Gateway 插件：数据采集层

### 3.1 插件注册

`plugins/wattclaw-prompt-capture-plugin/index.js` — 插件入口：

```javascript
export default definePluginEntry({
  id: "wattclaw-prompt-capture",
  name: "WattClaw Prompt Capture",

  register(api) {
    const config = api.config?.["wattclaw-prompt-capture"] ?? {}
    const {
      llmInputHook, modelCallStartedHook, modelCallEndedHook,
      llmOutputHook, agentEndHook,
      beforeToolCallHook, afterToolCallHook,
      storage,
    } = createHooks(api, config)

    // 注册 7 个事件钩子
    api.on("llm_input", llmInputHook)
    api.on("model_call_started", modelCallStartedHook)
    api.on("model_call_ended", modelCallEndedHook)
    api.on("llm_output", llmOutputHook)
    api.on("agent_end", agentEndHook)
    api.on("before_tool_call", beforeToolCallHook)
    api.on("after_tool_call", afterToolCallHook)

    // 注册 3 个 Gateway RPC
    api.registerGatewayMethod("wattclawTrace.get", handler)
    api.registerGatewayMethod("wattclawTrace.list", handler)
    api.registerGatewayMethod("wattclawTrace.stats", handler)
  }
})
```

**注意**：插件需要 `allowConversationAccess: true`（在 `openclaw.plugin.json` 中声明），因为 `llm_input` 和 `llm_output` 钩子属于会话访问级别。

### 3.2 事件钩子详解

`plugins/wattclaw-prompt-capture-plugin/hooks.js` — 7 个钩子的生命周期：

```
时间线:

  llm_input          ← 模型调用即将开始
    │
    ├─ storage.ensureTurn()      ← 首次创建 turn 行 (INSERT)
    └─ state.input = {...}       ← 缓存 model/provider/prompt 信息
    │
  model_call_started  ← 每次模型调用开始 (tool loop 中会多次触发)
    │
    └─ storage.startModelCall()  ← APPEND model_calls JSON 数组
         callId 去重：相同 callId 不重复追加
    │
  model_call_ended    ← 模型调用完成 (含 telemetry 数据)
    │
    └─ storage.finishModelCallTelemetry()
         按 callId 匹配 → 回退到最后一个 running → 新建条目
         更新 endedAt, durationMs, outcome, requestId
    │
  [tool loop 循环:]
    before_tool_call   ← 工具调用开始
      └─ storage.startToolCall()  ← APPEND tool_calls JSON 数组
           返回 index → 压入 state.toolStack[toolCallId ?? toolName]
    after_tool_call    ← 工具调用结束
      └─ 从 stack 弹出 index → storage.finishToolCall()
    │
  llm_output          ← 模型输出完成
    │
    └─ storage.recordLlmOutput()
         更新 assistant_output, tokenUsage, durationMs, status='completed'
    │
  agent_end           ← Agent 运行结束 (CRITICAL: 消息重建)
    │
    └─ storage.reconcileTurnFromMessages()
         使用 event.messages[] 重建 modelCalls
         将 tool loop 中的 N 次 assistant 回复拆分为 N 个 modelCall
         清理 activeRuns Map
```

**activeRuns Map**：内存中的 `Map<string, RunState>`，key 为 `runId`。每个 `RunState` 包含：
- `input`: 缓存的 `{ model, provider, systemPrompt, prompt, historyMessages, toolCount }`
- `toolStack`: `Map<string, number[]>` — 按 `toolCallId ?? toolName` 索引的 index 栈（支持同名工具并发调用）

### 3.3 TraceStorage 核心操作

`plugins/wattclaw-prompt-capture-plugin/storage.js` — `TraceStorage` 类：

| 方法 | 触发事件 | 操作 |
|------|---------|------|
| `ensureTurn()` | `llm_input` | `INSERT INTO turns`（已存在则跳过） |
| `startModelCall()` | `model_call_started` | 读取 model_calls JSON → append → UPDATE。callId 去重 |
| `finishModelCallTelemetry()` | `model_call_ended` | 按 callId→最后 running→新建 三级回退匹配，更新 timing |
| `recordLlmOutput()` | `llm_output` | 写入 assistant_output、tokenUsage、durationMs |
| `reconcileTurnFromMessages()` | `agent_end` | **核心**：DELETE+REWRITE model_calls，拆分 tool loop |
| `startToolCall()` | `before_tool_call` | APPEND tool_calls JSON |
| `finishToolCall()` | `after_tool_call` | 按 toolCallId→index→最后 running 三级回退，写入 result/error |
| `failTurn()` | (错误处理) | 设置 status='failed' |
| `getTurn()` | RPC `.get` | 单行查询 + 解析 |
| `listTurns()` | RPC `.list` | 支持 `sessionKey` 过滤，ASC 排序，limit 1-200 |
| `_cleanupOld()` | 启动时 | DELETE WHERE created_at < cutoff (默认 30 天) |

**Tool Call 的栈匹配机制**：同一工具可能在一个 turn 中被多次并发调用（同名），因此 hooks.js 使用栈来正确配对 `before`/`after` 事件：
- `before`: 按 `toolCallId ?? toolName` 作为 key，将 index 压栈
- `after`: 从对应 key 的栈中弹出 index，传入 `finishToolCall`

### 3.4 Native Trace 修复机制

`plugins/wattclaw-prompt-capture-plugin/native-trace.js`:

当 `wattclawTrace.get` 被调用时，如果检测到 turn 的 modelCalls 需要修复（条件见下节），插件会尝试从 Gateway 原生的 `.trajectory.jsonl` 文件中恢复完整消息数组：

```
扫描: ~/.openclaw/agents/{agentId}/sessions/*.trajectory.jsonl
      (按 mtime 降序排列，逐个读取直到找到目标 runId)

查找: 包含目标 runId 的 model.completed 事件行
返回: { messages (Snapshot), endedAt, provider, model, apiType }
```

这个机制解决了某些边界情况下 hook 采集数据不完整的问题（如 plugin 晚于 Agent 启动、异常重启等）。

### 3.5 数据配置限制

`TraceStorage` 构造函数中的三个关键配置：

```javascript
this.maxPromptLength = config.maxPromptLength ?? 1_000_000    // prompt 截断长度
this.maxHistoryMessages = config.maxHistoryMessages ?? 200      // history 消息数截断
this.retentionDays = config.retentionDays ?? 30                 // 自动清理阈值
```

每次存储 prompt/output/history 时都会应用截断，防止单条记录过大导致 SQLite 性能问题。

---

## 4. 消息重建算法

### 4.1 问题

Agent 在执行 tool loop 时会经历多轮"模型调用→工具执行→模型调用"的循环。但插件的 `llm_input`/`llm_output` 钩子在每个循环迭代中都会被触发，hook 层只能知道"当前这次"调用的信息。真正完整的消息数组（包含所有 assistant 回复、tool 结果等）只在 `agent_end` 事件的 `event.messages` 中可用。

### 4.2 算法核心

`plugins/wattclaw-prompt-capture-plugin/trace-reconstruction.js`:

```
reconstructModelCalls({ messages, existingCalls, toolCalls, ... })
  │
  ├─ 1. 找到最后一条 user 消息的索引 (latestUserIndex)
  │      只处理当前 turn 的消息（最后一条 user 之后的所有 assistant）
  │
  ├─ 2. 对每个 assistant 消息构建一个 projection:
  │      ├─ startedAt   ← message.timestamp ?? existing.startedAt ?? turnStartedAt
  │      ├─ endedAt     ← 下一组 toolCall 的开始时间 ?? turnEndedAt
  │      ├─ prompt      ← 前一条消息的文本 (toolResult 或 user 消息)
  │      ├─ historyMessages ← assistant 索引之前的所有消息
  │      ├─ output      ← messageText(assistant) (提取 text block 拼接)
  │      ├─ token*      ← message.usage 对象 (支持多种字段名别名)
  │      └─ finishReason ← message.stopReason ?? message.finishReason
  │
  ├─ 3. 合并 projection 与 existingCalls:
  │      有 telemetry (callId 存在): projection 提供内容, existing 保留 timing
  │      无 telemetry: projection 数据直接使用
  │      failed 的 existing 条目保留不覆盖
  │
  └─ 4. 返回重新编号的 modelCalls[]
```

### 4.3 修复判断

`needsModelCallReconstruction(messages, modelCalls)` 返回 true 当：
1. `messages` 中的 assistant 消息数 ≠ modelCalls 中的 completed 条目数（拆分不足），或
2. 存在 completed 的 modelCall 缺少 `finishReason`（数据不完整）

此检查在 `wattclawTrace.get` RPC 处理中被调用，确保每次查询返回的数据都是经过修复的最新版本。

### 4.4 Token 字段别名

重建时从 message.usage 解析 token，支持多种命名约定：

| 语义 | 支持的字段名 |
|------|------------|
| 输入 token | `input`, `inputTokens`, `promptTokens` |
| 输出 token | `output`, `outputTokens`, `completionTokens` |
| 缓存 token | `cacheRead`, `cache`, `cachedTokens` |

### 4.5 时间戳估算

当 message 本身没有 timestamp 时，通过下一条 toolCall 的开始时间来估算此 assistant 回复的结束时间：

```javascript
function fallbackEndTime(toolCalls, toolCursor, toolCallCount, turnEndedAt) {
  if (toolCallCount > 0) {
    const startedAt = toolCalls
      .slice(toolCursor, toolCursor + toolCallCount)
      .map(call => call?.startedAt)
      .filter(valid)
      .sort()[0]
    if (startedAt) return startedAt
  }
  return turnEndedAt
}
```

---

## 5. RPC 通信链路

### 5.1 完整的 RPC 路径

```
前端 rpc-client.ts
  → HTTP POST /api/rpc { method: "wattclawTrace.get", params: { runId } }
    → server/index.js: /api/rpc handler
      → callGatewayWithWattClawRuntime()
        → 所有 isWattClawProject* 检查均为 false
        → 所有 isAdmin 特殊路径均不匹配
        → gateway.call(method, forwardedParams)  ← 直接 WS 透传
          → Gateway WebSocket
            → wattclaw-prompt-capture 插件
              → api.registerGatewayMethod("wattclawTrace.get", handler)
                → storage.getTurn(runId)
                → findNativeRunCompletion() + reconcileTurnFromMessages() (按需修复)
                → ctx.respond(true, { turn })
```

**关键点**：后端对 `wattclawTrace.*` 调用完全透传。因为数据存储在 Gateway 本地 SQLite（`~/.openclaw/state/wattclaw-traces.db`），不经过 WattClaw 后端数据库。

### 5.2 三个 RPC 方法

#### `wattclawTrace.get`

```javascript
api.registerGatewayMethod("wattclawTrace.get", async (ctx) => {
  const runId = ctx.params?.runId
  // 1. 查询 turn
  let turn = storage.getTurn(runId)

  // 2. 自动修复 (native trace repair)
  const completion = findNativeRunCompletion({ runId, agentId: turn.agentId, agentsDir })
  if (completion && needsModelCallReconstruction(completion.messages, turn.modelCalls)) {
    storage.reconcileTurnFromMessages({ runId, messages: completion.messages, ... })
    turn = storage.getTurn(runId)  // 重新读取修复后的数据
  }

  ctx.respond(true, { turn })
})
```

#### `wattclawTrace.list`

```javascript
api.registerGatewayMethod("wattclawTrace.list", async (ctx) => {
  const limit = Math.min(Math.max(parseInt(ctx.params?.limit ?? "50"), 1), 200)
  const sessionKey = ctx.params?.sessionKey ?? null
  const turns = storage.listTurns({ limit, sessionKey })
  ctx.respond(true, { turns, count: turns.length })
})
```

#### `wattclawTrace.stats`

```javascript
api.registerGatewayMethod("wattclawTrace.stats", async (ctx) => {
  const sessionKey = ctx.params?.sessionKey ?? null
  const turns = storage.listTurns({ limit: 10000, sessionKey })
  const stats = {
    totalTurns, completedTurns, failedTurns,
    avgDurationMs, totalModelCalls, totalToolCalls,
  }
  ctx.respond(true, { stats })
})
```

### 5.3 前端 RPC Client 规范化

`src/api/rpc-client.ts` 中每个响应都经过防御性规范化：

- `normalizeAgentTurn(value)`: 验证 runId 存在，递归规范化 modelCalls/toolCalls 数组，解析 tokenUsage
- `normalizeModelCall(value, fallbackIndex)`: 校验每个字段类型，回退到默认值
- `normalizeToolCall(value, fallbackIndex)`: 同上，支持旧版 `t.at` 字段别名

Gateway 响应形状可能变化，规范化层确保前端始终获得类型安全的数据。

---

## 6. 前端：runId 持久化

### 6.1 问题

Gateway 的 history API 返回的消息中**没有 runId 字段**（`responseId` 和 `__openclaw.id` 与 runId 无关）。页面刷新后，所有 assistant 消息的 `runId` 丢失，轨迹按钮无法显示。

### 6.2 解决方案：`enrichRunIds()`

`src/stores/workspace.ts` 中的 `enrichRunIds(sessionKey)` 函数（第 586-661 行）：

```typescript
async function enrichRunIds(sessionKey: string) {
  // 1. 找到缺少 runId 的 assistant 消息
  const msgs = getSessionMessages(sessionKey)
  const assistants = msgs.filter(m => m.role === 'assistant')
  if (!assistants.length || assistants.every(m => m.runId)) return

  // 2. 获取该 session 的所有 turns (按创建时间 ASC)
  const turns = await wsStore.rpc.listAgentTraces({ sessionKey, limit: 200 })
  if (!turns.length) return

  // 3. 对每条缺少 runId 的消息，通过最长公共前缀匹配
  const norm = (s) => (s || '').replace(/\s+/g, ' ').trim()
  const commonPrefix = (a, b) => { /* ... */ }

  const PREFIX_CAP = 120   // 长回复只匹配开头
  const MIN_ABS = 12       // 最小匹配长度，防止通用开头误匹配

  const findByContent = (content: string): string | null => {
    const c = norm(content)
    let best = null
    for (const t of turnInfo) {
      const cp = commonPrefix(c, t.out)
      const need = Math.min(c.length, t.out.length, PREFIX_CAP)
      if (cp < need || cp < MIN_ABS) continue
      if (!best || cp > best.score) best = { runId: t.runId, score: cp }
    }
    return best?.runId ?? null
  }

  // 4. 更新消息
  const next = current.map(m => {
    if (m.role !== 'assistant' || m.runId) return m
    const runId = findByContent(m.content)
    return runId ? { ...m, runId } : m
  })
  if (changed) setSessionMessages(sessionKey, next)
}
```

**匹配策略**：
- 使用**最长公共前缀**匹配（而非子串包含），因为长回复的尾部可能因截断/格式差异不同，但开头稳定且唯一
- PREFIX_CAP=120：长回复只需开头 120 字符匹配即可（因为开头通常是独特的回复内容）
- MIN_ABS=12：短回复必须几乎完全匹配（防止"好的"、"明白了"等通用开头跨 turn 误匹配）
- 无法确定匹配的消息**保持无 runId**（宁可少显示轨迹按钮，也不错配错误轨迹）

### 6.3 触发时机

在 `loadHistory()` 中，非 cursor 模式加载完历史消息后：

```typescript
// fire-and-forget: trajectory is a best-effort enhancement
enrichRunIds(sessionKey)
```

非阻塞异步执行，失败时静默忽略（try/catch 包裹，注释"trajectory is a best-effort enhancement"）。

---

## 7. 前端：甘特图可视化

### 7.1 入口：MessageActions.vue

每条消息下方的操作按钮栏。轨迹按钮的条件渲染：

```html
<NTooltip v-if="role === 'assistant' && runId" trigger="hover">
  <NButton quaternary circle size="tiny" @click="trajectoryVisible = true">
    <span class="material-symbols-outlined">timeline</span>
  </NButton>
  {{ t('pages.workspace.chat.trajectory') }}  <!-- "查看运行轨迹" -->
</NTooltip>

<AgentTrajectoryDrawer
  v-model:visible="trajectoryVisible"
  :run-id="runId || null"
  :session-key="sessionKey || null"
/>
```

- 仅对 **assistant 角色** 且 **存在 runId** 的消息显示
- 点击打开 1280px 宽模态抽屉

### 7.2 主组件：AgentTrajectoryDrawer.vue

`src/views/workspace/components/AgentTrajectoryDrawer.vue`（1013 行）

#### 生命周期

```
props.visible + props.runId 变化
  → watch immediate: rpc.getAgentTrace(runId)
    → turn.value = result
    → autoSelectLast() → 选中最后一个 modelCall
```

#### 布局结构

```
┌──────────────────────────────────────────────────────────────┐
│  Agent 运行轨迹           traceId: run_abc123...             │
├──────────────────────────────────────────────────────────────┤
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌───────┐  │
│  │ 任务耗时 │ │ 模型调用 │ │ 工具调用 │ │Token消耗 │ │缓存命中│  │
│  │  12.3s  │ │    3    │ │    5    │ │ 8.2K    │ │  45%  │  │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └───────┘  │
├────────────────────────────┬─────────────────────────────────┤
│  甘特图 (Gantt)             │  详情面板 (460px)                │
│                             │                                 │
│  📋 用户任务执行  ████████  │  ┌─────────────────────────┐   │
│  🤖 Agent 运行    ████████  │  │ 第3次大模型调用  ✓ 已完成│   │
│  ⊞ 大模型调用循环 ████████  │  ├─────────────────────────┤   │
│    ● 第1次大模型调用 ████   │  │ 耗时      │ 2.3s         │   │
│    ● 第2次大模型调用  ██    │  │ Token     │ 1.2K / 856   │   │
│    ● 工具调用: read  █      │  │ 开始时间   │ 2026-07-30  │   │
│    ● 第3次大模型调用  ████  │  │ 模型      │ deepseek-v4  │   │
│                             │  │ ...                       │   │
│                             │  ├─────────────────────────┤   │
│                             │  │ ▶ 系统提示词             │   │
│                             │  │ ▼ 当前输入               │   │
│                             │  │   [prompt 内容...]       │   │
│                             │  │ ▼ 模型输出               │   │
│                             │  │   [output 内容...]       │   │
│                             │  └─────────────────────────┘   │
└────────────────────────────┴─────────────────────────────────┘
```

#### 统计卡片行（5 个指标）

| 指标 | 数据来源 | 说明 |
|------|---------|------|
| 任务耗时 | `turn.durationMs` | 格式化为 ms/s/min |
| 模型调用次数 | `turn.modelCalls.length` | completed / total |
| 工具调用次数 | `turn.toolCalls.length` | completed / total |
| Token 消耗 | `turn.tokenUsage` | `input + output`，≥1000 显示为 K |
| 缓存命中率 | `tokenUsage.cache / tokenUsage.input * 100` | 缓存命中 token 占输入的百分比 |

#### 甘特图树（左列）

四层缩进结构（`tree-indent`: L0=0, L1=18px, L2=36px, L3=54px）：

```
L0  📋 用户任务执行        [████████████████████████]  ← 全宽 bar-root
L1    🤖 Agent 运行        [████████████████████████]  ← 全宽 bar-branch
L2      ⊞ 大模型调用循环    [████████████████████████]  ← 全宽 bar-branch
L3        ● 第1次大模型调用  [████████]  1.2K/856       ← 绿色 bar-model
L3        ● 工具调用: read   [██]                      ← 蓝色 bar-tool
L3        ● 第2次大模型调用  [████████]  856/423        ← 绿色 bar-model
```

**时间窗口计算**（`timeWindow` computed）：
- 遍历所有 modelCalls 和 toolCalls 的 `startedAt` / `endedAt`
- 取 min start 和 max end 作为窗口
- 单条 bar 的 `offsetPct = (startMs - windowStart) / windowSpan * 100`
- 单条 bar 的 `widthPct = max(durationMs / windowSpan * 100, 1)`（最小 1% 可见）

**状态点**（`tree-dot`）：
- `dot-ok`: 绿色 `#18a058`（completed）
- `dot-running`: 蓝色 `#2080f0`
- `dot-failed`: 红色 `#d03050`

**叶子节点排序**：按 `startMs` 升序（modelCalls 和 toolCalls 时间交错）。

#### 详情面板（右列，460px）

根据 `selected` 的类型切换：

**模型调用详情**：
```
标题: "第 N 次大模型调用" + 状态 NTtag
详情网格 (2列):
  耗时 | 开始时间 | Token输入/输出 | 模型 | 结束原因 | API类型 | 请求ID
可折叠区块:
  ▶ 系统提示词 (collapsible, copyable)
  ▶ 历史消息 (collapsible, 每条显示 role NTtag + 内容)
  ▼ 当前输入 (默认展开, copyable)
  ▶ 模型输出 (collapsible, copyable)
```

**工具调用详情**：
```
标题: "工具调用: {toolName}" + 状态 NTag
详情网格: 耗时 | 开始时间
可折叠区块:
  ▼ 工具参数 (默认展开, copyable)
  ▼ 工具结果 (默认展开, copyable)
  ▼ 错误信息 (仅 failed, 默认展开, 红色背景)
```

**交互功能**：
- 点击叶子节点 → 选中（左侧高亮 + 右侧展示详情）
- 可折叠区块：点击标题展开/收起（chevron 图标）
- 复制按钮：`navigator.clipboard.writeText` + textarea fallback，复制后显示 check 图标 2 秒
- finishReason 映射为中文标签：`stop/end_turn`→正常结束, `length/max_tokens`→达到长度限制, `tool_calls/tool_use`→工具调用, `error`→错误, `aborted`→中止, `content_filter`→内容过滤

### 7.3 样式要点

在 `<style scoped>` 中定义的关键 CSS：

```css
.traj-body {
  display: grid;
  grid-template-columns: 1fr 460px;   /* 甘特图 | 详情 */
}

.traj-gantt-body {
  max-height: 62vh;
  overflow-y: auto;
}

.gantt-row.is-selected {
  border-left: 3px solid var(--primary);
}

.detail-pre {
  font-family: 'Fira Code', 'Cascadia Code', Consolas, monospace;
  max-height: 300px;
  overflow: auto;
}

.detail-pre-error {
  color: var(--error, #d03050);
  background: /* red-tinted */;
}
```

---

## 8. 完整调用链

### 8.1 数据采集（Agent 运行时）

```
Agent 开始运行 (runId = "run_abc123")
  │
  ▼ llm_input 事件
  hooks.llmInputHook()
    → storage.ensureTurn({ runId, sessionKey, agentId, userPrompt })
       INSERT INTO turns (run_id, ..., status='running', model_calls='[]', tool_calls='[]')
    → state.input = { model, provider, systemPrompt, prompt, ... }
  │
  ▼ model_call_started 事件
  hooks.modelCallStartedHook()
    → storage.startModelCall({ runId, callId, model, ... })
       读取 model_calls JSON → append → UPDATE
  │
  ▼ model_call_ended 事件
  hooks.modelCallEndedHook()
    → storage.finishModelCallTelemetry({ runId, callId, durationMs, outcome, ... })
       匹配 callId → 更新 endedAt/durationMs/status
  │
  ▼ [tool loop 迭代]
  before_tool_call → storage.startToolCall() → push index to state.toolStack
  after_tool_call  → pop index from stack → storage.finishToolCall()
  │
  ▼ llm_output 事件 (最后一次)
  hooks.llmOutputHook()
    → storage.recordLlmOutput({ runId, output, tokenUsage })
       UPDATE assistant_output, token_*, duration_ms, status='completed'
  │
  ▼ agent_end 事件
  hooks.agentEndHook()
    → storage.reconcileTurnFromMessages({ runId, messages: event.messages, ... })
       reconstructModelCalls(messages) → 拆分 N 个 assistant → DELETE+REWRITE model_calls
       → 聚合 token → 拼接 assistantOutput
    → activeRuns.delete(runId)
```

### 8.2 数据查询（前端打开轨迹）

```
用户点击 assistant 消息旁的 timeline 按钮
  │
  ▼ MessageActions.vue: trajectoryVisible = true
  AgentTrajectoryDrawer.vue watch(visible + runId)
  │
  ▼ rpc.getAgentTrace(runId)
  │
  ├─ HTTP POST /api/rpc
  │    { method: "wattclawTrace.get", params: { runId } }
  │
  ├─ server/index.js → gateway.call() [透传]
  │
  ├─ Gateway WS → wattclaw-prompt-capture 插件
  │    │
  │    ├─ storage.getTurn(runId)
  │    ├─ findNativeRunCompletion() → 扫描 .trajectory.jsonl
  │    ├─ needsModelCallReconstruction() → true?
  │    │    └─ storage.reconcileTurnFromMessages() → 修复
  │    └─ ctx.respond(true, { turn })
  │
  ▼ rpc-client.ts normalizeAgentTurn()
      normalizeModelCall() × N, normalizeToolCall() × M
  │
  ▼ AgentTrajectoryDrawer.vue
      turn.value = result
      autoSelectLast()
      → 渲染 Gantt 树 + 详情面板
```

### 8.3 刷新后恢复 runId

```
页面刷新 → loadHistory(sessionKey)
  │
  ▼ 加载历史消息 (无 runId)
  │
  ▼ enrichRunIds(sessionKey) [fire-and-forget]
      │
      ├─ 找到缺少 runId 的 assistant 消息
      ├─ rpc.listAgentTraces({ sessionKey, limit: 200 })
      │    → 获取所有 turns (ASC)
      │
      ├─ 对每条 assistant 消息:
      │    计算与每个 turn.assistantOutput 的最长公共前缀
      │    满足 PREFIX_CAP 且 >= MIN_ABS → 匹配
      │
      └─ setSessionMessages(sessionKey, updated)
           → assistant 消息获得 runId
           → timeline 按钮出现
```

---

## 9. 关键文件索引

| # | 文件 | 职责 |
|---|------|------|
| 1 | `plugins/wattclaw-prompt-capture-plugin/index.js` | 插件入口：注册 7 个事件钩子 + 3 个 Gateway RPC |
| 2 | `plugins/wattclaw-prompt-capture-plugin/hooks.js` | 钩子实现：事件→存储桥接，activeRuns Map，tool stack 管理 |
| 3 | `plugins/wattclaw-prompt-capture-plugin/storage.js` | `TraceStorage` 类：SQLite CRUD，JSON 序列化，数据截断，自动清理 |
| 4 | `plugins/wattclaw-prompt-capture-plugin/trace-reconstruction.js` | 消息重建算法：从 messages[] 拆分 modelCalls，token 解析，时间戳估算 |
| 5 | `plugins/wattclaw-prompt-capture-plugin/native-trace.js` | 读取 Gateway 原生 `.trajectory.jsonl` 用于数据修复 |
| 6 | `plugins/wattclaw-prompt-capture-plugin/openclaw.plugin.json` | 插件清单：activation, config schema, allowConversationAccess |
| 7 | `plugins/wattclaw-prompt-capture-plugin/package.json` | 包元数据：ESM, better-sqlite3, pluginApi >=2026.7.1 |
| 8 | `plugins/wattclaw-prompt-capture-plugin/storage.test.js` | 测试：reconcileTurnFromMessages 拆分验证 |
| 9 | `plugins/wattclaw-prompt-capture-plugin/hooks.test.js` | 测试：完整 hook 生命周期集成 |
| 10 | `plugins/wattclaw-prompt-capture-plugin/trace-reconstruction.test.js` | 测试：3 路拆分、只取最新 user 之后的消息、telemetry 保留 |
| 11 | `src/api/types/agent-trace.ts` | TypeScript 类型：`ModelCallEntry`, `ToolCallEntry`, `AgentTurnTrace` |
| 12 | `src/api/rpc-client.ts` (L2919-3018) | RPC Client：`getAgentTrace()`, `listAgentTraces()` + 3 个 normalizer |
| 13 | `src/stores/workspace.ts` (L586-661) | `enrichRunIds()`: 刷新后最长公共前缀匹配回填 runId |
| 14 | `src/views/workspace/components/AgentTrajectoryDrawer.vue` | 主 UI 组件：甘特图 + 详情面板，1013 行 |
| 15 | `src/views/workspace/components/MessageActions.vue` | 消息操作栏：timeline 按钮（条件渲染）+ 模态触发 |
| 16 | `src/views/workspace/MessageList.vue` (L437) | 传递 runId + sessionKey 给 MessageActions |
| 17 | `src/i18n/messages/zh-CN.ts` (L3034-3103) | 中文 i18n：`trajectoryDrawer` 命名空间下约 40 个 key |
| 18 | `server/index.js` | `/api/rpc` handler：wattclawTrace.* 完全透传到 Gateway |
