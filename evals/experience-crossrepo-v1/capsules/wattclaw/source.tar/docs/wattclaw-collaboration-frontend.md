# WattClaw 团队协作（Team Collaboration）前端实现文档

> 面向 WattClaw 前端「团队协作项目」这一独立功能域的完整代码梳理。涵盖路由、页面主体、Pinia store、类型定义、RPC/HTTP/SSE 通道、侧边栏集成、交付物预览、实时事件处理与 i18n。所有文件路径均相对仓库根 `/root/vibe/deploy/real-wattclaw/wattclaw`。

---

## 0. 功能概述

团队协作模式（`agent_team` / WattClaw Team）是一个**本地 REST/Gateway RPC 驱动**的多智能体协作能力，与普通单智能体工作区并存但相互独立：

- 用户在协作页面用自然语言描述目标 → 后端 `wattclaw-team-project-builder` skill 规划出一个「项目」，项目由一个 **manager（lead）成员** + 若干 **worker 成员** 组成（agentId 形如 `p-{projectId}-manager`、`p-{projectId}-worker1`）。
- 每个成员对应一个 Gateway 会话 `agent:{agentId}:main`。
- 用户确认后启动项目（可选同步到飞书群），manager 负责派发任务给 worker，产出「交付物（deliverables）」。
- 右侧诊断面板实时展示成员会话状态、任务列表、交付物，并支持在线预览 / 下载。

数据流：

```
协作页面 / 侧边栏
  → useWattClawCollaborationStore (Pinia)
     → rpc-client.ts (wattclaw.team.project.*)  ── WS RPC ──▶ Gateway
     → http-client.ts (/api/events/subscriptions/wattclaw-project) ── SSE 订阅 ──▶ 实时事件
  ← 实时事件经 websocket store 'event' 通道回流 → store.handleRealtimeEvent()
```

---

## 1. 文件清单（主体 + 支撑）

### 1.1 协作专属文件（本功能私有）

| 路径 | 行数 | 职责 |
|------|------|------|
| `src/views/wattclaw-collaboration/WattClawCollaborationPage.vue` | 486 | 协作主页面：头部、启动确认、消息区、聊天输入、挂载诊断面板；路由与实时订阅编排 |
| `src/views/wattclaw-collaboration/WattClawProjectPanel.vue` | 610 | 右侧诊断面板：项目摘要、成员会话、交付物分组、任务列表、失败重试 |
| `src/views/wattclaw-collaboration/WattClawDeliverableOutput.vue` | 720 | 单个交付物文件卡片 + 预览弹窗（md/html/code/csv/docx/xlsx/pdf/图片/音视频） |
| `src/stores/wattclaw-collaboration.ts` | 794 | 核心 Pinia store：项目状态、成员会话、任务、模型、实时事件、CRUD、诊断刷新 |
| `src/stores/wattclaw-collaboration.test.ts` | — | store 单元测试 |
| `src/api/types/wattclaw-team.ts` | 91 | 全部协作相关 TS 类型 |
| `src/utils/wattclaw-deliverable.ts` | 210 | 交付物结构归一化工具（形态多变的 Gateway 输出 → 统一 shape） |

### 1.2 被复用/被扩展的共享文件（含协作分支）

| 路径 | 协作相关内容 |
|------|--------------|
| `src/router/routes.ts` | `collaboration` 子路由（`name: 'WattClawCollaboration'`），Workspace 布局下的隐藏路由 |
| `src/views/workspace/ChatInput.vue` | `collaboration-mode` prop 分支：暂存消息、注入协作上下文、模型选择走 store |
| `src/views/workspace/MessageList.vue` | 接收 `pending-messages` 展示乐观消息 |
| `src/views/workspace/WorkspaceSidebar.vue` | 侧边栏「协作项目」分组：列表、激活态、重命名/删除、创建入口、会话过滤 |
| `src/api/rpc-client.ts` | `wattclaw.team.project.*` RPC 封装（第 2104–2159 行） |
| `src/api/http-client.ts` | `setWattClawProjectSubscription()` + SSE 订阅同步（第 225–262 行） |
| `src/api/websocket.ts` | `setWattClawProjectSubscription()` 委托到 apiClient（第 103 行） |
| `src/stores/websocket.ts` | 暴露 `setWattClawProjectSubscription`（第 148、184 行） |
| `src/utils/event-helpers.ts` | `extractSessionKey(payload)` — 从事件负载提取 sessionKey |
| `src/i18n/messages/zh-CN.ts` | `pages.wattClawCollaboration.*` 全部文案（第 3521 行起），`routes.wattClawCollaboration`（第 32 行） |

> 注意：项目目前**只有 `zh-CN.ts`** 一个 locale 文件（尽管 CLAUDE.md 提到 en-US），协作文案仅存在中文。

---

## 2. 路由（`src/router/routes.ts`）

协作页面作为 Workspace 布局下的隐藏子路由存在：

```ts
{
  path: 'collaboration',
  name: 'WattClawCollaboration',
  component: () => import('@/views/wattclaw-collaboration/WattClawCollaborationPage.vue'),
  meta: { titleKey: 'routes.wattClawCollaboration', hidden: true },
},
```

- 与 `Workspace`（`WorkspacePage.vue`）同级，共用侧边栏布局。
- 通过 query `?projectId=xxx` 携带当前项目；无 projectId 表示「新建草稿」状态。
- 页面与 store 之间的 `projectId` 双向同步（详见 §3 的两个 `watch`）。

---

## 3. 主页面 `WattClawCollaborationPage.vue`

### 3.1 结构（template）

```
.collaboration-page (flex 行)
├── main.collaboration-main
│   ├── header.collaboration-header  返回键 / 图标 / 标题+状态Tag / 新建项目 / 诊断开关
│   ├── NAlert.start-confirmation     启动确认条（仅 pending + 存在非 lead 成员时显示）
│   ├── NAlert.page-error             store.error 展示
│   ├── section.chat-area
│   │   ├── .collaboration-empty      空态（无消息且未发送时）：三步引导
│   │   └── MessageList               带 pending-messages 的消息流
│   ├── ChatInput collaboration-mode
│   └── .chat-ai-disclaimer
└── WattClawProjectPanel (v-if showDiagnostics)   右侧诊断面板
```

### 3.2 关键计算属性

- `hasStartMarker`：workspace 消息中是否出现 assistant 发的 `<team-project-start-confirm/>` 标记 → 表示 manager 规划完成，可启动。
- `showStartConfirmation`：`project.status === 'pending'` 且成员里存在非 lead 成员时，显示启动确认条。文案在 `hasStartMarker` 前后切换（`startDescription` vs `pendingDescription`）。

### 3.3 状态映射

- `statusText(status)`：`pages.wattClawCollaboration.status.{status}`，用 `te()` 判断 key 是否存在，回退原始值。
- `statusType(status)`：映射到 Naive UI Tag 类型 —— `in_progress→success`，`failed→error`，`pending/planning/creating/waiting→warning`，`paused/archived→default`，其余 `info`。

### 3.4 启动流程 `startProject()`

1. 若勾选 `syncToFeishu`：先 `collaborationStore.checkFeishuChannelPermission()` 校验飞书渠道绑定 + 建群权限；不满足则报错返回。
2. 调 `collaborationStore.startProject(syncToFeishu)`。
3. 若要求飞书但 `project.feishuSync.enabled` 为 false：打开 `permissionUrl` 授权页并告警。
4. 成功 toast（区分是否同步飞书）。

### 3.5 其它动作

- `createNewProject()`：`store.reset()` → 路由 replace 清空 query → `selectDefaultAgent()`。
- `goBack()`：回到 `Workspace`。
- `selectDefaultAgent()`：加载 agents/models，选中 `main` 或首个 agent（新建草稿态下让聊天输入可用）。

### 3.6 实时订阅与生命周期编排（核心）

`syncProjectSubscription()`：仅当页面可见（`document.visibilityState === 'visible'`）时订阅当前 `projectId`，否则订阅 `null`（省流/避免后台无谓推送）。走 `wsStore.setWattClawProjectSubscription()`。

`onMounted`：
1. `wsStore.ensureConnected()`。
2. 订阅 `'event'` 通道 → 每条事件转发 `collaborationStore.handleRealtimeEvent(event.event, event.payload)`。
3. 订阅 `'connected'` 通道 → 重连后若页面可见且有项目，重新订阅并 `refreshDiagnostics()`。
4. `selectDefaultAgent()` → 从 query 读取 `projectId` → `store.initialize(queryProjectId)`。
5. `routeSyncReady = true`，首帧订阅，`loadSavedProjectsMeta()`。
6. 监听 `visibilitychange`。

`onUnmounted`：取消项目订阅、解绑两个通道、移除 visibility 监听。

`handleVisibilityChange()`：同步订阅；页面变可见且有项目时刷新诊断。

### 3.7 路由 ↔ store 双向同步（两个 watch，易错点）

- `watch(store.projectId)`：projectId 变更 → 同步订阅 + 把 query 更新为最新 projectId（避免刷新丢失）。
- `watch(route.query.projectId)`（`routeSyncReady` 后才生效）：
  - **先处理「无 projectId」**（在相等性判断之前）：侧边栏「新建项目」会先 `reset()` 再导航，此时两侧都为 null，若先做相等判断会漏掉重置 → 残留上个项目会话。故 targetProjectId 为空时：若 store 仍有 projectId 则 `reset()`，再 `selectDefaultAgent()`。
  - 相等则跳过；否则 `store.switchToProject(targetProjectId)`。
- `watch(hasStartMarker)`：出现启动标记时刷新诊断。

---

## 4. 核心 Store `stores/wattclaw-collaboration.ts`

Pinia setup store，id `'wattclaw-collaboration'`。

### 4.1 常量与持久化

```ts
STORAGE_KEY       = 'wattclaw:wattclaw-collaboration:projectId'      // 旧版单 id（迁移用）
STORAGE_KEY_LIST  = 'wattclaw:wattclaw-collaboration:projectIds'     // 项目 id 列表
MODEL_STORAGE_KEY = 'wattclaw:wattclaw-collaboration:model'
DEFAULT_WATTCLAW_COLLABORATION_MODEL = 'deepseek/deepseek-v4-pro'
```

- `initialProjectIds()`：从 localStorage 读列表；兼容旧的单 id 键并自动迁移。
- `initialProjectId()`：取列表最后一个（最近项目）。
- `initialModel()`：读持久化模型，回退默认。

### 4.2 State

| 名称 | 类型 | 说明 |
|------|------|------|
| `projectId` | `ref<string \| null>` | 当前项目 id |
| `savedProjectIds` | `ref<string[]>` | 本地记住的项目 id 列表 |
| `savedProjectsMeta` | `shallowRef<(WattClawProject & {id})[]>` | 侧边栏用的项目元数据列表 |
| `project` | `shallowRef<WattClawProject \| null>` | 当前项目完整对象 |
| `tasks` | `ref<WattClawProjectTask[]>` | 当前项目任务列表 |
| `memberSessions` | `ref<WattClawMemberSession[]>` | 各成员会话运行态 |
| `selectedModel` | `ref<string>` | 协作模型 |
| `loading/creating/starting/retrying` | `ref<boolean>` | 各操作 loading |
| `error` | `ref<string \| null>` | 错误信息 |
| `pendingMessages` | `ref<ChatMessage[]>` | 乐观「发送中」消息 |

内部私有：`diagnosticsRequestId`（请求竞态令牌）、`diagnosticsInFlight`（同项目并发去重）、`syncedMemberModels`/`memberModelSyncs`（成员模型同步去重）、`seenMessageActivityIds`（消息活动去重，上限 2048）。

### 4.3 Getters

- `managerAgentId`：`members.find(isLead)?.agentId`。
- `hasProject`：`projectId && project`。
- `projectSessionKeys`：所有已知项目（savedProjectsMeta + 当前）成员的 `agent:{agentId}:main` 集合 → 供侧边栏过滤掉协作会话，避免它们混进普通会话列表。

### 4.4 实时事件处理 `handleRealtimeEvent(event, payload)`

按事件类型分派（均做 `projectId` 匹配校验）：

| 事件 | 处理 |
|------|------|
| `wattclaw.team.project.updated` | 校验 project.id 与成员数组 → 合并更新 `project`、`updateSavedProjectMeta`、`reconcileMemberSessions` |
| `wattclaw.team.tasks.updated` | 替换 `tasks` |
| `wattclaw.team.project.deleted` | `removeSavedProject` → `clearProjectData` → 若还有其它项目则 `initialize` 之 |
| `session.message.activity` | `applyMemberMessageActivity(payload)` 递增消息计数 |
| 其它 | `applyMemberSessionEvent(event, payload)` 更新会话运行态 |

`applyMemberSessionEvent()`（防御式解析 Gateway 多变形态）：
- 用 `extractSessionKey` + 正则 `^agent:([^:]+):` 定位成员。
- 归一 `stream`/`phase`/`action`，判定三态：
  - `isRemoved`：`sessions.deleted`/`session.deleted` 或 action 含 delete/remove。
  - `isFinished`：`agent.done`/`chat.done`/`chat.final`/含 error，或 `stream===lifecycle && phase∈{end,result,stop,completed,error,aborted,cancelled}`。
  - `isRunning`：`agent.started`/`chat.delta`，或 `agent` + lifecycle start，或 stream∈{thinking,tool,item,command_output,assistant,compaction}。
- 更新 `memberSessions[i]`：`available`、`messageCount`（取 max）、`lastActivity`、`isStreaming`。

`applyMemberMessageActivity()`：按 `messageId/messageSeq/seq` 去重（`seenMessageActivityIds`，超 2048 淘汰最旧），有绝对计数取 max，否则 `+messageDelta(默认1)`。

### 4.5 模型同步

- `syncMemberModel(agentId, force)`：`wsStore.rpc.updateAgent({agentId, model})`，用 `syncedMemberModels`/`memberModelSyncs` 去重、避免并发重复请求。
- `syncProjectMemberModels(members, force)`：`Promise.all` 批量。
- `selectModel(model)`：更新 + 持久化 → `workspaceStore.previewModelChange` → 有项目则强制同步所有成员模型。

### 4.6 会话绑定 `bindManagerSession(project, {fast})`

将 manager 会话接入 workspace（让主聊天区对接 manager）：
- 直接用项目成员数据 `ensureGatewayAgent` 种子 manager（**关键**：`rpc.listAgents()` 只见当前 tenant，admin 跨 tenant 打开项目时 manager 不在其中，故不能依赖它）。
- `fast` 模式：`activateAgentSession` + `previewModelChange` + `selectSession`（不阻塞）。
- 非 fast：尽力从 gateway `listAgents` 补充身份/头像/模型（单次非阻塞 try/catch）→ `selectAgent` + `selectSession` + `previewModelChange`。

### 4.7 草稿与消息编排

- `createDraft(prompt)`：已有项目直接返回；否则 `rpc.createWattClawProject({description, locale})`（RPC `wattclaw.team.project.build`，超时 120s）→ 持久化 id、同步成员模型、fast 绑定 manager、刷新诊断。
- `prepareOutgoingMessage(prompt, message)`：确保有项目（无则建草稿）→ 若当前 agent 非 manager 则重绑 → 给消息**追加协作上下文**：

  ```
  [WattClaw Team Collaboration Context]
  draft_project_id: {id}
  Use the wattclaw-team-project-builder skill for this draft project.
  After team planning is complete, finalize the project and include <team-project-start-confirm/> in the response.
  ```

  返回 `{message(含上下文), displayMessage(原文)}`。
- `stageOutgoingMessage(params)`：生成 `pending-collaboration-*` id，把乐观 user 消息 push 到 `pendingMessages`；返回 id。
- `clearPendingMessage(id)`：移除。

### 4.8 诊断刷新（竞态安全）

- `mapMemberSessions(members, sessions)`：把 `listSessions` 结果按 `agent:{agentId}:main` 或 agentId 匹配到成员，取最近 `lastActivity`，合并计数/流式态。
- `refreshDiagnosticsRequest(targetProjectId)`：`++diagnosticsRequestId` 作令牌；`Promise.allSettled([getWattClawProject, listWattClawProjectTasks])`；每步都校验 `requestId === diagnosticsRequestId && projectId === targetProjectId`，防止切换项目后旧响应覆盖；再 `listSessions({limit:500, refreshUsage:true, sessionKeys})` 填充成员会话。
- `refreshDiagnostics(targetProjectId?)`：同 targetProjectId 的并发合并到 `diagnosticsInFlight`。

### 4.9 生命周期 / CRUD

- `initialize(id?)`：切项目则 `clearProjectData` → 持久化 → `refreshDiagnostics` → 绑定 manager。
- `startProject(isCreateFeishuGroup)`：同步成员模型 → `rpc.startWattClawProject` → 绑 manager → 刷新 → 合并 feishuSync。
- `checkFeishuChannelPermission(force)`：`POST /api/user/feishu-bot/check`，返回 `{isFeishuChannelBound, hasFeishuGroupCreatePermission, feishuAuthUrl, error}`。
- `reset()`：清空 projectId + 数据。
- `switchToProject(id)`：持久化 → 清数据 → initialize。
- `removeSavedProject(id)`：从列表/meta 移除；若删的是当前项目则回退到列表最后一个或 reset。
- `loadSavedProjectsMeta()`：优先 `rpc.listWattClawProjects()`（合并本地顺序 + 服务端新项目）；失败回退逐个 `getWattClawProject`。
- `retryProject()`：同步模型 → `rpc.retryWattClawProject` → 刷新。
- `renameProject(id, name)` / `deleteProject(id)`：`updateWattClawProject` / `deleteWattClawProject` + 本地 meta 更新。
- `applyProjectMetaPatch(id, patch)`：局部更新 savedProjectsMeta 与 project。

---

## 5. 诊断面板 `WattClawProjectPanel.vue`

只读展示 store 状态，唯一交互是刷新 / 重试 / 打开会话 / 复制 id / 交付物预览下载。

### 5.1 分区

1. **panel-head**：标题 + 刷新按钮（`store.refreshDiagnostics()`，loading 绑定）。
2. **loading / NEmpty**：无 project 时空态。
3. **project-summary**：项目名 + 状态 Tag + 可复制的 project.id + updatedAt。
4. **failure-alert**（`project.failReason`）：失败原因 + 重试按钮（`handleRetry`）。
5. **members**：每个成员一个可点击 button → `openSession(sessionKey)` 跳 Workspace 打开该会话；显示 lead 图标/角色/会话状态点（running/ready/initializing）/消息数/最近活动时间。
6. **deliverables**（`deliverablesByAgent` 非空时）：按 agent 分组，每任务下渲染多个 `WattClawDeliverableOutput`；标记「最终/中间」交付物。
7. **tasks**：任务列表，状态 Tag，assignee，错误信息。

### 5.2 关键逻辑

- `sessionFor(member)`：从 `memberSessions` 找该 agent 的会话。
- `taskTitle/taskAgent/taskError`：多字段兜底（`title||name||taskId||id` 等）。
- 任务状态集合：`COMPLETED={Success,completed,done}`、`FAILED={failed,Failed,Block,error}`、`RUNNING={InProgress,in_progress,running,Dispatched,dispatched}`。
- `displayTaskStatus(task)`：**项目失败时**重算任务展示状态 —— 已完成保留、运行中→`Failed`、待处理→`undispatched`。
- `tasksWithDeliverables` / `deliverableCount` / `deliverablesByAgent`：基于 `getWattClawTaskDeliverables(task)`。
- `copyProjectId()`：优先 `navigator.clipboard`（仅安全上下文可用），HTTP+IP 非安全上下文回退到 `document.execCommand('copy')`（隐藏 textarea）。
- `openSession(sessionKey)`：`router.push({name:'Workspace', query:{session, historyLimit:'10'}})`。

---

## 6. 交付物预览 `WattClawDeliverableOutput.vue`

单个交付物的文件卡片 + 预览弹窗。这是协作域中最重的展示组件。

### 6.1 Props

```ts
{ projectId: string; taskId: string; output: unknown; outputIndex?: number }
```

### 6.2 归一 & 类型判定

- `outputFile = normalizeWattClawDeliverable(props.output, outputIndex)`（见 §8）。
- `isInline`：有 `inlineContent`。`isRemote`：path 为 URL/data/blob。`isUnavailable`：无文件或（非 inline/remote 且缺 projectId/taskId）。
- `outputPreviewKind`：扩展名映射 → `audio`/`video`/`image`(含 svg)/`getPreviewKind(ext)`（markdown/html/code/text/csv/docx/spreadsheet/pdf/image/unsupported）。
- `canPreview`：kind ≠ unsupported。

### 6.3 数据获取（三种来源 + 分块）

`fetchOutputBlob()`（带 `cachedBlob` 缓存、`MAX_DELIVERABLE_BYTES = 256MB` 限制）：
1. **inline**：base64 → `base64ToArrayBuffer`，或 text 直接建 Blob。
2. **remote**：`fetch(path)` → blob。
3. **Gateway 分块下载**：循环调用 `rpc.downloadWattClawTaskOutput({projectId, taskId, outputName:rpcOutputName, chunkIndex, chunkSize:1MB})`，按 `hasNext` 拼接，`chunkIndex>4096` 或超限报错；目录类型按 `application/gzip`。

`loadOutputBlob()`：缓存优先，`outputBlobPromise` 去重并发。

### 6.4 预览渲染 `openPreview()`

按 `previewKind` 分派（全部懒加载重库）：
- markdown/html/code/text → `blob.text()`；markdown 用 `renderMarkdown` 计算属性，html 用沙箱 `<iframe srcdoc sandbox="">`。
- csv → 动态 `import('xlsx')` → `sheet_to_json` → `setTablePreview`。
- docx → `import('docx-preview')` `renderAsync` 到容器。
- spreadsheet(xlsx) → xlsx 解析多 sheet，`tableSheets` Map，`NSelect` 切换 sheet。
- pdf → `defineAsyncComponent(PdfViewer)`。
- image/audio/video → `URL.createObjectURL`。

表格：`setTablePreview` 截断前 1000 行，首行无列名时用 `deliverableColumn` 占位；`tableAutoFit`（≤8 列自适应）。

### 6.5 下载 & 资源管理

- `downloadOutput()`：`loadOutputBlob` → `downloadBlob(blob, filename)`。
- `onUnmounted` / `resetPreview` / props watch：`URL.revokeObjectURL` 释放；props 变更清缓存。
- `mimeType(filename)`：内置扩展名→MIME 映射表（pdf/office/图片/音视频/压缩包等）。

---

## 7. 类型定义 `api/types/wattclaw-team.ts`

```ts
type WattClawProjectStatus =
  | 'creating' | 'waiting' | 'pending' | 'planning'
  | 'in_progress' | 'paused' | 'failed' | 'archived' | string

interface WattClawProjectMember {
  agentId: string; name: string; role: string
  status?: string; isLead?: boolean; skills?: string[]
  createdAt?: string; updatedAt?: string
}

interface WattClawProject {
  id: string; name: string; description?: string; locale?: string
  status: WattClawProjectStatus; createdAt?: string; updatedAt?: string
  members: WattClawProjectMember[]
  lastStatus?: WattClawProjectStatus; failReason?: string
  draftSuggestion?: Record<string, unknown>
  feishuSync?: { enabled: boolean; chatId?: string; chatName?: string; error?: string; permissionUrl?: string }
  [key: string]: unknown
}

interface WattClawProjectTask {
  id?/taskId?/projectId?/title?/name?/description?/status?: string
  agentId?/assigneeAgentId?/assignedAgentId?/error?/failReason?: string
  createdAt?/updatedAt?: string; outputs?: unknown; [key: string]: unknown
}

interface WattClawProjectTaskOutput { name; path; size?; isDirectory?; createdAt?; updatedAt?; [key]: unknown }
interface WattClawOutputDownloadChunk { chunkIndex; filename; outputName?; data; hasNext; fileSize? }
interface WattClawMemberSession { agentId; sessionKey; available; messageCount; lastActivity?; isStreaming }
```

> 类型大量使用可选字段 + 索引签名，因为 Gateway 返回形态多变，前端需防御式解析。

---

## 8. 交付物归一工具 `utils/wattclaw-deliverable.ts`

统一把「形态千变万化」的 Gateway task output 转成 `NormalizedWattClawDeliverable`。

```ts
interface NormalizedWattClawDeliverable {
  name; path; rpcOutputName?; size?; isDirectory?
  createdAt?; updatedAt?; mimeType?
  inlineContent?; inlineEncoding?: 'base64' | 'text'
}
```

- `normalizeWattClawDeliverable(output, index)`：
  - 字符串：`looksLikePath` → 当路径；否则当 inline 文本（`looksLikeMarkdown` 决定 .md/.txt）。
  - 对象：拆 `file/artifact/deliverable` 嵌套；多字段兜底提取 path/name/mimeType/content/base64/markdown；`normalizedName` 补扩展名；无 path 无 content 则序列化成 json。
  - 非对象非字符串：`JSON.stringify` 成 `.json`。
- `getWattClawTaskDeliverables(task)`：从 `task.outputs` 抽出交付物数组 —— 数组直返；对象则查 `items/files/artifacts/deliverables/data`；单文件字段（path/content 等）包成单元素；否则当「命名 map」逐条转换。
- 辅助：`asRecord`、`firstString`、`firstContent`、`basename`、`hasExtension`、`extensionForMimeType`、`looksLikeMarkdown`、`looksLikePath`、`normalizedName`。

---

## 9. 通信通道

### 9.1 RPC（`api/rpc-client.ts` 2104–2159）

| 方法 | Gateway method | 超时 | 说明 |
|------|----------------|------|------|
| `createWattClawProject({description, locale})` | `wattclaw.team.project.build` | 120s | `{prompt, locale, triggerManager:false}` |
| `getWattClawProject(id)` | `wattclaw.team.project.get` | 默认 | |
| `listWattClawProjects()` | `wattclaw.team.project.list` | 默认 | `normalizeList(['projects','items','list','data'])` |
| `startWattClawProject(id, isCreateFeishuGroup)` | `wattclaw.team.project.start` | 120s | |
| `retryWattClawProject(id)` | `wattclaw.team.project.retry` | 120s | |
| `updateWattClawProject({id, name?, description?})` | `wattclaw.team.project.update` | 120s | |
| `deleteWattClawProject(id)` | `wattclaw.team.project.delete` | 120s | |
| `listWattClawProjectTasks(projectId)` | `wattclaw.team.project.task.list` | 默认 | `normalizeList(['tasks',...])` |
| `downloadWattClawTaskOutput({projectId, taskId, outputName?, chunkIndex, chunkSize})` | `wattclaw.team.project.task.output.download` | 120s | 分块下载 |

### 9.2 SSE 项目订阅（`api/http-client.ts` 225–262）

- `setWattClawProjectSubscription(projectId | null)`：记录 `desiredWattClawProjectId`，入串行队列 `enqueueWattClawProjectSubscriptionSync`（`.catch().then()` 保证顺序、吞错）。
- `syncWattClawProjectSubscription()`：与 `appliedWattClawProjectId` 比较，避免重复；`PUT`（有 projectId）/`DELETE`（null）到 `/api/events/subscriptions/wattclaw-project`，body `{clientId, projectId?}`；成功后记录 applied，`clientId` 变化时放弃（重连场景）。
- 委托链：组件 → `wsStore.setWattClawProjectSubscription` → `websocket.ts` → `http-client.ts`。

### 9.3 实时事件回流

后端 SSE 事件 → websocket store 的 `'event'` 通道 → 页面 `onMounted` 订阅回调 → `store.handleRealtimeEvent(event, payload)`（见 §4.4）。相关事件名：`wattclaw.team.project.updated/deleted`、`wattclaw.team.tasks.updated`、`session.message.activity`、通用 agent/chat 事件。

### 9.4 飞书权限 REST

- `POST /api/user/feishu-bot/check`（`{force}`）→ `{bound, valid, permissionUrl, error}`（见 store `checkFeishuChannelPermission`）。

---

## 10. 侧边栏集成 `views/workspace/WorkspaceSidebar.vue`

### 10.1 会话过滤（第 255 行）

普通会话列表排除掉协作项目会话：`!collaborationStore.projectSessionKeys.has(session.key)` —— 协作成员会话不混进普通 agent 会话。

### 10.2 协作分组（template 409–470）

- 顶部 `collab-agent-item`（`hub` 图标）：点击 `createCollaborationProject()`（reset + 导航到空 query）。
- 展开按钮 `collabExpanded` 切换。
- `collabProjects = store.savedProjectsMeta` 列表：每项显示 `groups` 图标 + 项目名 + 状态 Tag；`isCollabProjectActive` 高亮；`NDropdown` 提供「重命名 / 删除」。
- 空态：`noSavedProjects`。

### 10.3 重命名 / 删除

- `handleProjectAction(action, proj)` → 设置 `renamingProject`/`deletingProject`。
- `confirmProjectRename` → `store.renameProject`；`confirmProjectDelete` → `store.deleteProject`，若删当前项目则导航到空 query。
- 各用 NModal（`showProjectRenameModal`/`showProjectDeleteModal` computed getter/setter 绑定）。

### 10.4 状态映射

`projectStatusType` / `projectStatusText`：与页面一致的状态→Tag 类型/文案映射。

---

## 11. ChatInput 协作分支 `views/workspace/ChatInput.vue`

- Props：`collaborationMode?: boolean`（默认 false）。
- 模型显示：协作模式取 `collaborationStore.selectedModel`（第 104 行）。
- 发送禁用：额外 `&& !collaborationStore.creating`。
- 发送流程 `handleSend`：
  1. 协作模式先 `stageOutgoingMessage`（乐观消息）拿到 `pendingMessageId`。
  2. 清空输入区。
  3. `prepareOutgoingMessage(display, sendText)` 注入协作上下文（失败则回滚输入/技能/附件并报错）。
  4. `workspaceStore.sendMessage(...)`；成功/失败都 `clearPendingMessage`；失败回滚。
- 模型切换 `handleModelChange`（699 行）：协作模式走 `collaborationStore.selectModel(modelId)`。
- `openCollaborationMode()`：扩展菜单里的入口，`router.push({name:'WattClawCollaboration'})`（仅非协作模式显示该菜单项）。

---

## 12. i18n（`src/i18n/messages/zh-CN.ts`）

- `routes.wattClawCollaboration`（第 32 行）：'WattClaw 协作模式'。
- `pages.wattClawCollaboration.*`（第 3521 行起）完整键（节选）：
  - 页面：`title/subtitle/placeholder/emptyTitle/emptyDescription/stepCreate/stepPlan/stepObserve/newProject`。
  - 诊断：`diagnostics/diagnosticsHint/noProject/failureReason/members/manager/tasks/noTasks/unnamedTask/noActivity`。
  - 会话：`sessionMissing/sessionInitializing/sessionReady/sessionRunning/sessionMessages/viewSession/updatedAt/projectIdCopied/copyFailed`。
  - 启动/飞书：`startTitle/startDescription/pendingDescription/startButton/startSuccess/startWithFeishuSuccess/startWithFeishuFailed/startFailed/feishuSyncLabel/feishuSyncHint/feishuNotBound/feishuNoPermission/feishuCheckFailed`。
  - 消息/项目：`createFailed/messagePreparing/myProjects/noSavedProjects`。
  - 交付物：`deliverables/noDeliverables/intermediateDeliverable/finalDeliverable/openDeliverable/previewDeliverable/downloadDeliverable/deliverableLoading/deliverableInvalidResponse/deliverableTooLarge/deliverableOpenFailed/deliverablePreviewFailed/deliverablePreviewInitFailed/deliverableDownloadFailed/deliverableUnsupportedPreview/deliverableColumn/deliverableTableSize`。
  - 操作：`retry/retrySuccess/retryFailed/rename/renameTitle/renameLabel/renamePlaceholder/renameFailed/deleteTitle/deleteDescription/deleteFailed`。
  - `status.*`：`creating/waiting/pending/planning/paused/...`（与 `WattClawProjectStatus` 对应）。

---

## 13. 关键设计要点 / 易错点小结

1. **projectId 三处同步**：localStorage（列表）、路由 query、store.projectId —— 通过页面两个 watch + store 持久化函数维持一致。
2. **「新建项目」必须先 reset 再导航**：否则 route watch 的相等判断会漏掉重置，残留上个项目会话（源码有专门注释处理该 case）。
3. **诊断刷新竞态**：`diagnosticsRequestId` 令牌 + `projectId` 双校验，防止切换项目后旧响应覆盖新状态。
4. **manager 会话种子化**：不能依赖 `rpc.listAgents()`（只见当前 tenant），必须用项目成员数据 `ensureGatewayAgent` 种子，才支持 admin 跨 tenant 打开项目。
5. **可见性感知订阅**：页面不可见时订阅 `null`，重连后自动恢复。
6. **交付物大而全**：256MB 上限、分块下载、blob 缓存、URL 及时 revoke、重库懒加载（xlsx/docx-preview/PdfViewer）。
7. **防御式解析贯穿始终**：事件、任务、交付物都用多字段兜底 + `asRecord`/`extractSessionKey`，适配 Gateway 多变返回。
8. **协作会话与普通会话隔离**：`projectSessionKeys` 在侧边栏过滤，避免协作成员会话污染普通列表。
