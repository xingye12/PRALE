# WattClaw 部署手册（OpenClaw 服务器）

> 本文档描述在 `openclaw` 服务器上部署/更新 WattClaw 的完整流程。

---

## 一、前置条件

### 1.1 服务器环境

- **主机**: `openclaw`（已安装 Docker + Docker Compose）
- **代码目录**: `/home/wattman/work/wattclaw`
- **数据目录**:
  - `/home/wattman/.openclaw` — Gateway 配置与媒体文件
  - `/home/wattman/.wattclaw` — WattClaw 本地数据（数字员工等）
  - `/home/wattman/work/wattclaw/data` — SQLite 数据库
  - `/home/wattman/work/wattclaw/uploads` — 上传文件
- **运行用户**: `wattman`（UID/GID = 1000）

### 1.2 关键配置文件

| 文件 | 作用 | 位置 |
|------|------|------|
| `.env` | 环境变量（数据库连接、认证、Gateway WS 地址等） | `/home/wattman/work/wattclaw/.env` |
| `docker-compose.wattclaw.yml` | 容器编排配置 | `/home/wattman/work/wattclaw/docker-compose.wattclaw.yml` |
| `Dockerfile.wattclaw` | 镜像构建配置 | `/home/wattman/work/wattclaw/Dockerfile.wattclaw` |

`.env` 核心变量示例：

```bash
PORT=3001
OPENCLAW_WS_URL=ws://172.17.0.1:18789
AUTH_USERNAME=admin
AUTH_PASSWORD=admin123
OPENCLAW_AUTH_TOKEN=...
LOG_LEVEL=INFO
GATEWAY_DEPLOY_MODE=colocated
GATEWAY_FILE_TRANSFER_MODE=local
GATEWAY_CONFIG_DIR=/home/wattman/.openclaw
VITE_BASE_PATH=/wattclaw/
```

> **注意**: `VITE_BASE_PATH=/wattclaw/` 必须带尾部斜杠，否则前端静态资源路径会错误。

---

## 二、首次部署流程

### Step 1: 拉取/准备代码

```bash
cd /home/wattman/work/wattclaw
git pull origin main
```

### Step 2: 安装依赖并构建前端

```bash
npm install
VITE_BASE_PATH=/wattclaw/ npm run build
```

构建产物输出到 `dist/` 目录。

> **为什么必须在宿主机构建？**  
> `VITE_BASE_PATH` 是构建时变量，必须在 `npm run build` 前设置，嵌入到编译后的 JS/CSS 中。Docker 镜像内构建无法感知宿主机部署路径。

### Step 3: 构建 Docker 镜像

```bash
cd /home/wattman/work/wattclaw
docker build -f Dockerfile.wattclaw -t wattclaw:v1.0 .
```

> **镜像标签**: 使用 `wattclaw:v1.0` 而非 `latest`，避免版本混乱。

### Step 4: 启动容器

```bash
docker compose -f docker-compose.wattclaw.yml up -d
```

### Step 5: 验证

```bash
# 查看容器状态
docker ps

# 查看日志
docker logs -f wattclaw

# 健康检查（容器内 wget 已安装）
docker exec wattclaw wget --quiet --tries=1 --spider http://localhost:3001/api/health
```

---

## 三、代码更新部署流程

当你修改了代码（如 `git pull` 或手动修改后），按以下步骤重新部署：

### 3.1 快速部署（推荐）

```bash
cd /home/wattman/work/wattclaw

# 1. 更新代码
git pull origin main

# 2. 重新构建前端
npm install
VITE_BASE_PATH=/wattclaw/ npm run build

# 3. 重新构建镜像
docker build -f Dockerfile.wattclaw -t wattclaw:v1.0 .

# 4. 重启容器（会自动使用新镜像）
docker compose -f docker-compose.wattclaw.yml up -d

# 5. 验证
docker ps
docker logs -f wattclaw
```

### 3.2 零停机部署（可选）

如果要求更新期间不中断服务：

```bash
cd /home/wattman/work/wattclaw

# 1-3. 同上：拉代码、构建前端、构建镜像

# 4. 使用新标签构建，保留旧容器运行
docker build -f Dockerfile.wattclaw -t wattclaw:v1.1 .

# 5. 修改 docker-compose 中的 image 标签为 v1.1
#    编辑 docker-compose.wattclaw.yml: image: wattclaw:v1.1

# 6. 滚动更新
docker compose -f docker-compose.wattclaw.yml up -d

# 7. 验证新版本正常后，删除旧镜像
docker rmi wattclaw:v1.0
```

---

## 四、Nginx 反向代理配置

Nginx 在另一台机器上，配置示例：

```nginx
location /wattclaw/ {
    proxy_pass http://<openclaw-ip>:3001/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

> **关键**: `proxy_pass` 末尾的 `/` 必须与 `VITE_BASE_PATH` 匹配。如果 `VITE_BASE_PATH=/wattclaw/`，则 Nginx 的 `location` 和 `proxy_pass` 都要带 `/wattclaw/`。

---

## 五、回滚操作

如果新版本出现问题：

```bash
cd /home/wattman/work/wattclaw

# 方法1: 回退代码后重新构建
git reset --hard <上一个稳定commit>
VITE_BASE_PATH=/wattclaw/ npm run build
docker build -f Dockerfile.wattclaw -t wattclaw:v1.0 .
docker compose -f docker-compose.wattclaw.yml up -d

# 方法2: 如果有历史镜像，直接切换标签
docker tag wattclaw:v0.9 wattclaw:v1.0
docker compose -f docker-compose.wattclaw.yml up -d
```

---

## 六、常见问题排查

### 6.1 前端资源 404 / MIME type 错误

**现象**: 浏览器控制台报错 `Failed to load module script` 或 `MIME type` 错误。

**根因**: `VITE_BASE_PATH` 未设置或设置错误，导致前端请求 `/assets/xxx.js` 而非 `/wattclaw/assets/xxx.js`。

**修复**:
```bash
VITE_BASE_PATH=/wattclaw/ npm run build
# 检查 dist/index.html 中 src 路径是否为 /wattclaw/assets/
grep 'src="/wattclaw/assets/' dist/index.html
```

### 6.2 容器状态 unhealthy

**现象**: `docker ps` 显示 `(unhealthy)`。

**根因**: 健康检查使用 `wget`，旧镜像未安装 wget。

**修复**: 确保 Dockerfile 中 `apt-get install` 包含 `wget`，然后重新构建镜像。

### 6.3 `better-sqlite3` 加载失败

**现象**: 容器启动报错 `cannot find /lib64/ld-linux-x86-64.so.2` 或 `better-sqlite3` 相关错误。

**根因**: `node:24-alpine`（musl）与宿主机编译的 `better-sqlite3`（glibc）不兼容。

**修复**: Dockerfile 必须使用 `node:24-slim`（Debian 基础）。

### 6.4 权限错误 `EACCES`

**现象**: 容器内报错 `permission denied, mkdir '/app/uploads'`。

**根因**: 宿主机挂载目录的 UID/GID 与容器内 `wattman` 用户不一致。

**修复**:
```bash
sudo chown -R 1000:1000 /home/wattman/work/wattclaw/data
sudo chown -R 1000:1000 /home/wattman/work/wattclaw/uploads
```

### 6.5 Gateway 连接失败

**现象**: 日志显示 `EHOSTUNREACH` 或 `ECONNREFUSED`。

**根因**: `OPENCLAW_WS_URL` 配置错误，或 Gateway 未运行。

**修复**: 检查 `.env` 中的 `OPENCLAW_WS_URL`。OpenClaw Gateway 如果在宿主机运行（非容器），应使用 `ws://172.17.0.1:18789`（Docker 默认网桥网关地址）。

---

## 七、文件变更速查

需要修改/确认的文件清单：

- [ ] `.env` — 确认 `OPENCLAW_WS_URL`、`VITE_BASE_PATH` 等变量
- [ ] `Dockerfile.wattclaw` — 确认基础镜像、安装包、标签版本
- [ ] `docker-compose.wattclaw.yml` — 确认 image 标签、volume 挂载、端口映射
- [ ] `dist/` — 由 `npm run build` 生成，确认包含正确的前端资源路径

---

## 八、命令速查表

| 操作 | 命令 |
|------|------|
| 构建前端 | `VITE_BASE_PATH=/wattclaw/ npm run build` |
| 构建镜像 | `docker build -f Dockerfile.wattclaw -t wattclaw:v1.0 .` |
| 启动容器 | `docker compose -f docker-compose.wattclaw.yml up -d` |
| 停止容器 | `docker compose -f docker-compose.wattclaw.yml down` |
| 查看日志 | `docker logs -f wattclaw` |
| 进入容器 | `docker exec -it wattclaw /bin/bash` |
| 重启容器 | `docker compose -f docker-compose.wattclaw.yml restart` |

---

*文档版本: 2026-05-22*
