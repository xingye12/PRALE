# WattClaw 协作项目飞书群同步功能 — 技术实现详解

> **分析日期**：2026-07-30
> **分析范围**：前端 (Vue3/TS) → 后端 (Node.js/Express) → Gateway 插件 (wattclaw-team) → 飞书 OpenAPI
> **核心结论**：该功能是平台工程实现，不依赖 Agent 智能能力。消息同步通过事件驱动架构完成，群创建和消息投递直接调用飞书 OpenAPI。

---

## 目录

1. [架构总览](#1-架构总览)
2. [数据模型](#2-数据模型)
3. [飞书机器人绑定](#3-飞书机器人绑定)
4. [项目启动时的群创建流程](#4-项目启动时的群创建流程)
5. [运行时消息同步](#5-运行时消息同步)
6. [Gateway 插件层的双向同步](#6-gateway-插件层的双向同步)
7. [多租户路由](#7-多租户路由)
8. [RPC 调用链总览](#8-rpc-调用链总览)
9. [关键文件索引](#9-关键文件索引)

---

## 1. 架构总览

```
┌──────────────────────────────────────────────────────────────────┐
│                        前端 (Vue3 + Pinia)                         │
│  WattClawCollaborationPage.vue                                    │
│  ├─ NCheckbox "同步到飞书群"                                       │
│  ├─ startProject() → checkFeishuChannelPermission()               │
│  └─ collaborationStore.startProject(isCreateFeishuGroup)          │
└──────────────────────────┬───────────────────────────────────────┘
                           │ HTTP REST + RPC (WebSocket proxy)
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    后端 (Node.js/Express)                          │
│                                                                   │
│  server/handlers/feishu-bot.js   ← REST: /api/user/feishu-bot    │
│  server/services/feishu-project-sync.js                           │
│    ├─ enableWattClawProjectFeishuSync()  ← 创建群、写DB           │
│    ├─ syncWattClawProjectMessage()       ← SSE事件→消息转发       │
│    ├─ buildWattClawFeishuMessage()       ← 消息格式转换           │
│    └─ deliverProjectMessage()            ← 发飞书卡片消息         │
│                                                                   │
│  server/index.js (/api/rpc handler)                               │
│    ├─ callGatewayWithWattClawRuntime()   ← 编排同步逻辑           │
│    └─ gateway.on('event', ...)           ← 监听 session.message   │
│                                                                   │
│  server/core/multi-tenant-gateway.js                              │
│    └─ MultiTenantGatewayProxy           ← 多租户WS客户端路由       │
└──────────────────────────┬───────────────────────────────────────┘
                           │ WebSocket RPC
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│              Gateway 容器 (OpenClaw Gateway)                       │
│                                                                   │
│  plugins/wattclaw-team/dist/index.js                              │
│    ├─ registerGatewayMethod("wattclaw.team.channel.permission     │
│    │                        .check")    ← 权限检查 RPC            │
│    ├─ on("before_message_write", ...)   ← 双向消息同步钩子        │
│    └─ wattclaw.team.project.start       ← 项目启动(群创建由后端做) │
│                                                                   │
│  plugins/openclaw-lark/                 ← 飞书渠道插件            │
│    └─ messaging/outbound/chat-manage.js ← 群成员管理              │
└──────────────────────────┬───────────────────────────────────────┘
                           │ HTTPS
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    飞书 OpenAPI                                    │
│  POST /open-apis/auth/v3/tenant_access_token/internal             │
│  POST /open-apis/im/v1/chats                  ← 创建群            │
│  POST /open-apis/im/v1/messages                ← 发送消息          │
│  POST /open-apis/im/v1/chats/{chat_id}/members ← 成员管理         │
│  POST /open-apis/bot/v1/openclaw_bot/ping      ← 凭证校验         │
└──────────────────────────────────────────────────────────────────┘
```

**关键设计决策**：
- 飞书群的创建由 **WattClaw 后端**（`server/services/feishu-project-sync.js`）完成，而非 Gateway 插件。后端在调用 `gateway.call('wattclaw.team.project.start')` 之前先创建飞书群，然后将 `isCreateFeishuGroup: false` 转发给 Gateway。
- 运行时的消息同步由 **WattClaw 后端监听 Gateway SSE 事件** 触发，不经过前端。
- Gateway 插件层另有一套独立的 `before_message_write` 钩子，用于插件内部的飞书群↔项目双向镜像。

---

## 2. 数据模型

### 2.1 SQLite 表结构

三张表均定义在 `server/database.js`。

#### `user_feishu_bots` — 用户绑定的飞书机器人

```sql
CREATE TABLE IF NOT EXISTS user_feishu_bots (
  user_id TEXT PRIMARY KEY,              -- 关联 users 表
  app_id TEXT NOT NULL UNIQUE,           -- 飞书应用 ID (cli_xxx)
  app_secret_encrypted TEXT NOT NULL,    -- AES-256-GCM 加密的 App Secret
  owner_open_id TEXT NOT NULL,           -- 用户的飞书 OpenID (ou_xxx)
  bot_open_id TEXT,                      -- 机器人 OpenID (探测得到)
  bot_name TEXT,                         -- 机器人名称 (探测得到)
  status TEXT NOT NULL DEFAULT 'active', -- active | error
  last_error TEXT,                       -- 最近错误信息
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

**加密方案**：`app_secret` 使用 AES-256-GCM 加密。密钥由 `FEISHU_BOT_CREDENTIAL_KEY` 环境变量（或 fallback 到 `AUTH_PASSWORD`、`OPENCLAW_AUTH_TOKEN`）经 SHA-256 派生得到。密文格式：`v1:{iv_base64}:{tag_base64}:{encrypted_base64}`。

#### `wattclaw_project_feishu_sync` — 项目与飞书群的绑定

```sql
CREATE TABLE IF NOT EXISTS wattclaw_project_feishu_sync (
  project_id TEXT PRIMARY KEY,           -- 项目 ID (p-xxx)
  user_id TEXT NOT NULL,                 -- 创建者
  tenant_id TEXT,                        -- 所属租户 ID
  project_name TEXT NOT NULL,            -- 项目名称 (冗余，用于消息卡片)
  chat_id TEXT NOT NULL UNIQUE,          -- 飞书群 chat_id (oc_xxx)
  chat_name TEXT NOT NULL,               -- 飞书群名称
  members_json TEXT NOT NULL DEFAULT '[]', -- 项目成员列表 JSON (用于消息发送人名称解析)
  enabled INTEGER NOT NULL DEFAULT 1,    -- 是否启用同步
  last_sync_at INTEGER,                  -- 最近同步时间
  last_error TEXT,                       -- 最近错误
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

#### `wattclaw_project_feishu_members` — 项目 Agent 索引表

```sql
CREATE TABLE IF NOT EXISTS wattclaw_project_feishu_members (
  project_id TEXT NOT NULL,
  agent_id TEXT NOT NULL,                -- Agent ID (p-xxx-manager, p-xxx-worker1, ...)
  PRIMARY KEY (project_id, agent_id),
  FOREIGN KEY (project_id) REFERENCES wattclaw_project_feishu_sync(project_id) ON DELETE CASCADE
);
```

此表是关键的性能优化：当 Gateway 发出 `session.message` 事件时，后端从 `sessionKey` 中提取 `agentId`，通过此索引表快速查到对应的 `project_id`，再 JOIN `wattclaw_project_feishu_sync` 和 `user_feishu_bots` 获取飞书凭据和目标群 chat_id。

### 2.2 TypeScript 类型

```typescript
// src/api/types/wattclaw-team.ts
interface WattClawProject {
  // ...其他字段
  feishuSync?: {
    enabled: boolean
    chatId?: string
    chatName?: string
    error?: string
    permissionUrl?: string
  }
}
```

### 2.3 SessionKey 约定

飞书群会话使用特殊的 sessionKey 格式：

```
agent:{projectId}-manager:feishu:group:{chatId}
```

判断逻辑（插件内）：

```javascript
function isFeishuGroupSession(ctx) {
  return ctx.sessionKey?.includes(":feishu:group:")
}
```

---

## 3. 飞书机器人绑定

### 3.1 REST API

定义在 `server/handlers/feishu-bot.js`：

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/api/user/feishu-bot` | 获取当前用户绑定的机器人 |
| `PUT` | `/api/user/feishu-bot` | 绑定/更新机器人 |
| `POST` | `/api/user/feishu-bot/check` | 验证机器人凭据是否有效 |
| `DELETE` | `/api/user/feishu-bot` | 解绑（同时禁用所有项目的飞书同步） |

### 3.2 绑定流程

```
[前端 FeishuBindModal.vue]
  │
  ├── 扫码流程:
  │   1. POST /api/proxy/feishu/register { action: 'begin' }
  │      → 返回 verification_uri_complete → 渲染 QR 码
  │   2. 轮询 POST /api/proxy/feishu/poll { action: 'poll' }
  │      → 直到绑定完成
  │
  └── 手动输入流程:
      用户输入 appId, appSecret, ownerOpenId
      → PUT /api/user/feishu-bot
```

### 3.3 凭据验证

`saveUserFeishuBot()` 在存储前调用 `probeFeishuBot()`：

1. 调用 `POST /open-apis/auth/v3/tenant_access_token/internal` 获取 `tenant_access_token`
2. 调用 `POST /open-apis/bot/v1/openclaw_bot/ping` 验证凭据有效性
3. 返回 `{ botOpenId, botName }` 并写入数据库

`tokenCache`（内存 Map）缓存 tenant_access_token，按 `appId` + `secretHash` 索引，提前 60 秒过期。

### 3.4 权限验证

`verifyUserFeishuBot()` 被 `/api/user/feishu-bot/check` 调用：
- 解密存储的 `app_secret`，重新探测飞书 API
- 成功 → 更新 `status='active'`，清除 `last_error`
- 失败 → 设置 `status='error'`，记录错误信息

---

## 4. 项目启动时的群创建流程

### 4.1 前端交互

`WattClawCollaborationPage.vue` 中，当项目处于 `pending` 状态且有 worker 成员时，显示启动确认面板：

```
┌─────────────────────────────────────────┐
│  ☑ 同步到飞书群                          │
│  启动后使用你的专属机器人创建飞书项目群，    │
│  并将项目进展实时汇报到群里                │
│                                         │
│  [启动项目]                              │
└─────────────────────────────────────────┘
```

用户点击"启动项目"后的完整前端逻辑：

```typescript
// WattClawCollaborationPage.vue → startProject()
async function startProject() {
  if (syncToFeishu.value) {
    // 步骤1: 权限前置检查
    const perm = await collaborationStore.checkFeishuChannelPermission()
    if (!perm.isFeishuChannelBound) {
      // 显示"尚未绑定个人飞书机器人"错误
      return
    }
    if (!perm.hasFeishuGroupCreatePermission) {
      // 显示权限不足错误
      return
    }
  }

  // 步骤2: 启动项目
  const result = await collaborationStore.startProject(syncToFeishu.value)

  // 步骤3: 如果请求了同步但飞书群创建失败，尝试打开权限授权URL
  if (syncToFeishu.value && !result.feishuSync?.enabled && result.feishuSync?.permissionUrl) {
    window.open(result.feishuSync.permissionUrl, '_blank')
  }
}
```

Store 中的 `checkFeishuChannelPermission()` 直接调用后端 REST API：

```typescript
// src/stores/wattclaw-collaboration.ts
async function checkFeishuChannelPermission(force = false) {
  const response = await fetch(apiPath('/api/user/feishu-bot/check'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authStore.getToken()}`,
    },
    body: JSON.stringify({ force }),
  })
  const result = await response.json()
  return {
    isFeishuChannelBound: !!result.bound,
    hasFeishuGroupCreatePermission: !!result.valid,
    feishuAuthUrl: result.permissionUrl || undefined,
    error: result.error || undefined,
  }
}
```

Store 中的 `startProject()` 通过 RPC 调用：

```typescript
async function startProject(isCreateFeishuGroup = false) {
  const startedProject = await wsStore.rpc.startWattClawProject(
    projectId.value, isCreateFeishuGroup
  )
  // 合并返回的 feishuSync 到本地 project 状态
  if (startedProject.feishuSync) {
    project.value = { ...project.value, feishuSync: startedProject.feishuSync }
  }
}
```

### 4.2 后端 RPC 处理

入口：`POST /api/rpc` → `server/index.js` 中的 `callGatewayWithWattClawRuntime()`

完整流程图：

```
callGatewayWithWattClawRuntime()
  │
  ├── 1. requireWattClawProjectAccess()
  │      └── 管理员: resolveWattClawProjectTenant() 跨租户解析
  │          非管理员: 所有权校验
  │
  ├── 2. params.isCreateFeishuGroup === true ?
  │      ├── getUserFeishuBot(userId)          ← 检查机器人已绑定
  │      └── verifyUserFeishuBot(userId)       ← 验证凭据有效
  │
  ├── 3. prepareWattClawProjectStart()         ← 准备启动
  │
  ├── 4. enableWattClawProjectFeishuSync()     ← 🔑 创建飞书群
  │      │
  │      ├── 检查是否已有 enabled 绑定 → 有则直接返回
  │      ├── getBotRow(userId) → 获取加密凭据
  │      ├── credentialsFromRow() → 解密 appSecret
  │      ├── createFeishuProjectChat()
  │      │     POST https://open.feishu.cn/open-apis/im/v1/chats
  │      │       ?user_id_type=open_id
  │      │     Body: {
  │      │       name: "{projectName}项目群",
  │      │       description: "...",
  │      │       owner_id: "<user openId>",
  │      │       user_id_list: ["<user openId>"],
  │      │       set_bot_manager: false,
  │      │       uuid: md5("project-chat:{projectId}")  ← 幂等
  │      │     }
  │      │     → { chatId, chatName }
  │      │
  │      ├── TRANSACTION:
  │      │     UPSERT wattclaw_project_feishu_sync
  │      │     + replaceProjectMembers() → wattclaw_project_feishu_members
  │      │
  │      └── sendIntro=false → 暂不发送介绍卡片
  │
  ├── 5. gateway.call('wattclaw.team.project.start', {
  │        ...params,
  │        isCreateFeishuGroup: false   ← 后端已处理群创建, 通知插件跳过
  │    })
  │    失败时 → disableWattClawProjectFeishuSync(projectId, reason)
  │
  ├── 6. registerWattClawProject(project, runtimeAgents)
  │      → 注册所有权 (user_agents, user_sessions)
  │
  └── 7. sendWattClawProjectFeishuIntro(project, userId)
         → 发送飞书互动卡片 (schema 2.0)
         Header: 项目名 + "WattClaw 协作项目已启动"
         Body: 项目描述 + 成员列表
```

### 4.3 飞书群创建 API 详解

调用飞书 OpenAPI 的 `POST /open-apis/im/v1/chats`：

| 参数 | 值 | 说明 |
|------|-----|------|
| `name` | `"{projectName}项目群"` | 群名称 |
| `description` | 项目描述 | 群描述 |
| `owner_id` | 用户的飞书 OpenID | 群主 |
| `user_id_list` | `[ownerOpenId]` | 初始成员（仅创建者自己） |
| `set_bot_manager` | `false` | 不将机器人设为管理员 |
| `uuid` | `md5("project-chat:{projectId}")` | 确定性 UUID，用于幂等（重复调用不会创建多个群） |

### 4.4 介绍卡片

`sendWattClawProjectFeishuIntro()` 在项目启动成功后发送。卡片结构：

```json
{
  "schema": "2.0",
  "config": { "wide_screen_mode": true, "enable_forward": true },
  "header": {
    "template": "blue",
    "title": { "tag": "plain_text", "content": "<项目名>" },
    "subtitle": { "tag": "plain_text", "content": "WattClaw 协作项目已启动" }
  },
  "body": {
    "elements": [
      { "tag": "markdown", "content": "<项目描述>" },
      { "tag": "hr" },
      { "tag": "markdown", "content": "- **成员名 · 角色**\n  `agentId`\n..." }
    ]
  }
}
```

### 4.5 错误处理

飞书群创建失败时，后端**不会抛出异常阻断项目启动**，而是返回带有错误信息的 project 对象：

```javascript
return {
  ...authorizedWattClawProject,
  feishuSync: {
    enabled: false,
    error: error.message,
    permissionUrl: getFeishuPermissionUrl(bot?.appId),
  },
}
```

前端据此判断：若 `feishuSync.enabled === false` 且有 `permissionUrl`，则打开授权页面让用户补充权限。

---

## 5. 运行时消息同步

### 5.1 触发机制

WattClaw 后端通过监听 Gateway 的 SSE 事件流来实现消息同步。在 `server/index.js` 中注册了两个监听点（初始连接 + 重连）：

```javascript
// 初始连接
gateway.on('event', (event, payload) => {
  if (event === 'session.message') {
    syncWattClawProjectMessage(payload).catch(err => {
      console.error('[FeishuProjectSync] event handling failed:', err.message)
    })
  }
  // ...其他事件处理
})

// 重连后同样注册
newGw.on('event', (event, payload) => {
  if (event === 'session.message') {
    syncWattClawProjectMessage(payload).catch(err => {
      console.error('[FeishuProjectSync] event handling failed:', err.message)
    })
  }
})
```

**关键点**：消息同步完全在后端完成，不经过前端。Gateway 每次产生新消息都会触发 `session.message` 事件，后端拦截后异步处理。

### 5.2 `syncWattClawProjectMessage(payload)`

`server/services/feishu-project-sync.js` 中的入口函数：

```javascript
export async function syncWattClawProjectMessage(payload) {
  // 1. 从 sessionKey 提取 agentId
  //    sessionKey 格式: "agent:{agentId}:main" 或 "agent:{agentId}:..."
  const sessionKey = String(payload?.sessionKey || payload?.session_key || payload?.key || '')
  const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
  if (!agentId || !payload?.message) return

  // 2. 查找所有启用了飞书同步且包含此 agent 的项目绑定
  const bindings = projectBindingsForAgent(agentId, payload.tenantId)

  // 3. 并发投递到每个飞书群
  await Promise.allSettled(bindings.map(binding => deliverProjectMessage(payload, binding)))
}
```

### 5.3 `projectBindingsForAgent(agentId, tenantId)`

三表 JOIN 查询：

```sql
SELECT sync.*, bot.app_id, bot.app_secret_encrypted, bot.status AS bot_status
FROM wattclaw_project_feishu_members member
JOIN wattclaw_project_feishu_sync sync ON sync.project_id = member.project_id
JOIN user_feishu_bots bot ON bot.user_id = sync.user_id
WHERE member.agent_id = ?
  AND sync.enabled = 1
  AND bot.status = 'active'
  AND (? IS NULL OR sync.tenant_id IS NULL OR sync.tenant_id = ?)
```

通过 `wattclaw_project_feishu_members` 索引表实现 O(1) 的 agent→project 查找。

### 5.4 `buildWattClawFeishuMessage(payload, binding)` — 消息转换

将 Gateway 的原始消息转换为飞书卡片所需的结构化数据。按消息角色分三种情况：

#### 情况 1：用户消息 (role='user')

- 过滤通知标记：跳过包含 `"_isNotification":true` 的消息
- 检测外部发送者：通过正则匹配 `Sender (untrusted metadata):` 约定（外部渠道如 webchat 使用此格式标记发送者身份）
- 输出：
  ```javascript
  {
    fromAgentId: 'external-user',
    senderDisplayName: '用户' | metadata.name,
    senderKind: 'external_user',
    toAgentId: agentId,
    content: '...',
    headerTemplate: 'blue'
  }
  ```

#### 情况 2：Agent 间工具调用 (role='assistant' + `wattclaw_team_message_send`)

- 从 toolCall arguments 提取 `from_id`, `to_id`, `content`
- 从 `members_json` 解析显示名称
- 输出：
  ```javascript
  {
    fromAgentId: 'p-xxx-manager',
    senderDisplayName: '项目经理',
    senderKind: 'agent',
    toAgentId: 'p-xxx-worker1',
    content: '...',
    headerTemplate: 'yellow' // manager
  }
  ```

#### 情况 3：普通 Agent 回复 (role='assistant')

- 提取文本内容，过滤 `NO_REPLY`
- 输出：
  ```javascript
  {
    fromAgentId: agentId,
    senderDisplayName: memberName(members, agentId),
    senderKind: 'agent',
    toAgentId: agentId,
    content: '...',
    headerTemplate: 'wathet' // worker | 'yellow' // manager | 'grey' // other
  }
  ```

**卡片头部颜色规则**：
| 条件 | template |
|------|----------|
| `senderKind === 'external_user'` | `blue` |
| `agentId.endsWith('-manager')` | `yellow` |
| `agentId.includes('-worker')` | `wathet` |
| 其他 | `grey` |

### 5.5 `deliverProjectMessage(payload, binding)` — 消息投递

```javascript
async function deliverProjectMessage(payload, binding) {
  // 1. 构建飞书消息结构
  const message = buildWattClawFeishuMessage(payload, binding)
  if (!message?.content) return

  // 2. 去重
  const dedupeKey = messageDedupeKey(payload, binding, message)
  clearExpiredMessageCache()  // 清理超过 10 分钟的缓存
  if (messageInFlight.has(dedupeKey) || recentMessages.has(dedupeKey)) return
  messageInFlight.add(dedupeKey)

  try {
    // 3. 发送飞书互动卡片
    await sendCard(
      { appId: binding.app_id, appSecret: decryptFeishuSecret(binding.app_secret_encrypted) },
      binding.chat_id,
      messageCard(message, binding),
      `project-message:${dedupeKey}`
    )
    // 4. 更新同步状态
    recentMessages.set(dedupeKey, Date.now())
    db.prepare(`UPDATE wattclaw_project_feishu_sync
      SET last_sync_at = ?, last_error = NULL, updated_at = ?
      WHERE project_id = ?`).run(now, now, binding.project_id)
  } catch (error) {
    db.prepare(`UPDATE wattclaw_project_feishu_sync
      SET last_error = ?, updated_at = ?
      WHERE project_id = ?`).run(error.message, Date.now(), binding.project_id)
  } finally {
    messageInFlight.delete(dedupeKey)
  }
}
```

### 5.6 去重机制

双层去重：

1. **`messageInFlight`**（`Set`）：正在发送中的消息，防止并发重复
2. **`recentMessages`**（`Map<key, timestamp>`）：已发送的消息，TTL 10 分钟，防止重放

去重 key 由 `project_id + sessionKey + messageId + content` 拼接，确保同一条消息不会重复投递。

### 5.7 飞书卡片消息 API

发送接口：`POST /open-apis/im/v1/messages?receive_id_type=chat_id`

```json
{
  "receive_id": "oc_xxx",
  "msg_type": "interactive",
  "content": "{飞书卡片 JSON (schema 2.0)}",
  "uuid": "md5('project-message:{dedupeKey}')"
}
```

卡片结构：
```json
{
  "schema": "2.0",
  "config": { "wide_screen_mode": true, "enable_forward": true },
  "header": {
    "template": "yellow|blue|wathet|grey",
    "title": { "tag": "plain_text", "content": "发送者名称" },
    "subtitle": { "tag": "plain_text", "content": "发送给 @接收者" }
  },
  "body": {
    "elements": [{ "tag": "markdown", "content": "消息内容..." }]
  }
}
```

### 5.8 消息内容清洗

`cleanContent()` 函数处理：
- 移除 `<relevant-memories>...</relevant-memories>` 标签
- 移除末尾的 `<team-project-download .../>` 元素
- 截断到 12000 字符（`MAX_CARD_CONTENT_LENGTH`）

---

## 6. Gateway 插件层的双向同步

WattClaw 后端已完成主要的单向（项目→飞书）消息同步。此外，Gateway 内的 `wattclaw-team` 插件还实现了一套独立的双向同步机制。

### 6.1 `before_message_write` 钩子

插件注册：

```javascript
pluginApi.on("before_message_write", (event, context) => {
  handleMessageWrite(pluginApi, event, context)
})
```

### 6.2 双向路由逻辑

```javascript
async function handleMessageWrite(pluginApi, event, context) {
  // 情况 1: 消息来自飞书群会话 → 镜像到项目主会话 (INBOUND)
  if (context.sessionKey?.includes(":feishu:group:")) {
    const mainSessionKey = context.sessionKey.replace(/:feishu:group:[^:]+$/, ":main")
    // 将用户消息镜像到项目的 main session
    await mirrorToMainSession({ agentId, sessionKey: mainSessionKey, message })
    return
  }

  // 情况 2: 消息来自项目会话 → 转发到飞书群 (OUTBOUND)
  const project = await getProject(context)
  if (project?.feishuChatId) {
    await forwardToFeishuGroup({
      agentId: context.agentId,
      sessionKey: context.sessionKey,
      chatId: project.feishuChatId,
      message: event.message
    })
  }
}
```

### 6.3 防循环机制

通过 sessionKey 格式天然防循环：
- 飞书群的 sessionKey 包含 `:feishu:group:` → 只做 INBOUND 镜像，不反向转发
- 项目主会话以 `:main` 结尾 → 只做 OUTBOUND 转发，不再次镜像

### 6.4 与 WattClaw 后端同步的关系

两套同步机制互补：
- **WattClaw 后端**（`syncWattClawProjectMessage`）：基于 SSE 事件，处理项目内 Agent 消息→飞书群（OUTBOUND），使用用户个人绑定的机器人凭据
- **Gateway 插件**（`before_message_write`）：基于会话写入钩子，同时处理 INBOUND（飞书群→项目）和 OUTBOUND（项目→飞书群），使用渠道配置中的飞书应用凭据

---

## 7. 多租户路由

### 7.1 权限检查 (`wattclaw.team.channel.permission.check`)

该方法**不是** project-scoped（以 `wattclaw.team.channel.` 开头而非 `wattclaw.team.project.`），因此在 `callGatewayWithWattClawRuntime()` 中走 fallthrough 路径：

```javascript
// 直接转发给当前请求租户的 Gateway
result = await gateway.call(method, forwardedParams)
```

Gateway 将 RPC 分发给 `wattclaw-team` 插件，插件内置的 handler 检查飞书渠道绑定状态和 `im:chat:create` 权限。

**注意**：WattClaw 前端的 `checkFeishuChannelPermission()` 实际上调用的是后端 REST API `POST /api/user/feishu-bot/check`（验证用户绑定的机器人凭据），而非直接调用 Gateway 的 `wattclaw.team.channel.permission.check` RPC。两者验证的是不同的东西：
- REST API：验证用户个人绑定的飞书机器人 App 凭据是否有效
- Gateway RPC：验证 Gateway 渠道配置中的飞书应用是否有 `im:chat:create` 权限

### 7.2 项目启动 (`wattclaw.team.project.start`)

对于跨租户管理场景：
- 飞书群的创建在 WattClaw 后端完成（使用 WattClaw 共享 SQLite 中的用户凭据），不依赖 Gateway
- 项目启动的 Gateway RPC 调用通过 `resolveWattClawProjectTenant()` 路由到正确的租户 Gateway 容器
- `tenant_id` 记录在 `wattclaw_project_feishu_sync` 表中，用于消息同步时的租户过滤

### 7.3 成员信息刷新

在 `wattclaw.team.project.get` 被调用时（前端每 5 秒轮询），非管理员用户会触发：

```javascript
if (!isAdmin) {
  registerWattClawProject(authorizedWattClawProject, [])
  refreshWattClawProjectFeishuMembers(authorizedWattClawProject)
}
```

`refreshWattClawProjectFeishuMembers()` 更新 `members_json` 和 `wattclaw_project_feishu_members` 索引表，确保消息同步时能正确解析发送者名称。

---

## 8. RPC 调用链总览

### 8.1 项目启动（创建飞书群）

```
[用户点击 "启动项目" (勾选了"同步到飞书群")]
  │
  ▼
[前端] WattClawCollaborationPage.vue → startProject()
  │
  ├── checkFeishuChannelPermission()
  │     └── POST /api/user/feishu-bot/check
  │           └── verifyUserFeishuBot(userId)
  │                 └── probeFeishuBot() → GET token → POST bot/ping
  │
  └── startProject(isCreateFeishuGroup=true)
        └── rpc-client.startWattClawProject(id, true)
              └── POST /api/rpc
                    { method: "wattclaw.team.project.start",
                      params: { id, isCreateFeishuGroup: true } }
                    │
                    ▼
              [后端] server/index.js → callGatewayWithWattClawRuntime()
                    │
                    ├── requireWattClawProjectAccess()
                    ├── getUserFeishuBot(userId)
                    ├── verifyUserFeishuBot(userId)
                    ├── prepareWattClawProjectStart()
                    ├── enableWattClawProjectFeishuSync({...})
                    │     └── createFeishuProjectChat()
                    │           └── POST open.feishu.cn/open-apis/im/v1/chats
                    │                 → { chatId: "oc_xxx", chatName: "..." }
                    │
                    ├── gateway.call('wattclaw.team.project.start',
                    │                  { id, isCreateFeishuGroup: false })
                    │     └── [Gateway wattclaw-team 插件] 启动项目
                    │
                    ├── registerWattClawProject(project, agents)
                    └── sendWattClawProjectFeishuIntro(project, userId)
                          └── POST open.feishu.cn/open-apis/im/v1/messages
                                → 介绍卡片
```

### 8.2 运行时消息同步

```
[Gateway Agent 产生消息]
  │
  ▼
[Gateway] 触发 session.message 事件
  │
  ▼
[后端] gateway.on('event', ...) 监听器
  │
  ▼
syncWattClawProjectMessage(payload)
  │
  ├── sessionKey → 正则提取 agentId
  ├── projectBindingsForAgent(agentId, tenantId)
  │     └── SQL: member JOIN sync JOIN bot
  │
  └── Promise.allSettled(
        bindings.map(binding => deliverProjectMessage(payload, binding))
      )
        │
        ├── buildWattClawFeishuMessage(payload, binding)
        │     ├── role='user' → 用户消息 (外部发送者检测)
        │     ├── role='assistant' + toolCall → Agent 间消息
        │     └── role='assistant' + text → Agent 回复
        │
        ├── 去重检查 (inFlight + recentMessages)
        │
        └── sendCard(credentials, chatId, card, uuid)
              └── POST open.feishu.cn/open-apis/im/v1/messages
                    msg_type=interactive, schema=2.0
```

### 8.3 项目删除

```
[用户删除项目]
  │
  ▼
gateway.call('wattclaw.team.project.delete', { id })
  │
  ▼
[后端] callGatewayWithWattClawRuntime()
  │
  └── 成功后: disableWattClawProjectFeishuSync(projectId, '项目已删除')
        └── UPDATE wattclaw_project_feishu_sync
            SET enabled = 0, last_error = '项目已删除'
```

---

## 9. 关键文件索引

| 文件 | 职责 |
|------|------|
| `server/services/feishu-project-sync.js` | **核心服务**：凭据加密/解密、群创建、消息构建、消息投递、成员管理、机器人 CRUD |
| `server/handlers/feishu-bot.js` | REST API 路由：机器人的绑定/查询/验证/解绑 |
| `server/index.js:530-536` | SSE 事件监听：拦截 `session.message` 触发消息同步 |
| `server/index.js:1006-1118` | RPC 处理：`callGatewayWithWattClawRuntime()` 编排飞书同步与项目启动 |
| `server/database.js:424-466` | SQLite 表定义：`user_feishu_bots`, `wattclaw_project_feishu_sync`, `wattclaw_project_feishu_members` |
| `server/core/multi-tenant-gateway.js` | 多租户 WS 客户端路由、插件 provision |
| `plugins/wattclaw-team/dist/index.js` | Gateway 插件：`before_message_write` 双向同步、`channel.permission.check` RPC |
| `plugins/wattclaw-team/openclaw.plugin.json` | 插件清单 |
| `plugins/wattclaw-team/config/feature-gates.json` | 功能开关：`team.project.feishu_group` |
| `src/stores/wattclaw-collaboration.ts` | 前端 Store：`startProject()`, `checkFeishuChannelPermission()` |
| `src/views/wattclaw-collaboration/WattClawCollaborationPage.vue` | 前端 UI："同步到飞书群"复选框 + 启动流程 |
| `src/api/rpc-client.ts:2125` | RPC 客户端：`startWattClawProject(id, isCreateFeishuGroup)` |
| `src/api/types/wattclaw-team.ts` | 类型定义：`WattClawProject.feishuSync` |
| `src/components/feishu/FeishuBindModal.vue` | 机器人绑定弹窗（扫码 + 手动输入） |
| `src/components/layout/UserMenuDropdown.vue` | "我的机器人"菜单入口 |
| `src/i18n/messages/zh-CN.ts` | 飞书相关 i18n 文案（仅中文） |
| `docs/arkclaw-feishu-group-sync-implementation.md` | 实现分析参考文档 |
