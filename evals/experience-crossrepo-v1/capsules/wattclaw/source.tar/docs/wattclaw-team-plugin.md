# WattClaw Team 插件（wattclaw-team）说明文档

> 面向 WattClaw「团队协作模式」背后的 OpenClaw Gateway 插件 `wattclaw-team` 的能力梳理：它注册了哪些 **Tool**、内置了哪些 **Skill**、这些能力如何协同，以及关键实现机制。
>
> 插件目录：`plugins/wattclaw-team/`（`openclaw.plugin.json` + `package.json` + `dist/index.js`（打包产物）+ `skills/` + `config/`）。
> 与之配套的前端实现见 `docs/wattclaw-collaboration-frontend.md`。

---

## 0. 插件定位

`wattclaw-team` 是安装到每个 OpenClaw Gateway 租户容器（`openclaw-le-N`）里的一个 **onStartup 插件**。它把「多智能体团队协作」的运行时能力注入 Gateway：

- 向 Agent（Manager / Worker）暴露一组 **协作 Tool**（任务、项目、成员、反馈、消息）。
- 打包一批 **可复用 Skill**（项目规划、前端开发、PRD、图/视频生成、视频剪辑、设计规范下载）。
- 后台常驻 **领队控制器（Lead Controller）** 服务，负责任务派发驱动、超时检测、心跳。
- 后台 **指标上报服务**（OpenTelemetry，可选）。
- 注册 `/acteam` **CLI 命令**用于查看状态 / 管理项目。

插件元数据（`openclaw.plugin.json`）：

```jsonc
{
  "id": "wattclaw-team",
  "name": "WattClaw Team Plugin",
  "description": "WattClaw Team plugin with im/doc/wiki/drive/task/calendar tools",
  "activation": { "onStartup": true },
  "contracts": { "tools": [ ...见下 ] },
  "skills": [ "skills" ]
}
```

> 数据落盘根目录：`~/.openclaw/.wattclaw-team/`，其下有 `projects/`（项目）、`agents/`、`experts.json`、`messages/`、`logs/`、`archives/`、`config.json`。所有 Tool/Skill 都围绕这套本地文件状态 + Gateway RPC 运作。

---

## 1. 插件注册的 Tool（对 Agent 暴露）

`openclaw.plugin.json` 的 `contracts.tools` 声明了 **9 个** 对协作 Agent 暴露的工具，运行时通过 `api.registerTool({ name, label, description, parameters, execute })` 注册（参数 schema 用 TypeBox `G.Object(...)`）。工具名统一前缀 `wattclaw_team_`（代码常量 `_t="wattclaw_team"`）。

| Tool 名 | Label | 作用 | 关键参数 |
|---------|-------|------|----------|
| `wattclaw_team_task_batch_create` | Batch Create Tasks | 批量创建任务（项目初始化 or 追加返工任务），创建后为 `Pending` | `projectId`, `tasks[]`（`taskName`/`agentId`/`content`/`stageId`/`stageName`/`dependencies?`/`taskId?`） |
| `wattclaw_team_task_list` | List Tasks | 列出项目任务，或按 `taskId` 取单个任务详情（含反馈/评论）；可按 `status`/`agentId` 过滤 | `projectId`, `taskId?`, `agentId?`, `status?` |
| `wattclaw_team_task_update_status` | Task Update | 更新任务状态 / 编辑任务属性 / 删除任务（`action=update_status\|edit\|delete`） | `projectId`, `taskId`, `status`/`outputs[]`（成功时必填，须绝对路径且带扩展名） |
| `wattclaw_team_task_feedback` | Task Feedback | 在任务节点上留言/反馈；Manager 可对 `Block` 任务 `retry=true` 重置为 `InProgress`；`mentions[]` 通知指定成员 | `projectId`, `taskId`, `agentId`, `message`, `mentions?`, `needReply?` |
| `wattclaw_team_project_status` | Check Project Status | 查询项目状态 | `id` |
| `wattclaw_team_project_status_update` | Update Project Status | 更新项目状态（`planning\|in_progress\|success\|failed` 等） | `id`, `status` |
| `wattclaw_team_project_list_members` | List Project Members | 列出项目全部成员的 Name + AgentID（供 `mentions` 查名用） | `id` |
| `wattclaw_team_project_output` | Get Project Output dir | 获取项目产出目录 | `id` |
| `wattclaw_team_project_output_pack` | Project Output pack | 打包项目产出目录（用于下载交付物） | `id` |

### 1.1 任务状态机

任务状态流转（工具描述里内嵌 `Status transition rules`）：

```
Pending → Dispatched → InProgress → Success / Failed / Unknown
                         ↘ Block ↗（Manager 可 retry 回到 InProgress）
```

规则要点（写在工具 description 中，作为对 Agent 的约束）：

- **命名规范**：`taskId = {projectId}-task-{n}`（如 `p-123-task-1`）；`stageId = {projectId}-stage-{n}`；每个任务必须归属某个 stage。
- **权限**：Manager 可改任意任务状态；Worker 只能改属于自己的任务且不能置为 `Dispatched`；任何人都不能把任务改回 `Pending`。
- **时间戳**：置 `InProgress` 记录 start time；置终态记录 finish time。
- **产出**：置 `Success` 必须提供 `outputs[]`（`name`+`path`），路径须为**绝对路径/完整 URL**、**不得含通配符**、**必须带文件扩展名**，目录产出用尾部 `/`；`name` 唯一。
- 当任务被置为 `Dispatched`，Lead Controller 会**自动通知**对应 Worker 开始工作（见第 3 节）。

### 1.2 内部 / 隐式 Tool

除上面 9 个契约工具外，代码里还引用了未列入 `contracts` 的名字：

- `wattclaw_team_message_send`：Agent 间点对点消息工具（`to_id`/`from_id`/`content`），用于团队成员在协作中互相通知；由 `EnableAgentMessaging` 开关控制是否启用。
- `sessions_send` / `sessions_spawn`：Gateway 原生会话工具，被协作流程复用（成员会话拉起、发送消息）。
- 内部指标名（非 Tool，OTel 指标）：`wattclaw_team_agent_run_token_usage`、`wattclaw_team_agent_lifecycle`、`wattclaw_team_cron_job_mapping`。

---

## 2. 插件打包的 Skill

`openclaw.plugin.json` 的 `"skills": ["skills"]` 表示把 `plugins/wattclaw-team/skills/` 目录整体作为技能包随插件安装。每个子目录含一个 `SKILL.md`（Frontmatter：`name`/`description`），部分带 `scripts/`。

| Skill | 用途 | 附带脚本 |
|-------|------|----------|
| **wattclaw-team-project-builder** | 项目经理核心 Skill：意图识别 → 澄清 → 规划团队 → 一键建团；以及项目运行期成员增删改、项目信息修改。通过 `openclaw gateway call` 落地 RPC。 | `prepare_data.py`, `load_data.py`, `create_team.py`, `finalize.py`, `find-skills.py` |
| **prd-developer** | 产品需求文档（PRD）撰写：需求分析、用户故事、功能规格、验收标准。 | — |
| **getdesign-md** | 从 getdesign.md 下载知名品牌设计系统文档（DESIGN.md）作为前端风格参考。 | — |
| **vite-react-tailwind** | Vite + React + TailwindCSS v4 + lucide-react 前端项目搭建与开发流程。 | — |
| **byted-teamproject-image-generate** | 火山引擎 Seedream 文生图/图生图（4.0/4.5/5.0-lite）。 | `seedream_image_generate.py` |
| **byted-teamproject-video-generate** | 豆包 Seedance 1.0/1.5 视频生成（文/图/参考素材生视频）。 | `video_generate.py` |
| **video-editor** | 视频后期：合并视频、加音轨、合并音频、生成/烧录字幕。 | `video_editor.py` |

> 这些 Skill 覆盖「一个内容/产品团队」的常见职能：项目经理规划（builder）、产品经理（prd）、前端开发（vite-react-tailwind + getdesign-md）、多媒体产出（image/video generate + video-editor）。Manager 规划团队时会把这些 Skill 按角色分配给不同 Worker。

### 2.1 核心 Skill：wattclaw-team-project-builder

这是整个协作模式的入口 Skill，Manager 收到「创建项目 / 调整项目」指令时**必须**使用。流程：

1. **意图识别**：需求清晰 → 直接规划；不清晰 → 先 `wattclaw.team.project.status.update` 置 `waiting`，向用户提 1~3 个问题，澄清后置回 `creating`。
2. **规划前收集参考**：`prepare_data.py` 一次性拉取
   - `projectTemplates` / `agentTemplates`：远程项目 & Agent 模板；
   - `skills`（本地已装）+ `remoteSkills`（远程可装，建团时自动安装）；
   - `agents`：当前已注册的非项目 Agent（可作模板）。
   - 若模板服务不可用（均为空数组）→ 直接基于需求规划，不重试。
   - 找不到合适 Skill 时用 `find-skills.py find "<关键词>"` 搜索远程 Skill 仓库。
3. **规划团队**：拆 3~6 个 expert，每个含 `name`（≤24 字）/`role`/`soul`（**必须结构化**：核心职责/输入来源/输出要求/协作边界）/`skills`（名称须**原样使用**含命名空间前缀，如 `clawhub/xxx/yyy`，不得截断）。
4. **一键建团**：`create_team.py <projectId> @/tmp/team.json` 一次性完成「项目更新 + 成员创建 + finalize」，回复末尾输出 `<team-project-start-confirm/>` 标签供前端渲染「启动项目」按钮。
5. **调整项目**（运行期）：`wattclaw.team.project.update` 改信息、`wattclaw.team.project.member.batch_add` 增、`wattclaw.team.project.member.update` 改、`wattclaw.team.project.member.delete` 删；调整后**必须** `finalize.py`。

约束（SKILL.md「严格约束」）：RPC 必须 `--json` + `jq` 裁剪；含中文/多行的 JSON 必须**先写文件再 `$(cat)`**，禁止命令行内嵌复杂 JSON；建团用 `create-team` 一次完成、不分步；建团成功后只反馈、不自动进入项目执行。

---

## 3. 后台常驻服务（Service）

插件在 `registerService(...)` 注册两个长期运行服务：

### 3.1 领队控制器（Lead Controller）

- 配置项（`configSchema`）：`LeadCtrlStateFile`（状态文件）、`LeadCtrlTickInterval`（检查间隔，默认 10s）、`LeadCtrlBaseInterval`（起始间隔，默认 60s）、`LeadCtrlBackOffRatio`（退避倍率，默认 1.2）、`LeadCtrlMaxBackOffs`（最大退避 10 次）。
- `onTick` 心跳逻辑（约每 `TickInterval` 一次）：
  - 读取所有活跃项目 + 任务快照；
  - 驱动任务派发：`Dispatched` 的任务自动通知对应 Worker 开始工作；
  - 超时检测：`TaskTimeoutMs`（默认 10min）任务超时、`SessionInactiveMs`（默认 10min）会话不活跃判定；
  - 采用**退避**策略避免空转（无任务时逐步拉长轮询间隔）。
- `EnableAgentMessaging`（默认 false）：是否启用 Agent 间消息交流机制（`wattclaw_team_message_send`）。

### 3.2 指标上报服务（Metrics Reporter）

- `id: wattclaw-team-metrics-reporter`，按 `MetricsReportInterval`（默认 5min）周期上报。
- 通过 OpenTelemetry 导出 Trace / Metric / Log（`OtelTraceExporter` / `OtelMetricExporter` / `OtelLogExporter` 可分别配置 URL、批量、超时、`disabled`）。
- 指标示例：`wattclaw_team_agent_run_token_usage`（token 消耗）、`wattclaw_team_agent_lifecycle`（Agent 生命周期）、`wattclaw_team_cron_job_mapping`（每个 agent-template/cron-template 映射下的活跃 cron 数）。

---

## 4. CLI 命令

注册命令 `/acteam`（`registerCommand`，`acceptsArgs:true`, `requireAuth:true`），子命令：

- `acteam status` — 显示插件版本 + 运行时长；
- `acteam help` — 帮助；
- `acteam list_projects`（`projects`）— 列出项目；
- `acteam delete_project <projectId>` — 删除指定项目。

---

## 5. Feature Gates（能力灰度）

`config/feature-gates.json` 定义按**版本 + 版本号 + edition** 灰度的能力开关，edition 分 `wattclaw` / `wattclaw_enterprise`。挑选关键项：

| Feature | 说明 | Editions |
|---------|------|----------|
| `team.agent` | 团队 Agent 能力 | `wattclaw` |
| `team.agent.channels` / `.discord_telegram` / `.check_view` | Agent 渠道绑定（含 Discord/Telegram） | 两版 |
| `team.agent.models` / `team.agent.tools` | Agent 可配模型 / 工具 | 两版 |
| `team.project.feishu_group` | 项目同步到飞书群 | 两版 |
| `team.project.task_dashboard` / `.task_dashboard_stage` | 任务看板 / 阶段视图 | 两版 |
| `team.project.token_status` | 项目 token 用量 | 两版 |
| `team.project.support_multilingual` | 项目多语言 | 两版 |
| `team.project.build` | 项目产物构建 | 两版 |
| `team.project.recall_main_memory` | 主记忆召回 | 两版 |
| `team.models.custom_model` / `team.gateway.feature-gates` | 自定义模型 / 网关级 gate | 仅 `wattclaw_enterprise` |
| `team.agent.skills.multi_version` / `.share`、`team.main_agent_upload_skill`、`wattclaw.main_agent.pack`、`wattclaw.env.update`、`team.larkcli.auth_status` | Skill 多版本/共享、主 Agent 上传 Skill/打包、环境更新、飞书 CLI 授权状态 | 两版 |

---

## 6. 与前端 / 后端的关系

- **前端（WattClaw dashboard）**：协作页面 → Pinia `useWattClawCollaborationStore` → `rpc-client.ts` 调 `wattclaw.team.project.*` RPC；实时事件经 SSE 回流。详见 `docs/wattclaw-collaboration-frontend.md`。
- **后端（server/）**：`server/index.js` 做 `/api/rpc` 权限层与多租户隔离，`server/services/wattclaw-project-runtime.js` 里 `trackWattClawProjectOwnership` 遍历 `project.members` 做归属追踪。
- **Gateway RPC 方法**（后端代理，`server/` 中出现）：`wattclaw.team.project.{create,get,list,update,start,activate,archive,retry,build,delete}`、`wattclaw.team.project.member.{batch_add,update,delete}`、`wattclaw.team.project.status.update`、事件 `wattclaw.team.project.updated` / `wattclaw.team.tasks.updated`。
- **本插件的 Tool** 则是给 **Agent（Manager/Worker）在会话内调用**的（任务/反馈/产出），与前端调用的 project.* RPC 分属两个层面：前端管「项目/成员生命周期」，Tool 管「项目内任务协作执行」。

### 数据流总览

```
用户自然语言目标
  → Manager Agent 调用 wattclaw-team-project-builder Skill
      → openclaw gateway call wattclaw.team.project.*（建/改团队）
  → 用户点「启动项目」→ wattclaw.team.project.start
  → Manager 用 wattclaw_team_task_batch_create 拆任务 → update_status=Dispatched
      → Lead Controller 心跳检测 Dispatched → 通知对应 Worker
      → Worker 执行（可能用 prd/vite/image/video 等 Skill）→ update_status=Success + outputs[]
      → 任意成员用 wattclaw_team_task_feedback 留言 / mentions 通知
  → Manager 汇总 → project_output_pack → 交付物下载
  → 全程指标经 Metrics Reporter 上报 OTel
```

---

## 7. 关键实现要点小结

- **状态存放本地文件**（`~/.openclaw/.wattclaw-team/`），Tool 直接读写这些文件，Lead Controller 周期扫描驱动流转。
- **打包产物** `dist/index.js`（esbuild bundle，minified，含 OTel 依赖）；源码 `index.ts` + `src/`（仓库中仅保留打包产物与 skills）。`.gitignore` 通常忽略 `dist/`，部署到租户时按 mtime/指纹安装。
- **工具约束以 description 承载**：任务命名规范、状态机、权限、产出路径规则都写进各 Tool 的 `description` 字符串，作为对 LLM Agent 的硬约束。
- **Skill 与 Tool 分工**：Skill 是「给 Agent 读的操作手册 + 脚本」（规划、开发、生成内容），Tool 是「Agent 可调用的结构化动作」（任务/项目/反馈状态变更）。
