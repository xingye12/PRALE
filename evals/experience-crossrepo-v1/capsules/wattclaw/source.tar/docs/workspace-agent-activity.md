# Workspace Agent 活动记录嵌入消息流

## 目标

在 Workspace 页面的消息流中，实时展示 Agent 的思考过程、工具调用过程、命令输出，作为消息的一种格式嵌入，按时间顺序与用户消息/助手消息交错排列。切页不丢失。

## 涉及文件

| 文件 | 改动量 | 作用 |
|------|--------|------|
| `src/stores/workspace.ts` | +286 行 | Store 层：解析 agent 事件，维护活动列表 |
| `src/views/workspace/MessageList.vue` | +402/-76 行 | UI 层：统一时间线、活动卡片渲染 |
| `src/views/workspace/WorkspacePage.vue` | 无改动 | 不需要改动 |

> `src/stores/chat.ts` 和 `src/views/chat/ChatPage.vue` 也有类似改动，但那些是 Chat 页面的，与 Workspace 无关。

## 架构设计

```
Gateway (WebSocket)
  → server/gateway.js → broadcastSSE({ type: 'event', event, payload })
  → SSE transport
  → stores/websocket.ts subscribe('event')
  → stores/workspace.ts handleEvent()
      ├─ chat.delta / chat.final → mergeMessages()（原有逻辑）
      └─ agent 事件（新增）:
          ├─ stream: thinking   → 创建/更新 thinking 活动
          ├─ stream: tool       → 创建/更新 tool 活动（start/update/result）
          ├─ stream: item       → 创建 tool 活动（简化版）
          ├─ stream: command_output → 累积命令输出
          └─ stream: assistant  → 关闭思考活动 + 合并助手文本到消息
  → MessageList.vue unifiedTimeline computed
      → 合并 messages + currentActivities，按 timestamp 排序
      → 单个 v-for 循环渲染统一时间线
```

## 数据模型

### AgentActivity 接口（workspace.ts 内部）

```typescript
interface AgentActivity {
  id: string                        // 唯一标识，如 "thinking-1714567890123-abc1"
  sessionKey: string                // 绑定到会话，用于切换会话时过滤
  type: 'thinking' | 'tool' | 'command_output'
  timestamp: number                 // Date.now()，用于时间线排序
  done: boolean                     // 是否已完成（不再更新）

  // thinking 类型
  text?: string

  // tool 类型
  toolName?: string
  toolPhase?: string                // 'start' | 'update' | 'result'
  toolArgs?: string | null          // 参数 JSON（截断到 2000 字符）
  toolResult?: string | null        // 结果 JSON（截断到 2000 字符）
  toolPartial?: string | null       // 部分结果（截断到 2000 字符）
  toolIsError?: boolean | null

  // command_output 类型
  output?: string                   // 累积的命令输出
}
```

### 追踪变量

```typescript
const agentActivities = ref<AgentActivity[]>([])  // 全局活动列表（跨 session 保留）
let activeThinkingId: string | null = null         // 当前正在更新的思考活动 ID
let activeToolId: string | null = null             // 当前正在更新的工具活动 ID
let activeCmdId: string | null = null              // 当前正在更新的命令输出 ID
```

### 过滤计算属性

```typescript
const currentActivities = computed(() =>
  agentActivities.value.filter(a => a.sessionKey === activeSessionKey.value)
)
```

## Store 层改动详情（workspace.ts）

### 1. 新增状态（约第 254-277 行）

在 `activeStreamId` 之后，添加 `AgentActivity` 接口、`agentActivities` ref、三个追踪变量、`currentActivities` computed。

### 2. handleEvent 中的 agent 事件处理（约第 670-906 行）

原来的 `handleEvent` 只处理 `chat.delta`/`chat.final` 和 `agent.lifecycle`（end/error/start），其他 agent 事件直接跳过。

改为：

```typescript
if (normalizedEvent === 'agent' && payloadRow) {
  const stream = typeof payloadRow.stream === 'string' ? payloadRow.stream.trim().toLowerCase() : ''
  const data = asRecord(payloadRow.data) || {}

  // lifecycle — 保持原有逻辑（start/end/error）
  if (stream === 'lifecycle') { ... }

  // ★ 新增：thinking
  if (stream === 'thinking') {
    // 如果没有活跃思考活动 → 创建新的
    // 如果已有 → 更新文本
    // 关闭逻辑：当 tool/assistant/item 事件到来时自动关闭活跃思考
    return
  }

  // ★ 新增：tool
  if (stream === 'tool') {
    // phase === 'start' → 关闭当前思考，创建新 tool 活动
    // phase === 'update' → 更新 partialPreview
    // phase === 'result' → 设置 resultPreview + done=true
    return
  }

  // ★ 新增：item（简化版工具事件）
  if (stream === 'item') {
    // phase === 'start' → 关闭当前思考，创建 tool 活动
    return
  }

  // ★ 新增：command_output
  if (stream === 'command_output') {
    // 追加 output 到当前 cmd 活动
    // phase === 'end'/'result' → 标记 done
    return
  }

  // ★ 新增：assistant / compaction
  if (stream === 'assistant' || stream === 'compaction') {
    // 1. 关闭活跃思考
    // 2. 提取 data.content / data.text / data.delta → mergeMessages()
    return
  }
}
```

#### 关键：stream === 'assistant' 事件提取消息

这是解决"消息只在切回后才显示"的核心修复。Gateway 可能不发送 `chat.delta`，只发送 `agent` 事件。从 `stream: 'assistant'` 中提取文本并合并：

```typescript
if (stream === 'assistant' || stream === 'compaction') {
  // 关闭活跃思考
  if (activeThinkingId) {
    // ... 标记 done
    activeThinkingId = null
  }

  // ★ 提取助手文本并合并为消息
  const rawContent = (typeof (data.content || data.text || data.delta) === 'string'
    ? String(data.content || data.text || data.delta) : '').trim()
  if (rawContent) {
    const cleaned = rawContent.replace(/\n{3,}/g, '\n\n')
    mergeMessages([{
      role: 'assistant' as const,
      content: cleaned,
      timestamp: new Date().toISOString(),
    }], true)
  }

  resetStreamTimeout()
  return
}
```

### 3. 活动关闭逻辑

当新阶段开始时，自动关闭前一个阶段的活动：
- tool start → 关闭活跃思考
- item start → 关闭活跃思考和前一个工具
- assistant → 关闭活跃思考
- lifecycle end → 所有活跃活动标记 done

```typescript
function finalizeOpenActivities() {
  for (const act of agentActivities.value) {
    if (!act.done) act.done = true
  }
  activeThinkingId = null
  activeToolId = null
  activeCmdId = null
  agentActivities.value = [...agentActivities.value]
}
```

### 4. 持久化策略

| 场景 | 行为 |
|------|------|
| 发新消息 | 关闭当前 session 的未完成活动，**不清除**历史活动 |
| 切换 session | 重置追踪 ID，**不清除**活动（`currentActivities` 按 session 过滤） |
| 新建对话 | 重置追踪 ID，**不清除**活动 |
| 页面跳走再回来 | 活动保留在 Pinia store 中，重新选择 session 后通过 `currentActivities` 恢复显示 |
| `clearMessages()` | 只清 `messages`，**不清**活动 |

### 5. return 对象新增

```typescript
return {
  // ... 原有
  agentActivities,
  currentActivities,
  // ...
}
```

## UI 层改动详情（MessageList.vue）

### 1. 类型定义（约第 12-26 行）

在 `<script setup>` 顶部，添加本地 `AgentActivity` 类型（镜像 store 的结构）：

```typescript
type AgentActivity = {
  id: string
  sessionKey: string
  type: 'thinking' | 'tool' | 'command_output'
  timestamp: number
  done: boolean
  text?: string
  toolName?: string
  toolPhase?: string
  toolArgs?: string | null
  toolResult?: string | null
  toolPartial?: string | null
  toolIsError?: boolean | null
  output?: string
}
```

### 2. 活动展开/折叠状态（约第 33-40 行）

```typescript
const expandedActivities = ref(new Set<string>())

function toggleActivity(id: string) {
  const s = new Set(expandedActivities.value)
  if (s.has(id)) s.delete(id)
  else s.add(id)
  expandedActivities.value = s
}
```

### 3. 统一时间线（约第 107-146 行）

核心设计：将消息和活动合并为统一列表，按 timestamp 排序后渲染。

```typescript
interface TimelineEntry {
  sortKey: number
  type: 'message'
  msg: ProcessedMessage
}

interface ActivityEntry {
  sortKey: number
  type: 'activity'
  act: AgentActivity
}

type UnifiedEntry = TimelineEntry | ActivityEntry

function parseTs(ts?: string | number): number {
  if (typeof ts === 'number') return ts
  if (!ts) return 0
  const n = Number(ts)
  if (Number.isFinite(n) && n > 0) return n > 1e12 ? n : n * 1000
  return new Date(ts).getTime() || 0
}

const unifiedTimeline = computed<UnifiedEntry[]>(() => {
  const items: UnifiedEntry[] = []
  for (const msg of processedMessages.value) {
    items.push({ sortKey: parseTs(msg.timestamp), type: 'message', msg })
  }
  for (const act of workspaceStore.currentActivities) {
    items.push({ sortKey: act.timestamp, type: 'activity', act })
  }
  items.sort((a, b) => a.sortKey - b.sortKey)
  return items
})
```

### 4. 可见条目（替换原来的 visibleMessages）

```typescript
const visibleEntries = computed(() => {
  const all = unifiedTimeline.value
  return all.slice(Math.max(0, all.length - visibleCount.value))
})
```

### 5. 渐进渲染 watcher

```typescript
watch(
  () => unifiedTimeline.value.length,
  (newLen, oldLen) => {
    if (newLen > 0 && newLen !== oldLen) {
      scheduleProgressiveRender(newLen)
    }
  }
)
```

### 6. 自动滚动 watcher

```typescript
// 消息内容变化 → 滚动
watch(
  () => {
    const msgs = workspaceStore.messages
    if (!msgs.length) return ''
    const last = msgs[msgs.length - 1]!
    return last.content || ''
  },
  () => { if (isPinned.value) nextTick(() => scrollToBottom()) }
)

// 活动内容变化 → 滚动
watch(
  () => workspaceStore.currentActivities
    .map(a => `${a.id}:${a.text?.length}:${a.toolPhase}:${a.output?.length}`)
    .join('|'),
  () => { if (isPinned.value) nextTick(() => scrollToBottom()) }
)
```

### 7. 模板：统一循环渲染

```html
<template v-for="(entry, index) in visibleEntries" :key="...">
  <!-- 用户消息 -->
  <div v-if="entry.type === 'message' && entry.msg.role === 'user'" ...>
    <!-- 原有用户消息渲染 -->
  </div>

  <!-- AI 消息 -->
  <div v-else-if="entry.type === 'message' && entry.msg.role === 'assistant'" ...>
    <!-- 原有助手消息渲染 -->
  </div>

  <!-- 工具消息 -->
  <div v-else-if="entry.type === 'message' && entry.msg.role === 'tool'" ...>
    <!-- 原有工具消息渲染 -->
  </div>

  <!-- ★ Agent 活动记录 -->
  <div v-else-if="entry.type === 'activity'"
    class="msg-row is-assistant is-activity">
    <div class="msg-role assistant">
      <span class="material-symbols-outlined">smart_toy</span>
    </div>
    <div class="msg-content-wrap">
      <div class="activity-card"
        :class="[`is-${entry.act.type}`, { 'is-active': !entry.act.done }]">
        <!-- thinking / tool / command_output 三种类型的渲染 -->
      </div>
    </div>
  </div>
</template>
```

每个活动使用与助手消息相同的布局结构（头像 + 内容区），`msg-content-wrap` 限制 `max-width: 70%`。

### 8. 活动卡片结构

#### 思考卡片
```
┌──────────────────────────────────┐
│ 🧠 已思考 / 思考中...    [▼/▶] │
│ ┌──────────────────────────────┐ │
│ │ 思考文本内容...              │ │
│ └──────────────────────────────┘ │
└──────────────────────────────────┘
```
- 进行中显示脉冲动画圆点
- 点击展开/折叠

#### 工具调用卡片
```
┌──────────────────────────────────┐
│ 🔧 tool_name    START    [▼/▶] │
│ ▸ 参数                          │
│   {"key": "value"}              │
│ ▸ Result                        │
│   {"result": "..."}             │
└──────────────────────────────────┘
```
- 三个可折叠区域：参数、Partial、Result
- 错误结果有红色左边框
- 进行中显示脉冲动画

#### 命令输出卡片
```
┌──────────────────────────────────┐
│ ⬛ stdout/stderr         [▼/▶]  │
│ command output text...           │
└──────────────────────────────────┘
```

### 9. CSS 关键样式

```css
/* 活动行间距 */
.msg-row.is-activity { padding: 6px 0; }

/* 内容区宽度限制 */
.msg-row.is-activity .msg-content-wrap { max-width: 70%; }

/* 活动卡片基础样式 */
.activity-card {
  border-radius: 8px;
  border: 1px solid rgba(0,0,0,.06);
  background: var(--bg-card, #fff);
  overflow: hidden;
  animation: msg-in .2s ease;
}

/* 活跃状态（进行中） */
.activity-card.is-active {
  border-color: var(--accent-bg-strong);
  background: var(--accent-bg);
}

/* 脉冲动画 */
.streaming-pulse {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--accent);
  animation: pulse-glow 1.4s ease-in-out infinite;
}

/* 代码块样式 */
.activity-pre {
  font-size: 11px;
  font-family: "SF Mono", ui-monospace, monospace;
  background: var(--bg-code);
  max-height: 250px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
}
```

## 事件流详解

Gateway 发送的 agent 事件示例：

```json
// 1. Agent 开始
{ "event": "agent", "payload": { "stream": "lifecycle", "data": { "phase": "start" } } }

// 2. 思考
{ "event": "agent", "payload": { "stream": "thinking", "data": { "text": "让我分析一下..." } } }

// 3. 工具调用开始
{ "event": "agent", "payload": { "stream": "tool", "data": { "name": "read_file", "phase": "start", "args": { "path": "/etc/config" } } } }

// 4. 工具结果
{ "event": "agent", "payload": { "stream": "tool", "data": { "name": "read_file", "phase": "result", "result": "file content..." } } }

// 5. 命令输出
{ "event": "agent", "payload": { "stream": "command_output", "data": { "output": "Running tests...\n", "phase": "start" } } }

// 6. 助手文本生成
{ "event": "agent", "payload": { "stream": "assistant", "data": { "content": "根据分析结果..." } } }

// 7. Agent 结束
{ "event": "agent", "payload": { "stream": "lifecycle", "data": { "phase": "end" } } }
```

对应 UI 渲染顺序（按时间）：
```
[用户] 请帮我检查配置文件
[🤖] 🧠 思考中... "让我分析一下..."
[🤖] 🔧 read_file  START
[🤖] 🔧 read_file  RESULT
[🤖] ⬛ stdout/stderr "Running tests..."
[🤖] 根据分析结果... (助手消息，Markdown 渲染)
```

## 复现步骤

### 1. 修改 `src/stores/workspace.ts`

在 `activeStreamId` 之后添加 `AgentActivity` 接口和状态变量。

在 `handleEvent` 中：
- 将原来只处理 `lifecycle` 的 `if (normalizedEvent === 'agent')` 块扩展
- 新增 `thinking`/`tool`/`item`/`command_output`/`assistant`/`compaction` 分支
- 每个分支：创建/更新活动、关闭前一个活动、return
- `assistant` 分支额外调用 `mergeMessages()` 将文本合入消息

在 `sendMessage` 中：关闭当前 session 的未完成活动，重置追踪 ID。

在 `forceStopStreaming` 中：调用 `finalizeOpenActivities()`。

在 return 对象中：导出 `agentActivities` 和 `currentActivities`。

### 2. 修改 `src/views/workspace/MessageList.vue`

添加 `AgentActivity` 类型、`expandedActivities` 状态、`toggleActivity` 函数。

添加 `TimelineEntry`/`ActivityEntry`/`UnifiedEntry` 类型、`parseTs` 函数。

添加 `unifiedTimeline` computed（合并消息+活动，按时间排序）。

将 `visibleMessages` 替换为 `visibleEntries`（从 `unifiedTimeline` 切片）。

更新渐进渲染 watcher 从 `unifiedTimeline.value.length`。

更新 `isLastAssistant` 使用 `unifiedTimeline`。

添加活动内容变化自动滚动 watcher。

重写模板为统一 `v-for` 循环，活动使用 `.msg-row.is-assistant.is-activity` 布局。

添加活动卡片 CSS。

### 3. 构建

```bash
source .env && export PATH=~/.nvm/versions/node/v20.20.2/bin:$PATH
npx vue-tsc --noEmit   # 类型检查
npx vite build         # 构建
```

## 注意事项

1. **Gateway 可能不发送 `chat.delta`**：助手文本可能只在 `agent` 事件的 `stream: 'assistant'` 中，所以必须从那里提取并 `mergeMessages`。
2. **活动绑定 sessionKey**：切换 session 时不清除活动，通过 `currentActivities` computed 过滤。
3. **字符串截断**：tool args/result/partial 截断到 2000 字符避免内存问题。
4. **思考活动自动关闭**：当 tool/assistant/item 事件到来时自动关闭活跃思考活动。
5. **不需要改 WorkspacePage.vue**：事件订阅和清理逻辑不变。
6. **不需要改后端**：`broadcastSSE` 已经正确转发所有 Gateway 事件。
