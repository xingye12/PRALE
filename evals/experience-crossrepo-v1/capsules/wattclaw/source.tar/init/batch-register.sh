#!/bin/bash
# 批量注册用户 + 绑定飞书 user_id
# 格式: 用户名,手机号,部门,飞书user_id
# 用户名=手机号，密码=wattman+后四位，显示名称=用户名
# 数据库有但文件没有的用户 → 跳过

set -euo pipefail

FILE="$(dirname "$0")/user_info.txt"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PORT="${PORT:-3001}"
URL="http://localhost:$PORT/api/auth/register"
SUCCESS=0
FAIL=0
SKIP=0

if [ ! -f "$FILE" ]; then
  echo "Error: user_info.txt not found in init/"
  exit 1
fi

echo "========================================"
echo "  Phase 1: 注册用户"
echo "  来源: $FILE"
echo "  API: $URL"
echo "========================================"
echo ""

while IFS=',' read -r name phone dept feishu_uid; do
  [ -z "$name" ] && continue
  phone=$(echo "$phone" | tr -d '[:space:]')
  name=$(echo "$name" | tr -d '[:space:]')
  [ -z "$phone" ] && continue

  username="$phone"
  password="wattman${phone: -4}"

  result=$(curl -s -X POST "$URL" \
    -H "Content-Type: application/json" \
    -d "{\"username\":\"$username\",\"password\":\"$password\",\"displayName\":\"$name\"}" 2>&1)

  if echo "$result" | grep -q '"ok":true'; then
    echo "  OK   $name ($username)"
    SUCCESS=$((SUCCESS + 1))
  elif echo "$result" | grep -q 'already exists\|UNIQUE'; then
    echo "  SKIP $name ($username) - already exists"
    SKIP=$((SKIP + 1))
  else
    err=$(echo "$result" | sed 's/.*"error":"\([^"]*\)".*/\1/')
    echo "  FAIL $name ($username) - $err"
    FAIL=$((FAIL + 1))
  fi
done < "$FILE"

echo ""
echo "注册完成: 成功 $SUCCESS | 跳过 $SKIP | 失败 $FAIL"
echo ""

# Phase 2: 绑定飞书 user_id
echo "========================================"
echo "  Phase 2: 绑定飞书 user_id"
echo "========================================"
echo ""

TEMP_CSV=$(mktemp)
BIND_OK=0
BIND_SKIP=0

while IFS=',' read -r name phone dept feishu_uid; do
  [ -z "$name" ] && continue
  phone=$(echo "$phone" | tr -d '[:space:]')
  feishu_uid=$(echo "$feishu_uid" | tr -d '[:space:]')
  [ -z "$feishu_uid" ] && continue

  # 查询 WattClaw UUID
  user_id=$(node "$SCRIPT_DIR/lookup-user.js" "$phone" 2>&1)

  if [ -n "$user_id" ] && ! echo "$user_id" | grep -q "Error\|error\|Cannot"; then
    echo "$user_id,$feishu_uid" >> "$TEMP_CSV"
    BIND_OK=$((BIND_OK + 1))
  else
    echo "  SKIP $name ($phone) - DB 中未找到"
    BIND_SKIP=$((BIND_SKIP + 1))
  fi
done < "$FILE"

if [ -s "$TEMP_CSV" ]; then
  cd "$PROJECT_DIR" && node scripts/bind-feishu.js file "$TEMP_CSV"
fi

rm -f "$TEMP_CSV"

echo ""
echo "绑定完成: 待绑定 $BIND_OK | 跳过 $BIND_SKIP"
echo ""
echo "========================================"
echo "  全部完成"
echo "========================================"
