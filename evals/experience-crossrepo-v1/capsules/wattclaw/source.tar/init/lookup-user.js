// Lookup WattClaw user UUID by username
// Usage: node init/lookup-user.js <username>
import Database from 'better-sqlite3'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const db = new Database(join(__dirname, '../data/wizard.db'))

const username = process.argv[2]
if (!username) process.exit(1)

const row = db.prepare('SELECT id FROM users WHERE username = ?').get(username)
if (row) process.stdout.write(row.id)
db.close()
