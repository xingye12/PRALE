# openclaw-lark Owner Policy 补丁

## 背景

OpenClaw 的飞书插件（`@larksuite/openclaw-lark`）默认实施 **App Owner 权限控制**：

- 只有飞书应用的创建者（Owner）才能使用 bot
- 非 owner 用户尝试交互时，会被拒绝并返回：
  > "当前应用仅限所有者（App Owner）使用。您没有权限发起授权，无法使用相关功能。"

对于企业内部使用的 Finance-FAQ Agent，这一限制导致**普通员工无法使用**。由于该插件没有提供配置项来关闭 owner 检查，我们只能通过打补丁的方式绕过。

---

## 补丁内容

### 修改的文件（共 3 个）

| # | 文件路径 | 修改说明 |
|---|---------|---------|
| 1 | `src/core/owner-policy.js` | `assertOwnerAccessStrict` 函数体直接 `return`，跳过所有 owner 校验 |
| 2 | `src/tools/oauth.js` | 删除 `executeAuthorize` 中的 owner check try-catch 块，替换为注释 `// Owner check bypassed for internal use.` |
| 3 | `src/tools/onboarding-auth.js` | 删除 `triggerOnboarding` 中的 owner 比对逻辑，替换为注释 `// Owner check bypassed for internal use.` |

### 补丁生效后的行为

- 任何飞书用户都可以与 bot 交互
- OAuth 授权流程不再检查用户是否为 app owner
- Onboarding 预授权不再限制为 owner 触发

---

## 环境信息

- **服务器 SSH 别名**: `openclaw`
- **插件安装路径**: `/home/wattman/.openclaw/extensions/openclaw-lark/src/`
- **日志路径**: `/tmp/openclaw/openclaw-YYYY-MM-DD.log`

### 常用命令

```bash
# 检查网关状态
ssh openclaw "systemctl --user status openclaw-gateway"

# 重启网关
ssh openclaw "systemctl --user restart openclaw-gateway"

# 查看 finance-faq 相关日志
ssh openclaw "tail -100 /tmp/openclaw/openclaw-\$(date +%Y-%m-%d).log | grep -iE 'finance-faq|error'"

# 查看当前插件版本
ssh openclaw "cat /home/wattman/.openclaw/extensions/openclaw-lark/package.json | grep 'version'"
```

---

## 操作流程

### 1. 应用补丁（插件更新后必须执行）

```bash
# 在项目根目录执行
bash openclaw-lark-patches/apply.sh openclaw
```

脚本会自动：
1. 将 3 个补丁文件 scp 到服务器的插件目录
2. 重启 `openclaw-gateway`

### 2. 验证补丁是否生效

```bash
ssh openclaw "grep -n 'return;' /home/wattman/.openclaw/extensions/openclaw-lark/src/core/owner-policy.js"
```

预期输出包含 `return;` 即表示生效。

### 3. 验证非 owner 用户能否使用

找一个非 owner 的飞书账号，向 bot 发送消息，确认能正常交互。

---

## 重要注意事项

### 插件更新会覆盖补丁

**这是最关键的风险点。**

当以下情况发生时，补丁会被完全覆盖，非 owner 用户将立即无法使用：

- 执行 `openclaw update` 升级 OpenClaw CLI
- 执行 `openclaw plugins install/update` 更新插件
- OpenClaw 自动修复/重装插件（如 2026.4.21+ 的启动时插件维护机制）

**每次插件更新后，必须重新执行 `apply.sh`。**

### 版本兼容性

| 插件版本 | 补丁兼容性 | 备注 |
|---------|-----------|------|
| 2026.4.7 | ✅ | 首次打补丁 |
| 2026.4.9 | ✅ | 补丁被覆盖后重新打过 |
| 2026.5.13 | ✅ | 当前最新版，无需修改补丁文件 |

补丁文件的源码基础结构在 `2026.4.x` → `2026.5.x` 期间未发生变化，因此同一套补丁文件可直接复用。

若未来某个版本补丁失效（文件结构变化导致 `apply.sh` 报错），需要：
1. 下载新版本原始包：`npm pack @larksuite/openclaw-lark@<version>`
2. 对比三个文件的代码结构
3. 更新本地补丁文件

---

## 历史记录

| 日期 | 事件 | 操作人 |
|------|------|--------|
| 2026-04-30 | 首次创建补丁并应用 | Claude |
| 2026-05-08 | OpenClaw 自动更新插件至 `2026.4.9`，补丁丢失 | 系统自动 |
| 2026-05-08 | 重新打补丁 | Claude |
| 2026-05-19 | OpenClaw 升级至 `2026.5.18`，插件自动重装为 `2026.5.13`，补丁再次丢失 | 用户手动执行 `openclaw update` |
| 2026-05-19 | 更新 `apply.sh`（移除失效的 npx 缓存路径），重新打补丁 | Claude |

---

## 文件清单

```
openclaw-lark-patches/
├── README.md                # 本文档
├── apply.sh                 # 一键补丁脚本
├── core/
│   └── owner-policy.js      # 补丁文件 1
└── tools/
    ├── oauth.js             # 补丁文件 2
    └── onboarding-auth.js   # 补丁文件 3
```

---

## 替代方案评估（长期）

当前补丁方案是**临时/脆弱**的，因为每次插件更新都会覆盖。长期可考虑：

1. **Fork 插件并维护私有版本**
   - 将 `@larksuite/openclaw-lark` fork 到公司内部 npm registry
   - 在 fork 中正式移除 owner check 或添加配置开关
   - OpenClaw 配置中指定从私有源安装

2. **向官方提交 Issue/PR**
   - 请求添加配置项（如 `disableOwnerCheck: true`）
   - 若官方接受，可彻底摆脱补丁维护

3. **保持现状**
   - 适合当前阶段（内部小范围使用）
   - 每次更新后手动执行 `apply.sh`（约 10 秒）
