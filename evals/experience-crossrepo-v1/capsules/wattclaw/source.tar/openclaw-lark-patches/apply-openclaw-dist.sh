#!/bin/bash
# Apply OpenClaw bundled Feishu startup patch.
# Usage: bash apply-openclaw-dist.sh <server-alias>
# Example: bash apply-openclaw-dist.sh openclaw

set -e

SERVER="${1:-openclaw}"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="/home/wattman/.npm-global/lib/node_modules/openclaw/dist/monitor-Bog7UNtj.js"

printf 'Applying OpenClaw bundled Feishu startup patch to %s ...\n' "$SERVER"
scp "$PATCH_DIR/monitor-Bog7UNtj.js" "$SERVER:$TARGET"

printf '\nPatch applied. Restarting gateway...\n'
ssh "$SERVER" "systemctl --user restart openclaw-gateway"
printf 'Gateway restarted.\n'
