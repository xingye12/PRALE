#!/bin/bash
# Apply patches to openclaw-lark plugin
# Usage: bash apply.sh <server-alias>
# Example: bash apply.sh openclaw

set -e

SERVER="${1:-openclaw}"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Applying patches to $SERVER ..."

# Location to patch
LOCATIONS=(
    "/home/wattman/.openclaw/extensions/openclaw-lark/src"
)

FILES=(
    "core/owner-policy.js"
    "tools/oauth.js"
    "tools/onboarding-auth.js"
    "channel/monitor.js"
)

count=0
for loc in "${LOCATIONS[@]}"; do
    for f in "${FILES[@]}"; do
        echo "  Patching: $loc/$f"
        scp "$PATCH_DIR/$f" "$SERVER:$loc/$f"
        ((count++))
    done
done

echo ""
echo "Done. $count files patched."
echo "Restarting gateway..."
ssh "$SERVER" "systemctl --user restart openclaw-gateway"
echo "Gateway restarted."
