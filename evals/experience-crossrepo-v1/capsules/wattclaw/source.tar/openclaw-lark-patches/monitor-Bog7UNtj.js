import { l as resolveFeishuRuntimeAccount, r as listEnabledFeishuAccounts } from "./accounts-Djfj3q-S.js";
import { l as fetchBotIdentityForMonitor } from "./monitor.state-e0QxMMNC.js";
//#region extensions/feishu/src/monitor.ts
const STARTUP_BATCH_SIZE = 5;
const STARTUP_BATCH_DELAY_MS = 2000;
let monitorAccountRuntimePromise;
let startupSlotQueue = Promise.resolve();
let startupBatchStartedAt = 0;
let startupBatchCount = 0;
function sleepWithAbort(ms, abortSignal) {
	if (ms <= 0 || abortSignal?.aborted) return Promise.resolve();
	return new Promise((resolve) => {
		let done = () => {};
		const timer = setTimeout(() => done(), ms);
		done = () => {
			clearTimeout(timer);
			abortSignal?.removeEventListener?.("abort", done);
			resolve();
		};
		abortSignal?.addEventListener?.("abort", done, { once: true });
	});
}
async function waitForStartupBatchSlot({ accountId, log, abortSignal }) {
	const waitForSlot = startupSlotQueue.then(async () => {
		if (abortSignal?.aborted) return;
		const now = Date.now();
		if (startupBatchStartedAt === 0 || now - startupBatchStartedAt >= STARTUP_BATCH_DELAY_MS) {
			startupBatchStartedAt = now;
			startupBatchCount = 0;
		}
		if (startupBatchCount >= STARTUP_BATCH_SIZE) {
			const delayMs = Math.max(0, STARTUP_BATCH_DELAY_MS - (Date.now() - startupBatchStartedAt));
			if (delayMs > 0) {
				log(`feishu: waiting ${delayMs}ms before next startup batch...`);
				await sleepWithAbort(delayMs, abortSignal);
			}
			startupBatchStartedAt = Date.now();
			startupBatchCount = 0;
		}
		startupBatchCount += 1;
		log(`feishu: startup batch slot ${startupBatchCount}/${STARTUP_BATCH_SIZE} account=${accountId}`);
	});
	startupSlotQueue = waitForSlot.catch(() => {});
	await waitForSlot;
}
async function loadMonitorAccountRuntime() {
	monitorAccountRuntimePromise ??= import("./monitor.account-BB6WFk7p.js");
	return await monitorAccountRuntimePromise;
}
async function monitorFeishuProvider(opts = {}) {
	const cfg = opts.config;
	if (!cfg) throw new Error("Config is required for Feishu monitor");
	const log = opts.runtime?.log ?? console.log;
	if (opts.accountId) {
		const account = resolveFeishuRuntimeAccount({
			cfg,
			accountId: opts.accountId
		}, { requireEventSecrets: true });
		if (!account.enabled || !account.configured) throw new Error(`Feishu account "${opts.accountId}" not configured or disabled`);
		await waitForStartupBatchSlot({
			accountId: opts.accountId,
			log,
			abortSignal: opts.abortSignal
		});
		if (opts.abortSignal?.aborted) return;
		const { monitorSingleAccount } = await loadMonitorAccountRuntime();
		return monitorSingleAccount({
			cfg,
			account,
			runtime: opts.runtime,
			abortSignal: opts.abortSignal
		});
	}
	const accounts = listEnabledFeishuAccounts(cfg);
	if (accounts.length === 0) throw new Error("No enabled Feishu accounts configured");
	log(`feishu: starting ${accounts.length} account(s): ${accounts.map((a) => a.accountId).join(", ")}`);
	const { monitorSingleAccount } = await loadMonitorAccountRuntime();
	const monitorPromises = [];
	for (const account of accounts) {
		if (opts.abortSignal?.aborted) {
			log("feishu: abort signal received during startup preflight; stopping startup");
			break;
		}
		const { botOpenId, botName } = await fetchBotIdentityForMonitor(account, {
			runtime: opts.runtime,
			abortSignal: opts.abortSignal
		});
		if (opts.abortSignal?.aborted) {
			log("feishu: abort signal received during startup preflight; stopping startup");
			break;
		}
		await waitForStartupBatchSlot({
			accountId: account.accountId,
			log,
			abortSignal: opts.abortSignal
		});
		if (opts.abortSignal?.aborted) break;
		monitorPromises.push(monitorSingleAccount({
			cfg,
			account,
			runtime: opts.runtime,
			abortSignal: opts.abortSignal,
			botOpenIdSource: {
				kind: "prefetched",
				botOpenId,
				botName
			}
		}));
	}
	await Promise.all(monitorPromises);
}
//#endregion
export { monitorFeishuProvider };
