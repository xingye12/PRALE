import type {
  AgentHarnessAttemptParams,
  NormalizedUsage,
} from "openclaw/plugin-sdk/agent-harness";
import { execFile } from "node:child_process";
import { createRequire } from "node:module";
import { realpath } from "node:fs/promises";
import { dirname, join } from "node:path";
import { pathToFileURL } from "node:url";

type SyntheticAgentTool = {
  name: string;
  description?: string;
  execute: (
    toolCallId: string,
    params: unknown,
    signal?: AbortSignal,
    onUpdate?: unknown,
  ) => Promise<unknown>;
};

type AgentHarnessRuntimeModule = {
  getAgentHarnessHookRunner?: () => {
    hasHooks: (hookName: string) => boolean;
    runModelCallStarted?: (event: Record<string, unknown>, ctx: AgentHarnessHookContext) => Promise<void>;
    runModelCallEnded?: (event: Record<string, unknown>, ctx: AgentHarnessHookContext) => Promise<void>;
  } | undefined;
  wrapToolWithBeforeToolCallHook?: (tool: SyntheticAgentTool, ctx?: {
    agentId?: string;
    config?: unknown;
    cwd?: string;
    sessionKey?: string;
    sessionId?: string;
    runId?: string;
    channelId?: string;
  }) => SyntheticAgentTool;
  runAgentHarnessAfterToolCallHook?: (params: {
    toolName: string;
    toolCallId: string;
    runId?: string;
    agentId?: string;
    sessionId?: string;
    sessionKey?: string;
    startArgs: Record<string, unknown>;
    result?: unknown;
    error?: string;
    startedAt?: number;
  }) => Promise<void>;
  runAgentHarnessLlmInputHook?: (params: {
    event: {
      runId: string;
      sessionId: string;
      provider: string;
      model: string;
      systemPrompt?: string;
      prompt: string;
      historyMessages: unknown[];
      imagesCount: number;
    };
    ctx: AgentHarnessHookContext;
  }) => void;
  runAgentHarnessLlmOutputHook?: (params: {
    event: {
      runId: string;
      sessionId: string;
      provider: string;
      model: string;
      resolvedRef?: string;
      harnessId?: string;
      prompt?: string;
      assistantTexts: string[];
      lastAssistant?: unknown;
      usage?: NormalizedUsage;
    };
    ctx: AgentHarnessHookContext;
  }) => void;
  runAgentHarnessAgentEndHook?: (params: {
    event: {
      runId?: string;
      messages: unknown[];
      success: boolean;
      error?: string;
      durationMs?: number;
    };
    ctx: AgentHarnessHookContext;
  }) => void;
};

type AgentHarnessHookContext = {
  runId: string;
  agentId?: string;
  sessionKey?: string;
  sessionId?: string;
  workspaceDir?: string;
  modelProviderId?: string;
  modelId?: string;
  messageProvider?: string;
  trigger?: string;
  channelId?: string;
};

type AgentHarnessAttemptRuntimePlan = {
  observability?: {
    resolvedRef?: string;
    harnessId?: string;
  };
};

export type HermesToolStartState = {
  toolName: string;
  startedAt: number;
  args: Record<string, unknown>;
};

export interface CustomAgentMessages {}

export type AgentMessage = Message | CustomAgentMessages[keyof CustomAgentMessages];

export type Message = UserMessage | AssistantMessage | ToolResultMessage;

export type AgentMessageForTranscript = AgentMessage;

export interface UserMessage {
  role: "user";
  content: string | (TextContent | ImageContent)[];
  timestamp: number;
}

export interface TextContent {
  type: "text";
  text: string;
  textSignature?: string;
}

export interface ImageContent {
  type: "image";
  data: string;
  mimeType: string;
}

export interface ThinkingContent {
  type: "thinking";
  thinking: string;
  thinkingSignature?: string;
  redacted?: boolean;
}

export interface ToolCall {
  type: "toolCall";
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  thoughtSignature?: string;
}

export type Api = KnownApi | (string & {});
export type KnownApi =
  | "openai-completions"
  | "openai-responses"
  | "azure-openai-responses"
  | "openai-codex-responses"
  | "anthropic-messages"
  | "bedrock-converse-stream"
  | "google-generative-ai"
  | "google-gemini-cli"
  | "google-vertex";

export type Provider = KnownProvider | string;
export type KnownProvider =
  | "amazon-bedrock"
  | "anthropic"
  | "google"
  | "google-gemini-cli"
  | "google-antigravity"
  | "google-vertex"
  | "openai"
  | "azure-openai-responses"
  | "openai-codex"
  | "github-copilot"
  | "xai"
  | "groq"
  | "cerebras"
  | "openrouter"
  | "vercel-ai-gateway"
  | "zai"
  | "mistral"
  | "minimax"
  | "minimax-cn"
  | "huggingface"
  | "opencode"
  | "kimi-coding";

export interface Usage {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  totalTokens: number;
  cost: {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
    total: number;
  };
}

export type StopReason = "stop" | "length" | "toolUse" | "error" | "aborted";

export interface AssistantMessage {
  role: "assistant";
  content: (TextContent | ThinkingContent | ToolCall)[];
  api: Api;
  provider: Provider;
  model: string;
  usage?: Usage;
  stopReason: StopReason;
  errorMessage?: string;
  timestamp: number;
}

export interface ToolResultMessage<TDetails = unknown> {
  role: "toolResult";
  toolCallId: string;
  toolName: string;
  content: (TextContent | ImageContent)[];
  details?: TDetails;
  isError: boolean;
  timestamp: number;
}

export function buildHermesToolCallMessage(args: {
  toolName: string;
  toolCallId: string;
  startArgs: Record<string, unknown>;
  provider?: string;
  model?: string;
  timestamp: number;
}): AssistantMessage {
  return {
    role: "assistant",
    content: [
      {
        type: "toolCall",
        id: args.toolCallId,
        name: args.toolName,
        arguments: args.startArgs,
      },
    ],
    api: "hermes-acp",
    provider: args.provider ?? "hermes",
    model: args.model ?? "hermes",
    stopReason: "toolUse",
    timestamp: args.timestamp,
  };
}

export function buildHermesToolResultMessage(args: {
  toolName: string;
  toolCallId: string;
  outputText?: string;
  isError?: boolean;
  timestamp: number;
}): ToolResultMessage<{ toolCallId: string; toolName: string; text: string }> {
  const text = args.outputText?.trim() || (args.isError ? "Tool call failed" : "Tool call completed");
  return {
    role: "toolResult",
    toolCallId: args.toolCallId,
    toolName: args.toolName,
    isError: Boolean(args.isError),
    content: [{ type: "text", text }],
    details: {
      toolCallId: args.toolCallId,
      toolName: args.toolName,
      text,
    },
    timestamp: args.timestamp,
  };
}

async function loadAgentHarnessRuntimeModule(): Promise<AgentHarnessRuntimeModule> {
  const require = createRequire(import.meta.url);
  const candidates: string[] = [];
  try {
    candidates.push(require.resolve("openclaw/plugin-sdk/agent-harness-runtime"));
  } catch {}
  try {
    const sdkEntry = require.resolve("openclaw/plugin-sdk/agent-harness");
    const pkgRoot = dirname(dirname(sdkEntry));
    candidates.push(join(pkgRoot, "plugin-sdk", "agent-harness-runtime.js"));
  } catch {}
  for (const root of await resolveOpenClawDistDirs(require)) {
    candidates.push(join(root, "plugin-sdk", "agent-harness-runtime.js"));
  }
  candidates.push("/usr/lib/node_modules/openclaw/dist/plugin-sdk/agent-harness-runtime.js");
  candidates.push("/usr/local/lib/node_modules/openclaw/dist/plugin-sdk/agent-harness-runtime.js");

  for (const candidate of [...new Set(candidates)]) {
    try {
      return (await import(pathToFileURL(candidate).href)) as AgentHarnessRuntimeModule;
    } catch {
      // Try the next real installed OpenClaw location.
    }
  }
  throw new Error("OpenClaw agent-harness-runtime SDK entry not found");
}

async function resolveOpenClawDistDirs(require: NodeRequire): Promise<string[]> {
  const dirs: string[] = [];
  try {
    const sdkEntry = require.resolve("openclaw/plugin-sdk/agent-harness");
    dirs.push(dirname(dirname(sdkEntry)));
  } catch {}
  dirs.push(...(await resolveOpenClawDistDirsFromCli()));
  dirs.push("/usr/lib/node_modules/openclaw/dist");
  dirs.push("/usr/local/lib/node_modules/openclaw/dist");
  return [...new Set(dirs)];
}

async function resolveOpenClawDistDirsFromCli(): Promise<string[]> {
  const openclawBin = (await execFileText("sh", ["-lc", "command -v openclaw || true"]))
    .trim()
    .split(/\r?\n/)[0];
  if (!openclawBin) return [];

  const resolvedBin = await safeRealpath(openclawBin);
  if (!resolvedBin) return [];

  const candidates = [
    join(dirname(resolvedBin), "..", "lib", "node_modules", "openclaw", "dist"),
    join(dirname(resolvedBin), "..", "node_modules", "openclaw", "dist"),
    join(dirname(dirname(resolvedBin)), "lib", "node_modules", "openclaw", "dist"),
  ];
  const result: string[] = [];
  for (const candidate of candidates) {
    const resolved = await safeRealpath(candidate);
    if (resolved) result.push(resolved);
  }
  return result;
}

async function safeRealpath(path: string): Promise<string | undefined> {
  try {
    return await realpath(path);
  } catch {
    return undefined;
  }
}

async function execFileText(file: string, args: string[]): Promise<string> {
  return await new Promise<string>((resolve) => {
    execFile(file, args, (error, stdout) => {
      resolve(error ? "" : stdout.toString());
    });
  });
}

function buildHermesHookContext(params: AgentHarnessAttemptParams): AgentHarnessHookContext {
  const looseParams = params as AgentHarnessAttemptParams & { trigger?: string };
  return {
    runId: params.runId ?? "",
    ...(params.agentId ? { agentId: params.agentId } : {}),
    ...(params.sessionKey ? { sessionKey: params.sessionKey } : {}),
    ...(params.sessionId ? { sessionId: params.sessionId } : {}),
    ...(params.workspaceDir ? { workspaceDir: params.workspaceDir } : {}),
    ...(params.provider ? { modelProviderId: params.provider } : {}),
    ...(params.modelId ? { modelId: params.modelId } : {}),
    ...(params.messageProvider ? { messageProvider: params.messageProvider } : {}),
    ...(looseParams.trigger ? { trigger: looseParams.trigger } : {}),
    ...(params.currentChannelId ? { channelId: params.currentChannelId } : {}),
  };
}

export async function runHermesLlmInputHook(args: {
  params: AgentHarnessAttemptParams;
  prompt: string;
  historyMessages: unknown[];
  systemPrompt?: string;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    module.runAgentHarnessLlmInputHook?.({
      event: {
        runId: args.params.runId ?? "",
        sessionId: args.params.sessionId ?? "",
        provider: args.params.provider ?? "",
        model: args.params.modelId ?? "",
        ...(args.systemPrompt ? { systemPrompt: args.systemPrompt } : {}),
        prompt: args.prompt,
        historyMessages: args.historyMessages,
        imagesCount: 0,
      },
      ctx: buildHermesHookContext(args.params),
    });
  } catch (error) {
    console.warn(`[hermes-acp] llm_input hook bridge unavailable: ${String(error)}`);
  }
}

export async function runHermesModelCallHooks(args: {
  params: AgentHarnessAttemptParams;
  callId: string;
  provider?: string;
  model?: string;
  systemPrompt?: string;
  usage?: NormalizedUsage;
  startedAt?: number;
  finishedAt?: number;
  stopReason?: string;
  error?: string;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    const hookRunner = module.getAgentHarnessHookRunner?.();
    if (!hookRunner) return;
    const provider = args.provider ?? args.params.provider ?? "";
    const model = args.model ?? args.params.modelId ?? "";
    const ctx = buildHermesHookContext(args.params);
    const eventBase = {
      runId: args.params.runId ?? "",
      callId: args.callId,
      ...(args.params.sessionKey ? { sessionKey: args.params.sessionKey } : {}),
      ...(args.params.sessionId ? { sessionId: args.params.sessionId } : {}),
      provider,
      model,
      api: "hermes-acp",
      transport: "acp",
      ...(args.systemPrompt ? { systemPrompt: args.systemPrompt } : {}),
      ...(typeof args.startedAt === "number" ? { startedAt: args.startedAt } : {}),
    };
    if (hookRunner.hasHooks("model_call_started") && hookRunner.runModelCallStarted) {
      await hookRunner.runModelCallStarted(eventBase, ctx);
    }
    if (hookRunner.hasHooks("model_call_ended") && hookRunner.runModelCallEnded) {
      const durationMs = typeof args.startedAt === "number" && typeof args.finishedAt === "number"
        ? Math.max(0, args.finishedAt - args.startedAt)
        : undefined;
      await hookRunner.runModelCallEnded({
        ...eventBase,
        ...(durationMs !== undefined ? { durationMs } : {}),
        ...(typeof args.finishedAt === "number" ? { finishedAt: args.finishedAt } : {}),
        outcome: args.error ? "error" : "completed",
        ...(args.usage ? { usage: args.usage } : {}),
        ...(args.stopReason ? { finishReason: args.stopReason, stopReason: args.stopReason } : {}),
        ...(args.error ? { error: args.error } : {}),
      }, ctx);
    }
  } catch (error) {
    console.warn(`[hermes-acp] model call hook bridge unavailable: ${String(error)}`);
  }
}

export async function runHermesLlmOutputHook(args: {
  params: AgentHarnessAttemptParams;
  assistantTexts: string[];
  lastAssistant?: unknown;
  usage?: NormalizedUsage;
  prompt?: string;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    const runtimePlan = (args.params as AgentHarnessAttemptParams & {
      runtimePlan?: AgentHarnessAttemptRuntimePlan;
    }).runtimePlan;
    module.runAgentHarnessLlmOutputHook?.({
      event: {
        runId: args.params.runId ?? "",
        sessionId: args.params.sessionId ?? "",
        provider: args.params.provider ?? "",
        model: args.params.modelId ?? "",
        resolvedRef:
          runtimePlan?.observability?.resolvedRef ??
          `${args.params.provider ?? ""}/${args.params.modelId ?? ""}`,
        ...(runtimePlan?.observability?.harnessId
          ? { harnessId: runtimePlan.observability.harnessId }
          : { harnessId: "hermes" }),
        ...(args.prompt ? { prompt: args.prompt } : {}),
        assistantTexts: args.assistantTexts,
        ...(args.lastAssistant ? { lastAssistant: args.lastAssistant } : {}),
        ...(args.usage ? { usage: args.usage } : {}),
      },
      ctx: buildHermesHookContext(args.params),
    });
  } catch (error) {
    console.warn(`[hermes-acp] llm_output hook bridge unavailable: ${String(error)}`);
  }
}

export async function runHermesAgentEndHook(args: {
  params: AgentHarnessAttemptParams;
  messages: unknown[];
  success: boolean;
  error?: string;
  startedAt: number;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    module.runAgentHarnessAgentEndHook?.({
      event: {
        runId: args.params.runId,
        messages: args.messages,
        success: args.success,
        ...(args.error ? { error: args.error } : {}),
        durationMs: Date.now() - args.startedAt,
      },
      ctx: buildHermesHookContext(args.params),
    });
  } catch (error) {
    console.warn(`[hermes-acp] agent_end hook bridge unavailable: ${String(error)}`);
  }
}

export function normalizeHermesToolArgs(input: unknown): Record<string, unknown> {
  if (input && typeof input === "object" && !Array.isArray(input)) {
    return input as Record<string, unknown>;
  }
  if (input === undefined || input === null || input === "") {
    return {};
  }
  return { input };
}

export async function runHermesBeforeToolCallHook(args: {
  params: AgentHarnessAttemptParams;
  toolName: string;
  toolCallId: string;
  startArgs: Record<string, unknown>;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    if (typeof module.wrapToolWithBeforeToolCallHook !== "function") {
      console.warn("[hermes-acp] wrapToolWithBeforeToolCallHook unavailable; before_tool_call will be skipped");
      return;
    }
    const syntheticTool: SyntheticAgentTool = {
      name: args.toolName,
      description: "Hermes ACP observed tool call",
      execute: async () => ({ content: [] }),
    };
    const wrappedTool = module.wrapToolWithBeforeToolCallHook(syntheticTool, {
        ...(args.params.agentId ? { agentId: args.params.agentId } : {}),
        ...(args.params.config ? { config: args.params.config } : {}),
        cwd: args.params.workspaceDir,
        ...(args.params.sessionKey ? { sessionKey: args.params.sessionKey } : {}),
        ...(args.params.sessionId ? { sessionId: args.params.sessionId } : {}),
        ...(args.params.runId ? { runId: args.params.runId } : {}),
        ...(args.params.currentChannelId ? { channelId: args.params.currentChannelId } : {}),
    });
    await wrappedTool.execute(args.toolCallId, args.startArgs, args.params.abortSignal);
  } catch (error) {
    console.warn(`[hermes-acp] before_tool_call hook failed: tool=${args.toolName} error=${String(error)}`);
  }
}

export async function runHermesAfterToolCallHook(args: {
  params: AgentHarnessAttemptParams;
  toolName: string;
  toolCallId: string;
  startArgs: Record<string, unknown>;
  result?: unknown;
  error?: string;
  durationMs?: number;
  startedAt?: number;
}): Promise<void> {
  try {
    const module = await loadAgentHarnessRuntimeModule();
    const startedAt =
      typeof args.startedAt === "number" && Number.isFinite(args.startedAt) && args.startedAt >= 0
        ? args.startedAt
        : typeof args.durationMs === "number" && Number.isFinite(args.durationMs) && args.durationMs >= 0
          ? Date.now() - args.durationMs
          : undefined;
    await module.runAgentHarnessAfterToolCallHook?.({
      toolName: args.toolName,
      toolCallId: args.toolCallId,
      runId: args.params.runId,
      agentId: args.params.agentId,
      sessionId: args.params.sessionId,
      sessionKey: args.params.sessionKey,
      startArgs: args.startArgs,
      ...(args.result !== undefined ? { result: args.result } : {}),
      ...(args.error ? { error: args.error } : {}),
      ...(startedAt !== undefined ? { startedAt } : {}),
    });
  } catch (error) {
    console.warn(`[hermes-acp] after_tool_call hook failed: tool=${args.toolName} error=${String(error)}`);
  }
}
