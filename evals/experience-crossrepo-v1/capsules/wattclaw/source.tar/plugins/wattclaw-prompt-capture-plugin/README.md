# WattClaw Prompt Capture Plugin

OpenClaw Gateway 插件，用于捕获每次模型调用的完整 system prompt、user prompt 和历史消息，并通过自定义 RPC 暴露给前端。

## 功能

- 通过 `llm_input` hook 捕获每次模型调用的完整输入
- 通过 `before_tool_call` / `after_tool_call` hook 捕获工具调用链
- 通过 `llm_output` hook 捕获模型输出
- 将完整数据按 `runId` 存储到 SQLite
- 暴露 `wattclawTrace.get` Gateway RPC 供前端查询

## 安装

将本目录复制到 OpenClaw 插件目录：

```bash
mkdir -p ~/.openclaw/extensions/wattclaw-prompt-capture
cp -r * ~/.openclaw/extensions/wattclaw-prompt-capture/
```

在 `openclaw.json` 中启用：

```json5
{
  plugins: {
    entries: {
      "wattclaw-prompt-capture": {
        enabled: true,
        hooks: { allowConversationAccess: true },
        config: {
          dbPath: "~/.openclaw/state/wattclaw-traces.db",
          maxPromptLength: 1000000,
          maxHistoryMessages: 200,
          retentionDays: 30,
        }
      }
    }
  }
}
```

重启 Gateway：

```bash
openclaw gateway
```

> 注意：在 WattClaw 多租户部署中，本插件由后端在创建/更新每个租户网关容器时自动安装（见 `server/core/multi-tenant-gateway.js`），无需手动执行以上步骤。

## API

### `wattclawTrace.get`

获取指定 runId 的完整轨迹。

**请求：**
```json
{
  "runId": "run_abc123xyz"
}
```

**响应：**
```json
{
  "ok": true,
  "data": {
    "runId": "run_abc123xyz",
    "sessionKey": "agent:main:main",
    "agentId": "main",
    "model": "openai/gpt-4",
    "timestamp": "2026-07-29T11:30:00+08:00",
    "systemPrompt": "...完整 system prompt 文本...",
    "userPrompt": "...当前用户输入...",
    "historyMessages": [
      { "role": "user", "content": "..." },
      { "role": "assistant", "content": "..." }
    ],
    "toolCalls": [...],
    "assistantOutput": "...模型输出...",
    "tokenUsage": { "input": 1024, "output": 512 }
  }
}
```

### `wattclawTrace.list`

列出最近 N 条轨迹记录。

**请求：**
```json
{
  "limit": 20,
  "sessionKey": "agent:main:main"
}
```

## License

MIT
