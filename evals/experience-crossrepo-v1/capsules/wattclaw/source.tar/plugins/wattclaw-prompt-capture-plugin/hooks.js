/**
 * OpenClaw Plugin SDK Hooks for capturing full turn trajectory.
 *
 * A "turn" (identified by runId) is one full agent run: from the user message
 * to the completed reply. It may contain MULTIPLE model calls (each is one
 * llm_input -> llm_output cycle) and multiple tool calls. This module records
 * every model call and tool call with absolute timestamps so the frontend can
 * render a Gantt chart.
 *
 * Event shapes (from OpenClaw Plugin SDK):
 *
 * PluginHookLlmInputEvent:
 *   { runId, sessionId?, sessionKey?, provider, model, systemPrompt?,
 *     prompt, historyMessages: [{ role, content }], imagesCount?, tools? }
 *
 * PluginHookLlmOutputEvent:
 *   { runId, model?, assistantTexts: string[], lastAssistant?,
 *     finishReason?, stopReason?, requestId?, id?, apiType?, usage? }
 *   ctx?.tokenUsage: { input, output, cache }
 *
 * PluginHookToolCallEvent (before / after):
 *   { runId, toolName?, cmd?, params?, args?, result?, stdout?, stderr?,
 *     error?, exitCode?, durationMs? }
 */

import { TraceStorage } from "./storage.js";
import { createLangfuseExporter } from "./langfuse-exporter.js";

export function createHooks(api, config) {
  const storage = new TraceStorage(config);
  const langfuse = createLangfuseExporter(config?.langfuse, api?.logger);
  const activeRuns = new Map();
  api?.logger?.info?.(
    `[wattclaw-prompt-capture] langfuse forwarding ${langfuse.enabled ? "ENABLED" : "disabled"}`
  );

  function getRunId(event, ctx) {
    return event?.runId ?? ctx?.runId ?? `fallback-${Date.now()}`;
  }

  function getSessionKey(event, ctx) {
    return ctx?.sessionKey ?? event?.sessionKey ?? event?.sessionId ?? "";
  }

  function getAgentId(ctx) {
    return ctx?.agentId ?? "";
  }

  function getRunState(runId) {
    let state = activeRuns.get(runId);
    if (!state) {
      state = { input: null, toolStack: new Map() };
      activeRuns.set(runId, state);
    }
    return state;
  }

  function toIsoTimestamp(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return new Date(value).toISOString()
    if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return new Date(value).toISOString()
    return undefined
  }

  const llmInputHook = async (event, ctx) => {
    const runId = getRunId(event, ctx);
    const state = getRunState(runId);
    const systemPrompt = typeof event?.systemPrompt === "string" ? event.systemPrompt : "";
    const userPrompt = typeof event?.prompt === "string" ? event.prompt : "";
    const history = Array.isArray(event?.historyMessages) ? event.historyMessages : [];

    storage.ensureTurn({
      runId,
      sessionKey: getSessionKey(event, ctx),
      agentId: getAgentId(ctx),
      userPrompt,
    });

    state.input = {
      runId,
      model: event?.model ?? null,
      provider: event?.provider ?? null,
      systemPrompt,
      prompt: userPrompt,
      historyMessages: history,
      toolCount: Array.isArray(event?.tools) ? event.tools.length : null,
    };

    api.logger.info?.(
      `[wattclaw-prompt-capture] llm_input runId=${runId} sysLen=${systemPrompt.length} histCount=${history.length}`
    );
  };

  const modelCallStartedHook = async (event, ctx) => {
    const runId = getRunId(event, ctx)
    const state = getRunState(runId)
    if (!storage.getTurn(runId)) {
      storage.ensureTurn({
        runId,
        sessionKey: getSessionKey(event, ctx),
        agentId: getAgentId(ctx),
        userPrompt: state.input?.prompt ?? '',
      })
    }
    storage.startModelCall({
      runId,
      callId: event?.callId ?? null,
      model: event?.model ?? state.input?.model ?? null,
      provider: event?.provider ?? state.input?.provider ?? null,
      systemPrompt: typeof event?.systemPrompt === 'string' ? event.systemPrompt : state.input?.systemPrompt ?? '',
      prompt: typeof event?.prompt === 'string' ? event.prompt : state.input?.prompt ?? '',
      historyMessages: Array.isArray(event?.historyMessages) ? event.historyMessages : state.input?.historyMessages ?? [],
      toolCount: typeof event?.toolCount === 'number' ? event.toolCount : state.input?.toolCount ?? null,
      apiType: event?.api ?? event?.transport ?? null,
      startedAt: toIsoTimestamp(event?.startedAt),
    })
  }

  const modelCallEndedHook = async (event, ctx) => {
    const runId = getRunId(event, ctx)
    storage.finishModelCallTelemetry({
      runId,
      callId: event?.callId ?? null,
      durationMs: typeof event?.durationMs === 'number' ? event.durationMs : null,
      outcome: event?.outcome ?? 'completed',
      requestId: event?.upstreamRequestIdHash ?? null,
      apiType: event?.api ?? event?.transport ?? null,
      provider: event?.provider ?? null,
      model: event?.model ?? null,
      tokenUsage: event?.usage ?? null,
      finishReason: event?.finishReason ?? event?.stopReason ?? null,
    })
  }

  const llmOutputHook = async (event, ctx) => {
    const runId = getRunId(event, ctx);
    const texts = Array.isArray(event?.assistantTexts) ? event.assistantTexts : [];
    const output = texts.join("\n");

    storage.recordLlmOutput({
      runId,
      output,
      tokenUsage: event?.usage ?? ctx?.tokenUsage ?? null,
      endedAt: new Date().toISOString(),
    });

    api.logger.info?.(`[wattclaw-prompt-capture] llm_output runId=${runId}`);
  };

  const agentEndHook = async (event, ctx) => {
    const runId = getRunId(event, ctx)
    const state = getRunState(runId)
    const turn = storage.getTurn(runId)
    const startedAtMs = Date.parse(turn?.startedAt ?? '')
    const endedAt = Number.isFinite(startedAtMs) && typeof event?.durationMs === 'number'
      ? new Date(startedAtMs + event.durationMs).toISOString()
      : new Date().toISOString()
    storage.reconcileTurnFromMessages({
      runId,
      messages: Array.isArray(event?.messages) ? event.messages : [],
      endedAt,
      provider: state.input?.provider ?? null,
      model: state.input?.model ?? null,
      systemPrompt: state.input?.systemPrompt ?? '',
      success: event?.success !== false,
      error: event?.error ?? null,
    })
    activeRuns.delete(runId)

    // Forward the fully-reconciled turn (full system prompt, tool params/results)
    // to Langfuse. Fire-and-forget so it never blocks the agent loop.
    if (langfuse.enabled) {
      const finalTurn = storage.getTurn(runId)
      if (finalTurn) void langfuse.export(finalTurn)
    }
  }

  // ── before_tool_call: start of a tool call ──────────────────
  const beforeToolCallHook = async (event, ctx) => {
    const runId = getRunId(event, ctx);
    const state = getRunState(runId);
    const toolName = event?.toolName ?? event?.cmd ?? "unknown";
    const toolCallId = event?.toolCallId ?? null
    const index = storage.startToolCall({
      runId,
      toolCallId,
      toolName,
      params: event?.params ?? event?.args ?? null,
    });
    if (index >= 0) {
      const stackKey = toolCallId ?? toolName
      const stack = state.toolStack.get(stackKey) ?? [];
      stack.push(index);
      state.toolStack.set(stackKey, stack);
    }
  };

  // ── after_tool_call: finalize the tool call ─────────────────
  const afterToolCallHook = async (event, ctx) => {
    const runId = getRunId(event, ctx);
    const state = getRunState(runId);
    const toolName = event?.toolName ?? event?.cmd ?? "unknown";
    const toolCallId = event?.toolCallId ?? null
    const stack = state.toolStack.get(toolCallId ?? toolName);
    const index = stack && stack.length ? stack.shift() : -1;

    storage.finishToolCall({
      runId,
      index,
      toolCallId,
      toolName,
      params: event?.params ?? event?.args ?? null,
      result: event?.result ?? event?.stdout ?? null,
      error: event?.error ?? event?.stderr ?? null,
      durationMs: event?.durationMs ?? null,
    });
  };

  return {
    llmInputHook,
    modelCallStartedHook,
    modelCallEndedHook,
    llmOutputHook,
    agentEndHook,
    beforeToolCallHook,
    afterToolCallHook,
    storage,
  };
}
