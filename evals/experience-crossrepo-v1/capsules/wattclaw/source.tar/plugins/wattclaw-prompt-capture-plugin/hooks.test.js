import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { createHooks } from './hooks.js'

test('captures each provider call and hydrates outputs at agent end', async (t) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wattclaw-hooks-test-'))
  const hooks = createHooks({ logger: {} }, {
    dbPath: path.join(directory, 'traces.db'),
    retentionDays: 0,
  })
  t.after(() => {
    hooks.storage.close()
    fs.rmSync(directory, { recursive: true, force: true })
  })

  const ctx = {
    runId: 'run-1',
    sessionKey: 'agent:test:session',
    agentId: 'test',
  }
  await hooks.llmInputHook({
    runId: 'run-1',
    provider: 'provider',
    model: 'model',
    systemPrompt: 'system',
    prompt: '问题',
    historyMessages: [],
  }, ctx)
  await hooks.modelCallStartedHook({
    runId: 'run-1',
    callId: 'call-1',
    provider: 'provider',
    model: 'model',
    systemPrompt: 'hermes system',
    api: 'openai-completions',
    startedAt: 1000,
  }, ctx)
  await hooks.modelCallEndedHook({
    runId: 'run-1',
    callId: 'call-1',
    durationMs: 50,
    outcome: 'completed',
    usage: { input: 10, output: 2, cacheRead: 20, cacheWrite: 3 },
  }, ctx)
  await hooks.beforeToolCallHook({
    runId: 'run-1',
    toolCallId: 'tool-1',
    toolName: 'lookup',
    params: {},
  }, ctx)
  await hooks.afterToolCallHook({
    runId: 'run-1',
    toolCallId: 'tool-1',
    toolName: 'lookup',
    result: '结果',
    durationMs: 10,
  }, ctx)
  await hooks.modelCallStartedHook({
    runId: 'run-1',
    callId: 'call-2',
    provider: 'provider',
    model: 'model',
    api: 'openai-completions',
    startedAt: 2000,
  }, ctx)
  await hooks.modelCallEndedHook({
    runId: 'run-1',
    callId: 'call-2',
    durationMs: 60,
    outcome: 'completed',
    usage: { input: 3, output: 4, cacheRead: 30 },
  }, ctx)
  await hooks.llmOutputHook({
    runId: 'run-1',
    assistantTexts: ['查找', '完成'],
    usage: { input: 13, output: 6, cacheRead: 50 },
  }, ctx)
  await hooks.agentEndHook({
    durationMs: 200,
    success: true,
    messages: [
      { role: 'user', timestamp: Date.now(), content: '问题' },
      {
        role: 'assistant',
        timestamp: Date.now() + 10,
        provider: 'provider',
        model: 'model',
        stopReason: 'toolUse',
        usage: { input: 10, output: 2, cacheRead: 20 },
        content: [{ type: 'text', text: '查找' }, { type: 'toolCall', name: 'lookup' }],
      },
      { role: 'toolResult', timestamp: Date.now() + 20, content: [{ type: 'text', text: '结果' }] },
      {
        role: 'assistant',
        timestamp: Date.now() + 30,
        provider: 'provider',
        model: 'model',
        stopReason: 'stop',
        usage: { input: 3, output: 4, cacheRead: 30 },
        content: [{ type: 'text', text: '完成' }],
      },
    ],
  }, ctx)

  const turn = hooks.storage.getTurn('run-1')
  assert.equal(turn.modelCalls.length, 2)
  assert.deepEqual(turn.modelCalls.map((call) => call.callId), ['call-1', 'call-2'])
  assert.deepEqual(turn.modelCalls.map((call) => call.finishReason), ['toolUse', 'stop'])
  assert.deepEqual(turn.modelCalls.map((call) => call.output), ['查找', '完成'])
  assert.deepEqual(turn.modelCalls.map((call) => call.durationMs), [50, 60])
  assert.deepEqual(turn.modelCalls.map((call) => call.systemPrompt), ['hermes system', 'system'])
  assert.deepEqual(turn.modelCalls.map((call) => call.tokenInput), [10, 3])
  assert.deepEqual(turn.modelCalls.map((call) => call.tokenOutput), [2, 4])
  assert.deepEqual(turn.modelCalls.map((call) => call.tokenCache), [23, 30])
  assert.deepEqual(turn.modelCalls.map((call) => call.startedAt), [
    new Date(1000).toISOString(),
    new Date(2000).toISOString(),
  ])
})
