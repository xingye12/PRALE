import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { createHooks } from "./hooks.js";
import { findNativeRunCompletion } from './native-trace.js'
import { needsModelCallReconstruction } from './trace-reconstruction.js'

export default definePluginEntry({
  id: "wattclaw-prompt-capture",
  name: "WattClaw Prompt Capture",
  description:
    "Capture full turn trajectory (model calls, tool calls, prompts, tokens) for visualization",

  register(api) {
    // OpenClaw exposes THIS plugin's `config` block via `api.pluginConfig`.
    // (`api.config` is the whole gateway config; `api.config[pluginId]` is undefined.)
    const config =
      api.pluginConfig ??
      api.config?.plugins?.entries?.["wattclaw-prompt-capture"]?.config ??
      {};
    const {
      llmInputHook,
      modelCallStartedHook,
      modelCallEndedHook,
      llmOutputHook,
      agentEndHook,
      beforeToolCallHook,
      afterToolCallHook,
      storage,
    } = createHooks(api, config);

    // Conversation hooks (requires allowConversationAccess: true).
    api.on("llm_input", llmInputHook);
    api.on('model_call_started', modelCallStartedHook)
    api.on('model_call_ended', modelCallEndedHook)
    api.on("llm_output", llmOutputHook);
    api.on('agent_end', agentEndHook)

    // Tool call hooks.
    api.on("before_tool_call", beforeToolCallHook);
    api.on("after_tool_call", afterToolCallHook);

    // ── RPC: wattclawTrace.get ─ full turn trace by runId ─────
    api.registerGatewayMethod("wattclawTrace.get", async (ctx) => {
      const runId = ctx.params?.runId;
      if (!runId || typeof runId !== "string") {
        ctx.respond(false, undefined, {
          code: "INVALID_REQUEST",
          message: "runId is required",
        });
        return;
      }
      let turn = storage.getTurn(runId);
      if (!turn) {
        ctx.respond(false, undefined, {
          code: "NOT_FOUND",
          message: `Trace not found for runId: ${runId}`,
        });
        return;
      }
      const completion = findNativeRunCompletion({
        runId,
        agentId: turn.agentId,
        agentsDir: config.agentsDir,
      })
      if (completion && needsModelCallReconstruction(completion.messages, turn.modelCalls)) {
        storage.reconcileTurnFromMessages({
          runId,
          messages: completion.messages,
          endedAt: completion.endedAt ?? turn.endedAt,
          provider: completion.provider,
          model: completion.model,
          apiType: completion.apiType,
          success: turn.status !== 'failed',
        })
        turn = storage.getTurn(runId)
      }
      ctx.respond(true, { turn });
    });

    // ── RPC: wattclawTrace.list ─ turns for a session (asc) ───
    api.registerGatewayMethod("wattclawTrace.list", async (ctx) => {
      const limit = Math.min(Math.max(parseInt(ctx.params?.limit ?? "50", 10), 1), 200);
      const sessionKey = ctx.params?.sessionKey ?? null;
      const turns = storage.listTurns({ limit, sessionKey });
      ctx.respond(true, { turns, count: turns.length });
    });

    // ── RPC: wattclawTrace.stats ──────────────────────────────
    api.registerGatewayMethod("wattclawTrace.stats", async (ctx) => {
      const sessionKey = ctx.params?.sessionKey ?? null;
      const turns = storage.listTurns({ limit: 10000, sessionKey });
      const stats = {
        totalTurns: turns.length,
        completedTurns: turns.filter((t) => t.status === "completed").length,
        failedTurns: turns.filter((t) => t.status === "failed").length,
        avgDurationMs: turns.length
          ? turns.reduce((sum, t) => sum + (t.durationMs ?? 0), 0) / turns.length
          : 0,
        totalModelCalls: turns.reduce((sum, t) => sum + (t.modelCalls?.length ?? 0), 0),
        totalToolCalls: turns.reduce((sum, t) => sum + (t.toolCalls?.length ?? 0), 0),
      };
      ctx.respond(true, { stats });
    });

    api.logger.info?.(
      "[wattclaw-prompt-capture] plugin registered. RPCs: wattclawTrace.get, wattclawTrace.list, wattclawTrace.stats"
    );
  },
});
