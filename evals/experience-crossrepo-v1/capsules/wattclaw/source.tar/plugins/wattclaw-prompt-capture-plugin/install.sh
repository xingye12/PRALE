#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ID="wattclaw-prompt-capture"

echo "[${PLUGIN_ID}] Installing dependencies..."
cd "${SCRIPT_DIR}"
npm install --ignore-scripts --production 2>/dev/null || npm install --production

echo "[${PLUGIN_ID}] Plugin installed."
echo "[${PLUGIN_ID}] Add the following to your openclaw.json:"
echo ""
cat <<'EOF'
{
  plugins: {
    entries: {
      "wattclaw-prompt-capture": {
        enabled: true,
        config: {
          dbPath: "~/.openclaw/state/wattclaw-traces.db",
          maxPromptLength: 1000000,
          maxHistoryMessages: 200,
          retentionDays: 30
        }
      }
    }
  }
}
EOF
echo ""
