/**
 * Langfuse OTLP exporter for wattclaw-prompt-capture.
 *
 * Forwards a completed turn (the same full data WattClaw stores locally) to a
 * Langfuse instance via its OpenTelemetry trace endpoint
 * (POST /api/public/otel/v1/traces, OTLP-JSON).
 *
 * Why this exists: OpenClaw's standard client APIs redact the system prompt.
 * WattClaw already captures the FULL system prompt / tool params / tool results
 * through the llm_input + tool_call hooks. This module ships that same full
 * payload to Langfuse so Langfuse shows the complete (non-redacted) prompt.
 *
 * Langfuse attribute mapping (verified against OtelIngestionProcessor):
 *   gen_ai.system_instructions  -> auto-prepended as {role:"system"} into input
 *   gen_ai.input.messages       -> observation input (history + user turn)
 *   gen_ai.output.messages      -> observation output (assistant reply)
 *   gen_ai.tool.call.arguments  -> tool span input  (full params)
 *   gen_ai.tool.call.result     -> tool span output (full result / error)
 *   gen_ai.usage.input_tokens / output_tokens -> token usage
 *   langfuse.observation.type   -> GENERATION | SPAN
 *   langfuse.session.id / langfuse.user.id -> trace grouping
 */

import crypto from "node:crypto";

function traceIdHex(runId) {
  // 16 bytes -> 32 hex chars, deterministic from runId.
  return crypto.createHash("sha256").update(String(runId)).digest("hex").slice(0, 32);
}

function spanIdHex(seed) {
  // 8 bytes -> 16 hex chars.
  return crypto.createHash("sha256").update(String(seed)).digest("hex").slice(0, 16);
}

function nano(iso, fallbackMs) {
  const ms = Date.parse(iso ?? "");
  const base = Number.isFinite(ms) ? ms : fallbackMs ?? Date.now();
  return String(base * 1_000_000);
}

function attr(key, value) {
  if (value === null || value === undefined) return null;
  if (typeof value === "number") {
    return Number.isInteger(value)
      ? { key, value: { intValue: String(value) } }
      : { key, value: { doubleValue: value } };
  }
  const stringValue = typeof value === "string" ? value : JSON.stringify(value);
  return { key, value: { stringValue } };
}

function pushAttr(list, key, value) {
  const a = attr(key, value);
  if (a) list.push(a);
}

function buildResourceSpans(turn, serviceName) {
  const traceId = traceIdHex(turn.runId);
  const rootSpanId = spanIdHex(`${turn.runId}:root`);
  const startedMs = Date.parse(turn.startedAt ?? "") || Date.now();
  const start = nano(turn.startedAt, startedMs);
  const end = nano(turn.endedAt, startedMs + (turn.durationMs ?? 0));

  const spans = [];

  // ── Root span == the trace ──────────────────────────────────
  const rootAttrs = [];
  pushAttr(rootAttrs, "langfuse.session.id", turn.sessionKey || undefined);
  pushAttr(rootAttrs, "langfuse.user.id", turn.agentId || undefined);
  pushAttr(rootAttrs, "input", turn.userPrompt ?? "");
  pushAttr(rootAttrs, "output", turn.assistantOutput ?? "");
  pushAttr(rootAttrs, "langfuse.trace.metadata.status", turn.status);
  spans.push({
    traceId,
    spanId: rootSpanId,
    name: `agent-turn:${turn.agentId ?? "agent"}`,
    kind: 1,
    startTimeUnixNano: start,
    endTimeUnixNano: end,
    attributes: rootAttrs,
    status: turn.status === "failed" ? { code: 2 } : { code: 1 },
  });

  // ── One GENERATION observation per model call ───────────────
  for (const mc of turn.modelCalls ?? []) {
    const history = Array.isArray(mc.historyMessages) ? mc.historyMessages : [];
    const inputMessages = [
      ...history.map((m) => ({
        role: m?.role ?? "unknown",
        content: m?.content ?? "",
      })),
    ];
    if (mc.prompt) inputMessages.push({ role: "user", content: mc.prompt });
    const outputMessages = mc.output
      ? [{ role: "assistant", content: mc.output }]
      : [];

    const a = [];
    pushAttr(a, "langfuse.observation.type", "GENERATION");
    pushAttr(a, "gen_ai.system", mc.provider ?? undefined);
    pushAttr(a, "gen_ai.request.model", mc.model ?? undefined);
    pushAttr(a, "gen_ai.response.model", mc.model ?? undefined);
    // FULL system prompt — Langfuse prepends this as a {role:"system"} message.
    pushAttr(a, "gen_ai.system_instructions", mc.systemPrompt ?? "");
    pushAttr(a, "gen_ai.input.messages", inputMessages);
    pushAttr(a, "gen_ai.output.messages", outputMessages);
    pushAttr(a, "gen_ai.usage.input_tokens", mc.tokenInput ?? undefined);
    pushAttr(a, "gen_ai.usage.output_tokens", mc.tokenOutput ?? undefined);
    pushAttr(a, "gen_ai.response.finish_reasons", mc.finishReason ?? undefined);
    pushAttr(a, "langfuse.observation.metadata.requestId", mc.requestId ?? undefined);
    pushAttr(a, "langfuse.observation.metadata.apiType", mc.apiType ?? undefined);
    pushAttr(a, "langfuse.observation.metadata.cacheTokens", mc.tokenCache ?? undefined);

    spans.push({
      traceId,
      spanId: spanIdHex(`${turn.runId}:model:${mc.index}`),
      parentSpanId: rootSpanId,
      name: mc.model ?? "llm",
      kind: 1,
      startTimeUnixNano: nano(mc.startedAt, startedMs),
      endTimeUnixNano: nano(mc.endedAt, startedMs + (mc.durationMs ?? 0)),
      attributes: a,
      status: mc.status === "failed" ? { code: 2 } : { code: 1 },
    });
  }

  // ── One SPAN observation per tool call ──────────────────────
  for (const tc of turn.toolCalls ?? []) {
    const a = [];
    pushAttr(a, "langfuse.observation.type", "SPAN");
    pushAttr(a, "gen_ai.tool.name", tc.toolName ?? "unknown");
    // FULL params / result — no truncation on the Langfuse side.
    pushAttr(a, "gen_ai.tool.call.arguments", tc.params ?? {});
    pushAttr(a, "gen_ai.tool.call.result", tc.error ?? tc.result ?? "");

    spans.push({
      traceId,
      spanId: spanIdHex(`${turn.runId}:tool:${tc.index}`),
      parentSpanId: rootSpanId,
      name: `tool:${tc.toolName ?? "unknown"}`,
      kind: 1,
      startTimeUnixNano: nano(tc.startedAt, startedMs),
      endTimeUnixNano: nano(tc.endedAt, startedMs + (tc.durationMs ?? 0)),
      attributes: a,
      status: tc.status === "failed" ? { code: 2 } : { code: 1 },
    });
  }

  return {
    resourceSpans: [
      {
        resource: {
          attributes: [attr("service.name", serviceName || "wattclaw")].filter(Boolean),
        },
        scopeSpans: [{ scope: { name: "wattclaw-prompt-capture" }, spans }],
      },
    ],
  };
}

export function createLangfuseExporter(rawConfig, logger) {
  const cfg = rawConfig ?? {};
  const enabled = cfg.enabled === true;
  const baseUrl = (cfg.baseUrl ?? "").replace(/\/+$/, "");
  const publicKey = cfg.publicKey ?? "";
  const secretKey = cfg.secretKey ?? "";
  const serviceName = cfg.serviceName ?? "wattclaw";
  const timeoutMs = cfg.timeoutMs ?? 8000;

  const ready = Boolean(enabled && baseUrl && publicKey && secretKey);
  if (enabled && !ready) {
    logger?.warn?.(
      "[wattclaw-prompt-capture] langfuse export enabled but baseUrl/publicKey/secretKey incomplete — skipping",
    );
  }

  const endpoint = `${baseUrl}/api/public/otel/v1/traces`;
  const authHeader =
    "Basic " + Buffer.from(`${publicKey}:${secretKey}`).toString("base64");

  return {
    enabled: ready,
    async export(turn) {
      if (!ready || !turn) return;
      const body = JSON.stringify(buildResourceSpans(turn, serviceName));
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: authHeader,
          },
          body,
          signal: controller.signal,
        });
        if (!res.ok) {
          const text = await res.text().catch(() => "");
          logger?.warn?.(
            `[wattclaw-prompt-capture] langfuse export failed: ${res.status} ${text.slice(0, 200)}`,
          );
        } else {
          logger?.info?.(
            `[wattclaw-prompt-capture] langfuse export ok runId=${turn.runId}`,
          );
        }
      } catch (err) {
        logger?.warn?.(
          `[wattclaw-prompt-capture] langfuse export error runId=${turn.runId}: ${err?.message ?? err}`,
        );
      } finally {
        clearTimeout(timer);
      }
    },
  };
}
