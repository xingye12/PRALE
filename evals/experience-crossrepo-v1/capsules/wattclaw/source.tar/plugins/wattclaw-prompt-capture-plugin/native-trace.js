import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

function resolveAgentsDir(configPath) {
  if (!configPath) return path.join(os.homedir(), '.openclaw', 'agents')
  if (configPath.startsWith('~/') || configPath.startsWith('~\\')) {
    return path.join(os.homedir(), configPath.slice(2))
  }
  return path.resolve(configPath)
}

function readCompletion(filePath, runId) {
  let content
  try {
    content = fs.readFileSync(filePath, 'utf8')
  } catch {
    return null
  }
  if (!content.includes(runId)) return null
  const lines = content.split('\n')
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const line = lines[index]
    if (!line.includes(runId) || !line.includes('"type":"model.completed"')) continue
    try {
      const event = JSON.parse(line)
      if (event.runId !== runId || event.type !== 'model.completed') continue
      if (!Array.isArray(event.data?.messagesSnapshot)) continue
      return {
        messages: event.data.messagesSnapshot,
        endedAt: typeof event.ts === 'string' ? event.ts : null,
        provider: typeof event.provider === 'string' ? event.provider : null,
        model: typeof event.modelId === 'string' ? event.modelId : null,
        apiType: typeof event.modelApi === 'string' ? event.modelApi : null,
      }
    } catch {}
  }
  return null
}

export function findNativeRunCompletion({ runId, agentId, agentsDir }) {
  if (!runId || !agentId || path.basename(agentId) !== agentId) return null
  const sessionDir = path.join(resolveAgentsDir(agentsDir), agentId, 'sessions')
  let entries
  try {
    entries = fs.readdirSync(sessionDir, { withFileTypes: true })
  } catch {
    return null
  }
  const files = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith('.trajectory.jsonl'))
    .map((entry) => {
      const filePath = path.join(sessionDir, entry.name)
      let modifiedAt = 0
      try {
        modifiedAt = fs.statSync(filePath).mtimeMs
      } catch {}
      return { filePath, modifiedAt }
    })
    .sort((left, right) => right.modifiedAt - left.modifiedAt)

  for (const file of files) {
    const completion = readCompletion(file.filePath, runId)
    if (completion) return completion
  }
  return null
}
