import Database from 'better-sqlite3'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { reconstructModelCalls } from './trace-reconstruction.js'

function resolveDbPath(configPath) {
  if (!configPath) {
    return path.join(os.homedir(), ".openclaw", "state", "wattclaw-traces.db");
  }
  if (configPath.startsWith("~/") || configPath.startsWith("~\\")) {
    return path.join(os.homedir(), configPath.slice(2));
  }
  return path.resolve(configPath);
}

/**
 * Turn-centric trace storage.
 *
 * One row == one agent turn (identified by runId). A turn contains an ordered
 * list of model calls (each llm_input -> llm_output cycle) and tool calls, all
 * timestamped so the frontend can render a Gantt chart. Earlier model calls in
 * the loop are preserved (the previous schema replaced them on every call).
 */
export class TraceStorage {
  constructor(config = {}) {
    this.dbPath = resolveDbPath(config.dbPath);
    this.maxPromptLength = config.maxPromptLength ?? 1_000_000;
    this.maxHistoryMessages = config.maxHistoryMessages ?? 200;
    this.retentionDays = config.retentionDays ?? 30;
    this._init();
  }

  _init() {
    fs.mkdirSync(path.dirname(this.dbPath), { recursive: true });
    this.db = new Database(this.dbPath);
    this.db.pragma("journal_mode = WAL");

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS turns (
        run_id TEXT PRIMARY KEY,
        session_key TEXT NOT NULL,
        agent_id TEXT,
        started_at TEXT NOT NULL,
        ended_at TEXT,
        user_prompt TEXT,
        assistant_output TEXT,
        model_calls TEXT,
        tool_calls TEXT,
        token_input INTEGER,
        token_output INTEGER,
        token_cache INTEGER,
        duration_ms INTEGER,
        status TEXT DEFAULT 'running',
        created_at INTEGER DEFAULT (unixepoch())
      );

      CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_key);
      CREATE INDEX IF NOT EXISTS idx_turns_created ON turns(created_at);
    `);

    this._cleanupOld();
  }

  _truncate(text, maxLen) {
    if (!text || text.length <= maxLen) return text;
    return text.slice(0, maxLen) + "\n\n... [truncated by wattclaw-prompt-capture plugin]";
  }

  _limitHistory(messages) {
    if (!Array.isArray(messages)) return [];
    return messages.slice(-this.maxHistoryMessages).map((m) => ({
      role: typeof m?.role === "string" ? m.role : "unknown",
      content:
        typeof m?.content === "string"
          ? this._truncate(m.content, this.maxPromptLength)
          : m?.content ?? null,
    }));
  }

  _loadTurn(runId) {
    const row = this.db.prepare("SELECT * FROM turns WHERE run_id = ?").get(runId);
    return row ?? null;
  }

  _parseCalls(row) {
    return {
      modelCalls: row?.model_calls ? JSON.parse(row.model_calls) : [],
      toolCalls: row?.tool_calls ? JSON.parse(row.tool_calls) : [],
    };
  }

  /** Ensure a turn row exists (called on first llm_input of the turn). */
  ensureTurn({ runId, sessionKey, agentId, userPrompt }) {
    const existing = this._loadTurn(runId);
    if (existing) return;
    this.db
      .prepare(
        `INSERT INTO turns (run_id, session_key, agent_id, started_at, user_prompt, model_calls, tool_calls, status)
         VALUES (?, ?, ?, ?, ?, '[]', '[]', 'running')`
      )
      .run(
        runId,
        sessionKey ?? "",
        agentId ?? null,
        new Date().toISOString(),
        this._truncate(userPrompt ?? "", this.maxPromptLength)
      );
  }

  /**
   * Append a model call at its start (llm_input). Returns the index of the new
   * call so llm_output can finalize the same entry.
   */
  startModelCall({
    runId,
    callId,
    model,
    provider,
    systemPrompt,
    prompt,
    historyMessages,
    toolCount,
    apiType,
    startedAt,
  }) {
    const row = this._loadTurn(runId);
    if (!row) return -1;
    const { modelCalls } = this._parseCalls(row);
    if (callId) {
      const existingIndex = modelCalls.findIndex((call) => call?.callId === callId)
      if (existingIndex >= 0) return existingIndex
    }
    const index = modelCalls.length;
    modelCalls.push({
      index,
      callId: callId ?? null,
      startedAt: startedAt ?? new Date().toISOString(),
      endedAt: null,
      durationMs: null,
      model: model ?? null,
      provider: provider ?? null,
      systemPrompt: this._truncate(systemPrompt ?? "", this.maxPromptLength),
      prompt: this._truncate(prompt ?? "", this.maxPromptLength),
      historyMessages: this._limitHistory(historyMessages),
      toolCount: typeof toolCount === "number" ? toolCount : null,
      output: null,
      tokenInput: null,
      tokenOutput: null,
      tokenCache: null,
      finishReason: null,
      requestId: null,
      apiType: apiType ?? null,
      status: "running",
    });
    this.db
      .prepare("UPDATE turns SET model_calls = ? WHERE run_id = ?")
      .run(JSON.stringify(modelCalls), runId);
    return index;
  }

  finishModelCallTelemetry({
    runId,
    callId,
    durationMs,
    outcome,
    requestId,
    apiType,
    provider,
    model,
    tokenUsage,
    finishReason,
  }) {
    const row = this._loadTurn(runId);
    if (!row) return;
    const { modelCalls } = this._parseCalls(row);
    let call = callId ? modelCalls.find((entry) => entry?.callId === callId) : null
    if (!call) call = [...modelCalls].reverse().find((entry) => entry?.status === 'running')
    if (!call) {
      call = {
        index: modelCalls.length,
        callId: callId ?? null,
        startedAt: new Date().toISOString(),
        endedAt: null,
        durationMs: null,
        model: model ?? null,
        provider: provider ?? null,
        systemPrompt: '',
        prompt: '',
        historyMessages: [],
        toolCount: null,
        output: null,
        tokenInput: null,
        tokenOutput: null,
        tokenCache: null,
        finishReason: null,
        requestId: null,
        apiType: null,
        status: 'running',
      }
      modelCalls.push(call)
    }
    const startMs = Date.parse(call.startedAt);
    const finishedAtMs = Number.isFinite(startMs) && typeof durationMs === 'number'
      ? startMs + durationMs
      : Date.now()
    call.endedAt = new Date(finishedAtMs).toISOString()
    call.durationMs = typeof durationMs === 'number'
      ? durationMs
      : Number.isFinite(startMs)
        ? Math.max(0, finishedAtMs - startMs)
        : null
    call.model = call.model ?? model ?? null
    call.provider = call.provider ?? provider ?? null
    call.requestId = requestId ?? call.requestId ?? null
    call.apiType = apiType ?? call.apiType ?? null
    if (tokenUsage) {
      call.tokenInput = tokenUsage.input ?? tokenUsage.inputTokens ?? call.tokenInput ?? null
      call.tokenOutput = tokenUsage.output ?? tokenUsage.outputTokens ?? call.tokenOutput ?? null
      const cacheRead = tokenUsage.cacheRead ?? tokenUsage.cache ?? tokenUsage.cachedTokens
      const cacheWrite = tokenUsage.cacheWrite
      call.tokenCache = typeof cacheRead === 'number' || typeof cacheWrite === 'number'
        ? (cacheRead ?? 0) + (cacheWrite ?? 0)
        : call.tokenCache ?? null
    }
    call.finishReason = finishReason ?? call.finishReason ?? null
    call.status = outcome === 'error' ? 'failed' : 'completed'
    if (outcome === 'error' && !call.finishReason) call.finishReason = 'error'
    this.db
      .prepare('UPDATE turns SET model_calls = ? WHERE run_id = ?')
      .run(JSON.stringify(modelCalls), runId)
  }

  recordLlmOutput({ runId, output, tokenUsage, endedAt }) {
    const row = this._loadTurn(runId)
    if (!row) return
    const end = endedAt ?? new Date().toISOString()
    const startMs = Date.parse(row.started_at)
    const endMs = Date.parse(end)
    const durationMs = Number.isFinite(startMs) && Number.isFinite(endMs)
      ? Math.max(0, endMs - startMs)
      : null
    this.db.prepare(
      `UPDATE turns SET
         assistant_output = ?, ended_at = ?, token_input = ?, token_output = ?,
         token_cache = ?, duration_ms = ?, status = 'completed'
       WHERE run_id = ?`
    ).run(
      this._truncate(output ?? '', this.maxPromptLength),
      end,
      tokenUsage?.input ?? null,
      tokenUsage?.output ?? null,
      tokenUsage?.cacheRead ?? tokenUsage?.cache ?? null,
      durationMs,
      runId,
    )
  }

  reconcileTurnFromMessages({
    runId,
    messages,
    endedAt,
    provider,
    model,
    systemPrompt,
    apiType,
    success = true,
    error = null,
  }) {
    const row = this._loadTurn(runId)
    if (!row || !Array.isArray(messages)) return false
    const { modelCalls, toolCalls } = this._parseCalls(row)
    const baseCall = modelCalls.find((call) => call?.status !== 'failed') ?? modelCalls[0] ?? null
    const nextCalls = reconstructModelCalls({
      messages,
      existingCalls: modelCalls,
      toolCalls,
      systemPrompt: baseCall?.systemPrompt || systemPrompt || '',
      fallbackPrompt: row.user_prompt ?? '',
      availableToolCount: baseCall?.toolCount ?? null,
      provider: provider ?? baseCall?.provider ?? null,
      model: model ?? baseCall?.model ?? null,
      apiType: apiType ?? baseCall?.apiType ?? null,
      turnStartedAt: row.started_at,
      turnEndedAt: endedAt ?? row.ended_at ?? new Date().toISOString(),
    }).map((call, index) => ({
      ...call,
      index,
      systemPrompt: this._truncate(call.systemPrompt ?? '', this.maxPromptLength),
      prompt: this._truncate(call.prompt ?? '', this.maxPromptLength),
      historyMessages: this._limitHistory(call.historyMessages),
      output: this._truncate(call.output ?? '', this.maxPromptLength),
      thinking: call.thinking ? this._truncate(call.thinking, this.maxPromptLength) : null,
    }))
    if (!nextCalls.length) return false

    const aggregate = nextCalls.reduce(
      (acc, call) => ({
        input: acc.input + (call.tokenInput ?? 0),
        output: acc.output + (call.tokenOutput ?? 0),
        cache: acc.cache + (call.tokenCache ?? 0),
        seen: acc.seen || call.tokenInput != null || call.tokenOutput != null || call.tokenCache != null,
      }),
      { input: 0, output: 0, cache: 0, seen: false },
    )
    const output = nextCalls
      .filter((call) => call.status !== 'failed' && call.output)
      .map((call) => call.output)
      .join('\n')
    const end = endedAt ?? row.ended_at ?? new Date().toISOString()
    const startMs = Date.parse(row.started_at)
    const endMs = Date.parse(end)
    const durationMs = Number.isFinite(startMs) && Number.isFinite(endMs)
      ? Math.max(0, endMs - startMs)
      : row.duration_ms
    const status = success === false || error ? 'failed' : 'completed'

    this.db.prepare(
      `UPDATE turns SET
         model_calls = ?, assistant_output = ?, ended_at = ?, token_input = ?,
         token_output = ?, token_cache = ?, duration_ms = ?, status = ?
       WHERE run_id = ?`
    ).run(
      JSON.stringify(nextCalls),
      this._truncate(output, this.maxPromptLength),
      end,
      aggregate.seen ? aggregate.input : null,
      aggregate.seen ? aggregate.output : null,
      aggregate.seen ? aggregate.cache : null,
      durationMs,
      status,
      runId,
    )
    return true
  }

  /** Append a tool call at its start (before_tool_call). Returns its index. */
  startToolCall({ runId, toolCallId, toolName, params }) {
    const row = this._loadTurn(runId);
    if (!row) return -1;
    const { toolCalls } = this._parseCalls(row);
    const index = toolCalls.length;
    toolCalls.push({
      index,
      toolCallId: toolCallId ?? null,
      toolName: toolName ?? "unknown",
      startedAt: new Date().toISOString(),
      endedAt: null,
      durationMs: null,
      params: params ?? null,
      result: null,
      error: null,
      status: "running",
    });
    this.db
      .prepare("UPDATE turns SET tool_calls = ? WHERE run_id = ?")
      .run(JSON.stringify(toolCalls), runId);
    return index;
  }

  /** Finalize a tool call (after_tool_call). */
  finishToolCall({ runId, index, toolCallId, toolName, params, result, error, durationMs }) {
    const row = this._loadTurn(runId);
    if (!row) return;
    const { toolCalls } = this._parseCalls(row);
    let call = toolCallId ? toolCalls.find((entry) => entry?.toolCallId === toolCallId) : null
    if (!call) call = index >= 0 && index < toolCalls.length ? toolCalls[index] : null;
    if (!call) {
      // Fallback: last running tool call with matching name.
      call = [...toolCalls]
        .reverse()
        .find((c) => c.status === "running" && (!toolName || c.toolName === toolName));
    }
    if (!call) {
      // No before-hook fired; create a completed entry directly.
      const newIndex = toolCalls.length;
      call = {
        index: newIndex,
        toolCallId: toolCallId ?? null,
        toolName: toolName ?? "unknown",
        startedAt: new Date().toISOString(),
        endedAt: null,
        durationMs: null,
        params: params ?? null,
        result: null,
        error: null,
        status: "running",
      };
      toolCalls.push(call);
    }
    const now = new Date();
    const startMs = Date.parse(call.startedAt);
    call.endedAt = now.toISOString();
    call.durationMs =
      typeof durationMs === "number"
        ? durationMs
        : Number.isFinite(startMs)
          ? now.getTime() - startMs
          : null;
    if (params != null) call.params = params;
    call.result = result ?? null;
    call.error = error ?? null;
    call.status = error ? "failed" : "completed";
    this.db
      .prepare("UPDATE turns SET tool_calls = ? WHERE run_id = ?")
      .run(JSON.stringify(toolCalls), runId);
  }

  /** Mark a turn as failed (e.g. on error). */
  failTurn(runId) {
    const row = this._loadTurn(runId);
    if (!row) return;
    const startedAtMs = Date.parse(row.started_at);
    const now = Date.now();
    this.db
      .prepare("UPDATE turns SET status = 'failed', ended_at = ?, duration_ms = ? WHERE run_id = ?")
      .run(
        new Date(now).toISOString(),
        Number.isFinite(startedAtMs) ? now - startedAtMs : null,
        runId
      );
  }

  getTurn(runId) {
    const row = this._loadTurn(runId);
    if (!row) return null;
    return this._rowToTurn(row);
  }

  listTurns({ limit = 50, sessionKey = null } = {}) {
    let rows;
    if (sessionKey) {
      rows = this.db
        .prepare("SELECT * FROM turns WHERE session_key = ? ORDER BY created_at ASC LIMIT ?")
        .all(sessionKey, limit);
    } else {
      rows = this.db
        .prepare("SELECT * FROM turns ORDER BY created_at DESC LIMIT ?")
        .all(limit);
    }
    return rows.map((r) => this._rowToTurn(r));
  }

  _rowToTurn(row) {
    const { modelCalls, toolCalls } = this._parseCalls(row);
    return {
      runId: row.run_id,
      sessionKey: row.session_key,
      agentId: row.agent_id,
      startedAt: row.started_at,
      endedAt: row.ended_at,
      userPrompt: row.user_prompt,
      assistantOutput: row.assistant_output,
      modelCalls,
      toolCalls,
      tokenUsage: {
        input: row.token_input,
        output: row.token_output,
        cache: row.token_cache,
      },
      durationMs: row.duration_ms,
      status: row.status,
      createdAt: row.created_at,
    };
  }

  _cleanupOld() {
    if (this.retentionDays <= 0) return;
    const cutoff = Math.floor(Date.now() / 1000) - this.retentionDays * 86400;
    const result = this.db.prepare("DELETE FROM turns WHERE created_at < ?").run(cutoff);
    if (result.changes > 0) {
      console.log(`[wattclaw-prompt-capture] cleaned up ${result.changes} old turns`);
    }
  }

  close() {
    this.db.close();
  }
}
