import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { TraceStorage } from './storage.js'

test('persists reconstructed calls and aggregate usage', (t) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'wattclaw-trace-test-'))
  const storage = new TraceStorage({ dbPath: path.join(directory, 'traces.db'), retentionDays: 0 })
  t.after(() => {
    storage.close()
    fs.rmSync(directory, { recursive: true, force: true })
  })

  storage.ensureTurn({
    runId: 'run-1',
    sessionKey: 'agent:test:session',
    agentId: 'test',
    userPrompt: '问题',
  })
  storage.startModelCall({
    runId: 'run-1',
    model: 'model',
    provider: 'provider',
    systemPrompt: 'system',
    prompt: '问题',
    historyMessages: [],
    toolCount: 10,
  })
  storage.startToolCall({
    runId: 'run-1',
    toolCallId: 'tool-1',
    toolName: 'lookup',
    params: {},
  })

  const messages = [
    { role: 'user', timestamp: Date.now(), content: '问题' },
    {
      role: 'assistant',
      timestamp: Date.now() + 10,
      stopReason: 'toolUse',
      usage: { input: 10, output: 2, cacheRead: 20 },
      content: [{ type: 'text', text: '查找' }, { type: 'toolCall', name: 'lookup' }],
    },
    { role: 'toolResult', timestamp: Date.now() + 20, content: [{ type: 'text', text: '结果' }] },
    {
      role: 'assistant',
      timestamp: Date.now() + 30,
      stopReason: 'stop',
      usage: { input: 3, output: 4, cacheRead: 30 },
      content: [{ type: 'text', text: '完成' }],
    },
  ]
  storage.reconcileTurnFromMessages({
    runId: 'run-1',
    messages,
    endedAt: new Date(Date.now() + 40).toISOString(),
  })

  const turn = storage.getTurn('run-1')
  assert.equal(turn.modelCalls.length, 2)
  assert.deepEqual(turn.modelCalls.map((call) => call.finishReason), ['toolUse', 'stop'])
  assert.deepEqual(turn.modelCalls.map((call) => call.output), ['查找', '完成'])
  assert.deepEqual(turn.tokenUsage, { input: 13, output: 6, cache: 50 })
  assert.equal(turn.assistantOutput, '查找\n完成')
})
