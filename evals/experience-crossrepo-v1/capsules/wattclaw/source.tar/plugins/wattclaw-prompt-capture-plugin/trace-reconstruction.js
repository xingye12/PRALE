function messageRole(message) {
  const role = typeof message?.role === 'string' ? message.role : 'unknown'
  return role === 'toolResult' ? 'tool' : role
}

function messageTimestamp(message) {
  const value = message?.timestamp
  if (typeof value === 'number' && Number.isFinite(value)) return new Date(value).toISOString()
  if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return new Date(value).toISOString()
  return null
}

function stringifyContent(content) {
  if (content == null) return ''
  if (typeof content === 'string') return content
  try {
    return JSON.stringify(content, null, 2)
  } catch {
    return String(content)
  }
}

const THINKING_BLOCK_TYPES = new Set(['thinking', 'thought', 'reasoning', 'redacted_thinking'])

function isThinkingBlock(block) {
  return !!block && typeof block === 'object' && THINKING_BLOCK_TYPES.has(block.type)
}

function blockThinkingText(block) {
  if (typeof block.thinking === 'string') return block.thinking
  if (typeof block.reasoning === 'string') return block.reasoning
  if (typeof block.text === 'string') return block.text
  if (typeof block.content === 'string') return block.content
  return ''
}

export function messageText(message) {
  const content = message?.content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .map((block) => {
      if (!block || typeof block !== 'object') return ''
      // Reasoning/thinking blocks are captured separately in `thinking`.
      if (isThinkingBlock(block)) return ''
      if (typeof block.text === 'string') return block.text
      if (typeof block.output_text === 'string') return block.output_text
      return ''
    })
    .filter(Boolean)
    .join('\n')
}

export function messageThinking(message) {
  const content = message?.content
  if (!Array.isArray(content)) return ''
  return content
    .filter(isThinkingBlock)
    .map(blockThinkingText)
    .filter(Boolean)
    .join('\n')
}

function messagePrompt(message) {
  const text = messageText(message)
  return text || stringifyContent(message?.content)
}

function normalizeHistory(messages) {
  return messages.map((message) => ({
    role: messageRole(message),
    content: message?.content ?? null,
  }))
}

function assistantToolCallCount(message) {
  if (!Array.isArray(message?.content)) return 0
  return message.content.filter((block) => block?.type === 'toolCall' || block?.type === 'tool_use').length
}

function usageValue(usage, ...keys) {
  for (const key of keys) {
    const value = usage?.[key]
    if (typeof value === 'number' && Number.isFinite(value)) return value
  }
  return null
}

function latestUserIndex(messages) {
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    if (messageRole(messages[index]) === 'user') return index
  }
  return -1
}

function currentTurnAssistants(messages) {
  const userIndex = latestUserIndex(messages)
  if (userIndex < 0) return []
  const assistants = []
  for (let index = userIndex + 1; index < messages.length; index += 1) {
    if (messageRole(messages[index]) === 'assistant') {
      assistants.push({ index, message: messages[index] })
    }
  }
  return assistants
}

function previousInputIndex(messages, assistantIndex) {
  for (let index = assistantIndex - 1; index >= 0; index -= 1) {
    const role = messageRole(messages[index])
    if (role !== 'assistant' && role !== 'system') return index
  }
  return -1
}

function durationBetween(startedAt, endedAt) {
  const startMs = Date.parse(startedAt || '')
  const endMs = Date.parse(endedAt || '')
  return Number.isFinite(startMs) && Number.isFinite(endMs)
    ? Math.max(0, endMs - startMs)
    : null
}

function fallbackEndTime(toolCalls, toolCursor, toolCallCount, turnEndedAt) {
  if (toolCallCount > 0) {
    const startedAt = toolCalls
      .slice(toolCursor, toolCursor + toolCallCount)
      .map((call) => call?.startedAt)
      .filter((value) => typeof value === 'string' && Number.isFinite(Date.parse(value)))
      .sort()[0]
    if (startedAt) return startedAt
  }
  return turnEndedAt
}

function mergeProjection(existing, projection, useExistingTiming) {
  const startedAt = useExistingTiming && existing?.startedAt
    ? existing.startedAt
    : projection.startedAt
  const endedAt = useExistingTiming && existing?.endedAt
    ? existing.endedAt
    : projection.endedAt
  return {
    ...existing,
    ...projection,
    callId: existing?.callId ?? null,
    startedAt,
    endedAt,
    durationMs: useExistingTiming && typeof existing?.durationMs === 'number'
      ? existing.durationMs
      : durationBetween(startedAt, endedAt),
    requestId: existing?.requestId ?? null,
    apiType: existing?.apiType ?? projection.apiType,
    model: existing?.model || projection.model,
    provider: existing?.provider || projection.provider,
    systemPrompt: existing?.systemPrompt || projection.systemPrompt,
    tokenInput: existing?.tokenInput ?? projection.tokenInput,
    tokenOutput: existing?.tokenOutput ?? projection.tokenOutput,
    tokenCache: existing?.tokenCache ?? projection.tokenCache,
    finishReason: projection.finishReason ?? existing?.finishReason ?? null,
    status: existing?.status === 'failed' ? 'failed' : 'completed',
  }
}

export function reconstructModelCalls({
  messages,
  existingCalls = [],
  toolCalls = [],
  systemPrompt = '',
  fallbackPrompt = '',
  availableToolCount = null,
  provider = null,
  model = null,
  apiType = null,
  turnStartedAt = '',
  turnEndedAt = '',
}) {
  if (!Array.isArray(messages)) return existingCalls
  const assistants = currentTurnAssistants(messages)
  if (!assistants.length) return existingCalls

  const hasTelemetry = existingCalls.some((call) => typeof call?.callId === 'string' && call.callId)
  const timingMatches = hasTelemetry || existingCalls.length === assistants.length
  const assignableCalls = hasTelemetry
    ? existingCalls.filter((call) => call?.status !== 'failed')
    : timingMatches
      ? existingCalls
      : []
  const projections = []
  let toolCursor = 0

  for (let ordinal = 0; ordinal < assistants.length; ordinal += 1) {
    const { index: assistantIndex, message } = assistants[ordinal]
    const existing = assignableCalls[ordinal] ?? null
    const inputIndex = previousInputIndex(messages, assistantIndex)
    const toolCallCount = assistantToolCallCount(message)
    const startedAt = messageTimestamp(message)
      ?? existing?.startedAt
      ?? turnStartedAt
    const endedAt = fallbackEndTime(toolCalls, toolCursor, toolCallCount, turnEndedAt)
      ?? existing?.endedAt
      ?? null
    const usage = message?.usage
    const projection = {
      index: ordinal,
      startedAt,
      endedAt,
      durationMs: durationBetween(startedAt, endedAt),
      model: typeof message?.model === 'string' ? message.model : existing?.model ?? model,
      provider: typeof message?.provider === 'string' ? message.provider : existing?.provider ?? provider,
      systemPrompt: existing?.systemPrompt ?? systemPrompt,
      prompt: inputIndex >= 0 ? messagePrompt(messages[inputIndex]) : fallbackPrompt,
      historyMessages: inputIndex >= 0 ? normalizeHistory(messages.slice(0, inputIndex)) : [],
      toolCount: existing?.toolCount ?? availableToolCount,
      output: messageText(message),
      thinking: messageThinking(message) || existing?.thinking || null,
      tokenInput: usageValue(usage, 'input', 'inputTokens', 'promptTokens'),
      tokenOutput: usageValue(usage, 'output', 'outputTokens', 'completionTokens'),
      tokenCache: usageValue(usage, 'cacheRead', 'cache', 'cachedTokens'),
      finishReason: typeof message?.stopReason === 'string'
        ? message.stopReason
        : typeof message?.finishReason === 'string'
          ? message.finishReason
          : existing?.finishReason ?? null,
      requestId: existing?.requestId ?? null,
      apiType: existing?.apiType ?? apiType,
      status: 'completed',
    }
    projections.push(mergeProjection(existing, projection, timingMatches))
    toolCursor += toolCallCount
  }

  if (!hasTelemetry) {
    return projections.map((call, index) => ({ ...call, index }))
  }

  let projectionIndex = 0
  const merged = existingCalls.map((call) => {
    if (call?.status === 'failed') return call
    const projection = projections[projectionIndex]
    projectionIndex += 1
    return projection ?? call
  })
  while (projectionIndex < projections.length) {
    merged.push(projections[projectionIndex])
    projectionIndex += 1
  }
  return merged.map((call, index) => ({ ...call, index }))
}

export function needsModelCallReconstruction(messages, modelCalls) {
  if (!Array.isArray(messages) || !Array.isArray(modelCalls)) return false
  const assistantCount = currentTurnAssistants(messages).length
  if (!assistantCount) return false
  const completedCount = modelCalls.filter((call) => call?.status !== 'failed').length
  if (assistantCount !== completedCount) return true
  return modelCalls.some((call) => call?.status !== 'failed' && !call?.finishReason)
}
