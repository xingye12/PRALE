import assert from 'node:assert/strict'
import test from 'node:test'
import { needsModelCallReconstruction, reconstructModelCalls } from './trace-reconstruction.js'

function assistant(timestamp, text, stopReason, usage, toolName = null) {
  return {
    role: 'assistant',
    timestamp,
    provider: 'deepseek',
    model: 'deepseek-v4-pro',
    stopReason,
    usage,
    content: [
      ...(text ? [{ type: 'text', text }] : []),
      ...(toolName ? [{ type: 'toolCall', name: toolName }] : []),
    ],
  }
}

function toolResult(timestamp, text) {
  return {
    role: 'toolResult',
    timestamp,
    content: [{ type: 'text', text }],
  }
}

test('splits a three-response tool loop into three model calls', () => {
  const messages = [
    { role: 'user', timestamp: 1000, content: [{ type: 'text', text: '写一份 C++ JD' }] },
    assistant(1100, '先查历史', 'toolUse', { input: 10, output: 2, cacheRead: 3 }, 'memory_search'),
    toolResult(2000, '没有历史'),
    assistant(2100, '开始写文件', 'toolUse', { input: 4, output: 20, cacheRead: 30 }, 'write'),
    toolResult(3000, '写入成功'),
    assistant(3100, 'JD 已生成', 'stop', { input: 1, output: 8, cacheRead: 40 }),
  ]
  const existingCalls = [{
    index: 0,
    startedAt: new Date(1000).toISOString(),
    endedAt: new Date(4000).toISOString(),
    durationMs: 3000,
    model: 'deepseek-v4-pro',
    provider: 'deepseek',
    systemPrompt: 'system',
    prompt: '写一份 C++ JD',
    historyMessages: [],
    toolCount: 72,
    output: '先查历史\n开始写文件\nJD 已生成',
    tokenInput: 15,
    tokenOutput: 30,
    tokenCache: 73,
    finishReason: null,
    requestId: null,
    apiType: 'openai-completions',
    status: 'completed',
  }]
  const toolCalls = [
    { startedAt: new Date(1500).toISOString() },
    { startedAt: new Date(2500).toISOString() },
  ]

  assert.equal(needsModelCallReconstruction(messages, existingCalls), true)
  const calls = reconstructModelCalls({
    messages,
    existingCalls,
    toolCalls,
    systemPrompt: 'system',
    fallbackPrompt: '写一份 C++ JD',
    availableToolCount: 72,
    turnStartedAt: new Date(900).toISOString(),
    turnEndedAt: new Date(4000).toISOString(),
  })

  assert.equal(calls.length, 3)
  assert.deepEqual(calls.map((call) => call.output), ['先查历史', '开始写文件', 'JD 已生成'])
  assert.deepEqual(calls.map((call) => call.finishReason), ['toolUse', 'toolUse', 'stop'])
  assert.deepEqual(calls.map((call) => call.tokenOutput), [2, 20, 8])
  assert.deepEqual(calls.map((call) => call.prompt), ['写一份 C++ JD', '没有历史', '写入成功'])
  assert.deepEqual(calls.map((call) => call.historyMessages.length), [0, 2, 4])
  assert.deepEqual(calls.map((call) => call.durationMs), [400, 400, 900])
})

test('uses only assistants after the latest user and keeps tool-only calls', () => {
  const messages = [
    { role: 'user', timestamp: 1000, content: '上一轮问题' },
    assistant(1100, '上一轮输出 1', 'toolUse', { input: 1, output: 1 }, 'one'),
    toolResult(1200, '结果 1'),
    assistant(1300, '上一轮输出 2', 'toolUse', { input: 1, output: 1 }, 'two'),
    toolResult(1400, '结果 2'),
    assistant(1500, '上一轮输出 3', 'stop', { input: 1, output: 1 }),
    { role: 'user', timestamp: 2000, content: [{ type: 'text', text: '当前问题' }] },
    assistant(2100, '', 'toolUse', { input: 3, output: 9, cacheRead: 20 }, 'write'),
    toolResult(2500, '写入完成'),
    assistant(2600, '当前最终输出', 'stop', { input: 4, output: 5, cacheRead: 30 }),
  ]
  const calls = reconstructModelCalls({
    messages,
    existingCalls: [],
    toolCalls: [{ startedAt: new Date(2300).toISOString() }],
    turnStartedAt: new Date(2000).toISOString(),
    turnEndedAt: new Date(3000).toISOString(),
  })

  assert.equal(calls.length, 2)
  assert.deepEqual(calls.map((call) => call.output), ['', '当前最终输出'])
  assert.deepEqual(calls.map((call) => call.finishReason), ['toolUse', 'stop'])
  assert.equal(calls[0].historyMessages.length, 6)
  assert.equal(calls[0].prompt, '当前问题')
  assert.equal(calls[1].prompt, '写入完成')
})

test('preserves model telemetry timings and failed attempts', () => {
  const messages = [
    { role: 'user', timestamp: 1000, content: '问题' },
    assistant(2000, '回答', 'stop', { input: 5, output: 6 }),
  ]
  const existingCalls = [
    {
      index: 0,
      callId: 'failed-call',
      startedAt: new Date(1100).toISOString(),
      endedAt: new Date(1200).toISOString(),
      durationMs: 100,
      status: 'failed',
      finishReason: 'error',
    },
    {
      index: 1,
      callId: 'successful-call',
      startedAt: new Date(1300).toISOString(),
      endedAt: new Date(1900).toISOString(),
      durationMs: 600,
      status: 'completed',
      model: 'gpt-5.6-luna',
      provider: 'custom',
      systemPrompt: 'hermes system',
      tokenInput: 120,
      tokenOutput: 9,
      tokenCache: 40,
      finishReason: null,
    },
  ]
  const calls = reconstructModelCalls({
    messages,
    existingCalls,
    turnEndedAt: new Date(2100).toISOString(),
  })

  assert.equal(calls.length, 2)
  assert.equal(calls[0].status, 'failed')
  assert.equal(calls[1].callId, 'successful-call')
  assert.equal(calls[1].durationMs, 600)
  assert.equal(calls[1].model, 'gpt-5.6-luna')
  assert.equal(calls[1].provider, 'custom')
  assert.equal(calls[1].systemPrompt, 'hermes system')
  assert.equal(calls[1].tokenInput, 120)
  assert.equal(calls[1].tokenOutput, 9)
  assert.equal(calls[1].tokenCache, 40)
  assert.equal(calls[1].finishReason, 'stop')
  assert.equal(calls[1].output, '回答')
})
