#!/usr/bin/env python3
import json
import sys
import os
import urllib.request

TEMPLATES_CACHE_DIR = os.path.expanduser(
    "~/.openclaw/.wattclaw-team/templates")

AGENT_TEMPLATES_URL = "https://wattclaw-team.tos-cn-beijing.volces.com/templates/agent-templates.json"
PROJECT_TEMPLATES_URL = "https://wattclaw-team.tos-cn-beijing.volces.com/templates/project-templates.json"
SKILL_TEMPLATES_URL = "https://wattclaw-team.tos-cn-beijing.volces.com/templates/skill-templates.json"

# Remote templates disabled - TOS bucket returns 404. Manager plans from scratch.
DISABLE_REMOTE_TEMPLATES = True

# Emit warning once if no templates available, so Manager knows to proceed without them
_WARNED_NO_TEMPLATES = False


def read_workspace_file(workspace, filename):
    if not workspace:
        return ""
    filepath = os.path.join(workspace, filename)
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def download_json(url, cache_filename):
    # TEMP: skip the network call when remote templates are disabled. Fall back
    # to a local cache if one exists, otherwise return None so the Manager plans
    # the team from scratch. This avoids 404 WARN noise from the dead TOS bucket.
    if DISABLE_REMOTE_TEMPLATES:
        cache_path = os.path.join(TEMPLATES_CACHE_DIR, cache_filename)
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return None

    os.makedirs(TEMPLATES_CACHE_DIR, exist_ok=True)
    cache_path = os.path.join(TEMPLATES_CACHE_DIR, cache_filename)
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = resp.read().decode("utf-8")
        parsed = json.loads(data)
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(parsed, f, ensure_ascii=False, indent=2)
        return parsed
    except Exception as e:
        print(f"WARN: failed to download {url}: {e}", file=sys.stderr)
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return None


def do_prepare():
    global _WARNED_NO_TEMPLATES
    result = {}

    has_any_templates = False

    agent_templates_data = download_json(
        AGENT_TEMPLATES_URL, "agent-templates.json")
    if agent_templates_data and isinstance(agent_templates_data, list):
        result["agentTemplates"] = [
            {
                "name": t.get("Name", ""),
                "shortDescription": t.get("ShortDescription", ""),
            }
            for t in agent_templates_data
        ]
        has_any_templates = True
    else:
        result["agentTemplates"] = []

    project_templates_data = download_json(
        PROJECT_TEMPLATES_URL, "project-templates.json")
    if project_templates_data and isinstance(project_templates_data, list):
        result["projectTemplates"] = [
            {
                "name": t.get("Name", ""),
                "description": t.get("Description", "")[:200],
                "memberCount": len(t.get("ProjectMembers", [])),
                "memberNames": [m.get("Name", "")
                                for m in t.get("ProjectMembers", [])],
            }
            for t in project_templates_data
        ]
        has_any_templates = True
    else:
        result["projectTemplates"] = []

    local_skills = set()
    skills_dir = os.path.expanduser("~/.agents/skills/")
    if os.path.isdir(skills_dir):
        local_skills = set(
            d for d in os.listdir(skills_dir)
            if os.path.isdir(os.path.join(skills_dir, d))
        )

    remote_skills_data = download_json(
        SKILL_TEMPLATES_URL, "skill-templates.json")
    remote_skills = []
    if remote_skills_data and isinstance(remote_skills_data, list):
        remote_skills = [
            {
                "name": s.get("name", ""),
                "description": s.get("description", ""),
            }
            for s in remote_skills_data
        ]
        has_any_templates = True

    result["skills"] = sorted(local_skills)
    result["remoteSkills"] = remote_skills

    openclaw_config_path = os.path.expanduser("~/.openclaw/openclaw.json")
    agents = []
    try:
        with open(openclaw_config_path, "r", encoding="utf-8") as f:
            openclaw_config = json.load(f)
        agents_list = openclaw_config.get("agents", {}).get("list", [])
        for agent in agents_list:
            agent_id = agent.get("id", "")
            if not agent_id.startswith("p-"):
                workspace = agent.get("workspace", "")
                agents.append({
                    "name": agent.get("name", ""),
                    "identity": read_workspace_file(workspace, "IDENTITY.md"),
                })
    except Exception:
        pass
    result["agents"] = agents

    # Emit a single INFO line if remote templates are unavailable
    if not has_any_templates and not _WARNED_NO_TEMPLATES:
        print("INFO: remote templates unavailable - planning from scratch with local skills only", file=sys.stderr)
        _WARNED_NO_TEMPLATES = True

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    do_prepare()
