// AudioWorklet processor：主线程外运行，仅转发原始 Float32 PCM 帧。
// 攒批与下采样在主线程 composable 完成（便于单测）。
// process 不写入 outputs（静音），避免麦克风回放/回声。
class VoicePcmProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const channel = inputs[0] && inputs[0][0]
    if (channel && channel.length) {
      this.port.postMessage(channel)
    }
    return true
  }
}

registerProcessor('voice-pcm-processor', VoicePcmProcessor)
