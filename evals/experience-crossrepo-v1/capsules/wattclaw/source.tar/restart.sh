#!/bin/bash
# OpenClaw 重启脚本 - 停止所有服务后重新启动

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

echo "正在停止所有服务..."
pkill -f "node server/index.js" 2>/dev/null
pkill -f "vite" 2>/dev/null
pkill -f "start.sh" 2>/dev/null
sleep 1

# 确认进程已停止
if pgrep -f "node server/index.js" >/dev/null 2>&1 || pgrep -f "vite" >/dev/null 2>&1; then
  echo "等待进程退出..."
  sleep 2
fi

echo "启动服务..."
exec ./start.sh
