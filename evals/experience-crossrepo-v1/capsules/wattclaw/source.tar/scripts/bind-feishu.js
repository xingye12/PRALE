#!/usr/bin/env node
// Feishu OAuth binding management script
// Usage:
//   node scripts/bind-feishu.js bind <WattClaw-UUID> <feishu_user_id>
//   node scripts/bind-feishu.js unbind <feishu_user_id>
//   node scripts/bind-feishu.js rebind <WattClaw-UUID> <feishu_user_id>
//   node scripts/bind-feishu.js list
//   node scripts/bind-feishu.js file <bindings.csv>

import Database from 'better-sqlite3'
import { randomUUID } from 'crypto'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { readFileSync } from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const dbPath = join(__dirname, '../data/wizard.db')
const db = new Database(dbPath)

const [, , command, ...params] = process.argv

function bind(userId, feishuUserId, { throwInsteadOfExit = false } = {}) {
  const user = db.prepare('SELECT id, username FROM users WHERE id = ?').get(userId)
  if (!user) {
    const msg = `User not found: ${userId}`
    if (throwInsteadOfExit) throw new Error(msg)
    console.error(`❌ ${msg}`); process.exit(1)
  }
  const existing = db.prepare('SELECT id FROM user_oauth_bindings WHERE provider = ? AND feishu_user_id = ?').get('feishu', feishuUserId)
  if (existing) {
    const msg = `feishu_user_id ${feishuUserId} already bound`
    if (throwInsteadOfExit) throw new Error(msg)
    console.error(`❌ ${msg}`); process.exit(1)
  }
  db.prepare(`
    INSERT INTO user_oauth_bindings (id, user_id, provider, feishu_user_id, created_at, updated_at)
    VALUES (?, ?, 'feishu', ?, ?, ?)
  `).run(randomUUID(), userId, feishuUserId, Date.now(), Date.now())
  console.log(`✅ Bound feishu:${feishuUserId} → ${user.username} (${userId})`)
}

function unbind(feishuUserId) {
  const result = db.prepare('DELETE FROM user_oauth_bindings WHERE provider = ? AND feishu_user_id = ?').run('feishu', feishuUserId)
  if (result.changes === 0) {
    console.error(`❌ No binding found for feishu_user_id: ${feishuUserId}`)
    process.exit(1)
  }
  console.log(`✅ Unbound feishu:${feishuUserId}`)
}

function rebind(userId, feishuUserId) {
  const user = db.prepare('SELECT id, username FROM users WHERE id = ?').get(userId)
  if (!user) {
    console.error(`❌ User not found: ${userId}`); process.exit(1)
  }
  // Check new feishu_user_id is available BEFORE deleting old binding
  const existing = db.prepare('SELECT id FROM user_oauth_bindings WHERE provider = ? AND feishu_user_id = ?').get('feishu', feishuUserId)
  if (existing) {
    console.error(`❌ feishu_user_id ${feishuUserId} already bound to another user`); process.exit(1)
  }
  db.prepare('DELETE FROM user_oauth_bindings WHERE provider = ? AND user_id = ?').run('feishu', userId)
  db.prepare(`
    INSERT INTO user_oauth_bindings (id, user_id, provider, feishu_user_id, created_at, updated_at)
    VALUES (?, ?, 'feishu', ?, ?, ?)
  `).run(randomUUID(), userId, feishuUserId, Date.now(), Date.now())
  console.log(`✅ Rebound ${user.username} (${userId}) → feishu:${feishuUserId}`)
}

function list() {
  const rows = db.prepare(`
    SELECT b.feishu_user_id, b.open_id, b.display_name, u.username, b.created_at
    FROM user_oauth_bindings b
    JOIN users u ON u.id = b.user_id
    WHERE b.provider = 'feishu'
    ORDER BY b.created_at DESC
  `).all()
  if (rows.length === 0) {
    console.log('No bindings found.')
    return
  }
  console.log(`${'feishu_user_id'.padEnd(40)} ${'username'.padEnd(20)} ${'display_name'.padEnd(15)} created_at`)
  console.log('-'.repeat(100))
  for (const r of rows) {
    console.log(`${r.feishu_user_id.padEnd(40)} ${r.username.padEnd(20)} ${(r.display_name || '-').padEnd(15)} ${new Date(r.created_at).toISOString()}`)
  }
}

function batchFile(filePath) {
  const content = readFileSync(filePath, 'utf-8')
  const lines = content.trim().split('\n')
  let success = 0, failed = 0
  for (const line of lines) {
    const [userId, feishuUserId] = line.split(',').map(s => s.trim())
    if (!userId || !feishuUserId) { failed++; continue }
    try {
      bind(userId, feishuUserId, { throwInsteadOfExit: true })
      success++
    } catch (e) {
      console.error(`  ❌ ${userId} ← ${feishuUserId}: ${e.message}`)
      failed++
    }
  }
  console.log(`\nBatch done: ${success} success, ${failed} failed`)
}

// Dispatch by positional command
switch (command) {
  case 'bind':
    if (params.length < 2) { console.error('Usage: bind <user-id> <feishu-user-id>'); process.exit(1) }
    bind(params[0], params[1])
    break
  case 'unbind':
    if (params.length < 1) { console.error('Usage: unbind <feishu-user-id>'); process.exit(1) }
    unbind(params[0])
    break
  case 'rebind':
    if (params.length < 2) { console.error('Usage: rebind <user-id> <feishu-user-id>'); process.exit(1) }
    rebind(params[0], params[1])
    break
  case 'list':
    list()
    break
  case 'file':
    if (params.length < 1) { console.error('Usage: file <bindings.csv>'); process.exit(1) }
    batchFile(params[0])
    break
  default:
    console.log('Usage:')
    console.log('  node scripts/bind-feishu.js bind <user-id> <feishu-user-id>')
    console.log('  node scripts/bind-feishu.js unbind <feishu-user-id>')
    console.log('  node scripts/bind-feishu.js rebind <user-id> <feishu-user-id>')
    console.log('  node scripts/bind-feishu.js list')
    console.log('  node scripts/bind-feishu.js file <bindings.csv>')
    process.exit(1)
}

db.close()
