#!/bin/sh
set -eu

provider="${OPENCLAW_WEB_SEARCH_PROVIDER:-}"
enabled="${OPENCLAW_WEB_SEARCH_ENABLED:-}"
max_results="${OPENCLAW_WEB_SEARCH_MAX_RESULTS:-}"

# Leave existing tenant configuration untouched when web search is not configured.
if [ -z "$provider" ] && [ -z "$enabled" ] && [ -z "${BRAVE_API_KEY:-}" ]; then
  exit 0
fi

run_openclaw() {
  if command -v openclaw >/dev/null 2>&1; then
    openclaw "$@"
  elif [ -f /app/openclaw.mjs ]; then
    node /app/openclaw.mjs "$@"
  elif [ -f ./openclaw.mjs ]; then
    node ./openclaw.mjs "$@"
  else
    echo "Cannot find openclaw CLI or openclaw.mjs inside container" >&2
    return 127
  fi
}

if [ -z "$provider" ]; then
  if [ -n "${BRAVE_API_KEY:-}" ]; then
    provider="brave"
  else
    provider="duckduckgo"
  fi
fi

if [ -z "$enabled" ]; then
  enabled="true"
fi

run_openclaw config set tools.web.search.enabled "$enabled" --strict-json

if [ "$enabled" = "false" ]; then
  exit 0
fi

if [ "$provider" = "brave" ]; then
  run_openclaw config set plugins.entries.brave.enabled true --strict-json
elif [ "$provider" = "duckduckgo" ]; then
  run_openclaw config set plugins.entries.duckduckgo.enabled true --strict-json
fi

# The Brave plugin may be installed by WattClaw immediately after the first
# container start. Keep that first boot healthy and retry on the restart.
if ! run_openclaw config set tools.web.search.provider "$provider"; then
  echo "[web-search] provider=$provider is not available yet; retrying after plugin provisioning" >&2
  exit 0
fi

if [ -n "$max_results" ]; then
  case "$max_results" in
    ''|*[!0-9]*)
      echo "OPENCLAW_WEB_SEARCH_MAX_RESULTS must be an integer" >&2
      exit 2
      ;;
  esac
  run_openclaw config set tools.web.search.maxResults "$max_results" --strict-json
fi

echo "[web-search] configured provider=$provider enabled=$enabled"
