#!/usr/bin/env node
import Database from 'better-sqlite3'
import { copyFileSync, existsSync, mkdirSync, statSync, writeFileSync } from 'fs'
import { dirname, join, resolve } from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const rootDir = resolve(__dirname, '..')

const args = new Set(process.argv.slice(2))
const apply = args.has('--apply')
const vacuum = args.has('--vacuum')
const json = args.has('--json')
const dbArg = process.argv.find((arg) => arg.startsWith('--db='))
const dbPath = resolve(rootDir, dbArg ? dbArg.slice('--db='.length) : 'data/wizard.db')
const backupDir = resolve(rootDir, 'backups/database-hygiene')

const requiredTables = [
  'agent_team',
  'auth_tokens',
  'backup_records',
  'cron_jobs',
  'issues',
  'model_health_checks',
  'models',
  'notification_reads',
  'notifications',
  'oauth_states',
  'openclaw_tenants',
  'scenarios',
  'skill_store_agent_skill',
  'skill_store_skill',
  'tasks',
  'user_agents',
  'user_channels',
  'user_model_providers',
  'user_oauth_bindings',
  'user_sessions',
  'user_tenant_assignments',
  'users',
]

const deprecatedTables = [
  'model_remarks_deprecated',
]

function quoteIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`
}

function nowStamp() {
  return new Date().toISOString().replace(/[:.]/g, '-')
}

function getTables(db) {
  return db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all()
    .map((row) => row.name)
}

function tableExists(db, table) {
  return Boolean(db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?").get(table))
}

function columnExists(db, table, column) {
  if (!tableExists(db, table)) return false
  return db.prepare(`PRAGMA table_info(${quoteIdentifier(table)})`).all().some((row) => row.name === column)
}

function countRows(db, table) {
  return db.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdentifier(table)}`).get().count
}

function safeCount(db, sql, params = []) {
  try {
    return db.prepare(sql).get(...params).count
  } catch {
    return null
  }
}

function runDelete(db, sql, params = []) {
  if (!apply) return 0
  return db.prepare(sql).run(...params).changes
}

function buildReport(db) {
  const tables = getTables(db)
  const rowCounts = Object.fromEntries(tables.map((table) => [table, countRows(db, table)]))
  const unexpectedTables = tables.filter((table) => !requiredTables.includes(table) && !deprecatedTables.includes(table))
  const missingTables = requiredTables.filter((table) => !tables.includes(table))
  const presentDeprecatedTables = deprecatedTables.filter((table) => tables.includes(table))

  const checks = []

  if (tableExists(db, 'auth_tokens')) {
    checks.push({
      name: 'expired_auth_tokens',
      table: 'auth_tokens',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM auth_tokens WHERE expires_at <= ?', [Date.now()]),
    })
  }

  if (tableExists(db, 'oauth_states')) {
    checks.push({
      name: 'expired_oauth_states',
      table: 'oauth_states',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM oauth_states WHERE created_at < ?', [Date.now() - 5 * 60 * 1000]),
    })
  }

  if (tableExists(db, 'backup_records')) {
    checks.push({
      name: 'old_completed_backup_records',
      table: 'backup_records',
      action: 'delete',
      count: safeCount(
        db,
        "SELECT COUNT(*) AS count FROM backup_records WHERE status IN ('completed', 'failed') AND created_at < ?",
        [Date.now() - 30 * 24 * 60 * 60 * 1000],
      ),
    })
  }

  if (tableExists(db, 'tasks') && tableExists(db, 'scenarios')) {
    checks.push({
      name: 'orphan_tasks',
      table: 'tasks',
      action: 'delete',
      count: safeCount(
        db,
        'SELECT COUNT(*) AS count FROM tasks WHERE scenario_id IS NOT NULL AND scenario_id != \'\' AND scenario_id NOT IN (SELECT id FROM scenarios)',
      ),
    })
  }

  if (tableExists(db, 'auth_tokens') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_auth_tokens',
      table: 'auth_tokens',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM auth_tokens WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_agents') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_user_agents',
      table: 'user_agents',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_agents WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_sessions') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_user_sessions',
      table: 'user_sessions',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_sessions WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_channels') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_user_channels',
      table: 'user_channels',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_channels WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_model_providers') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_user_model_providers',
      table: 'user_model_providers',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_model_providers WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_oauth_bindings') && tableExists(db, 'users')) {
    checks.push({
      name: 'orphan_user_oauth_bindings',
      table: 'user_oauth_bindings',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_oauth_bindings WHERE user_id NOT IN (SELECT id FROM users)'),
    })
  }

  if (tableExists(db, 'user_tenant_assignments')) {
    const hasUsers = tableExists(db, 'users')
    const hasTenants = tableExists(db, 'openclaw_tenants')
    if (hasUsers) {
      checks.push({
        name: 'orphan_user_tenant_assignments_user',
        table: 'user_tenant_assignments',
        action: 'delete',
        count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_tenant_assignments WHERE user_id NOT IN (SELECT id FROM users)'),
      })
    }
    if (hasTenants) {
      checks.push({
        name: 'orphan_user_tenant_assignments_tenant',
        table: 'user_tenant_assignments',
        action: 'delete',
        count: safeCount(db, 'SELECT COUNT(*) AS count FROM user_tenant_assignments WHERE tenant_id NOT IN (SELECT id FROM openclaw_tenants)'),
      })
    }
  }

  if (tableExists(db, 'notification_reads')) {
    const hasNotifications = tableExists(db, 'notifications')
    const hasUsers = tableExists(db, 'users')
    if (hasNotifications) {
      checks.push({
        name: 'orphan_notification_reads_notification',
        table: 'notification_reads',
        action: 'delete',
        count: safeCount(db, 'SELECT COUNT(*) AS count FROM notification_reads WHERE notification_id NOT IN (SELECT id FROM notifications)'),
      })
    }
    if (hasUsers) {
      checks.push({
        name: 'orphan_notification_reads_user',
        table: 'notification_reads',
        action: 'delete',
        count: safeCount(db, 'SELECT COUNT(*) AS count FROM notification_reads WHERE user_id NOT IN (SELECT id FROM users)'),
      })
    }
  }

  if (tableExists(db, 'skill_store_agent_skill') && tableExists(db, 'skill_store_skill')) {
    checks.push({
      name: 'orphan_skill_store_agent_skill_skill',
      table: 'skill_store_agent_skill',
      action: 'delete',
      count: safeCount(db, 'SELECT COUNT(*) AS count FROM skill_store_agent_skill WHERE skill_id NOT IN (SELECT id FROM skill_store_skill)'),
    })
  }

  if (tableExists(db, 'model_remarks_deprecated')) {
    checks.push({
      name: 'deprecated_model_remarks_table',
      table: 'model_remarks_deprecated',
      action: 'drop_table',
      count: countRows(db, 'model_remarks_deprecated'),
    })
  }

  const sessionColumns = [
    'tenant_id',
    'model',
    'model_provider',
    'peer_id',
    'display_title',
    'last_message_at',
    'usage_synced_at',
  ].filter((column) => columnExists(db, 'user_sessions', column))

  return {
    dbPath,
    mode: apply ? 'apply' : 'dry-run',
    generatedAt: new Date().toISOString(),
    fileSizeBytes: statSync(dbPath).size,
    tables,
    rowCounts,
    missingTables,
    unexpectedTables,
    deprecatedTables: presentDeprecatedTables,
    userSessionsOptionalColumns: sessionColumns,
    checks,
  }
}

function applyCleanup(db, report) {
  const changes = []

  const operations = [
    ['expired_auth_tokens', "DELETE FROM auth_tokens WHERE expires_at <= ?", [Date.now()]],
    ['expired_oauth_states', 'DELETE FROM oauth_states WHERE created_at < ?', [Date.now() - 5 * 60 * 1000]],
    [
      'old_completed_backup_records',
      "DELETE FROM backup_records WHERE status IN ('completed', 'failed') AND created_at < ?",
      [Date.now() - 30 * 24 * 60 * 60 * 1000],
    ],
    [
      'orphan_tasks',
      'DELETE FROM tasks WHERE scenario_id IS NOT NULL AND scenario_id != \'\' AND scenario_id NOT IN (SELECT id FROM scenarios)',
      [],
    ],
    ['orphan_auth_tokens', 'DELETE FROM auth_tokens WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_agents', 'DELETE FROM user_agents WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_sessions', 'DELETE FROM user_sessions WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_channels', 'DELETE FROM user_channels WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_model_providers', 'DELETE FROM user_model_providers WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_oauth_bindings', 'DELETE FROM user_oauth_bindings WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_tenant_assignments_user', 'DELETE FROM user_tenant_assignments WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_user_tenant_assignments_tenant', 'DELETE FROM user_tenant_assignments WHERE tenant_id NOT IN (SELECT id FROM openclaw_tenants)', []],
    ['orphan_notification_reads_notification', 'DELETE FROM notification_reads WHERE notification_id NOT IN (SELECT id FROM notifications)', []],
    ['orphan_notification_reads_user', 'DELETE FROM notification_reads WHERE user_id NOT IN (SELECT id FROM users)', []],
    ['orphan_skill_store_agent_skill_skill', 'DELETE FROM skill_store_agent_skill WHERE skill_id NOT IN (SELECT id FROM skill_store_skill)', []],
  ]

  db.transaction(() => {
    for (const [name, sql, params] of operations) {
      const check = report.checks.find((item) => item.name === name)
      if (!check || !check.count) continue
      changes.push({ name, changes: runDelete(db, sql, params) })
    }

    if (tableExists(db, 'model_remarks_deprecated')) {
      db.exec('DROP TABLE model_remarks_deprecated')
      changes.push({ name: 'deprecated_model_remarks_table', changes: 1 })
    }
  })()

  if (vacuum) {
    db.exec('VACUUM')
    changes.push({ name: 'vacuum', changes: 1 })
  }

  return changes
}

function printReport(report, changes = []) {
  if (json) {
    console.log(JSON.stringify({ ...report, changes }, null, 2))
    return
  }

  console.log(`Database: ${report.dbPath}`)
  console.log(`Mode: ${report.mode}`)
  console.log(`Generated: ${report.generatedAt}`)
  console.log(`Size: ${report.fileSizeBytes} bytes`)
  console.log('')

  console.log('Tables:')
  for (const table of report.tables) {
    console.log(`  ${table}: ${report.rowCounts[table]}`)
  }
  console.log('')

  if (report.missingTables.length > 0) {
    console.log(`Missing expected tables: ${report.missingTables.join(', ')}`)
  }
  if (report.unexpectedTables.length > 0) {
    console.log(`Unexpected tables: ${report.unexpectedTables.join(', ')}`)
  }
  if (report.deprecatedTables.length > 0) {
    console.log(`Deprecated tables: ${report.deprecatedTables.join(', ')}`)
  }
  if (report.userSessionsOptionalColumns.length > 0) {
    console.log(`user_sessions optional columns: ${report.userSessionsOptionalColumns.join(', ')}`)
  }
  console.log('')

  console.log('Cleanup checks:')
  for (const check of report.checks) {
    if (check.count === null) continue
    console.log(`  ${check.name}: ${check.count} (${check.action})`)
  }

  if (changes.length > 0) {
    console.log('')
    console.log('Applied changes:')
    for (const change of changes) {
      console.log(`  ${change.name}: ${change.changes}`)
    }
  }

  if (!apply) {
    console.log('')
    console.log('Dry-run only. Re-run with --apply to write changes.')
  }
}

if (!existsSync(dbPath)) {
  console.error(`Database not found: ${dbPath}`)
  process.exit(1)
}

let backupPath = null
if (apply) {
  mkdirSync(backupDir, { recursive: true })
  backupPath = join(backupDir, `wizard-${nowStamp()}.db`)
  copyFileSync(dbPath, backupPath)
}

const db = new Database(dbPath)
db.pragma('foreign_keys = ON')

const report = buildReport(db)
const changes = apply ? applyCleanup(db, report) : []
const finalReport = apply ? buildReport(db) : report

db.close()

if (backupPath && !json) {
  console.log(`Backup: ${backupPath}`)
}

printReport(finalReport, changes)

if (apply) {
  const reportPath = join(backupDir, `hygiene-report-${nowStamp()}.json`)
  writeFileSync(reportPath, JSON.stringify({ before: report, after: finalReport, changes, backupPath }, null, 2))
  if (!json) console.log(`Report: ${reportPath}`)
}
