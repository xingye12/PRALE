#!/bin/bash
# OpenClaw All-in-One Entrypoint Script
set -e

echo "----------------------------------------------------"
echo "  OpenClaw Consolidated Image v0.2.6 Starting..."
echo "----------------------------------------------------"

# 1. 确保数据目录权限
mkdir -p /app/data /root/.openclaw

# 2. 配置 OpenClaw 网关核心参数
echo "[Gateway] Initializing local provider configuration..."
# 强制设为本地模式以确保 Admin 能通过 127.0.0.1 访问
openclaw config set gateway.mode local
openclaw config set gateway.auth.mode token
# 允许非安全环境下的认证（容器内部环回）
openclaw config set gateway.controlUi.allowInsecureAuth true
openclaw config set gateway.controlUi.allowedOrigins '["*"]'

# 3. 注入认证密钥
if [ ! -z "$OPENCLAW_AUTH_TOKEN" ]; then
    echo "[Gateway] Syncing security token from environment..."
    openclaw config set gateway.auth.token "$OPENCLAW_AUTH_TOKEN"
    openclaw config set gateway.remote.token "$OPENCLAW_AUTH_TOKEN"
elif [ ! -z "$OPENCLAW_GATEWAY_TOKEN" ]; then
    echo "[Gateway] Syncing security token (legacy variable)..."
    openclaw config set gateway.auth.token "$OPENCLAW_GATEWAY_TOKEN"
    openclaw config set gateway.remote.token "$OPENCLAW_GATEWAY_TOKEN"
else
    echo "[Warning] OPENCLAW_AUTH_TOKEN is not set. Gateway might be inaccessible."
fi

# 4. 启动网关服务 (后台运行)
echo "[Gateway] Launching OpenClaw Gateway service..."
openclaw gateway &

# 等待网关链路准备就绪
echo "[System] Waiting for gateway to warm up (5s)..."
sleep 5

# 5. 启动 Admin 后台 (前台执行，接管 PID 1 代理)
echo "[Admin] Launching Management Backend..."
echo "----------------------------------------------------"
exec node server/index.js
