import Database from 'better-sqlite3'
import { existsSync, mkdirSync } from 'fs'
import { dirname, resolve } from 'path'

const args = new Set(process.argv.slice(2))
const apply = args.has('--apply')
const includeAuthTokens = args.has('--include-auth-tokens')
const sourcePath = getArg('--source') || 'old_wizard.db'
const targetPath = getArg('--target') || 'data/wizard.db'
const backupDir = getArg('--backup-dir') || 'backups/db-migration'
const assignTenantId = getArg('--assign-tenant-id')

const sourceFile = resolve(sourcePath)
const targetFile = resolve(targetPath)
const backupRoot = resolve(backupDir)

const baseTables = [
  'users',
  'user_model_providers',
  'skill_store_skill',
  'user_agents',
  'user_channels',
  'user_sessions',
  'skill_store_agent_skill',
  'agent_team',
  'cron_jobs',
  'issues',
  'notifications',
  'notification_reads',
  'user_oauth_bindings',
  'scenarios',
  'tasks',
]

const volatileTables = includeAuthTokens
  ? ['auth_tokens']
  : []

const tables = [...baseTables.slice(0, 1), ...volatileTables, ...baseTables.slice(1)]

main().catch((error) => {
  console.error('[migrate-online-db] failed:', error)
  process.exitCode = 1
})

async function main() {
  assertFile(sourceFile, 'source')
  assertFile(targetFile, 'target')

  const source = new Database(sourceFile, { readonly: true, fileMustExist: true })
  const target = new Database(targetFile, { fileMustExist: true })

  try {
    target.pragma('foreign_keys = ON')
    target.pragma('journal_mode = WAL')

    const plan = buildPlan(source, target)
    printPlan(plan)

    if (!apply) {
      console.log('\nDry run only. Re-run with --apply to write changes.')
      console.log('Optional: add --include-auth-tokens if you deliberately want to migrate login tokens.')
      return
    }

    mkdirSync(backupRoot, { recursive: true })
    const backupPath = resolve(backupRoot, `wizard.db.before-online-migration-${timestamp()}.db`)
    await target.backup(backupPath)
    console.log(`\nBackup created: ${backupPath}`)

    const result = target.transaction(() => {
      const summary = []
      for (const item of plan) {
        const changes = migrateTable(source, target, item)
        summary.push({ table: item.table, changes })
      }
      if (assignTenantId) {
        summary.push(assignTenantForNewUsers(target, assignTenantId))
      }
      validateForeignKeys(target)
      return summary
    })()

    console.log('\nApplied changes:')
    for (const row of result) {
      console.log(`  ${row.table}: inserted=${row.changes.inserted}, skipped=${row.changes.skipped}`)
    }
  } finally {
    source.close()
    target.close()
  }
}

function getArg(name) {
  const prefix = `${name}=`
  const found = process.argv.slice(2).find((arg) => arg.startsWith(prefix))
  return found ? found.slice(prefix.length) : null
}

function assertFile(file, label) {
  if (!existsSync(file)) {
    throw new Error(`${label} database not found: ${file}`)
  }
}

function buildPlan(source, target) {
  const sourceTables = tableSet(source)
  const targetTables = tableSet(target)

  return tables
    .filter((table) => sourceTables.has(table) && targetTables.has(table))
    .map((table) => {
      const sourceColumns = getColumns(source, table)
      const targetColumns = getColumns(target, table)
      const sourceColumnNames = new Set(sourceColumns.map((column) => column.name))
      const commonColumns = targetColumns
        .map((column) => column.name)
        .filter((name) => sourceColumnNames.has(name))
      const keyColumns = getConflictKey(target, table)
      const sourceRows = source.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdent(table)}`).get().count
      const targetRows = target.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdent(table)}`).get().count
      const missing = countMissingRows(source, target, table, keyColumns)

      return {
        table,
        commonColumns,
        keyColumns,
        sourceRows,
        targetRows,
        missing,
        sourceOnlyColumns: sourceColumns
          .map((column) => column.name)
          .filter((name) => !targetColumns.some((column) => column.name === name)),
        targetOnlyColumns: targetColumns
          .map((column) => column.name)
          .filter((name) => !sourceColumnNames.has(name)),
      }
    })
}

function printPlan(plan) {
  console.log(`Source: ${sourceFile}`)
  console.log(`Target: ${targetFile}`)
  console.log(`Mode: ${apply ? 'apply' : 'dry-run'}`)
  console.log('\nMigration plan:')
  for (const item of plan) {
    console.log(
      `  ${item.table}: source=${item.sourceRows}, target=${item.targetRows}, missing=${item.missing}, key=(${item.keyColumns.join(', ')})`,
    )
    if (item.targetOnlyColumns.length > 0) {
      console.log(`    target-only columns will use defaults/nulls: ${item.targetOnlyColumns.join(', ')}`)
    }
    if (item.sourceOnlyColumns.length > 0) {
      console.log(`    source-only columns ignored: ${item.sourceOnlyColumns.join(', ')}`)
    }
  }
}

function migrateTable(source, target, item) {
  const rows = source.prepare(`SELECT ${item.commonColumns.map(quoteIdent).join(', ')} FROM ${quoteIdent(item.table)}`).all()
  const exists = prepareExists(target, item.table, item.keyColumns)
  const insert = prepareInsert(target, item.table, item.commonColumns)
  let inserted = 0
  let skipped = 0

  for (const row of rows) {
    if (shouldSkipRow(item.table, row, target)) {
      skipped += 1
      continue
    }

    const keyValues = item.keyColumns.map((column) => row[column])
    if (exists.get(...keyValues)) {
      skipped += 1
      continue
    }

    try {
      const result = insert.run(...item.commonColumns.map((column) => row[column]))
      inserted += result.changes
      if (result.changes === 0) skipped += 1
    } catch (error) {
      skipped += 1
      console.warn(`  skipped ${item.table} row (${formatKey(item.keyColumns, row)}): ${error.message}`)
    }
  }

  return { inserted, skipped }
}

function shouldSkipRow(table, row, target) {
  if (table === 'user_sessions' && row.user_id) {
    const userExists = target.prepare('SELECT 1 FROM users WHERE id = ?').get(row.user_id)
    return !userExists
  }

  if (table === 'user_agents' && row.user_id) {
    const userExists = target.prepare('SELECT 1 FROM users WHERE id = ?').get(row.user_id)
    return !userExists
  }

  if (table === 'user_channels' && row.user_id) {
    const userExists = target.prepare('SELECT 1 FROM users WHERE id = ?').get(row.user_id)
    return !userExists
  }

  if (table === 'skill_store_agent_skill' && row.skill_id) {
    const skillExists = target.prepare('SELECT 1 FROM skill_store_skill WHERE id = ?').get(row.skill_id)
    return !skillExists
  }

  if (table === 'notification_reads') {
    const notificationExists = target.prepare('SELECT 1 FROM notifications WHERE id = ?').get(row.notification_id)
    const userExists = target.prepare('SELECT 1 FROM users WHERE id = ?').get(row.user_id)
    return !notificationExists || !userExists
  }

  return false
}

function assignTenantForNewUsers(target, tenantId) {
  const tenant = target.prepare('SELECT id FROM openclaw_tenants WHERE id = ?').get(tenantId)
  if (!tenant) {
    throw new Error(`tenant does not exist in target database: ${tenantId}`)
  }

  const now = Date.now()
  const result = target.prepare(`
    INSERT OR IGNORE INTO user_tenant_assignments (user_id, tenant_id, assignment_mode, created_at, updated_at)
    SELECT id, ?, 'manual', ?, ?
    FROM users
    WHERE id NOT IN (SELECT user_id FROM user_tenant_assignments)
  `).run(tenantId, now, now)

  return {
    table: 'user_tenant_assignments',
    changes: { inserted: result.changes, skipped: 0 },
  }
}

function validateForeignKeys(target) {
  const rows = target.prepare('PRAGMA foreign_key_check').all()
  if (rows.length > 0) {
    throw new Error(`foreign key check failed: ${JSON.stringify(rows.slice(0, 20))}`)
  }
}

function countMissingRows(source, target, table, keyColumns) {
  const rows = source.prepare(`SELECT ${keyColumns.map(quoteIdent).join(', ')} FROM ${quoteIdent(table)}`).all()
  const exists = prepareExists(target, table, keyColumns)
  return rows.filter((row) => !exists.get(...keyColumns.map((column) => row[column]))).length
}

function prepareExists(db, table, columns) {
  const where = columns.map((column) => `${quoteIdent(column)} = ?`).join(' AND ')
  return db.prepare(`SELECT 1 FROM ${quoteIdent(table)} WHERE ${where} LIMIT 1`)
}

function prepareInsert(db, table, columns) {
  const columnSql = columns.map(quoteIdent).join(', ')
  const valuesSql = columns.map(() => '?').join(', ')
  return db.prepare(`INSERT OR IGNORE INTO ${quoteIdent(table)} (${columnSql}) VALUES (${valuesSql})`)
}

function getConflictKey(db, table) {
  const pk = getColumns(db, table)
    .filter((column) => column.pk > 0)
    .sort((a, b) => a.pk - b.pk)
    .map((column) => column.name)

  if (pk.length > 0) return pk

  const uniqueIndex = db.prepare(`PRAGMA index_list(${quoteString(table)})`).all().find((row) => row.unique)
  if (!uniqueIndex) {
    throw new Error(`table has no primary key or unique index: ${table}`)
  }

  return db.prepare(`PRAGMA index_info(${quoteString(uniqueIndex.name)})`).all().map((row) => row.name)
}

function getColumns(db, table) {
  return db.prepare(`PRAGMA table_info(${quoteString(table)})`).all()
}

function tableSet(db) {
  const rows = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").all()
  return new Set(rows.map((row) => row.name))
}

function quoteIdent(value) {
  return `"${String(value).replaceAll('"', '""')}"`
}

function quoteString(value) {
  return `'${String(value).replaceAll("'", "''")}'`
}

function formatKey(columns, row) {
  return columns.map((column) => `${column}=${JSON.stringify(row[column])}`).join(', ')
}

function timestamp() {
  const date = new Date()
  const pad = (value) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}
