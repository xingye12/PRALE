import Database from 'better-sqlite3'
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'fs'
import { join, resolve } from 'path'

const args = new Set(process.argv.slice(2))
const apply = args.has('--apply')
const sourcePath = resolve(getArg('--source') || 'openclaw.json')
const tenantsDir = resolve(getArg('--tenants-dir') || 'tenants')
const dbPath = resolve(getArg('--db') || 'data/wizard.db')
const backupDir = resolve(getArg('--backup-dir') || 'backups/openclaw-config-migration')
const reportPath = resolve(getArg('--report') || 'backups/openclaw-config-migration/unresolved-openclaw-config.json')
const onlineOpenClawHome = '/home/wattman/.openclaw'
const tenantOpenClawHome = '/home/node/.openclaw'

main()

function main() {
  assertFile(sourcePath, 'source config')
  assertFile(dbPath, 'database')

  const source = readJson(sourcePath)
  const db = new Database(dbPath, { readonly: true, fileMustExist: true })

  try {
    const resolver = createTenantResolver(db, source)
    const plan = buildPlan(source, resolver)
    printPlan(plan)

    if (!apply) {
      console.log('\nDry run only. Re-run with --apply to write tenant configs.')
      return
    }

    mkdirSync(backupDir, { recursive: true })
    mkdirSync(resolve(reportPath, '..'), { recursive: true })

    for (const tenantPlan of plan.tenants) {
      if (tenantPlan.missingAgents.length === 0 && tenantPlan.missingAccounts.length === 0 && tenantPlan.missingBindings.length === 0) {
        continue
      }

      const file = join(tenantsDir, tenantPlan.tenant, 'openclaw.json')
      const cfg = readJson(file)
      const backupPath = join(backupDir, `${tenantPlan.tenant}.openclaw.${timestamp()}.json`)
      copyFileSync(file, backupPath)

      applyTenantPlan(cfg, source, tenantPlan)
      writeFileSync(file, `${JSON.stringify(cfg, null, 2)}\n`, 'utf8')
      console.log(`updated ${tenantPlan.tenant}, backup=${backupPath}`)
    }

    writeFileSync(reportPath, `${JSON.stringify(plan.unresolved, null, 2)}\n`, 'utf8')
    console.log(`unresolved report=${reportPath}`)
  } finally {
    db.close()
  }
}

function buildPlan(source, resolver) {
  const onlineAgents = asArray(source.agents?.list)
  const onlineAgentById = new Map(onlineAgents.map((agent) => [getAgentId(agent), agent]).filter(([id]) => id))
  const onlineAccounts = source.channels?.feishu?.accounts && isObject(source.channels.feishu.accounts)
    ? source.channels.feishu.accounts
    : {}
  const onlineBindings = asArray(source.bindings)

  const tenantPlans = []
  const unresolved = {
    agents: [],
    channelAccounts: [],
    bindings: [],
  }

  for (const tenant of readdirSync(tenantsDir).sort()) {
    const file = join(tenantsDir, tenant, 'openclaw.json')
    if (!existsSync(file)) continue

    const cfg = readJson(file)
    const existingAgentIds = new Set(asArray(cfg.agents?.list).map(getAgentId).filter(Boolean))
    const existingAccounts = new Set(Object.keys(isObject(cfg.channels?.feishu?.accounts) ? cfg.channels.feishu.accounts : {}))
    const existingBindingKeys = new Set(asArray(cfg.bindings).map(getBindingKey))

    const missingAgents = []
    const missingAccounts = []
    const missingBindings = []

    for (const [id, agent] of onlineAgentById) {
      const tenantId = resolver.resolveTenant(id)
      if (!tenantId) continue
      if (tenantId === tenant && !existingAgentIds.has(id)) {
        missingAgents.push({ id, value: agent })
      }
    }

    for (const [id, account] of Object.entries(onlineAccounts)) {
      if (id === 'default') continue
      const tenantId = resolver.resolveTenant(id)
      if (!tenantId) continue
      if (tenantId === tenant && !existingAccounts.has(id)) {
        missingAccounts.push({ id, value: account })
      }
    }

    for (const binding of onlineBindings) {
      const tenantId = resolver.resolveTenant(binding.agentId) || resolver.resolveTenant(binding.match?.accountId)
      if (!tenantId) continue
      if (tenantId === tenant && !existingBindingKeys.has(getBindingKey(binding))) {
        missingBindings.push(binding)
      }
    }

    tenantPlans.push({ tenant, missingAgents, missingAccounts, missingBindings })
  }

  for (const [id, agent] of onlineAgentById) {
    if (!resolver.resolveTenant(id)) unresolved.agents.push({ id, value: agent })
  }

  for (const [id, account] of Object.entries(onlineAccounts)) {
    if (id !== 'default' && !resolver.resolveTenant(id)) unresolved.channelAccounts.push({ id, value: account })
  }

  for (const binding of onlineBindings) {
    if (!resolver.resolveTenant(binding.agentId) && !resolver.resolveTenant(binding.match?.accountId)) {
      unresolved.bindings.push(binding)
    }
  }

  return {
    tenants: tenantPlans,
    unresolved,
    resolverInferredCount: typeof resolver.inferredCount === 'function' ? resolver.inferredCount() : 0,
  }
}

function applyTenantPlan(cfg, source, tenantPlan) {
  if (!cfg.agents || !isObject(cfg.agents)) cfg.agents = {}
  if (!Array.isArray(cfg.agents.list)) cfg.agents.list = []
  cfg.agents.list.push(...tenantPlan.missingAgents.map((item) => normalizeMigratedValue(item.value)))

  if (tenantPlan.missingAccounts.length > 0) {
    if (!cfg.channels || !isObject(cfg.channels)) cfg.channels = {}
    if (!cfg.channels.feishu || !isObject(cfg.channels.feishu)) {
      const sourceFeishu = source.channels?.feishu && isObject(source.channels.feishu)
        ? structuredClone(source.channels.feishu)
        : {}
      sourceFeishu.accounts = {}
      cfg.channels.feishu = sourceFeishu
    }
    if (!cfg.channels.feishu.accounts || !isObject(cfg.channels.feishu.accounts)) {
      cfg.channels.feishu.accounts = {}
    }
    for (const item of tenantPlan.missingAccounts) {
      cfg.channels.feishu.accounts[item.id] = normalizeFeishuAccount(normalizeMigratedValue(item.value))
    }
  }
  ensureFeishuAccountAllowLists(cfg)

  if (!Array.isArray(cfg.bindings)) cfg.bindings = []
  cfg.bindings.push(...tenantPlan.missingBindings.map(normalizeMigratedValue))
}

function ensureFeishuAccountAllowLists(cfg) {
  const accounts = cfg.channels?.feishu?.accounts
  if (!isObject(accounts)) return

  for (const account of Object.values(accounts)) {
    if (isObject(account)) {
      normalizeFeishuAccount(account)
    }
  }
}

function normalizeFeishuAccount(account) {
  if (!isObject(account)) return account
  account.allowFrom = ['*']
  account.groupAllowFrom = ['*']
  return account
}

function normalizeMigratedValue(value) {
  if (typeof value === 'string') {
    return value.replaceAll(onlineOpenClawHome, tenantOpenClawHome)
  }
  if (Array.isArray(value)) {
    return value.map(normalizeMigratedValue)
  }
  if (isObject(value)) {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, normalizeMigratedValue(item)]),
    )
  }
  return value
}

function createTenantResolver(db, source) {
  const agentRows = db.prepare(`
    SELECT ua.id, ua.gateway_agent_id, uta.tenant_id
    FROM user_agents ua
    LEFT JOIN user_tenant_assignments uta ON uta.user_id = ua.user_id
  `).all()
  const channelRows = db.prepare(`
    SELECT uc.agent_id, uta.tenant_id
    FROM user_channels uc
    LEFT JOIN user_tenant_assignments uta ON uta.user_id = uc.user_id
  `).all()
  const userRows = db.prepare(`
    SELECT u.id, u.username, u.display_name, uta.tenant_id
    FROM users u
    JOIN user_tenant_assignments uta ON uta.user_id = u.id
  `).all()
  const byId = new Map()
  const inferredById = new Map()

  for (const row of agentRows) {
    if (row.tenant_id && row.id) byId.set(row.id, row.tenant_id)
    if (row.tenant_id && row.gateway_agent_id) byId.set(row.gateway_agent_id, row.tenant_id)
  }
  for (const row of channelRows) {
    if (row.tenant_id && row.agent_id && !byId.has(row.agent_id)) byId.set(row.agent_id, row.tenant_id)
  }
  for (const agent of asArray(source.agents?.list)) {
    const id = getAgentId(agent)
    if (!id || byId.has(id)) continue

    const inferred = inferTenantFromAgent(agent, userRows)
    if (!inferred) continue

    byId.set(id, inferred.tenantId)
    inferredById.set(id, inferred)
  }

  return {
    resolveTenant(id) {
      return id ? byId.get(id) || null : null
    },
    inferredCount() {
      return inferredById.size
    },
  }
}

function inferTenantFromAgent(agent, users) {
  const searchText = [agent?.workspace, agent?.id, agent?.name]
    .filter((value) => typeof value === 'string')
    .join('\n')
  if (!searchText) return null

  const hits = []
  for (const user of users) {
    const matched = [user.username, user.display_name]
      .filter((value) => typeof value === 'string' && value.length >= 2)
      .filter((value) => searchText.includes(value))
    if (matched.length > 0) {
      hits.push({
        tenantId: user.tenant_id,
        userId: user.id,
        username: user.username,
        displayName: user.display_name,
        matched,
      })
    }
  }

  const tenantIds = new Set(hits.map((hit) => hit.tenantId))
  if (tenantIds.size !== 1) return null

  return {
    tenantId: hits[0].tenantId,
    hits,
  }
}

function printPlan(plan) {
  const totals = { agents: 0, channelAccounts: 0, bindings: 0 }
  console.log(`Source: ${sourcePath}`)
  console.log(`Tenants: ${tenantsDir}`)
  console.log(`Mode: ${apply ? 'apply' : 'dry-run'}`)
  console.log('\nTenant plan:')

  for (const item of plan.tenants) {
    totals.agents += item.missingAgents.length
    totals.channelAccounts += item.missingAccounts.length
    totals.bindings += item.missingBindings.length
    console.log(
      `  ${item.tenant}: agents=${item.missingAgents.length}, accounts=${item.missingAccounts.length}, bindings=${item.missingBindings.length}`,
    )
  }

  console.log('\nTotals:')
  console.log(`  agents=${totals.agents}`)
  console.log(`  channelAccounts=${totals.channelAccounts}`)
  console.log(`  bindings=${totals.bindings}`)
  console.log(`  inferredByUser=${plan.resolverInferredCount}`)
  console.log('\nUnresolved:')
  console.log(`  agents=${plan.unresolved.agents.length}`)
  console.log(`  channelAccounts=${plan.unresolved.channelAccounts.length}`)
  console.log(`  bindings=${plan.unresolved.bindings.length}`)
}

function getArg(name) {
  const prefix = `${name}=`
  const found = process.argv.slice(2).find((arg) => arg.startsWith(prefix))
  return found ? found.slice(prefix.length) : null
}

function assertFile(file, label) {
  if (!existsSync(file)) throw new Error(`${label} not found: ${file}`)
}

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8'))
}

function getAgentId(agent) {
  return agent?.id || agent?.name || agent?.key || agent?.agentId || agent?.gatewayAgentId || null
}

function getBindingKey(binding) {
  return JSON.stringify({ agentId: binding?.agentId || null, match: binding?.match || null })
}

function asArray(value) {
  return Array.isArray(value) ? value : []
}

function isObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value)
}

function timestamp() {
  const date = new Date()
  const pad = (value) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}
