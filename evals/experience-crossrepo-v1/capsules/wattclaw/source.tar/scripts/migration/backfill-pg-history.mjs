#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { createGatewayHttpClient, fetchHistoryFromGateway } from './lib/gateway-http.mjs';
import { createPgPool, mergeSessionMessages } from './lib/db-helpers.mjs';

const DRY_RUN = process.env.DRY_RUN === 'true' || process.argv.includes('--dry-run');
const SOURCE_GATEWAY_URL = process.env.SOURCE_GATEWAY_URL;
const SOURCE_GATEWAY_AUTH = process.env.SOURCE_GATEWAY_AUTH;
const NEW_PG_URL = process.env.NEW_PG_URL;
const SESSION_KEY_LIST = process.env.SESSION_KEY_LIST; // comma-separated or path to file
const CONCURRENCY = parseInt(process.env.CONCURRENCY ?? '3', 10);
const TIMEOUT = parseInt(process.env.TIMEOUT ?? '30000', 10);

function logInfo(...args) {
  // eslint-disable-next-line no-console
  console.error(...args);
}

function logOut(obj) {
  console.log(JSON.stringify(obj, null, 2));
}

function usage() {
  logInfo(`Usage: node backfill-pg-history.mjs [--dry-run]

Environment variables:
  SOURCE_GATEWAY_URL   Base URL of the OpenClaw Gateway
  SOURCE_GATEWAY_AUTH  Bearer token for Gateway
  NEW_PG_URL           PostgreSQL connection string
  SESSION_KEY_LIST     Comma-separated session keys, or path to a file with one key per line
  CONCURRENCY          Max parallel fetches (default: 3)
  TIMEOUT              Per-request timeout ms (default: 30000)
  DRY_RUN              Set to "true" to skip writes
`);
  process.exit(1);
}

async function resolveSessionKeys() {
  if (!SESSION_KEY_LIST) return [];
  const raw = SESSION_KEY_LIST.trim();
  if (!raw) return [];

  // If it contains a slash or ends with .txt/.json, treat as file path
  if (/[\/\\]/.test(raw) || /\.(txt|json|csv|list)$/i.test(raw)) {
    try {
      const text = readFileSync(raw, 'utf-8');
      return text
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length > 0 && !l.startsWith('#'));
    } catch (err) {
      throw new Error(`Failed to read session key file "${raw}": ${err.message}`);
    }
  }

  return raw.split(',').map((k) => k.trim()).filter(Boolean);
}

async function fetchSessionKeysFromGateway(client) {
  try {
    const payload = await client.get('/sessions.list', {}, TIMEOUT);
    if (Array.isArray(payload)) return payload;
    if (payload && Array.isArray(payload.sessions)) return payload.sessions;
    if (payload && Array.isArray(payload.list)) return payload.list;
    if (payload && Array.isArray(payload.data)) return payload.data;
    return [];
  } catch (err) {
    logInfo('Warning: failed to list sessions from gateway:', err.message);
    return [];
  }
}

async function run() {
  if (!SOURCE_GATEWAY_URL || !SOURCE_GATEWAY_AUTH || !NEW_PG_URL) {
    usage();
  }

  const gateway = createGatewayHttpClient(SOURCE_GATEWAY_URL, SOURCE_GATEWAY_AUTH);
  const pgPool = createPgPool(NEW_PG_URL);

  let sessionKeys = await resolveSessionKeys();
  if (sessionKeys.length === 0) {
    sessionKeys = await fetchSessionKeysFromGateway(gateway);
  }
  if (sessionKeys.length === 0) {
    logInfo('No session keys to process. Exiting.');
    await pgPool.end();
    process.exit(0);
  }

  logInfo(`Processing ${sessionKeys.length} session(s), concurrency=${CONCURRENCY}, dryRun=${DRY_RUN}`);

  const report = {
    dryRun: DRY_RUN,
    totalSessions: sessionKeys.length,
    succeeded: 0,
    failed: 0,
    totalInserted: 0,
    totalUpdated: 0,
    totalSkipped: 0,
    errors: [],
    sessions: [],
  };

  // Simple concurrency semaphore
  const queue = [...sessionKeys];
  let active = 0;
  let idx = 0;

  await new Promise((resolve) => {
    function next() {
      if (idx >= queue.length && active === 0) {
        resolve();
        return;
      }
      while (active < CONCURRENCY && idx < queue.length) {
        const key = queue[idx++];
        active++;
        (async () => {
          const start = Date.now();
          try {
            logInfo(`[${key}] Fetching history...`);
            const messages = await fetchHistoryFromGateway(gateway, key, 1000);
            logInfo(`[${key}] Fetched ${messages.length} message(s)`);

            const merged = await mergeSessionMessages(pgPool, key, messages, DRY_RUN);
            report.sessions.push({
              sessionKey: key,
              status: 'ok',
              messages: messages.length,
              ...merged,
              elapsedMs: Date.now() - start,
            });
            report.totalInserted += merged.inserted;
            report.totalUpdated += merged.updated;
            report.totalSkipped += merged.skipped;
            report.succeeded++;
          } catch (err) {
            report.sessions.push({
              sessionKey: key,
              status: 'error',
              error: err.message,
              elapsedMs: Date.now() - start,
            });
            report.errors.push({ sessionKey: key, error: err.message });
            report.failed++;
          } finally {
            active--;
            next();
          }
        })();
      }
    }
    next();
  });

  await pgPool.end();

  logInfo('\n--- Summary ---');
  logInfo(`Sessions: ${report.succeeded} succeeded, ${report.failed} failed`);
  logInfo(`Messages: ${report.totalInserted} inserted, ${report.totalUpdated} updated, ${report.totalSkipped} skipped`);
  if (DRY_RUN) logInfo('DRY RUN: no writes were performed.');

  logOut(report);
}

run().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
