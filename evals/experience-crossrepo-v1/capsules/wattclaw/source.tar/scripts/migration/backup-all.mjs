#!/usr/bin/env node
import { exec } from 'child_process';
import { promisify } from 'util';
import { createHash } from 'crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';

const execAsync = promisify(exec);

// ------------------------------------------------------------------
// Environment
// ------------------------------------------------------------------
const DEST = process.env.BACKUP_DEST_DIR;
const DRY_RUN = process.env.DRY_RUN === 'true';

if (!DEST) {
  console.error('Missing required env var: BACKUP_DEST_DIR');
  process.exit(1);
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

function now() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function sha256File(path) {
  const buf = readFileSync(path);
  return createHash('sha256').update(buf).digest('hex');
}

function log(msg) {
  console.log(`[${DRY_RUN ? 'DRY-RUN' : 'RUN'}] ${msg}`);
}

async function localSize(path) {
  try {
    const { stdout } = await execAsync(`du -sb ${JSON.stringify(path)} 2>/dev/null || echo 0`);
    const match = stdout.trim().match(/^(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  } catch {
    return 0;
  }
}

async function localCommand(cmd, label) {
  log(`${label}: ${cmd}`);
  if (DRY_RUN) {
    return { code: 0, stdout: '', stderr: '' };
  }
  try {
    const { stdout, stderr } = await execAsync(cmd);
    return { code: 0, stdout: stdout || '', stderr: stderr || '' };
  } catch (err) {
    return { code: err.code || 1, stdout: err.stdout || '', stderr: err.stderr || '' };
  }
}

function localEnsureDir(dir) {
  if (!DRY_RUN && !existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
}

// ------------------------------------------------------------------
// Backup definitions
// ------------------------------------------------------------------

const TIMESTAMP = now();
const BACKUP_DIR = join(DEST, `backup-${TIMESTAMP}`);

const TASKS = [
  {
    name: 'openclaw-home',
    type: 'tar',
    source: '/home/openclaw',
    destFile: join(BACKUP_DIR, 'openclaw-home.tar.gz'),
    command: (src, dst) =>
      `tar czf ${JSON.stringify(dst)} -C / ${JSON.stringify(src.replace(/^\//, ''))}`,
  },
  {
    name: 'pg-dump',
    type: 'pg_dump',
    db: 'wattclaw',
    destFile: join(BACKUP_DIR, 'wattclaw-db.sql.gz'),
    command: (_src, dst) =>
      `pg_dump -Fc ${JSON.stringify('wattclaw')} | gzip > ${JSON.stringify(dst)}`,
  },
  {
    name: 'wizard-db',
    type: 'sqlite',
    source: '/home/openclaw/wizard/data/wizard.db',
    destFile: join(BACKUP_DIR, 'wizard.db'),
    command: (src, dst) =>
      `cp ${JSON.stringify(src)} ${JSON.stringify(dst)}`,
  },
  {
    name: 'openclaw-web-wizard',
    type: 'sqlite',
    source: '/home/openclaw/web-wizard/data/web-wizard.db',
    destFile: join(BACKUP_DIR, 'web-wizard.db'),
    command: (src, dst) =>
      `cp ${JSON.stringify(src)} ${JSON.stringify(dst)}`,
  },
];

// ------------------------------------------------------------------
// Main
// ------------------------------------------------------------------

async function main() {
  log(`Backup destination: ${BACKUP_DIR}`);
  localEnsureDir(BACKUP_DIR);

  const backups = [];

  for (const task of TASKS) {
    log(`Task: ${task.name}`);

    let sizeBefore = 0;
    if (task.source) {
      sizeBefore = await localSize(task.source);
      log(`  size before: ${sizeBefore} bytes`);
    }

    const cmd = task.command(task.source, task.destFile);
    const { code, stderr } = await localCommand(cmd, task.name);

    if (code !== 0 && !DRY_RUN) {
      console.error(`  FAILED: ${stderr}`);
      backups.push({
        name: task.name,
        status: 'failed',
        error: stderr.trim(),
      });
      continue;
    }

    let sha256 = null;
    let sizeAfter = 0;
    if (!DRY_RUN) {
      try {
        sha256 = sha256File(task.destFile);
        sizeAfter = readFileSync(task.destFile).length;
      } catch (e) {
        console.error(`  checksum error: ${e.message}`);
      }
    }

    backups.push({
      name: task.name,
      status: 'ok',
      source: task.source ?? task.db ?? null,
      destFile: task.destFile,
      sizeBefore,
      sizeAfter,
      sha256,
    });
  }

  const totalSize = backups.reduce((sum, b) => sum + (b.sizeAfter || 0), 0);

  const report = {
    timestamp: TIMESTAMP,
    dryRun: DRY_RUN,
    backups,
    totalSize,
  };

  const reportPath = join(BACKUP_DIR, 'report.json');
  if (!DRY_RUN) {
    writeFileSync(reportPath, JSON.stringify(report, null, 2));
  }

  log(`Report written to ${reportPath}`);
  console.log(JSON.stringify(report, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
