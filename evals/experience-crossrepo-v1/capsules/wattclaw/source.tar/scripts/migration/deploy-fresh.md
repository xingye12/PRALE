# 全新部署运行手册 (deploy-fresh)

## 概述

本文档描述如何使用 `deploy-fresh.mjs` 在目标服务器上执行 WattClaw + OpenClaw 的全新部署。

脚本在**本地服务器**直接执行，无需 SSH 远程登录。

---

## 前置条件

1. 当前服务器已安装 Docker 与 Docker Compose。
2. 当前服务器已安装 Node.js (>= 18)。
3. 环境变量已配置（见下方）。
4. 已克隆代码仓库到本地目录。

---

## 环境变量

| 变量名 | 必填 | 默认值 | 说明 |
|--------|------|--------|------|
| `DEPLOY_DIR` | 是 | — | 本地部署目录（如 `/home/openclaw`） |
| `OPENCLAW_IMAGE` | 否 | `ghcr.io/openclaw/openclaw:latest` | 租户容器镜像 |
| `DRY_RUN` | 否 | `false` | 设为 `true` 时仅打印命令，不实际执行 |
| `OPENCLAW_INITIAL_TENANTS` | 否 | `3` | 初始租户数量 |

---

## 执行步骤

### 1. 设置环境变量

```bash
export DEPLOY_DIR=/home/openclaw
export OPENCLAW_IMAGE=ghcr.io/openclaw/openclaw:latest
# export DRY_RUN=true   # 如需演练，取消注释
```

### 2. 运行部署脚本

```bash
node scripts/migration/deploy-fresh.mjs
```

### 3. 查看输出

脚本会在 stderr 打印每一步的执行日志，并在 stdout 输出 JSON 格式的最终报告，包含：

- `steps` — 每个部署步骤的状态与耗时
- `healthChecks` — 各服务健康检查结果

---

## 部署流程详解

脚本按以下顺序执行：

1. **clone-repo** — 在本地克隆或拉取代码仓库
2. **build-admin** — 执行 `npm ci` + `npm run build` 构建前端与管理后台
3. **start-postgres** — 启动 PostgreSQL 容器 (`docker compose up -d new-postgres`)
4. **init-wizard-db** — 初始化 wizard 数据库 (`sync-wizard-db.mjs --init`)
5. **start-admin** — 以 `OPENCLAW_MULTI_TENANT=true` 启动 admin 容器
6. **create-tenants** — 同步 wizard 数据库并创建租户 (`sync-wizard-db.mjs`)
7. **start-tenants** — 启动租户容器 `openclaw-tenant-1` 至 `openclaw-tenant-N`

---

## 健康检查清单

部署完成后，脚本会自动检查以下项目：

| 检查项 | 命令示例 | 期望结果 |
|--------|----------|----------|
| admin-http | 容器内请求 `http://localhost:3002/api/health` | HTTP 200 |
| postgres | `pg_isready -U wattclaw` | 返回 0 |
| tenant-1 | `docker compose ps tenant-1` 状态为 `Up` | 返回 0 |
| tenant-2 | `docker compose ps tenant-2` 状态为 `Up` | 返回 0 |
| tenant-3 | `docker compose ps tenant-3` 状态为 `Up` | 返回 0 |

---

## 验证清单

- [ ] 脚本输出中所有 `steps` 状态为 `ok`
- [ ] 所有 `healthChecks` 状态为 `ok`
- [ ] 可通过浏览器访问 `http://localhost:3002` 打开管理面板
- [ ] 各租户 Gateway 端口可连通（默认 `18789` 起）

---

## 回滚命令

若部署失败，可执行以下命令回滚：

```bash
# 停止并移除所有容器
cd $DEPLOY_DIR && docker compose down -v

# 删除部署目录（谨慎操作）
rm -rf $DEPLOY_DIR

# 仅停止租户容器，保留数据
cd $DEPLOY_DIR && docker compose stop openclaw-tenant-1 openclaw-tenant-2 openclaw-tenant-3
```

---

## 演练模式 (Dry Run)

在正式执行前，建议先使用演练模式验证命令：

```bash
DRY_RUN=true node scripts/migration/deploy-fresh.mjs
```

演练模式下：
- 所有命令仅打印，不实际执行
- 健康检查返回 `dry-run` 状态
- 最终报告标记 `dryRun: true`

---

## 故障排查

| 现象 | 可能原因 | 处理建议 |
|------|----------|----------|
| clone-repo 失败 | 无 Git 或网络不通 | 检查 Git 安装与网络连接 |
| build-admin 失败 | Node.js 版本过低或依赖冲突 | 确认 Node.js >= 18，删除 `node_modules` 重试 |
| start-postgres 失败 | 端口 5432 被占用 | 修改 `.env` 中的 `POSTGRES_PORT` |
| init-wizard-db 失败 | SQLite 文件缺失或权限不足 | 检查 `data/` 目录权限 |
| healthCheck 失败 | 容器启动慢或配置错误 | 查看容器日志 `docker compose logs <service>` |

---

## 相关文件

- `scripts/migration/deploy-fresh.mjs` — 部署脚本
- `scripts/migration/sync-wizard-db.mjs` — Wizard 数据库同步工具
- `docker-compose.wattclaw.yml` — WattClaw 多租户编排文件
