#!/usr/bin/env node
import { exec } from 'child_process';
import { promisify } from 'util';
import { writeReport } from './lib/report.mjs';

const execAsync = promisify(exec);

// ------------------------------------------------------------------
// Environment
// ------------------------------------------------------------------
const DEPLOY_DIR = process.env.DEPLOY_DIR;
const IMAGE      = process.env.OPENCLAW_IMAGE || 'ghcr.io/openclaw/openclaw:latest';
const DRY_RUN    = process.env.DRY_RUN === 'true' || process.argv.includes('--dry-run');

// Validate DEPLOY_DIR to prevent command injection
if (!DEPLOY_DIR || !/^[A-Za-z0-9._/-]+$/.test(DEPLOY_DIR)) {
  console.error('Invalid DEPLOY_DIR: must be an absolute path with only alphanumeric, dot, underscore, slash, and hyphen characters');
  process.exit(1);
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------
function log(msg) {
  console.log(`[${DRY_RUN ? 'DRY-RUN' : 'RUN'}] ${msg}`);
}

async function local(cmd, label) {
  log(`${label}: ${cmd}`);
  if (DRY_RUN) {
    return { code: 0, stdout: '', stderr: '' };
  }
  try {
    const { stdout, stderr } = await execAsync(cmd, { cwd: DEPLOY_DIR });
    return { code: 0, stdout: stdout || '', stderr: stderr || '' };
  } catch (err) {
    return { code: err.code || 1, stdout: err.stdout || '', stderr: err.stderr || '' };
  }
}

async function healthCheck(label, cmd, expectCode = 0) {
  log(`Health check: ${label}`);
  if (DRY_RUN) {
    return { name: label, status: 'dry-run', stdout: '', stderr: '' };
  }
  try {
    const { stdout, stderr } = await execAsync(cmd, { cwd: DEPLOY_DIR });
    const ok = 0 === expectCode;
    return { name: label, status: ok ? 'ok' : 'failed', code: 0, stdout: stdout.trim(), stderr: stderr.trim() };
  } catch (err) {
    const ok = (err.code ?? 1) === expectCode;
    return { name: label, status: ok ? 'ok' : 'failed', code: err.code ?? 1, stdout: err.stdout?.trim() || '', stderr: err.stderr?.trim() || '' };
  }
}

// ------------------------------------------------------------------
// Steps
// ------------------------------------------------------------------
const steps = [];
const healthChecks = [];

async function runStep(name, action) {
  const start = Date.now();
  try {
    const result = await action();
    steps.push({ name, status: 'ok', elapsedMs: Date.now() - start, ...result });
    log(`Step OK: ${name}`);
  } catch (err) {
    steps.push({ name, status: 'failed', elapsedMs: Date.now() - start, error: err.message });
    log(`Step FAILED: ${name}: ${err.message}`);
    throw err; // stop on first failure
  }
}

// ------------------------------------------------------------------
// Main
// ------------------------------------------------------------------
async function main() {
  log(`Deploy directory: ${DEPLOY_DIR}`);
  log(`Image: ${IMAGE}`);
  log(`Dry-run: ${DRY_RUN}`);

  // 1. clone-repo
  await runStep('clone-repo', async () => {
    const repoUrl = 'https://github.com/wattman/openclaw.git';
    const cloneCmd = `git clone ${repoUrl} . || git pull`;
    const { code, stdout, stderr } = await local(cloneCmd, 'clone-repo');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'clone failed');
    return { stdout: stdout.trim() };
  });

  // 2. build-admin
  await runStep('build-admin', async () => {
    const cmd = `npm ci && npm run build`;
    const { code, stdout, stderr } = await local(cmd, 'build-admin');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'build failed');
    return { stdout: stdout.trim() };
  });

  // 3. start-postgres
  await runStep('start-postgres', async () => {
    const cmd = `docker compose up -d new-postgres`;
    const { code, stdout, stderr } = await local(cmd, 'start-postgres');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'postgres start failed');
    return { stdout: stdout.trim() };
  });

  // 4. init-wizard-db
  await runStep('init-wizard-db', async () => {
    const cmd = `node scripts/migration/sync-wizard-db.mjs --init`;
    const { code, stdout, stderr } = await local(cmd, 'init-wizard-db');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'wizard db init failed');
    return { stdout: stdout.trim() };
  });

  // 5. start-admin
  await runStep('start-admin', async () => {
    const cmd = `OPENCLAW_MULTI_TENANT=true docker compose up -d wattclaw`;
    const { code, stdout, stderr } = await local(cmd, 'start-admin');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'admin start failed');
    return { stdout: stdout.trim() };
  });

  // 6. create-tenants (sync-wizard-db)
  await runStep('create-tenants', async () => {
    const cmd = `node scripts/migration/sync-wizard-db.mjs`;
    const { code, stdout, stderr } = await local(cmd, 'create-tenants');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'tenant creation failed');
    return { stdout: stdout.trim() };
  });

  // 7. start-tenants
  await runStep('start-tenants', async () => {
    const tenantCount = parseInt(process.env.OPENCLAW_INITIAL_TENANTS || '3', 10);
    const tenantNames = Array.from({ length: tenantCount }, (_, i) => `openclaw-tenant-${i + 1}`);
    const cmd = `docker compose up -d ${tenantNames.join(' ')}`;
    const { code, stdout, stderr } = await local(cmd, 'start-tenants');
    if (code !== 0 && !DRY_RUN) throw new Error(stderr || 'tenant start failed');
    return { stdout: stdout.trim(), tenantCount, tenants: tenantNames };
  });

  // ------------------------------------------------------------------
  // Health checks
  // ------------------------------------------------------------------
  healthChecks.push(await healthCheck(
    'admin-http',
    `docker compose exec -T wattclaw node -e "require('http').get('http://localhost:3002/api/health', (r) => process.exit(r.statusCode === 200 ? 0 : 1)).on('error', () => process.exit(1))"`,
    0
  ));

  healthChecks.push(await healthCheck(
    'postgres',
    `docker compose exec -T new-postgres pg_isready -U wattclaw`,
    0
  ));

  for (const tenant of ['tenant-1', 'tenant-2', 'tenant-3']) {
    healthChecks.push(await healthCheck(
      tenant,
      `docker compose ps ${tenant} | grep -q 'Up'`,
      0
    ));
  }

  // ------------------------------------------------------------------
  // Report
  // ------------------------------------------------------------------
  const report = {
    dryRun: DRY_RUN,
    target: DEPLOY_DIR,
    image: IMAGE,
    steps,
    healthChecks,
  };

  writeReport(report);
  log('Deployment complete.');
}

main().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
