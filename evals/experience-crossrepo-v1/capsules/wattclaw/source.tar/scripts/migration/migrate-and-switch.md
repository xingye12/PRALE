# 迁移切换运行手册 (migrate-and-switch)

## 概述

本文档描述 `migrate-and-switch.mjs` 的使用方法，用于分阶段将单实例 OpenClaw 升级并迁移到多租户架构。

脚本在**本地服务器**直接执行，无需 SSH 远程登录。

---

## 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| `PHASE` | 否 | 执行阶段：`1`、`1.5`、`2`、`3`、`all`（默认 `all`） |
| `DRY_RUN` | 否 | 设为 `true` 时只打印命令，不实际执行 |

---

## 阶段说明

### Phase 1 — 单实例原地升级 latest

将现有单实例原地升级到 `ghcr.io/openclaw/openclaw:latest`。

步骤：
1. **backup** — 打包 `/home/openclaw` 到备份目录
2. **pm2 stop** — 停止现有服务
3. **npm install** — 全局安装新版本
4. **pm2 start** — 启动服务
5. **verify** — HTTP health check 验证

执行：
```bash
PHASE=1 DRY_RUN=true node scripts/migration/migrate-and-switch.mjs
```

回滚命令：
```bash
pm2 stop openclaw || true
npm install -g alpine/openclaw@previous-version || true
pm2 start openclaw || pm2 restart openclaw
```

---

### Phase 1.5 — 新 PG 灌满

将历史数据灌入新的 PostgreSQL。

步骤：
1. **migrate-pg-whitelist** — 迁移白名单数据
2. **backfill-pg-history** — 回填会话历史消息
3. **verify-coverage** — 查询 `session_messages` 表确认有数据

执行：
```bash
PHASE=1.5 DRY_RUN=true node scripts/migration/migrate-and-switch.mjs
```

回滚命令：
```bash
psql -d wattclaw -c "TRUNCATE TABLE session_messages CASCADE;" || true
psql -d wattclaw -c "TRUNCATE TABLE sessions CASCADE;" || true
```

---

### Phase 2 — 数据灌入新环境

将 Wizard DB 和 openclaw.json 拆分到新多租户环境。

步骤：
1. **sync-wizard** — 同步 SQLite Wizard DB 到目标
2. **split-openclaw-json** — 按租户拆分 `openclaw.json`
3. **copy workspaces** — 复制工作区文件
4. **restart tenants** — 重启所有租户服务

执行：
```bash
PHASE=2 DRY_RUN=true node scripts/migration/migrate-and-switch.mjs
```

回滚命令：
```bash
rm -rf /home/openclaw/tenants/shared/workspaces || true
rm -f /home/openclaw/tenants/*/openclaw.json || true
pm2 restart all || true
```

---

### Phase 3 — 切换+灰度

通过 Nginx 配置进行灰度切换。

步骤：
1. **nginx canary** — 切换到灰度配置（部分流量）
2. **verify** — 验证灰度健康
3. **nginx full** — 切换到全量配置
4. **verify** — 验证全量健康

执行：
```bash
PHASE=3 DRY_RUN=true node scripts/migration/migrate-and-switch.mjs
```

回滚命令：
```bash
cp /etc/nginx/sites-available/openclaw-legacy /etc/nginx/sites-enabled/openclaw && nginx -s reload || true
nginx -t && nginx -s reload || true
```

---

## 全量执行（all）

按顺序执行 Phase 1 → 1.5 → 2 → 3：

```bash
PHASE=all DRY_RUN=true node scripts/migration/migrate-and-switch.mjs
```

去掉 `DRY_RUN=true` 正式执行。

---

## 验证检查清单

每阶段执行后请确认：

- [ ] Phase 1: `http://localhost:3000/health` 返回 200
- [ ] Phase 1.5: `session_messages` 表记录数 > 0
- [ ] Phase 2: 各租户目录下 `openclaw.json` 存在且非空
- [ ] Phase 3: Nginx 灰度和全量切换后 health 均 200
- [ ] 全量执行后：业务功能测试通过（登录、对话、文件管理）

---

## 输出报告

脚本执行完成后输出 JSON 报告到 `stdout`，同时写入 `reports/migrate-and-switch-<timestamp>.json`。

报告结构：
```json
{
  "phase": "all",
  "dryRun": false,
  "elapsedMs": 12345,
  "overall": "ok",
  "results": [
    { "step": "phase1-backup", "status": "ok", "timestamp": "..." }
  ],
  "rollbacks": [ "..." ]
}
```

---

## 注意事项

1. 生产环境执行前务必先 `DRY_RUN=true` 演练
2. 各阶段脚本（`migrate-pg-whitelist.mjs`、`backfill-pg-history.mjs` 等）需已部署到目标主机的 `/home/openclaw/scripts/`
3. Nginx 配置模板（`openclaw-canary`、`openclaw-full`、`openclaw-legacy`）需预先准备好
