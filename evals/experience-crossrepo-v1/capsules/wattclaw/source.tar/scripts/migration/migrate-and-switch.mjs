#!/usr/bin/env node
import { exec } from 'child_process';
import { promisify } from 'util';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const execAsync = promisify(exec);
const __dirname = dirname(fileURLToPath(import.meta.url));

// ── Environment ────────────────────────────────────────────────────────────
const PHASE  = process.env.PHASE || 'all';
const DRY_RUN = process.env.DRY_RUN === 'true' || process.argv.includes('--dry-run');

const VALID_PHASES = ['1', '1.5', '2', '3', 'all'];

if (!VALID_PHASES.includes(PHASE)) {
  console.error(`Invalid PHASE "${PHASE}". Must be one of: ${VALID_PHASES.join(', ')}`);
  process.exit(1);
}

// ── Logging & helpers ──────────────────────────────────────────────────────
function log(label, msg) {
  const prefix = DRY_RUN ? '[DRY-RUN]' : '[RUN]';
  console.error(`${prefix} [${label}] ${msg}`);
}

function reportStep(step, status, detail = {}) {
  return { step, status, timestamp: new Date().toISOString(), ...detail };
}

async function local(cmd, label) {
  log(label, cmd);
  if (DRY_RUN) {
    return { code: 0, stdout: '', stderr: '' };
  }
  try {
    const { stdout, stderr } = await execAsync(cmd);
    return { code: 0, stdout: stdout || '', stderr: stderr || '' };
  } catch (err) {
    return { code: err.code || 1, stdout: err.stdout || '', stderr: err.stderr || '' };
  }
}

async function verifyHttp(url, expectStatus = 200, timeout = 30) {
  const cmd = `curl -sf -o /dev/null -w "%{http_code}" --max-time ${timeout} ${JSON.stringify(url)}`;
  const { code, stdout } = await local(cmd, 'verify-http');
  const ok = code === 0 && stdout.trim() === String(expectStatus);
  return { ok, status: stdout.trim(), code };
}

// ── Phase 1: 单实例原地升级 6.9 ─────────────────────────────────────────────
async function runPhase1(results) {
  log('Phase 1', '单实例原地升级 6.9');

  // 1.1 Backup
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const backupCmd = `mkdir -p /home/openclaw/backup && tar czf /home/openclaw/backup/openclaw-home-${ts}.tar.gz -C / home/openclaw`;
  const r1 = await local(backupCmd, 'phase1-backup');
  results.push(reportStep('phase1-backup', r1.code === 0 ? 'ok' : 'failed', {
    code: r1.code, stderr: r1.stderr?.slice(0, 200),
  }));
  if (r1.code !== 0 && !DRY_RUN) throw new Error('Phase 1 backup failed');

  // 1.2 PM2 stop
  const r2 = await local('pm2 stop openclaw || true', 'phase1-pm2-stop');
  results.push(reportStep('phase1-pm2-stop', r2.code === 0 ? 'ok' : 'warning', {
    code: r2.code, stderr: r2.stderr?.slice(0, 200),
  }));

  // 1.3 npm install global package
  const r3 = await local('npm install -g alpine/openclaw@2026.6.9-browser', 'phase1-npm-install');
  results.push(reportStep('phase1-npm-install', r3.code === 0 ? 'ok' : 'failed', {
    code: r3.code, stderr: r3.stderr?.slice(0, 200),
  }));
  if (r3.code !== 0 && !DRY_RUN) throw new Error('Phase 1 npm install failed');

  // 1.4 PM2 start
  const r4 = await local('pm2 start openclaw || pm2 restart openclaw', 'phase1-pm2-start');
  results.push(reportStep('phase1-pm2-start', r4.code === 0 ? 'ok' : 'failed', {
    code: r4.code, stderr: r4.stderr?.slice(0, 200),
  }));
  if (r4.code !== 0 && !DRY_RUN) throw new Error('Phase 1 pm2 start failed');

  // 1.5 Verify
  await new Promise((r) => setTimeout(r, 3000));
  const v1 = await verifyHttp('http://localhost:3000/health');
  results.push(reportStep('phase1-verify', v1.ok ? 'ok' : 'failed', v1));
  if (!v1.ok && !DRY_RUN) throw new Error('Phase 1 verification failed');
}

function rollbackPhase1() {
  return [
    'pm2 stop openclaw || true',
    'npm install -g alpine/openclaw@previous-version || true',
    'pm2 start openclaw || pm2 restart openclaw',
  ];
}

// ── Phase 1.5: 新 PG 灌满 ───────────────────────────────────────────────────
async function runPhase15(results) {
  log('Phase 1.5', '新 PG 灌满');

  // 1.5.1 migrate-pg-whitelist
  const r1 = await local('node /home/openclaw/scripts/migrate-pg-whitelist.mjs', 'phase1.5-whitelist');
  results.push(reportStep('phase1.5-whitelist', r1.code === 0 ? 'ok' : 'failed', {
    code: r1.code, stderr: r1.stderr?.slice(0, 200),
  }));
  if (r1.code !== 0 && !DRY_RUN) throw new Error('Phase 1.5 whitelist migration failed');

  // 1.5.2 backfill-pg-history
  const r2 = await local('node /home/openclaw/scripts/backfill-pg-history.mjs', 'phase1.5-backfill');
  results.push(reportStep('phase1.5-backfill', r2.code === 0 ? 'ok' : 'failed', {
    code: r2.code, stderr: r2.stderr?.slice(0, 200),
  }));
  if (r2.code !== 0 && !DRY_RUN) throw new Error('Phase 1.5 backfill failed');

  // 1.5.3 verify-coverage
  const r3 = await local(
    'psql -d wattclaw -c "SELECT COUNT(*) FROM session_messages;"',
    'phase1.5-verify-coverage'
  );
  const countMatch = r3.stdout?.match(/(\d+)/);
  const count = countMatch ? parseInt(countMatch[1], 10) : 0;
  const ok = r3.code === 0 && count > 0;
  results.push(reportStep('phase1.5-verify-coverage', ok ? 'ok' : 'failed', {
    count, code: r3.code,
  }));
  if (!ok && !DRY_RUN) throw new Error('Phase 1.5 coverage verification failed');
}

function rollbackPhase15() {
  return [
    'psql -d wattclaw -c "TRUNCATE TABLE session_messages CASCADE;" || true',
    'psql -d wattclaw -c "TRUNCATE TABLE sessions CASCADE;" || true',
  ];
}

// ── Phase 2: 数据灌入新环境 ────────────────────────────────────────────────────
async function runPhase2(results) {
  log('Phase 2', '数据灌入新环境');

  // 2.1 sync-wizard
  const r1 = await local('node /home/openclaw/scripts/sync-wizard-db.mjs', 'phase2-sync-wizard');
  results.push(reportStep('phase2-sync-wizard', r1.code === 0 ? 'ok' : 'failed', {
    code: r1.code, stderr: r1.stderr?.slice(0, 200),
  }));
  if (r1.code !== 0 && !DRY_RUN) throw new Error('Phase 2 sync-wizard failed');

  // 2.2 split-openclaw-json
  const r2 = await local('node /home/openclaw/scripts/split-openclaw-json.mjs', 'phase2-split-json');
  results.push(reportStep('phase2-split-json', r2.code === 0 ? 'ok' : 'failed', {
    code: r2.code, stderr: r2.stderr?.slice(0, 200),
  }));
  if (r2.code !== 0 && !DRY_RUN) throw new Error('Phase 2 split-openclaw-json failed');

  // 2.3 copy workspaces
  const r3 = await local(
    'cp -r /home/openclaw/wizard/data/workspaces /home/openclaw/tenants/shared/workspaces || true',
    'phase2-copy-workspaces'
  );
  results.push(reportStep('phase2-copy-workspaces', r3.code === 0 ? 'ok' : 'warning', {
    code: r3.code, stderr: r3.stderr?.slice(0, 200),
  }));

  // 2.4 restart tenants
  const r4 = await local('pm2 restart all || true', 'phase2-restart-tenants');
  results.push(reportStep('phase2-restart-tenants', r4.code === 0 ? 'ok' : 'warning', {
    code: r4.code, stderr: r4.stderr?.slice(0, 200),
  }));
}

function rollbackPhase2() {
  return [
    'rm -rf /home/openclaw/tenants/shared/workspaces || true',
    'rm -f /home/openclaw/tenants/*/openclaw.json || true',
    'pm2 restart all || true',
  ];
}

// ── Phase 3: 切换+灰度 ───────────────────────────────────────────────────────
async function runPhase3(results) {
  log('Phase 3', '切换+灰度');

  // 3.1 nginx canary
  const r1 = await local(
    'cp /etc/nginx/sites-available/openclaw-canary /etc/nginx/sites-enabled/openclaw && nginx -s reload',
    'phase3-nginx-canary'
  );
  results.push(reportStep('phase3-nginx-canary', r1.code === 0 ? 'ok' : 'failed', {
    code: r1.code, stderr: r1.stderr?.slice(0, 200),
  }));
  if (r1.code !== 0 && !DRY_RUN) throw new Error('Phase 3 nginx canary failed');

  // 3.2 verify canary
  await new Promise((r) => setTimeout(r, 2000));
  const v1 = await verifyHttp('http://localhost:3000/health');
  results.push(reportStep('phase3-verify-canary', v1.ok ? 'ok' : 'failed', v1));
  if (!v1.ok && !DRY_RUN) throw new Error('Phase 3 canary verification failed');

  // 3.3 nginx full
  const r2 = await local(
    'cp /etc/nginx/sites-available/openclaw-full /etc/nginx/sites-enabled/openclaw && nginx -s reload',
    'phase3-nginx-full'
  );
  results.push(reportStep('phase3-nginx-full', r2.code === 0 ? 'ok' : 'failed', {
    code: r2.code, stderr: r2.stderr?.slice(0, 200),
  }));
  if (r2.code !== 0 && !DRY_RUN) throw new Error('Phase 3 nginx full failed');

  // 3.4 verify full
  await new Promise((r) => setTimeout(r, 2000));
  const v2 = await verifyHttp('http://localhost:3000/health');
  results.push(reportStep('phase3-verify-full', v2.ok ? 'ok' : 'failed', v2));
  if (!v2.ok && !DRY_RUN) throw new Error('Phase 3 full verification failed');
}

function rollbackPhase3() {
  return [
    'cp /etc/nginx/sites-available/openclaw-legacy /etc/nginx/sites-enabled/openclaw && nginx -s reload || true',
    'nginx -t && nginx -s reload || true',
  ];
}

// ── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  const results = [];
  const rollbacks = [];
  const start = Date.now();

  const phasesToRun = PHASE === 'all' ? ['1', '1.5', '2', '3'] : [PHASE];

  for (const p of phasesToRun) {
    try {
      if (p === '1') {
        await runPhase1(results);
        rollbacks.push(...rollbackPhase1());
      } else if (p === '1.5') {
        await runPhase15(results);
        rollbacks.push(...rollbackPhase15());
      } else if (p === '2') {
        await runPhase2(results);
        rollbacks.push(...rollbackPhase2());
      } else if (p === '3') {
        await runPhase3(results);
        rollbacks.push(...rollbackPhase3());
      }
    } catch (err) {
      results.push(reportStep(`phase-${p}-fatal`, 'failed', { error: err.message }));
      break;
    }
  }

  const failed = results.filter((r) => r.status === 'failed');
  const report = {
    phase: PHASE,
    dryRun: DRY_RUN,
    elapsedMs: Date.now() - start,
    overall: failed.length === 0 ? 'ok' : 'failed',
    results,
    rollbacks: [...new Set(rollbacks)],
  };

  // Write report
  const reportDir = join(__dirname, '../../reports');
  if (!DRY_RUN) {
    if (!existsSync(reportDir)) mkdirSync(reportDir, { recursive: true });
    const reportPath = join(reportDir, `migrate-and-switch-${Date.now()}.json`);
    writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf-8');
    log('Report', `written to ${reportPath}`);
  }

  console.log(JSON.stringify(report, null, 2));

  if (failed.length > 0 && !DRY_RUN) {
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
