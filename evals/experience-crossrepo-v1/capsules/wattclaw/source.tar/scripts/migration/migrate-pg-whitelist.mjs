#!/usr/bin/env node
import Database from 'better-sqlite3';
import { createPgPool } from './lib/db-helpers.mjs';

const DRY_RUN = process.env.DRY_RUN === 'true' || process.argv.includes('--dry-run');
const OLD_PG_URL = process.env.OLD_PG_URL;
const NEW_PG_URL = process.env.NEW_PG_URL;
const WIZARD_DB_PATH = process.env.WIZARD_DB_PATH;
const BATCH_SIZE = parseInt(process.env.BATCH_SIZE ?? '500', 10);

function logInfo(...args) {
  // eslint-disable-next-line no-console
  console.error(...args);
}

function logOut(obj) {
  console.log(JSON.stringify(obj, null, 2));
}

function usage() {
  logInfo(`Usage: node migrate-pg-whitelist.mjs [--dry-run]

Environment variables:
  OLD_PG_URL        Source PostgreSQL connection string
  NEW_PG_URL        Target PostgreSQL connection string
  WIZARD_DB_PATH    Path to wizard.db SQLite file (whitelist source)
  BATCH_SIZE        Rows per batch (default: 500)
  DRY_RUN           Set to "true" to skip writes
`);
  process.exit(1);
}

async function loadWhitelist(dbPath) {
  const db = new Database(dbPath, { readonly: true });
  try {
    const rows = db.prepare('SELECT DISTINCT session_key FROM user_sessions').all();
    return new Set(rows.map((r) => r.session_key).filter(Boolean));
  } finally {
    db.close();
  }
}

async function countOldRows(pool, whitelist) {
  if (whitelist.size === 0) return 0;
  const keys = Array.from(whitelist);
  const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
  const result = await pool.query(
    `SELECT COUNT(*)::int AS c FROM session_messages WHERE session_key IN (${placeholders})`,
    keys
  );
  return result.rows[0]?.c ?? 0;
}

async function* batchReadOldPg(pool, whitelist, batchSize) {
  if (whitelist.size === 0) return;
  const keys = Array.from(whitelist);
  const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');

  let lastSeq = null;
  let lastSessionKey = null;
  let hasMore = true;

  while (hasMore) {
    let query;
    let params;

    if (lastSessionKey === null) {
      query = `
        SELECT session_key, msg_id, role, content, ts, seq, fingerprint, created_at, updated_at
        FROM session_messages
        WHERE session_key IN (${placeholders})
        ORDER BY session_key, seq
        LIMIT $${keys.length + 1}
      `;
      params = [...keys, batchSize];
    } else {
      query = `
        SELECT session_key, msg_id, role, content, ts, seq, fingerprint, created_at, updated_at
        FROM session_messages
        WHERE session_key IN (${placeholders})
          AND (session_key, seq) > ($${keys.length + 1}, $${keys.length + 2})
        ORDER BY session_key, seq
        LIMIT $${keys.length + 3}
      `;
      params = [...keys, lastSessionKey, lastSeq, batchSize];
    }

    const result = await pool.query(query, params);
    const rows = result.rows;

    if (rows.length === 0) {
      hasMore = false;
      break;
    }

    const lastRow = rows[rows.length - 1];
    lastSessionKey = lastRow.session_key;
    lastSeq = lastRow.seq;

    yield rows;

    if (rows.length < batchSize) {
      hasMore = false;
    }
  }
}

async function insertBatch(pool, rows, dryRun) {
  if (rows.length === 0) return 0;

  const columns = [
    'session_key',
    'msg_id',
    'role',
    'content',
    'ts',
    'seq',
    'fingerprint',
    'created_at',
    'updated_at',
  ];

  const valuePlaceholders = rows
    .map((_, rowIndex) => {
      const offset = rowIndex * columns.length;
      const cols = columns.map((_, colIndex) => `$${offset + colIndex + 1}`).join(', ');
      return `(${cols})`;
    })
    .join(', ');

  const flatValues = rows.flatMap((r) => [
    r.session_key,
    r.msg_id,
    r.role,
    r.content,
    r.ts,
    r.seq,
    r.fingerprint,
    r.created_at,
    r.updated_at,
  ]);

  const sql = `
    INSERT INTO session_messages
      (${columns.join(', ')})
    VALUES
      ${valuePlaceholders}
    ON CONFLICT (session_key, seq) DO NOTHING
  `;

  if (dryRun) {
    return rows.length;
  }

  const result = await pool.query(sql, flatValues);
  return result.rowCount ?? 0;
}

async function run() {
  if (!OLD_PG_URL || !NEW_PG_URL || !WIZARD_DB_PATH) {
    usage();
  }

  const oldPool = createPgPool(OLD_PG_URL);
  const newPool = createPgPool(NEW_PG_URL);

  logInfo(`Loading whitelist from ${WIZARD_DB_PATH}...`);
  const whitelist = await loadWhitelist(WIZARD_DB_PATH);
  logInfo(`Whitelist: ${whitelist.size} distinct session(s)`);

  if (whitelist.size === 0) {
    logInfo('No sessions in whitelist. Nothing to migrate.');
    await oldPool.end();
    await newPool.end();
    logOut({ migratedRows: 0, distinctSessions: 0 });
    return;
  }

  const totalOldRows = await countOldRows(oldPool, whitelist);
  logInfo(`Source rows matching whitelist: ${totalOldRows}`);
  logInfo(`Batch size: ${BATCH_SIZE}, dryRun: ${DRY_RUN}`);
  logInfo('');

  let migratedRows = 0;
  let batchCount = 0;

  for await (const batch of batchReadOldPg(oldPool, whitelist, BATCH_SIZE)) {
    batchCount++;
    logInfo(`[Batch ${batchCount}] Read ${batch.length} row(s)`);

    const inserted = await insertBatch(newPool, batch, DRY_RUN);
    migratedRows += inserted;
    logInfo(`[Batch ${batchCount}] Inserted ${inserted} row(s) (cumulative: ${migratedRows})`);
  }

  await oldPool.end();
  await newPool.end();

  const report = {
    migratedRows,
    distinctSessions: whitelist.size,
    dryRun: DRY_RUN,
    totalOldRows,
    batchCount,
  };

  logInfo('\n--- Summary ---');
  logInfo(`Distinct sessions: ${whitelist.size}`);
  logInfo(`Total source rows: ${totalOldRows}`);
  logInfo(`Migrated rows: ${migratedRows}`);
  if (DRY_RUN) logInfo('DRY RUN: no writes were performed.');

  logOut(report);
}

run().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
