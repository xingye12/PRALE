import fs from 'fs';
import path from 'path';
import { Database } from 'better-sqlite3';

const DRY_RUN = process.env.DRY_RUN === 'true';
const SOURCE_OPENCLAW_JSON = process.env.SOURCE_OPENCLAW_JSON;
const WIZARD_DB_PATH = process.env.WIZARD_DB_PATH;
const TENANT_OUTPUT_DIR = process.env.TENANT_OUTPUT_DIR;

function usage() {
  console.error('Usage: DRY_RUN=true SOURCE_OPENCLAW_JSON=... WIZARD_DB_PATH=... TENANT_OUTPUT_DIR=... node scripts/migration/split-openclaw-json.mjs');
  process.exit(1);
}

if (!SOURCE_OPENCLAW_JSON || !WIZARD_DB_PATH || !TENANT_OUTPUT_DIR) {
  usage();
}

if (!fs.existsSync(SOURCE_OPENCLAW_JSON)) {
  console.error(`Source file not found: ${SOURCE_OPENCLAW_JSON}`);
  process.exit(1);
}

if (!fs.existsSync(WIZARD_DB_PATH)) {
  console.error(`Wizard DB not found: ${WIZARD_DB_PATH}`);
  process.exit(1);
}

// Read source config
const sourceConfig = JSON.parse(fs.readFileSync(SOURCE_OPENCLAW_JSON, 'utf-8'));

// Connect to wizard DB
const db = new Database(WIZARD_DB_PATH);

// Build user_id -> tenant_id mapping from user_tenant_assignments
const userTenantRows = db.prepare('SELECT user_id, tenant_id FROM user_tenant_assignments').all();
const userToTenant = new Map();
for (const row of userTenantRows) {
  userToTenant.set(row.user_id, row.tenant_id);
}

// Build agent_id -> tenant_id mapping from user_agents
const agentRows = db.prepare('SELECT id, user_id FROM user_agents').all();
const agentToTenant = new Map();
for (const row of agentRows) {
  const tenantId = userToTenant.get(row.user_id);
  if (tenantId !== undefined) {
    agentToTenant.set(String(row.id), tenantId);
  }
}

// Collect all tenant IDs
const tenantIds = [...new Set(userToTenant.values())].sort((a, b) => a - b);

// Prepare tenant buckets
const tenantBuckets = new Map();
for (const tid of tenantIds) {
  tenantBuckets.set(tid, {
    agents: [],
    channels: [],
    bindings: [],
  });
}

// Distribute agents
const keptAgents = [];
const discardedAgents = [];
const skippedAgents = [];

for (const agent of sourceConfig.agents || []) {
  if (agent.id === 'finance-faq') {
    skippedAgents.push(agent.id);
    continue;
  }
  const tenantId = agentToTenant.get(String(agent.id));
  if (tenantId !== undefined) {
    keptAgents.push({ id: agent.id, tenantId });
    tenantBuckets.get(tenantId).agents.push(agent);
  } else {
    discardedAgents.push(agent.id);
  }
}

// Distribute channels
for (const channel of sourceConfig.channels || []) {
  const agentId = channel.agent_id;
  if (agentId === 'finance-faq') {
    continue;
  }
  const tenantId = agentToTenant.get(String(agentId));
  if (tenantId !== undefined) {
    tenantBuckets.get(tenantId).channels.push(channel);
  }
}

// Distribute bindings
for (const binding of sourceConfig.bindings || []) {
  const agentId = binding.agent_id;
  if (agentId === 'finance-faq') {
    continue;
  }
  const tenantId = agentToTenant.get(String(agentId));
  if (tenantId !== undefined) {
    tenantBuckets.get(tenantId).bindings.push(binding);
  }
}

// Global fields to copy to each tenant
const globalFields = [
  'auth',
  'models',
  'tools',
  'plugins',
  'secrets',
  'meta',
  'commands',
  'session',
  'messages',
];

// Fields to remove
const removeFields = [
  'skills',
  'gateway',
  'wizard',
];

// Build per-tenant configs and write
const byTenant = {};
for (const tid of tenantIds) {
  const bucket = tenantBuckets.get(tid);
  const tenantConfig = {};

  // Copy global fields from source
  for (const field of globalFields) {
    if (field in sourceConfig) {
      tenantConfig[field] = sourceConfig[field];
    }
  }

  // Explicitly remove fields (just don't include them)
  for (const field of removeFields) {
    delete tenantConfig[field];
  }

  // Add distributed data
  tenantConfig.agents = bucket.agents;
  tenantConfig.channels = bucket.channels;
  tenantConfig.bindings = bucket.bindings;

  byTenant[tid] = {
    agentsCount: bucket.agents.length,
    channelsCount: bucket.channels.length,
    bindingsCount: bucket.bindings.length,
  };

  const tenantDir = path.join(TENANT_OUTPUT_DIR, `tenant-${tid}`);
  const outputPath = path.join(tenantDir, 'openclaw.json');

  if (!DRY_RUN) {
    fs.mkdirSync(tenantDir, { recursive: true });
    fs.writeFileSync(outputPath, JSON.stringify(tenantConfig, null, 2), 'utf-8');
  }
  console.log(`${DRY_RUN ? '[DRY_RUN] ' : ''}tenant-${tid}: ${bucket.agents.length} agents, ${bucket.channels.length} channels, ${bucket.bindings.length} bindings -> ${outputPath}`);
}

// Report
const report = {
  totalAgents: (sourceConfig.agents || []).length,
  kept: keptAgents.length,
  discarded: discardedAgents.length,
  skipped: skippedAgents.length,
  byTenant,
  discardedList: discardedAgents,
  skippedList: skippedAgents,
};

const reportPath = path.join(TENANT_OUTPUT_DIR, 'split-report.json');
if (!DRY_RUN) {
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf-8');
}
console.log(`\n${DRY_RUN ? '[DRY_RUN] ' : ''}Report: ${reportPath}`);
console.log(JSON.stringify(report, null, 2));

db.close();
