#!/usr/bin/env node
import Database from 'better-sqlite3'
import { existsSync } from 'fs'
import { writeReport } from './lib/report.mjs'

// ── Environment ───────────────────────────────────────────────────────────
const SOURCE_WIZARD_DB = process.env.SOURCE_WIZARD_DB
const TARGET_WIZARD_DB = process.env.TARGET_WIZARD_DB
const TENANT_MAPPING_DB = process.env.TENANT_MAPPING_DB || ''
const DRY_RUN = process.env.DRY_RUN === 'true' || process.argv.includes('--dry-run')

if (!SOURCE_WIZARD_DB || !TARGET_WIZARD_DB) {
  console.error('Error: SOURCE_WIZARD_DB and TARGET_WIZARD_DB must be set')
  process.exit(1)
}

if (!existsSync(SOURCE_WIZARD_DB)) {
  console.error(`Error: Source DB not found: ${SOURCE_WIZARD_DB}`)
  process.exit(1)
}

// ── Tables to sync ────────────────────────────────────────────────────────
const CORE_TABLES = [
  'users',
  'user_agents',
  'user_sessions',
  'user_channels',
  'cron_jobs',
  'agent_team',
  'auth_tokens',
  'user_model_providers',
  'models',
]

const TENANT_TABLES = ['openclaw_tenants', 'user_tenant_assignments']

const TABLES_TO_SYNC = [...CORE_TABLES]
if (TENANT_MAPPING_DB) {
  TABLES_TO_SYNC.push(...TENANT_TABLES)
}

// ── Open DBs ──────────────────────────────────────────────────────────────
const source = new Database(SOURCE_WIZARD_DB, { readonly: true })
const target = new Database(TARGET_WIZARD_DB)

let tenantSource = null
if (TENANT_MAPPING_DB) {
  if (!existsSync(TENANT_MAPPING_DB)) {
    console.error(`Error: Tenant mapping DB not found: ${TENANT_MAPPING_DB}`)
    process.exit(1)
  }
  tenantSource = new Database(TENANT_MAPPING_DB, { readonly: true })
}

// ── Helpers ───────────────────────────────────────────────────────────────
function getSchemaTables(db) {
  return db
    .prepare(
      "SELECT name, sql FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_%'"
    )
    .all()
}

function getIndices(db) {
  return db
    .prepare(
      "SELECT name, sql FROM sqlite_master WHERE type = 'index' AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%'"
    )
    .all()
}

function getTableColumns(db, table) {
  return db.prepare(`PRAGMA table_info(${table})`).all()
}

function getTableInfo(db, table) {
  return db.prepare(`SELECT * FROM ${table} LIMIT 0`).columns().map((c) => c.name)
}

function quoteIdentifier(id) {
  return `"${id.replace(/"/g, '""')}"`
}

// ── Copy schema ───────────────────────────────────────────────────────────
function copySchema() {
  if (DRY_RUN) {
    console.error('[DRY-RUN] Would copy schema (tables + indices) from source to target')
    return
  }

  const sourceTables = getSchemaTables(source)
  const targetTables = new Set(getSchemaTables(target).map((t) => t.name))
  const sourceIndices = getIndices(source)

  for (const { name, sql } of sourceTables) {
    if (!TABLES_TO_SYNC.includes(name)) continue
    if (targetTables.has(name)) {
      console.error(`[Schema] Table ${name} already exists, skipping CREATE`)
      continue
    }
    console.error(`[Schema] Creating table: ${name}`)
    target.exec(sql)
  }

  // Also create tenant tables from tenant mapping DB if provided
  if (tenantSource) {
    const tenantSchema = getSchemaTables(tenantSource)
    for (const { name, sql } of tenantSchema) {
      if (!TENANT_TABLES.includes(name)) continue
      if (targetTables.has(name)) {
        console.error(`[Schema] Tenant table ${name} already exists, skipping CREATE`)
        continue
      }
      console.error(`[Schema] Creating tenant table: ${name}`)
      target.exec(sql)
    }
  }

  // Copy indices
  for (const { name, sql } of sourceIndices) {
    if (!sql) continue
    // Only copy indices for tables we sync
    const tableMatch = sql.match(/ON\s+(\S+)/i)
    const tableName = tableMatch ? tableMatch[1].replace(/"/g, '') : null
    if (!tableName || !TABLES_TO_SYNC.includes(tableName)) continue

    try {
      target.exec(sql)
      console.error(`[Schema] Created index: ${name}`)
    } catch (e) {
      if (!e.message.includes('already exists')) {
        console.error(`[Schema] Index ${name} error:`, e.message)
      }
    }
  }

  // Copy tenant indices
  if (tenantSource) {
    const tenantIndices = getIndices(tenantSource)
    for (const { name, sql } of tenantIndices) {
      if (!sql) continue
      const tableMatch = sql.match(/ON\s+(\S+)/i)
      const tableName = tableMatch ? tableMatch[1].replace(/"/g, '') : null
      if (!tableName || !TENANT_TABLES.includes(tableName)) continue
      try {
        target.exec(sql)
        console.error(`[Schema] Created tenant index: ${name}`)
      } catch (e) {
        if (!e.message.includes('already exists')) {
          console.error(`[Schema] Tenant index ${name} error:`, e.message)
        }
      }
    }
  }
}

// ── Sync table data ───────────────────────────────────────────────────────
function syncTable(db, table) {
  const columns = getTableInfo(db, table)
  if (columns.length === 0) {
    console.error(`[Sync] Table ${table} has no columns, skipping`)
    return 0
  }

  const colList = columns.map(quoteIdentifier).join(', ')
  const placeholders = columns.map(() => '?').join(', ')
  const selectStmt = db.prepare(`SELECT ${colList} FROM ${quoteIdentifier(table)}`)
  const rows = selectStmt.all()

  if (rows.length === 0) {
    console.error(`[Sync] Table ${table}: 0 rows`)
    return 0
  }

  if (DRY_RUN) {
    console.error(`[DRY-RUN] Would sync ${rows.length} rows into ${table}`)
    return rows.length
  }

  const insertStmt = target.prepare(
    `INSERT OR REPLACE INTO ${quoteIdentifier(table)} (${colList}) VALUES (${placeholders})`
  )

  const transaction = target.transaction((data) => {
    for (const row of data) {
      const values = columns.map((c) => row[c])
      insertStmt.run(values)
    }
  })

  transaction(rows)
  console.error(`[Sync] Table ${table}: ${rows.length} rows synced`)
  return rows.length
}

// ── Report unmapped users ─────────────────────────────────────────────────
function getUnmappedUsers() {
  if (!tenantSource) return []

  const allUsers = source.prepare('SELECT id, username FROM users').all()
  const assignedUsers = new Set(
    tenantSource.prepare('SELECT user_id FROM user_tenant_assignments').all().map((r) => r.user_id)
  )

  const unmapped = allUsers
    .filter((u) => !assignedUsers.has(u.id))
    .map((u) => `${u.username} (${u.id})`)

  return unmapped
}

// ── Main ──────────────────────────────────────────────────────────────────
console.error(`Source: ${SOURCE_WIZARD_DB}`)
console.error(`Target: ${TARGET_WIZARD_DB}`)
if (TENANT_MAPPING_DB) console.error(`Tenant mapping: ${TENANT_MAPPING_DB}`)
console.error(`Dry-run: ${DRY_RUN}`)
console.error('')

// Copy schema first
copySchema()

// Sync core tables from source
const rows = {}
for (const table of CORE_TABLES) {
  try {
    rows[table] = syncTable(source, table)
  } catch (e) {
    console.error(`[Sync] Table ${table} error:`, e.message)
    rows[table] = 0
  }
}

// Sync tenant tables from tenant mapping DB if provided
if (tenantSource) {
  for (const table of TENANT_TABLES) {
    try {
      rows[table] = syncTable(tenantSource, table)
    } catch (e) {
      console.error(`[Sync] Tenant table ${table} error:`, e.message)
      rows[table] = 0
    }
  }
}

// Unmapped users
const unmappedUsers = getUnmappedUsers()
if (unmappedUsers.length > 0) {
  console.error(`[Warning] ${unmappedUsers.length} unmapped users found:`)
  unmappedUsers.forEach((u) => console.error(`  ! ${u}`))
}

// Tenant count
let tenantCount = 0
if (tenantSource) {
  try {
    const t = tenantSource.prepare('SELECT COUNT(*) as c FROM openclaw_tenants').get()
    tenantCount = t ? t.c : 0
  } catch (e) {
    console.error('[Report] Tenant count error:', e.message)
  }
}

// Build report
const report = {
  tables: Object.keys(rows),
  rows,
  tenantCount,
  unmappedUsers,
}

writeReport(report)

// Cleanup
source.close()
target.close()
if (tenantSource) tenantSource.close()

if (DRY_RUN) {
  console.error('\n[DRY-RUN] No changes were written to the target database.')
}
