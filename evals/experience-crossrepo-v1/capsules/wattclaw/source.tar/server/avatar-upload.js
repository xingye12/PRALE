import { Router } from 'express'
import { randomUUID } from 'crypto'
import multer from 'multer'
import { existsSync, mkdirSync } from 'fs'
import { join, dirname, extname, basename } from 'path'
import { fileURLToPath } from 'url'
import { validateToken } from './user-manager.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const UPLOAD_DIR = join(__dirname, '../uploads/images')

if (!existsSync(UPLOAD_DIR)) {
  mkdirSync(UPLOAD_DIR, { recursive: true })
}

const imageUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = extname(file.originalname) || '.png'
      cb(null, `avatar-${Date.now()}-${randomUUID().slice(0, 8)}${ext}`)
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp']
    const ext = extname(file.originalname).toLowerCase()
    if (allowed.includes(ext)) cb(null, true)
    else cb(new Error('仅支持图片文件'))
  },
})

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies?.session
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  const result = validateToken(token)
  if (!result) return res.status(401).json({ error: 'Unauthorized' })
  req.currentUser = result.user
  next()
}

export function createAvatarUploadRouter() {
  const router = Router()

  router.post('/upload', authMiddleware, imageUpload.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, error: '未选择文件' })
    const filename = req.file.filename
    res.json({ ok: true, url: `/api/avatar-images/${filename}` })
  })

  router.get('/:filename', (req, res) => {
    const filename = basename(req.params.filename)
    const filePath = join(UPLOAD_DIR, filename)
    if (!existsSync(filePath)) return res.status(404).json({ ok: false, error: '文件不存在' })

    const ext = extname(filename).toLowerCase()
    const contentTypeMap = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.webp': 'image/webp',
      '.bmp': 'image/bmp',
    }
    res.setHeader('Content-Type', contentTypeMap[ext] || 'application/octet-stream')
    res.setHeader('Cache-Control', 'public, max-age=86400')
    res.sendFile(filePath)
  })

  return router
}
