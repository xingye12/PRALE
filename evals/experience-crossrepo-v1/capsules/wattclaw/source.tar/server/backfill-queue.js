import { mergeSessionMessages, countConfirmedMessages, isReady } from './message-store.js'
import { isExternalChannelSession } from './core/message-sync.js'

const MAX_CONCURRENT = 2
const BATCH_INTERVAL_MS = 500
const MAX_PENDING = 50

let activeJobs = 0
const pendingQueue = []
const inFlightSessionKeys = new Set()

/**
 * Enqueue a backfill job. Deduplicates by sessionKey.
 */
export function enqueueBackfill(sessionKey, { limit = 50, fetchFn, label = 'backfill' } = {}) {
  if (!isReady()) return
  if (inFlightSessionKeys.has(sessionKey)) return
  if (pendingQueue.length >= MAX_PENDING) return

  pendingQueue.push({ sessionKey, limit, fetchFn, label })
  inFlightSessionKeys.add(sessionKey)
  processQueue()
}

function processQueue() {
  while (activeJobs < MAX_CONCURRENT && pendingQueue.length > 0) {
    const job = pendingQueue.shift()
    activeJobs++
    executeJob(job).finally(() => {
      activeJobs--
      inFlightSessionKeys.delete(job.sessionKey)
      if (pendingQueue.length > 0) {
        setTimeout(processQueue, BATCH_INTERVAL_MS)
      }
    })
  }
}

async function executeJob({ sessionKey, limit, fetchFn, label }) {
  try {
    if (!fetchFn) {
      console.warn(`[Backfill] No fetchFn for ${sessionKey}, skipping`)
      return
    }
    // Internal sessions: PG is source of truth, never destructively replace
    if (!isExternalChannelSession(sessionKey)) {
      console.log(`[Backfill] skip internal session ${sessionKey}; PG is source of truth`)
      return
    }
    const messages = await fetchFn(sessionKey, limit)
    if (messages && messages.length > 0) {
      const result = await mergeSessionMessages(sessionKey, messages)
      const written = (result.inserted || 0) + (result.updated || 0)
      console.log(`[Backfill] ${label} ${sessionKey}: fetched=${messages.length} merged=${written} (inserted=${result.inserted} updated=${result.updated} skipped=${result.skipped})`)
      // If fetched count hit the limit, there might be more — trigger Phase 2
      if (messages.length >= limit && limit < 1000) {
        inFlightSessionKeys.delete(sessionKey)
        enqueueBackfill(sessionKey, { limit: 1000, fetchFn, label: 'phase2' })
      }
    }
  } catch (err) {
    console.error(`[Backfill] ${label} ${sessionKey} error:`, err.message)
  }
}

/**
 * Schedule preload for active user: top N sessions per agent, limit=50 each.
 * Skips sessions that already have data in PostgreSQL.
 */
export async function schedulePreloadForUser(userId, { getUserSessionsFn, fetchFn, topN = 4 }) {
  if (!isReady()) return
  if (!getUserSessionsFn) return

  const sessions = getUserSessionsFn(userId)
  if (!sessions || !sessions.length) return

  // Group by agent_id, take top N per agent (most recently updated)
  const byAgent = new Map()
  for (const s of sessions) {
    const aid = s.agent_id || '_none'
    if (!byAgent.has(aid)) byAgent.set(aid, [])
    byAgent.get(aid).push(s)
  }

  const candidates = []
  for (const [, agentSessions] of byAgent) {
    agentSessions.sort((a, b) => (b.updated_at || 0) - (a.updated_at || 0))
    candidates.push(...agentSessions.slice(0, topN))
  }

  // Filter out sessions that already have local data
  for (const s of candidates) {
    const sk = s.session_key || s.key
    if (!sk) continue
    const count = await countConfirmedMessages(sk)
    if (count > 0) continue
    enqueueBackfill(sk, { limit: 50, fetchFn, label: 'preload' })
  }
}

/**
 * Trigger Phase 2 background full backfill for a session.
 */
export function triggerPhase2Backfill(sessionKey, { fetchFn }) {
  if (!isReady()) return
  enqueueBackfill(sessionKey, { limit: 1000, fetchFn, label: 'phase2' })
}
