// Feishu OAuth 2.0 service — code exchange, user info, state management
import { randomBytes } from 'crypto'
import db from '../database.js'

const FEISHU_APP_ID = process.env.FEISHU_APP_ID || ''
const FEISHU_APP_SECRET = process.env.FEISHU_APP_SECRET || ''
const FEISHU_REDIRECT_URI = process.env.FEISHU_REDIRECT_URI || ''

const STATE_TTL = 5 * 60 * 1000 // 5 minutes

// ── Rate limiting ──
const _authorizeRateLimit = new Map() // ip → { count, resetAt }
const AUTHORIZE_RATE_LIMIT = 10 // per minute per IP

function checkAuthorizeRateLimit(ip) {
  const now = Date.now()
  const entry = _authorizeRateLimit.get(ip)
  if (!entry || now > entry.resetAt) {
    _authorizeRateLimit.set(ip, { count: 1, resetAt: now + 60_000 })
    return true
  }
  if (entry.count >= AUTHORIZE_RATE_LIMIT) return false
  entry.count++
  return true
}

// ── State management (SQLite-backed) ──
function generateState() {
  const state = randomBytes(32).toString('hex')
  db.prepare('INSERT INTO oauth_states (state, created_at) VALUES (?, ?)').run(state, Date.now())
  return state
}

function consumeState(state) {
  const row = db.prepare('SELECT created_at FROM oauth_states WHERE state = ?').get(state)
  if (!row) return false
  db.prepare('DELETE FROM oauth_states WHERE state = ?').run(state)
  return Date.now() - row.created_at <= STATE_TTL
}

// ── Authorization URL construction ──
export function isFeishuAuthEnabled() {
  return !!(FEISHU_APP_ID && FEISHU_APP_SECRET && FEISHU_REDIRECT_URI)
}

export function buildAuthorizeUrl(ip) {
  if (!isFeishuAuthEnabled()) return null
  if (!checkAuthorizeRateLimit(ip)) return { error: 'rate_limited' }

  const state = generateState()
  const params = new URLSearchParams({
    app_id: FEISHU_APP_ID,
    redirect_uri: FEISHU_REDIRECT_URI,
    state,
  })
  return { url: `https://open.feishu.cn/open-apis/authen/v1/authorize?${params.toString()}` }
}

// ── Token exchange ──
async function exchangeCodeForToken(code) {
  const response = await fetch('https://open.feishu.cn/open-apis/authen/v2/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'authorization_code',
      client_id: FEISHU_APP_ID,
      client_secret: FEISHU_APP_SECRET,
      code,
      redirect_uri: FEISHU_REDIRECT_URI,
    }),
  })
  const body = await response.json()
  if (body.code !== 0) {
    throw new Error(body.msg || 'Token exchange failed')
  }
  // Token fields are at root level, not nested in data
  return body
}

// ── User info ──
async function getUserInfo(accessToken) {
  const response = await fetch('https://open.feishu.cn/open-apis/authen/v1/user_info', {
    headers: { Authorization: `Bearer ${accessToken}` },
  })
  const body = await response.json()
  if (body.code !== 0) {
    throw new Error(body.msg || 'Get user info failed')
  }
  return body.data
}

// ── Full callback flow ──
export async function handleFeishuCallback(code, state) {
  // 1. Validate state
  if (!state || !consumeState(state)) {
    return { ok: false, status: 403, error: 'state 已过期，请重新登录' }
  }

  // 2. Exchange code for token
  let tokenData
  try {
    tokenData = await exchangeCodeForToken(code)
  } catch (e) {
    console.error('[FeishuOAuth] token exchange failed:', e.message)
    return { ok: false, status: 502, error: '飞书授权服务不可用' }
  }

  // 3. Get user info
  let feishuUser
  try {
    feishuUser = await getUserInfo(tokenData.access_token)
  } catch (e) {
    console.error('[FeishuOAuth] user_info failed:', e.message)
    return { ok: false, status: 502, error: '获取飞书用户信息失败' }
  }

  // 4. Look up binding by feishu user_id
  const feishuUserId = feishuUser.user_id
  console.log('[FeishuOAuth] user_info returned:', { user_id: feishuUser.user_id, open_id: feishuUser.open_id, name: feishuUser.name })
  const binding = db.prepare(
    'SELECT user_id FROM user_oauth_bindings WHERE provider = ? AND feishu_user_id = ?'
  ).get('feishu', feishuUserId)

  if (!binding) {
    return { ok: false, status: 401, error: '该飞书账号未绑定系统用户' }
  }

  // 5. Snapshot display info
  db.prepare(`
    UPDATE user_oauth_bindings
    SET open_id = ?, display_name = ?, avatar_url = ?, updated_at = ?
    WHERE provider = 'feishu' AND feishu_user_id = ?
  `).run(feishuUser.open_id || null, feishuUser.name || null, feishuUser.avatar_url || null, Date.now(), feishuUserId)

  return { ok: true, userId: binding.user_id }
}
