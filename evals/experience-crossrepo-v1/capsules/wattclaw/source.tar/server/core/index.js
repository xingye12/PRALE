// Central shared state for the server — imported by all modules.
// This file is the single source of truth for runtime state that
// would otherwise create circular dependencies.

export let gateway = null
export const sseClients = new Map()
export const terminalSessions = new Map()
export const desktopSessions = new Map()
export const streamIdMap = new Map() // streamId → { sessionKey, startTime }
export const backupTasks = new Map()
export let envConfig = {}
export let gatewayVersion = null
export let updateInfo = null

// Callback for Gateway reconnection — registered by index.js at startup
let _reconnectGatewayFn = null
export function setReconnectGatewayFn(fn) { _reconnectGatewayFn = fn }
export function triggerGatewayReconnect() { _reconnectGatewayFn?.() }

// Callback for flushing pending token updates — registered by index.js at startup
let _flushPendingTokenUpdateFn = null
export function setFlushPendingTokenUpdateFn(fn) { _flushPendingTokenUpdateFn = fn }
export function flushPendingTokenUpdate(sessionKey) { _flushPendingTokenUpdateFn?.(sessionKey) }

export function setGateway(g) { gateway = g }
export function setEnvConfig(c) { envConfig = c }
export function setGatewayVersion(v) { gatewayVersion = v }
export function setUpdateInfo(i) { updateInfo = i }
