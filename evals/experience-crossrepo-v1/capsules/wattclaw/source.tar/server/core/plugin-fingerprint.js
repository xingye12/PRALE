import { createHash } from 'crypto'
import { readdirSync, readFileSync, statSync } from 'fs'
import path from 'path'

export function hashDirectory(directory) {
  const hash = createHash('sha256')

  const visit = (currentDirectory, relativeDirectory) => {
    for (const name of readdirSync(currentDirectory).sort()) {
      if (name === 'node_modules') continue
      const absolutePath = path.join(currentDirectory, name)
      const relativePath = relativeDirectory ? `${relativeDirectory}/${name}` : name
      const stat = statSync(absolutePath)

      if (stat.isDirectory()) {
        hash.update(`dir:${relativePath}\n`)
        visit(absolutePath, relativePath)
      } else if (stat.isFile()) {
        hash.update(`file:${relativePath}:${stat.size}\n`)
        hash.update(readFileSync(absolutePath))
      }
    }
  }

  visit(directory, '')
  return hash.digest('hex')
}
