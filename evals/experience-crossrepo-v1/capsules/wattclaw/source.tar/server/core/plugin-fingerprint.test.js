import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'fs'
import { tmpdir } from 'os'
import path from 'path'
import { afterEach, describe, expect, it } from 'vitest'
import { hashDirectory } from './plugin-fingerprint.js'

const temporaryDirectories = []

afterEach(() => {
  for (const directory of temporaryDirectories.splice(0)) {
    rmSync(directory, { force: true, recursive: true })
  }
})

describe('hashDirectory', () => {
  it('is stable for unchanged files and changes when nested content changes', () => {
    const directory = mkdtempSync(path.join(tmpdir(), 'wattclaw-plugin-'))
    temporaryDirectories.push(directory)
    mkdirSync(path.join(directory, 'nested'))
    writeFileSync(path.join(directory, 'manifest.json'), '{"version":"1"}\n')
    writeFileSync(path.join(directory, 'nested', 'index.js'), 'export const value = 1\n')

    const initialHash = hashDirectory(directory)
    expect(hashDirectory(directory)).toBe(initialHash)

    writeFileSync(path.join(directory, 'nested', 'index.js'), 'export const value = 2\n')
    expect(hashDirectory(directory)).not.toBe(initialHash)
  })
})
