import { beforeEach, describe, expect, it, vi } from 'vitest'

// --- Statement-specific db.prepare mock ---
// Each prepare() call creates a dedicated {sql, run, get, all} object
// stored in preparedStatements[], so assertions can find statements by SQL.
const preparedStatements = []

function resetPreparedStatements() {
  preparedStatements.length = 0
}

function createStmtMock(sql) {
  const stmt = {
    sql: String(sql),
    run: vi.fn(),
    get: vi.fn(),
    all: vi.fn(),
  }
  preparedStatements.push(stmt)
  return stmt
}

const prepareMock = vi.fn((sql) => createStmtMock(sql))

vi.mock('../database.js', () => ({
  default: {
    prepare: prepareMock,
  },
}))

const usageCache = await import('./session-usage-cache.js')

function resetDbMocks() {
  prepareMock.mockClear()
  resetPreparedStatements()
}

/** Find the first prepared statement whose SQL contains `fragment`. */
function findStmt(fragment) {
  return preparedStatements.find((s) => s.sql.includes(fragment)) || null
}

describe('session usage cache ownership-safe writes', () => {
  beforeEach(() => {
    resetDbMocks()
  })

  it('updates a session only through user_id + session_key', () => {
    const result = usageCache.updateSessionUsageForUser('user-a', 'session-a', {
      model: 'anthropic/claude-sonnet-4-6',
      modelProvider: null,
      tokenInput: 10,
      tokenOutput: 20,
      tokenTotal: 30,
      costTotal: 0.12,
      toolUsage: [],
    })

    expect(result.userId).toBe('user-a')
    expect(result.sessionKey).toBe('session-a')

    const stmt = findStmt('UPDATE user_sessions')
    expect(stmt).not.toBeNull()
    expect(stmt.sql).toContain('WHERE')
    expect(stmt.sql).toContain('user_id = ?')
    expect(stmt.sql).toContain('session_key = ?')
    expect(stmt.run).toHaveBeenCalled()
    const runArgs = stmt.run.mock.calls[0]
    expect(runArgs).toContain('user-a')
    expect(runArgs).toContain('session-a')
  })

  it('does not throw on null userId but update returns updated=false', () => {
    const result = usageCache.updateSessionUsageForUser(null, 'session-a', { tokenTotal: 1 })
    expect(result.updated).toBe(false)
  })

  it('batch sync skips unmatched and conflicting gateway sessions', () => {
    // Reset and use a smart prepare implementation for dynamic .get/.all
    resetDbMocks()
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('SELECT') && String(sql).includes('user_id')) {
        // Lookup by session_key — .all returns ownership rows
        stmt.all.mockImplementation((sessionKey) => {
          if (sessionKey === 'conflict') {
            return [
              { user_id: 'user-a', session_key: 'conflict' },
              { user_id: 'user-b', session_key: 'conflict' },
            ]
          }
          if (sessionKey === 'owned') return [{ user_id: 'user-a', session_key: 'owned' }]
          return []
        })
      }
      stmt.run.mockReturnValue({ changes: 1 })
      return stmt
    })

    const report = usageCache.batchUpdateMatchedGatewayUsage({
      sessions: [
        { key: 'owned', usage: { input: 1, output: 2, totalTokens: 3 } },
        { key: 'missing', usage: { input: 4, output: 5, totalTokens: 9 } },
        { key: 'conflict', usage: { input: 6, output: 7, totalTokens: 13 } },
      ],
    })

    expect(report.scanned).toBe(3)
    expect(report.updated).toBe(1)
    expect(report.skippedUnmatched).toBe(1)
    expect(report.skippedConflict).toBe(1)
    expect(report.failed).toBe(0)

    // Ownership verification: any UPDATE statement must use WHERE user_id + session_key
    const updateStmt = findStmt('UPDATE')
    if (updateStmt) {
      expect(updateStmt.sql).toContain('WHERE')
      expect(updateStmt.sql).toContain('user_id = ?')
      expect(updateStmt.sql).toContain('session_key = ?')
    }
  })

  it('preserves user scope when using the legacy batch update alias', () => {
    resetDbMocks()
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('SELECT') && String(sql).includes('user_id')) {
        stmt.all.mockImplementation((userId, sessionKey) => {
          if (userId === 'user-a' && sessionKey === 'owned') {
            return [{ user_id: 'user-a', session_key: 'owned' }]
          }
          return []
        })
      }
      stmt.run.mockReturnValue({ changes: 1 })
      return stmt
    })

    const report = usageCache.batchUpdateMatchedGatewayUsage({
      sessions: [
        { key: 'owned', usage: { input: 1, output: 2, totalTokens: 3 } },
        { key: 'other-user-session', usage: { input: 4, output: 5, totalTokens: 9 } },
      ],
    }, 'user-a')

    expect(report.scanned).toBe(2)
    expect(report.updated).toBe(1)
    expect(report.skippedUnmatched).toBe(1)

    const ownershipStmt = preparedStatements.find(
      (s) => s.sql.includes('SELECT') && s.sql.includes('WHERE user_id = ? AND session_key = ?')
    )
    expect(ownershipStmt).not.toBeNull()
    expect(ownershipStmt.all).toHaveBeenCalledWith('user-a', 'owned')
    expect(ownershipStmt.all).toHaveBeenCalledWith('user-a', 'other-user-session')
  })

  it('does not count zero-row owner updates as successful', () => {
    resetDbMocks()
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('SELECT') && String(sql).includes('user_id')) {
        stmt.all.mockReturnValue([{ user_id: 'user-a', session_key: 'owned' }])
      }
      stmt.run.mockReturnValue({ changes: 0 })
      return stmt
    })

    const report = usageCache.batchUpdateMatchedGatewayUsage({
      sessions: [{ key: 'owned', usage: { input: 1, output: 2, totalTokens: 3 } }],
    })

    expect(report.updated).toBe(0)
    expect(report.failed).toBe(1)
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('owner-scoped usage update skipped: userId=user-a, sessionKey=owned')
    )
    warnSpy.mockRestore()
  })

  it('logs bounded diagnostics when a batch owner update fails', () => {
    resetDbMocks()
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('SELECT') && String(sql).includes('user_id')) {
        stmt.all.mockReturnValue([{ user_id: 'user-a', session_key: 'owned' }])
      }
      stmt.run.mockImplementation(() => {
        throw new Error('sqlite failed')
      })
      return stmt
    })

    const report = usageCache.batchUpdateMatchedGatewayUsage({
      sessions: [{ key: 'owned', usage: { input: 1, output: 2, totalTokens: 3 } }],
    })

    expect(report.updated).toBe(0)
    expect(report.failed).toBe(1)
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('failed to update usage: userId=user-a, sessionKey=owned, error=sqlite failed')
    )
    warnSpy.mockRestore()
  })
})

describe('session usage cache SQLite read helpers', () => {
  beforeEach(() => {
    resetDbMocks()
  })

  it('returns admin user usage rows from SQLite', () => {
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('LEFT JOIN user_sessions')) {
        stmt.all.mockReturnValue([
          {
            userId: 'user-a',
            username: 'alice',
            displayName: 'Alice',
            sessionCount: 2,
            totalTokens: 30,
            totalCost: 0.4,
            inputTokens: 10,
            outputTokens: 20,
          },
        ])
      }
      return stmt
    })

    const rows = usageCache.getAdminUserUsageAggregates()

    expect(rows).toEqual([
      {
        userId: 'user-a',
        username: 'alice',
        displayName: 'Alice',
        sessionCount: 2,
        totalTokens: 30,
        totalCost: 0.4,
        inputTokens: 10,
        outputTokens: 20,
      },
    ])
    const stmt = findStmt('LEFT JOIN user_sessions')
    expect(stmt).not.toBeNull()
    expect(stmt.sql).toContain("WHERE u.status = 'active'")
  })

  it('scopes admin user usage aggregates by tenantId when provided', () => {
    let capturedStmt = null
    let capturedArg = null
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      if (String(sql).includes('LEFT JOIN user_sessions') && String(sql).includes('s.tenant_id = ?')) {
        capturedStmt = stmt
        stmt.all.mockImplementation((tenantId) => {
          capturedArg = tenantId
          return [
            {
              userId: 'user-a',
              username: 'alice',
              displayName: 'Alice',
              sessionCount: 1,
              totalTokens: 15,
              totalCost: 0.2,
              inputTokens: 5,
              outputTokens: 10,
            },
          ]
        })
      }
      return stmt
    })

    const rows = usageCache.getAdminUserUsageAggregates('tenant-x')

    // tenant-scoped SQL 必须含 s.tenant_id = ? 绑定
    expect(capturedStmt).not.toBeNull()
    expect(capturedStmt.sql).toContain('s.tenant_id = ?')
    expect(capturedArg).toBe('tenant-x')
    expect(rows).toEqual([
      {
        userId: 'user-a',
        username: 'alice',
        displayName: 'Alice',
        sessionCount: 1,
        totalTokens: 15,
        totalCost: 0.2,
        inputTokens: 5,
        outputTokens: 10,
      },
    ])
  })

  it('checks whether any usage rows have synced for admin or a user', () => {
    // hasUsageSyncRows()       — admin path, no user_id filter
    // hasUsageSyncRows('user-b') — user-scoped, must include WHERE user_id = ?
    prepareMock.mockImplementation((sql) => {
      const stmt = createStmtMock(sql)
      // Admin COUNT (no user_id filter) → count = 1
      if (!String(sql).includes('WHERE user_id = ?')) {
        stmt.get.mockReturnValue({ count: 1 })
      } else {
        // User-scoped COUNT → count = 0
        stmt.get.mockReturnValue({ count: 0 })
      }
      return stmt
    })

    expect(usageCache.hasUsageSyncRows()).toBe(true)
    expect(usageCache.hasUsageSyncRows('user-b')).toBe(false)

    // Admin statement: no user_id filter
    const adminStmt = preparedStatements.find(
      (s) => s.sql.includes('COUNT') && !s.sql.includes('WHERE user_id = ?')
    )
    expect(adminStmt).not.toBeNull()

    // User-scoped statement: must include WHERE user_id = ?
    const userStmt = preparedStatements.find(
      (s) => s.sql.includes('COUNT') && s.sql.includes('WHERE user_id = ?')
    )
    expect(userStmt).not.toBeNull()
    expect(userStmt.sql).toContain('WHERE user_id = ?')
    // .get called with 'user-b'
    expect(userStmt.get).toHaveBeenCalledWith('user-b')
  })
})
