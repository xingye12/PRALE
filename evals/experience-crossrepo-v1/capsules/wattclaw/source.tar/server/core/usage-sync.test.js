import { beforeEach, describe, expect, it, vi } from 'vitest'

const callGatewayUsageMock = vi.fn()
const callGatewayUsageForTargetMock = vi.fn()
const getGatewayHttpTargetsForAllTenantsMock = vi.fn()
const batchUpdateMatchedGatewayUsageMock = vi.fn()
const getSessionOwnerMock = vi.fn()
const updateSessionUsageForUserMock = vi.fn()
const broadcastSSEMock = vi.fn()
const setTimeoutMock = vi.fn((fn) => {
  fn()
  return 1
})
const clearTimeoutMock = vi.fn()

vi.mock('./gateway-client.js', () => ({
  callGatewayUsage: callGatewayUsageMock,
  callGatewayUsageForTarget: callGatewayUsageForTargetMock,
}))

vi.mock('./multi-tenant-gateway.js', () => ({
  // 默认 null = 单实例路径(保现有测试)
  getGatewayHttpTargetsForAllTenants: getGatewayHttpTargetsForAllTenantsMock,
}))

vi.mock('./session-usage-cache.js', () => ({
  batchUpdateMatchedGatewayUsage: batchUpdateMatchedGatewayUsageMock,
  getSessionOwner: getSessionOwnerMock,
  updateSessionUsageForUser: updateSessionUsageForUserMock,
}))

vi.mock('./sse.js', () => ({
  broadcastSSE: broadcastSSEMock,
}))

const usageSync = await import('./usage-sync.js')

beforeEach(() => {
  callGatewayUsageMock.mockReset()
  callGatewayUsageForTargetMock.mockReset()
  // 默认单实例:targets === null(保现有 3 个测试走单 gateway 路径)
  getGatewayHttpTargetsForAllTenantsMock.mockReset()
  getGatewayHttpTargetsForAllTenantsMock.mockResolvedValue(null)
  batchUpdateMatchedGatewayUsageMock.mockReset()
  getSessionOwnerMock.mockReset()
  updateSessionUsageForUserMock.mockReset()
  broadcastSSEMock.mockReset()
  setTimeoutMock.mockClear()
  clearTimeoutMock.mockClear()
  usageSync.__resetUsageSyncForTests()
  usageSync.__setUsageSyncTimersForTests({
    setTimeoutFn: setTimeoutMock,
    clearTimeoutFn: clearTimeoutMock,
  })
})

describe('usage sync orchestration', () => {
  it('runs startup sync and returns the batch report', async () => {
    callGatewayUsageMock.mockResolvedValue({ sessions: [{ key: 's1', usage: { totalTokens: 1 } }] })
    batchUpdateMatchedGatewayUsageMock.mockReturnValue({
      scanned: 1,
      updated: 1,
      skippedUnmatched: 0,
      skippedConflict: 0,
      failed: 0,
      durationMs: 1,
    })

    const report = await usageSync.syncUsageFromGatewayOnStartup()

    expect(callGatewayUsageMock).toHaveBeenCalledWith({ limit: 1000 })
    expect(report.updated).toBe(1)
  })

  it('debounces repeated session usage sync scheduling', async () => {
    callGatewayUsageMock.mockResolvedValue({ sessions: [{ key: 's1', usage: { totalTokens: 3 } }] })
    batchUpdateMatchedGatewayUsageMock.mockReturnValue({
      scanned: 1,
      updated: 1,
      skippedUnmatched: 0,
      skippedConflict: 0,
      failed: 0,
      durationMs: 1,
    })

    usageSync.scheduleSessionUsageSync('s1', { delayMs: 100 })
    usageSync.scheduleSessionUsageSync('s1', { delayMs: 100 })

    expect(clearTimeoutMock).toHaveBeenCalledTimes(1)
    expect(setTimeoutMock).toHaveBeenCalledTimes(2)
  })

  it('does not start duplicate in-flight session syncs', async () => {
    let releaseGateway
    callGatewayUsageMock.mockReturnValue(new Promise(resolve => {
      releaseGateway = resolve
    }))

    const first = usageSync.syncSessionUsageNow('s1')
    const second = usageSync.syncSessionUsageNow('s1')

    releaseGateway({ sessions: [{ key: 's1', usage: { totalTokens: 4 } }] })
    await Promise.all([first, second])

    expect(callGatewayUsageMock).toHaveBeenCalledTimes(1)
  })

  it('broadcasts the authoritative message count after an event-driven sync', async () => {
    getSessionOwnerMock.mockReturnValue('user-1')
    updateSessionUsageForUserMock.mockReturnValue({ updated: true })
    callGatewayUsageMock.mockResolvedValue({
      sessions: [{
        key: 's1',
        usage: { messageCounts: { total: 12 } },
      }],
    })

    const report = await usageSync.syncSessionUsageNow('s1')

    expect(report.updated).toBe(1)
    expect(broadcastSSEMock).toHaveBeenCalledWith(
      {
        type: 'event',
        event: 'session.usage.updated',
        payload: expect.objectContaining({ sessionKey: 's1', messageCount: 12 }),
      },
      expect.objectContaining({ sessionKey: 's1', messageCount: 12 }),
    )
  })

  it('startup sync fans out across all tenants and merges sessions', async () => {
    const targets = [{ baseUrl: 'http://t1', token: 'k1' }, { baseUrl: 'http://t2', token: 'k2' }]
    getGatewayHttpTargetsForAllTenantsMock.mockResolvedValue(targets)
    callGatewayUsageForTargetMock.mockImplementation(async (target) => {
      if (target.token === 'k1') return { sessions: [{ key: 's1', usage: { totalTokens: 1 } }] }
      if (target.token === 'k2') return { sessions: [{ key: 's2', usage: { totalTokens: 2 } }] }
      return { sessions: [] }
    })
    let mergedArg
    batchUpdateMatchedGatewayUsageMock.mockImplementation((arg) => {
      mergedArg = arg
      return { scanned: 2, updated: 2, skippedUnmatched: 0, skippedConflict: 0, failed: 0, durationMs: 1 }
    })

    const report = await usageSync.syncUsageFromGatewayOnStartup()

    expect(callGatewayUsageForTargetMock).toHaveBeenCalledTimes(2)
    expect(callGatewayUsageMock).not.toHaveBeenCalled()
    expect(mergedArg.sessions).toHaveLength(2)
    expect(report.updated).toBe(2)
  })

  it('startup sync tolerates a failing tenant target without dropping others', async () => {
    const targets = [{ baseUrl: 'http://t1', token: 'k1' }, { baseUrl: 'http://t2', token: 'k2' }]
    getGatewayHttpTargetsForAllTenantsMock.mockResolvedValue(targets)
    callGatewayUsageForTargetMock.mockImplementation(async (target) => {
      if (target.token === 'k1') throw new Error('tenant down')
      return { sessions: [{ key: 's2', usage: { totalTokens: 2 } }] }
    })
    let mergedArg
    batchUpdateMatchedGatewayUsageMock.mockImplementation((arg) => {
      mergedArg = arg
      return { scanned: 1, updated: 1, skippedUnmatched: 0, skippedConflict: 0, failed: 0, durationMs: 1 }
    })

    const report = await usageSync.syncUsageFromGatewayOnStartup()

    // 失败租户被 allSettled 吞掉,仅合并成功租户
    expect(mergedArg.sessions).toHaveLength(1)
    expect(report.updated).toBe(1)
  })

  it('per-session sync returns first tenant hit and skips the rest', async () => {
    const targets = [{ baseUrl: 'http://t1', token: 'k1' }, { baseUrl: 'http://t2', token: 'k2' }]
    getGatewayHttpTargetsForAllTenantsMock.mockResolvedValue(targets)
    callGatewayUsageForTargetMock.mockImplementation(async (target) => {
      // 第二个租户命中
      if (target.token === 'k2') return { sessions: [{ key: 's9', usage: { totalTokens: 9 } }] }
      return { sessions: [] }
    })
    let mergedArg
    batchUpdateMatchedGatewayUsageMock.mockImplementation((arg) => {
      mergedArg = arg
      return { scanned: 1, updated: 1, skippedUnmatched: 0, skippedConflict: 0, failed: 0, durationMs: 1 }
    })

    const report = await usageSync.syncSessionUsageNow('s9')

    expect(callGatewayUsageForTargetMock).toHaveBeenCalledTimes(2)
    expect(callGatewayUsageMock).not.toHaveBeenCalled()
    expect(mergedArg.sessions).toHaveLength(1)
    expect(report.updated).toBe(1)
  })
})
