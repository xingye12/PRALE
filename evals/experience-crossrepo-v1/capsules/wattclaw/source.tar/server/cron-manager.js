import db from './database.js'
import { gatewayAdminRpc, gatewayAdminRpcForTarget } from './core/gateway-client.js'
import { getGatewayHttpTargetsForAllTenants } from './core/multi-tenant-gateway.js'
import { getAllGatewayAgentIds, getUserOwnedAgentIds } from './user-manager.js'

// ── helpers ──

function asString(value, fallback = '') {
  return typeof value === 'string' ? value : fallback
}

function asNumber(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n : undefined
}

function asBoolean(value, fallback = false) {
  if (typeof value === 'boolean') return value
  if (value === 1 || value === '1' || value === 'true') return true
  if (value === 0 || value === '0' || value === 'false') return false
  return fallback
}

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function parseJsonField(value) {
  if (!value || typeof value !== 'string') return undefined
  try { return JSON.parse(value) } catch { return undefined }
}

function normalizeSessionKey(value) {
  let sessionKey = asString(value).trim()
  while (sessionKey.startsWith('session:')) {
    sessionKey = sessionKey.slice('session:'.length).trim()
  }
  return sessionKey
}

function sessionKeyFromTarget(sessionTarget) {
  const target = asString(sessionTarget).trim()
  return target.startsWith('session:') ? normalizeSessionKey(target) : ''
}

function normalizeSessionTarget(sessionTarget, sessionKey = '') {
  const target = asString(sessionTarget).trim()
  if (target === 'main' || target === 'isolated') return target

  const normalizedKey = normalizeSessionKey(sessionKey) || sessionKeyFromTarget(target)
  return normalizedKey ? `session:${normalizedKey}` : ''
}

function uniqueStrings(values) {
  return [...new Set(values.filter(value => typeof value === 'string' && value.trim()).map(value => value.trim()))]
}

function cronJobIdOf(job) {
  const row = asRecord(job)
  return asString(row.id || row.jobId || row.taskId || row.name)
}

function cronJobAgentIdOf(job, fallbackAgentId = '') {
  const row = asRecord(job)
  const key = asString(row.key)
  const sessionKey = normalizeSessionKey(row.sessionKey) || sessionKeyFromTarget(asString(row.sessionTarget))
  return asString(row.agentId || row.agent || row.agent_id)
    || key.match(/^agent:([^:]+):/)?.[1]
    || sessionKey.match(/^agent:([^:]+):/)?.[1]
    || fallbackAgentId
}

function getAgentIdsForCronScope(options = {}) {
  if (!options.userId) return []
  return uniqueStrings(getUserOwnedAgentIds(options.userId))
}

function getAllAgentIdsByTenantId() {
  const rows = db.prepare(`
    SELECT DISTINCT uta.tenant_id, ua.gateway_agent_id
    FROM user_agents ua
    INNER JOIN user_tenant_assignments uta ON uta.user_id = ua.user_id
    WHERE ua.status = 'active' AND ua.gateway_agent_id IS NOT NULL AND ua.gateway_agent_id != ''
  `).all()

  const result = new Map()
  for (const row of rows) {
    const tenantId = asString(row.tenant_id)
    const agentId = asString(row.gateway_agent_id)
    if (!tenantId || !agentId) continue
    if (!result.has(tenantId)) result.set(tenantId, [])
    result.get(tenantId).push(agentId)
  }
  return result
}

async function mapWithConcurrency(items, limit, mapper) {
  const results = []
  let nextIndex = 0
  const workerCount = Math.min(Math.max(1, limit), items.length)

  async function worker() {
    while (nextIndex < items.length) {
      const index = nextIndex
      nextIndex += 1
      results[index] = await mapper(items[index], index)
    }
  }

  await Promise.all(Array.from({ length: workerCount }, () => worker()))
  return results
}

// ── normalize: DB row → CronJob shape (matches frontend CronJob interface) ──

function normalizeCronJobRow(row) {
  const state = parseJsonField(row.state)
  const scheduleObj = parseJsonField(row.schedule_obj)
  const payload = parseJsonField(row.payload)
  const delivery = parseJsonField(row.delivery)
  const scheduleRow = scheduleObj ? asRecord(scheduleObj) : {}
  const scheduleText = asString(row.schedule)
    || asString(scheduleRow.expr || scheduleRow.expression || scheduleRow.cron)
  const sessionTarget = normalizeSessionTarget(row.session_target)
  const sessionKey = sessionKeyFromTarget(sessionTarget)

  return {
    id: asString(row.id),
    agentId: asString(row.agent_id) || undefined,
    name: asString(row.name, 'unnamed'),
    description: asString(row.description) || undefined,
    enabled: asBoolean(row.enabled, true),
    deleteAfterRun: asBoolean(row.delete_after_run),
    createdAtMs: asNumber(row.created_at_ms),
    updatedAtMs: asNumber(row.updated_at_ms),
    scheduleObj,
    sessionTarget: sessionTarget || undefined,
    sessionKey: sessionKey || undefined,
    wakeMode: row.wake_mode === 'now' ? 'now' : row.wake_mode === 'next-heartbeat' ? 'next-heartbeat' : undefined,
    payload,
    delivery,
    state,
    schedule: scheduleText,
    command: asString(row.command) || (payload ? asRecord(payload).text || asRecord(payload).message : undefined) || undefined,
    timezone: asString(row.timezone || scheduleRow.timezone || scheduleRow.tz) || undefined,
    nextRun: asString(state?.nextRunAtMs ? String(state.nextRunAtMs) : '') || undefined,
    lastRun: asString(state?.lastRunAtMs ? String(state.lastRunAtMs) : '') || undefined,
  }
}

// ── read: list jobs with ownership filtering ──

export function listCronJobsFromDb(options = {}) {
  if (options.isAdmin) {
    return db.prepare('SELECT * FROM cron_jobs ORDER BY created_at_ms DESC').all().map(normalizeCronJobRow)
  }

  const rows = db.prepare(`
    SELECT DISTINCT cj.* FROM cron_jobs cj
    INNER JOIN user_agents ua ON cj.agent_id = ua.gateway_agent_id AND ua.status = 'active'
    WHERE ua.user_id = ?
    ORDER BY cj.created_at_ms DESC
  `).all(options.userId)

  return rows.map(normalizeCronJobRow)
}

async function listCronJobsFromGatewayForAgentIds(gatewayRpc, agentIds, options = {}) {
  if (typeof gatewayRpc !== 'function') return { ok: false, error: 'gatewayRpc is required', jobs: [] }

  const scopedAgentIds = uniqueStrings(agentIds)
  if (!scopedAgentIds.length) return { ok: true, jobs: [], count: 0, agents: 0 }

  const jobsById = new Map()
  const errors = []
  const syncedAgentIds = []
  const concurrency = Number.isFinite(options.concurrency) ? options.concurrency : 3

  await mapWithConcurrency(scopedAgentIds, concurrency, async (agentId) => {
    const result = await gatewayRpc('cron.list', { includeDisabled: true, agentId })
    if (!result?.ok) {
      errors.push({ agentId, error: result?.error || `cron.list failed for ${agentId}` })
      return
    }

    const jobs = normalizeCronListPayload(result.payload)
    syncedAgentIds.push(agentId)
    for (const job of jobs) {
      const id = cronJobIdOf(job)
      if (!id) continue
      const jobAgentId = cronJobAgentIdOf(job, agentId)
      if (!jobAgentId || !scopedAgentIds.includes(jobAgentId)) continue
      jobsById.set(id, { ...asRecord(job), id, agentId: jobAgentId })
    }
  })

  return {
    ok: errors.length < scopedAgentIds.length,
    jobs: Array.from(jobsById.values()),
    count: jobsById.size,
    agents: scopedAgentIds.length,
    syncedAgentIds,
    errors,
    error: errors.length ? errors.map(item => `${item.agentId}: ${item.error}`).join('; ') : undefined,
  }
}

export async function listCronJobsFromGatewayForScope(gatewayRpc, options = {}) {
  return listCronJobsFromGatewayForAgentIds(gatewayRpc, getAgentIdsForCronScope(options), options)
}

export function replaceCronJobsForAgents(jobs, agentIds) {
  const scopedAgentIds = uniqueStrings(agentIds)
  const syncTx = db.transaction(() => {
    for (const agentId of scopedAgentIds) {
      db.prepare('DELETE FROM cron_jobs WHERE agent_id = ?').run(agentId)
    }
    for (const job of jobs) {
      upsertCronJob(job)
    }
  })
  syncTx()
}

function replaceAllCronJobs(jobs) {
  const syncTx = db.transaction(() => {
    db.prepare('DELETE FROM cron_jobs').run()
    for (const job of jobs) {
      upsertCronJob(job)
    }
  })
  syncTx()
}

export async function refreshAllCronJobsForAdmin(gatewayRpc = gatewayAdminRpc) {
  const targets = await getGatewayHttpTargetsForAllTenants()
  if (!targets) {
    const agentIds = getAllGatewayAgentIds()
    const result = await listCronJobsFromGatewayForAgentIds(
      gatewayRpc,
      agentIds,
    )
    if (result.ok || result.jobs.length > 0) replaceAllCronJobs(result.jobs)
    return result
  }

  const agentIdsByTenantId = getAllAgentIdsByTenantId()
  const results = await Promise.allSettled(targets.map(target => {
    const agentIds = agentIdsByTenantId.get(target.tenant?.id) || []
    return listCronJobsFromGatewayForAgentIds(
      (method, params) => gatewayAdminRpcForTarget(target, method, params),
      agentIds,
    )
  }))

  const jobsById = new Map()
  const errors = []
  let agents = 0
  for (const result of results) {
    if (result.status === 'rejected') {
      errors.push({ error: result.reason?.message || String(result.reason) })
      continue
    }
    agents += result.value.agents || 0
    if (!result.value.ok && result.value.error) errors.push({ error: result.value.error })
    for (const job of result.value.jobs || []) {
      const id = cronJobIdOf(job)
      if (id) jobsById.set(id, job)
    }
  }

  const jobs = Array.from(jobsById.values())
  const ok = errors.length < results.length
  if (ok || jobs.length > 0) replaceAllCronJobs(jobs)
  return {
    ok,
    jobs,
    count: jobs.length,
    agents,
    errors,
    error: errors.length ? errors.map(item => item.error).join('; ') : undefined,
  }
}

export async function refreshCronJobsForScope(gatewayRpc, options = {}) {
  if (options.isAdmin) {
    return refreshAllCronJobsForAdmin(gatewayRpc)
  }

  const result = await listCronJobsFromGatewayForScope(gatewayRpc, options)
  if (!result.ok && result.errors?.length) {
    console.warn('[Cron] scoped refresh partial failure:', result.error)
  }
  if (result.ok || result.jobs.length > 0) {
    replaceCronJobsForAgents(result.jobs, result.syncedAgentIds || [])
  }
  return result
}

// ── read: check if a user can access a specific job ──

export function isCronJobOwnedBy(jobId, options = {}) {
  if (options.isAdmin) return true

  const row = db.prepare(`
    SELECT 1 FROM cron_jobs cj
    INNER JOIN user_agents ua ON cj.agent_id = ua.gateway_agent_id AND ua.status = 'active'
    WHERE cj.id = ? AND ua.user_id = ?
  `).get(jobId, options.userId)

  return !!row
}

// ── read: get a single job by id (admin-only, no ownership filter) ──

export function getCronJobById(jobId) {
  const row = db.prepare('SELECT * FROM cron_jobs WHERE id = ?').get(jobId)
  return row ? normalizeCronJobRow(row) : null
}

// ── read: check if user owns an agent ──

export function isAgentOwnedBy(agentId, options = {}) {
  if (options.isAdmin) return true
  if (!agentId) return false

  const row = db.prepare(
    "SELECT 1 FROM user_agents WHERE gateway_agent_id = ? AND user_id = ? AND status = 'active'"
  ).get(agentId, options.userId)

  return !!row
}

// ── write: upsert a cron job into SQLite ──

export function upsertCronJob(job) {
  const row = asRecord(job)
  const id = asString(row.id || row.jobId || row.taskId || row.name)
  if (!id) return

  // Extract agentId from direct field or from key/sessionKey patterns (e.g. "agent:my-agent:schedule-1")
  const directAgentId = asString(row.agentId || row.agent)
  const key = asString(row.key)
  const rawSessionTarget = asString(row.sessionTarget || row.session_target || row.targetSession || row.target)
  const sessionKey = normalizeSessionKey(row.sessionKey || row.session_key || row.targetSessionKey)
    || sessionKeyFromTarget(rawSessionTarget)
    || (asRecord(row.payload).kind === 'agentTurn' ? normalizeSessionKey(asRecord(row.payload).sessionKey) : '')
    || (asRecord(row.payload).kind === 'agentTurn' ? sessionKeyFromTarget(asString(asRecord(row.payload).sessionTarget)) : '')
  const sessionTarget = normalizeSessionTarget(rawSessionTarget, sessionKey)
  const extractedAgentId = key.match(/^agent:([^:]+):/)?.[1] || sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
  const agentId = directAgentId || extractedAgentId
  const scheduleObj = row.scheduleObj || (row.schedule && typeof row.schedule === 'object' ? row.schedule : null)
  const payload = row.payload || null
  const delivery = row.delivery || null
  const state = row.state || null
  // schedule text: prefer explicit text fields, then extract from scheduleObj if schedule is an object
  let scheduleText = asString(row.scheduleText || row.cron || row.expression)
  if (!scheduleText && scheduleObj) {
    scheduleText = asString(asRecord(scheduleObj).expr || asRecord(scheduleObj).expression || asRecord(scheduleObj).cron)
  }
  // Only use row.schedule if it's a plain string (not a CronSchedule object)
  if (!scheduleText && typeof row.schedule === 'string') {
    scheduleText = row.schedule
  }

  db.prepare(`
    INSERT INTO cron_jobs (id, agent_id, name, description, enabled, schedule, schedule_obj, payload, delivery, state, session_target, wake_mode, delete_after_run, timezone, created_at_ms, updated_at_ms, synced_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      agent_id = excluded.agent_id,
      name = excluded.name,
      description = excluded.description,
      enabled = excluded.enabled,
      schedule = excluded.schedule,
      schedule_obj = excluded.schedule_obj,
      payload = excluded.payload,
      delivery = excluded.delivery,
      state = excluded.state,
      session_target = excluded.session_target,
      wake_mode = excluded.wake_mode,
      delete_after_run = excluded.delete_after_run,
      timezone = excluded.timezone,
      created_at_ms = COALESCE(excluded.created_at_ms, cron_jobs.created_at_ms),
      updated_at_ms = excluded.updated_at_ms,
      synced_at = excluded.synced_at
  `).run(
    id,
    agentId || null,
    asString(row.name || row.title || row.id, 'unnamed'),
    asString(row.description) || null,
    asBoolean(row.enabled, true) ? 1 : 0,
    scheduleText || null,
    scheduleObj ? JSON.stringify(scheduleObj) : null,
    payload ? JSON.stringify(payload) : null,
    delivery ? JSON.stringify(delivery) : null,
    state ? JSON.stringify(state) : null,
    sessionTarget || (sessionKey ? `session:${sessionKey}` : null),
    asString(row.wakeMode) || null,
    asBoolean(row.deleteAfterRun) ? 1 : 0,
    asString(row.timezone) || null,
    asNumber(row.createdAtMs || row.createdAt || row.created) || null,
    asNumber(row.updatedAtMs || row.updatedAt || row.updated) || null,
    Date.now(),
  )
}

// ── write: delete a cron job from SQLite ──

export function deleteCronJob(id) {
  db.prepare('DELETE FROM cron_jobs WHERE id = ?').run(id)
}

export function upsertCronSessionBinding({ jobId, sessionKey, agentId, displayName }) {
  const normalizedJobId = asString(jobId).trim()
  const normalizedSessionKey = normalizeSessionKey(sessionKey)
  const normalizedAgentId = asString(agentId).trim()
  if (!normalizedJobId || !normalizedSessionKey || !normalizedAgentId) return

  const now = Date.now()
  db.prepare(`
    INSERT INTO cron_session_bindings (job_id, session_key, agent_id, display_name, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(job_id) DO UPDATE SET
      session_key = excluded.session_key,
      agent_id = excluded.agent_id,
      display_name = excluded.display_name,
      updated_at = excluded.updated_at
  `).run(
    normalizedJobId,
    normalizedSessionKey,
    normalizedAgentId,
    asString(displayName).trim(),
    now,
    now,
  )
}

export function updateCronSessionBindingName(jobId, displayName) {
  db.prepare(`
    UPDATE cron_session_bindings
    SET display_name = ?, updated_at = ?
    WHERE job_id = ?
  `).run(asString(displayName).trim(), Date.now(), asString(jobId).trim())
}

export function listCronSessionBindings(options = {}) {
  if (options.isAdmin) {
    return db.prepare('SELECT * FROM cron_session_bindings').all()
  }

  return db.prepare(`
    SELECT DISTINCT csb.*
    FROM cron_session_bindings csb
    INNER JOIN user_agents ua ON csb.agent_id = ua.gateway_agent_id AND ua.status = 'active'
    WHERE ua.user_id = ?
  `).all(options.userId)
}

// ── sync: full sync from Gateway ──

export async function syncCronFromGateway(gatewayAdminRpc) {
  try {
    const result = await gatewayAdminRpc('cron.list', { includeDisabled: true })
    if (!result.ok) {
      console.error('[Cron] sync failed:', result.error)
      return { ok: false, error: result.error, count: 0 }
    }

    const jobs = normalizeCronListPayload(result.payload)
    const gatewayIds = new Set()

    const syncTx = db.transaction(() => {
      for (const job of jobs) {
        upsertCronJob(job)
        gatewayIds.add(asString(job.id || job.jobId || job.taskId || job.name))
      }
      // Delete stale local records not present in Gateway
      const localRows = db.prepare('SELECT id FROM cron_jobs').all()
      for (const row of localRows) {
        if (!gatewayIds.has(row.id)) {
          db.prepare('DELETE FROM cron_jobs WHERE id = ?').run(row.id)
        }
      }
    })

    syncTx()
    console.log(`[Cron] synced ${jobs.length} jobs from Gateway`)
    return { ok: true, count: jobs.length }
  } catch (err) {
    console.error('[Cron] sync error:', err.message)
    return { ok: false, error: err.message, count: 0 }
  }
}

function normalizeCronListPayload(payload) {
  if (Array.isArray(payload)) return payload
  const row = asRecord(payload)
  for (const key of ['items', 'list', 'data', 'jobs', 'tasks', 'crons', 'schedules']) {
    const value = row[key]
    if (Array.isArray(value)) return value
  }
  return []
}
