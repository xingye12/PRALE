import Database from 'better-sqlite3'
import { mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const dbPath = join(__dirname, '../data/wizard.db')

mkdirSync(dirname(dbPath), { recursive: true })

const db = new Database(dbPath)

db.pragma('journal_mode = WAL')

db.exec(`
  CREATE TABLE IF NOT EXISTS scenarios (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'draft',
    agent_selection_mode TEXT DEFAULT 'existing',
    selected_agents TEXT DEFAULT '[]',
    generated_agents TEXT DEFAULT '[]',
    bindings TEXT DEFAULT '[]',
    tasks TEXT DEFAULT '[]',
    execution_log TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    scenario_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'pending',
    assigned_agents TEXT DEFAULT '[]',
    priority TEXT DEFAULT 'medium',
    mode TEXT DEFAULT 'default',
    conversation_history TEXT DEFAULT '[]',
    execution_history TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS backup_records (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    filename TEXT,
    status TEXT DEFAULT 'pending',
    progress INTEGER DEFAULT 0,
    message TEXT,
    stage TEXT,
    error TEXT,
    result TEXT,
    created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
    completed_at INTEGER,
    size INTEGER
  );

  CREATE TABLE IF NOT EXISTS skill_store_skill (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    icon TEXT NOT NULL DEFAULT '',
    icon_color TEXT NOT NULL DEFAULT '#6366f1',
    category TEXT NOT NULL DEFAULT 'general',
    usage TEXT NOT NULL DEFAULT '',
    version TEXT NOT NULL DEFAULT '1.0.0',
    type TEXT NOT NULL DEFAULT 'builtin',
    installed INTEGER NOT NULL DEFAULT 0,
    gateway_name TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS skill_store_agent_skill (
    id TEXT PRIMARY KEY,
    skill_id TEXT NOT NULL REFERENCES skill_store_skill(id) ON DELETE CASCADE,
    agent_id TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(skill_id, agent_id)
  );

  CREATE INDEX IF NOT EXISTS idx_tasks_scenario_id ON tasks(scenario_id);
  CREATE INDEX IF NOT EXISTS idx_scenarios_status ON scenarios(status);
  CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
  CREATE INDEX IF NOT EXISTS idx_backup_records_created_at ON backup_records(created_at);
  CREATE INDEX IF NOT EXISTS idx_skill_store_skill_gateway_name ON skill_store_skill(gateway_name);
  CREATE INDEX IF NOT EXISTS idx_skill_store_skill_category ON skill_store_skill(category);
  CREATE INDEX IF NOT EXISTS idx_skill_store_agent_skill_agent_id ON skill_store_agent_skill(agent_id);
`)

try {
  db.exec('ALTER TABLE scenarios ADD COLUMN execution_log TEXT DEFAULT \'[]\'')
} catch (e) {
  if (!e.message.includes('duplicate column name')) {
    console.error('[Database] Failed to add execution_log column:', e.message)
  }
}

try {
  db.exec('ALTER TABLE tasks ADD COLUMN execution_history TEXT DEFAULT \'[]\'')
} catch (e) {
  if (!e.message.includes('duplicate column name')) {
    console.error('[Database] Failed to add execution_history column:', e.message)
  }
}

function addColumnIfMissing(table, column, definition) {
  try {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`)
  } catch (e) {
    if (!e.message.includes('duplicate column name')) {
      console.error(`[Database] Failed to add ${table}.${column}:`, e.message)
    }
  }
}

// Cleanup expired OAuth states every minute
setInterval(() => {
  try {
    const cutoff = Date.now() - 5 * 60 * 1000
    db.prepare('DELETE FROM oauth_states WHERE created_at < ?').run(cutoff)
  } catch {}
}, 60_000)

export function createBackupRecord(id, type, filename = null) {
  const stmt = db.prepare(`
    INSERT INTO backup_records (id, type, filename, status, progress, message, created_at)
    VALUES (?, ?, ?, 'pending', 0, 'Task created', ?)
  `)
  stmt.run(id, type, filename, Date.now())
  return id
}

export function updateBackupRecord(id, updates) {
  const fields = []
  const values = []
  
  for (let [key, value] of Object.entries(updates)) {
    if (key === 'completedAt') key = 'completed_at'
    fields.push(`${key} = ?`)
    values.push(typeof value === 'object' ? JSON.stringify(value) : value)
  }
  
  values.push(id)
  
  const stmt = db.prepare(`UPDATE backup_records SET ${fields.join(', ')} WHERE id = ?`)
  stmt.run(...values)
}

export function getBackupRecord(id) {
  const stmt = db.prepare('SELECT * FROM backup_records WHERE id = ?')
  const record = stmt.get(id)
  if (record && record.result) {
    record.result = JSON.parse(record.result)
  }
  return record
}

export function getBackupRecords(limit = 20, offset = 0) {
  const stmt = db.prepare('SELECT * FROM backup_records ORDER BY created_at DESC LIMIT ? OFFSET ?')
  const records = stmt.all(limit, offset)
  return records.map(r => {
    if (r.result) {
      r.result = JSON.parse(r.result)
    }
    return r
  })
}

export function getBackupRecordsCount() {
  const stmt = db.prepare('SELECT COUNT(*) as count FROM backup_records')
  return stmt.get().count
}

export function deleteBackupRecord(id) {
  const stmt = db.prepare('DELETE FROM backup_records WHERE id = ?')
  stmt.run(id)
}

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    display_name TEXT,
    email TEXT,
    avatar TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    settings TEXT DEFAULT '{}',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
  );

  CREATE TABLE IF NOT EXISTS auth_tokens (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    token TEXT NOT NULL UNIQUE,
    user_agent TEXT,
    ip_address TEXT,
    expires_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    last_used_at INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS user_agents (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    gateway_agent_id TEXT,
    workspace TEXT,
    name TEXT NOT NULL,
    description TEXT,
    config TEXT DEFAULT '{}',
    system_prompt TEXT,
    model TEXT,
    category TEXT,
    template_id TEXT,
    avatar TEXT,
    status TEXT DEFAULT 'active',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS user_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    session_key TEXT NOT NULL,
    agent_id TEXT,
    label TEXT,
    channel TEXT,
    peer_id TEXT,
    display_title TEXT,
    last_message_at INTEGER,
    token_input INTEGER DEFAULT 0,
    token_output INTEGER DEFAULT 0,
    token_cache_read INTEGER DEFAULT 0,
    token_cache_write INTEGER DEFAULT 0,
    token_total INTEGER DEFAULT 0,
    cost_total REAL DEFAULT 0,
    msg_total INTEGER DEFAULT 0,
    msg_user INTEGER DEFAULT 0,
    msg_assistant INTEGER DEFAULT 0,
    msg_tool_calls INTEGER DEFAULT 0,
    msg_tool_results INTEGER DEFAULT 0,
    msg_errors INTEGER DEFAULT 0,
    tool_usage_json TEXT DEFAULT '{}',
    usage_synced_at INTEGER,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_user_sessions_agent_id ON user_sessions(agent_id);

  CREATE TABLE IF NOT EXISTS user_channels (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    agent_id TEXT,
    channel_type TEXT NOT NULL,
    name TEXT NOT NULL,
    config TEXT DEFAULT '{}',
    webhook_url TEXT,
    status TEXT DEFAULT 'inactive',
    last_sync_at INTEGER,
    error_message TEXT,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
  CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
  CREATE INDEX IF NOT EXISTS idx_auth_tokens_token ON auth_tokens(token);
  CREATE INDEX IF NOT EXISTS idx_auth_tokens_user_id ON auth_tokens(user_id);
  CREATE INDEX IF NOT EXISTS idx_user_agents_user_id ON user_agents(user_id);
  CREATE INDEX IF NOT EXISTS idx_user_agents_gateway_agent_id ON user_agents(gateway_agent_id);
  CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_user_sessions_session_key ON user_sessions(session_key);
  CREATE INDEX IF NOT EXISTS idx_user_channels_user_id ON user_channels(user_id);
  CREATE INDEX IF NOT EXISTS idx_user_channels_type ON user_channels(channel_type);

  CREATE TABLE IF NOT EXISTS agent_team (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    avatar TEXT,
    model TEXT,
    status TEXT DEFAULT 'idle',
    soul_md TEXT,
    agents_md TEXT,
    identity_md TEXT,
    user_md TEXT,
    created_by TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_agent_team_created_by ON agent_team(created_by);

  CREATE TABLE IF NOT EXISTS user_model_providers (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    config TEXT NOT NULL DEFAULT '{}',
    is_primary BOOLEAN DEFAULT 0,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(user_id, provider_id)
  );

  CREATE INDEX IF NOT EXISTS idx_user_model_providers_user ON user_model_providers(user_id);

  CREATE TABLE IF NOT EXISTS models (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL DEFAULT '',
    label TEXT DEFAULT '',
    family TEXT DEFAULT '',
    enabled INTEGER DEFAULT 1,
    available INTEGER DEFAULT 1,
    description TEXT DEFAULT '',
    context_window INTEGER DEFAULT 0,
    capabilities TEXT DEFAULT '[]',
    remark TEXT DEFAULT '',
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
  );

  CREATE INDEX IF NOT EXISTS idx_models_provider ON models(provider);
  CREATE INDEX IF NOT EXISTS idx_models_available ON models(available);

  CREATE TABLE IF NOT EXISTS model_health_checks (
    model_ref TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL DEFAULT '',
    model_id TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'unknown',
    latency_ms INTEGER DEFAULT 0,
    first_byte_ms INTEGER DEFAULT 0,
    error TEXT DEFAULT '',
    original_remark TEXT DEFAULT '',
    checked_at INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
  );

  CREATE INDEX IF NOT EXISTS idx_model_health_checks_status ON model_health_checks(status);

  CREATE TABLE IF NOT EXISTS issues (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    description TEXT NOT NULL,
    images TEXT DEFAULT '[]',
    status TEXT DEFAULT 'open',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_issues_user_id ON issues(user_id);
  CREATE INDEX IF NOT EXISTS idx_issues_created_at ON issues(created_at);

  CREATE TABLE IF NOT EXISTS cron_jobs (
    id              TEXT PRIMARY KEY,
    agent_id        TEXT,
    name            TEXT NOT NULL DEFAULT '',
    description     TEXT,
    enabled         INTEGER NOT NULL DEFAULT 1,
    schedule        TEXT,
    schedule_obj    TEXT,
    payload         TEXT,
    delivery        TEXT,
    state           TEXT,
    session_target  TEXT,
    wake_mode       TEXT,
    delete_after_run INTEGER DEFAULT 0,
    timezone        TEXT,
    created_at_ms   INTEGER,
    updated_at_ms   INTEGER,
    synced_at       INTEGER NOT NULL DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_cron_jobs_agent_id ON cron_jobs(agent_id);

  CREATE TABLE IF NOT EXISTS cron_session_bindings (
    job_id          TEXT PRIMARY KEY,
    session_key     TEXT NOT NULL UNIQUE,
    agent_id        TEXT NOT NULL,
    display_name    TEXT NOT NULL DEFAULT '',
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_cron_session_bindings_agent_id ON cron_session_bindings(agent_id);
`)

  // ── Feishu OAuth tables ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_oauth_bindings (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      provider TEXT NOT NULL DEFAULT 'feishu',
      feishu_user_id TEXT NOT NULL,
      open_id TEXT,
      display_name TEXT,
      avatar_url TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_oauth_provider_feishu_user
      ON user_oauth_bindings(provider, feishu_user_id);
    CREATE INDEX IF NOT EXISTS idx_oauth_user_id
      ON user_oauth_bindings(user_id);

    CREATE TABLE IF NOT EXISTS user_feishu_bots (
      user_id TEXT PRIMARY KEY,
      app_id TEXT NOT NULL UNIQUE,
      app_secret_encrypted TEXT NOT NULL,
      owner_open_id TEXT NOT NULL,
      bot_open_id TEXT,
      bot_name TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      last_error TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS wattclaw_project_feishu_sync (
      project_id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      tenant_id TEXT,
      project_name TEXT NOT NULL,
      chat_id TEXT NOT NULL UNIQUE,
      chat_name TEXT NOT NULL,
      members_json TEXT NOT NULL DEFAULT '[]',
      enabled INTEGER NOT NULL DEFAULT 1,
      last_sync_at INTEGER,
      last_error TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS wattclaw_project_feishu_members (
      project_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      PRIMARY KEY (project_id, agent_id),
      FOREIGN KEY (project_id) REFERENCES wattclaw_project_feishu_sync(project_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS wattclaw_project_access (
      user_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      tenant_id TEXT NOT NULL DEFAULT '',
      last_accessed_at INTEGER NOT NULL,
      restored_at INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, project_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_wattclaw_feishu_sync_user
      ON wattclaw_project_feishu_sync(user_id, enabled);
    CREATE INDEX IF NOT EXISTS idx_wattclaw_feishu_sync_tenant
      ON wattclaw_project_feishu_sync(tenant_id, enabled);
    CREATE INDEX IF NOT EXISTS idx_wattclaw_feishu_members_agent
      ON wattclaw_project_feishu_members(agent_id);
    CREATE INDEX IF NOT EXISTS idx_wattclaw_project_access_user
      ON wattclaw_project_access(user_id, last_accessed_at DESC);

    CREATE TABLE IF NOT EXISTS oauth_states (
      state TEXT PRIMARY KEY,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL,
      created_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notification_reads (
      notification_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      read_at INTEGER NOT NULL,
      PRIMARY KEY (notification_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS openclaw_tenants (
      id TEXT PRIMARY KEY,
      container_name TEXT NOT NULL UNIQUE,
      token TEXT NOT NULL,
      host TEXT NOT NULL,
      port INTEGER NOT NULL DEFAULT 18789,
      max_users INTEGER NOT NULL DEFAULT 20,
      cpuset_cpus TEXT DEFAULT '',
      data_source TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000)
    );

    CREATE TABLE IF NOT EXISTS user_tenant_assignments (
      user_id TEXT PRIMARY KEY,
      tenant_id TEXT NOT NULL,
      assignment_mode TEXT NOT NULL DEFAULT 'auto',
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (tenant_id) REFERENCES openclaw_tenants(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_user_tenant_assignments_tenant_id ON user_tenant_assignments(tenant_id);

    CREATE TABLE IF NOT EXISTS knowledge_bases (
      id TEXT PRIMARY KEY,
      ragflow_kb_id TEXT UNIQUE NOT NULL,
      user_id TEXT NOT NULL,
      name_snapshot TEXT DEFAULT '',
      description_snapshot TEXT DEFAULT '',
      ragflow_permission TEXT DEFAULT '',
      is_public INTEGER NOT NULL DEFAULT 0,
      document_count INTEGER NOT NULL DEFAULT 0,
      chunk_count INTEGER NOT NULL DEFAULT 0,
      ragflow_created_at INTEGER,
      ragflow_updated_at INTEGER,
      last_synced_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_knowledge_bases_user ON knowledge_bases(user_id);
  `)

db.exec(`
  CREATE TABLE IF NOT EXISTS team_templates (
    template_key TEXT PRIMARY KEY,
    template_id TEXT NOT NULL,
    version TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'global',
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    definition_json TEXT NOT NULL DEFAULT '{}',
    created_by TEXT,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    UNIQUE(template_id, version)
  );

  CREATE INDEX IF NOT EXISTS idx_team_templates_status
    ON team_templates(status, scope, updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_team_templates_id
    ON team_templates(template_id, version);

  CREATE TABLE IF NOT EXISTS wattclaw_project_template_matches (
    project_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL DEFAULT '',
    template_id TEXT,
    template_version TEXT,
    score REAL NOT NULL DEFAULT 0,
    decision TEXT NOT NULL DEFAULT 'fresh_plan',
    normalized_intent_json TEXT NOT NULL DEFAULT '{}',
    match_json TEXT NOT NULL DEFAULT '{}',
    template_snapshot_json TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_project_template_matches_user
    ON wattclaw_project_template_matches(user_id, updated_at DESC);

  CREATE TABLE IF NOT EXISTS team_template_runs (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    template_id TEXT,
    template_version TEXT,
    fingerprint TEXT NOT NULL,
    outcome TEXT NOT NULL,
    manifest_json TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(project_id, user_id)
  );

  CREATE INDEX IF NOT EXISTS idx_team_template_runs_fingerprint
    ON team_template_runs(fingerprint, outcome, updated_at DESC);

  CREATE TABLE IF NOT EXISTS agent_profiles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL DEFAULT '',
    role_id TEXT NOT NULL,
    name TEXT NOT NULL,
    gateway_agent_id TEXT,
    base_workspace TEXT,
    capability_tags_json TEXT NOT NULL DEFAULT '[]',
    skills_json TEXT NOT NULL DEFAULT '[]',
    model TEXT,
    reuse_policy TEXT NOT NULL DEFAULT 'profile',
    concurrency_limit INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'available',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_agent_profiles_user_status
    ON agent_profiles(user_id, status, updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_agent_profiles_role
    ON agent_profiles(user_id, role_id, status);

  CREATE TABLE IF NOT EXISTS project_member_bindings (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    slot_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    runtime_agent_id TEXT,
    session_key TEXT,
    project_workspace TEXT,
    lease_until INTEGER,
    status TEXT NOT NULL DEFAULT 'leased',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now') * 1000),
    released_at INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES agent_profiles(id) ON DELETE CASCADE,
    UNIQUE(project_id, slot_id)
  );

  CREATE INDEX IF NOT EXISTS idx_project_member_bindings_project
    ON project_member_bindings(project_id, status);
  CREATE INDEX IF NOT EXISTS idx_project_member_bindings_profile
    ON project_member_bindings(profile_id, status, lease_until);
`)

// Migrations: add columns to existing user_agents table
const migrations = [
  'ALTER TABLE user_agents ADD COLUMN category TEXT',
  'ALTER TABLE user_agents ADD COLUMN template_id TEXT',
  'ALTER TABLE user_agents ADD COLUMN avatar TEXT',
  'ALTER TABLE user_agents ADD COLUMN workspace TEXT',
  'ALTER TABLE user_channels ADD COLUMN agent_id TEXT',
  'ALTER TABLE users ADD COLUMN password_changed_at INTEGER',
  'ALTER TABLE user_model_providers ADD COLUMN remark TEXT DEFAULT \'\'',
  'ALTER TABLE user_model_providers ADD COLUMN description TEXT DEFAULT \'\'',
  'ALTER TABLE skill_store_skill ADD COLUMN readme TEXT DEFAULT \'\'',
  'ALTER TABLE skill_store_skill ADD COLUMN source TEXT DEFAULT \'gateway\'',
  'ALTER TABLE models ADD COLUMN health_status TEXT DEFAULT \'unknown\'',
  'ALTER TABLE models ADD COLUMN latency_ms INTEGER DEFAULT 0',
  'ALTER TABLE models ADD COLUMN first_byte_ms INTEGER DEFAULT 0',
  'ALTER TABLE models ADD COLUMN health_error TEXT DEFAULT \'\'',
  'ALTER TABLE models ADD COLUMN health_checked_at INTEGER DEFAULT 0',
  // Multi-tenant: columns duplicated from CREATE TABLE for legacy DB upgrade
  // (new DBs already have them via CREATE; runMigration swallows "duplicate column").
  'ALTER TABLE openclaw_tenants ADD COLUMN max_users INTEGER NOT NULL DEFAULT 20',
  'ALTER TABLE openclaw_tenants ADD COLUMN cpuset_cpus TEXT DEFAULT \'\'',
  'ALTER TABLE openclaw_tenants ADD COLUMN data_source TEXT DEFAULT \'\'',
  'ALTER TABLE openclaw_tenants ADD COLUMN status TEXT NOT NULL DEFAULT \'active\'',
  'ALTER TABLE openclaw_tenants ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE openclaw_tenants ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE user_tenant_assignments ADD COLUMN assignment_mode TEXT NOT NULL DEFAULT \'auto\'',
  'ALTER TABLE user_tenant_assignments ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE user_tenant_assignments ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE user_sessions ADD COLUMN tenant_id TEXT',
  'ALTER TABLE wattclaw_project_access ADD COLUMN restored_at INTEGER NOT NULL DEFAULT 0',
]
for (const sql of migrations) {
  try { db.exec(sql) } catch (e) {
    if (!String(e.message).includes('duplicate column name')) console.error('[Database] Migration error:', e.message)
  }
}

// Index on migrated column (source added by migration above)
try {
  db.exec('CREATE INDEX IF NOT EXISTS idx_skill_store_skill_source ON skill_store_skill(source)')
} catch (e) {
  if (!String(e.message).includes('already exists')) console.error('[Database] Index error:', e.message)
}

try {
  const hasModelRemarks = db.prepare(
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'model_remarks'"
  ).get()
  if (hasModelRemarks) {
    db.exec(`
      INSERT INTO models (id, provider, remark, updated_at)
        SELECT model_id, provider_id, remark, updated_at FROM model_remarks
        WHERE model_id IS NOT NULL AND model_id != ''
        ON CONFLICT(id) DO UPDATE SET
          remark = CASE
            WHEN models.remark IS NULL OR models.remark = '' THEN excluded.remark
            ELSE models.remark
          END,
          updated_at = MAX(models.updated_at, excluded.updated_at)
    `)

    const hasDeprecated = db.prepare(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'model_remarks_deprecated'"
    ).get()
    if (!hasDeprecated) {
      db.exec('ALTER TABLE model_remarks RENAME TO model_remarks_deprecated')
    }
  }
} catch (e) {
  console.error('[Database] model_remarks migration error:', e.message)
}

// Migration: add usage columns to existing user_sessions table
const usageColumns = [
  { name: 'token_input', type: 'INTEGER DEFAULT 0' },
  { name: 'token_output', type: 'INTEGER DEFAULT 0' },
  { name: 'token_cache_read', type: 'INTEGER DEFAULT 0' },
  { name: 'token_cache_write', type: 'INTEGER DEFAULT 0' },
  { name: 'token_total', type: 'INTEGER DEFAULT 0' },
  { name: 'cost_total', type: 'REAL DEFAULT 0' },
  { name: 'msg_total', type: 'INTEGER DEFAULT 0' },
  { name: 'msg_user', type: 'INTEGER DEFAULT 0' },
  { name: 'msg_assistant', type: 'INTEGER DEFAULT 0' },
  { name: 'msg_tool_calls', type: 'INTEGER DEFAULT 0' },
  { name: 'msg_tool_results', type: 'INTEGER DEFAULT 0' },
  { name: 'msg_errors', type: 'INTEGER DEFAULT 0' },
  { name: 'tool_usage_json', type: "TEXT DEFAULT '{}'" },
  { name: 'usage_synced_at', type: 'INTEGER' },
  { name: 'model', type: 'TEXT' },
  { name: 'model_provider', type: 'TEXT' },
  { name: 'peer_id', type: 'TEXT' },
  { name: 'display_title', type: 'TEXT' },
  { name: 'last_message_at', type: 'INTEGER' },
]

for (const col of usageColumns) {
  addColumnIfMissing('user_sessions', col.name, col.type)
}

const knowledgeBaseColumns = [
  { name: 'description_snapshot', type: "TEXT DEFAULT ''" },
  { name: 'ragflow_permission', type: "TEXT DEFAULT ''" },
  { name: 'is_public', type: 'INTEGER NOT NULL DEFAULT 0' },
  { name: 'document_count', type: 'INTEGER NOT NULL DEFAULT 0' },
  { name: 'chunk_count', type: 'INTEGER NOT NULL DEFAULT 0' },
  { name: 'ragflow_created_at', type: 'INTEGER' },
  { name: 'ragflow_updated_at', type: 'INTEGER' },
  { name: 'last_synced_at', type: 'INTEGER NOT NULL DEFAULT 0' },
]

for (const col of knowledgeBaseColumns) {
  addColumnIfMissing('knowledge_bases', col.name, col.type)
}

// Migration: add usage indexes
try {
  db.exec('CREATE INDEX IF NOT EXISTS idx_user_sessions_usage_user_id ON user_sessions(user_id, usage_synced_at)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_user_sessions_usage_agent_id ON user_sessions(agent_id, usage_synced_at)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_user_sessions_model ON user_sessions(model, model_provider)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_user_sessions_last_message_at ON user_sessions(last_message_at)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_user_sessions_peer_id ON user_sessions(peer_id)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_knowledge_bases_public ON knowledge_bases(is_public)')
} catch (e) {
  console.error('[Database] Failed to create usage indexes:', e.message)
}

// Backfill model + model_provider from user_agents for existing sessions
try {
  const backfilled = db.prepare(`
    UPDATE user_sessions
    SET model = ua.model,
        model_provider = CASE
          WHEN ua.model LIKE '%/%' THEN substr(ua.model, 1, instr(ua.model, '/') - 1)
          ELSE NULL
        END
    FROM user_agents ua
    WHERE ua.gateway_agent_id = user_sessions.agent_id
      AND user_sessions.model IS NULL
      AND user_sessions.agent_id IS NOT NULL
      AND ua.model IS NOT NULL AND ua.model != ''
  `).run()
  if (backfilled.changes > 0) {
    console.log(`[Database] Backfilled model for ${backfilled.changes} sessions`)
  }
} catch (e) {
  if (!String(e.message).includes('no such column')) console.error('[Database] model backfill error:', e.message)
}

// Fix NULL model_provider where model contains provider prefix (e.g. "openai/gpt-4o")
try {
  const fixed = db.prepare(`
    UPDATE user_sessions
    SET model_provider = substr(model, 1, instr(model, '/') - 1)
    WHERE model IS NOT NULL AND model != ''
      AND model LIKE '%/%'
      AND (model_provider IS NULL OR model_provider = '')
  `).run()
  if (fixed.changes > 0) {
    console.log(`[Database] Fixed model_provider for ${fixed.changes} sessions`)
  }
} catch (e) {
  if (!String(e.message).includes('no such column')) console.error('[Database] model_provider fix error:', e.message)
}

// Normalize model: strip provider prefix so "minimax/MiniMax-M2.7" → "MiniMax-M2.7"
try {
  const normalized = db.prepare(`
    UPDATE user_sessions
    SET model = substr(model, instr(model, '/') + 1),
        model_provider = substr(model, 1, instr(model, '/') - 1)
    WHERE model IS NOT NULL AND model != ''
      AND model LIKE '%/%'
  `).run()
  if (normalized.changes > 0) {
    console.log(`[Database] Normalized model names for ${normalized.changes} sessions`)
  }
} catch (e) {
  if (!String(e.message).includes('no such column')) console.error('[Database] model normalize error:', e.message)
}

// Inherit model_provider from same-model sessions that already have it
try {
  const inherited = db.prepare(`
    UPDATE user_sessions
    SET model_provider = (
      SELECT us2.model_provider FROM user_sessions us2
      WHERE us2.model = user_sessions.model
        AND us2.model_provider IS NOT NULL AND us2.model_provider != ''
      LIMIT 1
    )
    WHERE model IS NOT NULL AND model != ''
      AND (model_provider IS NULL OR model_provider = '')
      AND model IN (
        SELECT model FROM user_sessions
        WHERE model_provider IS NOT NULL AND model_provider != ''
        GROUP BY model
      )
  `).run()
  if (inherited.changes > 0) {
    console.log(`[Database] Inherited model_provider for ${inherited.changes} sessions`)
  }
} catch (e) {
  if (!String(e.message).includes('no such column')) console.error('[Database] model_provider inherit error:', e.message)
}

// Migration: add UNIQUE on session_key for upsert support
try {
  // Deduplicate any existing duplicate session_keys before adding constraint
  db.exec(`
    DELETE FROM user_sessions
    WHERE rowid NOT IN (
      SELECT MIN(rowid) FROM user_sessions GROUP BY session_key
    ) AND session_key IS NOT NULL AND session_key != ''
  `)
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_user_sessions_session_key_unique ON user_sessions(session_key)')
} catch (e) {
  if (!String(e.message).includes('already exists') && !String(e.message).includes('UNIQUE constraint')) {
    console.error('[Database] Failed to add session_key unique index:', e.message)
  }
}

export function ensureDefaultAdmin(passwordHash) {
  const existing = db.prepare("SELECT id FROM users WHERE username = 'admin'").get()
  if (!existing) {
    db.prepare(`
      INSERT INTO users (id, username, password_hash, role, display_name, status)
      VALUES (?, 'admin', ?, 'admin', 'Administrator', 'active')
    `).run(crypto.randomUUID(), passwordHash)
    console.log('[Database] Default admin user created')
  }
}

import { randomUUID as cryptoRandomUUID } from 'crypto'

try {
  ensureDefaultAdmin.__skip = true
} catch (e) {}

// Agent Team CRUD
export function getAgentTeamList(userId) {
  return db.prepare('SELECT * FROM agent_team WHERE created_by = ? ORDER BY created_at DESC').all(userId)
}

export function getAgentTeamById(id) {
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function createAgentTeam(userId, data) {
  const id = crypto.randomUUID()
  const now = Date.now()
  db.prepare(`
    INSERT INTO agent_team (id, name, description, avatar, model, status, soul_md, agents_md, identity_md, user_md, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, data.name || '', data.description || '', data.avatar || '',
    data.model || '', data.status || 'idle',
    data.soulMd || '', data.agentsMd || '', data.identityMd || '', data.userMd || '',
    userId, now, now
  )
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function updateAgentTeam(id, data) {
  const fields = []
  const values = []
  const columnMap = {
    name: 'name', description: 'description', avatar: 'avatar', model: 'model',
    status: 'status', soulMd: 'soul_md', agentsMd: 'agents_md',
    identityMd: 'identity_md', userMd: 'user_md',
  }
  for (const [key, col] of Object.entries(columnMap)) {
    if (data[key] !== undefined) {
      fields.push(`${col} = ?`)
      values.push(data[key])
    }
  }
  if (fields.length === 0) return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
  fields.push('updated_at = ?')
  values.push(Date.now())
  values.push(id)
  db.prepare(`UPDATE agent_team SET ${fields.join(', ')} WHERE id = ?`).run(...values)
  return db.prepare('SELECT * FROM agent_team WHERE id = ?').get(id)
}

export function deleteAgentTeam(id) {
  db.prepare('DELETE FROM agent_team WHERE id = ?').run(id)
}

function getPrimaryKnowledgeBaseOwnerId() {
  const admin = db.prepare("SELECT id FROM users WHERE role = 'admin' ORDER BY created_at ASC LIMIT 1").get()
  if (admin?.id) return admin.id
  const firstUser = db.prepare('SELECT id FROM users ORDER BY created_at ASC LIMIT 1').get()
  return firstUser?.id || null
}

function toDbBoolean(value) {
  if (value === true || value === 1) return 1
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase()
    if (['1', 'true', 'yes', 'public', 'all'].includes(normalized)) return 1
  }
  return 0
}

export function upsertKnowledgeBaseRecord(record) {
  if (!record?.ragflowKbId) return null
  const existing = getKnowledgeBaseBinding(record.ragflowKbId)
  const now = Number(record.lastSyncedAt || Date.now())
  const ownerId = record.userId || existing?.user_id || getPrimaryKnowledgeBaseOwnerId()
  if (!ownerId) {
    throw new Error('No knowledge base owner available')
  }

  const values = {
    nameSnapshot: String(record.nameSnapshot || '').trim(),
    descriptionSnapshot: String(record.descriptionSnapshot || '').trim(),
    ragflowPermission: String(record.ragflowPermission || '').trim(),
    isPublic: toDbBoolean(record.isPublic ?? existing?.is_public ?? 0),
    documentCount: Number.isFinite(Number(record.documentCount)) ? Number(record.documentCount) : Number(existing?.document_count || 0),
    chunkCount: Number.isFinite(Number(record.chunkCount)) ? Number(record.chunkCount) : Number(existing?.chunk_count || 0),
    ragflowCreatedAt: record.ragflowCreatedAt ?? existing?.ragflow_created_at ?? null,
    ragflowUpdatedAt: record.ragflowUpdatedAt ?? existing?.ragflow_updated_at ?? null,
    lastSyncedAt: now,
  }

  if (existing) {
    db.prepare(`
      UPDATE knowledge_bases
      SET
        user_id = COALESCE(user_id, ?),
        name_snapshot = ?,
        description_snapshot = ?,
        ragflow_permission = ?,
        is_public = ?,
        document_count = ?,
        chunk_count = ?,
        ragflow_created_at = ?,
        ragflow_updated_at = ?,
        last_synced_at = ?,
        updated_at = ?
      WHERE ragflow_kb_id = ?
    `).run(
      ownerId,
      values.nameSnapshot,
      values.descriptionSnapshot,
      values.ragflowPermission,
      values.isPublic,
      values.documentCount,
      values.chunkCount,
      values.ragflowCreatedAt,
      values.ragflowUpdatedAt,
      values.lastSyncedAt,
      now,
      record.ragflowKbId,
    )
  } else {
    db.prepare(`
      INSERT INTO knowledge_bases (
        id,
        ragflow_kb_id,
        user_id,
        name_snapshot,
        description_snapshot,
        ragflow_permission,
        is_public,
        document_count,
        chunk_count,
        ragflow_created_at,
        ragflow_updated_at,
        last_synced_at,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      cryptoRandomUUID(),
      record.ragflowKbId,
      ownerId,
      values.nameSnapshot,
      values.descriptionSnapshot,
      values.ragflowPermission,
      values.isPublic,
      values.documentCount,
      values.chunkCount,
      values.ragflowCreatedAt,
      values.ragflowUpdatedAt,
      values.lastSyncedAt,
      now,
      now,
    )
  }

  return getKnowledgeBaseBinding(record.ragflowKbId)
}

export function bindKnowledgeBase(ragflowKbId, userId, nameSnapshot = '') {
  return upsertKnowledgeBaseRecord({
    ragflowKbId,
    userId,
    nameSnapshot,
  })
}

export function getKnowledgeBaseBinding(ragflowKbId) {
  return db.prepare(`
    SELECT kb.*, u.username, u.display_name
    FROM knowledge_bases kb
    LEFT JOIN users u ON u.id = kb.user_id
    WHERE kb.ragflow_kb_id = ?
  `).get(ragflowKbId)
}

export function listKnowledgeBaseBindings() {
  return db.prepare(`
    SELECT kb.*, u.username, u.display_name
    FROM knowledge_bases kb
    LEFT JOIN users u ON u.id = kb.user_id
    ORDER BY kb.is_public DESC, kb.updated_at DESC
  `).all()
}

export function deleteKnowledgeBaseBindings(ragflowKbIds) {
  if (!Array.isArray(ragflowKbIds) || ragflowKbIds.length === 0) return 0
  const stmt = db.prepare('DELETE FROM knowledge_bases WHERE ragflow_kb_id = ?')
  const tx = db.transaction((ids) => {
    let changes = 0
    for (const id of ids) {
      changes += stmt.run(id).changes
    }
    return changes
  })
  return tx(ragflowKbIds)
}

export function updateKnowledgeBaseVisibility(ragflowKbId, isPublic) {
  const now = Date.now()
  const result = db.prepare(`
    UPDATE knowledge_bases
    SET is_public = ?, updated_at = ?, last_synced_at = ?
    WHERE ragflow_kb_id = ?
  `).run(toDbBoolean(isPublic), now, now, ragflowKbId)
  if (result.changes === 0) return null
  return getKnowledgeBaseBinding(ragflowKbId)
}

export function syncKnowledgeBaseCatalog(records = []) {
  if (!Array.isArray(records) || records.length === 0) return []
  const tx = db.transaction((items) => items.map(item => upsertKnowledgeBaseRecord(item)).filter(Boolean))
  return tx(records)
}

export function getAgentTeamStats(userId) {
  const row = db.prepare('SELECT COUNT(*) as count, MIN(created_at) as earliest FROM agent_team WHERE created_by = ?').get(userId)
  return { count: row.count, earliest: row.earliest }
}

console.log('[Database] Initialized at:', dbPath)

export default db
