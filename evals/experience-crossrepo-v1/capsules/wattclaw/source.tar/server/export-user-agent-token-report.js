import 'dotenv/config'
import Database from 'better-sqlite3'
import { existsSync, mkdirSync, createWriteStream, writeFileSync } from 'fs'
import { dirname, resolve } from 'path'
import { fileURLToPath } from 'url'
import { OpenClawGateway } from './gateway.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const projectRoot = resolve(__dirname, '..')

function parseArgs(argv) {
  const options = {
    db: resolve(projectRoot, 'data/wizard.db'),
    output: resolve(projectRoot, 'data/wattclaw_user_agent_token_report.txt'),
    activeOnly: false,
    localOnly: false,
    gatewayLimit: 10000,
    timeoutMs: 180000,
    debugGateway: false,
  }

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index]
    const next = argv[index + 1]

    if (arg === '--db' && next) {
      options.db = resolve(process.cwd(), next)
      index += 1
    } else if (arg === '--output' && next) {
      options.output = resolve(process.cwd(), next)
      index += 1
    } else if (arg === '--gateway-limit' && next) {
      options.gatewayLimit = Math.max(1, Number.parseInt(next, 10) || options.gatewayLimit)
      index += 1
    } else if (arg === '--timeout-ms' && next) {
      options.timeoutMs = Math.max(1000, Number.parseInt(next, 10) || options.timeoutMs)
      index += 1
    } else if (arg === '--active-only') {
      options.activeOnly = true
    } else if (arg === '--local-only') {
      options.localOnly = true
    } else if (arg === '--debug-gateway') {
      options.debugGateway = true
    } else if (arg === '--help' || arg === '-h') {
      printHelp()
      process.exit(0)
    } else {
      throw new Error(`Unknown argument: ${arg}`)
    }
  }

  return options
}

function printHelp() {
  console.log(`Usage:
  node --env-file=.env server/export-user-agent-token-report.js [options]

Options:
  --db <path>             SQLite DB path. Default: data/wizard.db
  --output <path>         Output txt path. Default: data/wattclaw_user_agent_token_report.txt
  --active-only           Export only active users and active agents
  --local-only            Use only local SQLite token cache
  --gateway-limit <num>   Gateway sessions.usage limit. Default: 10000
  --timeout-ms <num>      Gateway connect/RPC timeout. Default: 180000
  --debug-gateway         Write Gateway response summary to output .debug.json
  -h, --help              Show this help
`)
}

function escapeCsv(value) {
  const text = value === null || value === undefined ? '' : String(value)
  const safeText = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text
  if (!/[",\n\r]/.test(safeText)) return safeText
  return `"${safeText.replaceAll('"', '""')}"`
}

function toNumber(value) {
  const numberValue = Number(value)
  return Number.isFinite(numberValue) ? numberValue : 0
}

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function summarizeKeys(value) {
  if (!value || typeof value !== 'object') return []
  return Object.keys(value).sort()
}

function sampleRows(rows, limit = 5) {
  if (!Array.isArray(rows)) return []
  return rows.slice(0, limit).map((row) => {
    const record = asRecord(row)
    const totals = asRecord(record.totals)
    return {
      keys: summarizeKeys(record),
      agentFields: {
        agentId: record.agentId ?? null,
        agent_id: record.agent_id ?? null,
        agent: record.agent ?? null,
        id: record.id ?? null,
        key: record.key ?? null,
        name: record.name ?? null,
      },
      tokenFields: {
        totalTokens: record.totalTokens ?? null,
        total: record.total ?? null,
        tokens: record.tokens ?? null,
        input: record.input ?? null,
        output: record.output ?? null,
        totalsKeys: summarizeKeys(totals),
        totals,
      },
      parsedTotal: tokenTotalFromUsage(record),
    }
  })
}

function writeGatewayDebug(options, gatewayUsage, indexes) {
  if (!options.debugGateway) return

  const sessions = Array.isArray(gatewayUsage?.sessions) ? gatewayUsage.sessions : []
  const byAgent = Array.isArray(gatewayUsage?.aggregates?.byAgent) ? gatewayUsage.aggregates.byAgent : []
  const knownAgentIds = new Set(indexes.agentOwnersByAgentId.keys())
  const byAgentMatches = byAgent.filter((row) => {
    const record = asRecord(row)
    const agentId = String(record.agentId || record.agent_id || record.agent || record.id || record.key || '')
    return knownAgentIds.has(agentId)
  }).length
  const sessionMatches = sessions.filter((session) => {
    const key = sessionKeyOf(session)
    const agentId = agentIdOf(session, key)
    return indexes.sessionOwnersByKey.has(key) || knownAgentIds.has(agentId)
  }).length

  const debugPath = `${options.output}.debug.json`
  writeFileSync(debugPath, JSON.stringify({
    topLevelKeys: summarizeKeys(gatewayUsage),
    totalsKeys: summarizeKeys(asRecord(gatewayUsage?.totals)),
    aggregatesKeys: summarizeKeys(asRecord(gatewayUsage?.aggregates)),
    sessionsCount: sessions.length,
    byAgentCount: byAgent.length,
    knownAgentIdCount: knownAgentIds.size,
    sessionMatches,
    byAgentMatches,
    sampleKnownAgentIds: Array.from(knownAgentIds).slice(0, 20),
    sampleSessions: sampleRows(sessions),
    sampleByAgent: sampleRows(byAgent),
  }, null, 2), 'utf8')
  console.log(`Gateway debug written to ${debugPath}`)
}

function getTableColumns(db, tableName) {
  return new Set(db.prepare(`PRAGMA table_info(${tableName})`).all().map((row) => row.name))
}

function selectColumn(columns, name, fallback) {
  return columns.has(name) ? name : `${fallback} AS ${name}`
}

function loadDbSnapshot(db, activeOnly) {
  const usersColumns = getTableColumns(db, 'users')
  const agentsColumns = getTableColumns(db, 'user_agents')
  const sessionsColumns = getTableColumns(db, 'user_sessions')
  const activeUserWhere = activeOnly && usersColumns.has('status') ? "WHERE status = 'active'" : ''
  const activeAgentWhere = activeOnly && agentsColumns.has('status') ? "WHERE status = 'active'" : ''

  const users = db.prepare(`
    SELECT id, username, ${selectColumn(usersColumns, 'display_name', "''")}, ${selectColumn(usersColumns, 'status', "'active'")}
    FROM users
    ${activeUserWhere}
  `).all()

  const agents = db.prepare(`
    SELECT
      id,
      user_id,
      ${selectColumn(agentsColumns, 'gateway_agent_id', 'NULL')},
      name,
      ${selectColumn(agentsColumns, 'workspace', "''")},
      ${selectColumn(agentsColumns, 'status', "'active'")}
    FROM user_agents
    ${activeAgentWhere}
  `).all()

  const sessionFields = [
    'id', 'user_id', 'session_key', 'agent_id',
    'token_input', 'token_output', 'token_cache_read', 'token_cache_write', 'token_total',
  ].map((name) => selectColumn(sessionsColumns, name, name.startsWith('token_') ? '0' : 'NULL'))

  const sessions = db.prepare(`SELECT ${sessionFields.join(', ')} FROM user_sessions`).all()
  return { users, agents, sessions }
}

function createIndexes(snapshot) {
  const usersById = new Map(snapshot.users.map((user) => [user.id, user]))
  const agentsByUser = new Map()
  const sessionOwnersByKey = new Map()
  const agentOwnersByAgentId = new Map()

  for (const agent of snapshot.agents) {
    if (!usersById.has(agent.user_id)) continue
    const rows = agentsByUser.get(agent.user_id) || []
    rows.push(agent)
    agentsByUser.set(agent.user_id, rows)

    for (const agentId of [agent.id, agent.gateway_agent_id].filter(Boolean)) {
      const owners = agentOwnersByAgentId.get(agentId) || []
      owners.push({ userId: agent.user_id, agent })
      agentOwnersByAgentId.set(agentId, owners)
    }
  }

  for (const session of snapshot.sessions) {
    if (session.session_key && usersById.has(session.user_id)) {
      const owners = sessionOwnersByKey.get(session.session_key) || []
      owners.push(session)
      sessionOwnersByKey.set(session.session_key, owners)
    }
  }

  return { usersById, agentsByUser, sessionOwnersByKey, agentOwnersByAgentId }
}

function tokenTotalFromLocalSession(session) {
  return toNumber(session.token_total)
    || toNumber(session.token_input)
    + toNumber(session.token_output)
    + toNumber(session.token_cache_read)
    + toNumber(session.token_cache_write)
}

function tokenTotalFromUsage(value) {
  const usage = asRecord(value)
  const totals = asRecord(usage.totals)
  const source = Object.keys(totals).length > 0 ? totals : usage
  const explicitTotal = toNumber(source.totalTokens ?? source.total ?? source.tokens)
  if (explicitTotal > 0) return explicitTotal

  return toNumber(source.input ?? source.totalInput ?? source.inputTokens)
    + toNumber(source.output ?? source.totalOutput ?? source.outputTokens)
    + toNumber(source.cacheRead ?? source.cache_read ?? source.cacheReadTokens)
    + toNumber(source.cacheWrite ?? source.cache_write ?? source.cacheWriteTokens)
}

function tokenTotalFromGatewaySession(session) {
  const directTotal = tokenTotalFromUsage(session)
  if (directTotal > 0) return directTotal
  return tokenTotalFromUsage(session.usage || session.totals || session.tokenUsage)
}

function sessionKeyOf(session) {
  return String(session.key || session.sessionKey || session.session_key || '')
}

function agentIdOf(session, sessionKey) {
  return String(session.agentId || session.agent_id || session.agent || sessionKey.match(/^agent:([^:]+):/)?.[1] || '')
}

function resolveAgentForUser(indexes, userId, agentId) {
  if (!agentId) return null
  const owners = indexes.agentOwnersByAgentId.get(agentId) || []
  return owners.find((owner) => owner.userId === userId)?.agent || null
}

const AGENT_TOTAL_KEY_SEPARATOR = '::agent-total::'

function agentTotalKey(userId, agentId) {
  return `${userId}${AGENT_TOTAL_KEY_SEPARATOR}${agentId}`
}

function addUsage(totals, userId, agent, amount) {
  if (!userId || amount <= 0) return
  totals.user.set(userId, (totals.user.get(userId) || 0) + amount)
  if (!agent) return
  const key = agentTotalKey(userId, agent.id)
  totals.agent.set(key, (totals.agent.get(key) || 0) + amount)
}

function aggregateLocalUsage(snapshot, indexes) {
  const totals = { user: new Map(), agent: new Map(), unmappedCount: 0 }
  for (const session of snapshot.sessions) {
    const amount = tokenTotalFromLocalSession(session)
    const agent = resolveAgentForUser(indexes, session.user_id, session.agent_id)
    addUsage(totals, session.user_id, agent, amount)
  }
  return totals
}

function tokenTotalFromAggregate(value) {
  return tokenTotalFromUsage(value)
}

function aggregateGatewayPrecomputedUsage(result, indexes) {
  const totals = { user: new Map(), agent: new Map(), unmappedCount: 0 }
  const byAgent = Array.isArray(result?.aggregates?.byAgent) ? result.aggregates.byAgent : []

  for (const row of byAgent) {
    const record = asRecord(row)
    const agentId = String(record.agentId || record.agent || record.id || record.key || '')
    const amount = tokenTotalFromAggregate(record)
    const owners = indexes.agentOwnersByAgentId.get(agentId) || []

    if (owners.length === 0) {
      totals.unmappedCount += 1
      continue
    }

    for (const owner of owners) {
      addUsage(totals, owner.userId, owner.agent, amount)
    }
  }

  return totals
}

function aggregateGatewayUsage(gatewaySessions, indexes) {
  const totals = { user: new Map(), agent: new Map(), unmappedCount: 0 }
  for (const session of gatewaySessions) {
    const key = sessionKeyOf(session)
    const agentId = agentIdOf(session, key)
    const amount = tokenTotalFromGatewaySession(session)
    const ownedSessions = indexes.sessionOwnersByKey.get(key) || []

    if (ownedSessions.length > 0) {
      for (const ownedSession of ownedSessions) {
        const agent = resolveAgentForUser(indexes, ownedSession.user_id, ownedSession.agent_id || agentId)
        addUsage(totals, ownedSession.user_id, agent, amount)
      }
      continue
    }

    const owners = indexes.agentOwnersByAgentId.get(agentId) || []
    if (owners.length === 0) {
      totals.unmappedCount += 1
      continue
    }

    for (const owner of owners) {
      addUsage(totals, owner.userId, owner.agent, amount)
    }
  }
  return totals
}

function buildReportRows(snapshot, indexes, totals, source) {
  const rows = []
  for (const user of snapshot.users) {
    const agents = indexes.agentsByUser.get(user.id) || [null]
    for (const agent of agents) {
      rows.push({
        user_name: user.username,
        display_name: user.display_name || '',
        agent_name: agent?.name || '',
        agent_id: agent?.gateway_agent_id || agent?.id || '',
        workspace: agent?.workspace || '',
        agent_token_total: agent ? totals.agent.get(agentTotalKey(user.id, agent.id)) || 0 : 0,
        user_token_total: totals.user.get(user.id) || 0,
        source,
      })
    }
  }
  rows.sort((a, b) => a.user_name.localeCompare(b.user_name) || a.agent_name.localeCompare(b.agent_name))
  return rows
}

function writeCsv(filePath, rows) {
  mkdirSync(dirname(filePath), { recursive: true })
  const stream = createWriteStream(filePath, { encoding: 'utf8' })
  stream.write('user_name,display_name,agent_name,agent_id,workspace,agent_token_total,user_token_total,source\n')

  for (const row of rows) {
    stream.write([
      row.user_name,
      row.display_name,
      row.agent_name,
      row.agent_id,
      row.workspace,
      row.agent_token_total,
      row.user_token_total,
      row.source,
    ].map(escapeCsv).join(','))
    stream.write('\n')
  }

  stream.end()
  return new Promise((resolveWrite, rejectWrite) => {
    stream.on('finish', resolveWrite)
    stream.on('error', rejectWrite)
  })
}

function waitForGateway(gateway, timeoutMs) {
  return new Promise((resolveWait, rejectWait) => {
    const timer = setTimeout(() => rejectWait(new Error('Gateway connect timeout')), timeoutMs)
    gateway.once('connected', () => {
      clearTimeout(timer)
      resolveWait()
    })
    gateway.once('error', (error) => {
      clearTimeout(timer)
      rejectWait(error)
    })
    gateway.connect().catch((error) => {
      clearTimeout(timer)
      rejectWait(error)
    })
  })
}

function closeGateway(gateway) {
  gateway.clearTimers?.()
  if (gateway.ws) {
    gateway.ws.removeAllListeners('close')
    gateway.ws.close()
    gateway.ws = null
  }
  gateway.isConnected = false
}

async function fetchGatewayUsage(options) {
  const gateway = new OpenClawGateway(
    process.env.OPENCLAW_WS_URL || 'ws://localhost:18789',
    process.env.OPENCLAW_AUTH_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '',
    process.env.OPENCLAW_AUTH_PASSWORD || process.env.AUTH_PASSWORD || '',
    process.env.LOG_LEVEL || 'INFO',
  )

  try {
    await waitForGateway(gateway, options.timeoutMs)
    return await gateway.call('sessions.usage', { limit: options.gatewayLimit }, options.timeoutMs)
  } finally {
    closeGateway(gateway)
  }
}

async function main() {
  const options = parseArgs(process.argv.slice(2))
  if (!existsSync(options.db)) throw new Error(`Database not found: ${options.db}`)

  const db = new Database(options.db, { readonly: true, fileMustExist: true })
  try {
    const snapshot = loadDbSnapshot(db, options.activeOnly)
    const indexes = createIndexes(snapshot)
    const source = options.localOnly ? 'local' : 'gateway'
    const gatewayUsage = options.localOnly ? null : await fetchGatewayUsage(options)
    const gatewaySessions = Array.isArray(gatewayUsage?.sessions) ? gatewayUsage.sessions : []
    if (!options.localOnly) writeGatewayDebug(options, gatewayUsage, indexes)
    const totals = options.localOnly
      ? aggregateLocalUsage(snapshot, indexes)
      : gatewaySessions.length > 0
        ? aggregateGatewayUsage(gatewaySessions, indexes)
        : aggregateGatewayPrecomputedUsage(gatewayUsage, indexes)
    const rows = buildReportRows(snapshot, indexes, totals, source)

    await writeCsv(options.output, rows)
    console.log(`Exported ${rows.length} rows to ${options.output}`)
    if (totals.unmappedCount) console.log(`Unmapped gateway usage rows: ${totals.unmappedCount}`)
    if (!options.localOnly && gatewaySessions.length >= options.gatewayLimit) {
      console.log(`Warning: gateway returned ${gatewaySessions.length} sessions, equal to --gateway-limit. Increase --gateway-limit to avoid truncation.`)
    }
  } finally {
    db.close()
  }
}

main().catch((error) => {
  console.error(`[export-user-agent-token-report] ${error.message}`)
  process.exit(1)
})
