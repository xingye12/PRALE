// Agent Team (数字员工) routes — backed by user_agents table
import { authMiddleware } from '../core/auth.js'
import {
  getDigitalEmployees, getAllDigitalEmployees, getDigitalEmployeeByAgentId,
  updateUserAgentMeta, trackAgentForUser, removeAgentForUser,
  getChannelsByAgentId, removeChannelsByAgentId,
  getHotTemplateIds,
} from '../user-manager.js'
import { configQueueExecute } from '../core/config-queue.js'
import { gatewayAdminRpc, gatewayHttpGet } from '../core/gateway-client.js'
import { getAgentUsage } from '../core/session-usage-cache.js'
import { gateway, envConfig } from '../core/index.js'
import { removeChannelFromGateway } from './channels.js'
import { writeRemoteFile, deleteRemoteFile } from '../gateway-file-transfer.js'
import db from '../database.js'

const AGENT_TEAM_LIMIT = 10
const AGENT_TEAM_LIMIT_REACHED = 'AGENT_TEAM_LIMIT_REACHED'

function getDigitalEmployeeCount(userId) {
  const row = db.prepare(`
    SELECT COUNT(*) AS count
    FROM user_agents
    WHERE user_id = ?
      AND status = 'active'
      AND category IS NOT NULL
  `).get(userId)
  return Number(row?.count || 0)
}

function sendAgentTeamLimitReached(res) {
  return res.status(409).json({
    ok: false,
    code: AGENT_TEAM_LIMIT_REACHED,
    error: '每个用户最多可以创建 10 个数字员工',
  })
}

function canCreateDigitalEmployee(userId) {
  return getDigitalEmployeeCount(userId) < AGENT_TEAM_LIMIT
}

function isAgentAlreadyMissing(error) {
  const message = String(error || '').toLowerCase()
  return message.includes('not found')
    || message.includes('does not exist')
    || message.includes('no such agent')
    || message.includes('agent not found')
}

function sanitizeWorkspaceSegment(value, fallback) {
  const sanitized = String(value || '')
    .trim()
    .replace(/[\\/:*?"<>|\x00-\x1F]/g, '-')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
  return sanitized || fallback
}

function normalizeWorkspaceForCurrentUser(workspace, currentUser) {
  if (typeof workspace !== 'string' || !workspace.trim() || workspace !== workspace.trim()) {
    return null
  }
  if (workspace.includes('..') || workspace.includes('\\')) {
    return null
  }

  const displayName = sanitizeWorkspaceSegment(
    currentUser.displayName || currentUser.display_name || currentUser.username,
    'user'
  )
  const userName = sanitizeWorkspaceSegment(currentUser.username, 'user')
  const userSegment = `${displayName}-${userName}`
  const tildePrefix = `~/.wattclaw/${userSegment}/`
  const absPrefix = `/home/wattman/.wattclaw/${userSegment}/`
  return workspace.startsWith(tildePrefix) || workspace.startsWith(absPrefix) ? workspace : null
}

export function createAgentTeamRoutes(app) {
  app.get('/api/agent-team/list', authMiddleware, (req, res) => {
    const list = req.currentUser.role === 'admin'
      ? getAllDigitalEmployees()
      : getDigitalEmployees(req.currentUser.id)
    res.json({ ok: true, list })
  })

  app.get('/api/agent-team/stats', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const isAdmin = req.currentUser.role === 'admin'

      const employees = isAdmin ? getAllDigitalEmployees() : getDigitalEmployees(userId)
      const agentIds = new Set(employees.map(e => e.gateway_agent_id).filter(Boolean))
      if (agentIds.size === 0) {
        return res.json({ ok: true, stats: {} })
      }

      // Use local cached usage data instead of calling Gateway
      const statsMap = {}
      for (const agentId of agentIds) {
        const agentUsage = getAgentUsage(agentId)
        let totalMessages = 0
        let totalTasks = 0

        for (const usage of agentUsage) {
          totalMessages += (usage.msgUser || 0) + (usage.msgAssistant || 0)
          totalTasks += (usage.msgToolCalls || 0)
        }

        statsMap[agentId] = { messages: totalMessages, tasks: totalTasks }
      }

      console.log(`[UsageCache] agent-team stats: ${agentIds.size} agents queried, ${Object.values(statsMap).reduce((s, v) => s + v.messages, 0)} total msgs`)
      res.json({ ok: true, stats: statsMap })
    } catch (err) {
      console.error('[AgentStats] batch error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.get('/api/agent-team/create-limit', authMiddleware, (req, res) => {
    const count = getDigitalEmployeeCount(req.currentUser.id)
    res.json({
      ok: true,
      limit: AGENT_TEAM_LIMIT,
      count,
      remaining: Math.max(AGENT_TEAM_LIMIT - count, 0),
      canCreate: count < AGENT_TEAM_LIMIT,
    })
  })

  app.get('/api/agent-team/hot-templates', authMiddleware, (req, res) => {
    try {
      // 全局热门模板：公共预设的创建量聚合，跨用户但不返回个体数据。
      const limit = Math.min(Math.max(Number(req.query.limit) || 3, 1), 12)
      const list = getHotTemplateIds(limit)
      res.json({ ok: true, list })
    } catch (err) {
      console.error('[AgentTeam] hot-templates error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.get('/api/agent-team/:id', authMiddleware, (req, res) => {
    const userId = req.currentUser.role === 'admin' ? null : req.currentUser.id
    const agent = getDigitalEmployeeByAgentId(req.params.id, userId)
    if (!agent) return res.status(404).json({ ok: false, error: 'Agent not found' })
    res.json({ ok: true, agent })
  })

  app.put('/api/agent-team/:id', authMiddleware, async (req, res) => {
    const userId = req.currentUser.role === 'admin' ? null : req.currentUser.id
    const existing = getDigitalEmployeeByAgentId(req.params.id, userId)
    if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })

    const { model } = req.body || {}

    // model 是影响 agent 行为的关键字段,Gateway 是其真相源:先同步 Gateway,成功后才落 DB。
    // 原 fire-and-forget(.catch 不 await)会导致 DB 新 model / Gateway 旧 model 静默不一致——
    // 前端收到成功,但 agent 对话仍用旧 model。改为 await + 失败返回错误(不落库,原子更新)。
    if (model !== undefined && model !== existing.model) {
      if (!gateway.isConnected) {
        return res.status(503).json({ ok: false, error: 'Gateway 未连接,无法同步模型变更' })
      }
      try {
        await gateway.call('agents.update', { agentId: req.params.id, model })
      } catch (err) {
        console.error(`[AgentTeam] agents.update model sync failed for ${req.params.id}:`, err.message)
        return res.status(502).json({ ok: false, error: `模型同步到 Gateway 失败: ${err.message}` })
      }
    }

    // Gateway 同步成功(或 model 未变)后,落 DB(含 model + 其他展示字段)
    updateUserAgentMeta(req.params.id, req.body)

    const updated = getDigitalEmployeeByAgentId(req.params.id, userId)
    res.json({ ok: true, agent: updated })
  })

  app.post('/api/agent-team/create', authMiddleware, (req, res) => {
    const { name, description, avatar, model, category, templateId, gatewayAgentId, workspace } = req.body || {}
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ ok: false, error: 'Name is required' })
    }
    if (!gatewayAgentId) {
      return res.status(400).json({ ok: false, error: 'gatewayAgentId is required' })
    }
    const normalizedWorkspace = normalizeWorkspaceForCurrentUser(workspace, req.currentUser)
    if (!normalizedWorkspace) {
      return res.status(400).json({ ok: false, error: 'Invalid workspace' })
    }
    if (!canCreateDigitalEmployee(req.currentUser.id)) {
      return sendAgentTeamLimitReached(res)
    }
    trackAgentForUser(req.currentUser.id, gatewayAgentId, name, {
      category,
      templateId,
      description,
      avatar,
      model,
      workspace: normalizedWorkspace,
    })
    const agent = getDigitalEmployeeByAgentId(gatewayAgentId, req.currentUser.id)
    res.json({ ok: true, agent })
  })

  let _migrateBootstrapRunning = false
  app.post('/api/agent-team/migrate-bootstrap', authMiddleware, async (req, res) => {
    if (req.currentUser.role !== 'admin') return res.status(403).json({ ok: false, error: 'Admin only' })
    if (_migrateBootstrapRunning) return res.status(409).json({ ok: false, error: 'Migration already in progress' })
    _migrateBootstrapRunning = true
    try {
      const _rpcResult = await gatewayAdminRpc('agents.list')
      if (!_rpcResult.ok) throw new Error(_rpcResult.error)
      const agentsResult = _rpcResult.payload
      const agents = agentsResult?.agents || agentsResult?.list || agentsResult || []
      const agentsList = Array.isArray(agents) ? agents : Object.values(agents)

      let migrated = 0
      let skipped = 0
      let failed = 0
      const details = []

      for (const agent of agentsList) {
        const agentId = agent.id || agent.agentId || agent.name
        if (!agentId) continue
        try {
          const bsResult = await gateway.call('agents.files.get', { agentId, name: 'BOOTSTRAP.md' })
          const bootstrapContent = bsResult?.file?.content || bsResult?.content || ''
          if (!bootstrapContent.trim()) { skipped++; continue }
          const userResult = await gateway.call('agents.files.get', { agentId, name: 'USER.md' })
          const userContent = userResult?.file?.content || userResult?.content || ''
          const workspaceRulesMatch = bootstrapContent.match(/## 文件路径规则[\s\S]*$/)
          const workspaceRules = workspaceRulesMatch ? workspaceRulesMatch[0].trim() : ''
          if (workspaceRules && !userContent.includes('## 文件路径规则')) {
            const parts = []
            if (userContent.trim()) parts.push(userContent.trim())
            parts.push(workspaceRules)
            await gateway.call('agents.files.set', { agentId, name: 'USER.md', content: parts.join('\n\n---\n\n') })
          }
          const workspaceDir = agent.workspace
          if (workspaceDir) {
            const statePath = `${workspaceDir}/.openclaw/workspace-state.json`
            const state = { version: 1, setupCompletedAt: new Date().toISOString() }
            await Promise.all([
              writeRemoteFile(statePath, JSON.stringify(state, null, 2) + '\n').catch(() => {}),
              deleteRemoteFile(`${workspaceDir}/BOOTSTRAP.md`).catch(() => {}),
            ])
          }
          migrated++
          details.push({ agentId, status: 'migrated' })
        } catch (err) {
          failed++
          details.push({ agentId, status: 'error', error: err.message })
        }
      }
      console.log(`[MigrateBootstrap] migrated=${migrated} skipped=${skipped} failed=${failed}`)
      res.json({ ok: true, migrated, skipped, failed, details })
    } catch (err) {
      console.error('[MigrateBootstrap] Error:', err)
      res.status(500).json({ ok: false, error: err.message })
    } finally {
      _migrateBootstrapRunning = false
    }
  })

  app.post('/api/agent-team/complete-bootstrap', authMiddleware, async (req, res) => {
    const { workspacePath } = req.body || {}
    if (!workspacePath || typeof workspacePath !== 'string') {
      return res.status(400).json({ ok: false, error: 'workspacePath required' })
    }
    const resolvedPath = workspacePath.startsWith('~')
      ? `/home/${envConfig.GATEWAY_SSH_USER || 'wattman'}${workspacePath.slice(1)}`
      : workspacePath
    try {
      const statePath = `${resolvedPath}/.openclaw/workspace-state.json`
      const state = { version: 1, setupCompletedAt: new Date().toISOString() }
      const [stateOk, deleteOk] = await Promise.all([
        writeRemoteFile(statePath, JSON.stringify(state, null, 2) + '\n'),
        deleteRemoteFile(`${resolvedPath}/BOOTSTRAP.md`),
      ])
      console.log(`[CompleteBootstrap] ${resolvedPath} state=${stateOk} delete=${deleteOk}`)
      res.json({ ok: true, stateWritten: stateOk, bootstrapDeleted: deleteOk })
    } catch (err) {
      console.error('[CompleteBootstrap] Error:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/agent-team/repair-bootstrap', authMiddleware, async (req, res) => {
    if (req.currentUser.role !== 'admin') {
      return res.status(403).json({ ok: false, error: 'Admin only' })
    }
    try {
      const _rpcResult2 = await gatewayAdminRpc('agents.list')
      if (!_rpcResult2.ok) throw new Error(_rpcResult2.error)
      const agents = _rpcResult2.payload
      const agentList = agents?.agents || agents?.list || (Array.isArray(agents) ? agents : [])
      const results = []
      for (const agent of agentList) {
        const agentId = agent.name || agent.id || agent.agentId
        const workspace = agent.workspace || ''
        if (!agentId || !workspace) continue
        try {
          const resolvedPath = workspace.startsWith('~')
            ? `/home/${envConfig.GATEWAY_SSH_USER || 'wattman'}${workspace.slice(1)}`
            : workspace
          const statePath = `${resolvedPath}/.openclaw/workspace-state.json`
          const state = { version: 1, setupCompletedAt: new Date().toISOString() }
          await Promise.all([
            writeRemoteFile(statePath, JSON.stringify(state, null, 2) + '\n'),
            deleteRemoteFile(`${resolvedPath}/BOOTSTRAP.md`),
          ])
          results.push({ agentId, name: agent.emoji || agentId, status: 'ok' })
        } catch (err) {
          results.push({ agentId, status: 'error', error: err.message })
        }
      }
      console.log(`[RepairBootstrap] Processed ${results.length} agents`)
      res.json({ ok: true, total: results.length, results })
    } catch (err) {
      console.error('[RepairBootstrap] Error:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.delete('/api/agent-team/:id', authMiddleware, async (req, res) => {
    try {
      const agentId = req.params.id
      const userId = req.currentUser.role === 'admin' ? null : req.currentUser.id
      const existing = getDigitalEmployeeByAgentId(agentId, userId)
      if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })

      const deleteResult = await gatewayAdminRpc('agents.delete', { agentId })
      if (!deleteResult.ok && !isAgentAlreadyMissing(deleteResult.error)) {
        console.error(`[AgentTeam] agents.delete failed for ${agentId}:`, deleteResult.error)
        return res.status(502).json({ ok: false, error: `Gateway agent delete failed: ${deleteResult.error}` })
      }
      if (!deleteResult.ok) {
        console.warn(`[AgentTeam] Gateway agent ${agentId} already missing, cleaning local records`)
      }

      const channels = getChannelsByAgentId(agentId)
      for (const channel of channels) {
        await removeChannelFromGateway(channel)
      }
      removeChannelsByAgentId(agentId)
      removeAgentForUser(existing.user_id, agentId)

      try {
        const cleaned = await configQueueExecute((sourceConfig) => {
          const feishuAccounts = sourceConfig.channels?.feishu?.accounts
          if (!feishuAccounts || !feishuAccounts[agentId]) return null
          const accountsCopy = { ...feishuAccounts }
          delete accountsCopy[agentId]
          const bindings = Array.isArray(sourceConfig.bindings)
            ? sourceConfig.bindings.filter(b => !(b.match?.channel === 'feishu' && b.match?.accountId === agentId))
            : []
          return {
            ...sourceConfig,
            channels: { ...sourceConfig.channels, feishu: { ...sourceConfig.channels.feishu, accounts: accountsCopy } },
            bindings,
          }
        }, `agent-delete-residual-${agentId}`, 'config.set')
        if (cleaned !== null) {
          console.log(`[AgentTeam] cleaned residual feishu config for ${agentId}`)
        }
      } catch (residualErr) {
        console.error('[AgentTeam] residual check failed:', residualErr.message)
      }

      res.json({ ok: true, gatewayDeleted: deleteResult.ok })
    } catch (err) {
      console.error('[AgentTeam] delete failed:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.get('/api/agent-team/:id/files', authMiddleware, async (req, res) => {
    try {
      const agentId = req.params.id
      const userId = req.currentUser.role === 'admin' ? null : req.currentUser.id
      const existing = getDigitalEmployeeByAgentId(agentId, userId)
      if (!existing) return res.status(404).json({ ok: false, error: 'Agent not found' })

      const fileNames = ['SOUL.md', 'AGENTS.md', 'IDENTITY.md', 'USER.md', 'TOOLS.md', 'MEMORY.md']
      const results = await Promise.allSettled(
        fileNames.map(name => gateway.call('agents.files.get', { agentId, name }))
      )

      const files = {}
      for (let i = 0; i < fileNames.length; i++) {
        const r = results[i]
        if (r.status === 'fulfilled' && r.value) {
          const content = r.value?.file?.content || r.value?.content || ''
          if (content) files[fileNames[i]] = content
        }
      }
      res.json({ ok: true, files })
    } catch (err) {
      console.error('[AgentTeam] Batch files error:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.get('/api/agent-team/:id/stats', authMiddleware, async (req, res) => {
    try {
      const agentId = req.params.id
      const userId = req.currentUser.id
      const isAdmin = req.currentUser.role === 'admin'

      const agent = getDigitalEmployeeByAgentId(agentId, isAdmin ? undefined : userId)
      if (!agent && !isAdmin) {
        return res.status(403).json({ ok: false, error: 'Not your agent' })
      }
      if (!agent) {
        return res.status(404).json({ ok: false, error: 'Agent not found' })
      }

      if (!gateway.isConnected) {
        return res.json({ ok: true, stats: { messages: 0, tasks: 0 } })
      }

      // Read session keys from local SQLite instead of polling Gateway
      const agentSessions = isAdmin
        ? db.prepare("SELECT session_key FROM user_sessions WHERE agent_id = ? ORDER BY updated_at DESC LIMIT 20").all(agentId)
        : db.prepare("SELECT session_key FROM user_sessions WHERE user_id = ? AND agent_id = ? ORDER BY updated_at DESC LIMIT 20").all(userId, agentId)

      let totalMessages = 0
      let totalTasks = 0

      const recentSessions = agentSessions.slice(0, 20)
      for (const session of recentSessions) {
        try {
          const sessionKey = session.session_key
          if (!sessionKey) continue

          const httpResult = await gatewayHttpGet(
            `/sessions/${encodeURIComponent(sessionKey)}/history`,
            { limit: 50 }
          )
          if (!httpResult.ok) continue

          let messages
          const data = httpResult.data
          if (Array.isArray(data)) {
            messages = data
          } else if (data && typeof data === 'object') {
            messages = data.messages || data.history || data.items || data.payload || []
            if (!Array.isArray(messages)) messages = []
          } else {
            messages = []
          }

          for (const msg of messages) {
            const role = msg.role || ''
            if (role === 'user' || role === 'assistant') {
              totalMessages++
            }
            if (role === 'assistant') {
              const content = msg.content
              if (typeof content === 'string' && content.includes('"tool_use"')) {
                totalTasks++
              } else if (Array.isArray(content)) {
                if (content.some((c) =>
                  c.type === 'tool_use' || c.type === 'function_call' || c.type === 'tool_call'
                )) totalTasks++
              }
            }
          }
        } catch {
          // Skip sessions with errors
        }
      }

      res.json({ ok: true, stats: { messages: totalMessages, tasks: totalTasks } })
    } catch (err) {
      console.error('[AgentStats] error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })
}
