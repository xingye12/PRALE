// Auth routes: login, register, logout, profile, password
import { authMiddleware } from '../core/auth.js'
import {
  authenticateUser, createAuthToken, deleteToken, validateToken,
  createUser, updateUser,
} from '../user-manager.js'

export function createAuthRoutes(app) {
  app.get('/api/auth/config', (_req, res) => {
    res.json({ enabled: true })
  })

  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body
    if (!username || !password) {
      return res.status(400).json({ ok: false, error: 'Username and password required' })
    }
    const user = authenticateUser(username, password)
    if (!user) {
      return res.status(401).json({ ok: false, error: 'Invalid credentials' })
    }
    const { token, expiresAt } = createAuthToken(user.id, req.headers['user-agent'], req.ip)
    res.json({ ok: true, token, user, expiresAt })
  })

  app.post('/api/auth/register', (req, res) => {
    const { username, password, displayName, email, inviteCode } = req.body
    if (!username || !password) {
      return res.status(400).json({ ok: false, error: 'Username and password required' })
    }
    if (username.length < 3) {
      return res.status(400).json({ ok: false, error: 'Username must be at least 3 characters' })
    }
    if (password.length < 6) {
      return res.status(400).json({ ok: false, error: 'Password must be at least 6 characters' })
    }
    try {
      const user = createUser({
        username, password, role: 'user',
        displayName: displayName || username, email: email || null,
      })
      const { token, expiresAt } = createAuthToken(user.id, req.headers['user-agent'], req.ip)
      res.json({ ok: true, token, user, expiresAt })
    } catch (e) {
      res.status(409).json({ ok: false, error: e.message })
    }
  })

  app.post('/api/auth/logout', (req, res) => {
    const token = req.headers.authorization?.replace('Bearer ', '')
    if (token) deleteToken(token)
    res.json({ ok: true })
  })

  app.get('/api/auth/check', authMiddleware, (req, res) => {
    res.json({ ok: true, authenticated: true, user: req.currentUser })
  })

  app.put('/api/auth/profile', authMiddleware, (req, res) => {
    const { displayName, email, avatar } = req.body
    const user = updateUser(req.currentUser.id, { displayName, email, avatar })
    res.json({ ok: true, user })
  })

  app.put('/api/auth/password', authMiddleware, (req, res) => {
    const { currentPassword, newPassword } = req.body
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ ok: false, error: 'Current and new password required' })
    }
    const authed = authenticateUser(req.currentUser.username, currentPassword)
    if (!authed) {
      return res.status(401).json({ ok: false, error: 'Current password is incorrect' })
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ ok: false, error: 'Password must be at least 6 characters' })
    }
    const user = updateUser(req.currentUser.id, { password: newPassword })
    res.json({ ok: true, user })
  })
}
