// Channel routes and Gateway sync helpers
import { authMiddleware } from '../core/auth.js'
import {
  getUserChannels, createUserChannel, updateUserChannel, deleteUserChannel,
  getChannelsByAgentId, getUserOwnedAgentIds,
} from '../user-manager.js'
import { configQueueExecute } from '../core/config-queue.js'
import { gatewayAdminRpc } from '../core/gateway-client.js'

const FEISHU_POLICY_VALUES = new Set(['open', 'pairing', 'allowlist'])

function normalizeFeishuPolicy(value, fallback = 'open') {
  return FEISHU_POLICY_VALUES.has(value) ? value : fallback
}

function sanitizeFeishuAccountConfig(config) {
  const { footer, dmPolicy, groupPolicy, ...rest } = config || {}
  return {
    ...rest,
    dmPolicy: normalizeFeishuPolicy(dmPolicy),
    groupPolicy: normalizeFeishuPolicy(groupPolicy),
  }
}

export async function syncChannelToGateway(channel) {
  const channelType = channel.channel_type
  const agentId = channel.agent_id
  const channelCfg = typeof channel.config === 'string' ? JSON.parse(channel.config) : channel.config

  if (!agentId) {
    return { synced: false, error: 'No agent bound' }
  }

  try {
    await configQueueExecute((sourceConfig) => {
      const existingBindings = Array.isArray(sourceConfig.bindings) ? [...sourceConfig.bindings] : []
      const existingChannels = { ...sourceConfig.channels }
      const accountId = agentId

      const channelConfig = { ...(existingChannels[channelType] || { enabled: true }) }
      if (!channelConfig.accounts) channelConfig.accounts = {}
      if (channelType === 'feishu') {
        channelConfig.streaming = true
        channelConfig.blockStreaming = true
      }

      const accountConfig = channelType === 'feishu'
        ? sanitizeFeishuAccountConfig(channelCfg)
        : channelCfg

      channelConfig.accounts[accountId] = {
        ...accountConfig,
        enabled: true,
        dmPolicy: channelType === 'feishu' ? normalizeFeishuPolicy(accountConfig.dmPolicy) : 'open',
        groupPolicy: channelType === 'feishu' ? normalizeFeishuPolicy(accountConfig.groupPolicy) : 'open',
        connectionMode: accountConfig.connectionMode || 'websocket',
      }

      if (!channelConfig.enabled) channelConfig.enabled = true

      const bindingIndex = existingBindings.findIndex(
        b => b.match && b.match.channel === channelType && b.match.accountId === accountId
      )
      const newBinding = { agentId, match: { channel: channelType, accountId } }

      if (bindingIndex >= 0) {
        existingBindings[bindingIndex] = newBinding
      } else {
        existingBindings.push(newBinding)
      }

      return {
        ...sourceConfig,
        channels: { ...existingChannels, [channelType]: channelConfig },
        bindings: existingBindings,
      }
    }, `channel-sync-${channelType}/${agentId}`)

    // Explicitly start the channel after config is applied
    try {
      const startResult = await gatewayAdminRpc('channels.start', {
        channel: channelType,
        accountId: agentId,
      })
      if (startResult.ok) {
        console.log(`[ChannelSync] started ${channelType}/${agentId}`)
      } else {
        console.warn(`[ChannelSync] start ${channelType}/${agentId} returned:`, startResult.error)
      }
    } catch (startErr) {
      console.warn(`[ChannelSync] start ${channelType}/${agentId} failed:`, startErr.message)
    }

    return { synced: true }
  } catch (err) {
    console.error('[ChannelSync] failed:', err.message)
    return { synced: false, error: translateGatewayError(err.message) }
  }
}

export function translateGatewayError(msg) {
  if (!msg) return '未知错误'
  if (msg.includes('rate limit')) {
    const match = msg.match(/retry after (\d+)s/)
    return match ? `操作过于频繁，请 ${match[1]} 秒后重试` : '操作过于频繁，请稍后重试'
  }
  if (msg.includes('No agent bound')) return '未绑定 Agent'
  if (msg.includes('Gateway not connected')) return 'Gateway 未连接'
  if (msg.includes('timeout')) return '请求超时，请稍后重试'
  if (msg.includes('ECONNREFUSED')) return '无法连接到 Gateway'
  return msg
}

export async function removeChannelFromGateway(channel) {
  const channelType = channel.channel_type
  const agentId = channel.agent_id
  if (!agentId) return

  try {
    await configQueueExecute((sourceConfig) => {
      const existingChannels = { ...sourceConfig.channels }
      const channelConfig = existingChannels[channelType] ? { ...existingChannels[channelType] } : null

      if (channelConfig && channelConfig.accounts && channelConfig.accounts[agentId]) {
        const accounts = { ...channelConfig.accounts }
        delete accounts[agentId]
        channelConfig.accounts = accounts
      }

      const existingBindings = Array.isArray(sourceConfig.bindings)
        ? sourceConfig.bindings.filter(
            b => !(b.match && b.match.channel === channelType && b.match.accountId === agentId)
          )
        : []

      return {
        ...sourceConfig,
        channels: { ...existingChannels, [channelType]: channelConfig || {} },
        bindings: existingBindings,
      }
    }, `channel-remove-${channelType}/${agentId}`, 'config.set')
    console.log(`[ChannelSync] removed ${channelType}/${agentId} from gateway config`)
  } catch (err) {
    console.error(`[ChannelSync] remove ${channelType}/${agentId} failed: ${err.message}`)
  }
}

export async function logoutChannelFromGateway(channel) {
  try {
    const rpcResult = await gatewayAdminRpc('channels.logout', {
      channel: channel.channel_type,
      accountId: channel.agent_id,
    })
    if (!rpcResult.ok) {
      console.error('[ChannelSync] logout failed:', rpcResult.error)
      return
    }
    console.log(`[ChannelSync] logged out ${channel.channel_type}/${channel.agent_id}`)
  } catch (err) {
    console.error('[ChannelSync] logout failed:', err.message)
  }
}

export function createChannelRoutes(app) {
  app.get('/api/user/channels', authMiddleware, (req, res) => {
    const channels = getUserChannels(req.currentUser.id)
    res.json({ ok: true, channels })
  })

  app.post('/api/user/channels', authMiddleware, async (req, res) => {
    try {
      const { agentId } = req.body
      if (!agentId) {
        return res.status(400).json({ ok: false, error: '请选择要绑定的 Agent' })
      }
      const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
      if (!ownedIds.includes(agentId)) {
        return res.status(403).json({ ok: false, error: '无权操作该 Agent' })
      }
      const channel = createUserChannel(req.currentUser.id, req.body)

      const syncResult = await syncChannelToGateway(channel)
      if (syncResult.synced) {
        updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
        channel.status = 'active'
        channel.last_sync_at = Date.now()
      } else {
        updateUserChannel(channel.id, { status: 'error', errorMessage: syncResult.error })
        channel.status = 'error'
        channel.error_message = syncResult.error
      }

      res.json({ ok: true, channel })
    } catch (err) {
      console.error('[Channels] create failed:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.put('/api/user/channels/:id', authMiddleware, async (req, res) => {
    try {
      const owned = getUserChannels(req.currentUser.id)
      if (!owned.find(c => c.id === req.params.id)) {
        return res.status(403).json({ ok: false, error: '无权操作该频道' })
      }

      const { agentId } = req.body
      if (agentId !== undefined) {
        const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
        if (!ownedIds.includes(agentId)) {
          return res.status(403).json({ ok: false, error: '无权操作该 Agent' })
        }
      }

      const channel = updateUserChannel(req.params.id, req.body)
      if (!channel) {
        return res.status(404).json({ ok: false, error: 'Channel not found' })
      }

      const syncResult = await syncChannelToGateway(channel)
      if (syncResult.synced) {
        updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
        channel.status = 'active'
        channel.last_sync_at = Date.now()
      } else {
        updateUserChannel(channel.id, { status: 'error', errorMessage: syncResult.error })
        channel.status = 'error'
        channel.error_message = syncResult.error
      }

      res.json({ ok: true, channel })
    } catch (err) {
      console.error('[Channels] update failed:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.delete('/api/user/channels/:id', authMiddleware, async (req, res) => {
    try {
      const owned = getUserChannels(req.currentUser.id)
      const channel = owned.find(c => c.id === req.params.id)
      if (!channel) {
        return res.status(403).json({ ok: false, error: 'Not your channel' })
      }

      await removeChannelFromGateway(channel)
      deleteUserChannel(req.params.id)
      res.json({ ok: true })
    } catch (err) {
      console.error('[Channels] delete failed:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/user/channels/sync-from-gateway', authMiddleware, async (req, res) => {
    try {
      const { agentId } = req.body
      if (!agentId) return res.status(400).json({ ok: false, error: 'agentId required' })

      const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
      if (!ownedIds.includes(agentId)) {
        return res.status(403).json({ ok: false, error: '无权操作该 Agent' })
      }

      const existing = getChannelsByAgentId(agentId)
      if (existing.length > 0) {
        return res.json({ ok: true, channel: existing[0] })
      }

      let cfgResult = null
      {
        const rpcResult = await gatewayAdminRpc('config.get')
        cfgResult = rpcResult.ok ? rpcResult.payload : null
      }
      if (!cfgResult) {
        return res.json({ ok: true, channel: null })
      }
      const payload = cfgResult || {}
      const sourceConfig = payload.sourceConfig || payload.config || payload.parsed || {}

      const feishuAccount = sourceConfig.channels?.feishu?.accounts?.[agentId]
      const hasBinding = Array.isArray(sourceConfig.bindings)
        && sourceConfig.bindings.some(b => b.match?.channel === 'feishu' && b.match?.accountId === agentId)

      if (feishuAccount || hasBinding) {
        const channel = createUserChannel(req.currentUser.id, {
          channelType: 'feishu',
          name: `Feishu-synced-${agentId}`,
          agentId,
          config: feishuAccount ? { appId: feishuAccount.appId || '', appSecret: feishuAccount.appSecret || '' } : {},
        })
        updateUserChannel(channel.id, { status: 'active', lastSyncAt: Date.now() })
        channel.status = 'active'
        channel.last_sync_at = Date.now()
        console.log(`[ChannelSync] synced gateway feishu config to DB for ${agentId}`)
        return res.json({ ok: true, channel })
      }

      res.json({ ok: true, channel: null })
    } catch (err) {
      console.error('[Channels] sync-from-gateway failed:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })
}
