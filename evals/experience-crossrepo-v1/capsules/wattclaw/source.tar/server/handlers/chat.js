// Chat and workspace routes
import { authMiddleware } from '../core/auth.js'
import { gateway, streamIdMap, envConfig } from '../core/index.js'
import {
  isSessionOwned,
} from './sessions.js'
import {
  getUserOwnedSessionKeys, getUserOwnedAgentIds,
  trackSessionForUser, trackAgentForUser,
  resolveTenantIdForSession,
} from '../user-manager.js'
import {
  saveMessage,
  isReady as isMessageStoreReady, countConfirmedMessages,
  readMessages, mergeSessionMessages,
} from '../message-store.js'
import { triggerPhase2Backfill } from '../backfill-queue.js'
import { isExternalChannelSession } from '../core/message-sync.js'
import { generateSafeTitle } from '../utils/index.js'
import { broadcastSSE } from '../core/sse.js'
import { recordRequest, cacheSessionModel, getCachedSessionModel } from '../model-concurrency-monitor.js'
import { broadcastGlobalSSE } from '../core/sse.js'
import { flushPendingTokenUpdate } from '../core/index.js'
import { getGatewayHttpTargetForTenantId } from '../core/multi-tenant-gateway.js'
import { extractOccurredAt, normalizeTimestamp } from '../services/message-normalizer.js'
import { advanceSessionLastMessageAt, recomputeSessionLastMessageAt } from '../services/session-activity-service.js'
import {
  normalizeDisplayTitleCandidate,
  resolveSessionDisplayTitle,
  shouldBackfillDisplayTitle,
  summarizeMessage,
} from '../services/session-title-service.js'
import {
  isKnownExternalSession,
  parseExternalSessionKey,
} from '../services/external-session-projection.js'
import { getKnowledgeBaseBinding } from '../database.js'

function resolveKnowledgeBaseSelection(user, rawIds) {
  if (rawIds === undefined) return []
  if (!Array.isArray(rawIds) || rawIds.length > 20) {
    const error = new Error('Invalid knowledge base selection')
    error.statusCode = 400
    throw error
  }

  const ids = [...new Set(rawIds.map(id => String(id || '').trim()).filter(Boolean))]
  return ids.map((id) => {
    const binding = getKnowledgeBaseBinding(id)
    const canAccess = Boolean(binding) && (
      user?.role === 'admin'
      || binding.user_id === user?.id
      || Boolean(binding.is_public)
    )
    if (!canAccess) {
      const error = new Error('No permission for selected knowledge base')
      error.statusCode = 403
      throw error
    }
    const rawName = String(binding.name_snapshot || id).replace(/[\r\n]+/g, ' ').trim() || id
    return {
      id,
      name: rawName.replace(/^\[u[^\]]+\]_\d{4}-\d{2}-\d{2}_/, '') || id,
    }
  })
}

function buildKnowledgeBaseMessage(message, knowledgeBases) {
  if (knowledgeBases.length === 0) return message
  const metadata = JSON.stringify({ knowledgeBases })
  const targets = knowledgeBases.map(item => `- ${item.name} (dataset_id: ${item.id})`).join('\n')
  return [
    '[WATTCLAW_KNOWLEDGE_CONTEXT_BEGIN]',
    metadata,
    '本轮对话已指定知识库。必须使用已连接的知识库 MCP 检索工具查询以下知识库，并将这些 dataset_id 原样传给工具：',
    targets,
    '请先检索相关内容，再根据检索证据回答。不得改查其他知识库；如果 MCP 不可用、检索失败或没有相关证据，请明确说明，不要用常识编造知识库内容。',
    '[WATTCLAW_KNOWLEDGE_CONTEXT_END]',
    message,
  ].join('\n')
}

function materializeStoredMessage(row) {
  const raw = row.raw_content
  const rawTimestamp = extractOccurredAt(raw)
  const storedTimestamp = normalizeTimestamp(row.msg_timestamp)
  const timestamp = rawTimestamp || storedTimestamp

  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    return timestamp ? { ...raw, timestamp } : raw
  }

  return {
    role: row.role,
    content: row.content,
    ...(row.model ? { model: row.model } : {}),
    ...(timestamp ? { timestamp } : {}),
  }
}

function isSessionDiagnosticEnabled() {
  return envConfig.SESSION_DIAG === '1' || process.env.SESSION_DIAG === '1'
}

function logSessionDiagnostic(scope, payload) {
  if (!isSessionDiagnosticEnabled()) return
  console.log(`[SessionDiag:${scope}]`, payload)
}

async function resolveHistoryGatewayTarget({ isAdmin, sessionKey, sessionRow }) {
  const sessionTenantId = sessionRow?.tenant_id || resolveTenantIdForSession(sessionKey)
  // 会话可能属于任意 tenant（多租户下非默认 tenant 的会话也需要正确路由）。
  // 之前仅 admin 分支按 tenant 路由，非 admin 一律落到默认 OPENCLAW_WS_URL(tenant-1)，
  // 导致 tenant-2 会话刷新拉历史时 fetch 到错误网关 → 失败，页面只显示新消息。
  if (sessionTenantId) {
    const tenantTarget = await getGatewayHttpTargetForTenantId(sessionTenantId).catch((err) => {
      console.error('[APM - History] tenant target error:', err.message)
      return null
    })
    if (tenantTarget) {
      return {
        baseUrl: tenantTarget.baseUrl,
        headers: tenantTarget.headers,
      }
    }
  }

  const wsUrl = new URL(envConfig.OPENCLAW_WS_URL || 'ws://localhost:18789')
  const protocol = wsUrl.protocol === 'wss:' ? 'https' : 'http'
  return {
    baseUrl: `${protocol}://${wsUrl.host}`,
    headers: {
      Authorization: `Bearer ${envConfig.OPENCLAW_AUTH_TOKEN || ''}`,
    },
  }
}

async function fetchGatewayHistoryPayload({ sessionKey, limit, cursor, gatewayBaseUrl, gatewayHeaders, apmStart }) {
  const gatewayUrl = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, gatewayBaseUrl)
  gatewayUrl.searchParams.set('limit', String(limit))
  if (cursor) {
    gatewayUrl.searchParams.set('cursor', String(cursor))
  }

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 30_000)
  const fetchStart = performance.now()
  console.log(`[APM - History] Cache MISS, fetching ${gatewayUrl.toString()}`)

  try {
    const gatewayRes = await fetch(gatewayUrl.toString(), {
      headers: gatewayHeaders,
      signal: controller.signal,
    })

    const ttfbMs = (performance.now() - fetchStart).toFixed(1)
    console.log(`[APM - History] TTFB (first byte from Gateway): ${ttfbMs}ms, status=${gatewayRes.status}`)

    if (!gatewayRes.ok) {
      const text = await gatewayRes.text().catch(() => '')
      const totalMs = (performance.now() - apmStart).toFixed(1)
      console.log(`[APM - History] Gateway error response in ${totalMs}ms, status=${gatewayRes.status}`)
      return { ok: false, status: gatewayRes.status, error: `Gateway history error: ${text}` }
    }

    const bodyStart = performance.now()
    const gatewayData = await gatewayRes.json()
    const bodyMs = (performance.now() - bodyStart).toFixed(1)
    console.log(`[APM - History] body download + JSON parse: ${bodyMs}ms`)

    const extractStart = performance.now()
    const messages = extractMessagesFromHistoryPayload(gatewayData)
    const extractMs = (performance.now() - extractStart).toFixed(1)
    console.log(`[APM - History] extractMessagesFromHistoryPayload: ${extractMs}ms, messages=${messages.length}`)

    const totalMs = (performance.now() - apmStart).toFixed(1)
    console.log(`[APM - History] TOTAL end-to-end: ${totalMs}ms (TTFB=${ttfbMs}, body=${bodyMs}, extract=${extractMs})`)

    return {
      ok: true,
      messages,
      cursor: gatewayData.nextCursor || gatewayData.cursor || null,
      hasMore: !!gatewayData.hasMore,
    }
  } finally {
    clearTimeout(timeout)
  }
}

// Gateway history payloads are inconsistent: the same logical message may carry
// a top-level `id` on one fetch and omit it (keeping only `__openclaw.id`) on
// the next. Relying on `m.id` therefore inserts a duplicate on every refresh.
// Resolve a STABLE msg_id so repeated merges upsert instead of appending:
//   - user rows: strip the `:user` suffix from idempotencyKey so it aligns with
//     the real-time saveMessage copy (which stores msg_id = raw idempotencyKey).
//   - other rows (assistant/tool): prefer `__openclaw.id` — present on every
//     fetch — falling back to top-level id, then idempotencyKey. user and
//     assistant share the same idempotencyKey base, so the role suffix must be
//     kept for non-user rows to avoid msg_id collisions.
function resolveGatewayHistoryMsgId(message) {
  if (!message || typeof message !== 'object') return null
  const raw = message.rawContent && typeof message.rawContent === 'object'
    ? message.rawContent
    : message
  const oc = raw.__openclaw && typeof raw.__openclaw === 'object' ? raw.__openclaw : null
  const role = String(message.role || raw.role || '').trim().toLowerCase()

  const idempotencyKey = typeof raw.idempotencyKey === 'string'
    ? raw.idempotencyKey
    : (oc && typeof oc.idempotencyKey === 'string' ? oc.idempotencyKey : null)

  if (role === 'user' && idempotencyKey) {
    return idempotencyKey.replace(/:user$/, '')
  }

  const stableId = (oc && oc.id != null ? oc.id : null) ?? message.id ?? message.msg_id
  if (stableId != null) return String(stableId)

  return idempotencyKey
}

async function mergeGatewayHistoryIntoStore(sessionKey, messages) {
  if (!isMessageStoreReady() || messages.length === 0) return null

  console.log(`[Backfill] Phase 1 START ${sessionKey}: fetched=${messages.length} from Gateway`)
  const backfillMsgs = messages.map((m) => {
    const msgTimestamp = extractOccurredAt(m)
    return {
      msgId: resolveGatewayHistoryMsgId(m),
      role: m.role || 'unknown',
      content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
      rawContent: m,
      model: m.model || null,
      status: 'confirmed',
      msgTimestamp,
    }
  })

  const result = await mergeSessionMessages(sessionKey, backfillMsgs)
  recomputeSessionLastMessageAt(sessionKey, backfillMsgs.map(m => m.msgTimestamp))
  console.log(`[Backfill] Phase 1 ${sessionKey}:`, result)
  if (isExternalChannelSession(sessionKey)) {
    triggerPhase2Backfill(sessionKey, { fetchFn: fetchHistoryFromGateway })
  }
  return result
}

function extractHistoryText(value) {
  if (typeof value === 'string') return value.trim()
  if (Array.isArray(value)) {
    return value
      .map(item => extractHistoryText(item))
      .filter(Boolean)
      .join('\n')
      .trim()
  }
  if (!value || typeof value !== 'object') return ''
  for (const key of ['question', 'prompt', 'input', 'text', 'content', 'message']) {
    const text = extractHistoryText(value[key])
    if (text) return text
  }
  return ''
}

function extractHistoryUserContent(message) {
  const role = String(message?.role || message?.rawContent?.role || '').trim().toLowerCase()
  if (role && role !== 'user') return ''
  return extractHistoryText(message?.content) ||
    extractHistoryText(message?.rawContent?.content) ||
    extractHistoryText(message?.rawContent)
}

function firstHistoryUserContent(messages) {
  if (!Array.isArray(messages)) return ''
  for (const message of messages) {
    const content = extractHistoryUserContent(message)
    if (normalizeDisplayTitleCandidate(content)) return content
  }
  return ''
}

function repairSessionTitleFromHistory(sessionKey, messages) {
  const row = db.prepare(`
    SELECT id, label, display_title, channel, peer_id
    FROM user_sessions
    WHERE session_key = ?
    LIMIT 1
  `).get(sessionKey)
  if (!row) return false
  if (!shouldBackfillDisplayTitle(row.display_title, row.peer_id) &&
    !shouldBackfillDisplayTitle(row.label, row.peer_id)) {
    return false
  }

  const content = firstHistoryUserContent(messages)
  const parsed = parseExternalSessionKey(sessionKey)
  const title = normalizeDisplayTitleCandidate(
    parsed && isKnownExternalSession(sessionKey)
      ? resolveSessionDisplayTitle({
        channel: row.channel || parsed.channel,
        peerProfile: null,
        firstUserMessage: content,
        isGroup: parsed.kind === 'group',
      })
      : generateSafeTitle(summarizeMessage(content))
  )
  if (!title) return false

  db.prepare(`
    UPDATE user_sessions
    SET label = ?, display_title = ?, updated_at = ?
    WHERE id = ?
  `).run(title, title, Date.now(), row.id)
  return true
}

export function createChatRoutes(app) {
  app.post('/api/workspace/send', authMiddleware, async (req, res) => {
    try {
      const { sessionKey, message, idempotencyKey, title, model, knowledgeBaseIds } = req.body
      if (!sessionKey || typeof message !== 'string' || !message.trim()) {
        return res.status(400).json({ ok: false, error: 'sessionKey and message required' })
      }

      const knowledgeBases = resolveKnowledgeBaseSelection(req.currentUser, knowledgeBaseIds)
      const gatewayMessage = buildKnowledgeBaseMessage(message, knowledgeBases)

      logSessionDiagnostic('workspace-send:received', {
        userId: req.currentUser.id,
        sessionKey,
        idempotencyKey: idempotencyKey || null,
        hasTitle: typeof title === 'string' && title.trim().length > 0,
        model: model || null,
      })

      const streamId = randomUUID()
      streamIdMap.set(streamId, { sessionKey, startTime: Date.now() })

      if (model) {
        console.info('[Workspace] chat.send model requested', {
          sessionKey,
          requestedModel: model,
          idempotencyKey: idempotencyKey || null,
        })
      }

      // === 并发监控 ===
      const wsEffectiveModel = model || getCachedSessionModel(sessionKey)
      if (wsEffectiveModel) {
        const wsMonitorResult = recordRequest(wsEffectiveModel)
        if (wsMonitorResult.shouldAlert) {
          broadcastGlobalSSE({
            type: 'event',
            event: 'model.congestion',
            payload: { isCongested: wsMonitorResult.isCongested, count: wsMonitorResult.count, model: wsMonitorResult.model, windowMs: wsMonitorResult.windowMs }
          })
        }
      }

      if (!isSessionOwned(sessionKey, req.currentUser.id)) {
        const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || null
        trackSessionForUser(req.currentUser.id, sessionKey, agentId)
        if (agentId) {
          const ownedAgents = getUserOwnedAgentIds(req.currentUser.id)
          if (!ownedAgents.includes(agentId)) {
            trackAgentForUser(req.currentUser.id, agentId, agentId)
          }
        }
      }

      // Gateway chat.send does not accept model param; patch model without blocking delivery.
      if (model) {
        gateway.call('sessions.patch', { key: sessionKey, model })
          .then(() => { cacheSessionModel(sessionKey, model) })
          .catch(err => {
            console.error(`[Workspace] sessions.patch model failed for ${sessionKey}:`, err.message)
          })
      }

      const chatSendParams = {
        sessionKey,
        message: gatewayMessage,
        idempotencyKey,
      }
      console.info('[Workspace] Gateway chat.send dispatching', {
        sessionKey,
        idempotencyKey: idempotencyKey || null,
      })
      gateway.call('chat.send', chatSendParams)
        .then(() => {
          console.info('[Workspace] Gateway chat.send dispatched', {
            sessionKey,
            idempotencyKey: idempotencyKey || null,
          })
        })
        .catch(err => {
          streamIdMap.delete(streamId)
          console.error('[Workspace] Gateway chat.send error:', err.message)
          broadcastSSE({ type: 'event', event: 'chat.error', payload: { sessionKey, error: err.message } })
        })

      const userMsgTimestamp = new Date().toISOString()
      if (isMessageStoreReady()) {
        saveMessage({
          sessionKey, msgId: idempotencyKey || null,
          role: 'user', content: typeof message === 'string' ? message : JSON.stringify(message),
          rawContent: {
            role: 'user',
            content: message,
            timestamp: userMsgTimestamp,
            ...(knowledgeBases.length > 0 ? { knowledgeBases } : {}),
          },
          status: 'confirmed',
          msgTimestamp: userMsgTimestamp,
        }).catch(err => console.error('[MessageStore] user msg capture error:', err.message))
      }
      advanceSessionLastMessageAt(sessionKey, userMsgTimestamp)

      const safeTitle = title ? generateSafeTitle(title) : ''
      logSessionDiagnostic('workspace-send:title', {
        userId: req.currentUser.id,
        sessionKey,
        hasIncomingTitle: typeof title === 'string' && title.trim().length > 0,
        willTrackTitle: !!safeTitle,
      })
      if (safeTitle && sessionKey) {
        const parts = sessionKey.split(':')
        const agentId = parts.length >= 2 ? parts[1] : null
        trackSessionForUser(req.currentUser.id, sessionKey, agentId, safeTitle, null)
      }

      if (safeTitle && sessionKey) {
        const gatewayLabel = `${safeTitle}-${Date.now()}`
        logSessionDiagnostic('workspace-send:patch-label', {
          userId: req.currentUser.id,
          sessionKey,
          hasGatewayLabel: true,
        })
        gateway.call('sessions.patch', { key: sessionKey, label: gatewayLabel }).catch(() => {})
      }

      res.json({ ok: true, streamId })
    } catch (err) {
      console.error('[Workspace] Send error:', err)
      res.status(err.statusCode || 500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/workspace/rename-session', authMiddleware, async (req, res) => {
    try {
      const { sessionKey, label } = req.body
      if (!sessionKey || !label) {
        return res.status(400).json({ ok: false, error: 'sessionKey and label required' })
      }

      const row = db.prepare('SELECT id, user_id FROM user_sessions WHERE session_key = ?').get(sessionKey)
      if (!row || (row.user_id !== req.currentUser.id && req.currentUser.role !== 'admin')) {
        return res.status(403).json({ ok: false, error: 'Access denied' })
      }

      db.prepare('UPDATE user_sessions SET label = ?, display_title = ? WHERE session_key = ?').run(label, label, sessionKey)
      res.json({ ok: true })
    } catch (err) {
      console.error('[Workspace] Rename error:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/chat/cancel', authMiddleware, async (req, res) => {
    try {
      const { streamId, sessionKey } = req.body
      let targetSession = sessionKey

      if (streamId) {
        const entry = streamIdMap.get(streamId)
        if (entry) {
          const ownedKeys = getUserOwnedSessionKeys(req.currentUser.id)
          if (ownedKeys.includes(entry.sessionKey)) {
            targetSession = entry.sessionKey
          }
          streamIdMap.delete(streamId)
        }
      }

      if (targetSession) {
        gateway.call('chat.abort', { sessionKey: targetSession }).catch(() => {})
      }
      res.json({ ok: true })
    } catch (err) {
      res.json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/chat/send', authMiddleware, async (req, res) => {
    const { sessionKey, message, idempotencyKey, model, thinking, fastMode, deliver, timeoutMs, attachments } = req.body

    if (!sessionKey || typeof sessionKey !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing sessionKey' } })
    }
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing message' } })
    }
    if (!idempotencyKey || typeof idempotencyKey !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing idempotencyKey' } })
    }

    if (!gateway.isConnected) {
      return res.status(503).json({ ok: false, error: { message: 'Gateway not connected' } })
    }

    const userId = req.currentUser.id

    logSessionDiagnostic('chat-send:received', {
      userId,
      sessionKey,
      idempotencyKey,
      ownedBeforeSend: isSessionOwned(sessionKey, userId),
      model: model || null,
    })

    if (!isSessionOwned(sessionKey, userId)) {
      const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || null
      trackSessionForUser(userId, sessionKey, agentId)
      if (agentId) {
        const ownedAgents = getUserOwnedAgentIds(userId)
        if (!ownedAgents.includes(agentId)) {
          trackAgentForUser(userId, agentId, agentId)
        }
      }
    }

    const userMsgTimestamp = new Date().toISOString()
    saveMessage({
      sessionKey,
      msgId: idempotencyKey,
      role: 'user',
      content: message,
      rawContent: { role: 'user', content: message, timestamp: userMsgTimestamp },
      model: model || null,
      status: 'confirmed',
      msgTimestamp: userMsgTimestamp,
    }).catch(err => console.error('[MessageStore] user msg capture error:', err.message))
    advanceSessionLastMessageAt(sessionKey, userMsgTimestamp)

    // Gateway chat.send does not accept model param; patch session first
    if (model) {
      try {
        await gateway.call('sessions.patch', { key: sessionKey, model })
        cacheSessionModel(sessionKey, model)
      } catch (patchErr) {
        console.error(`[Chat] sessions.patch model failed for ${sessionKey}:`, patchErr.message)
      }
    }

    const gatewayParams = {
      sessionKey,
      message,
      idempotencyKey,
      ...(thinking ? { thinking } : {}),
      ...(fastMode !== undefined ? { fastMode } : {}),
      ...(deliver !== undefined ? { deliver } : {}),
      ...(timeoutMs ? { timeoutMs } : {}),
      ...(attachments ? { attachments } : {}),
    }

    // === 并发监控 ===
    const effectiveModel = model || getCachedSessionModel(sessionKey)
    if (effectiveModel) {
      const monitorResult = recordRequest(effectiveModel)
      if (monitorResult.shouldAlert) {
        broadcastGlobalSSE({
          type: 'event',
          event: 'model.congestion',
          payload: { isCongested: monitorResult.isCongested, count: monitorResult.count, model: monitorResult.model, windowMs: monitorResult.windowMs }
        })
      }
    }

    try {
      const result = await gateway.call('chat.send', gatewayParams)
      return res.json({ ok: true, payload: result })
    } catch (err) {
      return res.status(502).json({
        ok: false,
        error: { message: err.message || 'Gateway chat.send failed' },
      })
    }
  })

  app.post('/api/chat/abort', authMiddleware, async (req, res) => {
    const { sessionKey, runId } = req.body

    if (!sessionKey || typeof sessionKey !== 'string') {
      return res.status(400).json({ ok: false, error: { message: 'Missing sessionKey' } })
    }

    if (!gateway.isConnected) {
      return res.status(503).json({ ok: false, error: { message: 'Gateway not connected' } })
    }

    if (req.currentUser.role !== 'admin' && !isSessionOwned(sessionKey, req.currentUser.id)) {
      return res.json({ ok: true, payload: { ok: true, aborted: false, runIds: [] } })
    }

    gateway.call('chat.abort', { sessionKey, ...(runId ? { runId } : {}) }).catch(() => {})
    return res.json({ ok: true, payload: { ok: true, aborted: true } })
  })

  app.get('/api/chat/history', authMiddleware, async (req, res) => {
    const apmStart = performance.now()
    try {
      const sessionKey = req.query.sessionKey
      if (!sessionKey || typeof sessionKey !== 'string') {
        return res.status(400).json({ ok: false, error: { message: 'Missing sessionKey' } })
      }

      const isAdmin = req.currentUser.role === 'admin'
      const sessionRow = db.prepare('SELECT user_id, tenant_id FROM user_sessions WHERE session_key = ?').get(sessionKey)

      if (!isAdmin && !isSessionOwned(sessionKey, req.currentUser.id)) {
        logSessionDiagnostic('history:not-owned', {
          userId: req.currentUser.id,
          sessionKey,
        })
        return res.json({ ok: true, payload: { messages: [], cursor: null, hasMore: false } })
      }

      const limit = Math.min(1000, Math.max(1, parseInt(req.query.limit) || 50))
      const cursor = req.query.cursor || ''
      logSessionDiagnostic('history:request', {
        userId: req.currentUser.id,
        sessionKey,
        limit,
        cursor: cursor || null,
        storeReady: isMessageStoreReady(),
      })

      const historyTarget = await resolveHistoryGatewayTarget({ isAdmin, sessionKey, sessionRow })

      if (isMessageStoreReady()) {
        let localCount = await countConfirmedMessages(sessionKey)
        logSessionDiagnostic('history:local-count', {
          userId: req.currentUser.id,
          sessionKey,
          localCount,
          limit,
          cursor: cursor || null,
          isExternal: isExternalChannelSession(sessionKey),
        })

        if (!cursor) {
          const gatewayResult = await fetchGatewayHistoryPayload({
            sessionKey,
            limit: Math.max(limit, 1000),
            cursor: '',
            gatewayBaseUrl: historyTarget.baseUrl,
            gatewayHeaders: historyTarget.headers,
            apmStart,
          }).catch((err) => {
            console.error('[APM - History] Gateway pre-merge error:', err.message)
            return null
          })
          if (gatewayResult?.ok && gatewayResult.messages.length > 0) {
            repairSessionTitleFromHistory(sessionKey, gatewayResult.messages)
            await mergeGatewayHistoryIntoStore(sessionKey, gatewayResult.messages).catch((err) => {
              console.error('[Backfill] Phase 1 error:', err.message)
            })
            flushPendingTokenUpdate(sessionKey)
            localCount = await countConfirmedMessages(sessionKey)
            console.log('[APM - History] Gateway initial backfill merged:', {
              sessionKey,
              messages: gatewayResult.messages.length,
              localCountAfterMerge: localCount,
            })
            if (localCount === 0) {
              return res.json({
                ok: true,
                payload: {
                  messages: gatewayResult.messages,
                  cursor: gatewayResult.cursor,
                  hasMore: gatewayResult.hasMore,
                }
              })
            }
          }
        }

        if (localCount > 0) {
          // Only trigger Phase 2 backfill for external channels; internal sessions use PG as SSOT
          if (!cursor && localCount >= limit && isExternalChannelSession(sessionKey)) {
            triggerPhase2Backfill(sessionKey, { fetchFn: fetchHistoryFromGateway })
          }
          const beforeSeq = cursor || null
          const rows = await readMessages(sessionKey, { limit, beforeSeq })
          logSessionDiagnostic('history:local-rows', {
            userId: req.currentUser.id,
            sessionKey,
            localCount,
            returnedRows: rows.length,
            beforeSeq,
            newestSeq: rows[0]?.seq ?? null,
            oldestSeq: rows[rows.length - 1]?.seq ?? null,
            newestRole: rows[0]?.role ?? null,
            oldestRole: rows[rows.length - 1]?.role ?? null,
          })
          if (rows.length > 0) {
            const messages = rows.map(materializeStoredMessage)
            messages.reverse()
            repairSessionTitleFromHistory(sessionKey, messages)
            const oldestRow = rows[rows.length - 1]
            const cursorStr = String(oldestRow.seq)
            const hasMore = rows.length >= limit
            const totalMs = (performance.now() - apmStart).toFixed(1)
            console.log(`[APM - History] PostgreSQL HIT: ${totalMs}ms, ${messages.length} msgs from local store`)
            flushPendingTokenUpdate(sessionKey)
            return res.json({ ok: true, payload: { messages, cursor: cursorStr, hasMore } })
          }
          console.log(`[APM - History] PostgreSQL cursor exhausted, returning empty`)
          return res.json({ ok: true, payload: { messages: [], cursor: null, hasMore: false } })
        }
      }

      const gatewayResult = await fetchGatewayHistoryPayload({
        sessionKey,
        limit,
        cursor,
        gatewayBaseUrl: historyTarget.baseUrl,
        gatewayHeaders: historyTarget.headers,
        apmStart,
      })

      if (gatewayResult.ok) {
        repairSessionTitleFromHistory(sessionKey, gatewayResult.messages)
        await mergeGatewayHistoryIntoStore(sessionKey, gatewayResult.messages).catch((err) => {
          console.error('[Backfill] Phase 1 error:', err.message)
        })
        flushPendingTokenUpdate(sessionKey)
        return res.json({
          ok: true,
          payload: {
            messages: gatewayResult.messages,
            cursor: gatewayResult.cursor,
            hasMore: gatewayResult.hasMore,
          }
        })
      }

      return res.status(502).json({ ok: false, error: { message: gatewayResult.error } })
    } catch (err) {
      const totalMs = (performance.now() - apmStart).toFixed(1)
      if (err.name === 'AbortError') {
        console.error(`[APM - History] ABORTED after 30s timeout at ${totalMs}ms`)
        return res.status(504).json({ ok: false, error: { message: 'Gateway history timeout (30s)' } })
      }
      console.error(`[APM - History] error at ${totalMs}ms:`, err.message)
      return res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}

import { randomUUID } from 'crypto'
import { extractMessagesFromHistoryPayload } from '../utils/index.js'
import { fetchHistoryFromGateway } from '../core/gateway-client.js'
import db from '../database.js'
