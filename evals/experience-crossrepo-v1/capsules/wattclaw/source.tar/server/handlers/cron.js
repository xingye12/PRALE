import { randomUUID } from 'node:crypto'
import { authMiddleware } from '../core/auth.js'
import { gatewayAdminRpc, gatewayAdminRpcForTarget, fetchHistoryFromGateway } from '../core/gateway-client.js'
import { getGatewayHttpTargetForTenantId } from '../core/multi-tenant-gateway.js'
import { listCronJobsFromDb, isCronJobOwnedBy, isAgentOwnedBy, upsertCronJob, deleteCronJob, getCronJobById, refreshCronJobsForScope, upsertCronSessionBinding, updateCronSessionBindingName } from '../cron-manager.js'
import { resolveTenantIdForAgent, resolveTenantIdForSession, trackSessionForUser } from '../user-manager.js'
import { isReady as isMessageStoreReady, mergeSessionMessages } from '../message-store.js'
import { extractMessagesFromHistoryPayload } from '../utils/index.js'
import { extractOccurredAt } from '../services/message-normalizer.js'
import { advanceSessionLastMessageAt, recomputeSessionLastMessageAt } from '../services/session-activity-service.js'

const CRON_STATUS_KEY = 'cron.status'
const inflight = new Map()
function getErrorMessage(error) {
  return error instanceof Error ? error.message : String(error)
}

function sanitizeCronLogValue(value, depth = 0) {
  if (value === null || value === undefined) return value
  if (depth > 4) return '[DepthLimit]'
  if (typeof value !== 'object') return value
  if (Array.isArray(value)) return value.map(item => sanitizeCronLogValue(item, depth + 1))

  const sensitiveKeys = ['token', 'secret', 'password', 'apikey', 'apiKey', 'auth', 'authorization', 'credential', 'privateKey']
  const result = {}
  for (const [key, item] of Object.entries(value)) {
    const lowerKey = key.toLowerCase()
    const isSensitive = sensitiveKeys.some(word => lowerKey.includes(word.toLowerCase()))
    result[key] = isSensitive ? '***' : sanitizeCronLogValue(item, depth + 1)
  }
  return result
}

function logCronCreateStep(step, data) {
  console.info(`[Cron][create] ${step}`, sanitizeCronLogValue(data))
}

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function asString(value) {
  return typeof value === 'string' ? value : ''
}

function resolveCronAgentId(source) {
  const rawAgentId = asString(source?.agentId).trim()
  if (rawAgentId) return rawAgentId

  const sessionKey = normalizeSessionKey(source?.sessionKey)
    || sessionKeyFromTarget(asString(source?.sessionTarget))
  return sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
}

function formatEveryDuration(value) {
  const ms = Number(value)
  if (!Number.isFinite(ms) || ms <= 0) return ''
  if (ms % 86_400_000 === 0) return `${ms / 86_400_000}d`
  if (ms % 3_600_000 === 0) return `${ms / 3_600_000}h`
  if (ms % 60_000 === 0) return `${ms / 60_000}m`
  if (ms % 1000 === 0) return `${ms / 1000}s`
  return `${Math.round(ms)}ms`
}

function sendOk(res, payload) {
  return res.json({ ok: true, payload })
}

function sendGatewayError(res, result) {
  return res.status(502).json({
    ok: false,
    error: { message: result.error || 'Gateway RPC failed' },
  })
}

export function singleflight(key, factory) {
  const current = inflight.get(key)
  if (current) return current

  const request = Promise.resolve()
    .then(factory)
    .finally(() => {
      inflight.delete(key)
    })

  inflight.set(key, request)
  return request
}

async function getCronStatusPayload() {
  const result = await singleflight(CRON_STATUS_KEY, () => gatewayAdminRpc('cron.status', {}))
  if (!result.ok) throw new Error(result.error || 'cron.status failed')
  return result.payload || null
}

function listVisibleCronJobs(req) {
  return listCronJobsFromDb({
    isAdmin: req.currentUser?.role === 'admin',
    userId: req.currentUser?.id,
  })
}

async function refreshVisibleCronJobs(req) {
  const result = await refreshCronJobsForScope(gatewayAdminRpc, {
    isAdmin: req.currentUser?.role === 'admin',
    userId: req.currentUser?.id,
  })
  if (!result.ok && result.jobs.length === 0) {
    console.warn('[Cron] scoped refresh failed, serving cached jobs:', result.error)
  }
}

function assertCanUseAgent(req, agentId) {
  return isAgentOwnedBy(agentId, {
    isAdmin: req.currentUser?.role === 'admin',
    userId: req.currentUser?.id,
  })
}

function assertCanUseJob(req, jobId) {
  if (!jobId) return false
  return isCronJobOwnedBy(jobId, {
    isAdmin: req.currentUser?.role === 'admin',
    userId: req.currentUser?.id,
  })
}

function extractParams(req) {
  return req.body && typeof req.body === 'object' ? req.body : {}
}

function omitCronAgentId(params) {
  const source = asRecord(params)
  const { agentId, ...rest } = source
  return rest
}

function sessionKeyFromTarget(sessionTarget) {
  if (typeof sessionTarget !== 'string') return ''
  let target = sessionTarget.trim()
  if (!target.startsWith('session:')) return ''
  while (target.startsWith('session:')) {
    target = target.slice('session:'.length).trim()
  }
  return target
}

function normalizeSessionKey(value) {
  const text = asString(value).trim()
  return text.startsWith('session:') ? sessionKeyFromTarget(text) : text
}

function jobSessionKey(job) {
  return normalizeSessionKey(job?.sessionKey) || sessionKeyFromTarget(job?.sessionTarget || '')
}

function canonicalSessionTarget(sessionKey) {
  return sessionKey ? `session:${sessionKey}` : ''
}

function cronSessionDisplayName(name) {
  return Array.from(asString(name).trim()).slice(0, 10).join('')
}

export function prepareCronCreateParams(value, createId = randomUUID) {
  const source = asRecord(value)
  const { createDedicatedSession, ...params } = source
  if (createDedicatedSession !== true || asRecord(params.payload).kind !== 'agentTurn') {
    return { params, binding: null }
  }

  const agentId = resolveCronAgentId(params)
  const sessionKey = `agent:${agentId}:cron-task:${createId()}`
  const sessionTarget = canonicalSessionTarget(sessionKey)
  return {
    params: {
      ...params,
      sessionKey,
      sessionTarget,
      payload: {
        ...asRecord(params.payload),
        sessionTarget,
      },
    },
    binding: {
      sessionKey,
      agentId,
      displayName: cronSessionDisplayName(params.name),
    },
  }
}

function canonicalCronJob(job) {
  if (!job) return job
  const sessionKey = jobSessionKey(job)
  if (!sessionKey) return job
  return {
    ...job,
    sessionKey,
    sessionTarget: canonicalSessionTarget(sessionKey),
    payload: job.payload && typeof job.payload === 'object' && job.payload.kind === 'agentTurn'
      ? {
          ...job.payload,
          sessionKey,
          sessionTarget: canonicalSessionTarget(sessionKey),
        }
      : job.payload,
  }
}

function normalizeCronPayloadPatch(payload) {
  const source = asRecord(payload)
  const kind = asString(source.kind)

  if (kind === 'systemEvent') {
    return {
      kind: 'systemEvent',
      text: asString(source.text || source.message).trim() || undefined,
    }
  }

  if (kind === 'agentTurn' || source.message !== undefined || source.text !== undefined || source.sessionKey !== undefined || source.sessionTarget !== undefined) {
    const sessionKey = normalizeSessionKey(source.sessionKey) || sessionKeyFromTarget(asString(source.sessionTarget))
    return {
      kind: 'agentTurn',
      text: asString(source.text || source.message).trim() || undefined,
      ...(asString(source.model).trim() ? { model: asString(source.model).trim() } : {}),
      ...(asString(source.thinking).trim() ? { thinking: asString(source.thinking).trim() } : {}),
      ...(source.timeoutSeconds !== undefined ? { timeoutSeconds: Number(source.timeoutSeconds) || undefined } : {}),
      ...(sessionKey ? { sessionTarget: canonicalSessionTarget(sessionKey) } : {}),
    }
  }

  return null
}

function normalizeCronUpdatePatch(params) {
  const source = asRecord(params)
  const patchSource = asRecord(source.patch)
  const patch = {
    ...source,
    ...patchSource,
  }

  delete patch.jobId
  delete patch.id
  delete patch.taskId
  delete patch.sessionKey

  if (patch.payload && typeof patch.payload === 'object') {
    const normalizedPayload = normalizeCronPayloadPatch(patch.payload)
    if (normalizedPayload) {
      patch.payload = normalizedPayload
    }
  }

  if ('sessionTarget' in patch) {
    const sessionTarget = asString(patch.sessionTarget).trim()
    const sessionKey = normalizeSessionKey(sessionTarget) || sessionKeyFromTarget(sessionTarget)
    patch.sessionTarget = sessionKey ? canonicalSessionTarget(sessionKey) : sessionTarget || undefined
  }

  return patch
}

function buildCronAddParams(params) {
  const source = asRecord(params)
  const schedule = asRecord(source.schedule)
  const payload = asRecord(source.payload)
  const sessionTarget = asString(source.sessionTarget).trim()
  const sessionKey = normalizeSessionKey(source.sessionKey) || sessionKeyFromTarget(sessionTarget)
  const agentId = resolveCronAgentId(source)
  const agentTurn = payload.kind === 'agentTurn'
  const systemEvent = payload.kind === 'systemEvent'
  const normalizedSchedule = schedule.kind === 'at'
    ? {
        kind: 'at',
        at: asString(schedule.at).trim() || undefined,
      }
    : schedule.kind === 'every'
      ? {
          kind: 'every',
          everyMs: Number(schedule.everyMs) || undefined,
          ...(schedule.anchorMs !== undefined ? { anchorMs: Number(schedule.anchorMs) || undefined } : {}),
        }
      : schedule.kind === 'cron'
        ? {
            kind: 'cron',
            expr: asString(schedule.expr).trim() || undefined,
            ...(asString(schedule.tz).trim() ? { tz: asString(schedule.tz).trim() } : {}),
          }
        : {}

  const normalizedPayload = systemEvent
    ? {
        kind: 'systemEvent',
        text: asString(payload.text).trim() || undefined,
      }
    : agentTurn
      ? {
          kind: 'agentTurn',
          text: asString(payload.text || payload.message).trim() || undefined,
          ...(asString(payload.model).trim() ? { model: asString(payload.model).trim() } : {}),
          ...(asString(payload.thinking).trim() ? { thinking: asString(payload.thinking).trim() } : {}),
          ...(payload.timeoutSeconds !== undefined ? { timeoutSeconds: Number(payload.timeoutSeconds) || undefined } : {}),
        }
      : {}

  return {
    name: asString(source.name).trim() || undefined,
    enabled: source.enabled !== false,
    agentId: agentId || undefined,
    deleteAfterRun: source.deleteAfterRun === true,
    schedule: normalizedSchedule,
    payload: normalizedPayload,
    sessionTarget: sessionTarget || (sessionKey ? `session:${sessionKey}` : undefined),
    ...(source.wakeMode ? { wakeMode: source.wakeMode === 'now' ? 'now' : 'next-heartbeat' } : {}),
    ...(source.delivery && typeof source.delivery === 'object' ? { delivery: source.delivery } : {}),
  }
}

function trackCronRunSession(req, job, payload) {
  if (req.currentUser?.role === 'admin') return
  const fallbackAgentId = job?.agentId || ''
  const row = asRecord(payload)
  const sessionKey = normalizeSessionKey(row.sessionKey) || sessionKeyFromTarget(asString(row.sessionTarget)) || jobSessionKey(job)
  if (!sessionKey) return

  const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || fallbackAgentId || null
  trackSessionForUser(req.currentUser.id, sessionKey, agentId)
}

function toStoredHistoryMessage(message, index) {
  const msgTimestamp = extractOccurredAt(message)
  return {
    seq: index + 1,
    msgId: message.id || message.msg_id || null,
    role: message.role || 'unknown',
    content: typeof message.content === 'string' ? message.content : JSON.stringify(message.content || ''),
    rawContent: message,
    model: message.model || null,
    status: 'confirmed',
    msgTimestamp,
  }
}

async function fetchCronTargetHistory(job, sessionKey, limit = 1000) {
  const tenantId = resolveTenantIdForSession(sessionKey) || resolveTenantIdForAgent(job?.agentId)
  const target = tenantId ? await getGatewayHttpTargetForTenantId(tenantId) : null
  if (!target) return fetchHistoryFromGateway(sessionKey, limit)

  const url = new URL(`/sessions/${encodeURIComponent(sessionKey)}/history`, target.baseUrl)
  url.searchParams.set('limit', String(limit))
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15_000)
  try {
    const response = await fetch(url.toString(), {
      headers: target.headers,
      signal: controller.signal,
    })
    if (!response.ok) {
      console.warn('[Cron] pre-run history backfill fetch failed:', {
        sessionKey,
        status: response.status,
      })
      return []
    }
    const data = await response.json()
    return extractMessagesFromHistoryPayload(data).map(toStoredHistoryMessage)
  } finally {
    clearTimeout(timer)
  }
}

async function backfillCronOutputSession(job) {
  const sessionKey = jobSessionKey(job)
  if (!sessionKey || !isMessageStoreReady()) return

  const messages = await fetchCronTargetHistory(job, sessionKey, 1000)
  console.info('[Cron] pre-run history backfill fetched', {
    sessionKey,
    count: messages.length,
  })
  if (messages.length === 0) return

  const result = await mergeSessionMessages(sessionKey, messages)
  recomputeSessionLastMessageAt(sessionKey, messages.map(message => message.msgTimestamp))
  console.info('[Cron] pre-run history backfill merged', {
    sessionKey,
    ...result,
  })
}

async function patchGatewayJobSessionTarget(job) {
  const sessionKey = jobSessionKey(job)
  if (!job?.id || !sessionKey) return job

  const sessionTarget = canonicalSessionTarget(sessionKey)
  const payload = job.payload && typeof job.payload === 'object' && job.payload.kind === 'agentTurn'
    ? {
        ...job.payload,
        sessionTarget,
      }
    : job.payload

  if (job.sessionKey === sessionKey && job.sessionTarget === sessionTarget && payload === job.payload) {
    return job
  }

  const patch = {
    sessionTarget,
    ...(payload && payload !== job.payload ? { payload } : {}),
  }

  const result = await gatewayCronHttpForJob({ ...job, sessionKey, sessionTarget }, 'cron.update', {
    id: job.id,
    patch,
  })
  if (!result.ok) {
    console.warn('[Cron] canonical session target patch failed:', {
      id: job.id,
      sessionKey,
      error: result.error,
    })
    return canonicalCronJob(job)
  }

  const nextJob = canonicalCronJob({ ...job, ...patch, updatedAtMs: Date.now() })
  upsertCronJob(nextJob)
  return nextJob
}

function advanceCronSessionActivity(job, occurredAt = new Date().toISOString()) {
  const sessionKey = jobSessionKey(job)
  if (!sessionKey) return
  const result = advanceSessionLastMessageAt(sessionKey, occurredAt)
  console.info('[Cron] session activity advanced', {
    sessionKey,
    ...result,
  })
}

async function gatewayRpcForJob(job, method, params) {
  const sessionKey = jobSessionKey(job)
  const tenantId = resolveTenantIdForSession(sessionKey) || resolveTenantIdForAgent(job?.agentId)
  if (!tenantId) return gatewayAdminRpc(method, params)

  const target = await getGatewayHttpTargetForTenantId(tenantId)
  return gatewayAdminRpcForTarget(target, method, params)
}

async function gatewayRpcForAgent(agentId, method, params) {
  const tenantId = resolveTenantIdForAgent(agentId)
  if (!tenantId) return gatewayAdminRpc(method, params)

  const target = await getGatewayHttpTargetForTenantId(tenantId)
  return gatewayAdminRpcForTarget(target, method, params)
}

async function gatewayCronHttpForJob(job, method, params) {
  const sessionKey = jobSessionKey(job)
  const tenantId = resolveTenantIdForSession(sessionKey) || resolveTenantIdForAgent(job?.agentId)
  if (!tenantId) return gatewayAdminRpc(method, params)

  const target = await getGatewayHttpTargetForTenantId(tenantId)
  return gatewayAdminRpcForTarget(target, method, params)
}

function unwrapGatewayHttpPayload(result) {
  const data = result?.data
  if (data && typeof data === 'object' && 'payload' in data) return data.payload
  return data
}

export function createCronRoutes(app) {
  app.get('/api/cron/overview', authMiddleware, async (req, res) => {
    try {
      const [jobsResult, statusResult] = await Promise.allSettled([
        refreshVisibleCronJobs(req).then(() => listVisibleCronJobs(req)),
        getCronStatusPayload(),
      ])

      if (jobsResult.status === 'rejected') throw jobsResult.reason
      if (statusResult.status === 'rejected') {
        console.error('[Cron] status error:', getErrorMessage(statusResult.reason))
      }

      return sendOk(res, {
        jobs: jobsResult.value,
        status: statusResult.status === 'fulfilled' ? statusResult.value : null,
      })
    } catch (error) {
      console.error('[Cron] overview error:', getErrorMessage(error))
      return res.status(502).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.get('/api/cron/jobs', authMiddleware, async (req, res) => {
    try {
      await refreshVisibleCronJobs(req)
      return sendOk(res, listVisibleCronJobs(req))
    } catch (error) {
      console.error('[Cron] list error:', getErrorMessage(error))
      return res.status(502).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.get('/api/cron/status', authMiddleware, async (_req, res) => {
    try {
      return sendOk(res, await getCronStatusPayload())
    } catch (error) {
      console.error('[Cron] status error:', getErrorMessage(error))
      return res.status(502).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.get('/api/cron/jobs/:id/runs', authMiddleware, async (req, res) => {
    try {
      if (!assertCanUseJob(req, req.params.id)) {
        return res.status(403).json({ ok: false, error: { message: 'Forbidden' } })
      }

      const job = getCronJobById(req.params.id)
      const result = await gatewayRpcForJob(job, 'cron.runs', {
        id: req.params.id,
        limit: Number(req.query.limit || 50),
      })
      if (!result.ok) return sendGatewayError(res, result)
      return sendOk(res, result.payload)
    } catch (error) {
      console.error('[Cron] runs error:', getErrorMessage(error))
      return res.status(500).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.post('/api/cron/jobs', authMiddleware, async (req, res) => {
    try {
      const incomingParams = extractParams(req)
      logCronCreateStep('received', {
        userId: req.currentUser?.id,
        role: req.currentUser?.role,
        params: incomingParams,
      })
      if (!assertCanUseAgent(req, incomingParams.agentId)) {
        logCronCreateStep('forbidden', {
          userId: req.currentUser?.id,
          agentId: incomingParams.agentId,
        })
        return res.status(403).json({ ok: false, error: { message: 'Forbidden' } })
      }

      const prepared = prepareCronCreateParams(incomingParams)
      const normalizedParams = canonicalCronJob(prepared.params)
      const effectiveAgentId = resolveCronAgentId(normalizedParams) || resolveCronAgentId(incomingParams)
      const tenantId = resolveTenantIdForAgent(effectiveAgentId)
      const target = tenantId ? await getGatewayHttpTargetForTenantId(tenantId) : null
      const gatewayParams = buildCronAddParams({ ...normalizedParams, agentId: effectiveAgentId })
      logCronCreateStep('normalized', {
        agentId: effectiveAgentId || normalizedParams.agentId,
        target: target ? {
          baseUrl: target.baseUrl,
          hasAuthHeader: Boolean(target.headers?.Authorization),
        } : null,
        body: normalizedParams,
        gatewayParams,
      })

      logCronCreateStep('gateway-request', {
        method: 'cron.add',
        body: gatewayParams,
      })

      const result = await gatewayRpcForAgent(effectiveAgentId, 'cron.add', gatewayParams)
      if (!result.ok) {
        logCronCreateStep('gateway-failed', {
          error: result.error,
          body: gatewayParams,
        })
        return sendGatewayError(res, result)
      }

      logCronCreateStep('gateway-success', {
        result: unwrapGatewayHttpPayload(result),
      })

      // Upsert to SQLite — prefer Gateway result (has computed fields), fallback to params with explicit id
      const payload = unwrapGatewayHttpPayload(result)
      const upsertData = payload && typeof payload === 'object'
        ? payload
        : { ...normalizedParams, id: payload?.id || normalizedParams.id }
      upsertCronJob(upsertData)
      const createdJobId = asString(upsertData.id || upsertData.jobId || normalizedParams.id).trim()
      if (createdJobId && prepared.binding) {
        upsertCronSessionBinding({
          jobId: createdJobId,
          ...prepared.binding,
        })
      }
      logCronCreateStep('sqlite-upserted', {
        id: createdJobId,
      })

      return sendOk(res, payload || true)
    } catch (error) {
      console.error('[Cron] create error:', getErrorMessage(error), sanitizeCronLogValue({
        userId: req.currentUser?.id,
        error,
      }))
      return res.status(500).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.patch('/api/cron/jobs/:id', authMiddleware, async (req, res) => {
    try {
      if (!assertCanUseJob(req, req.params.id)) {
        return res.status(403).json({ ok: false, error: { message: 'Forbidden' } })
      }

      const existing = getCronJobById(req.params.id)
      const patch = canonicalCronJob(omitCronAgentId(normalizeCronUpdatePatch(extractParams(req))))
      const result = await gatewayCronHttpForJob(existing, 'cron.update', {
        id: req.params.id,
        patch,
      })
      if (!result.ok) return sendGatewayError(res, result)

      if (existing) {
        const isScheduleObject = typeof patch.schedule === 'object'
        const isScheduleString = typeof patch.schedule === 'string'
        upsertCronJob({
          ...existing,
          ...patch,
          // If patch sends CronSchedule object → replace scheduleObj so upsertCronJob extracts new text
          // If patch sends text string → use directly, keep existing scheduleObj
          // If patch has no schedule → preserve both existing fields
          scheduleObj: isScheduleObject ? patch.schedule : existing.scheduleObj,
          schedule: isScheduleString ? patch.schedule : existing.schedule,
          id: req.params.id,
          updatedAtMs: Date.now(),
        })
      }
      if (typeof patch.name === 'string' && patch.name.trim()) {
        updateCronSessionBindingName(req.params.id, cronSessionDisplayName(patch.name))
      }

      return sendOk(res, true)
    } catch (error) {
      console.error('[Cron] update error:', getErrorMessage(error))
      return res.status(500).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.delete('/api/cron/jobs/:id', authMiddleware, async (req, res) => {
    try {
      if (!assertCanUseJob(req, req.params.id)) {
        return res.status(403).json({ ok: false, error: { message: 'Forbidden' } })
      }

      const existing = getCronJobById(req.params.id)
      const result = await gatewayCronHttpForJob(existing, 'cron.remove', { id: req.params.id })
      if (!result.ok) return sendGatewayError(res, result)

      // Remove from SQLite
      deleteCronJob(req.params.id)

      return sendOk(res, true)
    } catch (error) {
      console.error('[Cron] delete error:', getErrorMessage(error))
      return res.status(500).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })

  app.post('/api/cron/jobs/:id/run', authMiddleware, async (req, res) => {
    try {
      if (!assertCanUseJob(req, req.params.id)) {
        return res.status(403).json({ ok: false, error: { message: 'Forbidden' } })
      }

      let existing = getCronJobById(req.params.id)
      existing = await patchGatewayJobSessionTarget(existing)
      trackCronRunSession(req, existing, null)
      advanceCronSessionActivity(existing)
      await backfillCronOutputSession(existing).catch((error) => {
        console.warn('[Cron] pre-run history backfill error:', getErrorMessage(error))
      })
      const runParams = {
        jobId: req.params.id,
        mode: extractParams(req).mode || 'force',
      }
      const result = await gatewayCronHttpForJob(existing, 'cron.run', runParams)
      if (!result.ok) return sendGatewayError(res, result)
      trackCronRunSession(req, existing, unwrapGatewayHttpPayload(result))
      advanceCronSessionActivity(existing)
      return sendOk(res, unwrapGatewayHttpPayload(result) || true)
    } catch (error) {
      console.error('[Cron] run error:', getErrorMessage(error))
      return res.status(500).json({ ok: false, error: { message: getErrorMessage(error) } })
    }
  })
}
