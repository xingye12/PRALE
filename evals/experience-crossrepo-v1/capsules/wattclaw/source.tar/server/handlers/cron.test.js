import { describe, expect, it, vi } from 'vitest'

vi.mock('../core/auth.js', () => ({
  authMiddleware: (_req, _res, next) => next(),
}))

vi.mock('../core/gateway-client.js', () => ({
  gatewayAdminRpc: vi.fn(),
  gatewayAdminRpcForTarget: vi.fn(),
  fetchHistoryFromGateway: vi.fn(),
}))

vi.mock('../core/multi-tenant-gateway.js', () => ({
  getGatewayHttpTargetForTenantId: vi.fn(),
}))

vi.mock('../cron-manager.js', () => ({
  listCronJobsFromDb: vi.fn(() => []),
  isCronJobOwnedBy: vi.fn(() => true),
  isAgentOwnedBy: vi.fn(() => true),
  upsertCronJob: vi.fn(),
  deleteCronJob: vi.fn(),
  getCronJobById: vi.fn(),
  refreshCronJobsForScope: vi.fn(),
  upsertCronSessionBinding: vi.fn(),
  updateCronSessionBindingName: vi.fn(),
}))

vi.mock('../user-manager.js', () => ({
  getUserOwnedAgentIds: vi.fn(() => []),
  resolveTenantIdForAgent: vi.fn(),
  resolveTenantIdForSession: vi.fn(),
  trackSessionForUser: vi.fn(),
}))

vi.mock('../message-store.js', () => ({
  isReady: vi.fn(() => false),
  mergeSessionMessages: vi.fn(),
}))

vi.mock('../services/session-activity-service.js', () => ({
  advanceSessionLastMessageAt: vi.fn(),
  recomputeSessionLastMessageAt: vi.fn(),
}))

const { prepareCronCreateParams, singleflight } = await import('./cron.js')

describe('cron route helpers', () => {
  it('coalesces concurrent calls with the same singleflight key', async () => {
    let calls = 0
    const factory = async () => {
      calls += 1
      return ['cron-list']
    }

    const [first, second] = await Promise.all([
      singleflight('cron.list', factory),
      singleflight('cron.list', factory),
    ])

    expect(first).toEqual(['cron-list'])
    expect(second).toEqual(['cron-list'])
    expect(calls).toBe(1)
  })

  it('allows a completed singleflight key to run again', async () => {
    let calls = 0
    const factory = async () => {
      calls += 1
      return calls
    }

    await singleflight('cron.status', factory)
    const second = await singleflight('cron.status', factory)

    expect(second).toBe(2)
    expect(calls).toBe(2)
  })

  it('creates a dedicated session target only for opted-in new jobs', () => {
    const result = prepareCronCreateParams({
      name: '每日情报官自动汇总任务',
      agentId: 'analyst',
      createDedicatedSession: true,
      payload: { kind: 'agentTurn', text: '生成日报' },
    }, () => 'job-session-id')

    expect(result.params.createDedicatedSession).toBeUndefined()
    expect(result.params.sessionKey).toBe('agent:analyst:cron-task:job-session-id')
    expect(result.params.sessionTarget).toBe('session:agent:analyst:cron-task:job-session-id')
    expect(result.binding).toEqual({
      sessionKey: 'agent:analyst:cron-task:job-session-id',
      agentId: 'analyst',
      displayName: '每日情报官自动汇总任',
    })
  })

  it('leaves existing session targets unchanged without the opt-in flag', () => {
    const result = prepareCronCreateParams({
      name: '旧任务',
      agentId: 'analyst',
      sessionTarget: 'session:agent:analyst:main:dm:existing',
      payload: { kind: 'agentTurn', text: '继续执行' },
    }, () => 'unused')

    expect(result.params.sessionTarget).toBe('session:agent:analyst:main:dm:existing')
    expect(result.binding).toBeNull()
  })
})
