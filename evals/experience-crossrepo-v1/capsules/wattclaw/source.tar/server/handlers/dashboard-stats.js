// Dashboard stats aggregation — single endpoint for lightweight stat cards
// Replaces 6 separate Phase 1 calls from the frontend dashboard.
import { authMiddleware } from '../core/auth.js'
import { listCronJobsFromDb } from '../cron-manager.js'
import db from '../database.js'

// Pre-compiled statements for hot-path queries (<1ms each)
const stmtSessionCount = db.prepare(
  'SELECT COUNT(*) as count FROM user_sessions WHERE user_id = ?'
)
const stmtSessionCountAdmin = db.prepare(
  'SELECT COUNT(*) as count FROM user_sessions'
)
const stmtInstalledSkills = db.prepare(
  'SELECT COUNT(*) as count FROM skill_store_skill WHERE installed = 1'
)
const stmtModelCount = db.prepare(
  'SELECT COUNT(*) as count FROM models WHERE available = 1 AND enabled = 1'
)
const stmtCachedTokenTotal = db.prepare(
  'SELECT COALESCE(SUM(token_total), 0) as total FROM user_sessions WHERE user_id = ? AND usage_synced_at IS NOT NULL'
)

export function createDashboardStatsRoutes(app) {
  app.get('/api/dashboard/stats', authMiddleware, async (req, res) => {
    const apmStart = performance.now()
    try {
      const userId = req.currentUser.id
      const isAdmin = req.currentUser.role === 'admin'

      // --- SQLite queries (synchronous, <1ms) ---
      const sessionCount = isAdmin
        ? stmtSessionCountAdmin.get().count
        : stmtSessionCount.get(userId).count

      const installedSkills = stmtInstalledSkills.get().count
      const modelCount = isAdmin ? stmtModelCount.get().count : 0

      const cachedTokenRow = stmtCachedTokenTotal.get(userId)
      const cachedTokenTotal = cachedTokenRow?.total > 0 ? cachedTokenRow.total : null

      // --- SQLite: cron count (synchronous, <1ms) ---
      const cronCount = listCronJobsFromDb({ isAdmin, userId })
        .filter(j => j.enabled !== false).length

      const totalMs = (performance.now() - apmStart).toFixed(1)
      console.log(`[APM - DashboardStats] GET /api/dashboard/stats ${totalMs}ms`)

      return res.json({
        ok: true,
        stats: { sessionCount, cronCount, modelCount, installedSkills },
        cachedTokenTotal,
      })
    } catch (err) {
      console.error('[DashboardStats] error:', err.message)
      return res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}
