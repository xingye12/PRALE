// Feishu OAuth auth routes: config, authorize, callback
import { isFeishuAuthEnabled, buildAuthorizeUrl, handleFeishuCallback } from '../core/feishu-oauth.js'
import { createAuthToken, getUserById } from '../user-manager.js'

export function createFeishuAuthRoutes(app) {
  // GET /api/auth/feishu/config — frontend checks if feishu login is enabled
  app.get('/api/auth/feishu/config', (_req, res) => {
    res.json({ enabled: isFeishuAuthEnabled() })
  })

  // GET /api/auth/feishu/authorize — generate state + return full authorization URL
  app.get('/api/auth/feishu/authorize', (req, res) => {
    const result = buildAuthorizeUrl(req.ip)
    if (!result) {
      return res.status(400).json({ error: '飞书登录未配置' })
    }
    if (result.error === 'rate_limited') {
      return res.status(429).json({ error: '请求过于频繁，请稍后再试' })
    }
    res.json({ url: result.url })
  })

  // POST /api/auth/feishu/callback — receive code+state, complete OAuth flow
  app.post('/api/auth/feishu/callback', async (req, res) => {
    const { code, state } = req.body
    if (!code || !state) {
      return res.status(400).json({ ok: false, error: '参数缺失' })
    }

    try {
      const result = await handleFeishuCallback(code, state)
      if (!result.ok) {
        return res.status(result.status).json({ ok: false, error: result.error })
      }

      // Verify user still active
      const user = getUserById(result.userId)
      if (!user || user.status !== 'active') {
        return res.status(403).json({ ok: false, error: '账号已被禁用' })
      }

      // Issue WattClaw internal token (same flow as password login)
      const { token, expiresAt } = createAuthToken(user.id, req.headers['user-agent'], req.ip)
      res.json({ ok: true, token, user, expiresAt })
    } catch (e) {
      console.error('[FeishuAuth] Callback error:', e.message)
      res.status(500).json({ ok: false, error: '飞书登录失败' })
    }
  })
}
