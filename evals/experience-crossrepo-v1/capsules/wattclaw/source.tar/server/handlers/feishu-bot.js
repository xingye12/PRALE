import { authMiddleware } from '../core/auth.js'
import db from '../database.js'
import {
  getFeishuPermissionUrl,
  getUserFeishuBot,
  removeUserFeishuBot,
  saveUserFeishuBot,
  verifyUserFeishuBot,
} from '../services/feishu-project-sync.js'

export function errorStatus(error) {
  if (error?.code === 1061004 || error?.code === 99991672) return 403
  if (String(error?.message || '').includes('UNIQUE constraint failed')) return 409
  return 400
}

export function errorMessage(error) {
  if (String(error?.message || '').includes('UNIQUE constraint failed: user_feishu_bots.app_id')) {
    return '该飞书机器人已被其他用户绑定'
  }
  return error?.message || '飞书机器人操作失败'
}

export function createFeishuBotRoutes(app) {
  app.get('/api/user/feishu-bot', authMiddleware, (req, res) => {
    const bot = getUserFeishuBot(req.currentUser.id)
    res.json({
      ok: true,
      bound: !!bot,
      bot,
      permissionUrl: getFeishuPermissionUrl(bot?.appId),
    })
  })

  app.put('/api/user/feishu-bot', authMiddleware, async (req, res) => {
    try {
      let { ownerOpenId } = req.body
      if (!ownerOpenId) {
        const binding = db.prepare(
          'SELECT open_id FROM user_oauth_bindings WHERE user_id = ? AND provider = ?',
        ).get(req.currentUser.id, 'feishu')
        if (!binding?.open_id) {
          res.status(400).json({ ok: false, error: '未找到飞书登录绑定信息，请先使用飞书扫码登录或扫码绑定机器人' })
          return
        }
        ownerOpenId = binding.open_id
      }
      const bot = await saveUserFeishuBot(req.currentUser.id, { ...req.body, ownerOpenId })
      res.json({
        ok: true,
        bound: true,
        bot,
        permissionUrl: getFeishuPermissionUrl(bot.appId),
      })
    } catch (error) {
      console.error('[FeishuBot] bind failed:', error.message)
      res.status(errorStatus(error)).json({ ok: false, error: errorMessage(error) })
    }
  })

  app.post('/api/user/feishu-bot/check', authMiddleware, async (req, res) => {
    const result = await verifyUserFeishuBot(req.currentUser.id)
    res.status(result.bound && !result.valid ? 400 : 200).json({
      ok: result.valid,
      ...result,
      permissionUrl: getFeishuPermissionUrl(result.bot?.appId),
    })
  })

  app.get('/api/user/feishu-bot/openid', authMiddleware, (req, res) => {
    const binding = db.prepare(
      'SELECT open_id FROM user_oauth_bindings WHERE user_id = ? AND provider = ?',
    ).get(req.currentUser.id, 'feishu')
    res.json({ open_id: binding?.open_id || null })
  })

  app.delete('/api/user/feishu-bot', authMiddleware, (req, res) => {
    removeUserFeishuBot(req.currentUser.id)
    res.json({ ok: true })
  })
}
