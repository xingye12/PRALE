// Feishu proxy routes
import { authMiddleware } from '../core/auth.js'
import {
  extractFeishuRegistrationOpenId,
  saveUserFeishuBot,
} from '../services/feishu-project-sync.js'
import { errorMessage, errorStatus } from './feishu-bot.js'

const FEISHU_ALLOWED_FIELDS = new Set([
  'app_id', 'app_secret', 'app_ticket', 'grant_type',
  'action', 'archetype', 'auth_method', 'request_user_info',
  'device_code', 'tp', 'from',
])

function buildSafeParams(body) {
  const params = new URLSearchParams()
  if (!body || typeof body !== 'object') return params
  for (const [key, value] of Object.entries(body)) {
    if (FEISHU_ALLOWED_FIELDS.has(key) && typeof value === 'string') {
      params.set(key, value)
    }
  }
  return params
}

const SENSITIVE_RESPONSE_FIELDS = new Set([
  'access_token',
  'client_secret',
  'refresh_token',
  'session_key',
  'password',
])

function stripSensitiveFields(data) {
  if (!data || typeof data !== 'object') return data
  const safe = { ...data }
  for (const key of Object.keys(safe)) {
    if (SENSITIVE_RESPONSE_FIELDS.has(key)) delete safe[key]
  }
  return safe
}

export function createFeishuProxyRoutes(app) {
  app.post('/api/proxy/feishu/register', authMiddleware, async (req, res) => {
    try {
      const response = await fetch('https://accounts.feishu.cn/oauth/v1/app/registration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: buildSafeParams(req.body),
      })
      const data = await response.json()
      res.json(stripSensitiveFields(data))
    } catch (err) {
      console.error('[Proxy] Feishu register error:', err.message)
      res.status(500).json({ error: err.message })
    }
  })

  app.post('/api/proxy/feishu/poll', authMiddleware, async (req, res) => {
    try {
      const response = await fetch('https://accounts.feishu.cn/oauth/v1/app/registration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: buildSafeParams(req.body),
      })
      const data = await response.json()
      if (data.client_id && data.client_secret) {
        const ownerOpenId = extractFeishuRegistrationOpenId(data)
        try {
          const bot = await saveUserFeishuBot(req.currentUser.id, {
            appId: data.client_id,
            appSecret: data.client_secret,
            ownerOpenId,
          })
          return res.json({
            ...stripSensitiveFields(data),
            botBound: true,
            bot,
          })
        } catch (bindErr) {
          // 绑定校验失败（如同一飞书应用已被其他用户绑定，触发 app_id 唯一约束）
          // 返回可读提示，避免前端只拿到原始 SQL 错误而反复轮询失败。
          console.error('[Proxy] Feishu bind failed:', bindErr.message)
          return res.status(errorStatus(bindErr)).json({
            ...stripSensitiveFields(data),
            botBound: false,
            error: errorMessage(bindErr),
          })
        }
      }
      res.json(stripSensitiveFields(data))
    } catch (err) {
      console.error('[Proxy] Feishu poll error:', err.message)
      res.status(500).json({ error: err.message })
    }
  })
}
