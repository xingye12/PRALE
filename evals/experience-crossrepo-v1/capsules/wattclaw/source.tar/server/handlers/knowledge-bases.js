import multer from 'multer'
import { authMiddleware } from '../core/auth.js'
import {
  bindKnowledgeBase,
  deleteKnowledgeBaseBindings,
  getKnowledgeBaseBinding,
  listKnowledgeBaseBindings,
  syncKnowledgeBaseCatalog,
  updateKnowledgeBaseVisibility,
} from '../database.js'
import {
  createRagflowDataset,
  deleteRagflowDatasets,
  deleteRagflowDocuments,
  isRagflowConfigError,
  listRagflowDatasets,
  listRagflowDocuments,
  listRagflowEmbeddingModels,
  parseRagflowDocuments,
  uploadRagflowDocuments,
} from '../services/ragflow-rest.js'

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024, files: 20 },
  defParamCharset: 'utf8',
})

function isAdmin(user) {
  return user?.role === 'admin'
}

function getDatasetId(dataset) {
  return String(dataset?.id || dataset?.dataset_id || dataset?.kb_id || '')
}

function getDocumentId(document) {
  return String(document?.id || document?.document_id || document?.doc_id || '')
}

function stripUserPrefix(name) {
  return String(name || '').replace(/^\[u[^\]]+\]_\d{4}-\d{2}-\d{2}_/, '')
}

function inferUserIdFromDatasetName(name) {
  const match = String(name || '').match(/^\[u([^\]]+)\]_\d{4}-\d{2}-\d{2}_/)
  return match?.[1] || null
}

function buildDatasetName(user, rawName) {
  const date = new Date().toISOString().slice(0, 10)
  return `[u${user.id}]_${date}_${String(rawName || '').trim()}`
}

function normalizeDataset(dataset, binding, user) {
  const rawName = dataset?.name || dataset?.title || ''
  const admin = isAdmin(user)
  return {
    id: getDatasetId(dataset),
    name: admin ? rawName : stripUserPrefix(rawName),
    rawName,
    description: dataset?.description || '',
    permission: dataset?.permission || '',
    documentCount: Number(dataset?.document_count || dataset?.doc_num || dataset?.docs_count || 0),
    chunkCount: Number(dataset?.chunk_count || dataset?.chunk_num || 0),
    createdAt: dataset?.create_time || dataset?.created_at || dataset?.create_date || '',
    updatedAt: dataset?.update_time || dataset?.updated_at || '',
    creatorId: binding?.user_id || '',
    creator: binding?.display_name || binding?.username || '',
    ownerUsername: binding?.username || '',
    mine: Boolean(binding?.user_id && binding.user_id === user?.id),
    managedByMe: Boolean(isAdmin(user) || (binding?.user_id && binding.user_id === user?.id)),
    isPublic: Boolean(binding?.is_public),
    publicLabel: binding?.is_public ? 'public' : 'private',
    descriptionSnapshot: binding?.description_snapshot || '',
    ragflowPermission: binding?.ragflow_permission || '',
    unbound: !binding,
  }
}

function normalizeDocument(document) {
  return {
    id: getDocumentId(document),
    name: document?.name || document?.filename || document?.file_name || '',
    size: Number(document?.size || document?.file_size || 0),
    type: document?.type || document?.extension || '',
    status: document?.status || document?.run || document?.progress || '',
    chunkCount: Number(document?.chunk_count || document?.chunk_num || 0),
    createdAt: document?.create_time || document?.created_at || '',
    updatedAt: document?.update_time || document?.updated_at || '',
  }
}

function normalizeDocumentList(data) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.documents)) return data.documents
  if (Array.isArray(data?.docs)) return data.docs
  if (Array.isArray(data?.items)) return data.items
  if (Array.isArray(data?.data)) return data.data
  return []
}

function canAccessKnowledgeBase(user, ragflowKbId, mode = 'view') {
  if (isAdmin(user)) return { ok: true, binding: getKnowledgeBaseBinding(ragflowKbId) }
  const binding = getKnowledgeBaseBinding(ragflowKbId)
  if (mode === 'view' && binding?.is_public) return { ok: true, binding }
  if (binding?.user_id === user?.id) return { ok: true, binding }
  return { ok: false, binding }
}

function canManageKnowledgeBase(user, ragflowKbId) {
  const binding = getKnowledgeBaseBinding(ragflowKbId)
  if (!binding) return { ok: false, binding: null }
  if (isAdmin(user)) return { ok: true, binding }
  if (binding.user_id === user?.id) return { ok: true, binding }
  return { ok: false, binding }
}

function canUpdateKnowledgeVisibility(user, ragflowKbId) {
  return canManageKnowledgeBase(user, ragflowKbId)
}

async function resolveEmbeddingModel(requestedModel) {
  if (requestedModel) return requestedModel
  const models = await listRagflowEmbeddingModels()
  if (models.length === 0) throw new Error('No embedding model is available in RAGFlow')
  return models[0].id
}

function sendKnowledgeError(res, action, err) {
  const message = err instanceof Error ? err.message : 'Knowledge base request failed'
  if (isRagflowConfigError(err)) {
    console.warn(`[KnowledgeBases] ${action} config error: ${message}`)
    return res.status(503).json({ ok: false, error: { message, code: 'RAGFLOW_NOT_CONFIGURED' } })
  }
  console.error(`[KnowledgeBases] ${action} error:`, err)
  return res.status(500).json({ ok: false, error: { message } })
}

export function createKnowledgeBaseRoutes(app) {
  app.get('/api/knowledge-bases', authMiddleware, async (req, res) => {
    try {
      console.log('[KnowledgeBases] list start:', { userId: req.currentUser?.id })
      const datasets = await listRagflowDatasets(req.query)
      const bindingMap = new Map(listKnowledgeBaseBindings().map(binding => [binding.ragflow_kb_id, binding]))
      const normalizedDatasets = datasets.map((dataset) => {
        const datasetId = getDatasetId(dataset)
        const binding = bindingMap.get(datasetId)
        const inferredUserId = binding?.user_id || inferUserIdFromDatasetName(dataset?.name || dataset?.title || '')
        return {
          datasetId,
          dataset,
          normalized: normalizeDataset(dataset, binding, req.currentUser),
          binding,
          inferredUserId,
        }
      })
      syncKnowledgeBaseCatalog(normalizedDatasets.map(({ datasetId, normalized, binding }) => ({
        ragflowKbId: datasetId,
        userId: binding?.user_id || normalized.creatorId || normalized.ownerUsername || inferUserIdFromDatasetName(normalized.rawName) || null,
        nameSnapshot: normalized.rawName || normalized.name,
        descriptionSnapshot: normalized.description || '',
        ragflowPermission: normalized.permission || '',
        isPublic: binding?.is_public ?? (normalized.permission === 'all' || normalized.permission === 'public'),
        documentCount: normalized.documentCount,
        chunkCount: normalized.chunkCount,
        ragflowCreatedAt: normalized.createdAt || null,
        ragflowUpdatedAt: normalized.updatedAt || null,
      })))
      const refreshedBindings = new Map(listKnowledgeBaseBindings().map(binding => [binding.ragflow_kb_id, binding]))
      const items = normalizedDatasets
        .map(({ datasetId, dataset }) => normalizeDataset(dataset, refreshedBindings.get(datasetId), req.currentUser))
        .filter(item => item.id && (
          isAdmin(req.currentUser)
          || item.isPublic
          || item.managedByMe
        ))

      console.log('[KnowledgeBases] list success:', { userId: req.currentUser?.id, count: items.length })
      res.json({ ok: true, items })
    } catch (err) {
      sendKnowledgeError(res, 'list', err)
    }
  })

  app.get('/api/knowledge-bases/embedding-models', authMiddleware, async (_req, res) => {
    try {
      const models = await listRagflowEmbeddingModels()
      res.json({ ok: true, models })
    } catch (err) {
      sendKnowledgeError(res, 'models', err)
    }
  })

  app.post('/api/knowledge-bases', authMiddleware, async (req, res) => {
    try {
      const name = String(req.body?.name || '').trim()
      if (!name) {
        return res.status(400).json({ ok: false, error: { message: 'Knowledge base name is required' } })
      }

      const embeddingModel = await resolveEmbeddingModel(req.body?.embeddingModel || req.body?.embedding_model)
      const created = await createRagflowDataset({
        name: buildDatasetName(req.currentUser, name),
        description: req.body?.description || '',
        embedding_model: embeddingModel,
        chunk_method: req.body?.chunkMethod || req.body?.chunk_method || 'naive',
        permission: req.body?.permission || 'me',
        parser_config: req.body?.parserConfig || req.body?.parser_config,
      })
      const datasetId = getDatasetId(created) || getDatasetId(created?.dataset)
      if (!datasetId) {
        throw new Error('RAGFlow did not return a knowledge base id')
      }
      const binding = syncKnowledgeBaseCatalog([{
        ragflowKbId: datasetId,
        userId: req.currentUser.id,
        nameSnapshot: created?.dataset?.name || created?.name || name,
        descriptionSnapshot: created?.dataset?.description || created?.description || req.body?.description || '',
        ragflowPermission: created?.dataset?.permission || created?.permission || req.body?.permission || 'me',
        isPublic: req.body?.isPublic ?? req.body?.is_public ?? req.body?.public ?? false,
        documentCount: created?.dataset?.document_count || created?.document_count || 0,
        chunkCount: created?.dataset?.chunk_count || created?.chunk_count || 0,
        ragflowCreatedAt: created?.dataset?.create_time || created?.create_time || null,
        ragflowUpdatedAt: created?.dataset?.update_time || created?.update_time || null,
      }])[0] || bindKnowledgeBase(datasetId, req.currentUser.id, name)
      updateKnowledgeBaseVisibility(datasetId, req.body?.isPublic ?? req.body?.is_public ?? req.body?.public ?? false)
      res.json({ ok: true, item: normalizeDataset(created?.dataset || created, binding, req.currentUser) })
    } catch (err) {
      sendKnowledgeError(res, 'create', err)
    }
  })

  app.delete('/api/knowledge-bases', authMiddleware, async (req, res) => {
    try {
      const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String).filter(Boolean) : []
      if (ids.length === 0) {
        return res.status(400).json({ ok: false, error: { message: 'ids array is required' } })
      }
      const denied = ids.filter(id => !canAccessKnowledgeBase(req.currentUser, id, 'manage').ok)
      if (denied.length > 0) {
        return res.status(403).json({ ok: false, error: { message: 'No permission for selected knowledge bases' } })
      }
      await deleteRagflowDatasets(ids)
      deleteKnowledgeBaseBindings(ids)
      res.json({ ok: true, deleted: ids })
    } catch (err) {
      sendKnowledgeError(res, 'delete', err)
    }
  })

  app.patch('/api/knowledge-bases/:id/visibility', authMiddleware, async (req, res) => {
    try {
      const access = canUpdateKnowledgeVisibility(req.currentUser, req.params.id)
      if (!access.ok) {
        return res.status(403).json({ ok: false, error: { message: 'No permission for this knowledge base' } })
      }
      const isPublic = Boolean(req.body?.isPublic ?? req.body?.is_public ?? req.body?.public)
      const binding = updateKnowledgeBaseVisibility(req.params.id, isPublic)
      if (!binding) {
        return res.status(404).json({ ok: false, error: { message: 'Knowledge base not found' } })
      }
      res.json({
        ok: true,
        item: {
          id: req.params.id,
          isPublic: Boolean(binding.is_public),
          publicLabel: binding.is_public ? 'public' : 'private',
        },
      })
    } catch (err) {
      sendKnowledgeError(res, 'visibility update', err)
    }
  })

  app.get('/api/knowledge-bases/:id/documents', authMiddleware, async (req, res) => {
    try {
      console.log('[KnowledgeBases] documents list start:', { datasetId: req.params.id, userId: req.currentUser?.id })
      const access = canAccessKnowledgeBase(req.currentUser, req.params.id, 'view')
      if (!access.ok) {
        return res.status(403).json({ ok: false, error: { message: 'No permission for this knowledge base' } })
      }
      const documents = await listRagflowDocuments(req.params.id, req.query)
      const normalized = documents.map(normalizeDocument)
      console.log('[KnowledgeBases] documents list success:', { datasetId: req.params.id, count: normalized.length })
      res.json({ ok: true, documents: normalized })
    } catch (err) {
      sendKnowledgeError(res, 'documents', err)
    }
  })

  app.post('/api/knowledge-bases/:id/documents', authMiddleware, upload.array('file', 20), async (req, res) => {
    try {
      console.log('[KnowledgeBases] upload start:', {
        datasetId: req.params.id,
        userId: req.currentUser?.id,
        files: Array.isArray(req.files) ? req.files.map(file => ({ name: file.originalname, size: file.size })) : [],
      })
      const access = canAccessKnowledgeBase(req.currentUser, req.params.id, 'manage')
      if (!access.ok) {
        return res.status(403).json({ ok: false, error: { message: 'No permission for this knowledge base' } })
      }
      if (!Array.isArray(req.files) || req.files.length === 0) {
        return res.status(400).json({ ok: false, error: { message: 'No files uploaded' } })
      }
      const result = await uploadRagflowDocuments(req.params.id, req.files)
      const documents = normalizeDocumentList(result).map(normalizeDocument)
      const shouldParse = req.body?.parse !== 'false'
      const documentIds = documents.map(doc => doc.id).filter(Boolean)
      let parseError = ''
      if (shouldParse && documentIds.length > 0) {
        try {
          await parseRagflowDocuments(req.params.id, documentIds)
        } catch (err) {
          parseError = err instanceof Error ? err.message : 'Document parsing failed'
          console.error('[KnowledgeBases] document parse failed after upload:', err)
        }
      }
      res.json({
        ok: true,
        documents,
        result,
        parseStarted: shouldParse && documentIds.length > 0 && !parseError,
        parseError: parseError || undefined,
      })
      console.log('[KnowledgeBases] upload success:', {
        datasetId: req.params.id,
        documentCount: documents.length,
        parseStarted: shouldParse && documentIds.length > 0 && !parseError,
      })
    } catch (err) {
      sendKnowledgeError(res, 'upload', err)
    }
  })

  app.delete('/api/knowledge-bases/:id/documents', authMiddleware, async (req, res) => {
    try {
      const access = canAccessKnowledgeBase(req.currentUser, req.params.id, 'manage')
      if (!access.ok) {
        return res.status(403).json({ ok: false, error: { message: 'No permission for this knowledge base' } })
      }
      const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String).filter(Boolean) : []
      if (ids.length === 0) {
        return res.status(400).json({ ok: false, error: { message: 'ids array is required' } })
      }
      await deleteRagflowDocuments(req.params.id, ids)
      res.json({ ok: true, deleted: ids })
    } catch (err) {
      sendKnowledgeError(res, 'document delete', err)
    }
  })
}
