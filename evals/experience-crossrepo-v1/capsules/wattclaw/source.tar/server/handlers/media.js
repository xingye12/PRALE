// Media serving route — serves files from Gateway media directories
import { authMiddleware } from '../core/auth.js'
import { envConfig } from '../core/index.js'
import { join, resolve, extname, sep } from 'path'
import { existsSync, statSync, createReadStream, realpathSync } from 'fs'
import os from 'os'

// Only serve these file types
const ALLOWED_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.mp4', '.webm', '.mp3', '.wav', '.pdf'])

export function createMediaRoutes(app) {
  app.get('/api/media', authMiddleware, (req, res) => {
    try {
      const path = req.query.path
      if (!path) {
        return res.status(400).json({ ok: false, error: { message: 'Path parameter is required' } })
      }

      console.log('[Media] Request path:', path)

      // Reject paths containing traversal sequences entirely
      if (path.includes('..')) {
        return res.status(400).json({ ok: false, error: { message: 'Invalid path' } })
      }

      // Enforce file extension whitelist
      const reqExt = extname(path).toLowerCase()
      if (!ALLOWED_EXTENSIONS.has(reqExt)) {
        return res.status(400).json({ ok: false, error: { message: 'File type not allowed' } })
      }

      const safePath = path.replace(/\//g, sep)
      console.log('[Media] Safe path:', safePath)

      // Support multiple possible media directories, searched by priority
      const possibleMediaDirs = []

      // 1. MEDIA_DIR from .env (highest priority)
      if (envConfig.MEDIA_DIR) {
        possibleMediaDirs.push(envConfig.MEDIA_DIR)
      }

      // 2. System environment variable MEDIA_DIR
      if (process.env.MEDIA_DIR) {
        possibleMediaDirs.push(process.env.MEDIA_DIR)
      }

      // 3. Derived from OPENCLAW_HOME
      const openclawHome = process.env.OPENCLAW_HOME
      if (openclawHome) {
        possibleMediaDirs.push(join(openclawHome, '.openclaw', 'media'))
      }

      // 4. Current user home directory
      possibleMediaDirs.push(join(os.homedir(), '.openclaw', 'media'))

      // 5. Common other user directories
      if (process.platform !== 'win32') {
        possibleMediaDirs.push('/home/ubuntu/.openclaw/media')
        possibleMediaDirs.push('/home/user/.openclaw/media')
      }

      // Deduplicate
      const uniqueMediaDirs = [...new Set(possibleMediaDirs)]
      console.log('[Media] Searching in dirs:', uniqueMediaDirs)

      let foundFile = null
      let usedMediaDir = null

      for (const mediaDir of uniqueMediaDirs) {
        const fullPath = resolve(mediaDir, safePath)

        // Security check: resolve symlinks and ensure path is within media directory
        try {
          const realBase = realpathSync(mediaDir)
          const realFull = realpathSync(fullPath)
          if (!realFull.startsWith(realBase + sep)) {
            continue
          }
        } catch {
          // Path doesn't exist or can't be resolved
          continue
        }

        if (existsSync(fullPath)) {
          const stats = statSync(fullPath)
          if (stats.isFile()) {
            foundFile = fullPath
            usedMediaDir = mediaDir
            break
          }
        }
      }

      if (!foundFile) {
        console.log('[Media] File not found in any media dir:', safePath)
        return res.status(404).json({ ok: false, error: { message: 'File not found' } })
      }

      console.log('[Media] File found:', foundFile, '| Media dir:', usedMediaDir)

      const stats = statSync(foundFile)
      if (!stats.isFile()) {
        return res.status(400).json({ ok: false, error: { message: 'Not a file' } })
      }

      // Set appropriate content type based on file extension
      const ext = extname(foundFile).toLowerCase()
      const contentTypeMap = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.webp': 'image/webp',
        '.svg': 'image/svg+xml'
      }

      const contentType = contentTypeMap[ext] || 'application/octet-stream'
      res.setHeader('Content-Type', contentType)
      res.setHeader('Content-Length', stats.size)

      // Stream the file
      const stream = createReadStream(foundFile)
      stream.pipe(res)

      stream.on('error', (err) => {
        console.error('[Media] Error streaming file:', err.message)
        res.status(500).json({ ok: false, error: { message: 'Internal server error' } })
      })
    } catch (err) {
      console.error('[Media] Error:', err.message)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}
