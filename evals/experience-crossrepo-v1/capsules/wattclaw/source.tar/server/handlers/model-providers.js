import { authMiddleware } from '../core/auth.js'
import {
  getAllUserModelProviders,
  getVisibleUserModelProviders,
  getUserModelProvider,
  getUserModelProviderById,
  createUserModelProvider,
  updateUserModelProvider,
  deleteUserModelProvider,
  setUserModelPrimary,
  getAdminUserIds,
  listUsers,
} from '../user-manager.js'
import { syncAllTenantOpenClawConfigsFromDB } from '../openclaw-config-sync.js'

export async function syncGatewayProvidersToDB() {
  try {
    const results = syncAllTenantOpenClawConfigsFromDB()
    console.log(`[ModelProviders] Synced DB providers to ${results.length} tenant openclaw.json file(s)`)
    return results
  } catch (err) {
    console.error('[ModelProviders] DB -> openclaw.json sync error:', err.message)
    return []
  }
}

function parseProviderConfig(config) {
  if (typeof config !== 'string') return config || {}
  try {
    return JSON.parse(config)
  } catch {
    return {}
  }
}

export function createModelProviderRoutes(app) {
  app.get('/api/model-providers', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const isAdmin = req.currentUser.role === 'admin'
      const allUsers = listUsers(1000, 0)
      const userMap = new Map(allUsers.map(u => [u.id, u.display_name || u.username]))

      const rows = isAdmin
        ? getAllUserModelProviders()
        : getVisibleUserModelProviders(userId)

      const adminIds = new Set(getAdminUserIds())
      const providers = rows.map(row => {
        const isOwner = row.user_id === userId
        const ownerIsAdmin = adminIds.has(row.user_id)
        return {
          id: row.id,
          providerId: row.provider_id,
          config: parseProviderConfig(row.config),
          isPrimary: !!row.is_primary,
          remark: row.remark || '',
          description: row.description || '',
          source: ownerIsAdmin ? 'shared' : 'private',
          ownerName: userMap.get(row.user_id) || 'unknown',
          ownerId: row.user_id,
          readOnly: !isOwner,
        }
      })

      res.json({ ok: true, providers })
    } catch (err) {
      console.error('[ModelProviders] list error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/model-providers', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const isAdmin = req.currentUser.role === 'admin'
      let { providerId, config, remark, description } = req.body || {}

      if (!providerId || !config) {
        return res.status(400).json({ ok: false, error: 'providerId and config are required' })
      }

      if (!isAdmin) {
        const username = req.currentUser.username
        providerId = `${username}_${providerId}`
      }

      const existing = getUserModelProvider(userId, providerId)
      if (existing) {
        return res.status(409).json({ ok: false, error: 'Provider ID already exists for this user' })
      }

      const row = createUserModelProvider(userId, providerId, config, remark || '', description || '')

      res.json({ ok: true, providerId, id: row.id })
    } catch (err) {
      console.error('[ModelProviders] create error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.put('/api/model-providers/default', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const { modelRef } = req.body || {}

      if (!modelRef) {
        return res.status(400).json({ ok: false, error: 'modelRef is required' })
      }

      const parsed = modelRef.split('/')[0]
      if (parsed) {
        setUserModelPrimary(userId, parsed)
      }

      res.json({ ok: true })
    } catch (err) {
      console.error('[ModelProviders] set default error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.put('/api/model-providers/:id', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const providerId = req.params.id
      const { config, remark, description } = req.body || {}

      const existing = getUserModelProvider(userId, providerId)
      if (!existing) {
        return res.status(403).json({ ok: false, error: 'You can only edit your own providers' })
      }

      const updates = {}
      if (config !== undefined) updates.config = config
      if (remark !== undefined) updates.remark = remark
      if (description !== undefined) updates.description = description
      updateUserModelProvider(existing.id, updates)

      res.json({ ok: true, providerId })
    } catch (err) {
      console.error('[ModelProviders] update error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.delete('/api/model-providers/:id', authMiddleware, async (req, res) => {
    try {
      const userId = req.currentUser.id
      const recordId = req.params.id

      const existing = getUserModelProviderById(recordId)
      if (!existing) {
        return res.status(404).json({ ok: false, error: 'Provider not found' })
      }

      const isAdmin = req.currentUser.role === 'admin'
      const visibleRows = isAdmin
        ? getAllUserModelProviders()
        : getVisibleUserModelProviders(userId)
      const isVisible = visibleRows.some(row => row.id === existing.id)
      if (!isVisible) {
        return res.status(403).json({ ok: false, error: 'Provider is not visible to current user' })
      }

      deleteUserModelProvider(existing.id)

      res.json({ ok: true })
    } catch (err) {
      console.error('[ModelProviders] delete error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })
}
