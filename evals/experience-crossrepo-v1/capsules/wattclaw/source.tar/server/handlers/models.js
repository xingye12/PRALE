import { authMiddleware, adminMiddleware } from '../core/auth.js'
import { listModelsFromProviders, syncModelsFromGateway } from '../model-manager.js'
import { runModelHealthCheck } from '../model-health-monitor.js'

export function createModelRoutes(app) {
  app.get('/api/models', authMiddleware, (req, res) => {
    try {
      const includeUnavailable = req.currentUser?.role === 'admin'
      const models = listModelsFromProviders({ includeUnavailable })
      res.json({ ok: true, models })
    } catch (err) {
      console.error('[Models] list error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/models/sync', authMiddleware, adminMiddleware, async (_req, res) => {
    try {
      const result = await syncModelsFromGateway()
      if (!result.ok) {
        return res.status(502).json({ ok: false, error: result.error })
      }

      res.json({ ok: true, count: result.count, unavailable: result.unavailable })
    } catch (err) {
      console.error('[Models] sync error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.post('/api/models/health-check', authMiddleware, adminMiddleware, async (req, res) => {
    try {
      const providerId = typeof req.body?.providerId === 'string' ? req.body.providerId.trim() : ''
      const modelRef = typeof req.body?.modelRef === 'string' ? req.body.modelRef.trim() : ''
      const result = await runModelHealthCheck(
        process.env,
        modelRef
          ? { modelRef }
          : providerId
            ? { providerId }
            : {}
      )
      if (!result.ok) {
        const status = result.skipped ? 409 : 500
        return res.status(status).json({ ok: false, error: result.reason || 'Health check failed' })
      }

      res.json(result)
    } catch (err) {
      console.error('[Models] health check error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })
}
