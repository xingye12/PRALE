// Skill store routes — catalog, install, toggle, delete, scan
import { Mutex } from 'async-mutex'
import { authMiddleware } from '../core/auth.js'
import { envConfig } from '../core/index.js'
import { gatewayExec } from '../core/system.js'
import { getUserOwnedAgentIds } from '../user-manager.js'
import db from '../database.js'

// ── Scan synchronization lock ──
// Ensures only one Gateway scan runs at a time; concurrent callers wait and then read DB.
const scanMutex = new Mutex()
let isBootstrapped = false

// ── Input validation for shell-safe identifiers ──
const SAFE_NAME_RE = /^[a-zA-Z0-9._-]+$/
function assertSafeName(name, label) {
  if (!name || !SAFE_NAME_RE.test(name)) {
    throw new Error(`Invalid ${label}: contains unsafe characters`)
  }
}

// ── Skill store helper functions ──

function getAgentWorkspace(agentId) {
  const row = db.prepare(
    `SELECT workspace FROM user_agents WHERE gateway_agent_id = ? AND status = 'active' ORDER BY updated_at DESC LIMIT 1`
  ).get(agentId)
  const workspace = typeof row?.workspace === 'string' ? row.workspace.trim() : ''
  return workspace || null
}

async function copySkillToAgent(skillName, agentId) {
  assertSafeName(skillName, 'skillName')
  assertSafeName(agentId, 'agentId')
  const workspace = getAgentWorkspace(agentId)
  if (!workspace) throw new Error(`Workspace not found for agent ${agentId}`)
  const skillsDir = `${workspace}/skills`
  const sourcePath = `${envConfig.GATEWAY_SKILLS_STORE_PATH}/${skillName}`
  const destPath = `${skillsDir}/${skillName}`

  console.log(`[SkillStore] Copying skill: ${sourcePath} -> ${destPath}`)
  await gatewayExec(`mkdir -p "${skillsDir}"`)
  await gatewayExec(`cp -r "${sourcePath}" "${destPath}"`)
  console.log(`[SkillStore] Copied skill ${skillName} to agent ${agentId}`)
}

async function removeSkillFromAgent(skillName, agentId) {
  assertSafeName(skillName, 'skillName')
  assertSafeName(agentId, 'agentId')
  const workspace = getAgentWorkspace(agentId)
  if (!workspace) throw new Error(`Workspace not found for agent ${agentId}`)
  const skillsDir = `${workspace}/skills`
  const skillPath = `${skillsDir}/${skillName}`

  console.log(`[SkillStore] Removing skill: ${skillPath}`)
  await gatewayExec(`rm -rf "${skillPath}"`)
  console.log(`[SkillStore] Removed skill ${skillName} from agent ${agentId}`)
}

function getAllSkillsWithAgents(source = null) {
  const where = source ? `WHERE source = ?` : ''
  const skills = db.prepare(`SELECT * FROM skill_store_skill ${where} ORDER BY created_at DESC`).all(...(source ? [source] : []))
  if (skills.length === 0) return []
  const skillIds = skills.map(s => s.id)
  const placeholders = skillIds.map(() => '?').join(',')
  const agentRows = db.prepare(
    `SELECT sas.skill_id, sas.agent_id, sas.enabled, ua.name AS agent_name, ua.avatar AS agent_avatar
     FROM skill_store_agent_skill sas
     LEFT JOIN user_agents ua ON sas.agent_id = ua.gateway_agent_id
     WHERE sas.skill_id IN (${placeholders})`
  ).all(...skillIds)
  const agentMap = {}
  for (const row of agentRows) {
    if (!agentMap[row.skill_id]) agentMap[row.skill_id] = []
    agentMap[row.skill_id].push({
      agent_id: row.agent_id,
      agent_name: row.agent_name,
      agent_avatar: row.agent_avatar,
      enabled: Boolean(row.enabled),
    })
  }
  return skills.map(skill => ({
    ...skill,
    installed: Boolean(skill.installed),
    agents: agentMap[skill.id] || [],
  }))
}

// ── Routes ──

export function createSkillStoreRoutes(app) {
  app.get('/api/skill-store/catalog', authMiddleware, (req, res) => {
    try {
      let skills = getAllSkillsWithAgents()
      const { category, search } = req.query
      if (category && category !== 'all') skills = skills.filter(s => s.category === category)
      if (search) {
        const q = search.toLowerCase()
        skills = skills.filter(s =>
          s.name.toLowerCase().includes(q) ||
          (s.description || '').toLowerCase().includes(q)
        )
      }
      res.json({ ok: true, skills })
    } catch (e) {
      console.error('[SkillStore] catalog error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.get('/api/skill-store/installed', authMiddleware, (_req, res) => {
    try {
      const all = getAllSkillsWithAgents('store')
      res.json({ ok: true, skills: all })
    } catch (e) {
      console.error('[SkillStore] installed error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.get('/api/skill-store/skills/:id', authMiddleware, (req, res) => {
    try {
      const all = getAllSkillsWithAgents()
      const skill = all.find(s => s.id === req.params.id)
      if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })
      res.json({ ok: true, skill })
    } catch (e) {
      console.error('[SkillStore] get skill error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.get('/api/skill-store/agents', authMiddleware, (req, res) => {
    try {
      const isAdmin = req.currentUser.role === 'admin'
      const ownedIds = isAdmin ? null : getUserOwnedAgentIds(req.currentUser.id)

      const agentIds = isAdmin
        ? db.prepare('SELECT DISTINCT gateway_agent_id FROM user_agents').all().map(r => r.gateway_agent_id).filter(Boolean)
        : (ownedIds || [])
      if (agentIds.length === 0) return res.json({ ok: true, agents: [] })

      const placeholders = agentIds.map(() => '?').join(',')
      const skillRows = db.prepare(
        `SELECT sas.agent_id, ss.id AS skill_id, ss.name AS skill_name, ss.icon AS skill_icon,
                ss.icon_color AS skill_icon_color, sas.enabled
         FROM skill_store_agent_skill sas
         JOIN skill_store_skill ss ON sas.skill_id = ss.id
         WHERE sas.agent_id IN (${placeholders})`
      ).all(...agentIds)

      const skillMap = {}
      for (const row of skillRows) {
        if (!skillMap[row.agent_id]) skillMap[row.agent_id] = []
        skillMap[row.agent_id].push({
          skillId: row.skill_id,
          skillName: row.skill_name,
          skillIcon: row.skill_icon,
          skillIconColor: row.skill_icon_color,
          enabled: Boolean(row.enabled),
        })
      }

      const agents = db.prepare(
        `SELECT gateway_agent_id AS id, name, avatar, template_id FROM user_agents WHERE gateway_agent_id IN (${placeholders})`
      ).all(...agentIds)

      res.json({
        ok: true,
        agents: agents.map(a => ({
          id: a.id,
          name: a.name,
          avatar: a.avatar,
          templateId: a.template_id,
          avatarColor: '',
          skills: skillMap[a.id] || [],
        })),
      })
    } catch (e) {
      console.error('[SkillStore] agents error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.get('/api/skill-store/agent/:agentId/skills', authMiddleware, (req, res) => {
    try {
      const { agentId } = req.params
      const all = getAllSkillsWithAgents()
      const agentSkills = all.filter(s => s.agents.some(a => a.agent_id === agentId))
      res.json({ ok: true, skills: agentSkills })
    } catch (e) {
      console.error('[SkillStore] agent skills error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.post('/api/skill-store/skills/:id/install', authMiddleware, async (req, res) => {
    try {
      const { id } = req.params
      const { agentIds } = req.body
      if (!Array.isArray(agentIds) || agentIds.length === 0) {
        return res.status(400).json({ ok: false, error: 'agentIds is required' })
      }

      const isAdmin = req.currentUser.role === 'admin'
      if (!isAdmin) {
        const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
        const unauthorized = agentIds.filter(aid => !ownedIds.includes(aid))
        if (unauthorized.length > 0) {
          return res.status(403).json({ ok: false, error: 'Not authorized to install for some agents' })
        }
      }

      let skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(id)

      if (!skill && id.startsWith('gw-')) {
        const gwName = id.slice(3)
        const iconPool = ['🤖', '🔧', '📊', '🧠', '💡', '📝', '🔍', '⚙️']
        const colorPool = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#6b7280']
        const idx = Math.abs(gwName.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % iconPool.length
        const newId = 'sk-' + Date.now() + '-' + Math.random().toString(36).slice(2)
        db.prepare(
          `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name, source)
           VALUES (?, ?, '', ?, ?, 'general', '', '1.0.0', 'builtin', 0, ?, 'gateway')`
        ).run(newId, gwName, iconPool[idx], colorPool[idx], gwName)
        skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(newId)
      }

      if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })

      for (const agentId of agentIds) {
        const existing = db.prepare('SELECT id FROM skill_store_agent_skill WHERE skill_id = ? AND agent_id = ?')
          .get(skill.id, agentId)
        if (!existing) {
          db.prepare('INSERT INTO skill_store_agent_skill (id, skill_id, agent_id, enabled) VALUES (?, ?, ?, 1)')
            .run('as-' + Date.now() + '-' + Math.random().toString(36).slice(2), skill.id, agentId)
        }
        if (skill.gateway_name) {
          try { await copySkillToAgent(skill.gateway_name, agentId) }
          catch (e) {
            console.error(`[SkillStore] SSH copy failed for ${skill.gateway_name} -> ${agentId}:`, e.message)
            return res.status(500).json({ ok: false, error: `SSH copy failed: ${e.message}` })
          }
        }
      }

      db.prepare('UPDATE skill_store_skill SET installed = 1 WHERE id = ?').run(skill.id)
      res.json({ ok: true })
    } catch (e) {
      console.error('[SkillStore] install error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.patch('/api/skill-store/skills/:id/toggle', authMiddleware, async (req, res) => {
    try {
      const { id } = req.params
      const { agentId, enabled } = req.body
      if (!agentId || enabled === undefined) {
        return res.status(400).json({ ok: false, error: 'agentId and enabled are required' })
      }

      const isAdmin = req.currentUser.role === 'admin'
      if (!isAdmin) {
        const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
        if (!ownedIds.includes(agentId)) {
          return res.status(403).json({ ok: false, error: 'Not authorized for this agent' })
        }
      }

      db.prepare('UPDATE skill_store_agent_skill SET enabled = ? WHERE skill_id = ? AND agent_id = ?')
        .run(enabled ? 1 : 0, id, agentId)

      const skill = db.prepare('SELECT gateway_name FROM skill_store_skill WHERE id = ?').get(id)
      if (skill && skill.gateway_name) {
        if (enabled) {
          await copySkillToAgent(skill.gateway_name, agentId)
        } else {
          await removeSkillFromAgent(skill.gateway_name, agentId)
        }
      }

      res.json({ ok: true })
    } catch (e) {
      console.error('[SkillStore] toggle error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.delete('/api/skill-store/skills/:id', authMiddleware, async (req, res) => {
    try {
      const { id } = req.params
      const skill = db.prepare('SELECT * FROM skill_store_skill WHERE id = ?').get(id)
      if (!skill) return res.status(404).json({ ok: false, error: 'Skill not found' })

      if (!req.currentUser || req.currentUser.role !== 'admin') {
        const agentRows = db.prepare('SELECT agent_id FROM skill_store_agent_skill WHERE skill_id = ?').all(id)
        const ownedIds = getUserOwnedAgentIds(req.currentUser.id)
        const hasUnowned = agentRows.some(r => !ownedIds.includes(r.agent_id))
        if (hasUnowned) {
          return res.status(403).json({ ok: false, error: 'Cannot delete skill installed on agents you do not own' })
        }
      }

      const sshErrors = []
      if (skill.gateway_name) {
        const agentRows = db.prepare('SELECT agent_id FROM skill_store_agent_skill WHERE skill_id = ?').all(id)
        for (const row of agentRows) {
          try { await removeSkillFromAgent(skill.gateway_name, row.agent_id) }
          catch (e) {
            console.error('[SkillStore] SSH remove failed:', e.message)
            sshErrors.push(e.message)
          }
        }
      }

      db.prepare('DELETE FROM skill_store_agent_skill WHERE skill_id = ?').run(id)
      db.prepare('DELETE FROM skill_store_skill WHERE id = ?').run(id)
      if (sshErrors.length > 0) {
        res.json({ ok: true, warnings: sshErrors })
      } else {
        res.json({ ok: true })
      }
    } catch (e) {
      console.error('[SkillStore] delete error:', e.message)
      res.status(500).json({ ok: false, error: e.message })
    }
  })

  app.post('/api/skill-store/scan', authMiddleware, async (req, res) => {
    const userId = req.currentUser?.id || 'unknown'
    try {
      // Serialize scans: if another scan is running, wait for it instead of starting a new one.
      console.log(`[SkillStore] Scan requested by user=${userId}, acquiring mutex...`)
      const t0 = Date.now()
      const result = await scanMutex.runExclusive(async () => doScan())
      console.log(`[SkillStore] Scan completed: user=${userId} count=${result.count} elapsed=${Date.now() - t0}ms`)
      res.json({ ok: true, count: result.count })
    } catch (e) {
      console.error(`[SkillStore] Scan failed: user=${userId} error=${e.message}`)
      res.status(500).json({ ok: false, error: e.message })
    }
  })
}

// ── Internal scan implementation ──
// Two-phase: collect from Gateway (async, with timeout), then apply to DB (sync transaction).
const SCAN_TIMEOUT_MS = 30_000

// ── Sync Gateway global skills (bundled + plugin) into DB ──
// These are the "global" skills visible in the store UI's global section.
// Source directories (per OpenClaw src/agents/skills/workspace.ts):
//   bundled: <openclaw-install>/skills/  (e.g. .../node_modules/openclaw/skills/)
//   plugin:  ~/.openclaw/plugin-skills/  (extension-provided, symlinks to extensions/)

const GLOBAL_SKILL_DIRS = [
  { envKey: 'GATEWAY_BUNDLED_SKILLS_PATH', defaultDir: '/home/wattman/.npm-global/lib/node_modules/openclaw/skills', source: 'bundled' },
  { envKey: 'GATEWAY_PLUGIN_SKILLS_PATH', defaultDir: '/home/wattman/.openclaw/plugin-skills', source: 'plugin' },
]

async function _scanSkillDir(dir, source) {
  const t0 = Date.now()
  console.log(`[SkillStore] Scanning ${source} skills from ${dir}`)
  let output = ''
  try {
    output = await withTimeout(
      gatewayExec(`find -L "${dir}" -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' 2>/dev/null`),
      SCAN_TIMEOUT_MS,
    )
  } catch (err) {
    console.error(`[SkillStore] ${source} skills scan failed: ${err.message}`)
    return []
  }
  const dirNames = output.trim().split('\n').filter(Boolean)
  console.log(`[SkillStore] ${source} skills found: ${dirNames.length} elapsed=${Date.now() - t0}ms`)
  if (dirNames.length === 0) return []

  // Validate names
  for (const name of dirNames) assertSafeName(name, `${source} skill name`)

  // Batch-read all SKILL.md in one SSH command (N+1 → 1)
  const safeDirs = dirNames.map((n) => `${dir}/${n}`).join("' '")
  let readmeOutput = ''
  try {
    readmeOutput = await withTimeout(
      gatewayExec(
        `for d in '${safeDirs}'; do echo "===SKILL_SEP==="; cat "$d/SKILL.md" 2>/dev/null || cat "$d/skill.md" 2>/dev/null; done`
      ),
      SCAN_TIMEOUT_MS,
    )
  } catch { readmeOutput = '' }

  const readmeParts = readmeOutput.split('===SKILL_SEP===').slice(1)

  const skillDataList = []
  for (let i = 0; i < dirNames.length; i++) {
    const name = dirNames[i]
    const readme = readmeParts[i] || ''

    let description = ''
    const fmMatch = readme.match(/^---\s*\n([\s\S]*?)\n---/)
    if (fmMatch) {
      const descMatch = fmMatch[1].match(/^description:\s*(.+)$/m)
      if (descMatch) description = descMatch[1].trim()
    }
    if (!description) {
      const bulletMatch = readme.match(/[-*]\s*\*\*[Dd]escription\*\*:\s*(.+)/)
      if (bulletMatch) description = bulletMatch[1].trim()
    }

    skillDataList.push({ name, description, readme })
  }
  return skillDataList
}

async function _syncGatewaySkills() {
  const iconPool = ['🤖', '🔧', '📊', '🧠', '💡', '📝', '🔍', '⚙️']
  const colorPool = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#6b7280']

  for (const { envKey, defaultDir, source } of GLOBAL_SKILL_DIRS) {
    const dir = envConfig[envKey] || defaultDir
    const skillDataList = await _scanSkillDir(dir, source)
    if (skillDataList.length === 0) continue

    const dirNames = skillDataList.map((s) => s.name)
    let inserted = 0
    let updated = 0

    const syncTx = db.transaction(() => {
      // Prune stale skills of this source (clean join table first — FK not enforced)
      const ph = dirNames.map(() => '?').join(',')
      db.prepare(
        `DELETE FROM skill_store_agent_skill WHERE skill_id IN (
          SELECT id FROM skill_store_skill WHERE source = ? AND gateway_name NOT IN (${ph})
        )`
      ).run(source, ...dirNames)
      db.prepare(
        `DELETE FROM skill_store_skill WHERE source = ? AND gateway_name NOT IN (${ph})`
      ).run(source, ...dirNames)

      for (const { name, description, readme } of skillDataList) {
        const existing = db.prepare('SELECT id FROM skill_store_skill WHERE gateway_name = ?').get(name)
        if (existing) {
          db.prepare(
            `UPDATE skill_store_skill SET description=?, readme=?, source=?, updated_at=datetime('now') WHERE gateway_name=?`
          ).run(description, readme, source, name)
          updated++
        } else {
          const id = 'sk-' + Date.now() + '-' + Math.random().toString(36).slice(2)
          const idx = Math.abs(name.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % iconPool.length
          db.prepare(
            `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name, readme, source)
             VALUES (?, ?, ?, ?, ?, 'general', '', '1.0.0', 'builtin', 1, ?, ?, ?)`
          ).run(id, name, description, iconPool[idx], colorPool[idx], name, readme, source)
          inserted++
        }
      }
    })

    syncTx()
    console.log(`[SkillStore] ${source} sync done: inserted=${inserted} updated=${updated} total=${dirNames.length}`)
  }
}

async function doScan() {
  const skillsPath = envConfig.GATEWAY_SKILLS_STORE_PATH || '/home/wattman/skills-store'
  const t0 = Date.now()

  // ── Phase 1: Collect skill data from Gateway (async, timeout-protected) ──
  console.log(`[SkillStore] Scan phase1: listing skills from ${skillsPath}`)
  let output = ''
  try {
    output = await withTimeout(
      gatewayExec(`find "${skillsPath}" -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' 2>/dev/null`),
      SCAN_TIMEOUT_MS,
    )
  } catch (err) {
    console.error(`[SkillStore] Scan phase1 failed: ${err.message}`)
    return { count: 0 }
  }
  const dirNames = output.trim().split('\n').filter(Boolean)
  console.log(`[SkillStore] Scan phase1 done: found=${dirNames.length} elapsed=${Date.now() - t0}ms`)

  // Validate names
  for (const gwName of dirNames) assertSafeName(gwName, 'gateway skill name')

  // Batch-read all SKILL.md in one SSH command (N+1 → 1)
  const safeDirs = dirNames.map((n) => `${skillsPath}/${n}`).join("' '")
  let readmeOutput = ''
  try {
    readmeOutput = await withTimeout(
      gatewayExec(
        `for d in '${safeDirs}'; do echo "===SKILL_SEP==="; cat "$d/SKILL.md" 2>/dev/null || cat "$d/skill.md" 2>/dev/null; done`
      ),
      SCAN_TIMEOUT_MS,
    )
  } catch { readmeOutput = '' }
  const readmeParts = readmeOutput.split('===SKILL_SEP===').slice(1)

  // Collect readmes
  const skillDataList = []
  for (let i = 0; i < dirNames.length; i++) {
    const gwName = dirNames[i]
    const readme = readmeParts[i] || ''

    let description = ''
    const fmMatch = readme.match(/^---\s*\n([\s\S]*?)\n---/)
    if (fmMatch) {
      const descMatch = fmMatch[1].match(/^description:\s*(.+)$/m)
      if (descMatch) description = descMatch[1].trim()
    }
    if (!description) {
      const bulletMatch = readme.match(/[-*]\s*\*\*[Dd]escription\*\*:\s*(.+)/)
      if (bulletMatch) description = bulletMatch[1].trim()
    }

    skillDataList.push({ gwName, description, readme })
  }
  console.log(`[SkillStore] Scan phase1 readmes: total=${skillDataList.length} elapsed=${Date.now() - t0}ms`)

  // ── Phase 2: Apply to DB in a single transaction (sync, blocks readers briefly) ──
  const iconPool = ['🤖', '🔧', '📊', '🧠', '💡', '📝', '🔍', '⚙️']
  const colorPool = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#6b7280']

  let inserted = 0
  let updated = 0
  const applyTx = db.transaction(() => {
    if (dirNames.length > 0) {
      const placeholders = dirNames.map(() => '?').join(',')
      db.prepare(`DELETE FROM skill_store_agent_skill WHERE skill_id IN (
        SELECT id FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})
      )`).run(...dirNames)
      const delSkill = db.prepare(`DELETE FROM skill_store_skill WHERE source = 'store' AND gateway_name NOT IN (${placeholders})`)
        .run(...dirNames)
      if (delSkill.changes > 0) console.log(`[SkillStore] Scan phase2: pruned ${delSkill.changes} stale skills`)
    } else {
      const delSkill = db.prepare(`DELETE FROM skill_store_skill WHERE source = 'store'`).run()
      if (delSkill.changes > 0) console.log(`[SkillStore] Scan phase2: pruned all ${delSkill.changes} skills (empty Gateway)`)
    }

    for (const { gwName, description, readme } of skillDataList) {
      const existing = db.prepare('SELECT id FROM skill_store_skill WHERE gateway_name = ?').get(gwName)
      if (existing) {
        db.prepare(`UPDATE skill_store_skill SET description=?, readme=?, source='store', updated_at=datetime('now') WHERE gateway_name=?`)
          .run(description, readme, gwName)
        updated++
      } else {
        const id = 'sk-' + Date.now() + '-' + Math.random().toString(36).slice(2)
        const idx = Math.abs(gwName.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % iconPool.length
        db.prepare(
          `INSERT INTO skill_store_skill (id, name, description, icon, icon_color, category, usage, version, type, installed, gateway_name, readme, source)
           VALUES (?, ?, ?, ?, ?, 'general', '', '1.0.0', 'builtin', 0, ?, ?, 'store')`
        ).run(id, gwName, description, iconPool[idx], colorPool[idx], gwName, readme)
        inserted++
      }
    }
  })

  applyTx()
  console.log(`[SkillStore] Scan phase2 done: inserted=${inserted} updated=${updated} total_elapsed=${Date.now() - t0}ms`)

  // Sync Gateway bundled/managed skills alongside filesystem scan
  await _syncGatewaySkills()

  return { count: dirNames.length }
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`Operation timed out after ${ms}ms`)), ms)),
  ])
}

// ── Bootstrap: scan once on startup + 24h periodic refresh ──
let lastBootstrapAttempt = 0
const BOOTSTRAP_COOLDOWN_MS = 60_000
const GATEWAY_SKILLS_REFRESH_MS = 24 * 60 * 60 * 1000 // 24h
let globalSkillsRefreshTimer = null

export async function bootstrapSkillsCache() {
  if (isBootstrapped) return
  const now = Date.now()
  if (now - lastBootstrapAttempt < BOOTSTRAP_COOLDOWN_MS) {
    console.log(`[Skills] Bootstrap skipped (cooldown: ${Math.round((BOOTSTRAP_COOLDOWN_MS - (now - lastBootstrapAttempt)) / 1000)}s remaining)`)
    return
  }
  lastBootstrapAttempt = now
  try {
    console.log('[Skills] Bootstrapping from Gateway...')
    const t0 = Date.now()
    await scanMutex.runExclusive(async () => doScan())
    isBootstrapped = true
    console.log(`[Skills] Bootstrap complete: elapsed=${Date.now() - t0}ms`)

    // Periodic refresh every 24h (fire-and-forget, mutex prevents overlap with scans)
    globalSkillsRefreshTimer = setInterval(() => {
      scanMutex.runExclusive(() => _syncGatewaySkills()).catch((err) => {
        console.error(`[Skills] 24h periodic sync failed: ${err.message}`)
      })
    }, GATEWAY_SKILLS_REFRESH_MS)
    console.log(`[Skills] Periodic sync scheduled: every ${GATEWAY_SKILLS_REFRESH_MS / 3600_000}h`)
  } catch (err) {
    console.error(`[Skills] Bootstrap failed: ${err.message} (will retry after ${BOOTSTRAP_COOLDOWN_MS / 1000}s cooldown)`)
  }
}
