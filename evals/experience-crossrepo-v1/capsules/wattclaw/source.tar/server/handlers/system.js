// System routes: health, metrics, config, npm, status
import { authMiddleware } from '../core/auth.js'
import { configQueueExecute } from '../core/config-queue.js'
import { gateway, sseClients, envConfig, triggerGatewayReconnect } from '../core/index.js'
import { gatewayAdminRpc } from '../core/gateway-client.js'
import { runOpenClawCliForTenant } from '../core/multi-tenant-gateway.js'
import { getNetworkStats, getDiskSpace } from '../core/system.js'
import { createPollingCache } from '../utils.js'
import { parseEnvFile, stringifyEnvFile } from '../utils/index.js'
import { spawn } from 'child_process'
import { existsSync, readFileSync, writeFileSync } from 'fs'
import { join } from 'path'
import os from 'os'

const envPath = join(process.cwd(), '.env')

let _gatewayHealthCache = { data: null, ts: 0 }
const GATEWAY_HEALTH_CACHE_TTL = 30_000

const npmVersionsPolling = createPollingCache(3_600_000, async () => {
  const response = await fetch('https://registry.npmjs.org/openclaw', {
    headers: { 'Accept': 'application/vnd.npm.install-v1+json' },
  })
  if (!response.ok) throw new Error('Failed to fetch versions from npm')
  const data = await response.json()
  const versions = Object.keys(data.versions || {})
  const validVersions = versions.filter(v => /^\d+\.\d+\.\d+/.test(v))
  validVersions.sort((a, b) => {
    const ap = a.split('.').map(Number)
    const bp = b.split('.').map(Number)
    for (let i = 0; i < 3; i++) {
      if (ap[i] !== bp[i]) return (bp[i] || 0) - (ap[i] || 0)
    }
    return 0
  })
  return { versions: validVersions }
})

function getOpenClawCliCommand() {
  return (process.env.OPENCLAW_CLI || process.env.OPENCLAW_CLI_COMMAND || 'openclaw').trim() || 'openclaw'
}

function sanitizeMcpKey(value) {
  const key = String(value || '').trim()
  if (!key) return ''
  if (!/^[a-zA-Z0-9._-]+$/.test(key)) return ''
  return key
}

function normalizeHeaderRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return Object.entries(value).reduce((acc, [key, rawValue]) => {
    const normalizedKey = String(key || '').trim()
    if (!normalizedKey) return acc
    if (rawValue === undefined || rawValue === null) return acc
    acc[normalizedKey] = typeof rawValue === 'string' ? rawValue : String(rawValue)
    return acc
  }, {})
}

function numberOrFallback(value, fallback) {
  const next = Number(value)
  return Number.isFinite(next) && next > 0 ? next : fallback
}

function buildMcpCliConfig(server) {
  const rawTransport = String(server?.transport || '').toLowerCase()
  const transport = rawTransport === 'streamable-http'
    ? 'streamable-http'
    : rawTransport === 'sse'
      ? 'sse'
      : 'stdio'
  const headers = normalizeHeaderRecord(server?.headers)
  const payload = {
    timeout: numberOrFallback(server?.timeout, 30),
  }

  if (transport !== 'stdio') {
    payload.transport = transport
  }

  if (transport !== 'stdio' && Object.keys(headers).length > 0) {
    payload.headers = headers
  }

  if (typeof server?.name === 'string' && server.name.trim()) {
    payload.name = server.name.trim()
  }

  if (typeof server?.description === 'string' && server.description.trim()) {
    payload.description = server.description.trim()
  }

  if (typeof server?.icon === 'string' && server.icon.trim()) {
    payload.icon = server.icon.trim()
  }

  if (transport === 'stdio') {
    if (typeof server?.command === 'string' && server.command.trim()) {
      payload.command = server.command.trim()
    }

    if (Array.isArray(server?.args)) {
      payload.args = server.args.map(item => String(item)).filter(Boolean)
    }

    if (typeof server?.cwd === 'string' && server.cwd.trim()) {
      payload.cwd = server.cwd.trim()
    }

    const env = server?.env && typeof server.env === 'object' && !Array.isArray(server.env)
      ? server.env
      : null
    if (env && Object.keys(env).length > 0) {
      payload.env = env
    }
  } else if (typeof server?.url === 'string' && server.url.trim()) {
    payload.url = server.url.trim()
  } else if (typeof server?.endpoint === 'string' && server.endpoint.trim()) {
    payload.url = server.endpoint.trim()
  }

  if (server?.enabled === false) {
    payload.enabled = false
  }

  return payload
}

function parseJsonOutput(text) {
  const trimmed = String(text || '').trim()
  if (!trimmed) return null
  try {
    return JSON.parse(trimmed)
  } catch {
    const arrayStart = trimmed.indexOf('[')
    const arrayEnd = trimmed.lastIndexOf(']')
    if (arrayStart >= 0 && arrayEnd > arrayStart) {
      try {
        return JSON.parse(trimmed.slice(arrayStart, arrayEnd + 1))
      } catch {
        // fall through to object extraction
      }
    }

    const start = trimmed.indexOf('{')
    const end = trimmed.lastIndexOf('}')
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(trimmed.slice(start, end + 1))
      } catch {
        return null
      }
    }
    return null
  }
}

function normalizeMcpListPayload(payload) {
  const root = payload?.payload && typeof payload.payload === 'object' ? payload.payload : payload
  const source = root?.mcpServers || root?.servers || root?.entries || root?.items || root
  if (!source) return {}

  if (Array.isArray(source)) {
    return source.reduce((acc, item) => {
      if (!item || typeof item !== 'object') return acc
      const key = sanitizeMcpKey(item.key || item.name || item.id)
      if (!key) return acc
      const config = item.config && typeof item.config === 'object' && !Array.isArray(item.config)
        ? item.config
        : {}
      acc[key] = {
        kind: 'mcp',
        type: 'mcp',
        ...config,
        ...item,
        name: typeof item.name === 'string' && item.name.trim() ? item.name.trim() : key,
      }
      return acc
    }, {})
  }

  if (typeof source === 'object') {
    return Object.entries(source).reduce((acc, [rawKey, rawValue]) => {
      const key = sanitizeMcpKey(rawKey)
      if (!key) return acc
      if (rawValue && typeof rawValue === 'object' && !Array.isArray(rawValue)) {
        const config = rawValue.config && typeof rawValue.config === 'object' && !Array.isArray(rawValue.config)
          ? rawValue.config
          : {}
        acc[key] = {
          kind: 'mcp',
          type: 'mcp',
          ...config,
          ...rawValue,
          name: typeof rawValue.name === 'string' && rawValue.name.trim() ? rawValue.name.trim() : key,
        }
      } else {
        acc[key] = {
          kind: 'mcp',
          type: 'mcp',
          name: key,
          value: rawValue,
        }
      }
      return acc
    }, {})
  }

  return {}
}

function pickMcpServersConfig(payload) {
  const queue = [payload]
  const visited = new Set()

  while (queue.length > 0) {
    const current = queue.shift()
    if (!current || typeof current !== 'object' || Array.isArray(current) || visited.has(current)) continue
    visited.add(current)

    const row = current
    if (
      row.path === 'mcp.servers' &&
      row.config &&
      typeof row.config === 'object' &&
      !Array.isArray(row.config)
    ) {
      return row.config
    }

    if (row.mcp?.servers && typeof row.mcp.servers === 'object' && !Array.isArray(row.mcp.servers)) {
      return row.mcp.servers
    }

    if (row.mcpServers && typeof row.mcpServers === 'object' && !Array.isArray(row.mcpServers)) {
      return row.mcpServers
    }

    if (row['mcp.servers'] && typeof row['mcp.servers'] === 'object' && !Array.isArray(row['mcp.servers'])) {
      return row['mcp.servers']
    }

    for (const key of ['payload', 'result', 'data', 'value', 'config', 'parsed', 'sourceConfig']) {
      const nested = row[key]
      if (nested && typeof nested === 'object') {
        queue.push(nested)
      }
    }
  }

  return null
}

function summarizePayloadShape(value) {
  if (!value || typeof value !== 'object') return { type: typeof value }
  if (Array.isArray(value)) return { type: 'array', length: value.length }

  return {
    type: 'object',
    keys: Object.keys(value).slice(0, 20),
    path: value.path,
    hasConfig: Boolean(value.config && typeof value.config === 'object'),
    hasResult: Boolean(value.result && typeof value.result === 'object'),
    hasPayload: Boolean(value.payload && typeof value.payload === 'object'),
  }
}

function safeMcpServerSummary(key, value) {
  const row = value && typeof value === 'object' && !Array.isArray(value) ? value : {}
  const headers = row.headers && typeof row.headers === 'object' && !Array.isArray(row.headers)
    ? row.headers
    : {}
  const env = row.env && typeof row.env === 'object' && !Array.isArray(row.env)
    ? row.env
    : {}

  return {
    key,
    transport: row.transport || (row.command ? 'stdio' : row.url || row.endpoint ? 'sse' : undefined),
    hasCommand: typeof row.command === 'string' && row.command.trim().length > 0,
    hasUrl: typeof row.url === 'string' && row.url.trim().length > 0,
    hasEndpoint: typeof row.endpoint === 'string' && row.endpoint.trim().length > 0,
    enabled: row.enabled !== false,
    timeout: row.timeout,
    connectTimeout: row.connectTimeout,
    headerKeys: Object.keys(headers),
    envKeys: Object.keys(env),
  }
}

function summarizeMcpEntries(entries) {
  if (!entries || typeof entries !== 'object' || Array.isArray(entries)) return []
  return Object.entries(entries).map(([key, value]) => safeMcpServerSummary(key, value))
}

async function runOpenClawCli(args, timeoutMs = 30_000, tenant = null) {
  const tenantOutput = await runOpenClawCliForTenant(tenant, args, timeoutMs)
  if (tenantOutput) return tenantOutput

  return new Promise((resolve, reject) => {
    const command = getOpenClawCliCommand()
    const child = spawn(command, args, {
      shell: false,
      windowsHide: true,
    })

    let stdout = ''
    let stderr = ''
    let timer = null

    child.stdout.on('data', data => {
      stdout += data.toString()
    })

    child.stderr.on('data', data => {
      stderr += data.toString()
    })

    child.on('error', error => {
      if (timer) clearTimeout(timer)
      reject(error)
    })

    child.on('close', code => {
      if (timer) clearTimeout(timer)
      if (code === 0) {
        resolve({ stdout, stderr })
        return
      }

      const error = new Error((stderr || stdout || `Command failed with exit code ${code}`).trim())
      error.stdout = stdout
      error.stderr = stderr
      error.exitCode = code
      reject(error)
    })

    if (timeoutMs > 0) {
      timer = setTimeout(() => {
        child.kill()
        const error = new Error(`Command timed out after ${Math.round(timeoutMs / 1000)}s`)
        error.stdout = stdout
        error.stderr = stderr
        reject(error)
      }, timeoutMs)
    }
  })
}

async function listMcpServers(tenant = null) {
  const gatewayAttempts = [
    {
      command: 'gateway config.get mcp.servers',
      method: 'gateway',
      params: { action: 'config.get', path: 'mcp.servers' },
    },
    {
      command: 'config.get',
      method: 'config.get',
      params: {},
    },
  ]
  const gatewayErrors = []

  for (const attempt of gatewayAttempts) {
    try {
      console.log('[MCP] Gateway list attempt:', attempt.command)
      const rpcResult = await gatewayAdminRpc(attempt.method, attempt.params)
      if (!rpcResult.ok) {
        throw new Error(rpcResult.error || `${attempt.command} failed`)
      }

      console.log('[MCP] Gateway list response shape:', {
        command: attempt.command,
        ...summarizePayloadShape(rpcResult.payload),
      })
      const config = pickMcpServersConfig(rpcResult.payload)
      if (config && typeof config === 'object' && !Array.isArray(config)) {
        const entries = normalizeMcpListPayload(config)
        console.log('[MCP] Gateway config normalized:', {
          command: attempt.command,
          count: Object.keys(entries).length,
          entries: summarizeMcpEntries(entries),
        })
        return {
          entries,
          command: attempt.command,
          stdout: '',
          stderr: '',
        }
      }
      console.warn('[MCP] Gateway list returned no mcp.servers config:', {
        command: attempt.command,
        ...summarizePayloadShape(rpcResult.payload),
      })
      gatewayErrors.push(`${attempt.command}: no mcp.servers config in response`)
    } catch (error) {
      console.warn('[MCP] Gateway list attempt failed:', {
        command: attempt.command,
        error: error.message,
      })
      gatewayErrors.push(`${attempt.command}: ${error.message}`)
    }
  }

  console.warn('[MCP] Gateway MCP list unavailable, falling back to CLI:', gatewayErrors)
  const attempts = [
    ['mcp', 'list', '--json'],
    ['mcp', 'ls', '--json'],
    ['mcp', 'get', '--json'],
  ]
  const errors = []

  for (const args of attempts) {
    try {
      console.log('[MCP] CLI list attempt:', args.join(' '))
      const output = await runOpenClawCli(args, 30_000, tenant)
      const parsed = parseJsonOutput(output.stdout)
      if (!parsed) {
        console.warn('[MCP] CLI list invalid JSON:', {
          command: args.join(' '),
          stdoutLength: output.stdout.length,
          stderrLength: output.stderr.length,
        })
        errors.push(`${args.join(' ')}: invalid JSON output`)
        continue
      }
      const entries = normalizeMcpListPayload(parsed)
      console.log('[MCP] CLI list success:', {
        command: args.join(' '),
        stdoutLength: output.stdout.length,
        stderrLength: output.stderr.length,
        parsed: summarizePayloadShape(parsed),
        count: Object.keys(entries).length,
        entries: summarizeMcpEntries(entries),
      })
      return {
        entries,
        command: args.join(' '),
        stdout: output.stdout,
        stderr: output.stderr,
      }
    } catch (error) {
      console.warn('[MCP] CLI list attempt failed:', {
        command: args.join(' '),
        error: error.message,
        stdoutLength: error.stdout?.length || 0,
        stderrLength: error.stderr?.length || 0,
      })
      errors.push(`${args.join(' ')}: ${error.message}`)
    }
  }

  const details = [...gatewayErrors, ...errors]
  const error = new Error(details.join('\n') || 'Unable to list MCP servers')
  error.details = details
  throw error
}

async function deleteMcpServer(key, tenant = null) {
  const command = `config.set mcp.servers.${key} <removed>`
  console.log('[MCP] config delete attempt:', { key, command, tenant: tenant?.id || null })

  const result = await configQueueExecute((sourceConfig) => {
    if (!sourceConfig || typeof sourceConfig !== 'object' || Array.isArray(sourceConfig)) return null

    const nextConfig = { ...sourceConfig }
    let changed = false

    const removeServer = (servers) => {
      if (!servers || typeof servers !== 'object' || Array.isArray(servers)) return servers
      if (!Object.prototype.hasOwnProperty.call(servers, key)) return servers
      const nextServers = { ...servers }
      delete nextServers[key]
      changed = true
      return nextServers
    }

    if (nextConfig.mcp && typeof nextConfig.mcp === 'object' && !Array.isArray(nextConfig.mcp)) {
      const nextMcp = { ...nextConfig.mcp }
      if (nextMcp.servers && typeof nextMcp.servers === 'object' && !Array.isArray(nextMcp.servers)) {
        nextMcp.servers = removeServer(nextMcp.servers)
      }
      nextConfig.mcp = nextMcp
    }

    if (nextConfig.mcpServers && typeof nextConfig.mcpServers === 'object' && !Array.isArray(nextConfig.mcpServers)) {
      nextConfig.mcpServers = removeServer(nextConfig.mcpServers)
    }

    if (nextConfig['mcp.servers'] && typeof nextConfig['mcp.servers'] === 'object' && !Array.isArray(nextConfig['mcp.servers'])) {
      nextConfig['mcp.servers'] = removeServer(nextConfig['mcp.servers'])
    }

    return changed ? nextConfig : null
  }, `mcp-delete-${key}`, 'config.set')

  if (result === null) {
    console.log('[MCP] config delete no-op:', { key, command })
    return {
      command,
      stdout: '',
      stderr: '',
      changed: false,
    }
  }

  console.log('[MCP] config delete success:', { key, command })
  return {
    command,
    stdout: '',
    stderr: '',
    changed: true,
  }
}

async function probeMcpServer(name, timeoutMs = 30_000, retries = 3, tenant = null) {
  let lastError = null

  for (let attempt = 0; attempt < retries; attempt += 1) {
    try {
      console.log('[MCP] probe attempt:', { name, attempt: attempt + 1, retries })
      const result = await runOpenClawCli(['mcp', 'probe', name, '--json'], timeoutMs, tenant)
      const parsed = parseJsonOutput(result.stdout)

      console.log('[MCP] probe success:', {
        name,
        attempt: attempt + 1,
        stdoutLength: result.stdout.length,
        stderrLength: result.stderr.length,
        parsed: summarizePayloadShape(parsed),
      })
      return {
        ok: true,
        stdout: result.stdout,
        stderr: result.stderr,
        parsed,
      }
    } catch (error) {
      lastError = error
      console.warn('[MCP] probe failed:', {
        name,
        attempt: attempt + 1,
        retries,
        error: error.message,
        stdoutLength: error.stdout?.length || 0,
        stderrLength: error.stderr?.length || 0,
      })
      if (attempt < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, 1500))
      }
    }
  }

  return {
    ok: false,
    error: lastError?.message || 'MCP probe failed',
    stdout: lastError?.stdout || '',
    stderr: lastError?.stderr || '',
  }
}

function extractMcpToolNames(value) {
  const names = new Set()
  const visit = (current, key = '') => {
    const normalizedKey = key.toLowerCase().replace(/[_-]/g, '')
    const isToolCollection = ['tools', 'toolnames', 'availabletools', 'registeredtools'].includes(normalizedKey)
    if (Array.isArray(current)) {
      if (isToolCollection) {
        for (const tool of current) {
          if (typeof tool === 'string' && tool.trim()) names.add(tool.trim())
          if (tool && typeof tool === 'object') {
            const toolName = tool.name || tool.toolName || tool.tool_name || tool.function?.name
            if (typeof toolName === 'string' && toolName.trim()) names.add(toolName.trim())
          }
        }
      }
      for (const item of current) visit(item, key)
      return
    }
    if (!current || typeof current !== 'object') return
    if (isToolCollection) {
      const directName = current.name || current.toolName || current.tool_name || current.function?.name
      if (typeof directName === 'string' && directName.trim()) names.add(directName.trim())
      if (!directName) {
        for (const [toolName, definition] of Object.entries(current)) {
          if (definition && typeof definition === 'object' && toolName.trim()) names.add(toolName.trim())
        }
      }
    }
    for (const [childKey, child] of Object.entries(current)) visit(child, childKey)
  }
  visit(value)
  return [...names]
}

async function patchMcpServerEnabled(key, enabled, tenant = null) {
  const configPath = `mcp.servers.${key}.enabled`
  const args = ['config', 'set', configPath, String(enabled)]
  console.log('[MCP] CLI enabled set start:', {
    key,
    enabled,
    configPath,
    command: args.join(' '),
  })

  try {
    const output = await runOpenClawCli(args, 30_000, tenant)
    console.log('[MCP] CLI reload after enabled set:', { key, enabled })
    const reloadOutput = await runOpenClawCli(['mcp', 'reload'], 30_000, tenant)
    console.log('[MCP] CLI enabled set success:', {
      key,
      enabled,
      configPath,
      stdoutLength: output.stdout.length,
      stderrLength: output.stderr.length,
      reloadStdoutLength: reloadOutput.stdout.length,
      reloadStderrLength: reloadOutput.stderr.length,
    })
    return {
      command: args.join(' '),
      stdout: output.stdout,
      stderr: output.stderr,
      reload: {
        stdout: reloadOutput.stdout,
        stderr: reloadOutput.stderr,
      },
    }
  } catch (error) {
    console.warn('[MCP] CLI enabled set failed:', {
      key,
      enabled,
      configPath,
      error: error.message,
      stdoutLength: error.stdout?.length || 0,
      stderrLength: error.stderr?.length || 0,
    })
    throw error
  }
}

export function createSystemRoutes(app) {
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      gateway: gateway.isConnected ? 'connected' : 'disconnected',
      clients: sseClients.size,
    })
  })

  app.get('/api/status', authMiddleware, async (_req, res) => {
    try {
      const rpcResult = await gatewayAdminRpc('status')
      if (!rpcResult.ok) {
        return res.status(503).json({ error: rpcResult.error })
      }
      res.json({ ok: true, payload: rpcResult.payload })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.get('/api/system/metrics', authMiddleware, async (_req, res) => {
    try {
      const cpus = os.cpus()
      const totalMem = os.totalmem()
      const freeMem = os.freemem()
      const usedMem = totalMem - freeMem

      const diskInfo = await getDiskSpace()
      const diskTotal = diskInfo.total
      const diskFree = diskInfo.free

      let cpuUsage = 0
      for (const cpu of cpus) {
        const total = Object.values(cpu.times).reduce((a, b) => a + b, 0)
        const idle = cpu.times.idle
        cpuUsage += ((total - idle) / total) * 100
      }
      cpuUsage = cpuUsage / cpus.length

      let presence = []
      try {
        if (gateway.isConnected) {
          presence = await gateway.call('system-presence')
          if (!Array.isArray(presence)) {
            presence = presence?.presence || presence?.items || presence?.list || []
          }
        }
      } catch {
        presence = []
      }

      let uptime = os.uptime()
      try {
        const now = Date.now()
        if (!_gatewayHealthCache.data || now - _gatewayHealthCache.ts > GATEWAY_HEALTH_CACHE_TTL) {
          const rpcResult = await gatewayAdminRpc('health')
          if (rpcResult.ok) {
            _gatewayHealthCache = { data: rpcResult.payload, ts: now }
          }
        }
        uptime = _gatewayHealthCache.data?.uptime || uptime
      } catch {
        // use os uptime
      }

      const networkStats = await getNetworkStats()

      res.json({
        ok: true,
        metrics: {
          cpu: {
            usage: Math.round(cpuUsage * 10) / 10,
            cores: cpus.length,
            model: cpus[0]?.model || 'Unknown',
          },
          memory: {
            total: totalMem,
            used: usedMem,
            free: freeMem,
            usagePercent: Math.round((usedMem / totalMem) * 1000) / 10,
          },
          disk: {
            total: diskTotal,
            used: diskTotal - diskFree,
            free: diskFree,
            usagePercent: diskTotal > 0 ? Math.round(((diskTotal - diskFree) / diskTotal) * 1000) / 10 : 0,
          },
          network: {
            bytesReceived: networkStats.bytesReceived,
            bytesSent: networkStats.bytesSent,
          },
          uptime,
          loadAverage: os.loadavg(),
          platform: os.platform(),
          hostname: os.hostname(),
        },
        presence,
      })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.get('/api/npm/versions', (_req, res) => {
    const data = npmVersionsPolling.getData()
    if (data) return res.json(data)
    npmVersionsPolling.refresh().then(() => {
      res.json(npmVersionsPolling.getData() || { versions: [] })
    }).catch(err => {
      console.error('[Server] Failed to fetch npm versions:', err.message)
      res.status(500).json({ error: 'Failed to fetch versions from npm' })
    })
  })

  app.post('/api/npm/update', async (_req, res) => {
    try {
      const { version } = _req.body
      const packageSpec = version ? `openclaw@${version}` : 'openclaw@latest'

      console.log(`[Server] Updating OpenClaw via npm: ${packageSpec}`)

      const { execSync } = await import('child_process')
      const output = execSync(`npm install -g ${packageSpec}`, {
        encoding: 'utf8',
        timeout: 120000
      })

      console.log('[Server] npm update output:', output)

      res.json({
        ok: true,
        message: `Successfully updated to ${packageSpec}`,
        output: output
      })
    } catch (error) {
      console.error('[Server] Failed to update OpenClaw via npm:', error.message)
      res.status(500).json({
        ok: false,
        error: error.message,
        stdout: error.stdout,
        stderr: error.stderr
      })
    }
  })

  app.get('/api/config', authMiddleware, (_req, res) => {
    try {
      let config = {}
      if (existsSync(envPath)) {
        config = parseEnvFile(readFileSync(envPath, 'utf-8'))
      }
      // voiceStt 用 envConfig(process.env 优先 + 文件),与 xfyun-speech 实际调用同源;
      // 容器化部署经 env_file 注入 process.env,容器内可能无 .env 文件,但 envConfig 仍可取值
      const voiceStt = Boolean(envConfig.XFYUN_APP_ID && envConfig.XFYUN_API_KEY && envConfig.XFYUN_API_SECRET)
      res.json({ ok: true, config, features: { voiceStt } })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/config', authMiddleware, (req, res) => {
    try {
      const { AUTH_USERNAME, AUTH_PASSWORD, OPENCLAW_WS_URL, OPENCLAW_AUTH_TOKEN, OPENCLAW_AUTH_PASSWORD } = req.body

      const existingContent = existsSync(envPath) ? readFileSync(envPath, 'utf-8') : ''
      const existing = parseEnvFile(existingContent)

      if (AUTH_USERNAME !== undefined) existing.AUTH_USERNAME = AUTH_USERNAME
      if (AUTH_PASSWORD !== undefined) existing.AUTH_PASSWORD = AUTH_PASSWORD
      if (OPENCLAW_WS_URL !== undefined) existing.OPENCLAW_WS_URL = OPENCLAW_WS_URL
      if (OPENCLAW_AUTH_TOKEN !== undefined) existing.OPENCLAW_AUTH_TOKEN = OPENCLAW_AUTH_TOKEN
      if (OPENCLAW_AUTH_PASSWORD !== undefined) existing.OPENCLAW_AUTH_PASSWORD = OPENCLAW_AUTH_PASSWORD

      const newContent = stringifyEnvFile(existing)
      writeFileSync(envPath, newContent, 'utf-8')

      const oldConfig = { ...envConfig }
      Object.assign(envConfig, existing)

      const wsUrlChanged = oldConfig.OPENCLAW_WS_URL !== envConfig.OPENCLAW_WS_URL
      const tokenChanged = oldConfig.OPENCLAW_AUTH_TOKEN !== envConfig.OPENCLAW_AUTH_TOKEN
      const passwordChanged = oldConfig.OPENCLAW_AUTH_PASSWORD !== envConfig.OPENCLAW_AUTH_PASSWORD

      if (wsUrlChanged || tokenChanged || passwordChanged) {
        console.log('[Config] Gateway config changed, reconnecting...')
        triggerGatewayReconnect()
      }

      console.log('[Config] Configuration reloaded')
      res.json({ ok: true, message: 'Configuration saved and reloaded.' })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.patch('/api/config', authMiddleware, async (req, res) => {
    try {
      const patches = Array.isArray(req.body?.patches) ? req.body.patches : []
      if (patches.length === 0) {
        return res.status(400).json({ ok: false, error: { message: 'Missing patches' } })
      }

      const mergePatch = buildMergePatchFromPatches(patches)
      await configQueueExecute(
        (sourceConfig) => ({ ...sourceConfig, ...mergePatch }),
        'http-config-patch'
      )
      return res.json({ ok: true, payload: {} })
    } catch (err) {
      return res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.get('/api/mcp', authMiddleware, async (req, res) => {
    try {
      console.log('[MCP] GET /api/mcp start')
      const result = await listMcpServers(req.currentTenant)
      console.log('[MCP] GET /api/mcp success:', {
        command: result.command,
        count: Object.keys(result.entries || {}).length,
      })
      res.json({
        ok: true,
        payload: {
          entries: result.entries,
          command: result.command,
        },
        stdout: result.stdout,
        stderr: result.stderr,
      })
    } catch (err) {
      console.error('[MCP] GET /api/mcp failed:', {
        error: err.message,
        details: err.details || [],
        stdoutLength: err.stdout?.length || 0,
        stderrLength: err.stderr?.length || 0,
      })
      res.status(500).json({
        ok: false,
        error: { message: err.message, details: err.details || [] },
        stdout: err.stdout || '',
        stderr: err.stderr || '',
      })
    }
  })

  app.post('/api/mcp', authMiddleware, async (req, res) => {
    try {
      const body = req.body && typeof req.body === 'object' ? req.body : {}
      const servers = Array.isArray(body.servers) ? body.servers : []
      console.log('[MCP] POST /api/mcp start:', {
        count: servers.length,
        keys: servers.map(server => sanitizeMcpKey(server?.key || server?.name) || '(invalid)'),
      })

      if (servers.length === 0) {
        console.warn('[MCP] POST /api/mcp rejected: missing servers')
        return res.status(400).json({ ok: false, error: { message: 'Missing MCP servers' } })
      }

      const setResults = []
      for (const server of servers) {
        const key = sanitizeMcpKey(server?.key || server?.name)
        if (!key) {
          console.warn('[MCP] POST /api/mcp rejected: invalid key')
          return res.status(400).json({ ok: false, error: { message: 'Invalid MCP key' } })
        }

        const payload = buildMcpCliConfig(server)
        console.log('[MCP] CLI set server:', safeMcpServerSummary(key, payload))
        const output = await runOpenClawCli(['mcp', 'set', key, JSON.stringify(payload)], 30_000, req.currentTenant)
        console.log('[MCP] CLI set server success:', {
          key,
          stdoutLength: output.stdout.length,
          stderrLength: output.stderr.length,
        })
        setResults.push({ key, stdout: output.stdout, stderr: output.stderr })
      }

      console.log('[MCP] CLI reload after set')
      const reloadOutput = await runOpenClawCli(['mcp', 'reload'], 30_000, req.currentTenant)
      console.log('[MCP] CLI reload success:', {
        stdoutLength: reloadOutput.stdout.length,
        stderrLength: reloadOutput.stderr.length,
      })

      const probeResults = []
      for (const server of servers) {
        const key = sanitizeMcpKey(server?.key || server?.name)
        if (!key || server?.enabled === false) {
          console.log('[MCP] probe skipped:', { key, enabled: server?.enabled !== false })
          probeResults.push({ key, skipped: true })
          continue
        }
        const probe = {
          key,
          ...(await probeMcpServer(key, 30_000, 4, req.currentTenant)),
        }
        console.log('[MCP] probe result:', {
          key,
          ok: probe.ok,
          skipped: probe.skipped,
          error: probe.error,
          stdoutLength: probe.stdout?.length || 0,
          stderrLength: probe.stderr?.length || 0,
        })
        probeResults.push(probe)
      }

      console.log('[MCP] POST /api/mcp success:', {
        setCount: setResults.length,
        probeCount: probeResults.length,
      })
      res.json({
        ok: true,
        message: 'MCP configuration applied',
        setResults,
        reload: {
          stdout: reloadOutput.stdout,
          stderr: reloadOutput.stderr,
        },
        probeResults,
      })
    } catch (err) {
      console.error('[MCP] POST /api/mcp failed:', {
        error: err.message,
        stdoutLength: err.stdout?.length || 0,
        stderrLength: err.stderr?.length || 0,
      })
      res.status(500).json({
        ok: false,
        error: { message: err.message },
        stdout: err.stdout || '',
        stderr: err.stderr || '',
      })
    }
  })

  app.post('/api/mcp/:key/test', authMiddleware, async (req, res) => {
    const key = sanitizeMcpKey(req.params.key)
    if (!key) {
      return res.status(400).json({ ok: false, error: { message: 'Invalid MCP key' } })
    }

    const startedAt = Date.now()
    try {
      const probe = await probeMcpServer(key, 30_000, 1, req.currentTenant)
      const latencyMs = Date.now() - startedAt
      if (!probe.ok) {
        return res.status(200).json({
          ok: false,
          error: { message: probe.error },
          latencyMs,
        })
      }
      return res.json({
        ok: true,
        payload: {
          key,
          tools: extractMcpToolNames(probe.parsed),
          probeParsed: probe.parsed !== null,
          latencyMs,
        },
      })
    } catch (err) {
      return res.status(200).json({
        ok: false,
        error: { message: err.message || 'MCP connection test failed' },
        latencyMs: Date.now() - startedAt,
      })
    }
  })

  app.patch('/api/mcp/:key/enabled', authMiddleware, async (req, res) => {
    try {
      const key = sanitizeMcpKey(req.params.key)
      const enabled = req.body?.enabled === true
      console.log('[MCP] PATCH /api/mcp/:key/enabled start:', {
        key: key || '(invalid)',
        enabled,
      })
      if (!key) {
        console.warn('[MCP] PATCH /api/mcp/:key/enabled rejected: invalid key')
        return res.status(400).json({ ok: false, error: { message: 'Invalid MCP key' } })
      }

      if (typeof req.body?.enabled !== 'boolean') {
        console.warn('[MCP] PATCH /api/mcp/:key/enabled rejected: invalid enabled value', { key })
        return res.status(400).json({ ok: false, error: { message: 'Invalid enabled value' } })
      }

      const payload = await patchMcpServerEnabled(key, enabled, req.currentTenant)
      console.log('[MCP] PATCH /api/mcp/:key/enabled success:', { key, enabled })
      res.json({
        ok: true,
        payload,
      })
    } catch (err) {
      console.error('[MCP] PATCH /api/mcp/:key/enabled failed:', {
        error: err.message,
      })
      res.status(500).json({
        ok: false,
        error: { message: err.message },
      })
    }
  })

  app.delete('/api/mcp/:key', authMiddleware, async (req, res) => {
    try {
      const key = sanitizeMcpKey(req.params.key)
      console.log('[MCP] DELETE /api/mcp start:', { key: key || '(invalid)' })
      if (!key) {
        console.warn('[MCP] DELETE /api/mcp rejected: invalid key')
        return res.status(400).json({ ok: false, error: { message: 'Invalid MCP key' } })
      }

      const output = await deleteMcpServer(key, req.currentTenant)
      console.log('[MCP] CLI reload after delete:', { key })
      const reloadOutput = await runOpenClawCli(['mcp', 'reload'], 30_000, req.currentTenant)
      console.log('[MCP] DELETE /api/mcp success:', {
        key,
        command: output.command,
        deleteStdoutLength: output.stdout.length,
        deleteStderrLength: output.stderr.length,
        reloadStdoutLength: reloadOutput.stdout.length,
        reloadStderrLength: reloadOutput.stderr.length,
      })
      res.json({
        ok: true,
        message: 'MCP configuration deleted',
        delete: output,
        reload: {
          stdout: reloadOutput.stdout,
          stderr: reloadOutput.stderr,
        },
      })
    } catch (err) {
      console.error('[MCP] DELETE /api/mcp failed:', {
        error: err.message,
        details: err.details || [],
        stdoutLength: err.stdout?.length || 0,
        stderrLength: err.stderr?.length || 0,
      })
      res.status(500).json({
        ok: false,
        error: { message: err.message, details: err.details || [] },
        stdout: err.stdout || '',
        stderr: err.stderr || '',
      })
    }
  })
}

import { buildMergePatchFromPatches } from '../utils/index.js'
