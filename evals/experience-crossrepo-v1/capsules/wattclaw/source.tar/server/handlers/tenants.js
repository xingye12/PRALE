import db from '../database.js'
import { createOpenClawTenant, getAllUserAssignments, moveUserToTenant, getAllTenantStates } from '../core/multi-tenant-gateway.js'
import { syncUserOpenClawConfigForTenantMove } from '../openclaw-config-sync.js'

export function createTenantRoutes(app, { authMiddleware }) {
  app.get('/api/tenants', authMiddleware, (req, res) => {
    try {
      if (req.currentUser.role !== 'admin') {
        return res.status(403).json({ ok: false, error: { message: 'Admin required' } })
      }

      try {
        const data = getAllUserAssignments()
        if (data.tenants.length === 0) {
          const users = db.prepare("SELECT id, username, display_name FROM users ORDER BY username").all()
          return res.json({ ok: true, tenants: [], unassigned: users })
        }
        res.json({ ok: true, ...withTenantAccessUrls(data, req) })
      } catch (e) {
        const users = db.prepare("SELECT id, username FROM users ORDER BY username").all()
        res.json({ ok: true, tenants: [], unassigned: users })
      }
    } catch (err) {
      console.error('[Tenants] List error:', err)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/tenants', authMiddleware, async (req, res) => {
    try {
      if (req.currentUser.role !== 'admin') {
        return res.status(403).json({ ok: false, error: { message: 'Admin required' } })
      }

      const tenant = await createOpenClawTenant()
      res.json({ ok: true, tenant: withTenantAccessUrls({ tenants: [tenant] }, req).tenants[0] })
    } catch (err) {
      console.error('[Tenants] Create tenant error:', err)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.put('/api/tenants/users/:userId', authMiddleware, (req, res) => {
    try {
      if (req.currentUser.role !== 'admin') {
        return res.status(403).json({ ok: false, error: { message: 'Admin required' } })
      }

      const { userId } = req.params
      const { tenantId } = req.body

      if (!tenantId) {
        return res.status(400).json({ ok: false, error: { message: 'tenantId is required' } })
      }

      const user = db.prepare("SELECT id FROM users WHERE id = ?").get(userId)
      if (!user) {
        return res.status(404).json({ ok: false, error: { message: 'User not found' } })
      }

      const result = moveUserToTenant(userId, tenantId, ({ previousTenantId }) => {
        return syncUserOpenClawConfigForTenantMove(userId, tenantId, previousTenantId)
      })
      res.json({ ok: true, ...result })
    } catch (err) {
      console.error('[Tenants] Move user error:', err)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.get('/api/tenants/status', authMiddleware, (req, res) => {
    try {
      if (req.currentUser.role !== 'admin') {
        return res.status(403).json({ ok: false, error: { message: 'Admin required' } })
      }
      const states = getAllTenantStates()
      res.json({ ok: true, tenants: withTenantAccessUrls({ tenants: states }, req).tenants })
    } catch (err) {
      console.error('[Tenants] Status error:', err)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}

function withTenantAccessUrls(data, req) {
  const fallbackHost = requestHostname(req)
  return {
    ...data,
    tenants: (data.tenants || []).map(tenant => {
      const publicProtocol = tenant.publicProtocol || forwardedProtocol(req)
      const publicHost = tenant.publicHost || fallbackHost
      const publicPort = tenant.publicPort || tenant.port
      return {
        ...tenant,
        publicProtocol,
        publicHost,
        publicPort,
        openclawTuiUrl: publicHost && publicPort ? `${publicProtocol}://${publicHost}:${publicPort}/chat?session=main#token=${tenant.token || ''}` : '',
      }
    }),
  }
}

function forwardedProtocol(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim()
  return proto || req.protocol || 'http'
}

function requestHostname(req) {
  const forwarded = String(req.headers['x-forwarded-host'] || '').split(',')[0].trim()
  const raw = forwarded || req.get('host') || req.hostname || ''
  return raw.replace(/:\d+$/, '')
}
