// Terminal (PTY) routes
import { authMiddleware } from '../core/auth.js'
import { terminalSessions } from '../core/index.js'
import pty from 'node-pty'

export function createTerminalRoutes(app) {
  app.get('/api/terminal/stream', authMiddleware, (req, res) => {
    const cols = parseInt(req.query.cols) || 120
    const rows = parseInt(req.query.rows) || 36
    const nodeId = req.query.nodeId || 'local'

    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.setHeader('X-Accel-Buffering', 'no')
    res.flushHeaders()

    const sessionId = randomUUID()

    const sendEvent = (type, data = {}) => {
      const event = { type, sessionId, ...data }
      res.write(`data: ${JSON.stringify(event)}\n\n`)
    }

    try {
      const shell = process.platform === 'win32' ? 'powershell.exe' : process.env.SHELL || '/bin/bash'

      const ptyProcess = pty.spawn(shell, [], {
        name: 'xterm-256color',
        cols,
        rows,
        cwd: process.env.HOME || process.cwd(),
        env: { ...process.env, TERM: 'xterm-256color' }
      })

      terminalSessions.set(sessionId, { ptyProcess, nodeId, res })

      ptyProcess.onData((data) => {
        try {
          sendEvent('output', { data })
        } catch (e) {
          console.error('[Terminal] Error sending output:', e.message)
        }
      })

      ptyProcess.onExit(({ exitCode }) => {
        console.log(`[Terminal] Session ${sessionId} exited with code ${exitCode}`)
        sendEvent('disconnected', { message: `Process exited with code ${exitCode}` })
        terminalSessions.delete(sessionId)
      })

      console.log(`[Terminal] Session ${sessionId} created (shell: ${shell}, size: ${cols}x${rows})`)
      sendEvent('connected', { cols, rows })

      req.on('close', () => {
        console.log(`[Terminal] Client disconnected, cleaning up session ${sessionId}`)
        const session = terminalSessions.get(sessionId)
        if (session) {
          try {
            session.ptyProcess.kill()
          } catch (e) {
            // Process may already be dead
          }
          terminalSessions.delete(sessionId)
        }
      })

    } catch (err) {
      console.error('[Terminal] Failed to create PTY:', err.message)
      sendEvent('error', { message: `Failed to create terminal: ${err.message}` })
      res.end()
    }
  })

  app.post('/api/terminal/input', authMiddleware, (req, res) => {
    const { sessionId, data } = req.body

    if (!sessionId || !data) {
      return res.status(400).json({ ok: false, error: { message: 'sessionId and data are required' } })
    }

    const session = terminalSessions.get(sessionId)
    if (!session) {
      return res.status(404).json({ ok: false, error: { message: 'Session not found' } })
    }

    try {
      session.ptyProcess.write(data)
      res.json({ ok: true })
    } catch (err) {
      console.error('[Terminal] Error writing to PTY:', err.message)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/terminal/resize', authMiddleware, (req, res) => {
    const { sessionId, cols, rows } = req.body

    if (!sessionId || cols === undefined || rows === undefined) {
      return res.status(400).json({ ok: false, error: { message: 'sessionId, cols, and rows are required' } })
    }

    const session = terminalSessions.get(sessionId)
    if (!session) {
      return res.status(404).json({ ok: false, error: { message: 'Session not found' } })
    }

    try {
      session.ptyProcess.resize(cols, rows)
      res.json({ ok: true, cols, rows })
    } catch (err) {
      console.error('[Terminal] Error resizing PTY:', err.message)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/terminal/destroy', authMiddleware, (req, res) => {
    const { sessionId } = req.body

    if (!sessionId) {
      return res.status(400).json({ ok: false, error: { message: 'sessionId is required' } })
    }

    const session = terminalSessions.get(sessionId)
    if (!session) {
      return res.json({ ok: true, message: 'Session already destroyed' })
    }

    try {
      session.ptyProcess.kill()
      terminalSessions.delete(sessionId)
      console.log(`[Terminal] Session ${sessionId} destroyed`)
      res.json({ ok: true })
    } catch (err) {
      console.error('[Terminal] Error destroying PTY:', err.message)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })

  app.post('/api/terminal/heartbeat', authMiddleware, (req, res) => {
    const { sessionId } = req.body

    if (!sessionId) {
      return res.status(400).json({ ok: false, error: { message: 'sessionId is required' } })
    }

    const session = terminalSessions.get(sessionId)
    if (!session) {
      return res.status(404).json({ ok: false, error: { message: 'Session not found' } })
    }

    session.lastHeartbeat = Date.now()
    res.json({ ok: true })
  })
}

import { randomUUID } from 'crypto'
