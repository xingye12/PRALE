// Usage routes — read-only from SQLite:
// SQLite = single source of truth. Gateway sync happens via background jobs
// (Task 4: usage-sync.js). Read path never calls Gateway.

import { authMiddleware, adminMiddleware } from '../core/auth.js'
import {
  getSessionUsage,
  getUserAggregates,
  getAdminUserUsageAggregates,
  hasUsageSyncRows,
} from '../core/session-usage-cache.js'

export function createUsageRoutes(app) {
  app.get('/api/sessions/usage', authMiddleware, async (req, res) => {
    const apmStart = performance.now()
    try {
      const isAdmin = req.currentUser.role === 'admin'
      const userId = req.currentUser.id
      const scopedUserId = isAdmin ? null : userId

      // Single session path — read from SQLite cache only
      const params = {}
      if (req.query.key) params.key = String(req.query.key)

      if (params.key) {
        const cached = getSessionUsage(params.key, userId)
        if (cached) {
          return res.json({ ok: true, payload: _buildSingleSessionResult(cached) })
        }
        return res.json({ ok: true, payload: { sessions: [], totals: {}, aggregates: {} } })
      }

      // Dashboard path — pure SQLite read
      const dateRange = {
        startDate: req.query.startDate || null,
        endDate: req.query.endDate || null,
      }
      const result = getUserAggregates(scopedUserId, dateRange)

      const totalMs = (performance.now() - apmStart).toFixed(1)
      console.log(`[Usage] sqlite aggregate: ${totalMs}ms daily=${result.aggregates.daily.length} byAgent=${result.aggregates.byAgent.length}`)

      // Schedule background sync if no usage rows have been synced yet (Task 4 replaces the no-op)
      if (!hasUsageSyncRows(scopedUserId)) {
        scheduleUsageSyncAfterRead().catch(() => {})
      }

      // Admin user-usage from SQLite
      const response = { ok: true, payload: result }
      if (isAdmin && req.query.include === 'userUsage') {
        response.userUsage = getAdminUserUsageAggregates()
      }
      return res.json(response)
    } catch (err) {
      const totalMs = (performance.now() - apmStart).toFixed(1)
      console.error(`[Usage] error at ${totalMs}ms:`, err.message)
      return res.status(502).json({ ok: false, error: { message: err.message } })
    }
  })

  app.get('/api/usage-totals', authMiddleware, async (req, res) => {
    try {
      const totals = getUserAggregates(req.currentUser.id).totals
      if (!totals || totals.totalTokens === 0) {
        return res.json({ ok: true, totals: null })
      }
      return res.json({ ok: true, totals })
    } catch (err) {
      console.error('[Usage] /api/usage-totals error:', err.message)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  app.get('/api/admin/user-usage', authMiddleware, adminMiddleware, async (req, res) => {
    try {
      const userUsage = getAdminUserUsageAggregates()
      res.json({ ok: true, data: userUsage })
    } catch (err) {
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Read-triggered background sync — delegates to server/index.js scheduleUsageSyncAfterRead. */
let _scheduleUsageSyncFn = null

export function setScheduleUsageSyncFn(fn) { _scheduleUsageSyncFn = fn }

async function scheduleUsageSyncAfterRead() {
  if (_scheduleUsageSyncFn) return _scheduleUsageSyncFn()
}

function _buildSingleSessionResult(cached) {
  return {
    sessions: [{
      key: cached.sessionKey,
      agentId: cached.agentId,
      usage: {
        input: cached.tokenInput,
        output: cached.tokenOutput,
        cacheRead: cached.tokenCacheRead,
        cacheWrite: cached.tokenCacheWrite,
        totalTokens: cached.tokenTotal,
        totalCost: cached.costTotal,
        messageCounts: {
          total: cached.msgTotal,
          user: cached.msgUser,
          assistant: cached.msgAssistant,
          toolCalls: cached.msgToolCalls,
          toolResults: cached.msgToolResults,
          errors: cached.msgErrors,
        },
        toolUsage: {
          tools: cached.toolUsage,
        },
      },
    }],
    totals: {
      input: cached.tokenInput,
      output: cached.tokenOutput,
      cacheRead: cached.tokenCacheRead,
      cacheWrite: cached.tokenCacheWrite,
      totalTokens: cached.tokenTotal,
      totalCost: cached.costTotal,
    },
  }
}

