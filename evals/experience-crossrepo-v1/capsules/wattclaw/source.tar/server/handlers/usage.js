// Usage data aggregation and filtering helpers
// Pure business logic — no route handlers.

export function recomputeUsageFromSessions(result) {
  const sessions = result.sessions || []
  const zeroTotals = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, totalCost: 0, inputCost: 0, outputCost: 0, cacheReadCost: 0, cacheWriteCost: 0, missingCostEntries: 0 }
  const totals = { ...zeroTotals }
  const byModelMap = {}
  const byProviderMap = {}
  const dailyMap = {}
  const toolsMap = {}
  let msgTotal = 0, msgUser = 0, msgAssistant = 0, msgToolCalls = 0, msgToolResults = 0, msgErrors = 0

  for (const s of sessions) {
    const u = s.usage
    if (!u) continue
    totals.input += u.input || 0
    totals.output += u.output || 0
    totals.cacheRead += u.cacheRead || 0
    totals.cacheWrite += u.cacheWrite || 0
    totals.totalTokens += u.totalTokens || 0
    totals.totalCost += u.totalCost || 0
    totals.inputCost += u.inputCost || 0
    totals.outputCost += u.outputCost || 0
    totals.cacheReadCost += u.cacheReadCost || 0
    totals.cacheWriteCost += u.cacheWriteCost || 0

    const mk = `${s.modelProvider || 'unknown'}/${s.model || 'unknown'}`
    if (!byModelMap[mk]) byModelMap[mk] = { provider: s.modelProvider, model: s.model, count: 0, totals: { ...zeroTotals } }
    byModelMap[mk].count++
    const mt = byModelMap[mk].totals
    mt.input += u.input || 0; mt.output += u.output || 0; mt.cacheRead += u.cacheRead || 0; mt.cacheWrite += u.cacheWrite || 0
    mt.totalTokens += u.totalTokens || 0; mt.totalCost += u.totalCost || 0; mt.inputCost += u.inputCost || 0; mt.outputCost += u.outputCost || 0
    mt.cacheReadCost += u.cacheReadCost || 0; mt.cacheWriteCost += u.cacheWriteCost || 0

    const pk = s.modelProvider || 'unknown'
    if (!byProviderMap[pk]) byProviderMap[pk] = { provider: pk, count: 0, totals: { ...zeroTotals } }
    byProviderMap[pk].count++
    const pt = byProviderMap[pk].totals
    pt.input += u.input || 0; pt.output += u.output || 0; pt.cacheRead += u.cacheRead || 0; pt.cacheWrite += u.cacheWrite || 0
    pt.totalTokens += u.totalTokens || 0; pt.totalCost += u.totalCost || 0; pt.inputCost += u.inputCost || 0; pt.outputCost += u.outputCost || 0
    pt.cacheReadCost += u.cacheReadCost || 0; pt.cacheWriteCost += u.cacheWriteCost || 0

    if (u.dailyBreakdown) {
      for (const d of u.dailyBreakdown) {
        if (!dailyMap[d.date]) dailyMap[d.date] = { date: d.date, tokens: 0, cost: 0, messages: 0, toolCalls: 0, errors: 0 }
        dailyMap[d.date].tokens += d.tokens || 0
        dailyMap[d.date].cost += d.cost || 0
      }
    }

    if (u.toolUsage && u.toolUsage.tools) {
      for (const tool of u.toolUsage.tools) {
        toolsMap[tool.name] = (toolsMap[tool.name] || 0) + (tool.count || 0)
      }
    }

    if (u.messageCounts) {
      msgTotal += u.messageCounts.total || 0
      msgUser += u.messageCounts.user || 0
      msgAssistant += u.messageCounts.assistant || 0
      msgToolCalls += u.messageCounts.toolCalls || 0
      msgToolResults += u.messageCounts.toolResults || 0
      msgErrors += u.messageCounts.errors || 0
    }
  }

  result.totals = totals
  if (result.aggregates) {
    result.aggregates.byModel = Object.values(byModelMap)
    result.aggregates.byProvider = Object.values(byProviderMap)
    result.aggregates.daily = Object.values(dailyMap).sort((a, b) => a.date.localeCompare(b.date))
    result.aggregates.messages = { total: msgTotal, user: msgUser, assistant: msgAssistant, toolCalls: msgToolCalls, toolResults: msgToolResults, errors: msgErrors }
    result.aggregates.tools = { totalCalls: Object.values(toolsMap).reduce((s, v) => s + v, 0), uniqueTools: Object.keys(toolsMap).length, tools: Object.entries(toolsMap).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count) }
  }
}

export function detectGatewayUsageFormat(result) {
  if (!result || typeof result !== 'object') return 'session-based'
  const sessions = result.sessions
  const aggregates = result.aggregates
  if (Array.isArray(sessions) && sessions.length > 0) return 'session-based'
  if (!aggregates || typeof aggregates !== 'object') return 'session-based'
  const hasPrecomputed = (
    (Array.isArray(aggregates.byAgent) && aggregates.byAgent.length > 0) ||
    (Array.isArray(aggregates.modelDaily) && aggregates.modelDaily.length > 0) ||
    (Array.isArray(aggregates.dailyLatency) && aggregates.dailyLatency.length > 0)
  )
  return hasPrecomputed ? 'precomputed' : 'session-based'
}

export function filterAggregatesByOwnership(result, userId, isAdmin) {
  if (isAdmin || !result.aggregates) return
  if (Array.isArray(result.aggregates.byChannel)) {
    const userChannelNames = new Set(getUserChannels(userId).map(c => c.name || c.channel_type).filter(Boolean))
    result.aggregates.byChannel = result.aggregates.byChannel.filter(c => userChannelNames.has(c.channel))
  }
}

export function rebuildTotalsFromByAgent(result) {
  if (!result.aggregates || !Array.isArray(result.aggregates.byAgent) || result.aggregates.byAgent.length === 0) {
    return
  }
  const initialTotals = {
    input: 0, output: 0, cacheRead: 0, cacheWrite: 0,
    totalTokens: 0, totalCost: 0, inputCost: 0, outputCost: 0,
    cacheReadCost: 0, cacheWriteCost: 0, missingCostEntries: 0
  }
  result.totals = result.aggregates.byAgent.reduce((acc, agent) => {
    const t = agent.totals || {}
    for (const key in initialTotals) {
      acc[key] += (t[key] || 0)
    }
    return acc
  }, { ...initialTotals })
}

export function rebuildDailyFromModelDaily(result) {
  if (!result.aggregates || !Array.isArray(result.aggregates.modelDaily) || result.aggregates.modelDaily.length === 0) {
    result.aggregates.daily = []
    return
  }
  const dailyMap = {}
  result.aggregates.modelDaily.forEach(item => {
    const date = item.date
    if (!dailyMap[date]) {
      dailyMap[date] = { date: date, tokens: 0, cost: 0, count: 0 }
    }
    dailyMap[date].tokens += (item.tokens || 0)
    dailyMap[date].cost += (item.cost || 0)
    dailyMap[date].count += (item.count || 0)
  })
  result.aggregates.daily = Object.values(dailyMap).sort((a, b) => a.date.localeCompare(b.date))
}

export function rebuildByModelFromModelDaily(result) {
  if (!result.aggregates || !Array.isArray(result.aggregates.modelDaily)) {
    if (result.aggregates) {
      result.aggregates.byModel = []
      result.aggregates.byProvider = []
    }
    return
  }
  const modelMap = {}
  const providerMap = {}
  const zeroTotals = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, totalCost: 0, inputCost: 0, outputCost: 0, cacheReadCost: 0, cacheWriteCost: 0, missingCostEntries: 0 }
  for (const m of result.aggregates.modelDaily) {
    const provider = m.provider || 'unknown'
    const model = m.model || 'unknown'
    const mk = `${provider}/${model}`
    if (!modelMap[mk]) {
      modelMap[mk] = { provider, model, count: 0, totals: { ...zeroTotals } }
    }
    modelMap[mk].count += m.count || 0
    modelMap[mk].totals.totalTokens += m.tokens || 0
    modelMap[mk].totals.totalCost += m.cost || 0

    if (!providerMap[provider]) {
      providerMap[provider] = { provider, model: undefined, count: 0, totals: { ...zeroTotals } }
    }
    providerMap[provider].count += m.count || 0
    providerMap[provider].totals.totalTokens += m.tokens || 0
    providerMap[provider].totals.totalCost += m.cost || 0
  }
  result.aggregates.byModel = Object.values(modelMap).filter(item => item.count > 0 || item.totals.totalTokens > 0 || item.totals.totalCost > 0)
  result.aggregates.byProvider = Object.values(providerMap).filter(item => item.count > 0 || item.totals.totalTokens > 0 || item.totals.totalCost > 0)
}

export function rebuildMessagesAndTools(result) {
  if (!result.aggregates) return
  let msgTotal = 0
  if (Array.isArray(result.aggregates.modelDaily)) {
    for (const m of result.aggregates.modelDaily) {
      msgTotal += m.count || 0
    }
  }
  if (!result.aggregates.messages || typeof result.aggregates.messages !== 'object') {
    result.aggregates.messages = { total: 0, user: 0, assistant: 0, toolCalls: 0, toolResults: 0, errors: 0 }
  }
  if ((result.aggregates.messages.total || 0) === 0 && msgTotal > 0) {
    result.aggregates.messages = { ...result.aggregates.messages, total: msgTotal }
  }
  if (!result.aggregates.tools || typeof result.aggregates.tools !== 'object') {
    result.aggregates.tools = { totalCalls: 0, uniqueTools: 0, tools: [] }
  }
}

export function synthesizeSessionFromByAgent(result, sessionKey) {
  if (!result.aggregates || !Array.isArray(result.aggregates.byAgent) || !sessionKey) return
  const match = sessionKey.match(/^agent:([^:]+):/)
  const agentId = match ? match[1] : null
  if (!agentId) return

  const agent = result.aggregates.byAgent.find(a => {
    const id = a.agentId || a.id || a.agent
    return id === agentId
  })
  if (!agent) return

  const t = agent.totals || {}
  result.sessions = [{
    key: sessionKey,
    usage: {
      input: t.input ?? 0,
      output: t.output ?? 0,
      cacheRead: t.cacheRead ?? 0,
      cacheWrite: t.cacheWrite ?? 0,
      totalTokens: t.totalTokens ?? 0,
      totalCost: t.totalCost ?? 0,
      inputCost: t.inputCost ?? 0,
      outputCost: t.outputCost ?? 0,
      cacheReadCost: t.cacheReadCost ?? 0,
      cacheWriteCost: t.cacheWriteCost ?? 0,
      missingCostEntries: t.missingCostEntries ?? 0,
    }
  }]
}

import { getUserChannels } from '../user-manager.js'

// ---------------------------------------------------------------------------
// User usage mapping — pure data transformation, no I/O
// Extracted from usage-routes.js admin/user-usage handler for reuse.
// ---------------------------------------------------------------------------

export function computeUserUsageMap(allSessions, users, { getUserOwnedSessionKeys, getUserOwnedAgentIds }) {
  // Build session key → userId mapping from explicit session ownership
  const sessionToUser = new Map()
  // Build agentId → userId reverse index (single pass, avoids O(users × sessions))
  const agentToUser = new Map()
  for (const user of users) {
    for (const sk of getUserOwnedSessionKeys(user.id)) {
      sessionToUser.set(sk, user.id)
    }
    for (const aid of getUserOwnedAgentIds(user.id)) {
      agentToUser.set(aid, user.id)
    }
  }

  // Resolve each session to an owner (session key first, then agent ID)
  for (const s of allSessions) {
    const key = s.key || s.sessionKey || ''
    if (sessionToUser.has(key)) continue // already mapped
    const agentId = s.agentId || key.match(/^agent:([^:]+):/)?.[1]
    if (agentId && agentToUser.has(agentId)) {
      sessionToUser.set(key, agentToUser.get(agentId))
    }
  }

  // Initialize per-user accumulators
  const userUsageMap = new Map()
  for (const user of users) {
    userUsageMap.set(user.id, {
      userId: user.id,
      username: user.username,
      displayName: user.display_name || user.username,
      sessionCount: 0,
      totalTokens: 0,
      totalCost: 0,
      inputTokens: 0,
      outputTokens: 0,
    })
  }
  // Unmapped sessions bucket
  userUsageMap.set('__unmapped__', {
    userId: null,
    username: '__unmapped__',
    displayName: '未归属',
    sessionCount: 0,
    totalTokens: 0,
    totalCost: 0,
    inputTokens: 0,
    outputTokens: 0,
  })

  // Accumulate per-session usage into user buckets (single pass)
  for (const s of allSessions) {
    const key = s.key || s.sessionKey || ''
    const ownerId = sessionToUser.get(key) || '__unmapped__'
    const entry = userUsageMap.get(ownerId)
    if (!entry) continue

    const usage = s.usage || s.totals || {}
    entry.sessionCount++
    entry.totalTokens += usage.totalTokens || 0
    entry.totalCost += usage.totalCost || 0
    entry.inputTokens += usage.input || 0
    entry.outputTokens += usage.output || 0
  }

  return Array.from(userUsageMap.values())
    .sort((a, b) => b.totalTokens - a.totalTokens)
}
