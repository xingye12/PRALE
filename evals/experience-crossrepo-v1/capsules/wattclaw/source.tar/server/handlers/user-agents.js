// User agent binding routes + agent workspace query
import { authMiddleware } from '../core/auth.js'
import {
  getUserAgents, createUserAgent, updateUserAgent, deleteUserAgent,
  getUserAgentsList, getAgentWorkspaceForUser,
} from '../user-manager.js'
import { expandHomePath } from '../utils/index.js'

export function createUserAgentRoutes(app) {
  // ── User-Agent CRUD ──
  app.get('/api/user/agents', authMiddleware, (req, res) => {
    const agents = getUserAgentsList(req.currentUser.id)
    res.json({ ok: true, agents })
  })

  app.post('/api/user/agents', authMiddleware, (req, res) => {
    const agent = createUserAgent(req.currentUser.id, req.body)
    res.json({ ok: true, agent })
  })

  app.put('/api/user/agents/:id', authMiddleware, (req, res) => {
    // Authorization check BEFORE mutation
    const owned = getUserAgents(req.currentUser.id)
    if (!owned.find(a => a.id === req.params.id)) {
      return res.status(403).json({ ok: false, error: 'Not your agent' })
    }
    const agent = updateUserAgent(req.params.id, req.body)
    if (!agent) {
      return res.status(404).json({ ok: false, error: 'Agent not found' })
    }
    res.json({ ok: true, agent })
  })

  app.delete('/api/user/agents/:id', authMiddleware, (req, res) => {
    const owned = getUserAgents(req.currentUser.id)
    if (!owned.find(a => a.id === req.params.id)) {
      return res.status(403).json({ ok: false, error: 'Not your agent' })
    }
    deleteUserAgent(req.params.id)
    res.json({ ok: true })
  })

  // ── Agent workspace query ──
  app.get('/api/agents/workspace', authMiddleware, async (req, res) => {
    try {
      const agentId = req.query.agentId || 'main'
      const traceId = typeof req.query.traceId === 'string' ? req.query.traceId : ''
      const workspaceInfo = getAgentWorkspaceForUser(req.currentUser.id, req.currentUser.role, agentId, traceId)
      if (!workspaceInfo) {
        console.info('[ChatFileIndex] workspace lookup failed', {
          traceId,
          requestedAgentId: agentId,
          userId: req.currentUser.id,
          role: req.currentUser.role,
        })
        return res.status(404).json({ ok: false, error: { message: 'Could not determine agent workspace' } })
      }
      console.info('[ChatFileIndex] workspace lookup', {
        traceId,
        requestedAgentId: agentId,
        resolvedAgentId: workspaceInfo.agentId,
        userId: req.currentUser.id,
        role: req.currentUser.role,
        workspace: workspaceInfo.workspace,
        expandedPath: expandHomePath(workspaceInfo.workspace),
      })
      res.json({
        ok: true,
        agentId: workspaceInfo.agentId,
        workspace: workspaceInfo.workspace,
        expandedPath: expandHomePath(workspaceInfo.workspace)
      })
    } catch (err) {
      console.error('[Agents] Workspace error:', err)
      res.status(500).json({ ok: false, error: { message: err.message } })
    }
  })
}
