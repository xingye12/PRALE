// User management routes (admin only)
import { randomUUID } from 'crypto'
import db from '../database.js'
import { authMiddleware, adminMiddleware } from '../core/auth.js'
import {
  listUsers, getUserCount, createUser, updateUser, deleteUser,
} from '../user-manager.js'

function attachFeishuBinding(user) {
  if (!user) return user
  const binding = db.prepare(
    'SELECT feishu_user_id FROM user_oauth_bindings WHERE provider = ? AND user_id = ?'
  ).get('feishu', user.id)
  return { ...user, feishuUserId: binding?.feishu_user_id || null }
}

export function createUserRoutes(app) {
  app.get('/api/users', authMiddleware, adminMiddleware, (req, res) => {
    const limit = parseInt(req.query.limit) || 50
    const offset = parseInt(req.query.offset) || 0
    const search = typeof req.query.search === 'string' ? req.query.search : ''
    const users = listUsers(limit, offset, search).map(attachFeishuBinding)
    const total = getUserCount(search)
    res.json({ ok: true, users, total })
  })

  app.post('/api/users', authMiddleware, adminMiddleware, (req, res) => {
    const { username, password, role, displayName, email, feishuUserId } = req.body
    if (!username || !password) {
      return res.status(400).json({ ok: false, error: 'Username and password required' })
    }
    try {
      const user = createUser({ username, password, role: role || 'user', displayName, email })
      if (feishuUserId) {
        db.prepare(`
          INSERT INTO user_oauth_bindings (id, user_id, provider, feishu_user_id, created_at, updated_at)
          VALUES (?, ?, 'feishu', ?, ?, ?)
        `).run(randomUUID(), user.id, feishuUserId, Date.now(), Date.now())
      }
      res.json({ ok: true, user: attachFeishuBinding(user) })
    } catch (e) {
      res.status(409).json({ ok: false, error: e.message })
    }
  })

  app.put('/api/users/:id', authMiddleware, adminMiddleware, (req, res) => {
    const { role, status, displayName, email, password, feishuUserId } = req.body
    const user = updateUser(req.params.id, { role, status, displayName, email, password })
    if (!user) {
      return res.status(404).json({ ok: false, error: 'User not found' })
    }

    // Sync feishu binding
    if (feishuUserId !== undefined) {
      const existing = db.prepare(
        'SELECT id FROM user_oauth_bindings WHERE provider = ? AND user_id = ?'
      ).get('feishu', req.params.id)

      if (feishuUserId) {
        if (existing) {
          db.prepare(
            'UPDATE user_oauth_bindings SET feishu_user_id = ?, updated_at = ? WHERE id = ?'
          ).run(feishuUserId, Date.now(), existing.id)
        } else {
          db.prepare(`
            INSERT INTO user_oauth_bindings (id, user_id, provider, feishu_user_id, created_at, updated_at)
            VALUES (?, ?, 'feishu', ?, ?, ?)
          `).run(randomUUID(), req.params.id, feishuUserId, Date.now(), Date.now())
        }
      } else if (existing) {
        db.prepare('DELETE FROM user_oauth_bindings WHERE id = ?').run(existing.id)
      }
    }

    res.json({ ok: true, user: attachFeishuBinding(user) })
  })

  app.delete('/api/users/:id', authMiddleware, adminMiddleware, (req, res) => {
    if (req.params.id === req.currentUser.id) {
      return res.status(400).json({ ok: false, error: 'Cannot delete yourself' })
    }
    deleteUser(req.params.id)
    res.json({ ok: true })
  })
}
