// Workspace file sharing and upload routes
import { authMiddleware } from '../core/auth.js'
import { envConfig } from '../core/index.js'
import { gatewayExec } from '../core/system.js'
import { getAgentWorkspaceForUser } from '../user-manager.js'
import { uploadToGateway } from '../gateway-file-transfer.js'
import { generateShareHtml } from '../share-generator.js'
import { expandHomePath } from '../utils/index.js'
import db from '../database.js'
import multer from 'multer'
import { randomUUID } from 'crypto'
import { join, basename, extname } from 'path'
import { existsSync, mkdirSync, promises as fsPromises } from 'fs'
import mammoth from 'mammoth'

// Multer instances for workspace uploads
const chatUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }
})
const gatewayUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }
})

const sharedDir = join(import.meta.dirname, '..', '..', 'data', 'shared')
mkdirSync(sharedDir, { recursive: true })

function normalizeUploadedFilename(name) {
  if (!name || typeof name !== 'string') return 'unnamed-file'
  try {
    const decoded = Buffer.from(name, 'latin1').toString('utf8')
    if (decoded && !decoded.includes('�') && decoded !== name) {
      return decoded
    }
  } catch { /* fallback to original */ }
  return name
}

// ── File preview helpers for share feature ──
const IMAGE_EXTS = new Set(['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'bmp', 'ico'])
const TEXT_EXTS = new Set(['txt', 'md', 'js', 'ts', 'py', 'json', 'yaml', 'yml', 'xml', 'html', 'css', 'sh', 'bash', 'go', 'rs', 'java', 'c', 'cpp', 'h', 'hpp', 'sql', 'log', 'csv', 'env', 'toml', 'ini', 'cfg', 'conf'])
const DOCX_EXTS = new Set(['docx', 'doc'])
const PDF_EXTS = new Set(['pdf'])

function getFilePreviewType(ext) {
  if (IMAGE_EXTS.has(ext)) return 'image'
  if (TEXT_EXTS.has(ext)) return 'text'
  if (DOCX_EXTS.has(ext)) return 'docx'
  if (PDF_EXTS.has(ext)) return 'pdf'
  return 'binary'
}

const SHARE_FILE_SIZE_LIMIT = 50 * 1024 * 1024
const SAFE_REMOTE_PATH_RE = /^\/[A-Za-z0-9/._-]+$/

async function collectShareFiles(messages, shareId) {
  const fileDir = join(sharedDir, shareId)
  const attachments = new Map()

  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i]
    if (msg.role !== 'user' || !msg.files || msg.files.length === 0) continue

    const msgFiles = []
    for (const f of msg.files) {
      const remotePath = f.name
      if (!remotePath || !remotePath.startsWith('/') || !SAFE_REMOTE_PATH_RE.test(remotePath)) continue
      if (f.size && f.size > SHARE_FILE_SIZE_LIMIT) continue

      try {
        const baseName = basename(remotePath)
        const ext = extname(baseName).slice(1).toLowerCase()
        const previewType = getFilePreviewType(ext)

        const content = await gatewayExec(`base64 "${remotePath}" | tr -d '\\n'`)
        if (!content || content.length < 10) continue

        const buffer = Buffer.from(content, 'base64')
        if (buffer.length < 4) continue

        mkdirSync(fileDir, { recursive: true })
        const targetPath = join(fileDir, baseName)
        await fsPromises.writeFile(targetPath, buffer)

        const fileInfo = {
          name: baseName,
          size: f.size || buffer.length,
          publicUrl: `/shared/${shareId}/${encodeURIComponent(baseName)}`,
          previewType,
        }

        if (previewType === 'docx') {
          try {
            const result = await mammoth.convertToHtml({ buffer })
            fileInfo.previewHtml = result.value || ''
          } catch (e) {
            console.error(`[Share] mammoth convert failed for ${baseName}:`, e.message)
          }
        }

        msgFiles.push(fileInfo)
      } catch (err) {
        console.error(`[Share] Failed to fetch file ${remotePath}:`, err.message)
      }
    }

    if (msgFiles.length > 0) {
      attachments.set(i, msgFiles)
    }
  }

  return attachments
}

export function createWorkspaceRoutes(app) {
  // Chat attachment upload — stores files locally
  app.post('/api/workspace/upload', authMiddleware, chatUpload.array('files', 5), async (req, res) => {
    try {
      const sessionKey = req.body.sessionKey
      if (!sessionKey) {
        return res.status(400).json({ ok: false, error: 'sessionKey required' })
      }

      const files = req.files
      if (!files || files.length === 0) {
        return res.status(400).json({ ok: false, error: 'No files uploaded' })
      }

      const uploadDir = join(process.cwd(), 'data', 'uploads', sessionKey)
      if (!existsSync(uploadDir)) {
        mkdirSync(uploadDir, { recursive: true })
      }

      const results = []
      for (const file of files) {
        const originalName = normalizeUploadedFilename(file.originalname)
        const filename = `${Date.now()}_${originalName}`
        const filePath = join(uploadDir, filename)
        await fsPromises.writeFile(filePath, file.buffer)
        results.push({
          name: originalName,
          path: filePath,
          size: file.size,
          url: `/api/workspace/uploads/${sessionKey}/${filename}`,
        })
      }

      res.json({ ok: true, files: results })
    } catch (err) {
      console.error('[Workspace] Upload error:', err)
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  // Serve uploaded files
  app.get('/api/workspace/uploads/:sessionKey/:filename', authMiddleware, async (req, res) => {
    try {
      const { sessionKey, filename } = req.params
      const filePath = join(process.cwd(), 'data', 'uploads', sessionKey, filename)
      if (!existsSync(filePath)) {
        return res.status(404).json({ ok: false, error: 'File not found' })
      }
      res.sendFile(filePath)
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message })
    }
  })

  // Share session — generates a static HTML file
  app.post('/api/workspace/share', authMiddleware, async (req, res) => {
    try {
      const { sessionKey, messages, title } = req.body
      if (!sessionKey || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ ok: false, error: 'sessionKey and messages required' })
      }

      const row = db.prepare('SELECT id, user_id FROM user_sessions WHERE session_key = ?').get(sessionKey)
      if (!row || (row.user_id !== req.currentUser.id && req.currentUser.role !== 'admin')) {
        return res.status(403).json({ ok: false, error: 'Access denied' })
      }

      const shareId = randomUUID().replace(/-/g, '').slice(0, 12)
      const sessionTitle = title || '分享的会话'

      const fileAttachments = await collectShareFiles(messages, shareId)
      for (const [idx, attachFiles] of fileAttachments) {
        const msg = messages[idx]
        if (!msg || !msg.files) continue
        for (const af of attachFiles) {
          const mf = msg.files.find(f => basename(f.name) === af.name)
          if (mf) {
            mf.publicUrl = af.publicUrl
            mf.previewType = af.previewType
            if (af.previewHtml) mf.previewHtml = af.previewHtml
          }
        }
      }
      const html = generateShareHtml({ title: sessionTitle, messages })

      const filePath = join(sharedDir, `${shareId}.html`)
      await fsPromises.writeFile(filePath, html, 'utf-8')

      res.json({ ok: true, url: `/shared/${shareId}.html`, id: shareId })
    } catch (err) {
      console.error('[Share] Error:', err)
      res.status(500).json({ ok: false, error: 'Share generation failed' })
    }
  })

  // Workspace file upload — transfers file to Gateway via SSH/SFTP
  app.post('/api/workspace/upload-to-gateway', authMiddleware, gatewayUpload.single('file'), async (req, res) => {
    try {
      const file = req.file
      if (!file) {
        return res.status(400).json({ ok: false, error: 'No file provided' })
      }

      const MAX_SIZE = 100 * 1024 * 1024
      if (file.size > MAX_SIZE) {
        return res.status(413).json({ ok: false, error: 'File too large (max 100 MB)' })
      }

      const agentId = req.body?.agentId
      if (typeof agentId !== 'string' || !agentId.trim()) {
        return res.status(400).json({ ok: false, error: 'agentId is required' })
      }

      const workspaceInfo = getAgentWorkspaceForUser(req.currentUser.id, req.currentUser.role, agentId)
      if (!workspaceInfo) {
        return res.status(404).json({ ok: false, error: 'Could not determine agent workspace' })
      }

      const targetDir = `${expandHomePath(workspaceInfo.workspace)}/uploads`

      const originalName = normalizeUploadedFilename(file.originalname)
      const result = await uploadToGateway(file.buffer, originalName, envConfig, targetDir)
      res.json({ ok: true, ...result })
    } catch (err) {
      console.error('[Workspace] Upload error:', err.message)
      res.status(502).json({ ok: false, error: `Upload to Gateway failed: ${err.message}` })
    }
  })
}
