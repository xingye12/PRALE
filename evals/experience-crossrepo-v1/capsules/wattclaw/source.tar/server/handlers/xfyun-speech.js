import { createHmac } from 'crypto'
import { WebSocket, WebSocketServer } from 'ws'
import { checkAuth } from '../core/auth.js'

const XFYUN_HOST = 'iat-api.xfyun.cn'
const XFYUN_PATH = '/v2/iat'

function getXfyunConfig(envConfig) {
  return {
    appId: envConfig.XFYUN_APP_ID || '',
    apiKey: envConfig.XFYUN_API_KEY || '',
    apiSecret: envConfig.XFYUN_API_SECRET || '',
  }
}

function createXfyunUrl(config) {
  const date = new Date().toUTCString()
  const signatureOrigin = `host: ${XFYUN_HOST}\ndate: ${date}\nGET ${XFYUN_PATH} HTTP/1.1`
  const signature = createHmac('sha256', config.apiSecret).update(signatureOrigin).digest('base64')
  const authorizationOrigin = `api_key="${config.apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`
  const authorization = Buffer.from(authorizationOrigin).toString('base64')
  const search = new URLSearchParams({ authorization, date, host: XFYUN_HOST })
  return `wss://${XFYUN_HOST}${XFYUN_PATH}?${search.toString()}`
}

function parseXfyunText(result) {
  const words = result?.ws
  if (!Array.isArray(words)) return ''
  return words
    .map((item) => Array.isArray(item?.cw) ? item.cw[0]?.w || '' : '')
    .join('')
}

function sendJson(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload))
  }
}

function sendError(ws, message) {
  console.error('[XFYUN Speech]', message)
  sendJson(ws, { type: 'error', message })
}

function closeWithError(ws, message, code = 1011) {
  sendError(ws, message)
  setTimeout(() => ws.close(code, message.slice(0, 120)), 30)
}

export function attachXfyunSpeechProxy(server, envConfig) {
  const wss = new WebSocketServer({ noServer: true })

  server.on('upgrade', (req, socket, head) => {
    const url = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`)
    if (url.pathname !== '/api/speech/xfyun') return

    req.query = Object.fromEntries(url.searchParams.entries())
    if (!checkAuth(req)) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n')
      socket.destroy()
      return
    }

    wss.handleUpgrade(req, socket, head, (clientWs) => {
      wss.emit('connection', clientWs, req)
    })
  })

  wss.on('connection', (clientWs) => {
    const config = getXfyunConfig(envConfig)
    if (!config.appId || !config.apiKey || !config.apiSecret) {
      closeWithError(clientWs, 'XFYUN speech config is missing')
      return
    }

    const xfyunWs = new WebSocket(createXfyunUrl(config))
    let initialized = false
    let closing = false
    let finalPending = false
    let resultText = ''
    let resultTextTemp = ''
    const pendingAudio = []

    function sendInitialFrame() {
      sendJson(xfyunWs, {
        common: { app_id: config.appId },
        business: {
          language: 'zh_cn',
          domain: 'iat',
          accent: 'mandarin',
          vad_eos: 5000,
          dwa: 'wpgs',
        },
        data: {
          status: 0,
          format: 'audio/L16;rate=16000',
          encoding: 'raw',
        },
      })
      initialized = true
    }

    function sendAudioFrame(audio, status) {
      sendJson(xfyunWs, {
        data: {
          status,
          format: 'audio/L16;rate=16000',
          encoding: 'raw',
          audio,
        },
      })
    }

    function flushPendingAudio() {
      while (pendingAudio.length > 0 && xfyunWs.readyState === WebSocket.OPEN) {
        sendAudioFrame(pendingAudio.shift(), 1)
      }
    }

    function sendFinalFrame() {
      if (xfyunWs.readyState === WebSocket.OPEN) {
        sendAudioFrame('', 2)
      } else {
        finalPending = true
      }
    }

    xfyunWs.on('open', () => {
      sendInitialFrame()
      flushPendingAudio()
      if (finalPending) sendFinalFrame()
    })

    xfyunWs.on('message', (data) => {
      let payload = null
      try {
        payload = JSON.parse(data.toString())
      } catch {
        return
      }

      if (payload.code && payload.code !== 0) {
        closeWithError(clientWs, payload.message || 'XFYUN speech recognition failed')
        return
      }

      const result = payload.data?.result
      const text = parseXfyunText(result)
      if (text) {
        if (result?.pgs) {
          if (result.pgs === 'apd') resultText = resultTextTemp
          resultTextTemp = resultText + text
        } else {
          resultText += text
        }
        sendJson(clientWs, {
          type: 'result',
          text: resultTextTemp || resultText,
          isFinal: payload?.data?.status === 2,
        })
      }
      if (payload?.data?.status === 2) {
        closing = true
        clientWs.close(1000, 'speech done')
      }
    })

    xfyunWs.on('error', (error) => {
      closeWithError(clientWs, error.message || 'XFYUN speech socket error')
    })

    xfyunWs.on('close', () => {
      if (!closing && clientWs.readyState === WebSocket.OPEN) {
        sendError(clientWs, 'XFYUN speech upstream closed')
        clientWs.close(1011, 'speech upstream closed')
      }
    })

    clientWs.on('message', (data, isBinary) => {
      if (!isBinary) {
        const message = data.toString()
        if (message === 'end') {
          sendFinalFrame()
          return
        }
        return
      }

      const audio = Buffer.from(data).toString('base64')
      if (xfyunWs.readyState === WebSocket.OPEN && initialized) {
        sendAudioFrame(audio, 1)
      } else {
        pendingAudio.push(audio)
      }
    })

    clientWs.on('close', () => {
      closing = true
      if (xfyunWs.readyState === WebSocket.OPEN) {
        sendFinalFrame()
        xfyunWs.close()
      }
    })
  })
}
