#!/usr/bin/env python3
"""ACP TCP Bridge — Exposes Hermes ACP agent over TCP.

Listens on a TCP port (default 3100) and bridges each connection to
the Hermes ACP agent using asyncio streams, speaking the same JSON-RPC
protocol as stdio ACP but over TCP.

Usage:
    python acp-tcp-server.py [--port PORT] [--host HOST]

Environment:
    ACP_TCP_PORT  — port (default 3100)
    ACP_TCP_HOST  — bind address (default 0.0.0.0)
"""

import asyncio
import datetime
import json
import logging
import os
import re
import signal
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Callable

ACP_TCP_STREAM_LIMIT = int(os.environ.get("ACP_TCP_STREAM_LIMIT", str(64 * 1024 * 1024)))

# Ensure Hermes source is on sys.path
project_root = str(Path("/opt/hermes"))
if project_root not in sys.path:
    sys.path.insert(0, project_root)


def _setup_logging() -> None:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)


def _load_env() -> None:
    from hermes_cli.env_loader import load_hermes_dotenv
    from hermes_constants import get_hermes_home

    hermes_home = get_hermes_home()
    load_hermes_dotenv(hermes_home=hermes_home)


logger = logging.getLogger("acp-tcp-server")

_API_CALL_RE = re.compile(
    r"API call #(?P<index>\d+):\s+"
    r"model=(?P<model>\S+)\s+"
    r"provider=(?P<provider>\S+)\s+"
    r"in=(?P<input>\d+)\s+"
    r"out=(?P<output>\d+)\s+"
    r"total=(?P<total>\d+)\s+"
    r"latency=(?P<latency>[0-9.]+)s"
    r"(?:\s+cache=(?P<cache_read>\d+)(?:/(?P<cache_base>\d+))?\s+\((?P<cache_pct>\d+)%\))?"
)
_OBS_BRIDGES: set["_OpenClawObservabilityBridge"] = set()
_OBS_LOG_HANDLER_INSTALLED = False
_SENSITIVE_OBSERVABILITY_KEYS = {
    "apikey",
    "api_key",
    "authorization",
    "authtoken",
    "access_token",
    "accesstoken",
    "cookie",
    "credential",
    "credentials",
    "password",
    "privatekey",
    "private_key",
    "secret",
    "token",
}


def _now_ms() -> int:
    return int(time.time() * 1000)


def _to_nonnegative_int(value: Any, default: int = 0) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return number if number >= 0 else default


def _as_record(value: Any) -> dict[str, Any] | None:
    return value if isinstance(value, dict) else None


def _read_openclaw_meta_payload(data: dict[str, Any]) -> dict[str, Any] | None:
    meta = _as_record(data.get("_meta"))
    if not meta:
        return None
    openclaw = meta.get("openclaw")
    return openclaw if isinstance(openclaw, dict) else None


def _ensure_openclaw_meta(data: dict[str, Any]) -> dict[str, Any]:
    meta = data.get("_meta")
    if not isinstance(meta, dict):
        meta = {}
        data["_meta"] = meta
    openclaw = meta.get("openclaw")
    if not isinstance(openclaw, dict):
        openclaw = {}
        meta["openclaw"] = openclaw
    return openclaw


def _read_text(value: Any) -> str | None:
    if isinstance(value, str):
        stripped = value.strip()
        return stripped or None
    if isinstance(value, list):
        parts = [_read_text(item) for item in value]
        text = "".join(part for part in parts if part)
        return text or None
    if isinstance(value, dict):
        return _read_text(value.get("text")) or _read_text(value.get("content"))
    return None


def _redact_observability_text(value: str) -> str:
    try:
        from agent.redact import redact_sensitive_text

        return redact_sensitive_text(value, force=True)
    except Exception:
        return value


def _redact_observability_value(value: Any) -> Any:
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            normalized_key = str(key).replace("-", "_").lower()
            compact_key = normalized_key.replace("_", "")
            if normalized_key in _SENSITIVE_OBSERVABILITY_KEYS or compact_key in _SENSITIVE_OBSERVABILITY_KEYS:
                result[str(key)] = "[REDACTED]"
            else:
                result[str(key)] = _redact_observability_value(item)
        return result
    if isinstance(value, (list, tuple)):
        return [_redact_observability_value(item) for item in value]
    if isinstance(value, str):
        return _redact_observability_text(value)
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return _redact_observability_text(str(value))


def _effective_system_prompt(agent: Any) -> str:
    system_prompt = getattr(agent, "_cached_system_prompt", None)
    if not isinstance(system_prompt, str):
        build_system_prompt = getattr(agent, "_build_system_prompt", None)
        if callable(build_system_prompt):
            try:
                system_prompt = build_system_prompt()
            except Exception:
                logger.debug("Failed to build Hermes system prompt for observability", exc_info=True)
                system_prompt = ""
    ephemeral = getattr(agent, "ephemeral_system_prompt", None)
    parts = [part.strip() for part in (system_prompt, ephemeral) if isinstance(part, str) and part.strip()]
    return _redact_observability_text("\n\n".join(parts))


def _read_tool_output_record(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
        except Exception:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


def _tool_event_id(data: dict[str, Any]) -> str:
    explicit = _tool_event_explicit_id(data)
    if explicit:
        return explicit
    name = _tool_event_name(data) or "tool"
    return f"openclaw:{name}:{uuid.uuid4().hex[:12]}"


def _tool_event_explicit_id(data: dict[str, Any]) -> str | None:
    nested = _as_record(data.get("toolCall")) or _as_record(data.get("tool_call")) or {}
    for key in ("id", "toolCallId", "tool_call_id"):
        value = data.get(key) or nested.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _tool_event_name(data: dict[str, Any]) -> str:
    nested = _as_record(data.get("toolCall")) or _as_record(data.get("tool_call")) or {}
    for key in ("name", "toolName", "tool_name"):
        value = data.get(key) or nested.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _tool_error_fields(data: dict[str, Any]) -> tuple[str | None, str | None]:
    error = _as_record(data.get("error"))
    output = (
        _read_tool_output_record(data.get("rawOutput"))
        or _read_tool_output_record(data.get("output"))
        or _read_tool_output_record(data.get("content"))
    )
    output_status = output.get("status")
    normalized_output_status = output_status.lower() if isinstance(output_status, str) else ""
    output_failed = (
        output.get("success") is False
        or normalized_output_status in ("error", "errored", "failed", "failure", "cancelled", "canceled")
    )
    code = None
    message = None
    if error:
        code = error.get("code") if isinstance(error.get("code"), str) else None
        message = error.get("message") if isinstance(error.get("message"), str) else None
    if not message:
        raw_error = data.get("error")
        message = raw_error if isinstance(raw_error, str) and raw_error.strip() else None
    if output:
        code = code or (output.get("code") if isinstance(output.get("code"), str) else None)
        message = message or (output.get("error") if isinstance(output.get("error"), str) else None)
        if output_failed:
            message = message or (output.get("message") if isinstance(output.get("message"), str) else None)
    message = message or (data.get("message") if isinstance(data.get("message"), str) else None)
    return code, message


def _infer_tool_status(data: dict[str, Any]) -> str:
    raw_status = data.get("status")
    status = raw_status.lower() if isinstance(raw_status, str) else ""
    if status in ("completed", "failed", "cancelled"):
        return status
    if status in ("success", "succeeded", "ok"):
        return "completed"
    if status in ("error", "errored", "failure"):
        return "failed"
    output = (
        _read_tool_output_record(data.get("rawOutput"))
        or _read_tool_output_record(data.get("output"))
        or _read_tool_output_record(data.get("content"))
    )
    output_status = output.get("status")
    if isinstance(output_status, str):
        normalized = output_status.lower()
        if normalized in ("failed", "error", "errored", "failure"):
            return "failed"
        if normalized in ("cancelled", "canceled"):
            return "cancelled"
        if normalized in ("completed", "success", "succeeded", "ok"):
            return "completed"
    if output.get("success") is False:
        return "failed"
    if _tool_error_fields(data)[1]:
        return "failed"
    return "completed"


class _OpenClawHermesLogHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        if getattr(record, "_openclaw_observability_seen", False):
            return
        bridges = list(_OBS_BRIDGES)
        if not bridges:
            return
        record_session_id = None
        for field in ("session_id", "sessionId", "conversation_id", "conversationId"):
            value = getattr(record, field, None)
            if isinstance(value, str) and value.strip():
                record_session_id = value.strip()
                break
        eligible = [
            bridge
            for bridge in bridges
            if not bridge.closed
            and not bridge.source_llm_events_seen
            and (not record_session_id or bridge.session_id == record_session_id)
        ]
        if not eligible and record_session_id:
            eligible = [bridge for bridge in bridges if not bridge.closed and not bridge.source_llm_events_seen]
        if len(eligible) != 1:
            logger.debug(
                "Skipping Hermes API-call log observation: %d eligible fallback ACP clients",
                len(eligible),
            )
            return
        setattr(record, "_openclaw_observability_seen", True)
        eligible[0].handle_log_record(record)


def _install_observability_log_handler() -> None:
    global _OBS_LOG_HANDLER_INSTALLED
    if _OBS_LOG_HANDLER_INSTALLED:
        return
    handler = _OpenClawHermesLogHandler()
    handler.setLevel(logging.INFO)
    for logger_name in ("", "agent.conversation_loop", "run_agent"):
        logging.getLogger(logger_name).addHandler(handler)
    _OBS_LOG_HANDLER_INSTALLED = True


class _OpenClawObservabilityBridge:
    def __init__(
        self,
        writer: asyncio.StreamWriter,
        original_write: Any,
        loop: asyncio.AbstractEventLoop,
        session_snapshot_reader: Callable[[str | None], dict[str, Any]] | None = None,
    ):
        self.writer = writer
        self.original_write = original_write
        self.loop = loop
        self.session_snapshot_reader = session_snapshot_reader
        self.tool_starts: dict[str, int] = {}
        self.tool_ids_by_name: dict[str, list[str]] = {}
        self.session_id: str | None = None
        self.last_llm_error: dict[str, str] | None = None
        self.llm_calls: list[dict[str, Any]] = []
        self.llm_call_count = 0
        self.source_llm_events_seen = False
        self.closed = False

    def attach(self) -> None:
        _OBS_BRIDGES.add(self)

    def detach(self) -> None:
        self.closed = True
        _OBS_BRIDGES.discard(self)

    def handle_log_record(self, record: logging.LogRecord) -> None:
        if self.closed:
            return
        message = record.getMessage()
        match = _API_CALL_RE.search(message)
        if match:
            if self.source_llm_events_seen:
                return
            latency_ms = int(float(match.group("latency")) * 1000)
            finished_at = _now_ms()
            started_at = max(0, finished_at - latency_ms)
            cache_read = int(match.group("cache_read") or "0")
            prompt_tokens = int(match.group("input"))
            input_tokens = max(0, prompt_tokens - cache_read)
            output_tokens = int(match.group("output"))
            total_tokens = int(match.group("total"))
            snapshot = self._session_snapshot()
            usage = {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
                "cache_read_tokens": cache_read,
                "cache_write_tokens": 0,
            }
            self.llm_call_count += 1
            call = {
                "callId": f"llm-{match.group('index')}",
                "startedAt": started_at,
                "finishedAt": finished_at,
                "durationMs": latency_ms,
                "model": match.group("model") or snapshot.get("model", ""),
                "provider": match.group("provider") or snapshot.get("provider", ""),
                "systemPrompt": snapshot.get("systemPrompt", ""),
                "stopReason": "",
                "usage": usage,
                "cacheHitRate": int(match.group("cache_pct") or "0"),
            }
            self.llm_calls.append(call)
            self._emit_session_update({
                "sessionUpdate": "agent_llm_call",
                "_meta": {"openclaw": call},
            })
            return

        if record.levelno >= logging.ERROR and record.name.startswith(("agent.", "run_agent")):
            error = {"code": record.name, "message": message or "Hermes LLM call failed"}
            self.last_llm_error = error
            if self.source_llm_events_seen:
                return
            now = _now_ms()
            self.llm_call_count += 1
            self._emit_session_update({
                "sessionUpdate": "agent_llm_call",
                "_meta": {
                    "openclaw": {
                        "callId": f"llm-error-{uuid.uuid4().hex[:12]}",
                        "startedAt": now,
                        "finishedAt": now,
                        "model": "",
                        "stopReason": "error",
                        "usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                        "error": error,
                    }
                },
            })

    def _emit_session_update(self, update: dict[str, Any]) -> None:
        params: dict[str, Any] = {"update": update}
        if self.session_id:
            params["sessionId"] = self.session_id
        payload = {
            "jsonrpc": "2.0",
            "method": "session/update",
            "params": params,
        }
        raw = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
        self.loop.call_soon_threadsafe(self.original_write, raw)

    def _session_snapshot(self) -> dict[str, Any]:
        if not self.session_snapshot_reader:
            return {}
        try:
            snapshot = self.session_snapshot_reader(self.session_id)
            return snapshot if isinstance(snapshot, dict) else {}
        except Exception:
            logger.debug("Failed to read Hermes observability session snapshot", exc_info=True)
            return {}

    def patch_outgoing_frame(self, data: bytes) -> bytes:
        try:
            text = data.decode("utf-8")
        except Exception:
            return data
        lines = text.splitlines(keepends=False)
        if not lines:
            return data
        changed = False
        patched_lines: list[str] = []
        for line in lines:
            stripped = line.strip()
            if not stripped:
                patched_lines.append(line)
                continue
            try:
                payload = json.loads(stripped)
            except Exception:
                patched_lines.append(line)
                continue
            if isinstance(payload, dict) and self._patch_json_payload(payload):
                changed = True
                patched_lines.append(json.dumps(payload, ensure_ascii=False))
            else:
                patched_lines.append(line)
        if not changed:
            return data
        suffix = "\n" if text.endswith("\n") else ""
        return ("\n".join(patched_lines) + suffix).encode("utf-8")

    def _patch_json_payload(self, payload: dict[str, Any]) -> bool:
        changed = False
        method = payload.get("method")
        if method == "session/update":
            params = _as_record(payload.get("params")) or {}
            session_id = params.get("sessionId") or params.get("session_id")
            if isinstance(session_id, str) and session_id:
                self.session_id = session_id
            update = _as_record(params.get("update")) or params
            changed = self._patch_session_update(update) or changed

        result = _as_record(payload.get("result"))
        if result is not None:
            session_id = result.get("sessionId") or result.get("session_id")
            if isinstance(session_id, str) and session_id:
                self.session_id = session_id
            changed = self._patch_prompt_result(result) or changed
        return changed

    def _patch_session_update(self, update: dict[str, Any]) -> bool:
        session_update = update.get("sessionUpdate", "")
        if session_update == "agent_llm_call":
            self.source_llm_events_seen = True
            self.llm_call_count += 1
            return False
        if session_update in ("tool_call_begin", "toolCallBegin", "tool_call"):
            explicit_tool_id = _tool_event_explicit_id(update)
            tool_id = explicit_tool_id or _tool_event_id(update)
            changed = False
            if not explicit_tool_id:
                update["toolCallId"] = tool_id
                changed = True
            tool_name = _tool_event_name(update) or "tool"
            self.tool_ids_by_name.setdefault(tool_name, []).append(tool_id)
            started_at = _read_openclaw_meta_payload(update) or {}
            raw_started = started_at.get("startedAt")
            self.tool_starts[tool_id] = int(raw_started) if isinstance(raw_started, (int, float)) else _now_ms()
            return changed

        if session_update not in ("tool_call_end", "tool_call_update", "toolCallEnd"):
            return False

        changed = False
        tool_id = _tool_event_explicit_id(update)
        if not tool_id:
            tool_name = _tool_event_name(update) or "tool"
            tool_ids = self.tool_ids_by_name.get(tool_name) or []
            tool_id = tool_ids.pop(0) if tool_ids else _tool_event_id(update)
            update["toolCallId"] = tool_id
            changed = True
        finished_at = _now_ms()
        started_at = self.tool_starts.pop(tool_id, finished_at)
        inferred_status = _infer_tool_status(update)
        raw_status = update.get("status")
        status = raw_status if raw_status in ("completed", "failed", "cancelled") else inferred_status
        if raw_status not in ("completed", "failed", "cancelled"):
            update["status"] = status
            changed = True
        if status in ("failed", "cancelled") and not isinstance(update.get("error"), dict):
            code, message = _tool_error_fields(update)
            update["error"] = {
                "code": code or ("TOOL_CANCELLED" if status == "cancelled" else "TOOL_FAILED"),
                "message": message or ("Tool call cancelled" if status == "cancelled" else "Tool call failed"),
            }
            changed = True
        openclaw = _ensure_openclaw_meta(update)
        if not isinstance(openclaw.get("startedAt"), (int, float)):
            openclaw["startedAt"] = started_at
            changed = True
        if not isinstance(openclaw.get("finishedAt"), (int, float)):
            openclaw["finishedAt"] = finished_at
            changed = True
        if not isinstance(openclaw.get("durationMs"), (int, float)):
            openclaw["durationMs"] = max(0, int(openclaw["finishedAt"]) - int(openclaw["startedAt"]))
            changed = True
        return changed

    def _patch_prompt_result(self, result: dict[str, Any]) -> bool:
        changed = False
        if self.llm_call_count == 0 and not self.source_llm_events_seen:
            usage = _as_record(result.get("usage"))
            if usage:
                now = _now_ms()
                cache_read_tokens = _to_nonnegative_int(usage.get("cache_read_tokens") or usage.get("cacheReadTokens") or usage.get("cached_read_tokens") or usage.get("cachedReadTokens"))
                cache_write_tokens = _to_nonnegative_int(usage.get("cache_write_tokens") or usage.get("cacheWriteTokens") or usage.get("cached_write_tokens") or usage.get("cachedWriteTokens"))
                raw_input_tokens = _to_nonnegative_int(usage.get("input_tokens") or usage.get("inputTokens"))
                input_tokens = max(0, raw_input_tokens - cache_read_tokens - cache_write_tokens)
                output_tokens = _to_nonnegative_int(usage.get("output_tokens") or usage.get("outputTokens"))
                total_tokens = _to_nonnegative_int(
                    usage.get("total_tokens") or usage.get("totalTokens"),
                    input_tokens + output_tokens + cache_read_tokens + cache_write_tokens,
                )
                openclaw = _ensure_openclaw_meta(result)
                openclaw["llmCalls"] = [{
                    "callId": "llm-final",
                    "model": result.get("model") or "",
                    "startedAt": now,
                    "finishedAt": now,
                    "stopReason": result.get("stopReason") or result.get("stop_reason") or "",
                    "usage": {
                        "input_tokens": input_tokens,
                        "output_tokens": output_tokens,
                        "total_tokens": total_tokens,
                        "cache_read_tokens": cache_read_tokens,
                        "cache_write_tokens": cache_write_tokens,
                    },
                }]
                self.llm_calls = list(openclaw["llmCalls"])
                changed = True

        snapshot = self._session_snapshot()
        system_prompt = snapshot.get("systemPrompt")
        if isinstance(system_prompt, str) and system_prompt:
            openclaw = _ensure_openclaw_meta(result)
            if openclaw.get("systemPrompt") != system_prompt:
                openclaw["systemPrompt"] = system_prompt
                changed = True
        if self.llm_calls:
            openclaw = _ensure_openclaw_meta(result)
            if openclaw.get("llmCalls") != self.llm_calls:
                openclaw["llmCalls"] = self.llm_calls
                changed = True

        if not self.last_llm_error:
            return changed
        stop_reason = result.get("stopReason") or result.get("stop_reason")
        if stop_reason == "error" or result.get("error"):
            return changed
        text = (
            _read_text(result.get("output"))
            or _read_text(result.get("content"))
            or _read_text(result.get("result"))
            or _read_text(result.get("text"))
        )
        if text:
            return changed
        result["stopReason"] = "error"
        result["error"] = self.last_llm_error
        return True


def _read_projected_model(cwd: str | None) -> str | None:
    """Read OpenClaw's projected runtime model from cwd/runtime-config.json."""
    if not cwd:
        return None
    try:
        config_path = Path(cwd) / "runtime-config.json"
        if not config_path.is_file():
            return None
        data = json.loads(config_path.read_text(encoding="utf-8"))
        model = data.get("model") if isinstance(data, dict) else None
        if isinstance(model, str) and model.strip():
            return model.strip()
    except Exception:
        logger.debug("Failed to read projected model from %s", cwd, exc_info=True)
    return None


def _to_positive_float(value: Any, default: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number <= 0:
        return default
    return number


def _read_tcp_port() -> int:
    raw = os.environ.get("ACP_TCP_PORT", "3100")
    try:
        port = int(raw)
    except (TypeError, ValueError):
        raise SystemExit(f"ACP_TCP_PORT must be an integer between 1 and 65535, got {raw!r}")
    if port < 1 or port > 65535:
        raise SystemExit(f"ACP_TCP_PORT must be an integer between 1 and 65535, got {raw!r}")
    return port


def _read_openclaw_mcp_meta(server: Any) -> dict[str, Any]:
    raw_meta = getattr(server, "field_meta", None)
    if raw_meta is None and hasattr(server, "model_dump"):
        try:
            raw_meta = server.model_dump(by_alias=True).get("_meta")
        except Exception:
            raw_meta = None
    if not isinstance(raw_meta, dict):
        return {}
    openclaw_meta = raw_meta.get("openclaw")
    return openclaw_meta if isinstance(openclaw_meta, dict) else {}


def _patch_hermes_mcp_runtime_options() -> None:
    """Make ACP-provided MCP runtime options survive into Hermes MCP calls.

    The upstream Hermes ACP adapter currently converts ACP HTTP MCP servers to
    only {url, headers}, dropping `_meta` and any runtime-specific timeouts.
    It also leaves MCP SDK call_tool read timeouts at the SDK default. OpenClaw
    passes its loopback bridge options under `_meta.openclaw` so ACP clients
    remain spec-compatible while this container adapter maps them into Hermes'
    native mcp_servers config shape.
    """
    from acp.schema import McpServerHttp, McpServerSse, McpServerStdio
    from acp_adapter.server import HermesACPAgent

    if getattr(HermesACPAgent, "_openclaw_mcp_options_patch", False):
        return

    def force_reconnect_session_scoped_servers(server_names: list[str]) -> None:
        if not server_names:
            return
        try:
            import tools.mcp_tool as mcp_tool
        except Exception:
            logger.debug("MCP tool module unavailable during reconnect refresh", exc_info=True)
            return

        mcp_tool._ensure_mcp_loop()

        async def shutdown_existing() -> None:
            for server_name in server_names:
                with mcp_tool._lock:
                    server = mcp_tool._servers.pop(server_name, None)
                    mcp_tool._server_error_counts.pop(server_name, None)
                    mcp_tool._server_breaker_opened_at.pop(server_name, None)
                if server is None:
                    continue
                try:
                    await server.shutdown()
                    logger.info("MCP server '%s': refreshed session-scoped OpenClaw bridge", server_name)
                except Exception:
                    logger.debug("Failed to shut down stale MCP server '%s'", server_name, exc_info=True)

        try:
            mcp_tool._run_on_mcp_loop(shutdown_existing(), timeout=15)
        except Exception:
            logger.debug("Failed to refresh session-scoped MCP servers", exc_info=True)

    async def register_session_mcp_servers(self: Any, state: Any, mcp_servers: list | None) -> None:
        if not mcp_servers:
            return

        try:
            from tools.mcp_tool import register_mcp_servers

            config_map: dict[str, dict] = {}
            session_scoped_server_names: list[str] = []
            for server in mcp_servers:
                name = server.name
                meta = _read_openclaw_mcp_meta(server)
                if meta:
                    session_scoped_server_names.append(name)
                timeout = _to_positive_float(meta.get("timeout"), 600.0)
                connect_timeout = _to_positive_float(
                    meta.get("connectTimeout", meta.get("connect_timeout")),
                    60.0,
                )
                if isinstance(server, McpServerStdio):
                    config = {
                        "command": server.command,
                        "args": list(server.args),
                        "env": {item.name: item.value for item in server.env},
                    }
                else:
                    config = {
                        "url": server.url,
                        "headers": {item.name: item.value for item in server.headers},
                    }
                    if isinstance(server, McpServerSse):
                        config["type"] = "sse"
                config["timeout"] = timeout
                config["connect_timeout"] = connect_timeout
                config_map[name] = config

            force_reconnect_session_scoped_servers(session_scoped_server_names)
            await asyncio.to_thread(register_mcp_servers, config_map)
        except Exception:
            logger.warning(
                "Session %s: failed to register ACP MCP servers",
                state.session_id,
                exc_info=True,
            )
            return

        try:
            from model_tools import get_tool_definitions
            from acp_adapter.session import _expand_acp_enabled_toolsets

            enabled_toolsets = _expand_acp_enabled_toolsets(
                getattr(state.agent, "enabled_toolsets", None) or ["hermes-acp"],
                mcp_server_names=[server.name for server in mcp_servers],
            )
            state.agent.enabled_toolsets = enabled_toolsets
            disabled_toolsets = getattr(state.agent, "disabled_toolsets", None)
            state.agent.tools = get_tool_definitions(
                enabled_toolsets=enabled_toolsets,
                disabled_toolsets=disabled_toolsets,
                quiet_mode=True,
            )
            state.agent.valid_tool_names = {
                tool["function"]["name"] for tool in state.agent.tools or []
            }
            invalidate = getattr(state.agent, "_invalidate_system_prompt", None)
            if callable(invalidate):
                invalidate()
            logger.info(
                "Session %s: refreshed tool surface after ACP MCP registration (%d tools)",
                state.session_id,
                len(state.agent.tools or []),
            )
        except Exception:
            logger.warning(
                "Session %s: failed to refresh tool surface after ACP MCP registration",
                state.session_id,
                exc_info=True,
            )

    HermesACPAgent._register_session_mcp_servers = register_session_mcp_servers
    HermesACPAgent._openclaw_mcp_options_patch = True

    try:
        import tools.mcp_tool as mcp_tool
    except Exception:
        logger.warning("Failed to import Hermes MCP tool module for timeout patch", exc_info=True)
        return

    if getattr(mcp_tool, "_openclaw_call_timeout_patch", False):
        return

    original_make_tool_handler = mcp_tool._make_tool_handler

    def make_tool_handler(server_name: str, tool_name: str, tool_timeout: float):
        handler = original_make_tool_handler(server_name, tool_name, tool_timeout)

        def wrapped(args: dict, **kwargs: Any) -> str:
            with mcp_tool._lock:
                server = mcp_tool._servers.get(server_name)
            if server and server.session:
                original_call_tool = server.session.call_tool

                async def call_tool_with_timeout(name: str, arguments: dict | None = None, **call_kwargs: Any):
                    call_kwargs.setdefault(
                        "read_timeout_seconds",
                        datetime.timedelta(seconds=float(tool_timeout)),
                    )
                    return await original_call_tool(name, arguments=arguments, **call_kwargs)

                server.session.call_tool = call_tool_with_timeout
                try:
                    return handler(args, **kwargs)
                finally:
                    server.session.call_tool = original_call_tool
            return handler(args, **kwargs)

        return wrapped

    mcp_tool._make_tool_handler = make_tool_handler
    mcp_tool._openclaw_call_timeout_patch = True
    logger.info("Installed OpenClaw MCP runtime options patch for Hermes ACP")


def _patch_hermes_acp_model_routing() -> None:
    """Teach Hermes' ACP adapter to create sessions with per-request models.

    The stock Hermes ACP adapter builds AIAgent from HERMES_HOME/config.yaml and
    ignores OpenClaw's projected runtime-config.json. OpenClaw now sends model in
    session/new|resume when supported, while this fallback also reads cwd so old
    clients still route dynamically.
    """
    from acp_adapter.session import SessionManager, SessionState

    if getattr(SessionManager, "_openclaw_model_patch", False):
        return

    _patch_hermes_mcp_runtime_options()

    original_create_session = SessionManager.create_session
    original_update_cwd = SessionManager.update_cwd

    def create_session(self: Any, cwd: str = ".", model: str | None = None) -> SessionState:
        resolved_model = (model.strip() if isinstance(model, str) and model.strip() else None) or _read_projected_model(cwd)
        if not resolved_model:
            return original_create_session(self, cwd)

        import threading
        import uuid

        session_id = str(uuid.uuid4())
        agent = self._make_agent(session_id=session_id, cwd=cwd, model=resolved_model)
        try:
            agent.model = resolved_model
        except Exception:
            logger.debug("Failed to force ACP session model", exc_info=True)
        state = SessionState(
            session_id=session_id,
            agent=agent,
            cwd=cwd,
            model=getattr(agent, "model", "") or resolved_model,
            cancel_event=threading.Event(),
        )
        with self._lock:
            self._sessions[session_id] = state
        self._persist(state)

        try:
            from tools.terminal_tool import register_task_env_overrides
            register_task_env_overrides(session_id, {"cwd": cwd})
        except Exception:
            logger.debug("Failed to register ACP task cwd override", exc_info=True)

        logger.info("Created ACP session %s (cwd=%s, model=%s)", session_id, cwd, state.model)
        return state

    def update_cwd(self: Any, session_id: str, cwd: str, model: str | None = None) -> SessionState | None:
        state = original_update_cwd(self, session_id, cwd)
        if state is None:
            return None
        resolved_model = (model.strip() if isinstance(model, str) and model.strip() else None) or _read_projected_model(cwd)
        if resolved_model and state.model != resolved_model:
            logger.info(
                "ACP session %s model changed from %s to %s; recreating agent",
                session_id,
                state.model,
                resolved_model,
            )
            state.agent = self._make_agent(session_id=session_id, cwd=cwd, model=resolved_model)
            try:
                state.agent.model = resolved_model
            except Exception:
                logger.debug("Failed to force resumed ACP session model", exc_info=True)
            state.model = getattr(state.agent, "model", "") or resolved_model
            state.history = []
            self._persist(state)
        return state

    SessionManager.create_session = create_session
    SessionManager.update_cwd = update_cwd
    SessionManager._openclaw_model_patch = True

    from acp_adapter.server import HermesACPAgent

    original_new_session = HermesACPAgent.new_session
    original_resume_session = HermesACPAgent.resume_session
    original_load_session = HermesACPAgent.load_session

    async def new_session(self: Any, cwd: str, mcp_servers: list | None = None, model: str | None = None, **kwargs: Any):
        state = self.session_manager.create_session(cwd=cwd, model=model)
        await self._register_session_mcp_servers(state, mcp_servers)
        logger.info("New session %s (cwd=%s, model=%s)", state.session_id, cwd, state.model)
        self._schedule_available_commands_update(state.session_id)
        from acp.schema import NewSessionResponse
        return NewSessionResponse(session_id=state.session_id)

    async def resume_session(
        self: Any,
        cwd: str,
        session_id: str,
        mcp_servers: list | None = None,
        model: str | None = None,
        **kwargs: Any,
    ):
        state = self.session_manager.update_cwd(session_id, cwd, model=model)
        if state is None:
            logger.warning("resume_session: session %s not found, creating new", session_id)
            state = self.session_manager.create_session(cwd=cwd, model=model)
        await self._register_session_mcp_servers(state, mcp_servers)
        logger.info("Resumed session %s (model=%s)", state.session_id, state.model)
        self._schedule_available_commands_update(state.session_id)
        from acp.schema import ResumeSessionResponse
        return ResumeSessionResponse()

    async def load_session(
        self: Any,
        cwd: str,
        session_id: str,
        mcp_servers: list | None = None,
        model: str | None = None,
        **kwargs: Any,
    ):
        state = self.session_manager.update_cwd(session_id, cwd, model=model)
        if state is None:
            logger.warning("load_session: session %s not found", session_id)
            return None
        await self._register_session_mcp_servers(state, mcp_servers)
        logger.info("Loaded session %s (model=%s)", session_id, state.model)
        self._schedule_available_commands_update(session_id)
        from acp.schema import LoadSessionResponse
        return LoadSessionResponse()

    HermesACPAgent.new_session = new_session
    HermesACPAgent.resume_session = resume_session
    HermesACPAgent.load_session = load_session
    HermesACPAgent._openclaw_original_new_session = original_new_session
    HermesACPAgent._openclaw_original_resume_session = original_resume_session
    HermesACPAgent._openclaw_original_load_session = original_load_session
    logger.info("Installed OpenClaw dynamic model routing patch for Hermes ACP")


def _patch_hermes_observability() -> None:
    """Install runtime observability adapters for Hermes ACP.

    The Hermes source is copied into the image at build time, so this repository
    cannot edit its modules directly. The TCP bridge owns the server->client
    transport, which is enough to normalize tool events and to expose Hermes'
    existing per-API-call logs as ACP `agent_llm_call` updates.
    """
    _install_observability_log_handler()
    _patch_hermes_tool_observability()


def _patch_hermes_tool_observability() -> None:
    import acp_adapter.events as events_module
    import acp_adapter.tools as tools_module

    if getattr(events_module, "_openclaw_tool_observability_patch", False):
        return

    original_build_tool_start = events_module.build_tool_start

    def build_tool_start_with_raw_input(
        tool_call_id: str,
        tool_name: str,
        arguments: dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        update = original_build_tool_start(tool_call_id, tool_name, arguments, **kwargs)
        try:
            update.raw_input = {
                "tool": tool_name,
                "arguments": _redact_observability_value(arguments),
            }
        except Exception:
            logger.debug("Failed to attach Hermes tool rawInput for %s", tool_name, exc_info=True)
        return update

    events_module.build_tool_start = build_tool_start_with_raw_input
    tools_module.build_tool_start = build_tool_start_with_raw_input
    events_module._openclaw_tool_observability_patch = True
    logger.info("Installed OpenClaw Hermes tool observability patch")


async def handle_client(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> None:
    """Handle one TCP client — create a fresh ACP agent and bridge I/O."""
    import acp
    from acp_adapter.server import HermesACPAgent

    _patch_hermes_acp_model_routing()
    _patch_hermes_observability()

    peer = writer.get_extra_info("peername")
    logger.info("Client connected: %s", peer)

    agent = HermesACPAgent()

    def read_session_snapshot(session_id: str | None) -> dict[str, Any]:
        if not session_id:
            return {}
        state = agent.session_manager.get_session(session_id)
        if state is None:
            return {}
        session_agent = state.agent
        return {
            "model": getattr(session_agent, "model", "") or getattr(state, "model", "") or "",
            "provider": getattr(session_agent, "provider", "") or "",
            "systemPrompt": _effective_system_prompt(session_agent),
        }

    original_write = writer.write
    hook_level = os.environ.get("OPENCLAW_OBS_HOOK_LEVEL", "debug")
    obs_bridge = _OpenClawObservabilityBridge(
        writer,
        original_write,
        asyncio.get_running_loop(),
        read_session_snapshot,
    )
    obs_bridge.attach()

    def _check_notification_fields(data: dict[str, Any]) -> None:
        session_update = data.get("sessionUpdate", "")
        if session_update == "agent_llm_call":
            meta = _read_openclaw_meta_payload(data)
            if not meta:
                logger.debug("agent_llm_call notification missing _meta.openclaw")
            elif not meta.get("usage"):
                logger.debug("agent_llm_call notification missing _meta.openclaw.usage")
            return

        if session_update in ("tool_call_end", "tool_call_update", "toolCallEnd"):
            status = data.get("status")
            if not status or status not in ("completed", "failed", "cancelled"):
                logger.debug("tool_call_end notification missing explicit status field")
            meta = _read_openclaw_meta_payload(data)
            if meta and not (meta.get("startedAt") or meta.get("durationMs")):
                logger.debug("tool_call_end notification missing _meta.openclaw timing fields")
            return

    def hooked_write(data: bytes) -> int:
        patched_data = obs_bridge.patch_outgoing_frame(data)
        if hook_level != "off":
            try:
                text = patched_data.decode("utf-8").strip()
                if text:
                    for line in text.split("\n"):
                        stripped = line.strip()
                        if not stripped:
                            continue
                        try:
                            parsed = json.loads(stripped)
                            if isinstance(parsed, dict) and "method" in parsed:
                                params = parsed.get("params", {})
                                if isinstance(params, dict):
                                    update = params.get("update")
                                    _check_notification_fields(update if isinstance(update, dict) else params)
                        except (json.JSONDecodeError, TypeError):
                            pass
            except Exception:
                pass
        return original_write(patched_data)

    writer.write = hooked_write  # type: ignore[method-assign]

    try:
        conn = acp.AgentSideConnection(
            agent,
            input_stream=writer,
            output_stream=reader,
            listening=False,
            use_unstable_protocol=True,
        )
        await conn.listen()
    except (ConnectionResetError, asyncio.IncompleteReadError, BrokenPipeError):
        logger.info("Client disconnected: %s", peer)
    except Exception:
        logger.exception("Error handling client %s", peer)
    finally:
        obs_bridge.detach()
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass
        logger.info("Client session ended: %s", peer)


async def run_server(host: str, port: int) -> None:
    server = await asyncio.start_server(handle_client, host, port, limit=ACP_TCP_STREAM_LIMIT)
    addrs = ", ".join(str(s.getsockname()) for s in server.sockets)
    logger.info("ACP TCP server listening on %s", addrs)

    loop = asyncio.get_running_loop()
    stop = loop.create_future()

    def request_stop() -> None:
        if not stop.done():
            stop.set_result(None)

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, request_stop)

    async with server:
        await stop
    logger.info("Server shutting down")


def main() -> None:
    _setup_logging()
    _load_env()

    host = os.environ.get("ACP_TCP_HOST", "0.0.0.0")
    port = _read_tcp_port()

    logger.info("Starting ACP TCP bridge on %s:%d", host, port)
    asyncio.run(run_server(host, port))


if __name__ == "__main__":
    main()
