import { Router } from 'express'
import { randomUUID } from 'crypto'
import multer from 'multer'
import { existsSync, mkdirSync, unlinkSync } from 'fs'
import { join, dirname, extname, basename } from 'path'
import { fileURLToPath } from 'url'
import { validateToken, getUserById } from './user-manager.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const UPLOAD_DIR = join(__dirname, '../uploads/images')

if (!existsSync(UPLOAD_DIR)) {
  mkdirSync(UPLOAD_DIR, { recursive: true })
}

const imageUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = extname(file.originalname) || '.png'
      cb(null, `${Date.now()}-${randomUUID().slice(0, 8)}${ext}`)
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp']
    const ext = extname(file.originalname).toLowerCase()
    if (allowed.includes(ext)) cb(null, true)
    else cb(new Error('仅支持图片文件'))
  },
})

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies?.session
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  const result = validateToken(token)
  if (!result) return res.status(401).json({ error: 'Unauthorized' })
  req.currentUser = result.user
  req.authToken = result.token
  next()
}

/**
 * @param {import('better-sqlite3').Database} db
 */
export function createIssuesRouter(db) {
  const router = Router()

  // Upload image
  router.post('/upload', authMiddleware, imageUpload.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, error: { message: '未选择文件' } })
    const filename = req.file.filename
    res.json({ ok: true, filename, url: `/api/issues/images/${filename}` })
  })

  // Serve uploaded images (supports both header and query token)
  router.get('/images/:filename', (req, res) => {
    // Try header first, then query param
    let token = req.headers.authorization?.replace('Bearer ', '') || req.cookies?.session
    if (!token && req.query.token) token = req.query.token
    if (!token) return res.status(401).json({ error: 'Unauthorized' })
    const result = validateToken(token)
    if (!result) return res.status(401).json({ error: 'Unauthorized' })

    const filename = basename(req.params.filename)
    const filePath = join(UPLOAD_DIR, filename)
    if (!existsSync(filePath)) return res.status(404).json({ ok: false, error: { message: '文件不存在' } })

    const ext = extname(filename).toLowerCase()
    const contentTypeMap = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.webp': 'image/webp',
      '.bmp': 'image/bmp',
    }
    res.setHeader('Content-Type', contentTypeMap[ext] || 'application/octet-stream')
    res.sendFile(filePath)
  })

  // Create issue
  router.post('/', authMiddleware, (req, res) => {
    const { description, images } = req.body
    if (!description || !description.trim()) {
      return res.status(400).json({ ok: false, error: { message: '问题描述不能为空' } })
    }
    const id = randomUUID()
    const now = Date.now()
    db.prepare(`
      INSERT INTO issues (id, user_id, description, images, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'open', ?, ?)
    `).run(id, req.currentUser.id, description.trim(), JSON.stringify(images || []), now, now)

    const row = db.prepare('SELECT * FROM issues WHERE id = ?').get(id)
    res.json({ ok: true, issue: formatIssue(row) })
  })

  // List issues
  router.get('/', authMiddleware, (req, res) => {
    const { scope, page = '1', pageSize = '20' } = req.query
    const p = Math.max(1, parseInt(page) || 1)
    const ps = Math.max(1, Math.min(100, parseInt(pageSize) || 20))
    const offset = (p - 1) * ps

    let countRow, rows
    if (scope === 'mine') {
      countRow = db.prepare('SELECT COUNT(*) as total FROM issues WHERE user_id = ?').get(req.currentUser.id)
      rows = db.prepare('SELECT * FROM issues WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?').all(req.currentUser.id, ps, offset)
    } else {
      countRow = db.prepare('SELECT COUNT(*) as total FROM issues').get()
      rows = db.prepare('SELECT * FROM issues ORDER BY created_at DESC LIMIT ? OFFSET ?').all(ps, offset)
    }
    res.json({ ok: true, issues: rows.map(formatIssue), total: countRow.total, page: p, pageSize: ps })
  })

  // Get single issue
  router.get('/:id', authMiddleware, (req, res) => {
    const row = db.prepare('SELECT * FROM issues WHERE id = ?').get(req.params.id)
    if (!row) return res.status(404).json({ ok: false, error: { message: '反馈不存在' } })
    res.json({ ok: true, issue: formatIssue(row) })
  })

  // Update issue (own only)
  router.put('/:id', authMiddleware, (req, res) => {
    const row = db.prepare('SELECT * FROM issues WHERE id = ?').get(req.params.id)
    if (!row) return res.status(404).json({ ok: false, error: { message: '反馈不存在' } })
    if (row.user_id !== req.currentUser.id) {
      return res.status(403).json({ ok: false, error: { message: '只能修改自己的反馈' } })
    }
    const { description, images } = req.body
    const now = Date.now()
    const updates = []
    const values = []
    if (description !== undefined) { updates.push('description = ?'); values.push(description.trim()) }
    if (images !== undefined) { updates.push('images = ?'); values.push(JSON.stringify(images)) }
    if (updates.length === 0) return res.json({ ok: true, issue: formatIssue(row) })
    updates.push('updated_at = ?')
    values.push(now)
    values.push(req.params.id)
    db.prepare(`UPDATE issues SET ${updates.join(', ')} WHERE id = ?`).run(...values)
    const updated = db.prepare('SELECT * FROM issues WHERE id = ?').get(req.params.id)
    res.json({ ok: true, issue: formatIssue(updated) })
  })

  // Delete issue (own only)
  router.delete('/:id', authMiddleware, (req, res) => {
    const row = db.prepare('SELECT * FROM issues WHERE id = ?').get(req.params.id)
    if (!row) return res.status(404).json({ ok: false, error: { message: '反馈不存在' } })
    if (row.user_id !== req.currentUser.id) {
      return res.status(403).json({ ok: false, error: { message: '只能删除自己的反馈' } })
    }
    // Remove associated images
    const images = JSON.parse(row.images || '[]')
    for (const filename of images) {
      const filePath = join(UPLOAD_DIR, filename)
      if (existsSync(filePath)) {
        try { unlinkSync(filePath) } catch (e) { console.warn('[Issues] Failed to delete image:', filePath, e.message) }
      }
    }
    db.prepare('DELETE FROM issues WHERE id = ?').run(req.params.id)
    res.json({ ok: true })
  })

  return router
}

function formatIssue(row) {
  const user = getUserById(row.user_id)
  return {
    id: row.id,
    userId: row.user_id,
    username: user?.display_name || user?.username || '未知用户',
    avatar: user?.avatar || null,
    description: row.description,
    images: JSON.parse(row.images || '[]'),
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}
