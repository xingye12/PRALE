import pg from 'pg'
import { extractOccurredAt } from './services/message-normalizer.js'

const { Pool } = pg

let pool = null
let _initPromise = null

export async function initMessageStore() {
  if (pool) return pool
  if (_initPromise) return _initPromise

  _initPromise = (async () => {
    const connectionString = process.env.DATABASE_URL
    if (!connectionString) {
      console.warn('[MessageStore] DATABASE_URL not set, message store disabled')
      return null
    }

    pool = new Pool({
      connectionString,
      max: 20,
      min: 2,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    })

    pool.on('error', (err) => {
      console.error('[MessageStore] Unexpected pool error:', err.message)
    })

    await pool.query(`
      CREATE TABLE IF NOT EXISTS session_messages (
        id            BIGSERIAL PRIMARY KEY,
        session_key   TEXT NOT NULL,
        seq           INTEGER NOT NULL,
        msg_id        TEXT,
        role          TEXT NOT NULL,
        content       TEXT NOT NULL DEFAULT '',
        raw_content   JSONB,
        model         TEXT,
        status        TEXT NOT NULL DEFAULT 'confirmed',
        msg_timestamp TIMESTAMPTZ,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE(session_key, seq)
      );

      CREATE INDEX IF NOT EXISTS idx_msg_session_seq ON session_messages (session_key, seq DESC);
      CREATE INDEX IF NOT EXISTS idx_msg_session_status ON session_messages (session_key, status);
      CREATE INDEX IF NOT EXISTS idx_msg_session_timestamp ON session_messages (session_key, msg_timestamp DESC);

      -- Partial unique index: one msg_id per session (NULL msg_id excluded)
      CREATE UNIQUE INDEX IF NOT EXISTS idx_msg_session_msg_id
        ON session_messages (session_key, msg_id) WHERE msg_id IS NOT NULL;
    `)

    console.log('[MessageStore] Initialized, table session_messages ready')
    return pool
  })()

  return _initPromise
}

export function getPool() {
  return pool
}

export function isReady() {
  return pool !== null
}

/**
 * Extract timestamp from message object defensively.
 */
function extractTimestamp(msg) {
  return extractOccurredAt(msg)
}

/**
 * Safe JSON stringify with defensive handling for circular refs, BigInt, Errors.
 */
function safeStringify(obj) {
  if (obj == null) return null
  try {
    return JSON.stringify(obj, (_key, value) => {
      if (typeof value === 'bigint') return value.toString()
      if (value instanceof Error) return { message: value.message, stack: value.stack }
      return value
    })
  } catch (err) {
    console.error('[MessageStore] JSON stringify failed:', err.message)
    return JSON.stringify({
      error: 'Serialization failed',
      type: typeof obj,
      keys: typeof obj === 'object' ? Object.keys(obj) : undefined,
    })
  }
}

async function getNextSeqInTransaction(client, sessionKey) {
  const { rows } = await client.query(
    'SELECT COALESCE(MAX(seq), 0) + 1 AS next_seq FROM session_messages WHERE session_key = $1',
    [sessionKey]
  )
  return rows[0].next_seq
}

// ═══════════════════════════════════════════════════════════════
//  NEW API: saveMessage + mergeSessionMessages
//  replaceSession is deprecated — use mergeSessionMessages instead.
// ═══════════════════════════════════════════════════════════════

/**
 * Save a single message. Idempotent.
 * Uses msg_id for dedup when available; falls back to (session_key, seq).
 * Throws on failure — caller must handle.
 */
export async function saveMessage({
  sessionKey,
  seq,
  msgId,
  role,
  content,
  rawContent,
  model,
  status = 'confirmed',
  msgTimestamp,
}) {
  if (!pool) throw new Error('MessageStore not initialized')
  if (!sessionKey) throw new Error('sessionKey required')

  const rawJson = safeStringify(rawContent)
  const ts = msgTimestamp || extractTimestamp(rawContent) || null
  const client = await pool.connect()

  try {
    await client.query('BEGIN')
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])

    let resolvedSeq
    if (msgId) {
      // ── msgId dedup path ──
      const { rows: existing } = await client.query(
        'SELECT seq FROM session_messages WHERE session_key = $1 AND msg_id = $2 LIMIT 1',
        [sessionKey, msgId]
      )

      if (existing[0]) {
        resolvedSeq = existing[0].seq
        console.log(`[MessageStore] saveMessage UPDATE ${sessionKey} seq=${resolvedSeq} msgId=${msgId} role=${role} status=${status}`)
      } else {
        resolvedSeq = await getNextSeqInTransaction(client, sessionKey)
        console.log(`[MessageStore] saveMessage INSERT ${sessionKey} seq=${resolvedSeq} msgId=${msgId} role=${role} status=${status}`)
      }

      await client.query(
        `INSERT INTO session_messages
           (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (session_key, msg_id) WHERE msg_id IS NOT NULL DO UPDATE SET
           content = EXCLUDED.content,
           raw_content = EXCLUDED.raw_content,
           model = EXCLUDED.model,
           status = EXCLUDED.status,
           msg_timestamp = EXCLUDED.msg_timestamp`,
        [sessionKey, resolvedSeq, msgId, role || 'unknown', content || '', rawJson, model || null, status, ts]
      )
    } else {
      // ── (session_key, seq) dedup path ──
      if (seq != null) {
        resolvedSeq = seq
        console.log(`[MessageStore] saveMessage CALLER-SEQ ${sessionKey} seq=${resolvedSeq} role=${role} status=${status}`)
      } else {
        resolvedSeq = await getNextSeqInTransaction(client, sessionKey)
        console.log(`[MessageStore] saveMessage AUTO-SEQ ${sessionKey} seq=${resolvedSeq} role=${role} status=${status}`)
      }

      await client.query(
        `INSERT INTO session_messages
           (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (session_key, seq) DO UPDATE SET
           content = EXCLUDED.content,
           raw_content = EXCLUDED.raw_content,
           model = EXCLUDED.model,
           status = EXCLUDED.status,
           msg_timestamp = EXCLUDED.msg_timestamp`,
        [sessionKey, resolvedSeq, null, role || 'unknown', content || '', rawJson, model || null, status, ts]
      )
    }

    await client.query('COMMIT')
    return resolvedSeq
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {})
    console.error(`[MessageStore] saveMessage FAILED ${sessionKey} role=${role} msgId=${msgId || 'N/A'} err=${err.message}`)
    throw err
  } finally {
    client.release()
  }
}


/**
 * Full replace: DELETE all existing messages + bulk INSERT fresh data in one transaction.
 * Uses UNNEST for efficient batch insert (no loop).
 * ⚠️ DESTRUCTIVE — no normal flow calls this anymore (all callers switched to mergeSessionMessages).
 * Retained as an escape hatch for manual/admin full-reset scenarios only.
 * Throws on failure — transaction is rolled back automatically.
 * @deprecated Use mergeSessionMessages instead.
 */
export async function replaceSession(sessionKey, messages) {
  if (!pool) throw new Error('MessageStore not initialized')
  if (!messages?.length) return 0

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])

    // 1. Clean slate — log what we're replacing
    const { rows: before } = await client.query(
      "SELECT COUNT(*)::int AS cnt FROM session_messages WHERE session_key = $1 AND status = 'confirmed'",
      [sessionKey]
    )
    const oldCount = before[0]?.cnt ?? 0

    await client.query('DELETE FROM session_messages WHERE session_key = $1', [sessionKey])

    // 2. Prepare data
    const values = messages.map((m, i) => ({
      seq: m.seq != null ? m.seq : i + 1,
      msgId: m.msgId || m.msg_id || null,
      role: m.role || 'unknown',
      content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content || ''),
      rawJson: safeStringify(m.rawContent || m.raw_content),
      model: m.model || null,
      status: m.status || 'confirmed',
      ts: extractTimestamp(m) || null,
    }))

    // 3. UNNEST bulk insert — single SQL, no loop
    await client.query(
      `INSERT INTO session_messages
         (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
       SELECT * FROM UNNEST(
         $1::text[],
         $2::int[],
         $3::text[],
         $4::text[],
         $5::text[],
         $6::jsonb[],
         $7::text[],
         $8::text[],
         $9::timestamptz[]
       ) AS t(session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)`,
      [
        Array(values.length).fill(sessionKey),
        values.map(v => v.seq),
        values.map(v => v.msgId),
        values.map(v => v.role),
        values.map(v => v.content),
        values.map(v => v.rawJson),
        values.map(v => v.model),
        values.map(v => v.status),
        values.map(v => v.ts),
      ]
    )

    await client.query('COMMIT')
    console.log(`[MessageStore] replaceSession ${sessionKey}: ${oldCount} → ${values.length} messages replaced`)
    return values.length
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {})
    console.error(`[MessageStore] replaceSession FAILED ${sessionKey} err=${err.message}`)
    throw err
  } finally {
    client.release()
  }
}

// ═══════════════════════════════════════════════════════════════
//  NON-DESTRUCTIVE MERGE — append/update without deleting local rows.
//  Use for Gateway history imports where Gateway may return partial data.
// ═══════════════════════════════════════════════════════════════

function normalizeImportMsgId(message) {
  return message.msgId || message.msg_id || null
}

function normalizeImportContent(message) {
  return typeof message.content === 'string'
    ? message.content
    : JSON.stringify(message.content || '')
}

function normalizeImportRaw(message) {
  return message.rawContent || message.raw_content || message
}

/**
 * Non-destructive merge: upsert messages without deleting existing rows.
 * - Matches by msg_id (preferred) or role+content fingerprint.
 * - Allocates new seq from PG MAX(seq)+1, never trusts imported seq.
 * - Returns { inserted, updated, skipped }.
 */
export async function mergeSessionMessages(sessionKey, messages) {
  if (!pool) throw new Error('MessageStore not initialized')
  if (!sessionKey) throw new Error('sessionKey required')
  if (!messages?.length) return { inserted: 0, updated: 0, skipped: 0 }

  console.log(`[MessageStore] mergeSessionMessages START ${sessionKey}: incoming=${messages.length}`)
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [sessionKey])

    let inserted = 0
    let updated = 0
    let skipped = 0

    const { rows: seqRows } = await client.query(
      'SELECT COALESCE(MAX(seq), 0) AS max_seq FROM session_messages WHERE session_key = $1',
      [sessionKey]
    )
    let nextSeq = Number(seqRows[0]?.max_seq || 0) + 1

    for (const message of messages) {
      const msgId = normalizeImportMsgId(message)
      const role = message.role || 'unknown'
      const content = normalizeImportContent(message)
      const rawContent = normalizeImportRaw(message)
      const rawJson = safeStringify(rawContent)
      const model = message.model || null
      const status = message.status || 'confirmed'
      const ts = extractTimestamp(message) || extractTimestamp(rawContent) || null

      if (msgId) {
        const { rows: existing } = await client.query(
          'SELECT seq FROM session_messages WHERE session_key = $1 AND msg_id = $2 LIMIT 1',
          [sessionKey, msgId]
        )
        const resolvedSeq = existing[0]?.seq || nextSeq++
        await client.query(
          `INSERT INTO session_messages
             (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
           ON CONFLICT (session_key, msg_id) WHERE msg_id IS NOT NULL DO UPDATE SET
             content = EXCLUDED.content,
             raw_content = EXCLUDED.raw_content,
             model = EXCLUDED.model,
             status = EXCLUDED.status,
             msg_timestamp = EXCLUDED.msg_timestamp`,
          [sessionKey, resolvedSeq, msgId, role, content, rawJson, model, status, ts]
        )
        if (existing[0]) updated++
        else inserted++
        continue
      }

      // No msgId — if timestamp is available, use role+content+ts fingerprint;
      // otherwise append directly (content-only dedup would drop legitimate repeated messages)
      if (!ts) {
        await client.query(
          `INSERT INTO session_messages
             (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
           VALUES ($1, $2, NULL, $3, $4, $5, $6, $7, $8)`,
          [sessionKey, nextSeq++, role, content, rawJson, model, status, ts]
        )
        inserted++
        continue
      }

      const { rows: existing } = await client.query(
        `SELECT seq FROM session_messages
         WHERE session_key = $1 AND role = $2 AND content = $3 AND msg_timestamp = $4
         LIMIT 1`,
        [sessionKey, role, content, ts]
      )
      if (existing[0]) {
        skipped++
        continue
      }

      await client.query(
        `INSERT INTO session_messages
           (session_key, seq, msg_id, role, content, raw_content, model, status, msg_timestamp)
         VALUES ($1, $2, NULL, $3, $4, $5, $6, $7, $8)`,
        [sessionKey, nextSeq++, role, content, rawJson, model, status, ts]
      )
      inserted++
    }

    await client.query('COMMIT')
    console.log(`[MessageStore] mergeSessionMessages ${sessionKey}: inserted=${inserted} updated=${updated} skipped=${skipped}`)
    return { inserted, updated, skipped }
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {})
    console.error(`[MessageStore] mergeSessionMessages FAILED ${sessionKey} err=${err.message}`)
    throw err
  } finally {
    client.release()
  }
}

// ═══════════════════════════════════════════════════════════════
//  REMOVED API — the following functions were deleted in Phase 3.
//  Use saveMessage() and replaceSession() instead.
// ═══════════════════════════════════════════════════════════════

/**
 * Update message status (e.g., pending -> confirmed / orphaned).
 */
export async function updateMessageStatus(sessionKey, seq, status) {
  if (!pool) return false
  try {
    await pool.query(
      'UPDATE session_messages SET status = $1 WHERE session_key = $2 AND seq = $3',
      [status, sessionKey, seq]
    )
    return true
  } catch (err) {
    console.error('[MessageStore] updateMessageStatus error:', err.message)
    return false
  }
}

/**
 * Read confirmed messages for a session, ordered by seq DESC (newest first).
 * Supports cursor-based pagination using seq.
 */
export async function readMessages(sessionKey, { limit = 50, beforeSeq = null } = {}) {
  if (!pool) return []
  try {
    let query, params
    if (beforeSeq != null) {
      query = `SELECT * FROM session_messages
               WHERE session_key = $1 AND status = 'confirmed' AND seq < $2
               ORDER BY seq DESC LIMIT $3`
      params = [sessionKey, parseInt(beforeSeq), limit]
    } else {
      query = `SELECT * FROM session_messages
               WHERE session_key = $1 AND status = 'confirmed'
               ORDER BY seq DESC LIMIT $2`
      params = [sessionKey, limit]
    }
    const { rows } = await pool.query(query, params)
    return rows
  } catch (err) {
    console.error('[MessageStore] readMessages error:', err.message)
    return []
  }
}

export async function readEarliestEffectiveUserMessage(sessionKey) {
  if (!pool || typeof sessionKey !== 'string' || !sessionKey.trim()) return null

  try {
    const { rows } = await pool.query(
      `SELECT content, msg_timestamp, seq
       FROM session_messages
         WHERE session_key = $1
           AND status = 'confirmed'
           AND role = 'user'
           AND NULLIF(BTRIM(content), '') IS NOT NULL
           AND LOWER(BTRIM(content)) NOT IN (
             'openclaw web backend', 'main', 'new chat', 'new conversation', 'new session',
             '新对话', '新会话', '新對話', '新會話'
           )
       ORDER BY COALESCE(msg_timestamp, created_at) ASC, seq ASC
       LIMIT 1`,
      [sessionKey]
    )
    return rows[0] || null
  } catch (err) {
    console.error('[MessageStore] readEarliestEffectiveUserMessage error:', err.message)
    return null
  }
}

export async function readEarliestEffectiveUserMessages(sessionKeys) {
  if (!pool || !Array.isArray(sessionKeys) || sessionKeys.length === 0) return []

  const keys = [...new Set(sessionKeys.filter((key) => typeof key === 'string' && key.trim()))]
  if (keys.length === 0) return []

  try {
    const { rows } = await pool.query(
      `SELECT DISTINCT ON (session_key)
              session_key, content, msg_timestamp, seq
       FROM session_messages
         WHERE session_key = ANY($1)
           AND status = 'confirmed'
           AND role = 'user'
           AND NULLIF(BTRIM(content), '') IS NOT NULL
           AND LOWER(BTRIM(content)) NOT IN (
             'openclaw web backend', 'main', 'new chat', 'new conversation', 'new session',
             '新对话', '新会话', '新對話', '新會話'
           )
       ORDER BY session_key, COALESCE(msg_timestamp, created_at) ASC, seq ASC`,
      [keys]
    )
    return rows
  } catch (err) {
    console.error('[MessageStore] readEarliestEffectiveUserMessages error:', err.message)
    return []
  }
}

export async function readSessionMaxMessageTimestamps(sessionKeys) {
  if (!pool || !Array.isArray(sessionKeys) || sessionKeys.length === 0) return []

  const keys = [...new Set(sessionKeys.filter((key) => typeof key === 'string' && key.trim()))]
  if (keys.length === 0) return []

  try {
    const { rows } = await pool.query(
      `SELECT session_key, MAX(msg_timestamp) AS last_message_at
       FROM session_messages
       WHERE session_key = ANY($1)
         AND status = 'confirmed'
         AND msg_timestamp IS NOT NULL
       GROUP BY session_key`,
      [keys]
    )
    return rows
  } catch (err) {
    console.error('[MessageStore] readSessionMaxMessageTimestamps error:', err.message)
    return []
  }
}

/**
 * Count confirmed messages for a session.
 */
export async function countConfirmedMessages(sessionKey) {
  if (!pool) return 0
  try {
    const { rows } = await pool.query(
      "SELECT COUNT(*)::int AS cnt FROM session_messages WHERE session_key = $1 AND status = 'confirmed'",
      [sessionKey]
    )
    return rows[0].cnt
  } catch (err) {
    console.error('[MessageStore] countConfirmedMessages error:', err.message)
    return 0
  }
}

/**
 * Delete all messages for a session (reset / delete lifecycle).
 */
export async function deleteSessionMessages(sessionKey) {
  if (!pool) return false
  try {
    await pool.query('DELETE FROM session_messages WHERE session_key = $1', [sessionKey])
    console.log('[MessageStore] Deleted messages for session:', sessionKey)
    return true
  } catch (err) {
    console.error('[MessageStore] deleteSessionMessages error:', err.message)
    return false
  }
}

/**
 * 去重清理：删除同一 session 内同一 msg_id 多余记录，
 * 以及无 msg_id 但 role+content+timestamp 三元组完全相同的重复行。
 * 保留最早的一条（最小的 id），删除其余。
 * 返回被删除的行数。
 */
export async function dedupSessionMessages(sessionKey) {
  if (!pool) return 0
  try {
    // 1) 同一 msg_id 出现多行 → 保留最早一条
    const { rowCount: r1 } = await pool.query(
      `DELETE FROM session_messages
       WHERE session_key = $1
         AND msg_id IS NOT NULL
         AND id NOT IN (
           SELECT MIN(id)
           FROM session_messages
           WHERE session_key = $1 AND msg_id IS NOT NULL
           GROUP BY msg_id
         )`,
      [sessionKey]
    )
    // 2) 无 msg_id 但 role+content 完全相同 → 保留最早一条
    const { rowCount: r2 } = await pool.query(
      `DELETE FROM session_messages
       WHERE session_key = $1
         AND msg_id IS NULL
         AND id NOT IN (
           SELECT MIN(id)
           FROM session_messages
           WHERE session_key = $1 AND msg_id IS NULL
           GROUP BY role, content
         )`,
      [sessionKey]
    )
    const total = (r1 || 0) + (r2 || 0)
    if (total > 0) {
      console.log(`[MessageStore] dedupSessionMessages: removed ${total} duplicates from ${sessionKey} (msg_id=${r1 || 0}, fingerprint=${r2 || 0})`)
    }
    return total
  } catch (err) {
    console.error('[MessageStore] dedupSessionMessages error:', err.message)
    return 0
  }
}
