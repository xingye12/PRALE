// server/model-concurrency-monitor.js
// 模型并发监控 — 滑动时间窗口计数器
// 职责: 记录请求时间戳、检测拥堵、管理告警冷却、缓存 session→model 映射

const config = {
  windowMs: 1000,
  threshold: 4,
  alertCooldownMs: 30_000,
  _initialized: false,
}

/**
 * 从 process.env 初始化配置（应在 server 加载 .env 后调用）。
 * 只执行一次，后续调用为 no-op。
 */
export function initMonitorConfig() {
  if (config._initialized) return
  if (process.env.MODEL_CONCURRENCY_WINDOW_MS) {
    config.windowMs = Number(process.env.MODEL_CONCURRENCY_WINDOW_MS) || 1000
  }
  if (process.env.MODEL_CONCURRENCY_THRESHOLD) {
    config.threshold = Number(process.env.MODEL_CONCURRENCY_THRESHOLD) || 4
  }
  if (process.env.MODEL_CONCURRENCY_ALERT_COOLDOWN_MS) {
    config.alertCooldownMs = Number(process.env.MODEL_CONCURRENCY_ALERT_COOLDOWN_MS) || 30_000
  }
  config._initialized = true
}

// 滑动窗口: modelId → 请求时间戳数组
const windows = new Map()

// 告警冷却: modelId → 上次告警时间戳
const alertCooldowns = new Map()

// Session→Model 缓存: sessionKey → { model, ts }
const sessionModelCache = new Map()
const SESSION_MODEL_CACHE_MAX = 1000
const SESSION_MODEL_CACHE_TTL = 30 * 60 * 1000 // 30 分钟

// ---------------------------------------------------------------------------
// Session Model Cache
// ---------------------------------------------------------------------------

export function cacheSessionModel(sessionKey, model) {
  if (!sessionKey || !model || typeof model !== 'string') return
  sessionModelCache.set(sessionKey, { model, ts: Date.now() })
  // FIFO 淘汰
  if (sessionModelCache.size > SESSION_MODEL_CACHE_MAX) {
    const firstKey = sessionModelCache.keys().next().value
    if (firstKey) sessionModelCache.delete(firstKey)
  }
}

export function getCachedSessionModel(sessionKey) {
  if (!sessionKey) return null
  const entry = sessionModelCache.get(sessionKey)
  if (!entry) return null
  if (Date.now() - entry.ts > SESSION_MODEL_CACHE_TTL) {
    sessionModelCache.delete(sessionKey)
    return null
  }
  return entry.model
}

// ---------------------------------------------------------------------------
// 核心监控
// ---------------------------------------------------------------------------

export function recordRequest(modelId) {
  if (!config._initialized) initMonitorConfig()
  if (!modelId || typeof modelId !== 'string') {
    return { isCongested: false, shouldAlert: false, count: 0, model: '', windowMs: config.windowMs }
  }

  const now = Date.now()

  // 推入时间戳
  let timestamps = windows.get(modelId)
  if (!timestamps) {
    timestamps = []
    windows.set(modelId, timestamps)
  }
  timestamps.push(now)

  // 裁剪过期条目
  const cutoff = now - config.windowMs
  let writeIdx = 0
  for (let i = 0; i < timestamps.length; i++) {
    if (timestamps[i] >= cutoff) {
      timestamps[writeIdx++] = timestamps[i]
    }
  }
  timestamps.length = writeIdx

  // GC: 数组为空时删除 key
  if (timestamps.length === 0) {
    windows.delete(modelId)
    alertCooldowns.delete(modelId)
    return { isCongested: false, shouldAlert: false, count: 0, model: modelId, windowMs: config.windowMs }
  }

  const count = timestamps.length
  const isCongested = count >= config.threshold

  // 告警冷却检查
  let shouldAlert = false
  if (isCongested) {
    const lastAlert = alertCooldowns.get(modelId) || 0
    if (now - lastAlert >= config.alertCooldownMs) {
      shouldAlert = true
      alertCooldowns.set(modelId, now)
    }
  }

  return { isCongested, shouldAlert, count, model: modelId, windowMs: config.windowMs }
}

// ---------------------------------------------------------------------------
// 状态查询
// ---------------------------------------------------------------------------

export function getStatus() {
  const now = Date.now()
  const cutoff = now - config.windowMs
  const result = {}
  const expired = []

  for (const [modelId, timestamps] of windows) {
    // 裁剪过期条目
    let writeIdx = 0
    for (let i = 0; i < timestamps.length; i++) {
      if (timestamps[i] >= cutoff) timestamps[writeIdx++] = timestamps[i]
    }
    timestamps.length = writeIdx

    if (timestamps.length > 0) {
      result[modelId] = {
        windowCount: timestamps.length,
        isCongested: timestamps.length >= config.threshold,
      }
    } else {
      expired.push(modelId)
    }
  }

  // 清理空窗口和对应冷却记录
  for (const id of expired) {
    windows.delete(id)
    alertCooldowns.delete(id)
  }

  return result
}

export function updateConfig(partial) {
  config._initialized = true
  if (partial.windowMs !== undefined) config.windowMs = Number(partial.windowMs) || 1000
  if (partial.threshold !== undefined) config.threshold = Number(partial.threshold) || 4
  if (partial.alertCooldownMs !== undefined) config.alertCooldownMs = Number(partial.alertCooldownMs) || 30_000
}
