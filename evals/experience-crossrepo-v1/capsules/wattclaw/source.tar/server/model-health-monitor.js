import db from './database.js'
import { broadcastGlobalSSE } from './core/sse.js'
import { syncAllTenantOpenClawConfigsFromDB } from './openclaw-config-sync.js'

const DEFAULT_INTERVAL_MS = 30 * 60 * 1000
const DEFAULT_TIMEOUT_MS = 30 * 1000
const DEFAULT_RETRIES = 2
const QUIET_HOURS_START = 20
const QUIET_HOURS_END = 8
const UNAVAILABLE_REMARK_PREFIX = '\u6682\u4e0d\u53ef\u7528'
const IMAGE_GENERATION_MODEL_PATTERNS = [
  /^dall-e-/i,
  /^flux(?:[-_]|$)/i,
  /^gpt-image(?:s)?(?:[-_]|$)/i,
  /^imagen(?:[-_]|$)/i,
  /^midjourney(?:[-_]|$)/i,
  /^seedream(?:[-_]|$)/i,
  /^stable-diffusion(?:[-_]|$)/i,
]

let timer = null
let running = false

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function asString(value, fallback = '') {
  return typeof value === 'string' ? value : fallback
}

function positiveInt(value, fallback) {
  const parsed = Number(value)
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback
}

function isModelHealthQuietHours(now = new Date()) {
  const hour = now.getHours()
  return hour >= QUIET_HOURS_START || hour < QUIET_HOURS_END
}

function parseJsonObject(value) {
  if (!value) return {}
  if (typeof value === 'object' && !Array.isArray(value)) return value
  if (typeof value !== 'string') return {}
  try {
    return asRecord(JSON.parse(value))
  } catch {
    return {}
  }
}

function readProviderConfig(row) {
  return parseJsonObject(row.config)
}

function readProviderApi(row) {
  const config = readProviderConfig(row)
  return asString(config.api || config.protocol || config.format).trim().toLowerCase()
}

function readProviderDescription(row) {
  const parsed = parseJsonObject(row.description)
  return {
    ...parsed,
    modelMeta: asRecord(parsed.modelMeta),
  }
}

function writeProviderDescription(rowId, description) {
  db.prepare('UPDATE user_model_providers SET description = ?, updated_at = ? WHERE id = ?')
    .run(JSON.stringify(description), Date.now(), rowId)
}

function readSecret(config) {
  return asString(
    config.apiKey ||
    config.api_key ||
    config.key ||
    config.token ||
    config.accessToken ||
    config.access_token
  )
}

function readBaseUrl(config) {
  return asString(
    config.baseUrl ||
    config.baseURL ||
    config.base_url ||
    config.url ||
    config.endpoint
  ).replace(/\/+$/, '')
}

function normalizeEndpointUrl(baseUrl, suffix) {
  if (!baseUrl) return ''
  const cleanBaseUrl = baseUrl.replace(/\/+$/, '')
  if (cleanBaseUrl.toLowerCase().endsWith(suffix.toLowerCase())) return cleanBaseUrl
  return `${cleanBaseUrl}${suffix}`
}

function normalizeChatCompletionsUrl(baseUrl) {
  return normalizeEndpointUrl(baseUrl, '/chat/completions')
}

function normalizeResponsesUrl(baseUrl) {
  return normalizeEndpointUrl(baseUrl, '/responses')
}

function normalizeAnthropicMessagesUrl(baseUrl) {
  const cleanBaseUrl = baseUrl.replace(/\/+$/, '')
  if (/\/v1\/messages\/?$/i.test(cleanBaseUrl)) return cleanBaseUrl
  if (/\/v1\/?$/i.test(cleanBaseUrl)) return `${cleanBaseUrl}/messages`
  return `${cleanBaseUrl}/v1/messages`
}

function readProviderModels(config) {
  const candidates = [config.models, config.modelIds, config.availableModels, config.whitelist]

  for (const candidate of candidates) {
    if (!candidate) continue
    if (Array.isArray(candidate)) {
      return candidate
        .map(item => {
          if (typeof item === 'string') return { id: item }
          const row = asRecord(item)
          return {
            id: asString(row.id || row.model || row.name),
            input: Array.isArray(row.input) ? row.input.map(item => asString(item).toLowerCase()) : null,
          }
        })
        .filter(model => model.id)
    }
    if (typeof candidate === 'object') {
      return Object.entries(candidate)
        .map(([key, value]) => {
          const row = asRecord(value)
          return {
            id: asString(row.id || row.model || row.name || key),
            input: Array.isArray(row.input) ? row.input.map(item => asString(item).toLowerCase()) : null,
          }
        })
        .filter(model => model.id)
    }
  }

  return []
}

function shouldProbeModel(model) {
  if (!model?.id) return false
  if (IMAGE_GENERATION_MODEL_PATTERNS.some(pattern => pattern.test(model.id))) return false
  if (Array.isArray(model.input) && model.input.length > 0 && !model.input.includes('text')) return false
  return true
}

function clearSkippedModelHealth(providerRow, model) {
  const providerId = asString(providerRow.provider_id)
  const modelRef = `${providerId}/${model.id}`
  const previous = readPreviousHealth(modelRef)
  if (!previous) return false

  const providerLatest = db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(providerRow.id)
    || providerRow
  const description = readProviderDescription(providerLatest)
  const modelMeta = description.modelMeta
  const currentMeta = asRecord(modelMeta[model.id])
  const currentRemark = asString(currentMeta.remark)

  if (currentRemark.startsWith(UNAVAILABLE_REMARK_PREFIX)) {
    modelMeta[model.id] = {
      ...currentMeta,
      remark: asString(previous.original_remark),
    }
    description.modelMeta = modelMeta
    writeProviderDescription(providerLatest.id, description)
  }

  db.prepare('DELETE FROM model_health_checks WHERE model_ref = ?').run(modelRef)
  db.prepare(`
    UPDATE models
    SET available = 1,
      remark = ?,
      health_status = 'unknown',
      latency_ms = 0,
      first_byte_ms = 0,
      health_error = '',
      health_checked_at = 0,
      updated_at = ?
    WHERE id = ?
  `).run(asString(previous.original_remark), Date.now(), modelRef)

  return true
}

function collectProbeTargets() {
  const rows = db.prepare('SELECT * FROM user_model_providers ORDER BY provider_id').all()
  const targets = []
  let skippedStateChanged = false

  for (const row of rows) {
    const config = readProviderConfig(row)
    const baseUrl = readBaseUrl(config)
    const apiKey = readSecret(config)
    const api = readProviderApi(row)
    const models = readProviderModels(config)

    if (!baseUrl || models.length === 0) continue

    for (const model of models) {
      if (!shouldProbeModel(model)) {
        skippedStateChanged = clearSkippedModelHealth(row, model) || skippedStateChanged
        continue
      }
      targets.push({
        providerRow: row,
        providerId: row.provider_id,
        modelId: model.id,
        modelRef: `${row.provider_id}/${model.id}`,
        baseUrl,
        apiKey,
        api,
      })
    }
  }

  if (skippedStateChanged) {
    try {
      syncAllTenantOpenClawConfigsFromDB()
    } catch (err) {
      console.error('[ModelHealth] openclaw.json sync error:', err?.message || err)
    }
  }

  return targets
}

function filterProbeTargets(targets, filter = {}) {
  const providerId = asString(filter.providerId).trim()
  const modelRef = asString(filter.modelRef).trim()

  if (modelRef) {
    return targets.filter(target => target.modelRef === modelRef)
  }

  if (!providerId) return targets
  return targets.filter(target => target.providerId === providerId)
}

async function probeModel(target, options) {
  const attempts = options.retries + 1
  let lastError = null

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await probeModelOnce(target, options)
    } catch (err) {
      lastError = err
      if (attempt < attempts) await new Promise(resolve => setTimeout(resolve, 500 * attempt))
    }
  }

  throw lastError || new Error('Probe failed')
}

async function probeModelOnce(target, options) {
  const controller = new AbortController()
  const startedAt = Date.now()
  const timeout = setTimeout(() => controller.abort(), options.timeoutMs)

  try {
    const api = asString(target.api).trim().toLowerCase()
    const request = buildHealthCheckRequest(target, api)
    const response = await fetch(request.url, {
      method: 'POST',
      headers: request.headers,
      body: JSON.stringify(request.body),
      signal: controller.signal,
    })

    if (!response.ok) {
      const text = await response.text().catch(() => '')
      throw new Error(`HTTP ${response.status}${text ? `: ${text.slice(0, 160)}` : ''}`)
    }

    const contentType = (response.headers.get('content-type') || '').toLowerCase()
    const reader = response.body?.getReader()
    const chunk = reader ? await reader.read() : { value: undefined }
    const firstByteMs = Date.now() - startedAt
    await reader?.cancel().catch(() => {})
    const latencyMs = Date.now() - startedAt
    const compactBody = chunk.value
      ? new TextDecoder().decode(chunk.value).trim().slice(0, 160)
      : ''

    if (contentType.includes('html') || /^<!doctype html/i.test(compactBody) || /^<html/i.test(compactBody)) {
      throw new Error(`Unexpected HTML response${compactBody ? `: ${compactBody}` : ''}`)
    }

    return { ok: true, firstByteMs, latencyMs }
  } catch (err) {
    if (err?.name === 'AbortError') throw new Error(`Timeout after ${options.timeoutMs}ms`)
    throw err
  } finally {
    clearTimeout(timeout)
  }
}

function buildHealthCheckRequest(target, api) {
  if (api === 'anthropic-messages') {
    return {
      url: normalizeAnthropicMessagesUrl(target.baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01',
        ...(target.apiKey ? { 'x-api-key': target.apiKey } : {}),
      },
      body: {
        model: target.modelId,
        max_tokens: 1,
        system: 'You are a helpful assistant.',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Hi',
              },
            ],
          },
        ],
        stream: true,
      },
    }
  }

  if (api === 'openai-responses') {
    return {
      url: normalizeResponsesUrl(target.baseUrl),
      headers: {
        'Content-Type': 'application/json',
        ...(target.apiKey ? { Authorization: `Bearer ${target.apiKey}` } : {}),
      },
      body: {
        model: target.modelId,
        input: 'Hi',
        instructions: 'You are a helpful assistant.',
        max_output_tokens: 16,
        stream: true,
      },
    }
  }

  return {
    url: normalizeChatCompletionsUrl(target.baseUrl),
    headers: {
      'Content-Type': 'application/json',
      ...(target.apiKey ? { Authorization: `Bearer ${target.apiKey}` } : {}),
    },
    body: {
      model: target.modelId,
      messages: [{ role: 'user', content: 'Hi' }],
      stream: true,
    },
  }
}

function readPreviousHealth(modelRef) {
  return db.prepare('SELECT * FROM model_health_checks WHERE model_ref = ?').get(modelRef)
}

function upsertModelHealth(target, status, result) {
  const now = Date.now()
  db.prepare(`
    INSERT INTO model_health_checks (
      model_ref, provider_id, model_id, status, latency_ms, first_byte_ms,
      error, original_remark, checked_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(model_ref) DO UPDATE SET
      provider_id = excluded.provider_id,
      model_id = excluded.model_id,
      status = excluded.status,
      latency_ms = excluded.latency_ms,
      first_byte_ms = excluded.first_byte_ms,
      error = excluded.error,
      original_remark = CASE
        WHEN model_health_checks.original_remark != '' THEN model_health_checks.original_remark
        ELSE excluded.original_remark
      END,
      checked_at = excluded.checked_at,
      updated_at = excluded.updated_at
  `).run(
    target.modelRef,
    target.providerId,
    target.modelId,
    status,
    result.latencyMs || 0,
    result.firstByteMs || 0,
    result.error || '',
    result.originalRemark || '',
    now,
    now
  )
}

function updateModelsTable(target, status, result) {
  const now = Date.now()
  db.prepare(`
    INSERT INTO models (
      id, provider, label, enabled, available, remark,
      health_status, latency_ms, first_byte_ms, health_error, health_checked_at, updated_at
    ) VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      provider = CASE WHEN models.provider = '' THEN excluded.provider ELSE models.provider END,
      available = excluded.available,
      remark = excluded.remark,
      health_status = excluded.health_status,
      latency_ms = excluded.latency_ms,
      first_byte_ms = excluded.first_byte_ms,
      health_error = excluded.health_error,
      health_checked_at = excluded.health_checked_at,
      updated_at = excluded.updated_at
  `).run(
    target.modelRef,
    target.providerId,
    target.modelId,
    status === 'ok' ? 1 : 0,
    result.remark || '',
    status,
    result.latencyMs || 0,
    result.firstByteMs || 0,
    result.error || '',
    now,
    now
  )
}

function setProviderModelRemark(target, status, result) {
  const providerRow = db.prepare('SELECT * FROM user_model_providers WHERE id = ?').get(target.providerRow.id)
    || target.providerRow
  const description = readProviderDescription(providerRow)
  const modelMeta = description.modelMeta
  const currentMeta = asRecord(modelMeta[target.modelId])
  const currentRemark = asString(currentMeta.remark)
  const previous = readPreviousHealth(target.modelRef)
  const originalRemark = previous?.original_remark || (
    currentRemark.startsWith(UNAVAILABLE_REMARK_PREFIX) ? '' : currentRemark
  )

  modelMeta[target.modelId] = {
    ...currentMeta,
    remark: status === 'ok'
      ? originalRemark
      : UNAVAILABLE_REMARK_PREFIX,
  }

  description.modelMeta = modelMeta
  writeProviderDescription(providerRow.id, description)
  try {
    syncAllTenantOpenClawConfigsFromDB()
  } catch (err) {
    console.error('[ModelHealth] openclaw.json sync error:', err?.message || err)
  }
  return originalRemark
}

async function probeAndPersist(target, options) {
  try {
    const result = await probeModel(target, options)
    const originalRemark = setProviderModelRemark(target, 'ok', result)
    upsertModelHealth(target, 'ok', { ...result, originalRemark, error: '' })
    updateModelsTable(target, 'ok', { ...result, remark: originalRemark, error: '' })
    broadcastModelHealth(target, 'ok', result)
    return { ok: true, ...result }
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err)
    const result = { error, latencyMs: 0, firstByteMs: 0 }
    const originalRemark = setProviderModelRemark(target, 'error', result)
    upsertModelHealth(target, 'error', { ...result, originalRemark })
    updateModelsTable(target, 'error', {
      ...result,
      remark: UNAVAILABLE_REMARK_PREFIX,
    })
    broadcastModelHealth(target, 'error', result)
    return { ok: false, error }
  }
}

function broadcastModelHealth(target, status, result) {
  broadcastGlobalSSE({
    type: 'modelHealth',
    providerId: target.providerId,
    modelId: target.modelId,
    status,
    latencyMs: result.latencyMs || 0,
    firstByteMs: result.firstByteMs || 0,
    error: result.error || '',
    checkedAt: Date.now(),
  })
}

export async function runModelHealthCheck(envConfig = process.env, filter = {}, optionsOverride = {}) {
  const filtered = !!(asString(filter.providerId).trim() || asString(filter.modelRef).trim())
  const scheduled = optionsOverride.source === 'scheduled'
  if (scheduled && isModelHealthQuietHours()) {
    console.log('[ModelHealth] skipped scheduled check during quiet hours')
    return { ok: true, skipped: true, reason: 'quiet hours', total: 0, healthy: 0, failed: 0, skippedCount: 0 }
  }
  if (running && !filtered) return { ok: true, skipped: true, reason: 'already running', total: 0, healthy: 0, failed: 0 }
  if (!filtered) running = true

  const options = {
    timeoutMs: positiveInt(envConfig.MODEL_HEALTH_TIMEOUT_MS, DEFAULT_TIMEOUT_MS),
    retries: positiveInt(envConfig.MODEL_HEALTH_MAX_RETRIES, DEFAULT_RETRIES),
  }

  try {
    const targets = filterProbeTargets(collectProbeTargets(), filter)
    let ok = 0
    let failed = 0
    let skipped = 0

    for (const target of targets) {
      const result = await probeAndPersist(target, options)
      if (result.ok) {
        ok += 1
        console.log(`[ModelHealth] ok ${target.modelRef} firstByte=${result.firstByteMs}ms latency=${result.latencyMs}ms`)
      } else if (result.skipped) {
        skipped += 1
        console.log(`[ModelHealth] skipped ${target.modelRef}: ${result.error}`)
      } else {
        failed += 1
        console.warn(`[ModelHealth] failed ${target.modelRef}: ${result.error}`)
      }
    }

    return { ok: true, total: targets.length, healthy: ok, failed, skipped }
  } finally {
    if (!filtered) running = false
  }
}

export function startModelHealthMonitor(envConfig = process.env) {
  if (envConfig.MODEL_HEALTH_CHECK_ENABLED === 'false') return
  if (timer) return

  const intervalMs = positiveInt(envConfig.MODEL_HEALTH_INTERVAL_MS, DEFAULT_INTERVAL_MS)
  timer = setInterval(() => {
    runModelHealthCheck(envConfig, {}, { source: 'scheduled' }).catch(err => {
      console.error('[ModelHealth] check failed:', err?.message || err)
    })
  }, intervalMs)

  setTimeout(() => {
    runModelHealthCheck(envConfig, {}, { source: 'scheduled' }).catch(err => {
      console.error('[ModelHealth] initial check failed:', err?.message || err)
    })
  }, positiveInt(envConfig.MODEL_HEALTH_INITIAL_DELAY_MS, 10_000))
}
