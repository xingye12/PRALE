import db from './database.js'
import { gatewayAdminRpc } from './core/gateway-client.js'

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function asString(value, fallback = '') {
  return typeof value === 'string' ? value : fallback
}

function asNumber(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function asPositiveInteger(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback
}

function asBoolean(value, fallback = false) {
  if (typeof value === 'boolean') return value
  if (value === 1 || value === '1' || value === 'true') return true
  if (value === 0 || value === '0' || value === 'false') return false
  return fallback
}

function parseCapabilities(value) {
  if (Array.isArray(value)) {
    return value.map((cap) => asString(cap)).filter(Boolean)
  }

  if (typeof value !== 'string' || value.trim() === '') return []

  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed.map((cap) => asString(cap)).filter(Boolean) : []
  } catch {
    return []
  }
}

function parseJsonObject(value) {
  if (!value) return {}
  if (typeof value === 'object' && !Array.isArray(value)) return value
  if (typeof value !== 'string') return {}
  try {
    return asRecord(JSON.parse(value))
  } catch {
    return {}
  }
}

function parseProviderModelMeta(description) {
  return asRecord(parseJsonObject(description).modelMeta)
}

function readModelContextWindow(row) {
  return asPositiveInteger(
    row.contextWindow || row.context_window || row.contextLength || row.context_length || row.context || row.maxContext,
    0
  )
}

function readModelMaxTokens(row) {
  return asPositiveInteger(
    row.maxTokens || row.max_tokens || row.outputTokens || row.output_tokens || row.maxOutputTokens || row.max_output_tokens,
    0
  )
}

function readProviderModels(config) {
  const candidates = [config.models, config.modelIds, config.availableModels, config.whitelist]

  for (const candidate of candidates) {
    if (!candidate) continue
    if (Array.isArray(candidate)) {
      return candidate
        .map(item => {
          if (typeof item === 'string') return { id: item, label: item, remark: '' }
          const row = asRecord(item)
          const id = asString(row.id || row.model || row.name)
          return {
            id,
            label: asString(row.name || row.label || row.model || row.id, id),
            remark: asString(row.remark),
            description: asString(row.description),
            contextWindow: readModelContextWindow(row) || undefined,
            maxTokens: readModelMaxTokens(row) || undefined,
          }
        })
        .filter(model => model.id)
    }
    if (typeof candidate === 'object') {
      return Object.entries(candidate)
        .map(([key, value]) => {
          const row = asRecord(value)
          const id = asString(row.id || row.model || row.name || key)
          return {
            id,
            label: asString(row.name || row.label || row.model || row.id || key, id),
            remark: asString(row.remark),
            description: asString(row.description),
            contextWindow: readModelContextWindow(row) || undefined,
            maxTokens: readModelMaxTokens(row) || undefined,
          }
        })
        .filter(model => model.id)
    }
  }

  return []
}

function toModelInfo(row) {
  const contextWindow = asNumber(row.context_window, 0)
  return {
    id: asString(row.id),
    label: asString(row.label) || undefined,
    provider: asString(row.provider) || undefined,
    family: asString(row.family) || undefined,
    enabled: asBoolean(row.enabled, true),
    available: asBoolean(row.available, true),
    description: asString(row.description) || undefined,
    contextWindow: contextWindow > 0 ? contextWindow : undefined,
    capabilities: parseCapabilities(row.capabilities),
    remark: asString(row.remark),
    healthStatus: asString(row.health_status, 'unknown'),
    latencyMs: asNumber(row.latency_ms, 0),
    firstByteMs: asNumber(row.first_byte_ms, 0),
    healthError: asString(row.health_error),
    healthCheckedAt: asNumber(row.health_checked_at, 0),
  }
}

function toModelInfoFromProvider(row, health) {
  const providerId = asString(row.provider_id)
  const config = parseJsonObject(row.config)
  const modelMeta = parseProviderModelMeta(row.description)
  const providerRemark = asString(row.remark)
  const models = readProviderModels(config)

  return models.map(model => {
    const meta = asRecord(modelMeta[model.id])
    const modelRef = `${providerId}/${model.id}`
    const healthRow = health.get(modelRef) || {}
    const status = asString(healthRow.status, 'unknown')
    return {
      id: modelRef,
      label: model.label || model.id,
      provider: providerId,
      enabled: true,
      available: status !== 'error',
      description: asString(meta.description || model.description),
      contextWindow: model.contextWindow,
      maxTokens: model.maxTokens,
      capabilities: [],
      remark: asString(meta.remark || model.remark || providerRemark),
      healthStatus: status,
      latencyMs: asNumber(healthRow.latency_ms, 0),
      firstByteMs: asNumber(healthRow.first_byte_ms, 0),
      healthError: asString(healthRow.error),
      healthCheckedAt: asNumber(healthRow.checked_at, 0),
    }
  })
}

export function listModelsFromDb(options = {}) {
  const includeUnavailable = options.includeUnavailable === true
  const sql = includeUnavailable
    ? 'SELECT * FROM models ORDER BY provider, label, id'
    : 'SELECT * FROM models WHERE available = 1 AND enabled = 1 ORDER BY provider, label, id'

  return db.prepare(sql).all().map(toModelInfo)
}

export function listModelsFromProviders(options = {}) {
  const includeUnavailable = options.includeUnavailable === true
  const healthRows = db.prepare('SELECT * FROM model_health_checks').all()
  const health = new Map(healthRows.map(row => [asString(row.model_ref), row]))
  const providerRows = db.prepare('SELECT * FROM user_model_providers ORDER BY provider_id, created_at ASC').all()
  const seen = new Set()
  const models = []

  for (const row of providerRows) {
    for (const model of toModelInfoFromProvider(row, health)) {
      if (seen.has(model.id)) continue
      seen.add(model.id)
      if (!includeUnavailable && model.available === false) continue
      models.push(model)
    }
  }

  return models.sort((a, b) => {
    const providerDiff = asString(a.provider).localeCompare(asString(b.provider))
    if (providerDiff !== 0) return providerDiff
    return asString(a.label || a.id).localeCompare(asString(b.label || b.id))
  })
}

export function normalizeModelItem(value) {
  const row = asRecord(value)
  const contextWindow = readModelContextWindow(row)
  const maxTokens = readModelMaxTokens(row)
  const enabled = asBoolean(row.enabled, true)

  return {
    id: asString(row.id || row.model || row.name),
    label: asString(row.label || row.displayName || row.name || row.model) || undefined,
    provider: asString(row.provider || row.vendor),
    family: asString(row.family || row.type) || undefined,
    enabled,
    available: asBoolean(row.available, true),
    description: asString(row.description) || undefined,
    contextWindow: contextWindow > 0 ? contextWindow : undefined,
    maxTokens: maxTokens > 0 ? maxTokens : undefined,
    capabilities: parseCapabilities(row.capabilities),
  }
}

export function normalizeModelList(payload) {
  const row = asRecord(payload)
  const list = Array.isArray(payload)
    ? payload
    : row.models || row.items || row.list || row.data || row.entries || []

  return Array.isArray(list)
    ? list.map(normalizeModelItem).filter((model) => model.id)
    : []
}

function upsertModelsUnsafe(models) {
  const stmt = db.prepare(`
    INSERT INTO models (
      id, provider, label, family, enabled, available, description,
      context_window, capabilities, updated_at
    ) VALUES (
      @id, @provider, @label, @family, @enabled, 1, @description,
      @contextWindow, @capabilities, strftime('%s', 'now') * 1000
    )
    ON CONFLICT(id) DO UPDATE SET
      provider = excluded.provider,
      label = excluded.label,
      family = excluded.family,
      available = 1,
      description = excluded.description,
      context_window = excluded.context_window,
      capabilities = excluded.capabilities,
      updated_at = excluded.updated_at
  `)

  for (const model of models) {
    stmt.run({
      id: model.id,
      provider: model.provider || '',
      label: model.label || '',
      family: model.family || '',
      enabled: model.enabled === false ? 0 : 1,
      description: model.description || '',
      contextWindow: model.contextWindow || 0,
      capabilities: JSON.stringify(parseCapabilities(model.capabilities)),
    })
  }

  return models.length
}

function markMissingModelsUnavailableUnsafe(models) {
  const ids = models.map((model) => model.id).filter(Boolean)
  if (ids.length === 0) return 0

  const placeholders = ids.map(() => '?').join(', ')
  const result = db
    .prepare(`UPDATE models SET available = 0, updated_at = strftime('%s', 'now') * 1000 WHERE id NOT IN (${placeholders}) AND available != 0`)
    .run(...ids)

  return result.changes || 0
}

export const upsertModels = db.transaction((models) => upsertModelsUnsafe(models))

export const markMissingModelsUnavailable = db.transaction((models) =>
  markMissingModelsUnavailableUnsafe(models)
)

const syncModelsTransaction = db.transaction((models) => {
  const count = upsertModelsUnsafe(models)
  const unavailable = markMissingModelsUnavailableUnsafe(models)
  return { count, unavailable }
})

export async function syncModelsFromGateway() {
  try {
    const rpcResult = await gatewayAdminRpc('models.list', {})
    if (!rpcResult.ok) {
      return {
        ok: false,
        error: rpcResult.error || 'models.list failed',
        count: 0,
        unavailable: 0,
      }
    }

    const models = normalizeModelList(rpcResult.payload)
    const { count, unavailable } = syncModelsTransaction(models)
    console.log(`[Models] synced ${count} models, marked unavailable ${unavailable}`)

    return { ok: true, count, unavailable }
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      count: 0,
      unavailable: 0,
    }
  }
}
