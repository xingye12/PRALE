import { Router } from 'express'
import { randomUUID } from 'crypto'
import { validateToken, getUserById } from './user-manager.js'

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies?.session
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  const result = validateToken(token)
  if (!result) return res.status(401).json({ error: 'Unauthorized' })
  req.currentUser = result.user
  next()
}

function adminMiddleware(req, res, next) {
  if (req.currentUser.role !== 'admin') return res.status(403).json({ error: 'Forbidden' })
  next()
}

export function createNotificationsRouter(db, broadcastGlobalSSE) {
  const router = Router()

  // 发布通知（仅管理员）
  router.post('/', authMiddleware, adminMiddleware, (req, res) => {
    const { title, content } = req.body
    if (!title?.trim()) return res.status(400).json({ error: '标题不能为空' })

    const id = randomUUID()
    const now = Date.now()
    db.prepare(
      'INSERT INTO notifications (id, title, content, created_at, created_by) VALUES (?, ?, ?, ?, ?)'
    ).run(id, title.trim(), (content || '').trim(), now, req.currentUser.id)

    // 保留最多 100 条，删除多余的旧通知
    db.prepare(`
      DELETE FROM notifications WHERE id NOT IN (
        SELECT id FROM notifications ORDER BY created_at DESC LIMIT 100
      )
    `).run()

    // 实时广播给所有在线用户
    if (broadcastGlobalSSE) {
      broadcastGlobalSSE({
        type: 'notification',
        action: 'new',
        payload: { id, title: title.trim(), content: (content || '').trim(), createdAt: now }
      })
    }

    res.json({ ok: true, id })
  })

  // 获取通知列表
  router.get('/', authMiddleware, (req, res) => {
    const rows = db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 100').all()
    const readRows = db.prepare(
      'SELECT notification_id FROM notification_reads WHERE user_id = ?'
    ).all(req.currentUser.id)
    const readSet = new Set(readRows.map(r => r.notification_id))

    const list = rows.map(r => ({
      id: r.id,
      title: r.title,
      content: r.content,
      createdAt: r.created_at,
      createdBy: r.created_by,
      isRead: readSet.has(r.id),
    }))

    res.json({ ok: true, list })
  })

  // 未读数量
  router.get('/unread-count', authMiddleware, (req, res) => {
    const total = db.prepare('SELECT COUNT(*) as c FROM notifications').get().c
    const readCount = db.prepare(
      'SELECT COUNT(DISTINCT notification_id) as c FROM notification_reads WHERE user_id = ?'
    ).get(req.currentUser.id).c
    res.json({ ok: true, count: Math.max(0, total - readCount) })
  })

  // 标记单条已读
  router.put('/:id/read', authMiddleware, (req, res) => {
    const now = Date.now()
    db.prepare(
      'INSERT OR IGNORE INTO notification_reads (notification_id, user_id, read_at) VALUES (?, ?, ?)'
    ).run(req.params.id, req.currentUser.id, now)
    res.json({ ok: true })
  })

  // 全部已读
  router.put('/read-all', authMiddleware, (req, res) => {
    const now = Date.now()
    const rows = db.prepare('SELECT id FROM notifications').all()
    const stmt = db.prepare(
      'INSERT OR IGNORE INTO notification_reads (notification_id, user_id, read_at) VALUES (?, ?, ?)'
    )
    for (const r of rows) {
      stmt.run(r.id, req.currentUser.id, now)
    }
    res.json({ ok: true })
  })

  // 删除通知（仅管理员）
  router.delete('/:id', authMiddleware, adminMiddleware, (req, res) => {
    db.prepare('DELETE FROM notification_reads WHERE notification_id = ?').run(req.params.id)
    db.prepare('DELETE FROM notifications WHERE id = ?').run(req.params.id)
    res.json({ ok: true })
  })

  return router
}
