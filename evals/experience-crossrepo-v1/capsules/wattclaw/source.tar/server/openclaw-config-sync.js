import path from 'path'
import { chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'fs'
import Database from 'better-sqlite3'
import db from './database.js'
import { getMultiTenantManager } from './core/multi-tenant-gateway.js'

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function asString(value, fallback = '') {
  return typeof value === 'string' ? value : fallback
}

function asPositiveInteger(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback
}

function parseJsonObject(value) {
  if (!value) return {}
  if (typeof value === 'object' && !Array.isArray(value)) return value
  if (typeof value !== 'string') return {}
  try {
    return asRecord(JSON.parse(value))
  } catch {
    return {}
  }
}

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value || {}))
}

function isHostPath(value) {
  return path.isAbsolute(value) || /^[A-Za-z]:[\\/]/.test(value)
}

function addCandidate(candidates, filePath) {
  if (!filePath) return
  const resolved = path.resolve(filePath)
  if (!candidates.includes(resolved)) candidates.push(resolved)
}

function resolveTenantConfigPath(tenant) {
  const candidates = []
  const dataSource = asString(tenant.data_source)
  const manager = getMultiTenantManager()
  const config = manager?.config || {}

  if (dataSource && isHostPath(dataSource)) {
    addCandidate(candidates, path.join(dataSource, 'openclaw.json'))

    const hostRoot = asString(config.hostDataDir || process.env.OPENCLAW_HOST_DATA_DIR)
    const containerRoot = asString(config.containerDataDir || process.env.OPENCLAW_CONTAINER_DATA_DIR)
    if (hostRoot && containerRoot) {
      const sourcePath = path.resolve(dataSource)
      const hostPath = path.resolve(hostRoot)
      if (sourcePath === hostPath || sourcePath.startsWith(`${hostPath}${path.sep}`)) {
        addCandidate(candidates, path.join(containerRoot, path.relative(hostPath, sourcePath), 'openclaw.json'))
      }
    }
  }

  const containerRoot = asString(config.containerDataDir || process.env.OPENCLAW_CONTAINER_DATA_DIR)
  if (containerRoot) {
    addCandidate(candidates, path.join(containerRoot, tenant.id, 'openclaw.json'))
  }

  const hostRoot = asString(config.hostDataDir || process.env.OPENCLAW_HOST_DATA_DIR)
  if (hostRoot) {
    addCandidate(candidates, path.join(hostRoot, tenant.id, 'openclaw.json'))
  }

  addCandidate(candidates, path.join(process.cwd(), 'tenants', tenant.id, 'openclaw.json'))

  return candidates.find(candidate => existsSync(candidate)) || candidates[0] || null
}

function resolveTenantStateDbPath(tenant) {
  const configPath = resolveTenantConfigPath(tenant)
  if (!configPath) return null
  return path.join(path.dirname(configPath), 'state', 'openclaw.sqlite')
}

function readTenantConfig(filePath) {
  if (!filePath || !existsSync(filePath)) return {}
  prepareWritableFile(filePath)
  try {
    const parsed = JSON.parse(readFileSync(filePath, 'utf8'))
    return asRecord(parsed)
  } catch (err) {
    throw new Error(`Invalid openclaw.json at ${filePath}: ${err.message}`)
  }
}

function relaxPathPermissions(filePath, fileMode = 0o666) {
  try {
    if (filePath && existsSync(filePath)) chmodSync(filePath, fileMode)
  } catch {
    /* ignore */
  }
}

function prepareWritableFile(filePath) {
  if (!filePath) return
  mkdirSync(path.dirname(filePath), { recursive: true })
  relaxPathPermissions(path.dirname(filePath), 0o777)
  relaxPathPermissions(filePath, 0o666)
}

function writeTenantConfig(filePath, config) {
  if (!filePath) throw new Error('Unable to resolve tenant openclaw.json path')
  prepareWritableFile(filePath)
  const tmpPath = `${filePath}.tmp-${process.pid}-${Date.now()}`
  writeFileSync(tmpPath, `${JSON.stringify(config, null, 2)}\n`)
  relaxPathPermissions(tmpPath, 0o666)
  renameSync(tmpPath, filePath)
  relaxPathPermissions(filePath, 0o666)
}

const DEFAULT_MODEL_CONTEXT_WINDOW = 1000000
const DEFAULT_MODEL_MAX_TOKENS = 131072

function sanitizeProviderConfigForOpenClaw(providerConfig) {
  const config = cloneJson(providerConfig)
  if (!config.models) return config

  const sanitizeModel = (model, fallbackId = '') => {
    if (typeof model === 'string') {
      const id = model.trim() || fallbackId
      if (!id) return model
      return {
        id,
        name: id,
        input: ['text'],
        contextWindow: DEFAULT_MODEL_CONTEXT_WINDOW,
        maxTokens: DEFAULT_MODEL_MAX_TOKENS,
      }
    }
    if (!model || typeof model !== 'object' || Array.isArray(model)) return model
    const { remark, description, ...next } = model
    const modelId = asString(next.id || next.model || next.name || fallbackId)
    if (modelId) {
      next.id = modelId
      if (!next.name) next.name = modelId
    }
    if (!Array.isArray(next.input) || next.input.length === 0) {
      next.input = ['text']
    }
    next.contextWindow = asPositiveInteger(
      next.contextWindow || next.context_window || next.contextLength || next.context_length || next.context || next.maxContext,
      DEFAULT_MODEL_CONTEXT_WINDOW
    )
    next.maxTokens = asPositiveInteger(
      next.maxTokens || next.max_tokens || next.outputTokens || next.output_tokens || next.maxOutputTokens || next.max_output_tokens,
      DEFAULT_MODEL_MAX_TOKENS
    )
    return next
  }

  if (Array.isArray(config.models)) {
    config.models = config.models.map(item => {
      return sanitizeModel(item)
    })
    return config
  }

  if (typeof config.models === 'object') {
    const nextModels = {}
    for (const [modelId, item] of Object.entries(config.models)) {
      nextModels[modelId] = sanitizeModel(item, modelId)
    }
    config.models = nextModels
  }

  return config
}

function collectProviderModels(providerId, providerConfig) {
  const models = providerConfig.models
  const refs = []

  const add = (modelId, model) => {
    if (!modelId) return
    refs.push({
      ref: `${providerId}/${modelId}`,
      alias: asString(model?.name || model?.label || modelId, modelId),
    })
  }

  if (Array.isArray(models)) {
    for (const item of models) {
      if (typeof item === 'string') {
        add(item, null)
      } else if (item && typeof item === 'object' && !Array.isArray(item)) {
        add(asString(item.id || item.model || item.name), item)
      }
    }
  } else if (models && typeof models === 'object') {
    for (const [modelId, item] of Object.entries(models)) {
      add(asString(asRecord(item).id || asRecord(item).model || asRecord(item).name || modelId), asRecord(item))
    }
  }

  return refs
}

export function buildModelProvidersFromDB() {
  const rows = db.prepare('SELECT * FROM user_model_providers ORDER BY created_at ASC').all()
  const providers = {}
  const aliases = {}

  for (const row of rows) {
    const providerId = asString(row.provider_id)
    if (!providerId) continue

    const config = sanitizeProviderConfigForOpenClaw(parseJsonObject(row.config))
    providers[providerId] = config

    for (const model of collectProviderModels(providerId, config)) {
      aliases[model.ref] = { alias: model.alias }
    }
  }

  return { providers, aliases }
}

function isKnownModelRef(value) {
  return typeof value === 'string' && value.includes('/') && value.indexOf('/') > 0 && value.indexOf('/') < value.length - 1
}

function isModelRefAllowed(value, providerPrefixes) {
  return !isKnownModelRef(value) || providerPrefixes.some(prefix => value.startsWith(prefix))
}

function filterModelRefList(value, providerPrefixes) {
  if (!Array.isArray(value)) return value
  const next = value.filter(item => isModelRefAllowed(item, providerPrefixes))
  return next.length > 0 ? next : undefined
}

const FEISHU_POLICY_VALUES = new Set(['open', 'pairing', 'allowlist'])

function normalizeFeishuPolicy(value, fallback = 'open') {
  const policy = asString(value, fallback)
  return FEISHU_POLICY_VALUES.has(policy) ? policy : fallback
}

function sanitizeFeishuAccountConfig(config) {
  const { footer, dmPolicy, groupPolicy, ...rest } = asRecord(config)
  return {
    ...rest,
    dmPolicy: normalizeFeishuPolicy(dmPolicy),
    groupPolicy: normalizeFeishuPolicy(groupPolicy),
  }
}

function sanitizeFeishuConfig(config) {
  const channels = asRecord(config.channels)
  const feishu = asRecord(channels.feishu)
  if (Object.keys(feishu).length === 0) return config

  const accounts = {}
  for (const [accountId, accountConfig] of Object.entries(asRecord(feishu.accounts))) {
    accounts[accountId] = sanitizeFeishuAccountConfig(accountConfig)
  }

  config.channels = {
    ...channels,
    feishu: {
      ...feishu,
      streaming: true,
      blockStreaming: true,
      accounts,
    },
  }
  return config
}

const HERMES_PLUGIN_ID = 'openclaw-plugin-hermes'

// Inject the per-tenant Hermes plugin configuration into openclaw.json. The
// plugin self-registers its provider + agent harness at startup, so we only
// need to (a) enable it and (b) point it at THIS tenant's paired Hermes
// container (`tcpHost`) and the shared execenv projection dir so the plugin's
// execenv-builder hits its docker-exec-free shortcut. This runs on every sync
// so it stays idempotent against model-health-monitor's periodic DB→file
// re-sync.
function injectHermesConfig(config, tenant) {
  const manager = getMultiTenantManager()
  const cfg = manager?.config
  if (!cfg?.hermesEnabled || !cfg?.hermesBaseImage) return
  if (!tenant?.id || typeof manager.hermesContainerNameFor !== 'function') return

  const containerName = manager.hermesContainerNameFor(tenant.id)
  const hermesDataDir = asString(cfg.hermesDataDir) || '/home/node/hermes-data'

  // In shared mode a single Hermes container serves every tenant, so partition
  // each tenant's execenv into its own subtree (…/execenv/<tenantId>) to keep
  // task workdirs from different tenants visibly separated. Both the OpenClaw
  // host view (execEnvRootDir) and the Hermes runtime view (runtimeExecEnvRootDir)
  // stay aligned under the same /opt/data mount so execenv-builder's免-exec 捷径
  // (hostExecEnvPath.replace(hermesDataDir,'/opt/data') === runtimeExecEnvPath)
  // still matches. In dedicated mode each tenant already owns its container, so
  // the roots stay flat to avoid churning existing execenv paths.
  const tenantSegment = String(tenant.id).replace(/[^A-Za-z0-9._-]/g, '_')
  const isShared = cfg.hermesMode === 'shared'
  const execEnvRootDir = isShared
    ? `${hermesDataDir}/execenv/${tenantSegment}`
    : `${hermesDataDir}/execenv`
  const runtimeExecEnvRootDir = isShared
    ? `/opt/data/execenv/${tenantSegment}`
    : '/opt/data/execenv'

  const plugins = asRecord(config.plugins)
  const entries = asRecord(plugins.entries)
  const existing = asRecord(entries[HERMES_PLUGIN_ID])
  const existingConfig = asRecord(existing.config)

  const hermesConfig = {
    ...existingConfig,
    transport: 'tcp',
    tcpHost: containerName,
    tcpPort: asPositiveInteger(cfg.hermesAcpPort, 3100),
    hermesContainerName: containerName,
    // Shared bind-mount path inside the OpenClaw container. Combined with
    // runtimeExecEnvRootDir this makes hostExecEnvPath
    // (${execEnvRootDir}/<task>) project to ${runtimeExecEnvRootDir}/<task>
    // inside Hermes, hitting execenv-builder's免-exec 捷径.
    hermesDataDir,
    execEnvRootDir,
    runtimeExecEnvRootDir,
    mirrorExecEnvToContainer: true,
  }
  if (asString(cfg.hermesModel)) hermesConfig.defaultModel = asString(cfg.hermesModel)

  config.plugins = {
    ...plugins,
    entries: {
      ...entries,
      [HERMES_PLUGIN_ID]: {
        ...existing,
        enabled: true,
        config: hermesConfig,
      },
    },
  }

  // The plugin self-registers its provider at runtime, but the gateway's
  // sessions.patch model validation checks the STATIC model list in
  // openclaw.json. syncTenantOpenClawConfigFromDB writes models with
  // mode:'replace' + DB-only providers, so hermes/default is rejected as
  // "model not allowed" unless we also declare it here. Mirror the plugin's
  // own catalog (provider.ts buildModelDefinition) and mark agentRuntime so
  // the harness takes over the agent loop.
  const models = asRecord(config.models)
  const providersMap = asRecord(models.providers)
  config.models = {
    ...models,
    providers: {
      ...providersMap,
      hermes: {
        baseUrl: 'http://127.0.0.1/hermes-runtime',
        apiKey: 'hermes-runtime',
        auth: 'token',
        api: 'openai-responses',
        agentRuntime: { id: 'hermes' },
        models: [
          {
            id: 'default',
            name: 'default',
            api: 'openai-responses',
            reasoning: true,
            input: ['text', 'image'],
            contextWindow: 200000,
            maxTokens: 32000,
            cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
            compat: { supportsReasoningEffort: true, supportsUsageInStreaming: true },
          },
        ],
      },
    },
  }

  const agents = asRecord(config.agents)
  const defaults = asRecord(agents.defaults)
  const aliasModels = asRecord(defaults.models)
  config.agents = {
    ...agents,
    defaults: {
      ...defaults,
      models: {
        ...aliasModels,
        'hermes/default': {
          alias: 'hermes',
          agentRuntime: { id: 'hermes' },
        },
      },
    },
  }
}

export function syncTenantOpenClawConfigFromDB(filePath, tenant = null) {
  const config = readTenantConfig(filePath)
  const { providers, aliases } = buildModelProvidersFromDB()

  sanitizeFeishuConfig(config)

  const existingModels = asRecord(config.models)
  config.models = {
    ...existingModels,
    mode: existingModels.mode || 'replace',
    providers,
  }

  const agents = asRecord(config.agents)
  const defaults = asRecord(agents.defaults)
  const providerPrefixes = Object.keys(providers).map(providerId => `${providerId}/`)
  const defaultModel = asRecord(defaults.model)
  const nextDefaultModel = { ...defaultModel }

  if (!isModelRefAllowed(nextDefaultModel.primary, providerPrefixes)) {
    delete nextDefaultModel.primary
  }
  if (!isModelRefAllowed(nextDefaultModel.fallback, providerPrefixes)) {
    delete nextDefaultModel.fallback
  }

  const nextFallbacks = filterModelRefList(nextDefaultModel.fallbacks, providerPrefixes)
  if (nextFallbacks) {
    nextDefaultModel.fallbacks = nextFallbacks
  } else {
    delete nextDefaultModel.fallbacks
  }

  config.agents = {
    ...agents,
    defaults: {
      ...defaults,
      model: nextDefaultModel,
      models: aliases,
    },
  }
  if (Array.isArray(config.agents.list)) {
    config.agents.list = config.agents.list.map(agent => sanitizeAgentIdentityForOpenClaw(agent))
  }

  if (tenant) injectHermesConfig(config, tenant)

  writeTenantConfig(filePath, config)
  return { ok: true, filePath, providerCount: Object.keys(providers).length }
}

export function syncAllTenantOpenClawConfigsFromDB() {
  const tenants = db.prepare('SELECT * FROM openclaw_tenants ORDER BY id').all()
  const targets = tenants.length > 0
    ? tenants
    : [{ id: 'tenant-1', data_source: '' }]
  const results = []

  for (const tenant of targets) {
    const filePath = resolveTenantConfigPath(tenant)
    if (!filePath) continue
    results.push(syncTenantOpenClawConfigFromDB(filePath, tenant))
  }

  return results
}

function tenantRowById(tenantId) {
  if (!tenantId) return null
  return db.prepare('SELECT * FROM openclaw_tenants WHERE id = ?').get(tenantId) || null
}

function listTenantRows() {
  return db.prepare('SELECT * FROM openclaw_tenants ORDER BY id').all()
}

function listUserAgentRows(userId) {
  return db.prepare(`
    SELECT *
    FROM user_agents
    WHERE user_id = ? AND status = 'active' AND gateway_agent_id IS NOT NULL AND gateway_agent_id != ''
    ORDER BY created_at ASC
  `).all(userId)
}

function listUserFeishuChannelRows(userId, agentIds) {
  if (agentIds.length === 0) return []
  const placeholders = agentIds.map(() => '?').join(', ')
  return db.prepare(`
    SELECT *
    FROM user_channels
    WHERE user_id = ?
      AND channel_type = 'feishu'
      AND status = 'active'
      AND agent_id IN (${placeholders})
    ORDER BY created_at ASC
  `).all(userId, ...agentIds)
}

function parseConfigObject(value) {
  return cloneJson(parseJsonObject(value))
}

function isImageAvatar(value) {
  return typeof value === 'string' && (
    value.startsWith('/') ||
    value.startsWith('http://') ||
    value.startsWith('https://') ||
    value.startsWith('data:')
  )
}

function isWattClawDisplayAvatar(value) {
  return typeof value === 'string' && (
    value.startsWith('/assets/') ||
    value.startsWith('/wattclaw/assets/') ||
    value.startsWith('/api/avatar-images/') ||
    value.startsWith('data:')
  )
}

function sanitizeAgentIdentityForOpenClaw(agent) {
  if (!agent || typeof agent !== 'object' || Array.isArray(agent)) return agent
  const identity = asRecord(agent.identity)
  if (Object.keys(identity).length === 0) return agent

  const nextIdentity = { ...identity }
  if (isWattClawDisplayAvatar(nextIdentity.avatar)) delete nextIdentity.avatar
  if (isWattClawDisplayAvatar(nextIdentity.avatarUrl)) delete nextIdentity.avatarUrl
  if (isWattClawDisplayAvatar(nextIdentity.emoji)) delete nextIdentity.emoji

  agent.identity = nextIdentity
  return agent
}

function fallbackAgentConfig(row) {
  const config = parseConfigObject(row.config)
  const agent = {
    ...config,
    id: asString(row.gateway_agent_id),
    name: asString(row.name || row.gateway_agent_id),
  }

  if (row.workspace && !agent.workspace) agent.workspace = row.workspace
  if (row.model && !agent.model) agent.model = row.model
  if (row.description && !agent.description) agent.description = row.description
  if (row.avatar && !agent.avatar) {
    const identity = asRecord(agent.identity)
    if (!isImageAvatar(row.avatar)) {
      agent.identity = { ...identity, emoji: row.avatar }
    }
  }

  return sanitizeAgentIdentityForOpenClaw(agent)
}

function fallbackFeishuAccountConfig(row) {
  const config = parseConfigObject(row.config)
  return sanitizeFeishuAccountConfig({
    ...config,
    enabled: 'enabled' in config ? config.enabled : true,
    dmPolicy: asString(config.dmPolicy, 'open'),
    groupPolicy: asString(config.groupPolicy, 'open'),
    connectionMode: asString(config.connectionMode, 'websocket'),
    allowFrom: Array.isArray(config.allowFrom) ? config.allowFrom : ['*'],
    groupAllowFrom: Array.isArray(config.groupAllowFrom) ? config.groupAllowFrom : ['*'],
  })
}

function fallbackBindingConfig(agentId) {
  return {
    agentId,
    match: {
      channel: 'feishu',
      accountId: agentId,
    },
  }
}

function bindingBelongsToAgent(binding, agentIds) {
  if (!binding || typeof binding !== 'object' || Array.isArray(binding)) return false
  const agentId = asString(binding.agentId)
  const match = asRecord(binding.match)
  const accountId = asString(match.accountId)
  return agentIds.has(agentId) || agentIds.has(accountId)
}

function collectTenantConfig(tenant) {
  const filePath = resolveTenantConfigPath(tenant)
  return {
    tenant,
    filePath,
    config: readTenantConfig(filePath),
    changed: false,
  }
}

const STATE_MIGRATION_TABLES = {
  acp_sessions: {
    agentColumns: ['agent'],
    sessionColumns: ['session_key'],
  },
  acp_replay_sessions: {
    sessionColumns: ['session_key'],
  },
  acp_replay_events: {
    sessionColumns: ['session_key'],
  },
  agent_databases: {
    agentColumns: ['agent_id'],
  },
  channel_ingress_events: {
    accountColumns: ['account_id'],
  },
  channel_pairing_allow_entries: {
    accountColumns: ['account_id'],
  },
  channel_pairing_requests: {
    accountColumns: ['account_id'],
  },
  command_log_entries: {
    sessionColumns: ['session_key'],
  },
  commitments: {
    agentColumns: ['agent_id'],
    accountColumns: ['account_id'],
    sessionColumns: ['session_key'],
  },
  cron_jobs: {
    agentColumns: ['agent_id'],
    accountColumns: ['delivery_account_id', 'failure_delivery_account_id'],
    sessionColumns: ['session_key'],
    collectJobColumns: ['job_id'],
  },
  cron_run_logs: {
    jobColumns: ['job_id'],
    sessionColumns: ['session_key'],
  },
  current_conversation_bindings: {
    agentColumns: ['target_agent_id'],
    accountColumns: ['account_id'],
    sessionColumns: ['target_session_key'],
  },
  delivery_queue_entries: {
    accountColumns: ['account_id'],
    sessionColumns: ['session_key'],
  },
  managed_outgoing_image_records: {
    sessionColumns: ['session_key'],
  },
  plugin_binding_approvals: {
    accountColumns: ['account_id'],
  },
  sandbox_registry_entries: {
    sessionColumns: ['session_key'],
  },
  subagent_runs: {
    sessionColumns: ['child_session_key', 'controller_session_key', 'requester_session_key', 'requester_display_key'],
  },
  task_runs: {
    agentColumns: ['agent_id'],
    jobColumns: ['source_id'],
    sessionColumns: ['requester_session_key', 'child_session_key'],
    collectJobColumns: ['source_id'],
    collectTaskColumns: ['task_id'],
  },
  task_delivery_state: {
    taskColumns: ['task_id'],
  },
  tui_last_sessions: {
    sessionColumns: ['session_key'],
  },
  voicewake_routing_config: {
    agentColumns: ['default_target_agent_id'],
    sessionColumns: ['default_target_session_key'],
  },
  voicewake_routing_routes: {
    agentColumns: ['target_agent_id'],
    sessionColumns: ['target_session_key'],
  },
}

function quoteSqlIdentifier(value) {
  return `"${String(value).replaceAll('"', '""')}"`
}

function getStateTableColumns(stateDb, tableName) {
  return stateDb.prepare(`PRAGMA table_info(${quoteSqlIdentifier(tableName)})`).all()
}

function listStateTables(stateDb) {
  return new Set(
    stateDb.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").all()
      .map(row => asString(row.name))
      .filter(Boolean)
  )
}

function valuesFromSet(values) {
  return Array.from(values).filter(Boolean)
}

function addToSet(target, value) {
  if (!value || target.has(value)) return false
  target.add(value)
  return true
}

function addRowIdentifiers(row, spec, identifiers) {
  let changed = false
  for (const column of spec.collectJobColumns || []) {
    changed = addToSet(identifiers.jobIds, asString(row[column])) || changed
  }
  for (const column of spec.collectTaskColumns || []) {
    changed = addToSet(identifiers.taskIds, asString(row[column])) || changed
  }
  for (const column of spec.sessionColumns || []) {
    changed = addToSet(identifiers.sessionKeys, asString(row[column])) || changed
  }
  return changed
}

function buildStateWhere(columns, spec, identifiers) {
  const available = new Set(columns.map(column => column.name))
  const clauses = []
  const params = []
  const addInClause = (column, values) => {
    if (!available.has(column) || values.length === 0) return
    clauses.push(`${quoteSqlIdentifier(column)} IN (${values.map(() => '?').join(', ')})`)
    params.push(...values)
  }

  const agentIds = valuesFromSet(identifiers.agentIds)
  const accountIds = valuesFromSet(identifiers.accountIds)
  const sessionKeys = valuesFromSet(identifiers.sessionKeys)
  const jobIds = valuesFromSet(identifiers.jobIds)
  const taskIds = valuesFromSet(identifiers.taskIds)

  for (const column of spec.agentColumns || []) addInClause(column, agentIds)
  for (const column of spec.accountColumns || []) addInClause(column, accountIds)
  for (const column of spec.jobColumns || []) addInClause(column, jobIds)
  for (const column of spec.taskColumns || []) addInClause(column, taskIds)

  for (const column of spec.sessionColumns || []) {
    addInClause(column, sessionKeys)
    if (!available.has(column)) continue
    for (const agentId of agentIds) {
      clauses.push(`${quoteSqlIdentifier(column)} LIKE ?`)
      params.push(`agent:${agentId}:%`)
    }
  }

  if (clauses.length === 0) return null
  return { sql: clauses.map(clause => `(${clause})`).join(' OR '), params }
}

function selectStateRows(stateDb, tableName, spec, identifiers) {
  const columns = getStateTableColumns(stateDb, tableName)
  const where = buildStateWhere(columns, spec, identifiers)
  if (!where) return []

  const columnNames = columns.map(column => column.name)
  const hasPk = columns.some(column => column.pk > 0)
  const selectList = hasPk
    ? '*'
    : `rowid AS __rowid__, ${columnNames.map(quoteSqlIdentifier).join(', ')}`
  return stateDb.prepare(`SELECT ${selectList} FROM ${quoteSqlIdentifier(tableName)} WHERE ${where.sql}`).all(...where.params)
}

function deriveStateMigrationIdentifiers(sourceDb, identifiers) {
  const tables = listStateTables(sourceDb)
  let changed = true

  while (changed) {
    changed = false
    for (const [tableName, spec] of Object.entries(STATE_MIGRATION_TABLES)) {
      if (!tables.has(tableName)) continue
      for (const row of selectStateRows(sourceDb, tableName, spec, identifiers)) {
        changed = addRowIdentifiers(row, spec, identifiers) || changed
      }
    }
  }
}

function insertStateRow(targetDb, tableName, columns, row) {
  const columnNames = columns.map(column => column.name)
  const sql = `
    INSERT OR REPLACE INTO ${quoteSqlIdentifier(tableName)}
      (${columnNames.map(quoteSqlIdentifier).join(', ')})
    VALUES (${columnNames.map(() => '?').join(', ')})
  `
  targetDb.prepare(sql).run(...columnNames.map(column => row[column]))
}

function deleteStateRow(sourceDb, tableName, columns, row) {
  const pkColumns = columns
    .filter(column => column.pk > 0)
    .sort((a, b) => a.pk - b.pk)
    .map(column => column.name)

  if (pkColumns.length > 0) {
    const where = pkColumns.map(column => `${quoteSqlIdentifier(column)} IS ?`).join(' AND ')
    sourceDb.prepare(`DELETE FROM ${quoteSqlIdentifier(tableName)} WHERE ${where}`).run(...pkColumns.map(column => row[column]))
    return
  }

  if ('__rowid__' in row) {
    sourceDb.prepare(`DELETE FROM ${quoteSqlIdentifier(tableName)} WHERE rowid = ?`).run(row.__rowid__)
  }
}

function moveMatchingStateRows(sourceDb, targetDb, tableName, spec, identifiers) {
  const sourceColumns = getStateTableColumns(sourceDb, tableName)
  const targetColumns = getStateTableColumns(targetDb, tableName)
  if (sourceColumns.length === 0 || targetColumns.length === 0) return 0

  const sourceColumnNames = sourceColumns.map(column => column.name)
  const targetColumnNames = targetColumns.map(column => column.name)
  if (sourceColumnNames.join('\n') !== targetColumnNames.join('\n')) return 0

  const rows = selectStateRows(sourceDb, tableName, spec, identifiers)
  for (const row of rows) {
    insertStateRow(targetDb, tableName, sourceColumns, row)
    deleteStateRow(sourceDb, tableName, sourceColumns, row)
  }

  return rows.length
}

function cleanupBackup(filePath) {
  try {
    if (filePath && existsSync(filePath)) unlinkSync(filePath)
  } catch {
    /* ignore */
  }
}

function migrateTenantStateDbForUserMove(sourceTenant, targetTenant, agentIds, accountIds) {
  if (!sourceTenant || !targetTenant || sourceTenant.id === targetTenant.id) {
    return { sourceTenantId: sourceTenant?.id || '', movedRows: 0, skipped: true }
  }

  const sourcePath = resolveTenantStateDbPath(sourceTenant)
  const targetPath = resolveTenantStateDbPath(targetTenant)
  if (!sourcePath || !targetPath || !existsSync(sourcePath) || !existsSync(targetPath)) {
    return { sourceTenantId: sourceTenant.id, movedRows: 0, skipped: true, reason: 'state db missing' }
  }

  const stamp = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`
  const sourceBackup = `${sourcePath}.sync-${stamp}.bak`
  const targetBackup = `${targetPath}.sync-${stamp}.bak`
  prepareWritableFile(sourcePath)
  prepareWritableFile(targetPath)
  copyFileSync(sourcePath, sourceBackup)
  copyFileSync(targetPath, targetBackup)
  relaxPathPermissions(sourceBackup, 0o666)
  relaxPathPermissions(targetBackup, 0o666)

  let sourceDb
  let targetDb
  try {
    sourceDb = new Database(sourcePath)
    targetDb = new Database(targetPath)
    const identifiers = {
      agentIds: new Set(agentIds),
      accountIds: new Set([...agentIds, ...accountIds]),
      sessionKeys: new Set(),
      jobIds: new Set(),
      taskIds: new Set(),
    }

    deriveStateMigrationIdentifiers(sourceDb, identifiers)

    const tables = listStateTables(sourceDb)
    let movedRows = 0
    sourceDb.prepare('BEGIN IMMEDIATE').run()
    targetDb.prepare('BEGIN IMMEDIATE').run()
    try {
      for (const [tableName, spec] of Object.entries(STATE_MIGRATION_TABLES)) {
        if (!tables.has(tableName)) continue
        movedRows += moveMatchingStateRows(sourceDb, targetDb, tableName, spec, identifiers)
      }
      targetDb.prepare('COMMIT').run()
      sourceDb.prepare('COMMIT').run()
    } catch (err) {
      try { targetDb.prepare('ROLLBACK').run() } catch { /* ignore */ }
      try { sourceDb.prepare('ROLLBACK').run() } catch { /* ignore */ }
      throw err
    }

    return {
      sourceTenantId: sourceTenant.id,
      movedRows,
      stateDb: targetPath,
      identifiers: {
        sessionCount: identifiers.sessionKeys.size,
        jobCount: identifiers.jobIds.size,
        taskCount: identifiers.taskIds.size,
      },
    }
  } catch (err) {
    try { sourceDb?.close() } catch { /* ignore */ }
    try { targetDb?.close() } catch { /* ignore */ }
    copyFileSync(sourceBackup, sourcePath)
    copyFileSync(targetBackup, targetPath)
    throw err
  } finally {
    try { sourceDb?.close() } catch { /* ignore */ }
    try { targetDb?.close() } catch { /* ignore */ }
    cleanupBackup(sourceBackup)
    cleanupBackup(targetBackup)
  }
}

function syncTenantStateDbsForUserMove(sourceTenants, targetTenant, agentIds, accountIds) {
  const results = []
  const seen = new Set()
  const stateBackups = []
  const stamp = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`

  for (const tenant of [targetTenant, ...sourceTenants]) {
    if (!tenant || seen.has(tenant.id)) continue
    seen.add(tenant.id)
    const statePath = resolveTenantStateDbPath(tenant)
    if (!statePath || !existsSync(statePath)) continue
    const backupPath = `${statePath}.sync-all-${stamp}.bak`
    copyFileSync(statePath, backupPath)
    stateBackups.push({ filePath: statePath, backupPath })
  }

  try {
    seen.clear()
    for (const sourceTenant of sourceTenants) {
      if (!sourceTenant || sourceTenant.id === targetTenant.id || seen.has(sourceTenant.id)) continue
      seen.add(sourceTenant.id)
      results.push(migrateTenantStateDbForUserMove(sourceTenant, targetTenant, agentIds, accountIds))
    }
  } catch (err) {
    restoreBackupFiles(stateBackups)
    throw err
  } finally {
    cleanupBackupFiles(stateBackups)
  }

  return results
}

function backupFiles(items) {
  const backups = []
  const stamp = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`
  for (const item of items) {
    if (!item.filePath || !existsSync(item.filePath)) continue
    const backupPath = `${item.filePath}.sync-${stamp}.bak`
    prepareWritableFile(item.filePath)
    copyFileSync(item.filePath, backupPath)
    relaxPathPermissions(backupPath, 0o666)
    backups.push({ filePath: item.filePath, backupPath })
  }
  return backups
}

function restoreBackupFiles(backups) {
  for (const backup of backups) {
    if (!existsSync(backup.backupPath)) continue
    prepareWritableFile(backup.filePath)
    copyFileSync(backup.backupPath, backup.filePath)
    relaxPathPermissions(backup.filePath, 0o666)
  }
}

function cleanupBackupFiles(backups) {
  for (const backup of backups) cleanupBackup(backup.backupPath)
}

function removeUserOpenClawArtifacts(target, agentIds, collected) {
  const config = target.config
  const agents = asRecord(config.agents)
  const list = Array.isArray(agents.list) ? agents.list : []
  const nextList = []

  for (const item of list) {
    const agentId = asString(item?.id || item?.agentId)
    if (agentIds.has(agentId)) {
      if (!collected.agents.has(agentId)) collected.agents.set(agentId, cloneJson(item))
      target.changed = true
    } else {
      nextList.push(item)
    }
  }

  if (list.length !== nextList.length) {
    config.agents = {
      ...agents,
      list: nextList,
    }
  }

  const channels = asRecord(config.channels)
  const feishu = asRecord(channels.feishu)
  const accounts = asRecord(feishu.accounts)
  let accountsChanged = false

  for (const agentId of agentIds) {
    if (Object.prototype.hasOwnProperty.call(accounts, agentId)) {
      if (!collected.accounts.has(agentId)) {
        collected.accounts.set(agentId, sanitizeFeishuAccountConfig(cloneJson(accounts[agentId])))
      }
      delete accounts[agentId]
      accountsChanged = true
      target.changed = true
    }
  }

  if (accountsChanged) {
    config.channels = {
      ...channels,
      feishu: {
        ...feishu,
        accounts,
      },
    }
  }

  const bindings = Array.isArray(config.bindings) ? config.bindings : []
  if (bindings.length > 0) {
    const nextBindings = []
    for (const binding of bindings) {
      if (bindingBelongsToAgent(binding, agentIds)) {
        const bindingAgentId = asString(binding.agentId || asRecord(binding.match).accountId)
        if (bindingAgentId && !collected.bindings.has(bindingAgentId)) {
          collected.bindings.set(bindingAgentId, cloneJson(binding))
        }
        target.changed = true
      } else {
        nextBindings.push(binding)
      }
    }
    if (nextBindings.length !== bindings.length) config.bindings = nextBindings
  }
}

function addUserOpenClawArtifacts(target, agentRows, channelRows, collected) {
  const config = target.config
  const bindingAgentIds = new Set()

  config.agents = {
    ...asRecord(config.agents),
    list: Array.isArray(asRecord(config.agents).list) ? asRecord(config.agents).list : [],
  }

  const existingAgentIds = new Set(config.agents.list.map(item => asString(item?.id || item?.agentId)).filter(Boolean))
  for (const row of agentRows) {
    const agentId = asString(row.gateway_agent_id)
    if (!agentId || existingAgentIds.has(agentId)) continue
    config.agents.list.push(sanitizeAgentIdentityForOpenClaw(collected.agents.get(agentId) || fallbackAgentConfig(row)))
    existingAgentIds.add(agentId)
    target.changed = true
  }

  if (channelRows.length > 0) {
    const channels = asRecord(config.channels)
    const feishu = asRecord(channels.feishu)
    const accounts = asRecord(feishu.accounts)
    let accountsChanged = false

    for (const row of channelRows) {
      const agentId = asString(row.agent_id)
      if (!agentId) continue
      accounts[agentId] = sanitizeFeishuAccountConfig(collected.accounts.get(agentId) || fallbackFeishuAccountConfig(row))
      bindingAgentIds.add(agentId)
      accountsChanged = true
    }

    if (accountsChanged) {
      config.channels = {
        ...channels,
        feishu: {
          enabled: 'enabled' in feishu ? feishu.enabled : true,
          ...feishu,
          streaming: true,
          blockStreaming: true,
          accounts,
        },
      }
      target.changed = true
    }
  }

  if (bindingAgentIds.size === 0) return

  config.bindings = Array.isArray(config.bindings) ? config.bindings : []
  const existingBindingKeys = new Set(config.bindings.map(binding => JSON.stringify(asRecord(binding.match))))
  for (const agentId of bindingAgentIds) {
    const binding = collected.bindings.get(agentId) || fallbackBindingConfig(agentId)
    const key = JSON.stringify(asRecord(binding.match))
    if (existingBindingKeys.has(key)) continue
    config.bindings.push(binding)
    existingBindingKeys.add(key)
    target.changed = true
  }
}

export function syncUserOpenClawConfigForTenantMove(userId, tenantId, previousTenantId = '') {
  const targetTenant = tenantRowById(tenantId)
  if (!targetTenant) throw new Error(`Tenant ${tenantId} not found`)

  const agentRows = listUserAgentRows(userId)
  const agentIds = agentRows.map(row => asString(row.gateway_agent_id)).filter(Boolean)
  if (agentIds.length === 0) {
    return { ok: true, skipped: true, reason: 'no user agents' }
  }

  const channelRows = listUserFeishuChannelRows(userId, agentIds)
  const agentIdSet = new Set(agentIds)
  const tenants = listTenantRows()
  const configs = []

  for (const tenant of tenants) {
    if (tenant.id === tenantId || tenant.id === previousTenantId) {
      configs.push(collectTenantConfig(tenant))
      continue
    }

    const filePath = resolveTenantConfigPath(tenant)
    if (!filePath || !existsSync(filePath)) continue
    const config = readTenantConfig(filePath)
    const list = Array.isArray(asRecord(config.agents).list) ? asRecord(config.agents).list : []
    const hasAgent = list.some(item => agentIdSet.has(asString(item?.id || item?.agentId)))
    const accounts = asRecord(asRecord(asRecord(config.channels).feishu).accounts)
    const hasAccount = agentIds.some(agentId => Object.prototype.hasOwnProperty.call(accounts, agentId))
    const bindings = Array.isArray(config.bindings) ? config.bindings : []
    const hasBinding = bindings.some(binding => bindingBelongsToAgent(binding, agentIdSet))

    if (hasAgent || hasAccount || hasBinding) {
      configs.push({ tenant, filePath, config, changed: false })
    }
  }

  if (!configs.some(item => item.tenant.id === tenantId)) {
    configs.push(collectTenantConfig(targetTenant))
  }

  const collected = {
    agents: new Map(),
    accounts: new Map(),
    bindings: new Map(),
  }
  const sourceTenants = tenants.filter(tenant => tenant.id !== tenantId)

  for (const item of configs) {
    removeUserOpenClawArtifacts(item, agentIdSet, collected)
  }

  const target = configs.find(item => item.tenant.id === tenantId)
  addUserOpenClawArtifacts(target, agentRows, channelRows, collected)

  const changedConfigItems = configs.filter(item => item.changed)
  const configBackups = backupFiles(changedConfigItems)
  let stateSync = []
  const changed = []
  try {
    for (const item of changedConfigItems) {
      writeTenantConfig(item.filePath, item.config)
      changed.push({ tenantId: item.tenant.id, filePath: item.filePath })
    }

    stateSync = syncTenantStateDbsForUserMove(
      sourceTenants,
      targetTenant,
      agentIds,
      channelRows.map(row => asString(row.agent_id)).filter(Boolean)
    )
  } catch (err) {
    restoreBackupFiles(configBackups)
    throw err
  } finally {
    cleanupBackupFiles(configBackups)
  }

  return {
    ok: true,
    tenantId,
    previousTenantId,
    agentCount: agentRows.length,
    feishuAccountCount: channelRows.length,
    bindingCount: channelRows.length,
    changed,
    stateSync,
  }
}
