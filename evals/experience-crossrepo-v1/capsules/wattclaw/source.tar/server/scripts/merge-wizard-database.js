import Database from 'better-sqlite3'
import { copyFileSync, existsSync } from 'fs'
import { resolve } from 'path'

const args = process.argv.slice(2)
const dryRun = args.includes('--dry-run')
const sourceArg = args.find(arg => arg.startsWith('--source='))
const targetArg = args.find(arg => arg.startsWith('--target='))
const sourcePath = resolve(sourceArg?.slice('--source='.length) || 'data/wizard-old.db')
const targetPath = resolve(targetArg?.slice('--target='.length) || 'data/wizard.db')

if (!existsSync(sourcePath)) throw new Error(`Source database not found: ${sourcePath}`)
if (!existsSync(targetPath)) throw new Error(`Target database not found: ${targetPath}`)

function quoteIdentifier(value) {
  return `"${value.replace(/"/g, '""')}"`
}

function listTables(db) {
  return db.prepare("SELECT name, sql FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all()
}

function getTableInfo(db, table) {
  return db.prepare(`PRAGMA table_info(${quoteIdentifier(table)})`).all()
}

function getRows(db, table, columns) {
  return db.prepare(`SELECT ${columns.map(quoteIdentifier).join(', ')} FROM ${quoteIdentifier(table)}`).all()
}

const source = new Database(sourcePath, { readonly: true })
const target = new Database(targetPath)
const sourceTables = listTables(source)
const targetTables = new Set(listTables(target).map(row => row.name))
const summary = []

try {
  target.pragma('foreign_keys = OFF')
  target.pragma('journal_mode = WAL')

  if (!dryRun) {
    const backupPath = `${targetPath}.before-old-db-merge-${Date.now()}`
    copyFileSync(targetPath, backupPath)
    console.log(`Backup created: ${backupPath}`)
  }

  const merge = target.transaction(() => {
    for (const sourceTable of sourceTables) {
      const table = sourceTable.name
      const tableExists = targetTables.has(table)
      if (!tableExists) {
        if (!dryRun) target.exec(sourceTable.sql)
        targetTables.add(table)
      }

      const sourceInfo = getTableInfo(source, table)
      const targetInfo = tableExists ? getTableInfo(target, table) : sourceInfo
      const sourceColumns = sourceInfo.map(column => column.name)
      const targetColumns = new Set(targetInfo.map(column => column.name))
      const columns = sourceColumns.filter(column => targetColumns.has(column))
      const primaryKey = sourceInfo
        .filter(column => column.pk)
        .sort((a, b) => a.pk - b.pk)
        .map(column => column.name)

      if (!tableExists && dryRun) {
        const rows = getRows(source, table, columns)
        summary.push({ table, inserted: rows.length, updated: 0, skipped: 0, createdTable: true })
        continue
      }

      if (columns.length === 0 || primaryKey.length === 0) {
        summary.push({ table, inserted: 0, updated: 0, skipped: 0, reason: 'no compatible primary key' })
        continue
      }

      const rows = getRows(source, table, columns)
      const selectExisting = target.prepare(`SELECT ${columns.map(quoteIdentifier).join(', ')} FROM ${quoteIdentifier(table)} WHERE ${primaryKey.map(column => `${quoteIdentifier(column)} = ?`).join(' AND ')}`)
      const insert = target.prepare(`INSERT OR IGNORE INTO ${quoteIdentifier(table)} (${columns.map(quoteIdentifier).join(', ')}) VALUES (${columns.map(() => '?').join(', ')})`)
      const updateColumns = columns.filter(column => !primaryKey.includes(column) && column !== 'created_at')
      const update = updateColumns.length > 0
        ? target.prepare(`UPDATE ${quoteIdentifier(table)} SET ${updateColumns.map(column => `${quoteIdentifier(column)} = ?`).join(', ')} WHERE ${primaryKey.map(column => `${quoteIdentifier(column)} = ?`).join(' AND ')}`)
        : null
      const updateBySessionKey = table === 'user_sessions'
        ? target.prepare(`UPDATE ${quoteIdentifier(table)} SET ${updateColumns.filter(column => column !== 'session_key').map(column => `${quoteIdentifier(column)} = ?`).join(', ')} WHERE "session_key" = ?`)
        : null
      const selectBySessionKey = table === 'user_sessions'
        ? target.prepare(`SELECT ${columns.map(quoteIdentifier).join(', ')} FROM ${quoteIdentifier(table)} WHERE "session_key" = ?`)
        : null

      let inserted = 0
      let updated = 0
      let skipped = 0
      let conflicts = 0
      for (const row of rows) {
        const keyValues = primaryKey.map(column => row[column])
        const existing = selectExisting.get(...keyValues)
        if (!existing) {
          if (dryRun) {
            inserted++
          } else {
            const result = insert.run(...columns.map(column => row[column]))
            if (result.changes) inserted++
            else if (selectBySessionKey && updateBySessionKey) {
              const conflictingSession = selectBySessionKey.get(row.session_key)
              const sourceUpdatedAt = Number(row.updated_at)
              const targetUpdatedAt = Number(conflictingSession?.updated_at)
              if (conflictingSession && Number.isFinite(sourceUpdatedAt) && Number.isFinite(targetUpdatedAt) && sourceUpdatedAt > targetUpdatedAt) {
                updateBySessionKey.run(...updateColumns.filter(column => column !== 'session_key').map(column => row[column]), row.session_key)
                updated++
              } else {
                conflicts++
              }
            } else conflicts++
          }
          continue
        }

        const sourceUpdatedAt = Number(row.updated_at)
        const targetUpdatedAt = Number(existing.updated_at)
        const canUpdate = 'updated_at' in row && 'updated_at' in existing
          && Number.isFinite(sourceUpdatedAt)
          && Number.isFinite(targetUpdatedAt)
          && sourceUpdatedAt > targetUpdatedAt
        if (canUpdate && update) {
          updated++
          if (!dryRun) update.run(...updateColumns.map(column => row[column]), ...keyValues)
        } else {
          skipped++
        }
      }
      summary.push({ table, inserted, updated, skipped, conflicts })
    }
  })

  merge()
  for (const item of summary) console.log(JSON.stringify(item))
  if (!dryRun) {
    const integrity = target.pragma('integrity_check', { simple: true })
    if (integrity !== 'ok') throw new Error(`Integrity check failed: ${integrity}`)
    target.pragma('wal_checkpoint(TRUNCATE)')
  }
} finally {
  source.close()
  target.close()
}
