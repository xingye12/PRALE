import { randomBytes } from 'crypto'
import db from '../database.js'
import { createUser } from '../user-manager.js'
import { getPool, initMessageStore } from '../message-store.js'

function required(name, fallback = '') {
  const value = String(process.env[name] || fallback).trim()
  if (!value) throw new Error(`${name} is required`)
  return value
}

function quoteIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`
}

function assertTestEnvironment() {
  if (process.env.TEST_ENVIRONMENT !== 'true') {
    throw new Error('Refusing to reset data outside the isolated test environment')
  }
  if (process.env.TEST_DATA_RESET !== 'confirm') {
    throw new Error('Set TEST_DATA_RESET=confirm to reset the isolated test databases')
  }

  const databaseUrl = new URL(required('DATABASE_URL'))
  const databaseName = databaseUrl.pathname.replace(/^\//, '')
  if (databaseUrl.hostname !== 'postgres-test' || !databaseName.includes('test')) {
    throw new Error('Refusing to reset a PostgreSQL database that is not the isolated test database')
  }

  const containerPrefix = required('OPENCLAW_CONTAINER_PREFIX')
  const network = required('OPENCLAW_NETWORK')
  const instanceId = required('INSTANCE_ID')
  if (!/^[a-z0-9][a-z0-9-]{1,30}$/.test(instanceId)) {
    throw new Error('Refusing to reset data with an invalid INSTANCE_ID')
  }
  if (!containerPrefix.startsWith(`openclaw-${instanceId}`) || network !== `wattclaw-${instanceId}-net`) {
    throw new Error('Refusing to reset data with non-test OpenClaw container settings')
  }

  const projectRoot = required('PROJECT_ROOT')
  const hostDataDir = required('OPENCLAW_HOST_DATA_DIR')
  if (!hostDataDir.startsWith(`${projectRoot.replace(/[\\/]+$/, '')}/runtime/`)) {
    throw new Error('Refusing to reset data outside the project runtime directory')
  }
}

function clearSqliteData() {
  const tables = db.prepare(`
    SELECT name
    FROM sqlite_master
    WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
    ORDER BY name
  `).all()

  db.pragma('foreign_keys = OFF')
  const clear = db.transaction(() => {
    for (const { name } of tables) {
      db.exec(`DELETE FROM ${quoteIdentifier(name)}`)
    }
  })
  clear()
  db.pragma('foreign_keys = ON')
  return tables.length
}

function tenantDataSource(id) {
  const root = String(process.env.OPENCLAW_HOST_DATA_DIR || '').replace(/[\\/]+$/, '')
  return root ? `${root}/${id}` : `openclaw-test-data-${id}`
}

function seedAccounts() {
  const adminUsername = required('AUTH_USERNAME')
  const adminPassword = required('AUTH_PASSWORD')
  const firstUsername = required('TEST_ACCOUNT_1_USERNAME')
  const firstPassword = required('TEST_ACCOUNT_1_PASSWORD')
  const secondUsername = required('TEST_ACCOUNT_2_USERNAME')
  const secondPassword = required('TEST_ACCOUNT_2_PASSWORD')
  if (new Set([adminUsername, firstUsername, secondUsername]).size !== 3) {
    throw new Error('The three test usernames must be different')
  }

  const admin = createUser({
    username: adminUsername,
    password: adminPassword,
    role: 'admin',
    displayName: 'Test Administrator',
  })
  const first = createUser({
    username: firstUsername,
    password: firstPassword,
    role: 'user',
    displayName: 'Test User 1',
  })
  const second = createUser({
    username: secondUsername,
    password: secondPassword,
    role: 'user',
    displayName: 'Test User',
  })

  const now = Date.now()
  const prefix = required('OPENCLAW_CONTAINER_PREFIX')
  const port = Number(process.env.OPENCLAW_PORT || 18789)
  const maxUsers = Number(process.env.OPENCLAW_MAX_USERS || 2)
  const cpuSets = String(process.env.OPENCLAW_CPUSETS || '').split(';').map(value => value.trim())
  const insertTenant = db.prepare(`
    INSERT INTO openclaw_tenants (
      id, container_name, token, host, port, max_users, cpuset_cpus,
      data_source, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
  `)
  const assignTenant = db.prepare(`
    INSERT INTO user_tenant_assignments (
      user_id, tenant_id, assignment_mode, created_at, updated_at
    ) VALUES (?, ?, 'manual', ?, ?)
  `)

  const seed = db.transaction(() => {
    for (const index of [0, 1]) {
      const tenantId = `tenant-${index + 1}`
      const containerName = `${prefix}-${index + 1}`
      const token = `openclaw-test-token-${tenantId}-${randomBytes(12).toString('hex')}`
      insertTenant.run(
        tenantId,
        containerName,
        token,
        containerName,
        port,
        maxUsers,
        cpuSets[index] || '',
        tenantDataSource(tenantId),
        now,
        now,
      )
    }
    assignTenant.run(admin.id, 'tenant-1', now, now)
    assignTenant.run(first.id, 'tenant-1', now, now)
    assignTenant.run(second.id, 'tenant-2', now, now)
  })
  seed()

  return [
    { username: admin.username, role: admin.role, tenant: 'tenant-1', container: `${prefix}-1` },
    { username: first.username, role: first.role, tenant: 'tenant-1', container: `${prefix}-1` },
    { username: second.username, role: second.role, tenant: 'tenant-2', container: `${prefix}-2` },
  ]
}

async function clearPostgresData() {
  await initMessageStore()
  const pool = getPool()
  if (!pool) throw new Error('Test PostgreSQL message store is unavailable')
  await pool.query('TRUNCATE TABLE session_messages RESTART IDENTITY')
  await pool.end()
}

async function main() {
  assertTestEnvironment()
  const tableCount = clearSqliteData()
  const accounts = seedAccounts()
  await clearPostgresData()
  console.log(JSON.stringify({ sqliteTablesCleared: tableCount, postgresCleared: true, accounts }, null, 2))
}

main().then(
  () => process.exit(0),
  error => {
    console.error('[TestDataReset] Reset failed:', error.message)
    process.exit(1)
  },
)
