import { randomUUID } from 'crypto'
import db from '../database.js'

function parseJson(value, fallback) {
  try {
    return JSON.parse(value || '')
  } catch {
    return fallback
  }
}

function normalizeProfile(row) {
  if (!row) return null
  return {
    id: row.id,
    userId: row.user_id,
    tenantId: row.tenant_id,
    roleId: row.role_id,
    name: row.name,
    gatewayAgentId: row.gateway_agent_id || null,
    baseWorkspace: row.base_workspace || null,
    capabilityTags: parseJson(row.capability_tags_json, []),
    skills: parseJson(row.skills_json, []),
    model: row.model || null,
    reusePolicy: row.reuse_policy,
    concurrencyLimit: Number(row.concurrency_limit || 1),
    status: row.status,
    metadata: parseJson(row.metadata_json, {}),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

function inferredRole(text) {
  const value = String(text || '').toLowerCase()
  if (/(frontend|前端|网页|web)/.test(value)) return 'frontend_engineer'
  if (/(product|产品|需求|prd)/.test(value)) return 'product_analyst'
  if (/(qa|test|测试|验收|质量)/.test(value)) return 'qa_engineer'
  if (/(design|设计|视觉|ui|ux)/.test(value)) return 'visual_designer'
  if (/(data|数据|分析|统计)/.test(value)) return 'data_analyst'
  if (/(copy|writer|文案|编辑|内容)/.test(value)) return 'copywriter'
  if (/(video|视频|剪辑)/.test(value)) return 'video_editor'
  if (/(manager|经理|管理|协调)/.test(value)) return 'project_manager'
  return 'domain_specialist'
}

function inferredCapabilities(roleId) {
  const mapping = {
    project_manager: ['planning', 'delegation'],
    frontend_engineer: ['frontend_implementation'],
    product_analyst: ['requirements_analysis'],
    qa_engineer: ['qa_validation'],
    visual_designer: ['visual_design'],
    data_analyst: ['data_analysis', 'data_visualization'],
    copywriter: ['copywriting'],
    video_editor: ['video_editing'],
    domain_specialist: ['domain_execution'],
  }
  return mapping[roleId] || []
}

export function syncReusableAgentProfiles(userId) {
  if (!userId) return 0
  const agents = db.prepare(`
    SELECT id, gateway_agent_id, workspace, name, description, model, category, template_id
    FROM user_agents
    WHERE user_id = ? AND status = 'active'
      AND gateway_agent_id IS NOT NULL AND gateway_agent_id != ''
      AND gateway_agent_id NOT LIKE 'p-%'
  `).all(userId)
  const insert = db.prepare(`
    INSERT OR IGNORE INTO agent_profiles
      (id, user_id, role_id, name, gateway_agent_id, base_workspace,
       capability_tags_json, skills_json, model, reuse_policy, concurrency_limit,
       status, metadata_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, '[]', ?, 'profile', 1, 'available', ?, ?, ?)
  `)
  let changes = 0
  const now = Date.now()
  for (const agent of agents) {
    const existing = db.prepare(`
      SELECT id FROM agent_profiles WHERE user_id = ? AND gateway_agent_id = ? LIMIT 1
    `).get(userId, agent.gateway_agent_id)
    if (existing) continue
    const roleId = inferredRole([
      agent.category,
      agent.template_id,
      agent.name,
      agent.description,
    ].filter(Boolean).join(' '))
    changes += insert.run(
      `user-agent-${agent.id}`,
      userId,
      roleId,
      agent.name || agent.gateway_agent_id,
      agent.gateway_agent_id,
      agent.workspace || null,
      JSON.stringify(inferredCapabilities(roleId)),
      agent.model || null,
      JSON.stringify({ source: 'user_agents', userAgentId: agent.id }),
      now,
      now,
    ).changes
  }
  return changes
}

function profileQuery(userId, roleId = '') {
  if (roleId) {
    return db.prepare(`
      SELECT * FROM agent_profiles
      WHERE user_id = ? AND role_id = ?
      ORDER BY CASE WHEN status = 'available' THEN 0 ELSE 1 END, updated_at DESC
    `).all(userId, roleId)
  }
  return db.prepare(`
    SELECT * FROM agent_profiles
    WHERE user_id = ?
    ORDER BY updated_at DESC
  `).all(userId)
}

export function listAgentProfiles(userId, { roleId = '', status = '' } = {}) {
  if (!userId) return []
  syncReusableAgentProfiles(userId)
  const rows = profileQuery(userId, roleId).filter(row => !status || row.status === status)
  return rows.map(normalizeProfile)
}

export function getAgentProfile(id, userId = null) {
  if (!id) return null
  const row = userId
    ? db.prepare('SELECT * FROM agent_profiles WHERE id = ? AND user_id = ?').get(id, userId)
    : db.prepare('SELECT * FROM agent_profiles WHERE id = ?').get(id)
  return normalizeProfile(row)
}

export function findReusableAgentProfile(userId, { roleId = '', capabilities = [] } = {}) {
  const requiredCapabilities = new Set(
    (Array.isArray(capabilities) ? capabilities : []).filter(value => typeof value === 'string' && value.trim()),
  )
  const profiles = listAgentProfiles(userId, { roleId }).filter(profile =>
    profile.status === 'available' || profile.status === 'leased'
  )
  for (const profile of profiles) {
    const profileCapabilities = new Set(profile.capabilityTags)
    if (![...requiredCapabilities].every(capability => profileCapabilities.has(capability))) continue
    const activeBindings = db.prepare(`
      SELECT COUNT(*) AS count
      FROM project_member_bindings
      WHERE profile_id = ? AND status = 'leased'
        AND (lease_until IS NULL OR lease_until > ?)
    `).get(profile.id, Date.now())
    if (Number(activeBindings?.count || 0) < profile.concurrencyLimit) return profile
  }
  return null
}

export function upsertAgentProfile({
  id = randomUUID(),
  userId,
  tenantId = '',
  roleId,
  name,
  gatewayAgentId = null,
  baseWorkspace = null,
  capabilityTags = [],
  skills = [],
  model = null,
  reusePolicy = 'profile',
  concurrencyLimit = 1,
  status = 'available',
  metadata = {},
}) {
  if (!userId) throw new Error('Agent profile userId is required')
  if (!roleId) throw new Error('Agent profile roleId is required')
  if (!name) throw new Error('Agent profile name is required')
  const existing = db.prepare('SELECT user_id FROM agent_profiles WHERE id = ?').get(id)
  if (existing && existing.user_id !== userId) throw new Error('Agent profile belongs to another user')
  const now = Date.now()
  db.prepare(`
    INSERT INTO agent_profiles
      (id, user_id, tenant_id, role_id, name, gateway_agent_id, base_workspace,
       capability_tags_json, skills_json, model, reuse_policy, concurrency_limit,
       status, metadata_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      tenant_id = excluded.tenant_id,
      role_id = excluded.role_id,
      name = excluded.name,
      gateway_agent_id = excluded.gateway_agent_id,
      base_workspace = excluded.base_workspace,
      capability_tags_json = excluded.capability_tags_json,
      skills_json = excluded.skills_json,
      model = excluded.model,
      reuse_policy = excluded.reuse_policy,
      concurrency_limit = excluded.concurrency_limit,
      status = excluded.status,
      metadata_json = excluded.metadata_json,
      updated_at = excluded.updated_at
  `).run(
    id,
    userId,
    tenantId,
    roleId,
    name,
    gatewayAgentId,
    baseWorkspace,
    JSON.stringify(Array.isArray(capabilityTags) ? capabilityTags : []),
    JSON.stringify(Array.isArray(skills) ? skills : []),
    model,
    reusePolicy,
    Math.max(1, Number(concurrencyLimit) || 1),
    status,
    JSON.stringify(metadata && typeof metadata === 'object' ? metadata : {}),
    now,
    now,
  )
  return getAgentProfile(id, userId)
}

export function bindAgentProfileToProject({
  projectId,
  userId,
  slotId,
  profileId,
  runtimeAgentId = null,
  sessionKey = null,
  projectWorkspace = null,
  leaseMs = 30 * 60 * 1000,
}) {
  if (!projectId || !userId || !slotId || !profileId) {
    throw new Error('projectId, userId, slotId and profileId are required')
  }
  const profile = getAgentProfile(profileId, userId)
  if (!profile) throw new Error('Agent profile not found')
  if (profile.status !== 'available' && profile.status !== 'leased') {
    throw new Error(`Agent profile is not available: ${profile.status}`)
  }

  const existing = db.prepare(`
    SELECT id FROM project_member_bindings
    WHERE project_id = ? AND slot_id = ? AND user_id = ?
  `).get(projectId, slotId, userId)
  const id = existing?.id || randomUUID()
  const now = Date.now()
  const leaseUntil = now + Math.max(60_000, Number(leaseMs) || 0)
  db.prepare(`
    INSERT INTO project_member_bindings
      (id, project_id, user_id, slot_id, profile_id, runtime_agent_id, session_key,
       project_workspace, lease_until, status, created_at, updated_at, released_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'leased', ?, ?, NULL)
    ON CONFLICT(project_id, slot_id) DO UPDATE SET
      profile_id = excluded.profile_id,
      runtime_agent_id = excluded.runtime_agent_id,
      session_key = excluded.session_key,
      project_workspace = excluded.project_workspace,
      lease_until = excluded.lease_until,
      status = 'leased',
      updated_at = excluded.updated_at,
      released_at = NULL
  `).run(
    id,
    projectId,
    userId,
    slotId,
    profileId,
    runtimeAgentId,
    sessionKey,
    projectWorkspace,
    leaseUntil,
    now,
    now,
  )
  return getProjectMemberBinding(id, userId)
}

export function getProjectMemberBinding(id, userId = null) {
  if (!id) return null
  const row = userId
    ? db.prepare('SELECT * FROM project_member_bindings WHERE id = ? AND user_id = ?').get(id, userId)
    : db.prepare('SELECT * FROM project_member_bindings WHERE id = ?').get(id)
  if (!row) return null
  return {
    id: row.id,
    projectId: row.project_id,
    userId: row.user_id,
    slotId: row.slot_id,
    profileId: row.profile_id,
    runtimeAgentId: row.runtime_agent_id || null,
    sessionKey: row.session_key || null,
    projectWorkspace: row.project_workspace || null,
    leaseUntil: row.lease_until,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    releasedAt: row.released_at,
  }
}

export function listProjectMemberBindings(projectId, userId) {
  if (!projectId || !userId) return []
  return db.prepare(`
    SELECT id FROM project_member_bindings
    WHERE project_id = ? AND user_id = ?
    ORDER BY created_at ASC
  `).all(projectId, userId).map(row => getProjectMemberBinding(row.id, userId)).filter(Boolean)
}

export function releaseProjectMemberBinding(id, userId) {
  const binding = getProjectMemberBinding(id, userId)
  if (!binding) return null
  const now = Date.now()
  db.prepare(`
    UPDATE project_member_bindings
    SET status = 'released', lease_until = NULL, released_at = ?, updated_at = ?
    WHERE id = ? AND user_id = ?
  `).run(now, now, id, userId)
  return getProjectMemberBinding(id, userId)
}

export function releaseProjectMemberBindings(projectId, userId) {
  if (!projectId || !userId) return 0
  const result = db.prepare(`
    UPDATE project_member_bindings
    SET status = 'released', lease_until = NULL, released_at = ?, updated_at = ?
    WHERE project_id = ? AND user_id = ? AND status != 'released'
  `).run(Date.now(), Date.now(), projectId, userId)
  return result.changes
}
