import { describe, expect, it } from 'vitest'
import db from '../database.js'
import {
  bindAgentProfileToProject,
  findReusableAgentProfile,
  listAgentProfiles,
  releaseProjectMemberBinding,
  upsertAgentProfile,
} from './agent-profile-service.js'

const rollback = Symbol('rollback')

function inRolledBackTransaction(callback) {
  let value
  try {
    db.transaction(() => {
      value = callback()
      throw rollback
    })()
  } catch (error) {
    if (error !== rollback) throw error
  }
  return value
}

describe('agent profile reuse', () => {
  it('finds, leases, and releases a reusable profile without sharing active capacity', () => {
    inRolledBackTransaction(() => {
      db.prepare(`
        INSERT INTO users (id, username, password_hash, role)
        VALUES ('profile-test-user', 'profile-test-user', 'test', 'user')
      `).run()
      const profile = upsertAgentProfile({
        id: 'profile-test',
        userId: 'profile-test-user',
        roleId: 'frontend_engineer',
        name: 'Frontend Agent',
        capabilityTags: ['frontend_implementation'],
        concurrencyLimit: 1,
      })

      expect(findReusableAgentProfile('profile-test-user', {
        roleId: 'frontend_engineer',
        capabilities: ['frontend_implementation'],
      })?.id).toBe(profile.id)

      const binding = bindAgentProfileToProject({
        projectId: 'p-profile-test',
        userId: 'profile-test-user',
        slotId: 'frontend',
        profileId: profile.id,
      })
      expect(findReusableAgentProfile('profile-test-user', {
        roleId: 'frontend_engineer',
        capabilities: ['frontend_implementation'],
      })).toBeNull()

      releaseProjectMemberBinding(binding.id, 'profile-test-user')
      expect(findReusableAgentProfile('profile-test-user', {
        roleId: 'frontend_engineer',
        capabilities: ['frontend_implementation'],
      })?.id).toBe(profile.id)
    })
  })

  it('projects existing non-project user agents into the reusable profile pool', () => {
    inRolledBackTransaction(() => {
      db.prepare(`
        INSERT INTO users (id, username, password_hash, role)
        VALUES ('profile-sync-user', 'profile-sync-user', 'test', 'user')
      `).run()
      db.prepare(`
        INSERT INTO user_agents
          (id, user_id, gateway_agent_id, workspace, name, description, model, category, status)
        VALUES
          ('user-agent-row', 'profile-sync-user', 'frontend-agent', '/profiles/frontend',
           '前端工程师', '负责 Web 页面开发', 'provider/model', 'development', 'active')
      `).run()

      const profiles = listAgentProfiles('profile-sync-user')

      expect(profiles).toHaveLength(1)
      expect(profiles[0]).toMatchObject({
        gatewayAgentId: 'frontend-agent',
        baseWorkspace: '/profiles/frontend',
        roleId: 'frontend_engineer',
        capabilityTags: ['frontend_implementation'],
      })
    })
  })
})
