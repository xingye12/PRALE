import db from '../database.js'
import * as userManager from '../user-manager.js'
import {
  readEarliestEffectiveUserMessage,
  readEarliestEffectiveUserMessages,
} from '../message-store.js'
import {
  normalizeDisplayTitleCandidate,
  resolveSessionDisplayTitle,
  shouldBackfillDisplayTitle,
} from './session-title-service.js'

const KNOWN_EXTERNAL_CHANNELS = new Set([
  'feishu', 'lark', 'wechat', 'dingtalk', 'slack', 'telegram', 'discord', 'whatsapp',
])

const EXTERNAL_SESSION_KINDS = new Set(['private', 'dm', 'direct', 'im', 'group', 'channel', 'thread'])

export function parseExternalSessionKey(sessionKey) {
  if (typeof sessionKey !== 'string') return null

  const parts = sessionKey.split(':')
  if (parts.length < 4 || parts[0] !== 'agent') return null

  const agentId = parts[1] || ''
  const channel = String(parts[2] || '').trim().toLowerCase()
  const explicitKind = String(parts[3] || '').trim().toLowerCase()
  const hasExplicitKind = parts.length >= 5 && EXTERNAL_SESSION_KINDS.has(explicitKind)
  const kind = hasExplicitKind
    ? (explicitKind === 'dm' || explicitKind === 'direct' || explicitKind === 'im' ? 'private' : explicitKind)
    : 'private'
  const peer = (hasExplicitKind ? parts.slice(4) : parts.slice(3)).join(':')

  if (!agentId || !channel || !kind || !peer) return null
  return { agentId, channel, kind, peer }
}

export function isKnownExternalSession(sessionKey) {
  const parsed = parseExternalSessionKey(sessionKey)
  return !!parsed && KNOWN_EXTERNAL_CHANNELS.has(parsed.channel)
}

export function extractExternalMessageContent(message) {
  const content = message?.content
  if (typeof content === 'string') return content.trim()
  if (!Array.isArray(content)) return ''

  return content
    .map((block) => {
      if (!block || typeof block !== 'object') return ''
      if (block.type === 'text') return String(block.text || '')
      return ''
    })
    .filter(Boolean)
    .join('\n')
    .trim()
}

function selectTitleSource(earliestRow, incomingContent) {
  const earliestContent = String(earliestRow?.content || '').trim()
  if (normalizeDisplayTitleCandidate(earliestContent)) return earliestContent
  const incoming = String(incomingContent || '').trim()
  return normalizeDisplayTitleCandidate(incoming) ? incoming : ''
}

function defaultUpsertExternalSessionProjection(input) {
  if (typeof userManager.upsertExternalSessionProjection !== 'function') {
    throw new Error('upsertExternalSessionProjection is not available')
  }
  return userManager.upsertExternalSessionProjection(input)
}

export function createExternalSessionProjectionService(deps = {}) {
  const getOwners = deps.getUserIdsByAgentId || userManager.getUserIdsByAgentId
  const readEarliest = deps.readEarliestEffectiveUserMessage || readEarliestEffectiveUserMessage
  const upsertProjection = deps.upsertExternalSessionProjection || defaultUpsertExternalSessionProjection

  return {
    async projectExternalUserMessage({ sessionKey, message, content, occurredAt }) {
      const parsed = parseExternalSessionKey(sessionKey)
      if (!parsed || !KNOWN_EXTERNAL_CHANNELS.has(parsed.channel)) {
        return { projected: false, reason: 'not-external-session' }
      }
      if (message?.role !== 'user') {
        return { projected: false, reason: 'not-user-message' }
      }

      const incomingContent = String(content || extractExternalMessageContent(message)).trim()
      if (!incomingContent) {
        return { projected: false, reason: 'empty-content' }
      }

      const userIds = getOwners(parsed.agentId)
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return { projected: false, reason: 'missing-owner' }
      }

      const earliestRow = await readEarliest(sessionKey)
      const titleSource = selectTitleSource(earliestRow, incomingContent)
      if (!titleSource) {
        return { projected: false, reason: 'empty-content' }
      }

      const title = resolveSessionDisplayTitle({
        channel: parsed.channel,
        peerProfile: null,
        firstUserMessage: titleSource,
        isGroup: parsed.kind === 'group',
      })

      let titleWritten = false
      for (const userId of userIds) {
        const result = upsertProjection({
          userId,
          sessionKey,
          agentId: parsed.agentId,
          channel: parsed.channel,
          peer: parsed.peer,
          title,
          lastActivity: occurredAt || earliestRow?.msg_timestamp || null,
        })
        titleWritten = titleWritten || !!result?.titleWritten
      }

      return { projected: true, userCount: userIds.length, titleWritten }
    },
  }
}

export const externalSessionProjection = createExternalSessionProjectionService()

export async function backfillExternalSessionTitles() {
  const rows = db.prepare(`
    SELECT id, user_id, session_key, agent_id, channel, peer_id, display_title, label
    FROM user_sessions
    WHERE session_key LIKE 'agent:%'
  `).all()

  const candidates = rows.filter((row) => {
    if (!isKnownExternalSession(row.session_key)) return false
    return shouldBackfillDisplayTitle(row.display_title, row.peer_id) ||
      shouldBackfillDisplayTitle(row.label, row.peer_id)
  })

  if (candidates.length === 0) {
    return { checked: rows.length, repaired: 0, skipped: 0 }
  }

  const messages = await readEarliestEffectiveUserMessages(candidates.map((row) => row.session_key))
  const bySessionKey = new Map(messages.map((row) => [row.session_key, row]))
  let repaired = 0
  let skipped = 0

  for (const row of candidates) {
    const parsed = parseExternalSessionKey(row.session_key)
    const message = bySessionKey.get(row.session_key)
    const content = String(message?.content || '').trim()
    if (!parsed || !content) {
      skipped += 1
      continue
    }

    const title = resolveSessionDisplayTitle({
      channel: parsed.channel,
      peerProfile: null,
      firstUserMessage: content,
      isGroup: parsed.kind === 'group',
    })

    const result = defaultUpsertExternalSessionProjection({
      userId: row.user_id,
      sessionKey: row.session_key,
      agentId: row.agent_id || parsed.agentId,
      channel: row.channel || parsed.channel,
      peer: row.peer_id || parsed.peer,
      title,
      lastActivity: message?.msg_timestamp || null,
    })
    if (result?.titleWritten) repaired += 1
  }

  return { checked: rows.length, repaired, skipped }
}
