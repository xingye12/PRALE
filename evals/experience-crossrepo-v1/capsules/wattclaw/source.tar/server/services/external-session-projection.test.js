import test from 'node:test'
import assert from 'node:assert/strict'
import {
  createExternalSessionProjectionService,
  extractExternalMessageContent,
  isKnownExternalSession,
  parseExternalSessionKey,
} from './external-session-projection.js'

test('parseExternalSessionKey preserves peer colons', () => {
  assert.deepEqual(parseExternalSessionKey('agent:agent-a:feishu:private:ou:abc'), {
    agentId: 'agent-a',
    channel: 'feishu',
    kind: 'private',
    peer: 'ou:abc',
  })
})

test('parseExternalSessionKey supports legacy four-part external keys', () => {
  assert.deepEqual(parseExternalSessionKey('agent:agent-a:feishu:ou:abc'), {
    agentId: 'agent-a',
    channel: 'feishu',
    kind: 'private',
    peer: 'ou:abc',
  })
})

test('parseExternalSessionKey treats dm keys as private peer sessions', () => {
  assert.deepEqual(parseExternalSessionKey('agent:agent-a:feishu:dm:ou_1'), {
    agentId: 'agent-a',
    channel: 'feishu',
    kind: 'private',
    peer: 'ou_1',
  })
})

test('isKnownExternalSession accepts Feishu and Lark only through external channel set', () => {
  assert.equal(isKnownExternalSession('agent:a:feishu:private:ou_1'), true)
  assert.equal(isKnownExternalSession('agent:a:lark:private:ou_1'), true)
  assert.equal(isKnownExternalSession('agent:a:main:session:123'), false)
})

test('extractExternalMessageContent supports strings and text blocks', () => {
  assert.equal(extractExternalMessageContent({ content: '帮我查一下库存' }), '帮我查一下库存')
  assert.equal(
    extractExternalMessageContent({ content: [{ type: 'text', text: '今天产线状态怎么样' }] }),
    '今天产线状态怎么样'
  )
})

test('projectExternalUserMessage writes first-message display title only', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => ({ content: '更早的问题', seq: 1 }),
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  const result = await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '当前消息' },
    content: '当前消息',
    occurredAt: '2026-06-10T00:00:00.000Z',
  })

  assert.deepEqual(result, { projected: true, userCount: 1, titleWritten: true })
  assert.equal(writes[0].title, '飞书 · 更早的问题')
  assert.equal(writes[0].peer, 'ou_1')
})

test('projectExternalUserMessage skips assistant messages and empty content', async () => {
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => null,
    upsertExternalSessionProjection: () => {
      throw new Error('should not write')
    },
  })

  assert.deepEqual(await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'assistant', content: 'ok' },
    content: 'ok',
  }), { projected: false, reason: 'not-user-message' })

  assert.deepEqual(await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '   ' },
    content: '   ',
  }), { projected: false, reason: 'empty-content' })
})

test('projection can rewrite invalid title when an earlier message appears later', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => ({ content: '真正第一条', seq: 1 }),
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  const result = await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '后到的消息' },
    content: '后到的消息',
  })

  assert.deepEqual(result, { projected: true, userCount: 1, titleWritten: true })
  assert.equal(writes[0].title, '飞书 · 真正第一条')
})

test('projection backfills Feishu placeholder titles from earliest user message', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => ({ content: '第一条提问', seq: 1 }),
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  const result = await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '新对话' },
    content: '新对话',
    occurredAt: '2026-06-10T00:00:00.000Z',
  })

  assert.deepEqual(result, { projected: true, userCount: 1, titleWritten: true })
  assert.equal(writes[0].title, '飞书 · 第一条提问')
})

test('projection skips an earliest placeholder message and uses incoming Feishu content', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => ({ content: '新对话', seq: 1 }),
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  const result = await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '帮我检查项目进度' },
    content: '帮我检查项目进度',
  })

  assert.deepEqual(result, { projected: true, userCount: 1, titleWritten: true })
  assert.equal(writes[0].title, '飞书 · 帮我检查项目进度')
})

test('projection treats placeholder display titles as replaceable', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => ({ content: '真正的首条问题', seq: 1 }),
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  const result = await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '新会话' },
    content: '新会话',
    occurredAt: '2026-06-10T00:00:00.000Z',
  })

  assert.deepEqual(result, { projected: true, userCount: 1, titleWritten: true })
  assert.equal(writes[0].title, '飞书 · 真正的首条问题')
})

test('projection upsert contract does not write generated title into label', async () => {
  const writes = []
  const service = createExternalSessionProjectionService({
    getUserIdsByAgentId: () => ['user-1'],
    readEarliestEffectiveUserMessage: async () => null,
    upsertExternalSessionProjection: (input) => {
      writes.push(input)
      return { changed: true, titleWritten: true }
    },
  })

  await service.projectExternalUserMessage({
    sessionKey: 'agent:agent-a:feishu:private:ou_1',
    message: { role: 'user', content: '帮我查一下库存' },
    content: '帮我查一下库存',
  })

  assert.equal(Object.hasOwn(writes[0], 'label'), false)
  assert.equal(writes[0].title, '飞书 · 帮我查一下库存')
})
