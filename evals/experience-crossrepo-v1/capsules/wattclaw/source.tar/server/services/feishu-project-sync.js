import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from 'crypto'
import db from '../database.js'
import { envConfig } from '../core/index.js'

const FEISHU_BASE_URL = 'https://open.feishu.cn'
const TOKEN_CACHE_SKEW_MS = 60_000
const MESSAGE_CACHE_TTL_MS = 10 * 60 * 1000
const MAX_CARD_CONTENT_LENGTH = 12_000

const tokenCache = new Map()
const messageInFlight = new Set()
const recentMessages = new Map()

function credentialKeySource() {
  return String(
    envConfig.FEISHU_BOT_CREDENTIAL_KEY
      || process.env.FEISHU_BOT_CREDENTIAL_KEY
      || envConfig.AUTH_PASSWORD
      || process.env.AUTH_PASSWORD
      || envConfig.OPENCLAW_AUTH_TOKEN
      || process.env.OPENCLAW_AUTH_TOKEN
      || '',
  ).trim()
}

function credentialKey() {
  const source = credentialKeySource()
  if (!source) {
    throw new Error('未配置 FEISHU_BOT_CREDENTIAL_KEY，无法安全保存飞书机器人凭据')
  }
  return createHash('sha256').update(source).digest()
}

export function encryptFeishuSecret(value) {
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', credentialKey(), iv)
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()])
  const tag = cipher.getAuthTag()
  return `v1:${iv.toString('base64')}:${tag.toString('base64')}:${encrypted.toString('base64')}`
}

export function decryptFeishuSecret(value) {
  const [version, ivValue, tagValue, encryptedValue] = String(value || '').split(':')
  if (version !== 'v1' || !ivValue || !tagValue || !encryptedValue) {
    throw new Error('飞书机器人凭据格式无效')
  }
  const decipher = createDecipheriv('aes-256-gcm', credentialKey(), Buffer.from(ivValue, 'base64'))
  decipher.setAuthTag(Buffer.from(tagValue, 'base64'))
  return Buffer.concat([
    decipher.update(Buffer.from(encryptedValue, 'base64')),
    decipher.final(),
  ]).toString('utf8')
}

function parseJson(text, fallback = null) {
  try {
    return JSON.parse(text)
  } catch {
    return fallback
  }
}

function feishuError(body, fallback) {
  const message = typeof body?.msg === 'string'
    ? body.msg
    : typeof body?.error_description === 'string'
      ? body.error_description
      : fallback
  const error = new Error(message)
  if (body?.code !== undefined) error.code = body.code
  return error
}

async function getTenantAccessToken(credentials, fetchImpl = fetch) {
  const secretHash = createHash('sha256').update(credentials.appSecret).digest('hex')
  const cached = tokenCache.get(credentials.appId)
  if (
    cached
    && cached.secretHash === secretHash
    && cached.expiresAt > Date.now() + TOKEN_CACHE_SKEW_MS
  ) {
    return cached.token
  }

  const response = await fetchImpl(`${FEISHU_BASE_URL}/open-apis/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({
      app_id: credentials.appId,
      app_secret: credentials.appSecret,
    }),
  })
  const text = await response.text()
  const body = parseJson(text, {})
  if (!response.ok || !body.tenant_access_token) {
    throw feishuError(body, `获取飞书 tenant_access_token 失败（HTTP ${response.status}）`)
  }

  const expiresIn = Number(body.expire) || 7200
  tokenCache.set(credentials.appId, {
    token: body.tenant_access_token,
    secretHash,
    expiresAt: Date.now() + Math.max(expiresIn - 120, 60) * 1000,
  })
  return body.tenant_access_token
}

async function feishuApi(credentials, path, options = {}) {
  const token = await getTenantAccessToken(credentials, options.fetchImpl)
  const response = await (options.fetchImpl || fetch)(`${FEISHU_BASE_URL}${path}`, {
    method: options.method || 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json; charset=utf-8',
    },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  })
  const text = await response.text()
  const body = parseJson(text, {})
  if (!response.ok || (body.code !== undefined && body.code !== 0)) {
    throw feishuError(body, `飞书 API 请求失败（HTTP ${response.status}）`)
  }
  return body
}

export async function probeFeishuBot(credentials, fetchImpl = fetch) {
  const body = await feishuApi(credentials, '/open-apis/bot/v1/openclaw_bot/ping', {
    method: 'POST',
    body: { needBotInfo: true },
    fetchImpl,
  })
  const info = body.data?.pingBotInfo || body.data?.bot || {}
  return {
    botOpenId: info.botID || info.bot_id || info.open_id || null,
    botName: info.botName || info.bot_name || info.name || null,
  }
}

function getBotRow(userId) {
  return db.prepare('SELECT * FROM user_feishu_bots WHERE user_id = ?').get(userId) || null
}

function credentialsFromRow(row) {
  if (!row) return null
  return {
    appId: row.app_id,
    appSecret: decryptFeishuSecret(row.app_secret_encrypted),
  }
}

function publicBot(row) {
  if (!row) return null
  return {
    appId: row.app_id,
    ownerOpenId: row.owner_open_id,
    botOpenId: row.bot_open_id || null,
    botName: row.bot_name || null,
    status: row.status,
    lastError: row.last_error || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

export function getUserFeishuBot(userId) {
  return publicBot(getBotRow(userId))
}

export async function saveUserFeishuBot(userId, input) {
  const appId = String(input?.appId || '').trim()
  const appSecret = String(input?.appSecret || '').trim()
  const ownerOpenId = String(input?.ownerOpenId || '').trim()
  if (!appId || !appSecret || !ownerOpenId) {
    throw new Error('App ID、App Secret 和用户 OpenID 均为必填项')
  }
  if (!ownerOpenId.startsWith('ou_')) {
    throw new Error('用户 OpenID 格式无效，应以 ou_ 开头')
  }

  const identity = await probeFeishuBot({ appId, appSecret })
  const now = Date.now()
  db.prepare(`
    INSERT INTO user_feishu_bots (
      user_id, app_id, app_secret_encrypted, owner_open_id,
      bot_open_id, bot_name, status, last_error, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'active', NULL, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET
      app_id = excluded.app_id,
      app_secret_encrypted = excluded.app_secret_encrypted,
      owner_open_id = excluded.owner_open_id,
      bot_open_id = excluded.bot_open_id,
      bot_name = excluded.bot_name,
      status = 'active',
      last_error = NULL,
      updated_at = excluded.updated_at
  `).run(
    userId,
    appId,
    encryptFeishuSecret(appSecret),
    ownerOpenId,
    identity.botOpenId,
    identity.botName,
    now,
    now,
  )
  tokenCache.delete(appId)
  return getUserFeishuBot(userId)
}

export async function verifyUserFeishuBot(userId) {
  const row = getBotRow(userId)
  if (!row) return { bound: false, valid: false, bot: null }

  try {
    const identity = await probeFeishuBot(credentialsFromRow(row))
    db.prepare(`
      UPDATE user_feishu_bots
      SET bot_open_id = ?, bot_name = ?, status = 'active', last_error = NULL, updated_at = ?
      WHERE user_id = ?
    `).run(identity.botOpenId, identity.botName, Date.now(), userId)
    return { bound: true, valid: true, bot: getUserFeishuBot(userId) }
  } catch (error) {
    db.prepare(`
      UPDATE user_feishu_bots
      SET status = 'error', last_error = ?, updated_at = ?
      WHERE user_id = ?
    `).run(error.message, Date.now(), userId)
    return { bound: true, valid: false, bot: getUserFeishuBot(userId), error: error.message }
  }
}

export function removeUserFeishuBot(userId) {
  const row = getBotRow(userId)
  const remove = db.transaction(() => {
    db.prepare(`
      UPDATE wattclaw_project_feishu_sync
      SET enabled = 0, last_error = '飞书机器人已解绑', updated_at = ?
      WHERE user_id = ?
    `).run(Date.now(), userId)
    db.prepare('DELETE FROM user_feishu_bots WHERE user_id = ?').run(userId)
  })
  remove()
  if (row?.app_id) tokenCache.delete(row.app_id)
}

export function getFeishuPermissionUrl(appId) {
  if (!appId) return null
  return `${FEISHU_BASE_URL}/app/${encodeURIComponent(appId)}/auth?q=im:chat:create&op_from=openapi&token_type=tenant`
}

function deterministicUuid(value) {
  return createHash('md5').update(value).digest('hex')
}

async function createFeishuProjectChat(credentials, project, ownerOpenId) {
  const body = await feishuApi(credentials, '/open-apis/im/v1/chats?user_id_type=open_id', {
    method: 'POST',
    body: {
      name: `${project.name}项目群`,
      description: project.description || `${project.name}（${project.id}）`,
      owner_id: ownerOpenId,
      user_id_list: [ownerOpenId],
      set_bot_manager: false,
      uuid: deterministicUuid(`project-chat:${project.id}`),
    },
  })
  if (!body.data?.chat_id) throw new Error('飞书创建群聊响应缺少 chat_id')
  return {
    chatId: body.data.chat_id,
    chatName: body.data.name || `${project.name}项目群`,
  }
}

async function sendCard(credentials, chatId, card, uuid) {
  const body = await feishuApi(credentials, '/open-apis/im/v1/messages?receive_id_type=chat_id', {
    method: 'POST',
    body: {
      receive_id: chatId,
      msg_type: 'interactive',
      content: JSON.stringify(card),
      uuid: deterministicUuid(uuid),
    },
  })
  return body.data || null
}

function memberSummary(member) {
  const role = member.role ? ` · ${member.role}` : ''
  return `- **${member.name || member.agentId}${role}**\n  \`${member.agentId}\``
}

function introCard(project) {
  const members = Array.isArray(project.members) ? project.members : []
  const memberContent = members.length > 0
    ? members.map(memberSummary).join('\n')
    : '暂无成员'
  return {
    schema: '2.0',
    config: { wide_screen_mode: true, enable_forward: true },
    header: {
      template: 'blue',
      title: { tag: 'plain_text', content: project.name },
      subtitle: { tag: 'plain_text', content: 'WattClaw 协作项目已启动' },
    },
    body: {
      elements: [
        { tag: 'markdown', content: project.description || '项目团队已开始执行。' },
        { tag: 'hr' },
        { tag: 'markdown', content: memberContent },
      ],
    },
  }
}

function parseMembers(row) {
  const members = parseJson(row?.members_json, [])
  return Array.isArray(members) ? members : []
}

function replaceProjectMembers(projectId, members) {
  db.prepare('DELETE FROM wattclaw_project_feishu_members WHERE project_id = ?').run(projectId)
  const insert = db.prepare(`
    INSERT OR IGNORE INTO wattclaw_project_feishu_members (project_id, agent_id)
    VALUES (?, ?)
  `)
  for (const member of members) {
    const agentId = String(member?.agentId || '').trim()
    if (agentId) insert.run(projectId, agentId)
  }
}

export async function sendWattClawProjectFeishuIntro(project, userId) {
  const binding = db.prepare(`
    SELECT sync.*, bot.app_id, bot.app_secret_encrypted
    FROM wattclaw_project_feishu_sync sync
    JOIN user_feishu_bots bot ON bot.user_id = sync.user_id
    WHERE sync.project_id = ? AND sync.user_id = ? AND sync.enabled = 1
  `).get(project.id, userId)
  if (!binding) return false

  try {
    await sendCard(
      {
        appId: binding.app_id,
        appSecret: decryptFeishuSecret(binding.app_secret_encrypted),
      },
      binding.chat_id,
      introCard(project),
      `project-intro:${project.id}`,
    )
    return true
  } catch (error) {
    db.prepare(`
      UPDATE wattclaw_project_feishu_sync
      SET last_error = ?, updated_at = ?
      WHERE project_id = ?
    `).run(`项目群已创建，但介绍消息发送失败：${error.message}`, Date.now(), project.id)
    return false
  }
}

export async function enableWattClawProjectFeishuSync({
  project,
  userId,
  tenantId,
  sendIntro = true,
}) {
  const existing = db.prepare(`
    SELECT * FROM wattclaw_project_feishu_sync
    WHERE project_id = ? AND user_id = ? AND enabled = 1
  `).get(project.id, userId)
  if (existing) {
    if (sendIntro) await sendWattClawProjectFeishuIntro(project, userId)
    return {
      enabled: true,
      chatId: existing.chat_id,
      chatName: existing.chat_name,
    }
  }

  const botRow = getBotRow(userId)
  if (!botRow) throw new Error('请先绑定你的飞书机器人')
  if (!botRow.owner_open_id) throw new Error('飞书机器人绑定缺少用户 OpenID，请重新绑定')

  const credentials = credentialsFromRow(botRow)
  const chat = await createFeishuProjectChat(credentials, project, botRow.owner_open_id)
  const now = Date.now()
  const members = Array.isArray(project.members) ? project.members : []
  const upsert = db.transaction(() => {
    db.prepare(`
      INSERT INTO wattclaw_project_feishu_sync (
        project_id, user_id, tenant_id, project_name, chat_id, chat_name,
        members_json, enabled, last_error, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?)
      ON CONFLICT(project_id) DO UPDATE SET
        user_id = excluded.user_id,
        tenant_id = excluded.tenant_id,
        project_name = excluded.project_name,
        chat_id = excluded.chat_id,
        chat_name = excluded.chat_name,
        members_json = excluded.members_json,
        enabled = 1,
        last_error = NULL,
        updated_at = excluded.updated_at
    `).run(
      project.id,
      userId,
      tenantId || null,
      project.name,
      chat.chatId,
      chat.chatName,
      JSON.stringify(members),
      now,
      now,
    )
    replaceProjectMembers(project.id, members)
  })
  upsert()

  if (sendIntro) await sendWattClawProjectFeishuIntro(project, userId)

  return { enabled: true, ...chat }
}

export function disableWattClawProjectFeishuSync(projectId, reason = null) {
  db.prepare(`
    UPDATE wattclaw_project_feishu_sync
    SET enabled = 0, last_error = ?, updated_at = ?
    WHERE project_id = ?
  `).run(reason, Date.now(), projectId)
}

export function refreshWattClawProjectFeishuMembers(project) {
  if (!project?.id || !Array.isArray(project.members)) return false
  const existing = db.prepare(`
    SELECT project_id FROM wattclaw_project_feishu_sync
    WHERE project_id = ? AND enabled = 1
  `).get(project.id)
  if (!existing) return false

  const refresh = db.transaction(() => {
    db.prepare(`
      UPDATE wattclaw_project_feishu_sync
      SET project_name = ?, members_json = ?, updated_at = ?
      WHERE project_id = ?
    `).run(project.name || project.id, JSON.stringify(project.members), Date.now(), project.id)
    replaceProjectMembers(project.id, project.members)
  })
  refresh()
  return true
}

function extractText(content) {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
}

function cleanContent(value) {
  return String(value || '')
    .replace(/<relevant-memories>[\s\S]*?<\/relevant-memories>/gi, '')
    .replace(/\n*\s*<team-project-download\b[^>]*\/>\s*$/u, '')
    .trim()
    .slice(0, MAX_CARD_CONTENT_LENGTH)
}

function parseToolArguments(value) {
  if (value && typeof value === 'object') return value
  if (typeof value !== 'string') return null
  return parseJson(value, null)
}

function memberName(members, agentId) {
  const member = members.find(item => item?.agentId === agentId)
  return member?.name || agentId || 'Agent'
}

function headerTemplate(agentId, senderKind) {
  if (senderKind === 'external_user') return 'blue'
  if (agentId.endsWith('-manager')) return 'yellow'
  if (agentId.includes('-worker')) return 'wathet'
  return 'grey'
}

function externalSender(text) {
  const match = text.match(/^Sender \(untrusted metadata\):\s*```json\s*([\s\S]*?)\s*```\s*([\s\S]+)$/u)
  if (!match) return null
  const metadata = parseJson(match[1], {})
  return {
    senderDisplayName: metadata.name || metadata.label || metadata.username || '用户',
    senderId: metadata.id || metadata.username || 'external-user',
    content: cleanContent(match[2]),
  }
}

export function buildWattClawFeishuMessage(payload, binding) {
  const sessionKey = String(payload?.sessionKey || payload?.session_key || payload?.key || '')
  const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
  const message = payload?.message
  if (!agentId || !message?.role) return null

  const members = parseMembers(binding)
  if (message.role === 'user') {
    const text = cleanContent(extractText(message.content))
    if (!text || text.includes('"_isNotification":true') || text.includes('"_isNotification": true')) {
      return null
    }
    const sender = externalSender(text)
    return {
      fromAgentId: sender?.senderId || 'external-user',
      senderDisplayName: sender?.senderDisplayName || '用户',
      senderKind: 'external_user',
      toAgentId: agentId,
      content: sender?.content || text.replace(/^\[[^\]]+\]\s*/u, '').trim(),
      headerTemplate: 'blue',
    }
  }

  if (message.role !== 'assistant' || !Array.isArray(message.content)) return null

  const toolCall = message.content.find(
    block => block?.type === 'toolCall' && block.name === 'wattclaw_team_message_send',
  )
  if (toolCall) {
    const args = parseToolArguments(toolCall.arguments)
    const content = cleanContent(args?.content)
    const fromAgentId = String(args?.from_id || agentId).trim()
    const toAgentId = String(args?.to_id || '').trim()
    if (!content || !fromAgentId || !toAgentId) return null
    return {
      fromAgentId,
      senderDisplayName: memberName(members, fromAgentId),
      senderKind: 'agent',
      toAgentId,
      content,
      headerTemplate: headerTemplate(fromAgentId, 'agent'),
    }
  }

  const content = cleanContent(extractText(message.content))
  if (!content || content === 'NO_REPLY') return null
  return {
    fromAgentId: agentId,
    senderDisplayName: memberName(members, agentId),
    senderKind: 'agent',
    toAgentId: agentId,
    content,
    headerTemplate: headerTemplate(agentId, 'agent'),
  }
}

function messageCard(message, binding) {
  const target = message.fromAgentId === message.toAgentId
    ? ''
    : `发送给 @${memberName(parseMembers(binding), message.toAgentId)}`
  return {
    schema: '2.0',
    config: { wide_screen_mode: true, enable_forward: true },
    header: {
      template: message.headerTemplate,
      title: { tag: 'plain_text', content: message.senderDisplayName.slice(0, 100) },
      subtitle: { tag: 'plain_text', content: target },
    },
    body: { elements: [{ tag: 'markdown', content: message.content }] },
  }
}

function messageDedupeKey(payload, binding, message) {
  const sessionKey = payload?.sessionKey || payload?.session_key || payload?.key || ''
  const messageId = payload?.messageId
    || payload?.message_id
    || payload?.message?.__openclaw?.id
    || payload?.message?.id
    || payload?.message?.responseId
  const sequence = payload?.messageSeq || payload?.message_seq || payload?.message?.__openclaw?.seq || ''
  return [binding.project_id, sessionKey, messageId || sequence || message.content].join(':')
}

function clearExpiredMessageCache() {
  const cutoff = Date.now() - MESSAGE_CACHE_TTL_MS
  for (const [key, createdAt] of recentMessages) {
    if (createdAt < cutoff) recentMessages.delete(key)
  }
}

function projectBindingsForAgent(agentId, tenantId) {
  const rows = db.prepare(`
    SELECT sync.*, bot.app_id, bot.app_secret_encrypted, bot.status AS bot_status
    FROM wattclaw_project_feishu_members member
    JOIN wattclaw_project_feishu_sync sync ON sync.project_id = member.project_id
    JOIN user_feishu_bots bot ON bot.user_id = sync.user_id
    WHERE member.agent_id = ?
      AND sync.enabled = 1
      AND bot.status = 'active'
      AND (? IS NULL OR sync.tenant_id IS NULL OR sync.tenant_id = ?)
  `).all(agentId, tenantId || null, tenantId || null)
  return rows
}

async function deliverProjectMessage(payload, binding) {
  const message = buildWattClawFeishuMessage(payload, binding)
  if (!message?.content) return

  const dedupeKey = messageDedupeKey(payload, binding, message)
  clearExpiredMessageCache()
  if (messageInFlight.has(dedupeKey) || recentMessages.has(dedupeKey)) return
  messageInFlight.add(dedupeKey)

  try {
    await sendCard(
      {
        appId: binding.app_id,
        appSecret: decryptFeishuSecret(binding.app_secret_encrypted),
      },
      binding.chat_id,
      messageCard(message, binding),
      `project-message:${dedupeKey}`,
    )
    const now = Date.now()
    recentMessages.set(dedupeKey, now)
    db.prepare(`
      UPDATE wattclaw_project_feishu_sync
      SET last_sync_at = ?, last_error = NULL, updated_at = ?
      WHERE project_id = ?
    `).run(now, now, binding.project_id)
  } catch (error) {
    db.prepare(`
      UPDATE wattclaw_project_feishu_sync
      SET last_error = ?, updated_at = ?
      WHERE project_id = ?
    `).run(error.message, Date.now(), binding.project_id)
    console.error('[FeishuProjectSync] message delivery failed:', {
      projectId: binding.project_id,
      sessionKey: payload?.sessionKey || payload?.session_key || payload?.key,
      error: error.message,
    })
  } finally {
    messageInFlight.delete(dedupeKey)
  }
}

export async function syncWattClawProjectMessage(payload) {
  const sessionKey = String(payload?.sessionKey || payload?.session_key || payload?.key || '')
  const agentId = sessionKey.match(/^agent:([^:]+):/)?.[1] || ''
  if (!agentId || !payload?.message) return

  const bindings = projectBindingsForAgent(agentId, payload.tenantId)
  await Promise.allSettled(bindings.map(binding => deliverProjectMessage(payload, binding)))
}

export function extractFeishuRegistrationOpenId(result) {
  const userInfo = result?.user_info || result?.userInfo
  if (typeof userInfo === 'string') return userInfo.trim()
  if (!userInfo || typeof userInfo !== 'object') return ''
  return String(userInfo.open_id || userInfo.openId || userInfo.user_open_id || '').trim()
}
