import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  buildWattClawFeishuMessage,
  decryptFeishuSecret,
  encryptFeishuSecret,
  extractFeishuRegistrationOpenId,
  probeFeishuBot,
} from './feishu-project-sync.js'

afterEach(() => {
  delete process.env.FEISHU_BOT_CREDENTIAL_KEY
})

describe('feishu project sync', () => {
  it('encrypts App Secrets without storing plaintext', () => {
    process.env.FEISHU_BOT_CREDENTIAL_KEY = 'test-key-with-at-least-32-characters'
    const encrypted = encryptFeishuSecret('app-secret-value')

    expect(encrypted).not.toContain('app-secret-value')
    expect(decryptFeishuSecret(encrypted)).toBe('app-secret-value')
  })

  it('extracts the owner OpenID from registration responses', () => {
    expect(extractFeishuRegistrationOpenId({ user_info: { open_id: 'ou_owner' } })).toBe('ou_owner')
    expect(extractFeishuRegistrationOpenId({ userInfo: 'ou_string' })).toBe('ou_string')
    expect(extractFeishuRegistrationOpenId({})).toBe('')
  })

  it('validates credentials through the tenant token and bot probe APIs', async () => {
    const fetchImpl = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({
        code: 0,
        tenant_access_token: 'tenant-token',
        expire: 7200,
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({
        code: 0,
        data: { pingBotInfo: { botID: 'ou_bot', botName: 'Project Bot' } },
      }), { status: 200 }))

    await expect(probeFeishuBot({
      appId: 'cli_test_probe',
      appSecret: 'secret',
    }, fetchImpl)).resolves.toEqual({
      botOpenId: 'ou_bot',
      botName: 'Project Bot',
    })
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('normalizes project user and agent messages into Feishu cards', () => {
    const binding = {
      members_json: JSON.stringify([
        { agentId: 'p-test-manager', name: '项目经理' },
        { agentId: 'p-test-worker1', name: '研究员' },
      ]),
    }

    expect(buildWattClawFeishuMessage({
      sessionKey: 'agent:p-test-manager:main',
      message: {
        role: 'user',
        content: 'Sender (untrusted metadata):\n```json\n{"name":"张三","id":"user-1"}\n```\n请汇报当前进度',
      },
    }, binding)).toMatchObject({
      senderDisplayName: '张三',
      senderKind: 'external_user',
      toAgentId: 'p-test-manager',
      content: '请汇报当前进度',
    })

    expect(buildWattClawFeishuMessage({
      sessionKey: 'agent:p-test-worker1:main',
      message: {
        role: 'assistant',
        content: [{
          type: 'toolCall',
          name: 'wattclaw_team_message_send',
          arguments: {
            from_id: 'p-test-worker1',
            to_id: 'p-test-manager',
            content: '调研已完成 80%',
          },
        }],
      },
    }, binding)).toMatchObject({
      senderDisplayName: '研究员',
      fromAgentId: 'p-test-worker1',
      toAgentId: 'p-test-manager',
      content: '调研已完成 80%',
    })
  })
})
