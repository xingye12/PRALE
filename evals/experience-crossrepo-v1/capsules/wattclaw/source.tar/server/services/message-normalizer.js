const TIME_FIELDS = ['timestamp', 'createdAt', 'created_at', 'ts', 'time', 'msgTimestamp', 'msg_timestamp']

function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null
}

export function normalizeTimestamp(value) {
  if (value == null || value === '') return null
  const numeric = Number(value)
  const date = Number.isFinite(numeric) && numeric > 0
    ? new Date(numeric > 1e12 ? numeric : numeric * 1000)
    : new Date(value)
  return Number.isFinite(date.getTime()) ? date.toISOString() : null
}

export function extractOccurredAt(raw) {
  const row = asRecord(raw)
  if (!row) return null
  for (const field of TIME_FIELDS) {
    const timestamp = normalizeTimestamp(row[field])
    if (timestamp) return timestamp
  }
  return null
}

export function normalizeMessageEnvelope({ sessionKey, message, seq, msgId, role, content, occurredAt }) {
  const raw = asRecord(message) || {}
  const normalizedRole = role || raw.role || raw.type || 'unknown'
  const normalizedContent = content != null
    ? content
    : raw.content != null
      ? raw.content
      : ''
  const normalizedOccurredAt = normalizeTimestamp(occurredAt) || extractOccurredAt(raw)

  return {
    id: msgId || raw.id || raw.msg_id || null,
    sessionKey,
    seq: seq ?? raw.seq ?? raw.messageSeq ?? null,
    role: normalizedRole,
    content: normalizedContent,
    occurredAt: normalizedOccurredAt,
    raw: message || raw,
    model: raw.model || null,
  }
}
