const DEFAULT_RAGFLOW_BASE_URL = 'http://localhost:9380'
const RAGFLOW_TIMEOUT_MS = 60_000

export class RagflowConfigError extends Error {
  constructor(message) {
    super(message)
    this.name = 'RagflowConfigError'
    this.statusCode = 503
  }
}

export function isRagflowConfigError(error) {
  return error?.name === 'RagflowConfigError'
}

function getBaseUrl() {
  return (process.env.RAGFLOW_BASE_URL || DEFAULT_RAGFLOW_BASE_URL).replace(/\/+$/, '')
}

function getApiKey() {
  return process.env.RAGFLOW_API_KEY || ''
}

function buildUrl(path, query = {}) {
  const url = new URL(`${getBaseUrl()}/api/v1${path}`)
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value))
    }
  }
  return url
}

async function readResponse(response) {
  const text = await response.text()
  if (!text) return {}
  try {
    return JSON.parse(text)
  } catch {
    return { raw: text }
  }
}

function extractData(payload) {
  if (payload && typeof payload === 'object' && 'data' in payload) return payload.data
  return payload
}

async function ragflowRequest(path, options = {}) {
  const apiKey = getApiKey()
  if (!apiKey) {
    throw new RagflowConfigError('RAGFLOW_API_KEY is not configured. Set RAGFLOW_API_KEY in .env and restart the web container.')
  }

  const controller = new AbortController()
  const method = options.method || 'GET'
  const startedAt = Date.now()
  console.log('[RAGFlow] request start:', { method, path })
  const timer = setTimeout(() => controller.abort(), options.timeoutMs || RAGFLOW_TIMEOUT_MS)
  try {
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      ...(options.headers || {}),
    }
    const response = await fetch(buildUrl(path, options.query), {
      ...options,
      headers,
      signal: controller.signal,
    })
    const payload = await readResponse(response)
    const responseCode = payload?.code
    const hasRagflowError = responseCode !== undefined && Number(responseCode) !== 0
    if (!response.ok || hasRagflowError) {
      const message = payload?.message || payload?.error || payload?.raw || `RAGFlow HTTP ${response.status}`
      throw new Error(message)
    }
    const data = extractData(payload)
    console.log('[RAGFlow] request success:', {
      method,
      path,
      status: response.status,
      latencyMs: Date.now() - startedAt,
      shape: Array.isArray(data) ? `array:${data.length}` : Object.keys(data || {}).slice(0, 12),
    })
    return data
  } catch (error) {
    console.error('[RAGFlow] request failed:', {
      method,
      path,
      latencyMs: Date.now() - startedAt,
      error: error instanceof Error ? error.message : String(error),
    })
    throw error
  } finally {
    clearTimeout(timer)
  }
}

function normalizeList(data) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.items)) return data.items
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.datasets)) return data.datasets
  if (Array.isArray(data?.documents)) return data.documents
  if (Array.isArray(data?.docs)) return data.docs
  if (Array.isArray(data?.kbs)) return data.kbs
  return []
}

function flattenModelValues(value, result = []) {
  if (Array.isArray(value)) {
    for (const item of value) flattenModelValues(item, result)
    return result
  }
  if (!value || typeof value !== 'object') return result
  if (value.name || value.id || value.model_name) {
    result.push(value)
  }
  for (const child of Object.values(value)) {
    if (child && typeof child === 'object') flattenModelValues(child, result)
  }
  return result
}

export async function listRagflowDatasets(query = {}) {
  const data = await ragflowRequest('/datasets', {
    method: 'GET',
    query: {
      page: query.page || 1,
      page_size: query.pageSize || 100,
      orderby: query.orderby || 'create_time',
      desc: query.desc ?? true,
    },
  })
  return normalizeList(data)
}

export async function listRagflowEmbeddingModels() {
  const data = await ragflowRequest('/models', { method: 'GET' })
  const models = normalizeList(data).length > 0 ? normalizeList(data) : flattenModelValues(data)
  return models
    .filter(model => {
      const type = String(model?.type || model?.model_type || model?.category || '').toLowerCase()
      return !type || type.includes('embedding') || type.includes('embed')
    })
    .map(model => {
      const name = model?.name || model?.model_name || model?.id || ''
      const instanceName = model?.instance_name || model?.instanceName || ''
      const providerName = model?.provider_name || model?.providerName || model?.provider || ''
      const id = name && instanceName && providerName ? `${name}@${instanceName}@${providerName}` : model?.id || name
      return {
        id,
        name,
        provider: providerName,
        raw: model,
      }
    })
    .filter(model => model.id)
}

export async function createRagflowDataset(payload) {
  return ragflowRequest('/datasets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
}

export async function deleteRagflowDatasets(ids) {
  return ragflowRequest('/datasets', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids }),
  })
}

export async function listRagflowDocuments(datasetId, query = {}) {
  const data = await ragflowRequest(`/datasets/${encodeURIComponent(datasetId)}/documents`, {
    method: 'GET',
    query: {
      page: query.page || 1,
      page_size: query.pageSize || 100,
      orderby: query.orderby || 'create_time',
      desc: query.desc ?? true,
    },
  })
  const documents = normalizeList(data)
  console.log('[RAGFlow] documents normalized:', { datasetId, count: documents.length })
  return documents
}

export async function uploadRagflowDocuments(datasetId, files) {
  const form = new FormData()
  for (const file of files) {
    const blob = new Blob([file.buffer], { type: file.mimetype || 'application/octet-stream' })
    form.append('file', blob, file.originalname || file.filename || 'document')
  }
  return ragflowRequest(`/datasets/${encodeURIComponent(datasetId)}/documents`, {
    method: 'POST',
    body: form,
    timeoutMs: 180_000,
  })
}

export async function deleteRagflowDocuments(datasetId, ids) {
  return ragflowRequest(`/datasets/${encodeURIComponent(datasetId)}/documents`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids }),
  })
}

export async function parseRagflowDocuments(datasetId, ids) {
  return ragflowRequest(`/datasets/${encodeURIComponent(datasetId)}/documents/parse`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ document_ids: ids }),
  })
}
