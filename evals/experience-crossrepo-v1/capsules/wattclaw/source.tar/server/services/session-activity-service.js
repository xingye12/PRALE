import db from '../database.js'
import { readSessionMaxMessageTimestamps } from '../message-store.js'
import { normalizeTimestamp } from './message-normalizer.js'
import { stripGeneratedTitleSuffix } from './session-title-service.js'

function toMillis(isoString) {
  const time = new Date(isoString).getTime()
  return Number.isFinite(time) ? time : null
}

export function advanceSessionLastMessageAt(sessionKey, occurredAt) {
  if (!sessionKey) return { changed: false, reason: 'missing-session-key' }

  const normalized = normalizeTimestamp(occurredAt)
  if (!normalized) return { changed: false, reason: 'missing-occurred-at' }

  const nextMs = toMillis(normalized)
  if (nextMs == null) return { changed: false, reason: 'invalid-occurred-at' }

  const rows = db.prepare(`
    SELECT id, last_message_at
    FROM user_sessions
    WHERE session_key = ?
  `).all(sessionKey)

  let changed = 0
  const update = db.prepare(`
    UPDATE user_sessions
    SET last_message_at = ?, updated_at = ?
    WHERE id = ?
      AND (last_message_at IS NULL OR last_message_at < ?)
  `)

  const now = Date.now()
  const tx = db.transaction((items) => {
    for (const row of items) {
      const result = update.run(nextMs, now, row.id, nextMs)
      changed += result.changes
    }
  })

  tx(rows)

  return { changed: changed > 0, rows: changed, occurredAt: normalized }
}

export function recomputeSessionLastMessageAt(sessionKey, occurredAtValues = []) {
  const timestamps = occurredAtValues
    .map(normalizeTimestamp)
    .filter(Boolean)
    .map((value) => ({ iso: value, ms: toMillis(value) }))
    .filter((item) => item.ms != null)

  if (timestamps.length === 0) return { changed: false, reason: 'no-real-message-time' }

  timestamps.sort((a, b) => b.ms - a.ms)
  return setSessionLastMessageAt(sessionKey, timestamps[0].ms, timestamps[0].iso)
}

function setSessionLastMessageAt(sessionKey, nextMs, normalizedIso) {
  if (!sessionKey) return { changed: false, reason: 'missing-session-key' }
  if (!Number.isFinite(nextMs) || nextMs <= 0) return { changed: false, reason: 'invalid-occurred-at' }

  const rows = db.prepare(`
    SELECT id, last_message_at
    FROM user_sessions
    WHERE session_key = ?
  `).all(sessionKey)

  let changed = 0
  const update = db.prepare(`
    UPDATE user_sessions
    SET last_message_at = ?, updated_at = ?
    WHERE id = ?
      AND (last_message_at IS NULL OR last_message_at < ?)
  `)

  const now = Date.now()
  const tx = db.transaction((items) => {
    for (const row of items) {
      changed += update.run(nextMs, now, row.id, nextMs).changes
    }
  })

  tx(rows)

  return { changed: changed > 0, rows: changed, occurredAt: normalizedIso }
}

export function cleanGeneratedSessionTitles() {
  const rows = db.prepare(`
    SELECT id, label, display_title
    FROM user_sessions
    WHERE label LIKE '%-%' OR display_title LIKE '%-%'
  `).all()

  let changed = 0
  const update = db.prepare(`
    UPDATE user_sessions
    SET label = ?, display_title = ?, updated_at = ?
    WHERE id = ?
  `)
  const now = Date.now()
  const tx = db.transaction((items) => {
    for (const row of items) {
      const label = row.label == null ? null : stripGeneratedTitleSuffix(row.label)
      const displayTitle = row.display_title == null ? null : stripGeneratedTitleSuffix(row.display_title)
      if (label === row.label && displayTitle === row.display_title) continue
      changed += update.run(label, displayTitle, now, row.id).changes
    }
  })

  tx(rows)
  return { changed }
}

export async function backfillLegacySessionLastMessageAt() {
  const rows = db.prepare(`
    SELECT DISTINCT session_key
    FROM user_sessions
    WHERE session_key IS NOT NULL AND session_key != ''
  `).all()
  const sessionKeys = rows.map((row) => row.session_key)
  const timestamps = await readSessionMaxMessageTimestamps(sessionKeys)
  if (timestamps.length === 0) return { changed: 0, scanned: sessionKeys.length }

  let changed = 0
  const now = Date.now()
  const update = db.prepare(`
    UPDATE user_sessions
    SET last_message_at = ?, updated_at = ?
    WHERE session_key = ?
      AND (last_message_at IS NULL OR last_message_at < ?)
  `)
  const tx = db.transaction((items) => {
    for (const item of items) {
      const normalized = normalizeTimestamp(item.last_message_at)
      if (!normalized) continue
      const millis = toMillis(normalized)
      if (millis == null) continue
      changed += update.run(millis, now, item.session_key, millis).changes
    }
  })

  tx(timestamps)
  return { changed, scanned: sessionKeys.length }
}

export async function repairSessionLastMessageAtFromStore(sessionKeys = []) {
  const keys = [...new Set(sessionKeys.filter((key) => typeof key === 'string' && key.trim()))]
  if (keys.length === 0) return { changed: 0, scanned: 0 }

  const timestamps = await readSessionMaxMessageTimestamps(keys)
  if (timestamps.length === 0) return { changed: 0, scanned: keys.length }

  let changed = 0
  const now = Date.now()
  const update = db.prepare(`
    UPDATE user_sessions
    SET last_message_at = ?, updated_at = ?
    WHERE session_key = ?
      AND (last_message_at IS NULL OR last_message_at < ?)
  `)
  const tx = db.transaction((items) => {
    for (const item of items) {
      const normalized = normalizeTimestamp(item.last_message_at)
      if (!normalized) continue
      const millis = toMillis(normalized)
      if (millis == null) continue
      changed += update.run(millis, now, item.session_key, millis).changes
    }
  })

  tx(timestamps)
  return { changed, scanned: keys.length, timestamps }
}

export async function repairSessionTitleAndActivitySemantics() {
  const titleResult = cleanGeneratedSessionTitles()
  const activityResult = await backfillLegacySessionLastMessageAt()
  return {
    titlesChanged: titleResult.changed,
    lastMessageAtChanged: activityResult.changed,
    sessionsScanned: activityResult.scanned,
  }
}
