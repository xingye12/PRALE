const CHANNEL_LABELS = {
  feishu: '飞书',
  lark: '飞书',
  qqbot: 'QQ Bot',
  qq: 'QQ',
  telegram: 'Telegram',
  whatsapp: 'WhatsApp',
  discord: 'Discord',
  slack: 'Slack',
  main: '在线对话',
  webchat: '在线对话',
}

// 内部 web 渠道（PC + 手机）标题不加前缀，仅显示首条消息内容
const INTERNAL_WEB_CHANNELS = new Set(['main', 'webchat'])

const INTERNAL_PEER_PATTERNS = [
  /^ou_[a-z0-9_-]+$/i,
  /^oc_[a-z0-9_-]+$/i,
  /^on_[a-z0-9_-]+$/i,
  /^chat_[a-z0-9_-]+$/i,
]

const MEANINGLESS_TITLE_KEYS = new Set([
  '',
  'openclaw web backend',
  'main',
  '新对话',
  '新会话',
  '新對話',
  '新會話',
  'new chat',
  'new conversation',
  'new session',
])

const GENERATED_TITLE_SUFFIX_RE = /^(.+)-(\d{10}|\d{13})$/
const MIN_GENERATED_TITLE_TIME = Date.UTC(2020, 0, 1)
const MAX_GENERATED_TITLE_TIME_DRIFT_MS = 366 * 24 * 60 * 60 * 1000

function normalizeChannel(channel) {
  return String(channel || '').trim().toLowerCase()
}

function toGeneratedTitleTime(value) {
  const numeric = Number(value)
  if (!Number.isFinite(numeric) || numeric <= 0) return null
  const millis = value.length === 10 ? numeric * 1000 : numeric
  const max = Date.now() + MAX_GENERATED_TITLE_TIME_DRIFT_MS
  return millis >= MIN_GENERATED_TITLE_TIME && millis <= max ? millis : null
}

function normalizeTitleKey(value) {
  return String(value || '').trim().toLowerCase()
}

function extractTitleCore(value) {
  const title = stripGeneratedTitleSuffix(value)
  const segments = title.split(' 路 ')
  const core = (segments[segments.length - 1] || '').trim()
  return core || title
}

function isPlaceholderDisplayTitle(value) {
  const core = extractTitleCore(value)
  const key = normalizeTitleKey(core)
  return !key || MEANINGLESS_TITLE_KEYS.has(key) || isInternalPeerId(core)
}

export function stripGeneratedTitleSuffix(value) {
  const title = String(value || '').trim()
  const match = title.match(GENERATED_TITLE_SUFFIX_RE)
  if (!match) return title

  const baseTitle = match[1]?.trim() || ''
  const suffixTime = toGeneratedTitleTime(match[2] || '')
  return baseTitle && suffixTime != null ? baseTitle : title
}

export function isGeneratedTitlePolluted(value) {
  return stripGeneratedTitleSuffix(value) !== String(value || '').trim()
}

export function normalizeDisplayTitleCandidate(value) {
  const title = stripGeneratedTitleSuffix(value)
  if (!title || isPlaceholderDisplayTitle(title)) return null
  return title
}

export function getChannelLabel(channel) {
  const key = normalizeChannel(channel)
  return CHANNEL_LABELS[key] || channel || '会话'
}

export function isInternalPeerId(value) {
  const text = String(value || '').trim()
  if (!text) return false
  return INTERNAL_PEER_PATTERNS.some((pattern) => pattern.test(text))
}

export function summarizeMessage(content) {
  const text = String(content || '')
    .replace(/^\[[^\]]+\]\s*/, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (!text) return ''
  return text.length > 32 ? `${text.slice(0, 32)}…` : text
}

export function shouldBackfillDisplayTitle(existingTitle, peerId) {
  const title = String(existingTitle || '').trim()
  return isPlaceholderDisplayTitle(title) ||
    isGeneratedTitlePolluted(title) ||
    hasLegacyWebChannelPrefix(title) ||
    title === String(peerId || '').trim()
}

// 识别旧版「在线对话 · 摘要」或「uuid · 摘要」前缀标题，需重填为纯摘要（飞书等外部前缀不误伤）
function hasLegacyWebChannelPrefix(title) {
  const text = String(title || '').trim()
  const idx = text.indexOf(' · ')
  if (idx <= 0) return false
  const prefix = text.slice(0, idx).trim()
  if (prefix === CHANNEL_LABELS.main || prefix === CHANNEL_LABELS.webchat) return true
  return /^[a-z0-9]{4,}-[a-z0-9]{4,}$/i.test(prefix)
}

export function resolveSessionDisplayTitle({ channel, peerProfile, firstUserMessage, isGroup = false }) {
  const isInternal = INTERNAL_WEB_CHANNELS.has(normalizeChannel(channel))
  const channelLabel = getChannelLabel(channel)
  // 内部 web 渠道（PC + 手机）不加前缀，仅首条消息；外部 im（飞书等）才拼「渠道 · 」
  const prefix = isInternal ? '' : `${channelLabel} · `

  const profileName = peerProfile?.groupName || peerProfile?.displayName || ''
  if (profileName && !isInternalPeerId(profileName)) {
    return `${prefix}${profileName}`
  }

  const summary = summarizeMessage(firstUserMessage)
  if (summary && !isInternalPeerId(summary)) {
    return `${prefix}${summary}`
  }

  // 内部 web 无有效摘要返回空（前端用「新对话」占位）；外部 im 返回渠道群聊/私聊
  return isInternal ? '' : (isGroup ? `${channelLabel}群聊` : `${channelLabel}私聊`)
}
