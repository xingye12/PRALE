import { createHash, randomUUID } from 'crypto'
import db from '../database.js'

export const DEFAULT_TEAM_TEMPLATES = [
  {
    id: 'web-product-delivery',
    version: '1.0.0',
    scope: 'global',
    name: 'Web 产品交付团队',
    description: '适合网站、Web 应用和 MVP 产品的需求分析、设计、开发与验收。',
    intent: {
      required: ['web_app'],
      preferred: ['mvp', 'frontend', 'product'],
      excluded: ['video_only'],
    },
    capabilities: [
      'requirements_analysis',
      'ux_design',
      'frontend_implementation',
      'qa_validation',
    ],
    slots: [
      {
        id: 'manager',
        roleId: 'project_manager',
        count: 1,
        required: true,
        selector: { capabilities: ['planning', 'delegation'] },
        reusePolicy: 'profile',
      },
      {
        id: 'product',
        roleId: 'product_analyst',
        count: 1,
        required: true,
        selector: { capabilities: ['requirements_analysis'] },
        reusePolicy: 'profile',
      },
      {
        id: 'frontend',
        roleId: 'frontend_engineer',
        count: 1,
        required: true,
        selector: { capabilities: ['frontend_implementation'] },
        skills: ['vite-react-tailwind'],
        reusePolicy: 'profile',
      },
      {
        id: 'qa',
        roleId: 'qa_engineer',
        count: 1,
        required: false,
        selector: { capabilities: ['qa_validation'] },
        reusePolicy: 'profile',
      },
    ],
    workflow: {
      stages: ['requirements', 'design', 'implementation', 'validation'],
      handoffs: [
        ['requirements', 'design'],
        ['design', 'implementation'],
        ['implementation', 'validation'],
      ],
    },
    constraints: { maxMembers: 5, requiresIsolation: true },
    qualityGate: { reviewRequired: true },
    status: 'active',
  },
  {
    id: 'content-campaign',
    version: '1.0.0',
    scope: 'global',
    name: '内容营销团队',
    description: '适合营销活动、品牌内容、社交媒体和图文内容生产。',
    intent: {
      required: ['content_campaign'],
      preferred: ['marketing', 'copywriting', 'social_media'],
      excluded: ['web_app_only'],
    },
    capabilities: ['content_strategy', 'copywriting', 'visual_design', 'content_review'],
    slots: [
      {
        id: 'manager',
        roleId: 'project_manager',
        count: 1,
        required: true,
        selector: { capabilities: ['planning', 'delegation'] },
        reusePolicy: 'profile',
      },
      {
        id: 'strategist',
        roleId: 'content_strategist',
        count: 1,
        required: true,
        selector: { capabilities: ['content_strategy'] },
        reusePolicy: 'profile',
      },
      {
        id: 'writer',
        roleId: 'copywriter',
        count: 1,
        required: true,
        selector: { capabilities: ['copywriting'] },
        reusePolicy: 'profile',
      },
      {
        id: 'designer',
        roleId: 'visual_designer',
        count: 1,
        required: false,
        selector: { capabilities: ['visual_design'] },
        reusePolicy: 'profile',
      },
    ],
    workflow: {
      stages: ['strategy', 'draft', 'visuals', 'review'],
      handoffs: [
        ['strategy', 'draft'],
        ['draft', 'visuals'],
        ['visuals', 'review'],
      ],
    },
    constraints: { maxMembers: 5, requiresIsolation: true },
    qualityGate: { reviewRequired: true },
    status: 'active',
  },
  {
    id: 'data-insight',
    version: '1.0.0',
    scope: 'global',
    name: '数据分析团队',
    description: '适合数据清洗、统计分析、可视化和分析报告。',
    intent: {
      required: ['data_analysis'],
      preferred: ['analytics', 'dashboard', 'report'],
      excluded: [],
    },
    capabilities: ['data_collection', 'data_analysis', 'data_visualization', 'insight_review'],
    slots: [
      {
        id: 'manager',
        roleId: 'project_manager',
        count: 1,
        required: true,
        selector: { capabilities: ['planning', 'delegation'] },
        reusePolicy: 'profile',
      },
      {
        id: 'analyst',
        roleId: 'data_analyst',
        count: 1,
        required: true,
        selector: { capabilities: ['data_analysis'] },
        reusePolicy: 'profile',
      },
      {
        id: 'reviewer',
        roleId: 'insight_reviewer',
        count: 1,
        required: false,
        selector: { capabilities: ['insight_review'] },
        reusePolicy: 'profile',
      },
    ],
    workflow: {
      stages: ['collection', 'analysis', 'visualization', 'review'],
      handoffs: [
        ['collection', 'analysis'],
        ['analysis', 'visualization'],
        ['visualization', 'review'],
      ],
    },
    constraints: { maxMembers: 4, requiresIsolation: true },
    qualityGate: { reviewRequired: true },
    status: 'active',
  },
]

const SIGNALS = [
  { tag: 'web_app', terms: ['web', 'website', '网页', '网站', '前端', 'react', 'vue', '小程序', '落地页', 'mvp'] },
  { tag: 'content_campaign', terms: ['营销', '品牌内容', '内容运营', '社交媒体', '公众号', '小红书', '文案', '宣传'] },
  { tag: 'data_analysis', terms: ['数据分析', '数据清洗', '数据报表', 'dashboard', '可视化', '统计', '指标分析', '数据洞察'] },
  { tag: 'video_production', terms: ['视频', '短片', '剪辑', '分镜', '视频生成'] },
  { tag: 'mvp', terms: ['mvp', '最小可行', '原型', '快速上线'] },
  { tag: 'frontend', terms: ['前端', '页面', '界面', '组件', 'react', 'vue'] },
  { tag: 'product', terms: ['产品', '需求', 'prd', '用户故事', '功能规划'] },
  { tag: 'marketing', terms: ['营销', '投放', '品牌', '增长', '推广'] },
  { tag: 'copywriting', terms: ['文案', '文章', '公众号', '宣传稿', '广告语'] },
  { tag: 'social_media', terms: ['社交媒体', '小红书', '抖音', '公众号', '微博'] },
  { tag: 'analytics', terms: ['分析', '指标', '报表', 'dashboard', '洞察'] },
  { tag: 'report', terms: ['报告', '汇报', '分析报告'] },
]

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

export function readProjectCollaborationSettings(project) {
  const draftSuggestion = project?.draftSuggestion && typeof project.draftSuggestion === 'object'
    ? project.draftSuggestion
    : {}
  const settings = draftSuggestion.collaborationSettings
    && typeof draftSuggestion.collaborationSettings === 'object'
    ? draftSuggestion.collaborationSettings
    : {}
  return {
    teamCreationMode: settings.teamCreationMode === 'manager' ? 'manager' : 'template',
    captureTeamTemplate: settings.captureTeamTemplate !== false,
  }
}

function asString(value) {
  return typeof value === 'string' ? value.trim() : ''
}

function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(asString).filter(Boolean))]
}

function includesSignal(text, term) {
  return text.includes(term.toLowerCase())
}

export function normalizeIntent(input) {
  const prompt = typeof input === 'string'
    ? input.trim()
    : asString(input?.prompt || input?.description || input?.name)
  const text = prompt.toLowerCase()
  const tags = []
  for (const signal of SIGNALS) {
    if (signal.terms.some(term => includesSignal(text, term))) tags.push(signal.tag)
  }

  const capabilities = new Set(['planning', 'delegation'])
  if (tags.includes('web_app')) {
    capabilities.add('requirements_analysis')
    capabilities.add('ux_design')
    capabilities.add('frontend_implementation')
    capabilities.add('qa_validation')
  }
  if (tags.includes('content_campaign')) {
    capabilities.add('content_strategy')
    capabilities.add('copywriting')
    capabilities.add('visual_design')
    capabilities.add('content_review')
  }
  if (tags.includes('data_analysis')) {
    capabilities.add('data_collection')
    capabilities.add('data_analysis')
    capabilities.add('data_visualization')
    capabilities.add('insight_review')
  }
  if (tags.includes('video_production')) {
    capabilities.add('video_production')
    capabilities.add('video_editing')
  }

  return {
    prompt,
    tags: uniqueStrings(tags),
    capabilities: [...capabilities],
    deliverables: [
      ...(tags.includes('web_app') ? ['web_application'] : []),
      ...(tags.includes('content_campaign') ? ['campaign_content'] : []),
      ...(tags.includes('data_analysis') ? ['analysis_report'] : []),
      ...(tags.includes('video_production') ? ['video_asset'] : []),
    ],
  }
}

function normalizedTemplate(template) {
  const source = template && typeof template === 'object' ? template : {}
  const id = asString(source.id || source.templateId)
  const version = asString(source.version) || '1.0.0'
  return {
    ...clone(source),
    id,
    version,
    scope: asString(source.scope) || 'global',
    name: asString(source.name) || id,
    description: asString(source.description),
    intent: {
      required: uniqueStrings(source.intent?.required),
      preferred: uniqueStrings(source.intent?.preferred),
      excluded: uniqueStrings(source.intent?.excluded),
    },
    capabilities: uniqueStrings(source.capabilities),
    slots: Array.isArray(source.slots) ? source.slots : [],
    status: asString(source.status) || 'active',
  }
}

export function validateTeamTemplate(template) {
  const normalized = normalizedTemplate(template)
  if (!normalized.id) throw new Error('Team template id is required')
  if (!normalized.name) throw new Error('Team template name is required')
  if (normalized.slots.length === 0) throw new Error('Team template must define at least one slot')
  const slotIds = normalized.slots.map(slot => asString(slot?.id)).filter(Boolean)
  if (new Set(slotIds).size !== slotIds.length) throw new Error('Team template slot ids must be unique')
  return normalized
}

function overlap(left, right) {
  const a = new Set(left)
  const b = new Set(right)
  if (a.size === 0 || b.size === 0) return 0
  return [...a].filter(item => b.has(item)).length / Math.max(a.size, b.size)
}

function coverage(need, available) {
  const required = new Set(need)
  if (required.size === 0) return 0
  const source = new Set(available)
  return [...required].filter(item => source.has(item)).length / required.size
}

function comparableOverlap(left, right) {
  if (left.length === 0 && right.length === 0) return 1
  return overlap(left, right)
}

function scoreTemplate(template, intent) {
  const required = template.intent.required
  const excluded = template.intent.excluded
  if (excluded.some(tag => intent.tags.includes(tag))) return { score: 0, reasons: ['命中模板排除条件'] }
  if (required.length > 0 && !required.every(tag => intent.tags.includes(tag))) {
    return { score: 0, reasons: ['未满足模板的必需意图标签'] }
  }

  const preferredScore = overlap(template.intent.preferred, intent.tags)
  const intentScore = required.length > 0
    ? 0.75 + preferredScore * 0.25
    : preferredScore
  const capabilityScore = coverage(template.capabilities, intent.capabilities)
  const deliverableScore = template.capabilities.some(capability =>
    intent.capabilities.includes(capability)
  ) ? Math.min(capabilityScore + 0.2, 1) : capabilityScore
  const score = Math.min(1, intentScore * 0.55 + capabilityScore * 0.3 + deliverableScore * 0.15)
  const reasons = []
  if (intentScore > 0) reasons.push('任务意图与模板领域匹配')
  if (capabilityScore > 0) reasons.push(`覆盖 ${Math.round(capabilityScore * 100)}% 核心能力`)
  if (template.slots.length > 0) reasons.push(`包含 ${template.slots.length} 个角色槽位`)
  return { score: Number(score.toFixed(4)), reasons }
}

function decisionForScore(score) {
  if (score >= 0.85) return 'auto_apply'
  if (score >= 0.65) return 'recommend'
  return 'fresh_plan'
}

export function matchTeamTemplates(input, templates = DEFAULT_TEAM_TEMPLATES) {
  const normalizedIntent = normalizeIntent(input)
  const candidates = templates
    .map(item => normalizedTemplate(item))
    .filter(template => template.id && template.status === 'active')
    .map(template => {
      const result = scoreTemplate(template, normalizedIntent)
      return {
        templateId: template.id,
        version: template.version,
        name: template.name,
        description: template.description,
        score: result.score,
        reasons: result.reasons,
        template,
      }
    })
    .filter(candidate => candidate.score > 0)
    .sort((left, right) => right.score - left.score)

  const best = candidates[0] || null
  const decision = decisionForScore(best?.score || 0)
  return {
    normalizedIntent,
    decision,
    selectedTemplate: decision === 'fresh_plan' ? null : best?.template || null,
    candidates,
  }
}

function rowToTemplate(row) {
  if (!row) return null
  let definition = {}
  try { definition = JSON.parse(row.definition_json || '{}') } catch { definition = {} }
  return normalizedTemplate({
    ...definition,
    id: row.template_id,
    version: row.version,
    scope: row.scope,
    name: row.name,
    description: row.description,
    status: row.status,
  })
}

export function ensureDefaultTeamTemplates() {
  const statement = db.prepare(`
    INSERT OR IGNORE INTO team_templates
      (template_key, template_id, version, scope, name, description, status, definition_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `)
  const insert = db.transaction((templates) => {
    for (const template of templates) {
      const normalized = validateTeamTemplate(template)
      statement.run(
        `${normalized.id}@${normalized.version}`,
        normalized.id,
        normalized.version,
        normalized.scope,
        normalized.name,
        normalized.description,
        normalized.status,
        JSON.stringify(normalized),
      )
    }
  })
  insert(DEFAULT_TEAM_TEMPLATES)
}

export function listTeamTemplates({ includeInactive = false, userId = null } = {}) {
  ensureDefaultTeamTemplates()
  let rows
  if (includeInactive && userId) {
    rows = db.prepare(`
      SELECT * FROM team_templates
      WHERE status = 'active' OR created_by = ?
      ORDER BY template_id ASC, version DESC
    `).all(userId)
  } else {
    rows = db.prepare(`
      SELECT * FROM team_templates
      ${includeInactive ? '' : "WHERE status = 'active'"}
      ORDER BY template_id ASC, version DESC
    `).all()
  }
  return rows.map(rowToTemplate).filter(Boolean)
}

export function getTeamTemplate(templateId, version = '') {
  ensureDefaultTeamTemplates()
  const row = version
    ? db.prepare('SELECT * FROM team_templates WHERE template_id = ? AND version = ?').get(templateId, version)
    : db.prepare('SELECT * FROM team_templates WHERE template_id = ? AND status = \'active\' ORDER BY version DESC LIMIT 1').get(templateId)
  return rowToTemplate(row)
}

export function teamTemplateFunctionalSimilarity(left, right) {
  const a = normalizedTemplate(left)
  const b = normalizedTemplate(right)
  const intentScore = comparableOverlap(
    [...a.intent.required, ...a.intent.preferred],
    [...b.intent.required, ...b.intent.preferred],
  )
  const capabilityScore = comparableOverlap(a.capabilities, b.capabilities)
  const roleScore = comparableOverlap(
    a.slots.map(slot => asString(slot?.roleId)).filter(Boolean),
    b.slots.map(slot => asString(slot?.roleId)).filter(Boolean),
  )
  const workflowScore = comparableOverlap(
    Array.isArray(a.workflow?.stages) ? a.workflow.stages : [],
    Array.isArray(b.workflow?.stages) ? b.workflow.stages : [],
  )
  return Number((
    intentScore * 0.35
    + capabilityScore * 0.35
    + roleScore * 0.2
    + workflowScore * 0.1
  ).toFixed(4))
}

export function findFunctionallySimilarTeamTemplate(template, threshold = 0.85, createdBy = null) {
  const normalized = normalizedTemplate(template)
  ensureDefaultTeamTemplates()
  const rows = createdBy
    ? db.prepare(`
      SELECT * FROM team_templates
      WHERE template_id != ?
        AND (status = 'active' OR created_by = ?)
    `).all(normalized.id, createdBy)
    : db.prepare(`
      SELECT * FROM team_templates
      WHERE template_id != ? AND status IN ('active', 'validated', 'candidate')
    `).all(normalized.id)
  let best = null
  for (const row of rows) {
    const candidate = rowToTemplate(row)
    if (!candidate) continue
    const similarity = teamTemplateFunctionalSimilarity(normalized, candidate)
    if (similarity >= threshold && (!best || similarity > best.similarity)) {
      best = { template: candidate, similarity }
    }
  }
  return best
}

export function saveTeamTemplate(template, createdBy = null, { allowForeignUpdate = false } = {}) {
  const normalized = validateTeamTemplate(template)
  const existingRow = db.prepare(`
    SELECT created_by FROM team_templates WHERE template_key = ?
  `).get(`${normalized.id}@${normalized.version}`)
  if (existingRow && !allowForeignUpdate && existingRow.created_by !== createdBy) {
    throw new Error('Team template belongs to another owner')
  }
  const duplicate = findFunctionallySimilarTeamTemplate(normalized, 0.85, createdBy)
  if (duplicate) {
    throw new Error(
      `Functionally similar team template already exists: ${duplicate.template.id} (${duplicate.similarity})`,
    )
  }
  const now = Date.now()
  db.prepare(`
    INSERT INTO team_templates
      (template_key, template_id, version, scope, name, description, status, definition_json, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(template_key) DO UPDATE SET
      scope = excluded.scope,
      name = excluded.name,
      description = excluded.description,
      status = excluded.status,
      definition_json = excluded.definition_json,
      updated_at = excluded.updated_at
  `).run(
    `${normalized.id}@${normalized.version}`,
    normalized.id,
    normalized.version,
    normalized.scope,
    normalized.name,
    normalized.description,
    normalized.status,
    JSON.stringify(normalized),
    createdBy,
    now,
    now,
  )
  return getTeamTemplate(normalized.id, normalized.version)
}

export function matchTeamTemplatesFromRegistry(input) {
  return matchTeamTemplates(input, listTeamTemplates())
}

export function recordProjectTemplateMatch({
  projectId,
  userId,
  tenantId = '',
  match,
}) {
  if (!projectId || !userId || !match) return null
  const selected = match.selectedTemplate
  const now = Date.now()
  db.prepare(`
    INSERT INTO wattclaw_project_template_matches
      (project_id, user_id, tenant_id, template_id, template_version, score, decision,
       normalized_intent_json, match_json, template_snapshot_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(project_id) DO UPDATE SET
      tenant_id = excluded.tenant_id,
      template_id = excluded.template_id,
      template_version = excluded.template_version,
      score = excluded.score,
      decision = excluded.decision,
      normalized_intent_json = excluded.normalized_intent_json,
      match_json = excluded.match_json,
      template_snapshot_json = excluded.template_snapshot_json,
      updated_at = excluded.updated_at
  `).run(
    projectId,
    userId,
    tenantId,
    selected?.id || null,
    selected?.version || null,
    Number(match.candidates?.[0]?.score || 0),
    match.decision || 'fresh_plan',
    JSON.stringify(match.normalizedIntent || {}),
    JSON.stringify(match),
    JSON.stringify(selected || {}),
    now,
    now,
  )
  return getProjectTemplateMatch(projectId, userId)
}

export function getProjectTemplateMatch(projectId, userId = null) {
  const row = userId
    ? db.prepare('SELECT * FROM wattclaw_project_template_matches WHERE project_id = ? AND user_id = ?').get(projectId, userId)
    : db.prepare('SELECT * FROM wattclaw_project_template_matches WHERE project_id = ?').get(projectId)
  if (!row) return null
  const parse = (value, fallback) => {
    try { return JSON.parse(value || '') } catch { return fallback }
  }
  return {
    projectId: row.project_id,
    userId: row.user_id,
    tenantId: row.tenant_id,
    templateId: row.template_id,
    version: row.template_version,
    score: row.score,
    decision: row.decision,
    normalizedIntent: parse(row.normalized_intent_json, {}),
    match: parse(row.match_json, {}),
    templateSnapshot: parse(row.template_snapshot_json, {}),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

function canonicalRoleId(member) {
  if (member?.isLead) return 'project_manager'
  const text = `${asString(member?.role)} ${asString(member?.name)}`.toLowerCase()
  if (/(frontend|前端|网页|web)/.test(text)) return 'frontend_engineer'
  if (/(product|产品|需求|prd)/.test(text)) return 'product_analyst'
  if (/(qa|test|测试|验收|质量)/.test(text)) return 'qa_engineer'
  if (/(design|设计|视觉|ui|ux)/.test(text)) return 'visual_designer'
  if (/(data|数据|分析|统计)/.test(text)) return 'data_analyst'
  if (/(copy|writer|文案|编辑|内容)/.test(text)) return 'copywriter'
  if (/(video|视频|剪辑)/.test(text)) return 'video_editor'
  return 'domain_specialist'
}

function roleCapabilities(roleId) {
  const mapping = {
    project_manager: ['planning', 'delegation'],
    frontend_engineer: ['frontend_implementation'],
    product_analyst: ['requirements_analysis'],
    qa_engineer: ['qa_validation'],
    visual_designer: ['visual_design'],
    data_analyst: ['data_analysis', 'data_visualization'],
    copywriter: ['copywriting'],
    video_editor: ['video_editing'],
    domain_specialist: ['domain_execution'],
  }
  return mapping[roleId] || []
}

function projectTemplateFingerprint(intent, members) {
  const roles = members.map(canonicalRoleId).sort()
  const capabilities = uniqueStrings(roles.flatMap(roleCapabilities)).sort()
  return createHash('sha256').update(JSON.stringify({
    intent: [...intent.tags].sort(),
    roles,
    capabilities,
  })).digest('hex').slice(0, 16)
}

export function captureSuccessfulProjectTemplateCandidate({ project, userId }) {
  if (!project?.id || !userId) return null
  if (String(project.status || '').trim().toLowerCase() !== 'success') return null
  const persistedMatch = getProjectTemplateMatch(project.id, userId)
  if (persistedMatch?.match?.collaborationSettings?.captureTeamTemplate === false) return null
  if (!readProjectCollaborationSettings(project).captureTeamTemplate) return null
  const members = Array.isArray(project.members) ? project.members : []
  const workers = members.filter(member => !member?.isLead)
  if (workers.length < 2) return null

  const existingRun = db.prepare(`
    SELECT id FROM team_template_runs WHERE project_id = ? AND user_id = ?
  `).get(project.id, userId)
  if (existingRun) return null

  const intent = normalizeIntent(project.initialPrompt || project.description || project.name || '')
  const fingerprint = projectTemplateFingerprint(intent, members)
  const match = getProjectTemplateMatch(project.id, userId)
  const selected = match?.templateSnapshot && Object.keys(match.templateSnapshot).length > 0
    ? match.templateSnapshot
    : null
  const manifest = {
    normalizedIntent: intent,
    memberCount: members.length,
    roles: members.map(member => ({
      roleId: canonicalRoleId(member),
      role: asString(member?.role),
      skills: uniqueStrings(member?.skills),
      isLead: member?.isLead === true,
    })),
    outcome: 'success',
  }

  let candidate = null
  if (!selected) {
    const templateId = `candidate-${fingerprint}`
    const existing = getTeamTemplate(templateId, '0.1.0')
    const successfulRuns = Number(existing?.evidence?.successfulRuns || 0) + 1
    const slots = members.map((member, index) => {
      const roleId = canonicalRoleId(member)
      return {
        id: member?.isLead ? 'manager' : `${roleId}-${index}`,
        roleId,
        count: 1,
        required: true,
        selector: { capabilities: roleCapabilities(roleId) },
        defaultProfile: {
          name: asString(member?.name),
          role: asString(member?.role),
          soul: asString(member?.soul),
          skills: uniqueStrings(member?.skills),
        },
        reusePolicy: 'profile',
      }
    })
    const candidateDefinition = {
      id: templateId,
      version: '0.1.0',
      scope: 'user',
      name: `${asString(project.name) || '未命名项目'}团队候选模板`,
      description: asString(project.description),
      intent: {
        required: intent.tags.slice(0, 1),
        preferred: intent.tags.slice(1),
        excluded: [],
      },
      capabilities: uniqueStrings(slots.flatMap(slot => slot.selector.capabilities)),
      slots,
      workflow: project.draftSuggestion?.templateMatch?.selectedTemplate?.workflow || {
        stages: [],
        handoffs: [],
      },
      constraints: { requiresIsolation: true, maxMembers: Math.max(members.length, 3) },
      qualityGate: { reviewRequired: true },
      evidence: {
        successfulRuns,
        promotionThreshold: 3,
        fingerprint,
      },
      status: successfulRuns >= 3 ? 'validated' : 'candidate',
    }
    if (existing && ['active', 'validated'].includes(existing.status)) {
      candidate = existing
    } else {
      const duplicate = findFunctionallySimilarTeamTemplate(candidateDefinition, 0.85, userId)
      candidate = duplicate?.template || saveTeamTemplate(candidateDefinition, userId)
    }
  }

  db.prepare(`
    INSERT INTO team_template_runs
      (id, project_id, user_id, template_id, template_version, fingerprint, outcome, manifest_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, 'success', ?, ?, ?)
  `).run(
    randomUUID(),
    project.id,
    userId,
    selected?.id || candidate?.id || null,
    selected?.version || candidate?.version || null,
    fingerprint,
    JSON.stringify(manifest),
    Date.now(),
    Date.now(),
  )

  return {
    projectId: project.id,
    fingerprint,
    reusedTemplate: selected,
    candidate,
  }
}

ensureDefaultTeamTemplates()
