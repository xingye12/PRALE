import { describe, expect, it } from 'vitest'
import db from '../database.js'
import {
  captureSuccessfulProjectTemplateCandidate,
  matchTeamTemplates,
  normalizeIntent,
  teamTemplateFunctionalSimilarity,
  validateTeamTemplate,
} from './team-template-service.js'

const rollback = Symbol('rollback')

function inRolledBackTransaction(callback) {
  let value
  try {
    db.transaction(() => {
      value = callback()
      throw rollback
    })()
  } catch (error) {
    if (error !== rollback) throw error
  }
  return value
}

const templates = [
  {
    id: 'web',
    version: '1.0.0',
    name: 'Web 团队',
    description: 'Web application delivery',
    intent: { required: ['web_app'], preferred: ['mvp'], excluded: [] },
    capabilities: ['requirements_analysis', 'frontend_implementation', 'qa_validation'],
    slots: [{ id: 'frontend', roleId: 'frontend_engineer' }],
    status: 'active',
  },
  {
    id: 'video',
    version: '1.0.0',
    name: 'Video 团队',
    description: 'Video production',
    intent: { required: ['video_production'], preferred: [], excluded: [] },
    capabilities: ['video_production', 'video_editing'],
    slots: [{ id: 'editor', roleId: 'video_editor' }],
    status: 'active',
  },
]

describe('team template matching', () => {
  it('normalizes Chinese and English task signals into intent tags', () => {
    const intent = normalizeIntent('开发一个 React 电商网站 MVP')

    expect(intent.tags).toEqual(expect.arrayContaining(['web_app', 'mvp', 'frontend']))
    expect(intent.capabilities).toEqual(expect.arrayContaining([
      'requirements_analysis',
      'frontend_implementation',
    ]))
  })

  it('automatically selects a template when required intent and capabilities match', () => {
    const result = matchTeamTemplates('开发一个 React 电商网站 MVP', templates)

    expect(result.decision).toBe('auto_apply')
    expect(result.selectedTemplate?.id).toBe('web')
    expect(result.candidates[0]?.score).toBeGreaterThanOrEqual(0.85)
  })

  it('does not apply a template when the prompt has no known domain signal', () => {
    const result = matchTeamTemplates('帮我处理一些事情', templates)

    expect(result.decision).toBe('fresh_plan')
    expect(result.selectedTemplate).toBeNull()
  })

  it('rejects templates with duplicate slot ids', () => {
    expect(() => validateTeamTemplate({
      id: 'invalid',
      name: 'Invalid',
      slots: [{ id: 'same' }, { id: 'same' }],
    })).toThrow('slot ids must be unique')
  })

  it('detects functionally equivalent teams independently of template names', () => {
    const renamed = {
      ...templates[0],
      id: 'renamed-web',
      name: '完全不同的名称',
    }

    expect(teamTemplateFunctionalSimilarity(templates[0], renamed)).toBe(1)
  })

  it('captures successful fresh teams as deduplicated candidate templates', () => {
    inRolledBackTransaction(() => {
      db.prepare(`
        INSERT INTO users (id, username, password_hash, role)
        VALUES ('template-capture-user', 'template-capture-user', 'test', 'user')
      `).run()
      const project = {
        id: 'p-template-capture',
        name: '企业流程审查',
        description: '审查复杂的企业流程',
        status: 'success',
        members: [
          { agentId: 'p-template-capture-manager', name: 'Manager', role: '项目经理', isLead: true },
          { agentId: 'p-template-capture-worker1', name: '合规专家', role: '合规顾问' },
          { agentId: 'p-template-capture-worker2', name: '法务专家', role: '法务顾问' },
        ],
      }

      const first = captureSuccessfulProjectTemplateCandidate({ project, userId: 'template-capture-user' })
      const second = captureSuccessfulProjectTemplateCandidate({ project, userId: 'template-capture-user' })

      expect(first?.candidate?.status).toBe('candidate')
      expect(JSON.stringify(first?.candidate)).not.toContain('p-template-capture-worker1')
      expect(second).toBeNull()
    })
  })

  it('skips successful team capture when the project setting is disabled', () => {
    inRolledBackTransaction(() => {
      db.prepare(`
        INSERT INTO users (id, username, password_hash, role)
        VALUES ('template-capture-disabled-user', 'template-capture-disabled-user', 'test', 'user')
      `).run()
      const project = {
        id: 'p-template-capture-disabled',
        name: '不沉淀的团队项目',
        status: 'success',
        draftSuggestion: {
          collaborationSettings: {
            teamCreationMode: 'manager',
            captureTeamTemplate: false,
          },
        },
        members: [
          { agentId: 'p-template-capture-disabled-manager', name: 'Manager', isLead: true },
          { agentId: 'p-template-capture-disabled-worker1', name: '前端工程师', role: '前端' },
          { agentId: 'p-template-capture-disabled-worker2', name: '测试工程师', role: 'QA' },
        ],
      }

      expect(captureSuccessfulProjectTemplateCandidate({
        project,
        userId: 'template-capture-disabled-user',
      })).toBeNull()
    })
  })
})
