import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtemp, mkdir, rm, writeFile } from 'fs/promises'
import { join } from 'path'
import { tmpdir } from 'os'
import {
  createWattClawProjectEventService,
  resolveWattClawProjectDirectory,
} from './wattclaw-project-events.js'

const tempDirectories = []

async function createTempDirectory() {
  const directory = await mkdtemp(join(tmpdir(), 'wattclaw-project-events-'))
  tempDirectories.push(directory)
  return directory
}

async function waitFor(predicate, timeoutMs = 2000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  throw new Error('Timed out waiting for project event')
}

afterEach(async () => {
  await Promise.all(tempDirectories.splice(0).map(directory =>
    rm(directory, { recursive: true, force: true })
  ))
})

describe('WattClaw project realtime events', () => {
  it('resolves a tenant project directory from the mounted data root', async () => {
    const root = await createTempDirectory()
    const projectDir = join(root, 'tenant-1', '.wattclaw-team', 'projects', 'p-test')
    await mkdir(projectDir, { recursive: true })

    expect(resolveWattClawProjectDirectory({
      envConfig: {
        OPENCLAW_CONTAINER_DATA_DIR: root,
        OPENCLAW_HOST_DATA_DIR: '',
      },
      tenantId: 'tenant-1',
      projectId: 'p-test',
    })).toBe(projectDir)
  })

  it('publishes subscribed project changes and stops after unsubscribe', async () => {
    const root = await createTempDirectory()
    const projectDir = join(root, 'tenant-1', '.wattclaw-team', 'projects', 'p-test')
    await mkdir(projectDir, { recursive: true })
    await writeFile(join(projectDir, 'config.json'), JSON.stringify({
      id: 'p-test',
      status: 'pending',
      members: [],
    }))
    await writeFile(join(projectDir, 'task-list.json'), '[]')

    const publish = vi.fn()
    const service = createWattClawProjectEventService({ publish, debounceMs: 10 })
    service.subscribe({
      clientId: 'client-1',
      projectId: 'p-test',
      tenantId: 'tenant-1',
      projectDir,
    })

    await waitFor(() => publish.mock.calls.length >= 2)
    expect(service.getActiveProjectCount()).toBe(1)
    expect(publish).toHaveBeenCalledWith(expect.objectContaining({
      clientIds: ['client-1'],
      event: 'wattclaw.team.project.updated',
    }))
    expect(publish).toHaveBeenCalledWith(expect.objectContaining({
      clientIds: ['client-1'],
      event: 'wattclaw.team.tasks.updated',
    }))

    await writeFile(join(projectDir, 'config.json'), JSON.stringify({
      id: 'p-test',
      status: 'in_progress',
      members: [],
    }))
    await waitFor(() => publish.mock.calls.some(([entry]) =>
      entry.event === 'wattclaw.team.project.updated'
      && entry.payload.project?.status === 'in_progress'
    ))

    service.unsubscribe('client-1')
    expect(service.getActiveProjectCount()).toBe(0)
    const callCount = publish.mock.calls.length
    await writeFile(join(projectDir, 'config.json'), JSON.stringify({
      id: 'p-test',
      status: 'success',
      members: [],
    }))
    await new Promise(resolve => setTimeout(resolve, 100))
    expect(publish).toHaveBeenCalledTimes(callCount)
  })
})
