import { describe, expect, it, vi } from 'vitest'
import {
  activateWattClawProjectRuntime,
  ensureWattClawProjectRuntime,
  extractWattClawProject,
  extractWattClawProjects,
  filterWattClawProjectsByOwnedAgents,
  nextWattClawRetentionRunAt,
  pruneWattClawProjectsForUser,
  trackWattClawProjectOwnership,
  userOwnsWattClawProject,
} from './wattclaw-project-runtime.js'

const project = {
  id: 'p-test',
  name: 'Test project',
  members: [
    { agentId: 'p-test-manager', name: 'Manager', role: 'Lead', isLead: true },
    { agentId: 'p-test-worker1', name: 'Worker', role: 'Researcher', isLead: false },
  ],
}

describe('wattclaw project runtime', () => {
  it('schedules retention for 18:00 Asia/Shanghai every day', () => {
    const beforeRun = Date.parse('2026-08-20T09:59:00.000Z')
    const atRun = Date.parse('2026-08-20T10:00:00.000Z')

    expect(new Date(nextWattClawRetentionRunAt(beforeRun)).toISOString()).toBe('2026-08-20T10:00:00.000Z')
    expect(new Date(nextWattClawRetentionRunAt(atRun)).toISOString()).toBe('2026-08-21T10:00:00.000Z')
  })

  it('extracts a nested project payload', () => {
    expect(extractWattClawProject({ data: { project } })).toEqual(project)
  })

  it('filters project lists by owned project agents', () => {
    const otherProject = {
      ...project,
      id: 'p-other',
      members: [{ agentId: 'p-other-manager', name: 'Other', role: 'Lead', isLead: true }],
    }

    expect(extractWattClawProjects({ projects: [project, otherProject] })).toEqual([project, otherProject])
    expect(userOwnsWattClawProject(project, new Set(['p-test-worker1']))).toBe(true)
    expect(userOwnsWattClawProject(otherProject, new Set(['p-test-worker1']))).toBe(false)
    expect(filterWattClawProjectsByOwnedAgents([project, otherProject], ['p-test-manager'])).toEqual([project])
  })

  it('applies config and waits for all project agents', async () => {
    let listCount = 0
    const gatewayAdminRpc = vi.fn(async (method) => {
      if (method === 'agents.list') {
        listCount += 1
        return {
          ok: true,
          payload: {
            agents: listCount < 3
              ? [{ id: 'main' }]
              : [{ id: 'p-test-manager' }, { id: 'p-test-worker1' }],
          },
        }
      }
      if (method === 'config.get') {
        return { ok: true, payload: { raw: '{"agents":{}}', hash: 'hash-1' } }
      }
      if (method === 'config.apply') return { ok: true, payload: {} }
      return { ok: false, error: 'unexpected method' }
    })

    const agents = await ensureWattClawProjectRuntime({
      project,
      gatewayAdminRpc,
      timeoutMs: 100,
      pollIntervalMs: 1,
    })

    expect(agents.map(agent => agent.id)).toEqual(['p-test-manager', 'p-test-worker1'])
    expect(gatewayAdminRpc).toHaveBeenCalledWith('config.apply', {
      raw: '{"agents":{}}',
      baseHash: 'hash-1',
    })
  })

  it('archives only expired terminal or restored archived projects', async () => {
    const now = Date.UTC(2026, 7, 20)
    const old = new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString()
    const fresh = new Date(now - 2 * 24 * 60 * 60 * 1000).toISOString()
    const projects = [
      { id: 'p-success-old', name: 'Success old', status: 'success', updatedAt: old, members: [{ agentId: 'p-success-old-manager', isLead: true }] },
      { id: 'p-failed-old', name: 'Failed old', status: 'failed', updatedAt: old, members: [{ agentId: 'p-failed-old-manager', isLead: true }] },
      { id: 'p-success-fresh', name: 'Success fresh', status: 'success', updatedAt: fresh, members: [{ agentId: 'p-success-fresh-manager', isLead: true }] },
      { id: 'p-running-old', name: 'Running old', status: 'in_progress', updatedAt: old, members: [{ agentId: 'p-running-old-manager', isLead: true }] },
      { id: 'p-pending-old', name: 'Pending old', status: 'pending', updatedAt: old, members: [{ agentId: 'p-pending-old-manager', isLead: true }] },
      { id: 'p-archived-cold', name: 'Archived cold', status: 'archived', updatedAt: old, members: [{ agentId: 'p-archived-cold-manager', isLead: true }] },
      { id: 'p-archived-restored', name: 'Archived restored', status: 'archived', updatedAt: old, members: [{ agentId: 'p-archived-restored-manager', isLead: true }] },
      { id: 'p-other', name: 'Other project', status: 'success', updatedAt: old, members: [{ agentId: 'p-other-manager', isLead: true }] },
    ]

    const gatewayRpc = vi.fn(async (method, params) => {
      if (method === 'wattclaw.team.project.list') return { projects }
      if (method === 'agents.list') {
        return {
          agents: projects
            .filter(item => item.id !== 'p-archived-cold')
            .flatMap(item => item.members.map(member => ({ id: member.agentId }))),
        }
      }
      if (method === 'wattclaw.team.project.archive') return { id: params.id, status: 'archived' }
      throw new Error(`unexpected method: ${method}`)
    })

    const result = await pruneWattClawProjectsForUser({
      gatewayRpc,
      now,
      ownedAgentIds: projects.slice(0, 7).map(item => item.members[0].agentId),
      projectAccessStates: new Map([
        ['p-archived-restored', {
          restoredAt: now - 2 * 24 * 60 * 60 * 1000,
          lastAccessedAt: now,
        }],
      ]),
    })

    expect(result.archived).toEqual(['p-success-old', 'p-failed-old', 'p-archived-restored'])
    expect(result.kept).toEqual([
      'p-success-fresh',
      'p-running-old',
      'p-pending-old',
      'p-archived-cold',
    ])
    expect(gatewayRpc).toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-success-old' })
    expect(gatewayRpc).toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-failed-old' })
    expect(gatewayRpc).toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-archived-restored' })
    expect(gatewayRpc).not.toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-running-old' })
    expect(gatewayRpc).not.toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-pending-old' })
    expect(gatewayRpc).not.toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-archived-cold' })
    expect(gatewayRpc).not.toHaveBeenCalledWith('wattclaw.team.project.archive', { id: 'p-other' })
  })

  it('scans every tenant project when no ownership filter is provided', async () => {
    const now = Date.UTC(2026, 7, 20)
    const old = new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString()
    const projects = [
      { id: 'p-a', status: 'success', updatedAt: old, members: [] },
      { id: 'p-b', status: 'failed', updatedAt: old, members: [] },
    ]
    const gatewayRpc = vi.fn(async (method, params) => {
      if (method === 'wattclaw.team.project.list') return { projects }
      if (method === 'agents.list') return { agents: [] }
      if (method === 'wattclaw.team.project.archive') return { id: params.id, status: 'archived' }
      throw new Error(`unexpected method: ${method}`)
    })

    const result = await pruneWattClawProjectsForUser({ gatewayRpc, now })

    expect(result.scanned).toBe(2)
    expect(result.archived).toEqual(['p-a', 'p-b'])
  })

  it('restores only missing project agents with their original IDs', async () => {
    let workerLoaded = false
    const gatewayRpc = vi.fn(async (method, params) => {
      if (method === 'agents.list') {
        return {
          agents: [
            { id: 'p-test-manager' },
            ...(workerLoaded ? [{ id: 'p-test-worker1' }] : []),
          ],
        }
      }
      if (method === 'wattclaw.team.project.member.update') {
        workerLoaded = true
        return project
      }
      throw new Error(`unexpected method: ${method}`)
    })

    const result = await activateWattClawProjectRuntime({ project: { ...project, status: 'archived' }, gatewayRpc })

    expect(result.agents.map(agent => agent.id)).toEqual(['p-test-manager', 'p-test-worker1'])
    expect(gatewayRpc).toHaveBeenCalledWith('wattclaw.team.project.member.update', {
      projectId: 'p-test',
      agentId: 'p-test-worker1',
      name: 'Worker',
      role: 'Researcher',
    })
    expect(gatewayRpc).not.toHaveBeenCalledWith(
      'wattclaw.team.project.member.update',
      expect.objectContaining({ agentId: 'p-test-manager' }),
    )
    expect(result.restored).toBe(true)
  })

  it('tracks every member and all member sessions', () => {
    const trackAgent = vi.fn()
    const trackSession = vi.fn()

    const tracked = trackWattClawProjectOwnership({
      project,
      agents: [
        { id: 'p-test-manager', workspace: '/manager' },
        { id: 'p-test-worker1', workspace: '/worker' },
      ],
      userId: 'user-1',
      trackAgent,
      trackSession,
    })

    expect(trackAgent).toHaveBeenCalledTimes(2)
    expect(trackAgent).toHaveBeenCalledWith('user-1', 'p-test-manager', 'Manager', {
      workspace: '/manager',
      description: 'Lead',
    })
    expect(trackSession).toHaveBeenCalledTimes(2)
    expect(trackSession).toHaveBeenCalledWith(
      'user-1',
      'agent:p-test-manager:main',
      'p-test-manager',
      'Test project',
      'main',
    )
    expect(trackSession).toHaveBeenCalledWith(
      'user-1',
      'agent:p-test-worker1:main',
      'p-test-worker1',
      'Test project',
      'main',
    )
    expect(tracked).toEqual({
      agentIds: ['p-test-manager', 'p-test-worker1'],
      sessionKeys: ['agent:p-test-manager:main', 'agent:p-test-worker1:main'],
    })
  })
})
