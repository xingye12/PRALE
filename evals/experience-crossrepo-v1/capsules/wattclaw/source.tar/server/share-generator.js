import markdownIt from 'markdown-it'
import hljs from 'highlight.js'

const md = markdownIt({
  html: false,
  linkify: true,
  breaks: true,
  highlight(str, lang) {
    if (lang && hljs.getLanguage(lang)) {
      try {
        return `<pre class="hljs"><code>${hljs.highlight(str, { language: lang, ignoreIllegals: true }).value}</code></pre>`
      } catch { /* fallback */ }
    }
    return `<pre class="hljs"><code>${md.utils.escapeHtml(str)}</code></pre>`
  },
})

const defaultFence = md.renderer.rules.fence || function (tokens, idx, options, _env, self) {
  return self.renderToken(tokens, idx, options)
}
md.renderer.rules.fence = (tokens, idx, options, env, self) => {
  const result = defaultFence(tokens, idx, options, env, self)
  return result.replace('<pre class="hljs">', '<pre class="hljs"><button class="code-copy-btn" onclick="copyCode(this)">复制</button>')
}

function stripThinking(content) {
  if (!content) return ''
  return content.replace(/<thinking>[\s\S]*?<\/thinking>/g, '').trimEnd()
}

function normalizeContent(content) {
  if (Array.isArray(content)) {
    return content
      .filter(c => c.type === 'text' && c.text)
      .map(c => c.text)
      .join('\n')
  }
  return typeof content === 'string' ? content : ''
}

function generateShareHtml({ title, messages }) {
  const now = new Date()
  const dateStr = `${now.getFullYear()} 年 ${now.getMonth() + 1} 月 ${now.getDate()} 日`

  const renderedMessages = messages
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .map(m => {
      const rawContent = normalizeContent(m.content)
      const content = m.role === 'assistant' ? stripThinking(rawContent) : rawContent

      if (m.role === 'assistant') {
        const html = md.render(content || '')
        return `<div class="message assistant"><div class="markdown-body">${html}</div></div>`
      }

      // User message: bubble style
      const filesHtml = m.files && m.files.length > 0
        ? `<div class="files">${m.files.map(f => `
          <div class="file-card">
            <span class="material-symbols-outlined">description</span>
            <span class="file-name">${escapeHtml(f.name)}</span>
            <span class="file-size">${formatSize(f.size)}</span>
          </div>`).join('')}</div>`
        : ''
      return `<div class="message user"><div class="user-bubble">${escapeHtml(content || '')}${filesHtml}</div></div>`
    })
    .join('\n')

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)} - WattClaw</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #f5f5f5;
      color: #1a1a1a;
      line-height: 1.6;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    header {
      margin-bottom: 32px;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    header h1 {
      font-size: 24px;
      font-weight: 600;
      margin-bottom: 8px;
      color: #1a1a1a;
    }
    header .meta {
      font-size: 13px;
      color: #888;
    }
    .messages {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .message {
      display: flex;
    }
    .message.user {
      justify-content: flex-end;
    }
    .message.assistant {
      justify-content: flex-start;
    }

    /* ── User bubble (matches chat page) ── */
    .user-bubble {
      max-width: 65%;
      padding: 10px 14px;
      border-radius: 14px;
      border-bottom-right-radius: 4px;
      font-size: 14px;
      line-height: 1.6;
      word-break: break-word;
      overflow-wrap: anywhere;
      white-space: pre-wrap;
      background: #e3f2fd;
      color: #1565c0;
      border: 1px solid #bbdefb;
    }

    /* ── Markdown body (matches markdown.css in chat page) ── */
    .markdown-body {
      font-size: 14px;
      line-height: 1.75;
      word-break: break-word;
      overflow-wrap: anywhere;
      max-width: 100%;
    }
    .markdown-body p { margin: 0 0 10px; }
    .markdown-body p:last-child { margin-bottom: 0; }
    .markdown-body h1, .markdown-body h2, .markdown-body h3 {
      margin: 16px 0 6px;
      font-weight: 600;
    }
    .markdown-body h1 { font-size: 18px; }
    .markdown-body h2 { font-size: 16px; }
    .markdown-body h3 { font-size: 14px; }
    .markdown-body strong { font-weight: 600; color: #1a1a1a; }
    .markdown-body ul, .markdown-body ol {
      padding-left: 20px;
      margin: 6px 0 10px;
    }
    .markdown-body li { margin-bottom: 3px; }
    .markdown-body blockquote {
      border-left: 3px solid #1976d2;
      padding-left: 14px;
      margin: 10px 0;
      color: #666;
      font-style: italic;
    }
    .markdown-body blockquote p { margin: 0; }
    .markdown-body a { color: #1976d2; text-decoration: underline; }
    .markdown-body hr {
      border: none;
      border-top: 1px solid #e0e0e0;
      margin: 12px 0;
    }
    .markdown-body img {
      max-width: 100%;
      border-radius: 8px;
    }
    .markdown-body table {
      border-collapse: collapse;
      width: 100%;
      margin: 8px 0;
      font-size: 12px;
    }
    .markdown-body th,
    .markdown-body td {
      border: 1px solid #e0e0e0;
      padding: 5px 10px;
      text-align: left;
    }
    .markdown-body th {
      background: rgba(0,0,0,.04);
      font-weight: 600;
    }
    .markdown-body tr:nth-child(even) {
      background: rgba(0,0,0,.02);
    }
    .markdown-body code {
      background: #eff1f3;
      padding: 1px 5px;
      border-radius: 4px;
      font-size: 12.5px;
      font-family: "SF Mono", ui-monospace, "Cascadia Code", "Fira Code", monospace;
      color: #1a1a1a;
    }
    .markdown-body pre.hljs {
      position: relative;
      background: #f6f8fa;
      border: 1px solid #e0e0e0;
      border-radius: 10px;
      padding: 14px 16px;
      margin: 10px 0;
      overflow-x: auto;
      font-size: 13px;
      line-height: 1.6;
    }
    .markdown-body pre.hljs code {
      background: none;
      padding: 0;
      font-size: inherit;
      color: inherit;
    }

    /* ── File attachments ── */
    .files {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 8px;
    }
    .file-card {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 10px;
      background: rgba(0,0,0,.06);
      border-radius: 6px;
      font-size: 12px;
    }
    .file-card .material-symbols-outlined {
      font-size: 16px;
      color: #666;
    }
    .file-name { font-weight: 500; }
    .file-size { color: #888; }

    /* ── Code copy button ── */
    .code-copy-btn {
      position: absolute;
      top: 6px;
      right: 6px;
      padding: 3px 8px;
      font-size: 11px;
      background: rgba(255,255,255,.8);
      border: 1px solid #ddd;
      border-radius: 6px;
      cursor: pointer;
      opacity: 0;
      transition: opacity .2s;
      color: #666;
      font-family: inherit;
    }
    .markdown-body pre.hljs:hover .code-copy-btn {
      opacity: 1;
    }
    .code-copy-btn:hover {
      background: #fff;
    }

    /* ── Highlight.js light ── */
    ${HLJS_LIGHT_CSS}

    footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e0e0e0;
      text-align: center;
      font-size: 12px;
      color: #888;
    }

    /* ── Dark mode ── */
    @media (prefers-color-scheme: dark) {
      body { background: #1a1a1a; color: #e0e0e0; }
      header { border-bottom-color: #333; }
      header h1 { color: #e0e0e0; }
      .user-bubble {
        background: #1a3a5c;
        color: #90caf9;
        border-color: #2a4a6c;
      }
      .markdown-body strong { color: #e0e0e0; }
      .markdown-body code {
        background: #333;
        color: #e0e0e0;
      }
      .markdown-body pre.hljs {
        background: #161b22;
        border-color: #333;
      }
      .markdown-body blockquote { border-left-color: #64b5f6; color: #999; }
      .markdown-body a { color: #64b5f6; }
      .markdown-body th { background: rgba(255,255,255,.04); }
      .markdown-body th, .markdown-body td { border-color: #333; }
      .markdown-body tr:nth-child(even) { background: rgba(255,255,255,.02); }
      .markdown-body hr { border-top-color: #333; }
      .file-card { background: rgba(255,255,255,.06); }
      .file-card .material-symbols-outlined { color: #999; }
      .code-copy-btn { background: rgba(30,30,30,.8); border-color: #444; color: #ccc; }
      .code-copy-btn:hover { background: #333; }
      footer { border-top-color: #333; }
      /* ── Highlight.js dark ── */
      ${HLJS_DARK_CSS}
    }
    @media (max-width: 640px) {
      .container { padding: 20px 12px; }
      .user-bubble { max-width: 90%; }
      header h1 { font-size: 20px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>${escapeHtml(title)}</h1>
      <div class="meta">${dateStr} • 内容由 AI 生成，仅供参考</div>
    </header>
    <div class="messages">
      ${renderedMessages}
    </div>
    <footer>由 WattClaw 生成</footer>
  </div>
  <script>
    function copyCode(btn) {
      var pre = btn.closest('pre');
      if (!pre) return;
      var code = pre.querySelector('code');
      if (!code) return;
      var text = code.textContent || '';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function() {
          btn.textContent = '已复制!';
          setTimeout(function() { btn.textContent = '复制'; }, 2000);
        });
      } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;left:-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        btn.textContent = '已复制!';
        setTimeout(function() { btn.textContent = '复制'; }, 2000);
      }
    }
  </script>
</body>
</html>`
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function formatSize(bytes) {
  if (!bytes) return ''
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

const HLJS_LIGHT_CSS = `.hljs{color:#24292e}.hljs-doctag,.hljs-keyword,.hljs-meta .hljs-keyword,.hljs-template-tag,.hljs-template-variable,.hljs-type,.hljs-variable.language_{color:#d73a49}.hljs-title,.hljs-title.class_,.hljs-title.class_.inherited__,.hljs-title.function_{color:#6f42c1}.hljs-attr,.hljs-attribute,.hljs-literal,.hljs-meta,.hljs-number,.hljs-operator,.hljs-selector-attr,.hljs-selector-class,.hljs-selector-id,.hljs-variable{color:#005cc5}.hljs-meta .hljs-string,.hljs-regexp,.hljs-string{color:#032f62}.hljs-built_in,.hljs-symbol{color:#e36209}.hljs-code,.hljs-comment,.hljs-formula{color:#6a737d}.hljs-name,.hljs-quote,.hljs-selector-pseudo,.hljs-selector-tag{color:#22863a}.hljs-subst{color:#24292e}.hljs-section{color:#005cc5;font-weight:700}.hljs-bullet{color:#735c0f}.hljs-emphasis{color:#24292e;font-style:italic}.hljs-strong{color:#24292e;font-weight:700}.hljs-addition{color:#22863a;background-color:#f0fff4}.hljs-deletion{color:#b31d28;background-color:#ffeef0}`

const HLJS_DARK_CSS = `.hljs{color:#c9d1d9}.hljs-doctag,.hljs-keyword,.hljs-meta .hljs-keyword,.hljs-template-tag,.hljs-template-variable,.hljs-type,.hljs-variable.language_{color:#ff7b72}.hljs-title,.hljs-title.class_,.hljs-title.class_.inherited__,.hljs-title.function_{color:#d2a8ff}.hljs-attr,.hljs-attribute,.hljs-literal,.hljs-meta,.hljs-number,.hljs-operator,.hljs-selector-attr,.hljs-selector-class,.hljs-selector-id,.hljs-variable{color:#79c0ff}.hljs-meta .hljs-string,.hljs-regexp,.hljs-string{color:#a5d6ff}.hljs-built_in,.hljs-symbol{color:#ffa657}.hljs-code,.hljs-comment,.hljs-formula{color:#8b949e}.hljs-name,.hljs-quote,.hljs-selector-pseudo,.hljs-selector-tag{color:#7ee787}.hljs-subst{color:#c9d1d9}.hljs-section{color:#1f6feb;font-weight:700}.hljs-bullet{color:#f2cc60}.hljs-emphasis{color:#c9d1d9;font-style:italic}.hljs-strong{color:#c9d1d9;font-weight:700}.hljs-addition{color:#aff5b4;background-color:#033a16}.hljs-deletion{color:#ffdcd7;background-color:#67060c}`

export { generateShareHtml }
