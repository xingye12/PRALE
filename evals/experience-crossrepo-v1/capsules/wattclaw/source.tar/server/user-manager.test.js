import { beforeEach, describe, expect, it, vi } from 'vitest'

const dbMock = vi.hoisted(() => {
  const statements = []
  const db = {
    prepare: vi.fn((sql) => {
      const stmt = {
        sql,
        get: vi.fn(),
        all: vi.fn(() => []),
        run: vi.fn(() => ({ changes: 1 })),
      }
      statements.push(stmt)
      return stmt
    }),
    transaction: vi.fn((fn) => fn),
    exec: vi.fn(),
    pragma: vi.fn(),
  }
  return { db, statements }
})

vi.mock('./database.js', () => ({
  default: dbMock.db,
  ensureDefaultAdmin: vi.fn(),
}))

vi.mock('./services/session-title-service.js', () => ({
  normalizeDisplayTitleCandidate: vi.fn((value) => String(value || '').trim()),
  shouldBackfillDisplayTitle: vi.fn(() => false),
}))

vi.mock('./openclaw-config-sync.js', () => ({
  syncAllTenantOpenClawConfigsFromDB: vi.fn(() => []),
}))

const userManager = await import('./user-manager.js')

function resetDbMock() {
  dbMock.statements.length = 0
  dbMock.db.prepare.mockClear()
  dbMock.db.prepare.mockImplementation((sql) => {
    const stmt = {
      sql,
      get: vi.fn(),
      all: vi.fn(() => []),
      run: vi.fn(() => ({ changes: 1 })),
    }
    dbMock.statements.push(stmt)

    if (sql.includes('SELECT tenant_id FROM user_tenant_assignments')) {
      stmt.get.mockReturnValue(null)
    } else if (sql.includes('INNER JOIN user_tenant_assignments')) {
      stmt.get.mockReturnValue(null)
    }

    return stmt
  })
}

function findStatement(fragment) {
  return dbMock.statements.find((stmt) => stmt.sql.includes(fragment))
}

describe('user session upserts', () => {
  beforeEach(() => {
    resetDbMock()
  })

  it('tracks an existing session by global session_key without reinserting it for another user', () => {
    dbMock.db.prepare.mockImplementation((sql) => {
      const stmt = {
        sql,
        get: vi.fn(),
        all: vi.fn(() => []),
        run: vi.fn(() => ({ changes: 1 })),
      }
      dbMock.statements.push(stmt)

      if (sql.includes('SELECT tenant_id FROM user_tenant_assignments')) {
        stmt.get.mockReturnValue(null)
      } else if (sql.includes('INNER JOIN user_tenant_assignments')) {
        stmt.get.mockReturnValue(null)
      } else if (sql.includes('FROM user_sessions') && sql.includes('WHERE session_key = ?')) {
        stmt.get.mockReturnValue({
          id: 'session-row',
          user_id: 'user-a',
          label: null,
          display_title: null,
          agent_id: null,
          channel: null,
          tenant_id: null,
        })
      }

      return stmt
    })

    userManager.trackSessionForUser('user-b', 'agent:agent-a:run-1', 'agent-a', 'Run 1', 'webchat')

    const select = findStatement('FROM user_sessions')
    expect(select.sql).toContain('WHERE session_key = ?')
    expect(select.sql).not.toContain('user_id = ? AND session_key = ?')
    expect(select.get).toHaveBeenCalledWith('agent:agent-a:run-1')
    expect(findStatement('UPDATE user_sessions').run).toHaveBeenCalled()
    expect(findStatement('INSERT INTO user_sessions')).toBeUndefined()
  })

  it('sync upsert updates the existing unique session_key row instead of inserting a duplicate', () => {
    dbMock.db.prepare.mockImplementation((sql) => {
      const stmt = {
        sql,
        get: vi.fn(),
        all: vi.fn(() => []),
        run: vi.fn(() => ({ changes: 1 })),
      }
      dbMock.statements.push(stmt)

      if (sql.includes('SELECT tenant_id FROM user_tenant_assignments')) {
        stmt.get.mockReturnValue(null)
      } else if (sql.includes('INNER JOIN user_tenant_assignments')) {
        stmt.get.mockReturnValue(null)
      } else if (sql.includes('FROM user_sessions') && sql.includes('WHERE session_key = ?')) {
        stmt.get.mockReturnValue({
          id: 'session-row',
          user_id: 'user-a',
          agent_id: null,
          channel: null,
          peer_id: null,
          label: null,
          display_title: null,
          last_message_at: null,
          tenant_id: null,
        })
      }

      return stmt
    })

    const result = userManager.upsertSyncedUserSession({
      userId: 'user-b',
      sessionKey: 'agent:agent-a:run-1',
      agentId: 'agent-a',
      channel: 'webchat',
      peer: null,
      label: 'Run 1',
      lastActivity: 1783664644760,
    })

    const select = findStatement('FROM user_sessions')
    expect(select.sql).toContain('WHERE session_key = ?')
    expect(select.sql).not.toContain('user_id = ? AND session_key = ?')
    expect(select.get).toHaveBeenCalledWith('agent:agent-a:run-1')
    expect(result.action).toBe('updated')
    expect(findStatement('UPDATE user_sessions').run).toHaveBeenCalled()
    expect(findStatement('INSERT INTO user_sessions')).toBeUndefined()
  })
})

describe('wattclaw project retention state', () => {
  beforeEach(() => {
    resetDbMock()
  })

  it('aggregates restored state by project across users', () => {
    dbMock.db.prepare.mockImplementation((sql) => {
      const stmt = {
        sql,
        get: vi.fn(),
        all: vi.fn(() => sql.includes('GROUP BY project_id')
          ? [{ project_id: 'p-a', last_accessed_at: 200, restored_at: 100 }]
          : []),
        run: vi.fn(() => ({ changes: 1 })),
      }
      dbMock.statements.push(stmt)
      return stmt
    })

    expect(userManager.getWattClawProjectAccessStatesForRetention()).toEqual(new Map([
      ['p-a', { lastAccessedAt: 200, restoredAt: 100 }],
    ]))

    expect(findStatement('GROUP BY project_id').sql).toContain('MAX(restored_at)')
  })
})
