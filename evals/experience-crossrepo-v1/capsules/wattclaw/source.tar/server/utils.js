/**
 * Polling cache — lazily refreshes data on access,
 * reads return the cached value instantly (stale data allowed).
 *
 * @param {number} interval - Refresh interval in ms
 * @param {() => Promise<any>} fetcher - Async function that returns fresh data
 * @returns {{ getData: () => any, getFreshData: () => Promise<any>, refresh: () => Promise<void>, removeItem: (predicate: (item: any) => boolean) => void }}
 */
export function createPollingCache(interval, fetcher) {
  let data = null
  let refreshing = false
  let lastRefresh = 0
  let refreshPromise = null

  async function refresh() {
    if (refreshing) {
      return refreshPromise
    }
    refreshing = true
    refreshPromise = (async () => {
      try {
        let newData = await fetcher()
        if (newData) {
          data = newData
        }
      } catch (err) {
        console.error('[PollingCache] refresh failed:', err.message)
      } finally {
        lastRefresh = Date.now()
        refreshing = false
        refreshPromise = null
      }
    })()
    return refreshPromise
  }

  function shouldRefresh() {
    return !refreshing && (data === null || Date.now() - lastRefresh > interval)
  }

  return {
    getData() {
      if (shouldRefresh()) {
        refresh() // fire-and-forget
      }
      return data
    },
    async getFreshData() {
      if (refreshPromise || shouldRefresh()) {
        await (refreshPromise || refresh())
      }
      return data
    },
    refresh,
    removeItem(predicate) {
      if (Array.isArray(data)) {
        data = data.filter(item => !predicate(item))
      }
    }
  }
}
