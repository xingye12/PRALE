import { describe, expect, it } from 'vitest'
import { resolveGeneratedFileCandidatePath } from './generated-file-path.js'

describe('resolveGeneratedFileCandidatePath', () => {
  const workspace = '/home/wattman/.wattclaw/user/report-agent'

  it('resolves a leading-slash downloads path from the workspace root', () => {
    expect(resolveGeneratedFileCandidatePath(workspace, '/downloads/report.pdf')).toEqual({
      candidatePath: `${workspace}/downloads/report.pdf`,
      pathMode: 'workspace-root-relative',
    })
  })

  it('resolves an ordinary relative path from the workspace root', () => {
    expect(resolveGeneratedFileCandidatePath(workspace, 'downloads/report.pdf')).toEqual({
      candidatePath: `${workspace}/downloads/report.pdf`,
      pathMode: 'workspace-relative',
    })
  })

  it('preserves an absolute path already inside the workspace', () => {
    const absolutePath = `${workspace}/downloads/report.pdf`
    expect(resolveGeneratedFileCandidatePath(workspace, absolutePath)).toEqual({
      candidatePath: absolutePath,
      pathMode: 'workspace-absolute',
    })
  })
})
