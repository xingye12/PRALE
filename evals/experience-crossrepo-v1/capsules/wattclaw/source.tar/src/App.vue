<script setup lang="ts">
import { computed, watch, onMounted } from "vue";
import { useRoute } from "vue-router";
import {
  NConfigProvider,
  NMessageProvider,
  NDialogProvider,
  NNotificationProvider,
  zhCN,
  dateZhCN,
} from "naive-ui";
import { useI18n } from "vue-i18n";
import { useTheme } from "@/composables/useTheme";

const { theme, themeOverrides } = useTheme();
const route = useRoute();
const { t } = useI18n();

const naiveLocale = zhCN;
const naiveDateLocale = dateZhCN;

watch(
  () => route.meta.titleKey as string | undefined,
  (titleKey) => {
    if (typeof document === "undefined") return;
    if (!titleKey) {
      document.title = "WattClaw";
      return;
    }
    const title = t(titleKey);
    document.title = `${title} - WattClaw`;
  },
  { immediate: true },
);

onMounted(() => {
  // bfcache 恢复时内存态是离开时的快照（可能已登出），以 localStorage 持久 token 为真值：
  // 已登出则整页重载，让路由守卫基于清空的 token 重新拦截到登录页（PC/移动通用）
  window.addEventListener("pageshow", (event: PageTransitionEvent) => {
    if (event.persisted && !localStorage.getItem("auth_token")) {
      window.location.reload();
    }
  });
});
</script>

<template>
  <NConfigProvider
    :theme="theme"
    :theme-overrides="themeOverrides"
    :locale="naiveLocale"
    :date-locale="naiveDateLocale"
  >
    <NNotificationProvider>
      <NMessageProvider>
        <NDialogProvider>
          <RouterView />
        </NDialogProvider>
      </NMessageProvider>
    </NNotificationProvider>
  </NConfigProvider>
</template>
