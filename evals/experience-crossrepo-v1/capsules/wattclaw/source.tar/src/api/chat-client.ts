/**
 * ChatClient — 类型安全的 Chat HTTP 客户端
 *
 * 直接通过 REST 端点与后端通信，无 RPC 封装、无参数猜测、无 fallback。
 * 每个方法对应一个专用端点，请求/响应类型从 OpenClaw Gateway 契约推导。
 */

import type {
  ChatSendRequest,
  ChatSendResponse,
  ChatAbortRequest,
  ChatAbortResponse,
  ChatHistoryResponse,
} from './types/chat-contract'

/** Get the base path for API calls (e.g. '/wattclaw/' in production, '/' in dev) */
function getBasePath(): string {
  const base = (import.meta.env.BASE_URL as string) || '/'
  return base.endsWith('/') ? base : base + '/'
}

export class ChatClientError extends Error {
  readonly status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'ChatClientError'
    this.status = status
  }
}

export interface ChatClientOptions {
  baseUrl?: string
  getToken: () => string | null
}

export class ChatClient {
  private readonly baseUrl: string
  private readonly getToken: () => string | null

  constructor(options: ChatClientOptions) {
    this.baseUrl = (options.baseUrl || getBasePath()).replace(/\/$/, '')
    this.getToken = options.getToken
  }

  private async request<T>(path: string, init: RequestInit): Promise<T> {
    const url = `${this.baseUrl}/api/chat/${path}`
    const token = this.getToken()
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    }
    const response = await fetch(url, { ...init, headers })

    if (response.status === 401) {
      throw new ChatClientError('Unauthorized', 401)
    }

    const body = await response.json()
    if (!body.ok) {
      throw new ChatClientError(
        body.error?.message || `Chat API error: ${path}`,
        response.status,
      )
    }
    return body.payload as T
  }

  /**
   * 发送消息到 session
   * POST /api/chat/send
   */
  async send(
    params: Omit<ChatSendRequest, 'idempotencyKey'> & { idempotencyKey?: string },
  ): Promise<ChatSendResponse> {
    const idempotencyKey =
      params.idempotencyKey ||
      `web-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
    return this.request<ChatSendResponse>('send', {
      method: 'POST',
      body: JSON.stringify({ ...params, idempotencyKey }),
    })
  }

  /**
   * 中止活跃的 agent run
   * POST /api/chat/abort
   */
  async abort(params: ChatAbortRequest): Promise<ChatAbortResponse> {
    return this.request<ChatAbortResponse>('abort', {
      method: 'POST',
      body: JSON.stringify(params),
    })
  }

  /**
   * 获取会话历史消息
   * GET /api/chat/history
   */
  async history(
    sessionKey: string,
    limit?: number,
    cursor?: string | null,
  ): Promise<ChatHistoryResponse> {
    const qs = new URLSearchParams({ sessionKey })
    if (limit !== undefined) {
      qs.set('limit', String(limit))
    }
    if (cursor) {
      qs.set('cursor', cursor)
    }
    return this.request<ChatHistoryResponse>(`history?${qs}`, {
      method: 'GET',
    })
  }
}
