import type { CronJob, CronRunLogEntry, CronStatus, CronUpsertParams } from '@/api/types'
import { apiPath } from '@/utils/api-path'

export interface CronOverviewResponse {
  jobs: CronJob[]
  status: CronStatus | null
}

export class CronClientError extends Error {
  readonly status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'CronClientError'
    this.status = status
  }
}

export interface CronClientOptions {
  getToken: () => string | null
}

interface CronEnvelope<T> {
  ok: boolean
  payload?: T
  error?: {
    message?: string
  } | string
}

function getErrorMessage(error: CronEnvelope<unknown>['error'], fallback: string): string {
  if (typeof error === 'string') return error
  return error?.message || fallback
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' ? value as Record<string, unknown> : {}
}

function asString(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback
}

function asNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function asBoolean(value: unknown, fallback = false): boolean {
  return typeof value === 'boolean' ? value : fallback
}

function normalizeList<T>(payload: unknown, keys: string[]): T[] {
  if (Array.isArray(payload)) return payload as T[]
  const row = asRecord(payload)
  for (const key of keys) {
    const value = row[key]
    if (Array.isArray(value)) return value as T[]
  }
  return []
}

function normalizeSessionKey(value: string): string {
  let sessionKey = value.trim()
  while (sessionKey.startsWith('session:')) {
    sessionKey = sessionKey.slice('session:'.length).trim()
  }
  return sessionKey
}

function sessionKeyFromTarget(sessionTarget: string): string {
  return sessionTarget.startsWith('session:') ? normalizeSessionKey(sessionTarget) : ''
}

function canonicalSessionTarget(sessionTarget: string, sessionKey: string): string {
  if (sessionTarget === 'main' || sessionTarget === 'isolated') return sessionTarget
  return sessionKey ? `session:${sessionKey}` : sessionTarget
}

function normalizeCronJob(value: unknown): CronJob {
  const row = asRecord(value)
  const sessionTarget = asString(row.sessionTarget)
  const sessionKey = normalizeSessionKey(asString(row.sessionKey)) || sessionKeyFromTarget(sessionTarget)
  const state = asRecord(row.state)
  const scheduleObject = row.schedule && typeof row.schedule === 'object'
    ? row.schedule
    : row.scheduleObj
  const scheduleRow = asRecord(scheduleObject)
  const scheduleText = asString(row.scheduleText || row.cron || row.expression)
    || asString(row.schedule)
    || asString(scheduleRow.expr || scheduleRow.expression || scheduleRow.cron)

  return {
    id: asString(row.id || row.jobId || row.taskId || row.name),
    agentId: asString(row.agentId || row.agent) || undefined,
    name: asString(row.name || row.title || row.id, 'unnamed'),
    description: asString(row.description) || undefined,
    enabled: asBoolean(row.enabled, true),
    deleteAfterRun: asBoolean(row.deleteAfterRun),
    createdAtMs: asNumber(row.createdAtMs || row.createdAt || row.created),
    updatedAtMs: asNumber(row.updatedAtMs || row.updatedAt || row.updated),
    scheduleObj: scheduleObject as CronJob['scheduleObj'],
    sessionTarget: canonicalSessionTarget(sessionTarget, sessionKey) || undefined,
    sessionKey: sessionKey || undefined,
    wakeMode: row.wakeMode === 'now' ? 'now' : row.wakeMode === 'next-heartbeat' ? 'next-heartbeat' : undefined,
    payload: row.payload as CronJob['payload'],
    delivery: row.delivery as CronJob['delivery'],
    state: row.state as CronJob['state'],
    schedule: scheduleText,
    command: asString(row.command || asRecord(row.payload).text || asRecord(row.payload).message) || undefined,
    timezone: asString(row.timezone || scheduleRow.timezone || scheduleRow.tz) || undefined,
    nextRun: asString(row.nextRun || row.nextRunAt || row.nextRunAtMs || state.nextRunAtMs) || undefined,
    lastRun: asString(row.lastRun || row.lastRunAt || row.lastRunAtMs || state.lastRunAtMs) || undefined,
  }
}

function normalizeCronStatus(payload: unknown): CronStatus | null {
  if (payload === null || payload === undefined) return null
  const row = asRecord(payload)
  return {
    enabled: asBoolean(row.enabled, true),
    jobs: asNumber(row.jobs || row.jobCount || row.total) || 0,
    running: asNumber(row.running || row.runningJobs),
    nextWakeAtMs: asNumber(row.nextWakeAtMs || row.nextWake || row.nextRunAtMs),
  }
}

function normalizeCronRun(value: unknown): CronRunLogEntry {
  const row = asRecord(value)
  const sessionKey = normalizeSessionKey(asString(row.sessionKey || row.key))
    || sessionKeyFromTarget(asString(row.sessionTarget))
  return {
    ts: asNumber(row.ts || row.timestamp || row.time) || 0,
    jobId: asString(row.jobId || row.id || row.taskId),
    action: row.action === 'finished' ? 'finished' : undefined,
    status: row.status === 'ok' || row.status === 'error' || row.status === 'skipped' ? row.status : undefined,
    error: asString(row.error) || undefined,
    summary: asString(row.summary || row.message) || undefined,
    sessionId: asString(row.sessionId) || undefined,
    sessionKey: sessionKey || undefined,
    runAtMs: asNumber(row.runAtMs || row.startedAtMs),
    durationMs: asNumber(row.durationMs),
    nextRunAtMs: asNumber(row.nextRunAtMs),
  }
}

export class CronClient {
  private readonly getToken: () => string | null

  constructor(options: CronClientOptions) {
    this.getToken = options.getToken
  }

  private async request<T>(path: string, init: RequestInit): Promise<T> {
    const token = this.getToken()
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    }

    const response = await fetch(apiPath(`/api/cron/${path}`), { ...init, headers })
    if (response.status === 401) {
      throw new CronClientError('Unauthorized', 401)
    }

    const body = (await response.json()) as CronEnvelope<T>
    if (!body.ok) {
      throw new CronClientError(
        getErrorMessage(body.error, `Cron API error: ${path}`),
        response.status,
      )
    }

    return body.payload as T
  }

  async getOverview(): Promise<CronOverviewResponse> {
    const overview = await this.request<{ jobs: unknown[]; status: unknown }>('overview', { method: 'GET' })
    return {
      jobs: overview.jobs.map(normalizeCronJob).filter(item => !!item.id),
      status: normalizeCronStatus(overview.status),
    }
  }

  async listJobs(): Promise<CronJob[]> {
    const payload = await this.request<unknown>('jobs', { method: 'GET' })
    return normalizeList<unknown>(payload, ['items', 'list', 'data', 'jobs', 'tasks', 'crons', 'schedules'])
      .map(normalizeCronJob)
      .filter(item => !!item.id)
  }

  async getStatus(): Promise<CronStatus | null> {
    return normalizeCronStatus(await this.request<unknown>('status', { method: 'GET' }))
  }

  async listRuns(jobId: string, limit = 50): Promise<CronRunLogEntry[]> {
    const qs = new URLSearchParams({ limit: String(limit) })
    const payload = await this.request<unknown>(`jobs/${encodeURIComponent(jobId)}/runs?${qs}`, {
      method: 'GET',
    })
    return normalizeList<unknown>(payload, ['entries', 'items', 'list', 'data', 'runs', 'history'])
      .map(normalizeCronRun)
      .filter(item => !!item.jobId)
  }

  createJob(params: CronUpsertParams): Promise<unknown> {
    return this.request<unknown>('jobs', {
      method: 'POST',
      body: JSON.stringify(params),
    })
  }

  updateJob(id: string, params: Partial<CronUpsertParams>): Promise<unknown> {
    return this.request<unknown>(`jobs/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify({ id, ...params }),
    })
  }

  deleteJob(id: string): Promise<unknown> {
    return this.request<unknown>(`jobs/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    })
  }

  runJob(id: string, mode: 'force' | 'due' = 'force'): Promise<unknown> {
    return this.request<unknown>(`jobs/${encodeURIComponent(id)}/run`, {
      method: 'POST',
      body: JSON.stringify({ mode }),
    })
  }
}
