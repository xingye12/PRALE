export interface AgentTemplate {
  id: string
  category: string
  name: string
  avatar: string
  description: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  bootstrapMd?: string
  tagline: string
  prompts: string[]
}

export interface AgentCategory {
  id: string
  name: string
  icon: string
  templates: AgentTemplate[]
}

export interface AgentTeamMember {
  id: string                    // gateway_agent_id
  workspace?: string
  name: string
  description: string
  avatar: string
  emoji?: string
  avatarUrl?: string
  model: string
  category: string
  templateId: string
  status: string
  createdBy: string
  createdAt: number
  updatedAt: number
  lastActiveAt?: number
  ownerName?: string            // admin view: which user owns this agent
}
