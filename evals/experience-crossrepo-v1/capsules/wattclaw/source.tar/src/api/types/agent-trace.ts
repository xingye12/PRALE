/**
 * Agent Trajectory Trace Types
 *
 * Turn-centric model captured by the wattclaw-prompt-capture plugin. One turn
 * (runId) represents a full agent run — from the user message to the completed
 * reply — and contains an ordered list of model calls and tool calls, each with
 * absolute timestamps for Gantt-style visualization.
 */

export interface ModelCallEntry {
  index: number
  startedAt: string
  endedAt: string | null
  durationMs: number | null
  model: string | null
  provider: string | null
  systemPrompt: string | null
  prompt: string | null
  historyMessages: Array<{ role: string; content: string | unknown }>
  toolCount: number | null
  output: string | null
  thinking: string | null
  tokenInput: number | null
  tokenOutput: number | null
  tokenCache: number | null
  finishReason: string | null
  requestId: string | null
  apiType: string | null
  status: 'running' | 'completed' | 'failed'
}

export interface ToolCallEntry {
  index: number
  toolName: string
  startedAt: string
  endedAt: string | null
  durationMs: number | null
  params: unknown
  result: unknown
  error: string | null
  status: 'running' | 'completed' | 'failed'
}

export interface AgentTurnTrace {
  runId: string
  sessionKey: string
  agentId: string | null
  startedAt: string
  endedAt: string | null
  userPrompt: string | null
  assistantOutput: string | null
  modelCalls: ModelCallEntry[]
  toolCalls: ToolCallEntry[]
  tokenUsage: {
    input: number | null
    output: number | null
    cache: number | null
  }
  durationMs: number | null
  status: 'running' | 'completed' | 'failed'
  createdAt: number
}

export interface AgentTurnListResult {
  turns: AgentTurnTrace[]
  count: number
}

export interface AgentTraceStatsResult {
  stats: {
    totalTurns: number
    completedTurns: number
    failedTurns: number
    avgDurationMs: number
    totalModelCalls: number
    totalToolCalls: number
  }
}
