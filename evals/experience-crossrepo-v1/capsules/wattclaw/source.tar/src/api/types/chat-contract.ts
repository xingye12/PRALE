/**
 * Chat API 类型契约
 *
 * 从 OpenClaw Gateway 源码提取的精确接口定义。
 * 所有字段名与 Gateway `chat.send` / `chat.abort` / `chat.history` 方法一一对应，
 * 不存在猜测性字段或 fallback 候选。
 *
 * 源码参考:
 *   - openclaw/src/gateway/server-methods/chat.ts (chat.send handler, line 2346)
 *   - openclaw/src/gateway/server-methods/chat.ts (chat.abort handler, line 2241)
 *   - openclaw/src/gateway/server-methods/chat.ts (chat.history handler, line 2137)
 *   - openclaw/src/gateway/server-chat.ts (event broadcasting, line 546+)
 */

import type { ChatMessage } from './index'

// ─── chat.send ──────────────────────────────────────────────

export interface ChatSendRequest {
  /** 目标 session — REQUIRED */
  sessionKey: string
  /** 用户消息文本 — REQUIRED */
  message: string
  /** 幂等 key，防止重复提交 — REQUIRED */
  idempotencyKey: string
  /** 模型覆盖（provider/model 格式） */
  model?: string
  /** 思考级别覆盖 ("on" | "off" | "low" | "high") */
  thinking?: string
  /** 快速模式 */
  fastMode?: boolean
  /** 是否投递出站消息 */
  deliver?: boolean
  /** Agent 运行超时 (ms) */
  timeoutMs?: number
  /** 文件附件 */
  attachments?: ChatAttachment[]
}

export interface ChatAttachment {
  type?: string
  mimeType?: string
  fileName?: string
  content?: unknown
}

export type ChatSendStatus = 'started' | 'in_flight'

export interface ChatSendResponse {
  runId: string
  status: ChatSendStatus
}

// ─── chat.abort ─────────────────────────────────────────────

export interface ChatAbortRequest {
  /** 目标 session — REQUIRED */
  sessionKey: string
  /** 指定要中止的 runId（可选，不传则中止该 session 所有活跃 run） */
  runId?: string
}

export interface ChatAbortResponse {
  ok: boolean
  aborted: boolean
  runIds: string[]
}

// ─── chat.history ───────────────────────────────────────────

export interface ChatHistoryRequest {
  sessionKey: string
  /** 最大消息数（默认 200，硬上限 1000） */
  limit?: number
  /** 单条消息最大字符数 */
  maxChars?: number
}

export interface ChatHistoryResponse {
  sessionKey: string
  sessionId?: string
  messages: ChatMessage[]
  thinkingLevel?: string
  fastMode?: boolean
  verboseLevel?: string
  /** 前端已从 /api/chat/history REST 端点获取的分页信息 */
  cursor?: string | null
  hasMore?: boolean
}

// ─── Gateway SSE Event Payloads ─────────────────────────────

/**
 * Gateway "chat" channel 事件载荷
 * 事件名: "chat"
 */
export type ChatEventState = 'delta' | 'final' | 'error' | 'aborted'

export interface ChatEventPayload {
  state: ChatEventState
  runId: string
  sessionKey: string
  seq?: number
  /** delta 状态时的增量文本 */
  deltaText?: string
  /** 如果 true，替换之前的文本而非追加 */
  replace?: boolean
  /** assistant 消息对象 */
  message?: {
    role: string
    content: Array<{ type: string; text: string }>
    timestamp: number
  }
  /** error 状态时的错误信息 */
  errorMessage?: string
  /** aborted 状态时的停止原因 */
  stopReason?: string
}

/**
 * Gateway "agent" channel 事件载荷
 * 事件名: "agent"
 */
export type AgentStreamType = 'lifecycle' | 'assistant' | 'thinking' | 'tool' | 'error' | 'compaction'

export interface AgentEventPayload {
  stream: AgentStreamType
  data: Record<string, unknown>
  runId: string
  sessionKey?: string
  seq?: number
  ts?: number
}
