export interface FeishuAuthConfig {
  enabled: boolean
}

export interface FeishuAuthorizeResponse {
  url: string
}

export interface FeishuCallbackRequest {
  code: string
  state: string
}

export interface FeishuCallbackResponse {
  ok: boolean
  token?: string
  user?: import('./index').User
  expiresAt?: number
  error?: string
}
