export interface Session {
  key: string
  agentId: string
  channel: string
  peer: string
  peerId?: string
  messageCount: number
  lastActivity: string
  model?: string
  tokenUsage?: TokenUsage
  label?: string
  displayTitle?: string
  isStreaming?: boolean
  sessionKind?: 'cron'
  cronJobId?: string
  cronJobName?: string
}

export interface SessionDetail extends Session {
  transcript: TranscriptMessage[]
  tokenUsage?: TokenUsage
  directives?: string[]
  _truncated?: boolean
  _totalMessages?: number
}

export interface TranscriptMessage {
  role: 'user' | 'assistant' | 'tool' | 'system'
  content: string
  timestamp: string
  name?: string
  input?: unknown
  output?: unknown
  tokens?: { input: number; output: number }
}

export interface TokenUsage {
  totalInput: number
  totalOutput: number
  cacheRead?: number
  cacheWrite?: number
  cacheReadCost?: number
  cacheWriteCost?: number
}

export interface SessionExport {
  key: string
  transcript: TranscriptMessage[]
  exportedAt: string
}
