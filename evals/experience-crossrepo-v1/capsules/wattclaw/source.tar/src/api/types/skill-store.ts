export interface SkillStoreSkill {
  id: string
  name: string
  description: string
  icon: string
  icon_color: string
  category: string
  usage: string
  version: string
  type: string
  installed: boolean
  gateway_name?: string
  readme?: string
  source?: string
  agents: SkillStoreAgentSkill[]
  created_at: string
  updated_at: string
}

export interface SkillStoreAgentSkill {
  agent_id: string
  agent_name: string
  agent_avatar: string
  enabled: boolean
}

export interface SkillStoreAgent {
  id: string
  name: string
  avatar: string
  templateId?: string
  avatarColor: string
  skills: SkillStoreAgentSkillDetail[]
}

export interface SkillStoreAgentSkillDetail {
  skillId: string
  skillName: string
  skillIcon: string
  skillIconColor: string
  enabled: boolean
}

export type SkillStoreCategory = 'all' | 'featured' | 'general' | 'creative'

export type DisplaySkill = SkillStoreSkill & { isGlobal: boolean }
