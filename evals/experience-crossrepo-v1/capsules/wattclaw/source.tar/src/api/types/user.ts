export interface User {
  id: string
  username: string
  role: 'admin' | 'user'
  display_name: string | null
  email: string | null
  avatar: string | null
  status: 'active' | 'disabled'
  settings: Record<string, unknown>
  password_changed_at: number | null
  created_at: number
  updated_at: number
}

export interface UserAgent {
  id: string
  user_id: string
  gateway_agent_id: string | null
  name: string
  description: string | null
  config: Record<string, unknown>
  system_prompt: string | null
  model: string | null
  status: 'active' | 'inactive'
  created_at: number
  updated_at: number
}

export interface UserSession {
  id: string
  user_id: string
  session_key: string
  agent_id: string | null
  label: string | null
  channel: string | null
  created_at: number
  updated_at: number
}

export type ChannelType = 'feishu' | 'wecom' | 'dingtalk' | 'telegram' | 'slack' | 'discord' | 'custom'

export interface UserChannel {
  id: string
  user_id: string
  channel_type: ChannelType
  name: string
  config: Record<string, unknown>
  agent_id: string | null
  status: 'active' | 'inactive' | 'error'
  last_sync_at: number | null
  error_message: string | null
  created_at: number
  updated_at: number
}

export interface ChannelTypeConfig {
  feishu: {
    appId: string
    appSecret: string
    verificationToken: string
    encryptKey: string
  }
  wecom: {
    corpId: string
    agentId: string
    secret: string
    token: string
    encodingAesKey: string
  }
  dingtalk: {
    appKey: string
    appSecret: string
    token: string
    aesKey: string
  }
  custom: Record<string, string>
}

export interface LoginResponse {
  ok: boolean
  token?: string
  user?: User
  expiresAt?: number
  error?: string
}

export interface RegisterParams {
  username: string
  password: string
  displayName?: string
  email?: string
}

export interface CreateUserParams {
  username: string
  password: string
  role?: 'admin' | 'user'
  displayName?: string
  email?: string
}

export interface UpdateUserParams {
  role?: 'admin' | 'user'
  status?: 'active' | 'disabled'
  displayName?: string
  email?: string
  password?: string
}

export interface CreateUserAgentParams {
  gatewayAgentId?: string
  name: string
  description?: string
  config?: Record<string, unknown>
  systemPrompt?: string
  model?: string
}

export interface UpdateUserAgentParams {
  gatewayAgentId?: string
  name?: string
  description?: string
  config?: Record<string, unknown>
  systemPrompt?: string
  model?: string
  status?: 'active' | 'inactive'
}

export interface CreateUserChannelParams {
  channelType: ChannelType
  name: string
  config?: Record<string, unknown>
  agentId: string
  status?: 'active' | 'inactive'
}

export interface UpdateUserChannelParams {
  name?: string
  config?: Record<string, unknown>
  agentId?: string
  status?: 'active' | 'inactive' | 'error'
  errorMessage?: string
}
