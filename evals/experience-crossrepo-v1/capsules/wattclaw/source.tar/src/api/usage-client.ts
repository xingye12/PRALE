/**
 * UsageClient — 类型安全的 Sessions Usage HTTP 客户端
 *
 * 无状态 BFF 代理：前端 → WattClaw GET /api/sessions/usage → OpenClaw Gateway
 * 无缓存、无轮询、无 RPC，每次调用实时穿透到 Gateway。
 */

import type { SessionsUsageParams, SessionsUsageResultWithUserUsage } from './types'

function getBasePath(): string {
  const base = (import.meta.env.BASE_URL as string) || '/'
  return base.endsWith('/') ? base : base + '/'
}

export interface UsageClientOptions {
  baseUrl?: string
  getToken: () => string | null
}

export class UsageClientError extends Error {
  readonly status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'UsageClientError'
    this.status = status
  }
}

export class UsageClient {
  private readonly baseUrl: string
  private readonly getToken: () => string | null

  constructor(options: UsageClientOptions) {
    this.baseUrl = (options.baseUrl || getBasePath()).replace(/\/$/, '')
    this.getToken = options.getToken
  }

  async getSessionsUsage(params?: SessionsUsageParams & { include?: string }): Promise<SessionsUsageResultWithUserUsage> {
    const qs = new URLSearchParams()
    if (params?.key?.trim()) qs.set('key', params.key.trim())
    if (params?.startDate?.trim()) qs.set('startDate', params.startDate.trim())
    if (params?.endDate?.trim()) qs.set('endDate', params.endDate.trim())
    if (typeof params?.limit === 'number' && Number.isFinite(params.limit) && params.limit > 0) {
      qs.set('limit', String(Math.floor(params.limit)))
    }
    if (params?.include) qs.set('include', params.include)

    const url = `${this.baseUrl}/api/sessions/usage${qs.toString() ? '?' + qs.toString() : ''}`
    const token = this.getToken()
    const headers: Record<string, string> = {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    }

    const response = await fetch(url, { method: 'GET', headers })

    if (response.status === 401) {
      throw new UsageClientError('Unauthorized', 401)
    }

    const body = await response.json()
    if (!body.ok) {
      throw new UsageClientError(
        body.error?.message || `Usage API error`,
        response.status,
      )
    }
    // Attach userUsage from include=userUsage response (admin only)
    const result = body.payload as SessionsUsageResultWithUserUsage
    if (body.userUsage) {
      result._userUsage = body.userUsage
    }
    return result
  }
}
