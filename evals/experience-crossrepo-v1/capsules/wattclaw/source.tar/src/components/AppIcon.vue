<script setup lang="ts">
import { computed } from 'vue'
import { getIconUrl } from '@/utils/icon-map'

const props = withDefaults(defineProps<{
  name: string
  size?: number | string
}>(), {
  size: 24,
})

const iconUrl = computed(() => getIconUrl(props.name))
const sizePx = computed(() => `${props.size}px`)
</script>

<template>
  <img
    v-if="iconUrl"
    :src="iconUrl"
    :alt="name"
    class="app-icon"
    :style="{ width: sizePx, height: sizePx }"
  />
</template>

<style scoped>
.app-icon {
  object-fit: contain;
  flex-shrink: 0;
  display: inline-block;
}
</style>
