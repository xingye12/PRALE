<script setup lang="ts">
import { ref, computed } from 'vue'
import { NModal } from 'naive-ui'
import { getAllAvatarUrls } from '@/utils/agent-avatar'
import { isImageAvatar } from '@/utils/agent-avatar'
import { useAuthStore } from '@/stores/auth'

const props = withDefaults(defineProps<{
  modelValue: string
  size?: number
}>(), {
  size: 80,
})

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const authStore = useAuthStore()
const showModal = ref(false)
const uploading = ref(false)
const dragOver = ref(false)

const presetAvatars = getAllAvatarUrls().slice(0, 12)

const displaySrc = computed(() => {
  if (isImageAvatar(props.modelValue)) return props.modelValue
  const first = presetAvatars[0]
  return first || ''
})

const isEmoji = computed(() => !isImageAvatar(props.modelValue) && props.modelValue)

function selectAvatar(url: string) {
  emit('update:modelValue', url)
  showModal.value = false
}

async function handleUpload(file: File) {
  if (!file) return
  uploading.value = true
  try {
    const formData = new FormData()
    formData.append('image', file)
    const token = authStore.getToken()
    const res = await fetch('/api/avatar-images/upload', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    })
    const data = await res.json()
    if (data.ok && data.url) {
      emit('update:modelValue', data.url)
      showModal.value = false
    }
  } catch (e) {
    console.error('[AvatarEditor] upload failed:', e)
  } finally {
    uploading.value = false
  }
}

function onFileInput(e: Event) {
  const input = e.target as HTMLInputElement
  if (input.files?.[0]) handleUpload(input.files[0])
}

function onDrop(e: DragEvent) {
  dragOver.value = false
  const file = e.dataTransfer?.files?.[0]
  if (file && file.type.startsWith('image/')) handleUpload(file)
}

function removeCustom() {
  if (presetAvatars[0]) {
    emit('update:modelValue', presetAvatars[0])
  }
}
</script>

<template>
  <div class="avatar-editor">
    <!-- Trigger -->
    <div
      class="avatar-trigger"
      :style="{ width: size + 'px', height: size + 'px' }"
      @click="showModal = true"
    >
      <img v-if="displaySrc" v-avatar-fallback :src="displaySrc" alt="avatar" class="avatar-image" draggable="false" />
      <span v-else class="avatar-emoji">{{ modelValue || '🤖' }}</span>
      <div class="avatar-overlay">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
          <circle cx="12" cy="13" r="4" />
        </svg>
      </div>
    </div>

    <!-- Modal -->
    <NModal :show="showModal" @update:show="showModal = $event" :mask-closable="true">
      <div class="editor-modal">
        <div class="modal-header">
          <h3>选择头像</h3>
          <button class="modal-close" @click="showModal = false">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <!-- Upload Area -->
        <div
          class="upload-area"
          :class="{ dragover: dragOver, uploading }"
          @dragover.prevent="dragOver = true"
          @dragleave.prevent="dragOver = false"
          @drop.prevent="onDrop"
          @click="($refs.fileInput as HTMLInputElement)?.click()"
        >
          <input
            ref="fileInput"
            type="file"
            accept="image/png,image/jpeg,image/gif,image/webp,image/bmp"
            style="display: none"
            @change="onFileInput"
          />
          <template v-if="uploading">
            <div class="upload-spinner" />
            <p>上传中...</p>
          </template>
          <template v-else>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            <p>点击或拖拽上传图片</p>
            <span>支持 PNG、JPG、GIF、WebP，最大 10MB</span>
          </template>
        </div>

        <!-- Preset Grid -->
        <div class="preset-section">
          <p class="preset-title">预设头像</p>
          <div class="preset-grid">
            <div
              v-for="avatar in presetAvatars"
              :key="avatar"
              class="preset-item"
              :class="{ selected: modelValue === avatar }"
              @click="selectAvatar(avatar)"
            >
              <img :src="avatar" alt="preset" draggable="false" />
            </div>
          </div>
        </div>

        <!-- Remove Custom -->
        <div v-if="isImageAvatar(modelValue) && modelValue.startsWith('/api/avatar-images/')" class="remove-section">
          <button class="remove-btn" @click="removeCustom">恢复默认头像</button>
        </div>
      </div>
    </NModal>
  </div>
</template>

<style scoped>
.avatar-editor {
  display: inline-flex;
}

/* --- Trigger --- */
.avatar-trigger {
  position: relative;
  border-radius: 50%;
  cursor: pointer;
  overflow: hidden;
  border: 3px solid var(--bg-card, #fff);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.15s, box-shadow 0.15s;
  background: var(--bg-surface, #f3f4f6);
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-trigger:hover {
  transform: scale(1.03);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

.avatar-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.avatar-emoji {
  font-size: calc(var(--size, 80px) * 0.5);
}

.avatar-overlay {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  opacity: 0;
  transition: opacity 0.2s;
}

.avatar-trigger:hover .avatar-overlay {
  opacity: 1;
}

/* --- Modal --- */
.editor-modal {
  background: var(--bg-card, #fff);
  border-radius: 16px;
  padding: 24px;
  width: 420px;
  max-width: 90vw;
  max-height: 85vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.modal-header h3 {
  font-size: 17px;
  font-weight: 600;
  margin: 0;
  color: var(--text-primary, #1f2937);
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-secondary, #6b7280);
  padding: 4px;
  display: flex;
  align-items: center;
  border-radius: 6px;
  transition: background 0.15s;
}

.modal-close:hover {
  background: var(--bg-surface, #f3f4f6);
  color: var(--text-primary, #1f2937);
}

/* --- Upload Area --- */
.upload-area {
  border: 2px dashed var(--border-color, #e5e7eb);
  border-radius: 12px;
  padding: 28px 16px;
  text-align: center;
  cursor: pointer;
  transition: border-color 0.2s, background 0.2s;
  color: var(--text-secondary, #6b7280);
  margin-bottom: 20px;
}

.upload-area:hover,
.upload-area.dragover {
  border-color: var(--primary, #3b82f6);
  background: var(--accent-bg, rgba(59, 130, 246, 0.04));
}

.upload-area.uploading {
  pointer-events: none;
  opacity: 0.7;
}

.upload-area svg {
  margin-bottom: 8px;
  color: var(--text-tertiary, #9ca3af);
}

.upload-area p {
  margin: 4px 0 2px;
  font-size: 14px;
  color: var(--text-primary, #1f2937);
}

.upload-area span {
  font-size: 12px;
  color: var(--text-tertiary, #9ca3af);
}

.upload-spinner {
  width: 24px;
  height: 24px;
  border: 2.5px solid var(--border-color, #e5e7eb);
  border-top-color: var(--primary, #3b82f6);
  border-radius: 50%;
  margin: 0 auto 8px;
  animation: spin 0.6s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* --- Presets --- */
.preset-section {
  margin-bottom: 16px;
}

.preset-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary, #6b7280);
  margin: 0 0 10px;
}

.preset-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 8px;
}

.preset-item {
  aspect-ratio: 1;
  border-radius: 50%;
  cursor: pointer;
  overflow: hidden;
  border: 2.5px solid transparent;
  transition: border-color 0.15s, transform 0.15s;
  padding: 2px;
}

.preset-item img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
}

.preset-item:hover {
  border-color: var(--border-color, #e5e7eb);
  transform: scale(1.05);
}

.preset-item.selected {
  border-color: var(--primary, #3b82f6);
  background: rgba(59, 130, 246, 0.06);
}

/* --- Remove --- */
.remove-section {
  text-align: center;
  padding-top: 8px;
  border-top: 1px solid var(--border-color, #e5e7eb);
}

.remove-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 13px;
  color: var(--text-tertiary, #9ca3af);
  padding: 6px 12px;
  border-radius: 6px;
  transition: color 0.15s, background 0.15s;
}

.remove-btn:hover {
  color: #ef4444;
  background: rgba(239, 68, 68, 0.06);
}
</style>
