<script setup lang="ts">
interface Props {
  progress: number
  statusText: string
  subText: string
}

defineProps<Props>()
</script>

<template>
  <div class="create-progress">
    <div class="progress-labels">
      <span class="progress-status">{{ statusText }}</span>
      <span class="progress-sub">{{ subText }}</span>
    </div>
    <div class="progress-track">
      <div
        class="progress-fill"
        :style="{ width: `${Math.min(100, Math.max(0, progress))}%` }"
      />
    </div>
  </div>
</template>

<style scoped>
.create-progress {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.progress-labels {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
}

.progress-status {
  color: var(--text-primary, #1f2937);
  font-weight: 500;
}

.progress-sub {
  color: var(--text-secondary, #6b7280);
}

.progress-track {
  height: 6px;
  background: var(--border-color, #e5e7eb);
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #3b82f6, #60a5fa);
  border-radius: 3px;
  transition: width 0.3s ease;
}
</style>
