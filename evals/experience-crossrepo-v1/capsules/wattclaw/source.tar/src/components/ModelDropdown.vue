<script setup lang="ts">
import { ref, computed, watch, onUnmounted, Teleport } from 'vue'
import { useI18n } from 'vue-i18n'
import { useModelProviders } from '@/composables/useModelProviders'
import { useWorkspaceStore } from '@/stores/workspace'
import { useModelStore } from '@/stores/model'
import { getIconUrl } from '@/utils/icon-map'

type Variant = 'chip' | 'select'

const props = withDefaults(defineProps<{
  modelValue: string
  variant?: Variant
}>(), {
  variant: 'chip',
})

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const { modelList, loaded, fetchProviders } = useModelProviders()
const { t } = useI18n()
const workspaceStore = useWorkspaceStore()
const modelStore = useModelStore()

function getDisplayRemark(modelId: string, originalRemark: string): string {
  if (workspaceStore.isModelRateLimited(modelId)) return t('pages.workspace.chat.rateLimitedRemark')
  if (modelStore.isModelCongested(modelId)) return t('pages.chat.concurrency.congested')
  return originalRemark
}

function isUnavailableRemark(remark: string): boolean {
  return remark.trim() === '暂不可用'
}

function isModelOverloaded(modelId: string): boolean {
  return workspaceStore.isModelRateLimited(modelId)
}

function isModelCongested(modelId: string): boolean {
  return modelStore.isModelCongested(modelId)
}

const showDropdown = ref(false)
const hoveredModelId = ref<string | null>(null)
const hoverTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const leaveTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const descCardPos = ref({ top: 0 })
const descCardScreenPos = ref({ top: 0, left: 0 })
const selectPanelPos = ref({ top: 0, left: 0 })
const triggerRef = ref<HTMLElement | null>(null)

function updateSelectPanelPos() {
  if (!triggerRef.value) return
  const rect = triggerRef.value.getBoundingClientRect()
  selectPanelPos.value = { top: rect.bottom + 4, left: rect.left }
}

onUnmounted(() => {
  if (hoverTimer.value) clearTimeout(hoverTimer.value)
  if (leaveTimer.value) clearTimeout(leaveTimer.value)
  document.removeEventListener('click', onDocClick)
  document.removeEventListener('scroll', updateSelectPanelPos, true)
  window.removeEventListener('resize', updateSelectPanelPos)
})

const selectedOption = computed(() => {
  if (!props.modelValue) return undefined
  // 精确匹配
  const exact = modelList.value.find((m) => m.id === props.modelValue)
  if (exact) return exact
  // 处理 provider/model 格式：取最后一段后缀匹配
  const parts = props.modelValue.split('/')
  const lastPart = parts[parts.length - 1]
  return modelList.value.find((m) => m.modelId === lastPart || m.label === props.modelValue)
})

const displayLabel = computed(() => {
  const opt = selectedOption.value
  if (!opt) return props.modelValue || 'Agent'
  return opt.label || opt.id
})

const displayRemark = computed(() => {
  const id = selectedOption.value?.id
  if (id && workspaceStore.isModelRateLimited(id)) return t('pages.workspace.chat.rateLimitedRemark')
  if (id && modelStore.isModelCongested(id)) return t('pages.chat.concurrency.congested')
  return selectedOption.value?.remark || ''
})

const isSelectedOverloaded = computed(() => {
  return !!selectedOption.value?.id && workspaceStore.isModelRateLimited(selectedOption.value.id)
})

const isSelectedCongested = computed(() => {
  return !!selectedOption.value?.id && !isSelectedOverloaded.value && modelStore.isModelCongested(selectedOption.value.id)
})

const isSelectedUnavailable = computed(() => {
  return !isSelectedOverloaded.value && !isSelectedCongested.value && isUnavailableRemark(displayRemark.value)
})

const hasDescription = computed(() => {
  if (!hoveredModelId.value) return false
  const m = modelList.value.find((m) => m.id === hoveredModelId.value)
  return !!m?.description
})

const descContent = computed(() => {
  if (!hoveredModelId.value) return { label: '', description: '' }
  const m = modelList.value.find((m) => m.id === hoveredModelId.value)
  return {
    label: m?.label || m?.id || '',
    description: m?.description || '',
  }
})

function toggleDropdown(e: MouseEvent) {
  e.stopPropagation()
  showDropdown.value = !showDropdown.value
  if (showDropdown.value && props.variant === 'select') {
    updateSelectPanelPos()
  }
}

function selectModel(id: string) {
  emit('update:modelValue', id)
  showDropdown.value = false
}

function onItemEnter(modelId: string, e: MouseEvent) {
  if (leaveTimer.value) {
    clearTimeout(leaveTimer.value)
    leaveTimer.value = null
  }
  const target = e.currentTarget as HTMLElement
  const scrollEl = target.closest('.dropdown-scroll, .select-panel-scroll')
  const scrollTop = scrollEl ? scrollEl.scrollTop : 0
  descCardPos.value = { top: target.offsetTop - scrollTop }

  const rect = target.getBoundingClientRect()
  descCardScreenPos.value = { top: rect.top, left: rect.right + 8 }

  hoverTimer.value = setTimeout(() => {
    hoveredModelId.value = modelId
  }, 100)
}

function onItemLeave() {
  if (hoverTimer.value) {
    clearTimeout(hoverTimer.value)
    hoverTimer.value = null
  }
  leaveTimer.value = setTimeout(() => {
    hoveredModelId.value = null
  }, 200)
}

function onCardEnter() {
  if (leaveTimer.value) {
    clearTimeout(leaveTimer.value)
    leaveTimer.value = null
  }
}

function onCardLeave() {
  leaveTimer.value = setTimeout(() => {
    hoveredModelId.value = null
  }, 200)
}

function onDocClick(e: MouseEvent) {
  const target = e.target as HTMLElement
  if (!target.closest('.model-dropdown-root') && !target.closest('.select-panel-fixed')) {
    showDropdown.value = false
  }
}

watch(showDropdown, (val) => {
  if (val) {
    document.addEventListener('click', onDocClick)
    if (props.variant === 'select') {
      document.addEventListener('scroll', updateSelectPanelPos, true)
      window.addEventListener('resize', updateSelectPanelPos)
    }
  } else {
    document.removeEventListener('click', onDocClick)
    document.removeEventListener('scroll', updateSelectPanelPos, true)
    window.removeEventListener('resize', updateSelectPanelPos)
    hoveredModelId.value = null
  }
})

// Fetch providers on first mount
if (!loaded.value) fetchProviders()
</script>

<template>
  <div class="model-dropdown-root">
    <!-- Chip trigger (for ChatInput) -->
    <button
      v-if="variant === 'chip'"
      class="chip"
      :class="{ active: showDropdown }"
      @click="toggleDropdown"
    >
      <img
        v-if="selectedOption && getIconUrl(selectedOption.providerId)"
        :src="getIconUrl(selectedOption.providerId)"
        class="provider-icon"
        alt=""
        style="width: 16px; height: 16px"
      />
      <span v-else class="material-symbols-outlined" style="font-size:13px">smart_toy</span>
      <span class="chip-label" :class="{ overloaded: isSelectedOverloaded, congested: isSelectedCongested, unavailable: isSelectedUnavailable }">{{ displayRemark ? `${displayLabel}（${displayRemark}）` : displayLabel }}</span>
      <span class="chip-chevron">&#9662;</span>
    </button>

    <!-- Select trigger (for AgentEditPage) -->
    <button
      v-else
      ref="triggerRef"
      class="select-trigger"
      :class="{ active: showDropdown }"
      @click="toggleDropdown"
    >
      <img
        v-if="selectedOption && getIconUrl(selectedOption.providerId)"
        :src="getIconUrl(selectedOption.providerId)"
        class="provider-icon"
        alt=""
        style="width: 16px; height: 16px"
      />
      <span class="select-value">{{ displayRemark ? `${displayLabel}（${displayRemark}）` : (displayLabel || '选择模型') }}</span>
      <span class="select-arrow">&#9662;</span>
    </button>

    <!-- Dropdown panel (chip variant: inline absolute) -->
    <div v-if="showDropdown && variant === 'chip'" class="dropdown-panel">
      <div class="dropdown-scroll">
        <div
          v-for="model in modelList"
          :key="model.id"
          class="dd-item"
          :class="{ active: model.id === modelValue }"
          @click="selectModel(model.id)"
          @mouseenter="onItemEnter(model.id, $event)"
          @mouseleave="onItemLeave"
        >
          <img
            v-if="getIconUrl(model.providerId)"
            :src="getIconUrl(model.providerId)"
            class="provider-icon"
            alt=""
          />
          <span class="dd-name">{{ model.label || model.id }}</span>
          <span v-if="isModelOverloaded(model.id)" class="dd-remark dd-overloaded">{{ getDisplayRemark(model.id, model.remark) }}</span>
          <span v-else-if="isModelCongested(model.id)" class="dd-remark dd-congested">{{ getDisplayRemark(model.id, model.remark) }}</span>
          <span v-else-if="model.remark" class="dd-remark" :class="{ 'dd-unavailable': isUnavailableRemark(model.remark) }">{{ model.remark }}</span>
          <span v-if="model.id === modelValue" class="dd-check">&#10003;</span>
        </div>
      </div>

      <!-- Description popup card (inline for chip variant) -->
      <Transition name="desc-card">
        <div
          v-if="hasDescription"
          class="desc-card"
          :style="{ top: descCardPos.top + 'px' }"
          @mouseenter="onCardEnter"
          @mouseleave="onCardLeave"
        >
          <div class="desc-card-title">{{ descContent.label }}</div>
          <div class="desc-card-divider"></div>
          <div class="desc-card-text">{{ descContent.description }}</div>
        </div>
      </Transition>
    </div>
  </div>

  <!-- Dropdown panel (select variant: teleported to body with fixed positioning) -->
  <Teleport to="body">
    <div v-if="showDropdown && variant === 'select'" class="select-panel-fixed" :style="{ top: selectPanelPos.top + 'px', left: selectPanelPos.left + 'px' }">
      <div class="select-panel-scroll">
        <div
          v-for="model in modelList"
          :key="model.id"
          class="dd-item"
          :class="{ active: model.id === modelValue }"
          @click="selectModel(model.id)"
          @mouseenter="onItemEnter(model.id, $event)"
          @mouseleave="onItemLeave"
        >
          <img
            v-if="getIconUrl(model.providerId)"
            :src="getIconUrl(model.providerId)"
            class="provider-icon"
            alt=""
          />
          <span class="dd-name">{{ model.label || model.id }}</span>
          <span v-if="isModelOverloaded(model.id)" class="dd-remark dd-overloaded">{{ getDisplayRemark(model.id, model.remark) }}</span>
          <span v-else-if="isModelCongested(model.id)" class="dd-remark dd-congested">{{ getDisplayRemark(model.id, model.remark) }}</span>
          <span v-else-if="model.remark" class="dd-remark" :class="{ 'dd-unavailable': isUnavailableRemark(model.remark) }">{{ model.remark }}</span>
          <span v-if="model.id === modelValue" class="dd-check">&#10003;</span>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Description popup card (teleported for select variant to avoid overflow clipping) -->
  <Teleport to="body">
    <Transition v-if="variant === 'select'" name="desc-card">
      <div
        v-if="hasDescription && showDropdown"
        class="desc-card desc-card--teleported"
        :style="{ top: descCardScreenPos.top + 'px', left: descCardScreenPos.left + 'px' }"
        @mouseenter="onCardEnter"
        @mouseleave="onCardLeave"
      >
        <div class="desc-card-title">{{ descContent.label }}</div>
        <div class="desc-card-divider"></div>
        <div class="desc-card-text">{{ descContent.description }}</div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.model-dropdown-root {
  position: relative;
  min-width: 0;
}

/* ── Chip trigger ── */
.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-muted);
  font-weight: 500;
  cursor: pointer;
  transition: all .12s;
  font-size: 12px;
  white-space: nowrap;
  font-family: inherit;
}

.chip:hover {
  background: var(--bg-hover);
  color: var(--text);
}

.chip.active {
  background: var(--accent-bg);
  border-color: var(--accent-bg-strong);
  color: var(--accent-text);
}

.chip-label {
  max-width: clamp(180px, 28vw, 360px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.chip-chevron {
  opacity: .5;
  font-size: 10px;
}

/* ── Select trigger ── */
.select-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  width: 100%;
  padding: 4px 8px;
  border-radius: 6px;
  border: 1px solid var(--border-color, #e0e0e6);
  background: var(--bg-card, #fff);
  color: var(--text);
  font-size: 13px;
  cursor: pointer;
  transition: all .12s;
  font-family: inherit;
  text-align: left;
}

.select-trigger:hover {
  border-color: var(--accent);
}

.select-trigger.active {
  border-color: var(--accent);
  box-shadow: 0 0 0 2px var(--accent-bg);
}

.select-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.select-arrow {
  opacity: .5;
  font-size: 10px;
  flex-shrink: 0;
}

/* ── Dropdown panel (chip variant only) ── */
.dropdown-panel {
  position: absolute;
  bottom: calc(100% + 6px);
  left: 0;
  z-index: 200;
}

.dropdown-scroll {
  min-width: 280px;
  max-width: 420px;
  width: max-content;
  max-height: 240px;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--bg-surface);
  border: 1px solid var(--border2);
  border-radius: 10px;
  box-shadow: 0 -4px 20px rgba(0,0,0,.1);
  padding: 4px;
}

[data-theme='dark'] .dropdown-scroll {
  box-shadow: 0 -4px 20px rgba(0,0,0,.3);
}

/* ── Select variant: fixed panel (teleported to body) ── */
.select-panel-fixed {
  position: fixed;
  z-index: 9999;
  width: 280px;
  max-height: 240px;
  overflow: hidden;
}

.select-panel-scroll {
  width: 100%;
  max-height: 240px;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--bg-surface);
  border: 1px solid var(--border2);
  border-radius: 10px;
  box-shadow: 0 8px 24px rgba(0,0,0,.12);
  padding: 4px;
}

[data-theme='dark'] .select-panel-scroll {
  box-shadow: 0 8px 24px rgba(0,0,0,.3);
}

/* ── Dropdown items ── */
.dd-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  font-size: 13px;
  cursor: pointer;
  transition: background .1s;
  color: var(--text);
}

.dd-name {
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
}

.dd-remark {
  margin-left: auto;
  flex-shrink: 0;
  max-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 11px;
  color: var(--text-secondary);
}

.dd-overloaded {
  color: #ef4444;
  font-weight: 600;
}

.chip-label.overloaded,
.chip-label.unavailable {
  color: #ef4444;
}

.dd-unavailable {
  color: #ef4444;
  font-weight: 600;
}

.dd-congested {
  color: #f59e0b;
  font-weight: 600;
}

.chip-label.congested {
  color: #f59e0b;
}

.dd-item:hover {
  background: var(--bg-hover);
}

.dd-item.active {
  background: var(--accent-bg);
  color: var(--accent-text);
}

.dd-item.active .dd-remark {
  color: var(--accent-text);
  opacity: .7;
}

.dd-check {
  flex-shrink: 0;
  font-size: 11px;
  color: var(--accent);
}

.provider-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  object-fit: contain;
}

/* ── Description popup card ── */
.desc-card {
  position: absolute;
  left: calc(100% + 8px);
  top: 0;
  width: 260px;
  max-width: 300px;
  padding: 12px;
  background: var(--bg-card);
  border: 1px solid var(--border-color, #e0e0e6);
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
  z-index: 201;
  pointer-events: auto;
}

[data-theme='dark'] .desc-card {
  box-shadow: 0 4px 16px rgba(0,0,0,.3);
}

.desc-card--teleported {
  position: fixed;
}

.desc-card-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-strong, #1a1a1a);
  margin-bottom: 8px;
}

.desc-card-divider {
  height: 1px;
  background: var(--border-color, #e0e0e6);
  margin-bottom: 8px;
}

.desc-card-text {
  font-size: 12px;
  line-height: 1.6;
  color: var(--text-secondary);
  white-space: pre-wrap;
  word-break: break-word;
}

/* ── Transition ── */
.desc-card-enter-active {
  transition: opacity .15s, transform .15s;
}

.desc-card-leave-active {
  transition: opacity .1s;
}

.desc-card-enter-from {
  opacity: 0;
  transform: translateX(-4px);
}

.desc-card-leave-to {
  opacity: 0;
}
</style>
