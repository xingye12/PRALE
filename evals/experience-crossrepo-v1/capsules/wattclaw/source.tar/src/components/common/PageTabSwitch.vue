<script setup lang="ts">
interface PageTabOption {
  value: string
  label: string
}

defineProps<{
  modelValue: string
  options: PageTabOption[]
  ariaLabel?: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()
</script>

<template>
  <div class="page-tab-switch" role="tablist" :aria-label="ariaLabel">
    <button
      v-for="option in options"
      :key="option.value"
      class="page-tab-button"
      :class="{ 'page-tab-button--active': modelValue === option.value }"
      type="button"
      role="tab"
      :aria-selected="modelValue === option.value"
      @click="emit('update:modelValue', option.value)"
    >
      {{ option.label }}
    </button>
  </div>
</template>

<style scoped>
.page-tab-switch {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px;
  border-radius: 10px;
  background: var(--surface-container);
}

.page-tab-button {
  min-width: 64px;
  height: 34px;
  padding: 0 14px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--text-secondary);
  font: inherit;
  font-size: 14px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: color 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
}

.page-tab-button:hover {
  color: var(--text-strong);
}

.page-tab-button--active {
  color: var(--text-strong);
  background: var(--bg-card);
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.08);
}
</style>
