<script setup lang="ts">
export interface SkillCardProps {
  icon: string
  name: string
  description?: string
  variant?: 'default' | 'global'
  clickable?: boolean
  iconColor?: string
}

defineProps<SkillCardProps>()
</script>

<template>
  <div
    class="skill-card-modern"
    :class="{
      'is-global': variant === 'global',
      'is-clickable': clickable,
    }"
  >
    <span
      class="skill-card-icon"
      :style="iconColor ? { backgroundColor: iconColor + '1A', color: iconColor } : undefined"
    >
      {{ icon }}
    </span>
    <div class="skill-card-content">
      <div class="skill-card-title-row">
        <h4 class="skill-card-title">{{ name }}</h4>
        <span v-if="$slots.badge" class="skill-card-badge"><slot name="badge" /></span>
      </div>
      <p class="skill-card-description">{{ description || '—' }}</p>
    </div>
    <div v-if="$slots.action" class="skill-card-action">
      <slot name="action" />
    </div>
  </div>
</template>

<style scoped>
.skill-card-modern {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 20px;
  border-radius: 12px;
  background: var(--bg-card, #fff);
  border: 1px solid var(--border-color, #e5e7eb);
  transition: all 0.2s ease;
  cursor: default;
}

.skill-card-modern.is-clickable {
  cursor: pointer;
}

.skill-card-modern:hover {
  border-color: var(--accent, #435ba8);
  box-shadow: var(--shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.06));
}

.skill-card-modern.is-global {
  background: var(--bg-surface, #fafafa);
  border-style: dashed;
}

.skill-card-modern.is-global:hover {
  border-style: solid;
}

.skill-card-icon {
  font-size: 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: var(--accent-bg, rgba(67, 91, 168, 0.08));
  flex-shrink: 0;
}

.skill-card-content {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.skill-card-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.skill-card-title {
  font-weight: 600;
  font-size: 15px;
  color: var(--text-primary, #1f2937);
  margin: 0;
  line-height: 1.4;
}

.skill-card-badge {
  flex-shrink: 0;
}

.skill-card-description {
  font-size: 13px;
  color: var(--text-secondary, #6b7280);
  line-height: 1.5;
  margin: 0;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.skill-card-action {
  flex-shrink: 0;
  margin-left: auto;
}
</style>
