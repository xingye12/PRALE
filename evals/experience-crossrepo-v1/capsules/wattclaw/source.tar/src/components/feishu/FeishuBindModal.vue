<script setup lang="ts">
import { onBeforeUnmount, ref, watch } from 'vue'
import { NButton, NInput, NModal, NSpin, NTag, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import { apiPath } from '@/utils/api-path'
import * as QRCode from 'qrcode'

const props = defineProps<{
  show: boolean
}>()

const emit = defineEmits<{
  'update:show': [value: boolean]
  bound: []
}>()

const { t } = useI18n()
const message = useMessage()
const authStore = useAuthStore()

interface FeishuBotInfo {
  appId: string
  ownerOpenId: string
  botOpenId?: string | null
  botName?: string | null
  status: string
  lastError?: string | null
  createdAt: number
  updatedAt: number
}

const loading = ref(false)
const feishuBot = ref<FeishuBotInfo | null>(null)
const unbinding = ref(false)

const showManualInput = ref(false)
const manualAppId = ref('')
const manualAppSecret = ref('')
const manualBinding = ref(false)
const feishuQrCodeUrl = ref('')
const feishuPolling = ref(false)
const feishuPollStatus = ref('')
const feishuPollActive = ref(false)

let loadAbortController: AbortController | null = null
let pollAbortController: AbortController | null = null

watch(() => props.show, (visible) => {
  if (visible) {
    feishuQrCodeUrl.value = ''
    showManualInput.value = false
    feishuPollStatus.value = ''
    loadFeishuBot()
  } else {
    feishuPollActive.value = false
    pollAbortController?.abort()
  }
})

onBeforeUnmount(() => {
  feishuPollActive.value = false
  loadAbortController?.abort()
  pollAbortController?.abort()
  loadAbortController = null
  pollAbortController = null
})

async function loadFeishuBot() {
  loadAbortController?.abort()
  loadAbortController = new AbortController()
  const signal = loadAbortController.signal

  loading.value = true
  try {
    const token = authStore.getToken()
    const res = await fetch(apiPath('/api/user/feishu-bot'), {
      headers: { Authorization: `Bearer ${token}` },
      signal,
    })
    const data = await res.json()
    if (data.ok) {
      feishuBot.value = data.bot || null
    }
  } catch (e) {
    if (signal.aborted) return
    console.error('[FeishuBindModal] load feishu bot error:', e)
  } finally {
    if (!signal.aborted) loading.value = false
  }
}

async function handleScanBind() {
  pollAbortController?.abort()
  pollAbortController = new AbortController()
  const signal = pollAbortController.signal

  feishuQrCodeUrl.value = ''
  showManualInput.value = false
  feishuPollStatus.value = t('pages.agentManagement.connections.qrLoading')
  feishuPollActive.value = true

  try {
    const token = authStore.getToken()
    const begin = await fetch(apiPath('/api/proxy/feishu/register'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        action: 'begin',
        archetype: 'PersonalAgent',
        auth_method: 'client_secret',
        request_user_info: 'open_id',
      }),
      signal,
    }).then((r) => r.json())

    if (!feishuPollActive.value || signal.aborted) return

    if (!begin.verification_uri_complete) {
      feishuPollStatus.value = t('pages.agentManagement.connections.qrFailed')
      return
    }

    const qrUrl = new URL(begin.verification_uri_complete)
    qrUrl.searchParams.set('from', 'oc_onboard')
    qrUrl.searchParams.set('tp', 'ob_cli_app')

    feishuQrCodeUrl.value = await QRCode.toDataURL(qrUrl.toString(), { margin: 1 })
    feishuPollStatus.value = t('pages.agentManagement.connections.scanPrompt')

    const deviceCode = begin.device_code
    const maxWait = begin.expire_in || 600
    const start = Date.now()

    while (feishuPollActive.value && Date.now() - start < maxWait * 1000) {
      if (signal.aborted) break

      const pollToken = authStore.getToken()
      const result = await fetch(apiPath('/api/proxy/feishu/poll'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${pollToken}` },
        body: JSON.stringify({ action: 'poll', device_code: deviceCode, tp: 'ob_app' }),
        signal,
      }).then((r) => r.json())

      if (!feishuPollActive.value || signal.aborted) return

      if (result.botBound && result.bot) {
        feishuPolling.value = true
        feishuPollStatus.value = t('pages.agentManagement.connections.scanSuccess')
        feishuBot.value = result.bot
        feishuPollActive.value = false
        message.success(t('pages.agentManagement.connections.bindSuccess'))
        emit('bound')
        break
      }

      await new Promise((r) => setTimeout(r, (begin.interval || 5) * 1000))
      if (!feishuPollActive.value || signal.aborted) return
    }

    if (feishuPollActive.value && !feishuBot.value) {
      feishuPollStatus.value = t('pages.agentManagement.connections.qrExpired')
      feishuPolling.value = false
    }
  } catch (e) {
    if (signal.aborted) return
    console.error('[FeishuBindModal] feishu auth error:', e)
    feishuPollStatus.value = t('pages.agentManagement.connections.errorRetry')
  } finally {
    feishuPolling.value = false
    pollAbortController = null
  }
}

async function handleManualBind() {
  if (!manualAppId.value || !manualAppSecret.value) {
    message.warning(t('pages.agentManagement.connections.fillRequired'))
    return
  }
  manualBinding.value = true
  try {
    await saveFeishuBot(manualAppId.value, manualAppSecret.value)
  } finally {
    manualBinding.value = false
  }
}

function openManualInput() {
  manualAppId.value = ''
  manualAppSecret.value = ''
  showManualInput.value = true
}

async function saveFeishuBot(appId: string, appSecret: string) {
  try {
    const token = authStore.getToken()
    const res = await fetch(apiPath('/api/user/feishu-bot'), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        appId,
        appSecret,
      }),
    })
    const data = await res.json()
    if (res.ok && data.ok) {
      message.success(t('pages.agentManagement.connections.bindSuccess'))
      feishuBot.value = data.bot
      feishuPollActive.value = false
      showManualInput.value = false
      manualAppId.value = ''
      manualAppSecret.value = ''
      emit('bound')
    } else {
      message.error(t('pages.agentManagement.connections.bindFailed') + '：' + data.error)
      feishuPollStatus.value = t('pages.agentManagement.connections.bindFailed')
    }
  } catch (e) {
    console.error('[FeishuBindModal] channel binding error:', e)
    message.error(t('pages.agentManagement.connections.bindFailed'))
    feishuPollStatus.value = t('pages.agentManagement.connections.bindFailed')
  }
}

async function handleUnbind() {
  if (!feishuBot.value) return
  if (!window.confirm(t('pages.agentManagement.connections.unbindConfirm'))) return
  unbinding.value = true
  try {
    const token = authStore.getToken()
    const res = await fetch(apiPath('/api/user/feishu-bot'), {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    if (data.ok) {
      message.success(t('pages.agentManagement.connections.unbindSuccess'))
      feishuBot.value = null
    } else {
      message.error(t('pages.agentManagement.connections.unbindFailed') + '：' + data.error)
    }
  } catch (e) {
    console.error('[FeishuBindModal] unbind error:', e)
    message.error(t('pages.agentManagement.connections.unbindFailed'))
  } finally {
    unbinding.value = false
  }
}

function close() {
  feishuPollActive.value = false
  emit('update:show', false)
}
</script>

<template>
  <NModal
    :show="show"
    preset="card"
    :title="t('components.feishuBind.title')"
    style="width: 480px; max-width: 90vw; border-radius: 12px;"
    :segmented="{ content: 'soft', footer: 'soft' }"
    @update:show="(value: boolean) => !value && close()"
  >
    <NSpin :show="loading">
      <div v-if="feishuBot" class="bound-state">
        <div class="bound-icon"><span class="material-symbols-outlined">forum</span></div>
        <div class="bound-info">
          <div class="bound-row">
            <NTag size="small" type="success" :bordered="false">
              {{ t('pages.agentManagement.connections.connected') }}
            </NTag>
            <span class="bound-name">{{ feishuBot.botName || feishuBot.appId }}</span>
          </div>
          <p v-if="feishuBot.createdAt" class="bound-time">
            {{ t('pages.agentManagement.connections.bindTime') }}：{{ new Date(feishuBot.createdAt).toLocaleString('zh-CN') }}
          </p>
          <p class="bound-time">
            {{ t('components.feishuBind.ownerOpenId') }}：{{ feishuBot.ownerOpenId }}
          </p>
          <p class="bound-hint">{{ t('components.feishuBind.boundHint') }}</p>
        </div>
        <NButton size="small" type="error" dashed :loading="unbinding" @click="handleUnbind">
          {{ t('pages.agentManagement.connections.unbind') }}
        </NButton>
      </div>

      <div v-else style="display: flex; flex-direction: column; gap: 20px;">
        <div class="modal-hint">{{ t('components.feishuBind.hint') }}</div>

        <NButton
          type="warning"
          block
          size="large"
          class="scan-refresh-btn"
          :loading="!feishuQrCodeUrl && feishuPolling"
          @click="handleScanBind"
        >
          {{ feishuQrCodeUrl ? t('pages.agentManagement.connections.refreshQr') : t('components.feishuBind.startScan') }}
        </NButton>

        <div v-if="feishuQrCodeUrl && !showManualInput" class="qr-panel">
          <div class="qr-wrap">
            <img :src="feishuQrCodeUrl" alt="Feishu QR Code" class="qr-img" />
          </div>
          <div class="qr-status">
            <NSpin v-if="feishuPolling" size="small" />
            <span :style="{ color: feishuPolling ? '#F97316' : 'inherit' }">{{ feishuPollStatus }}</span>
          </div>
        </div>

        <div v-if="showManualInput" class="manual-panel">
          <div class="manual-title">{{ t('pages.agentManagement.connections.manualTitle') }}</div>
          <div class="manual-fields">
            <div>
              <div class="manual-label">{{ t('pages.agentManagement.connections.appId') }}</div>
              <NInput v-model:value="manualAppId" :placeholder="t('pages.agentManagement.connections.appIdPlaceholder')" />
            </div>
            <div>
              <div class="manual-label">{{ t('pages.agentManagement.connections.appSecret') }}</div>
              <NInput v-model:value="manualAppSecret" type="password" show-password-on="mousedown" :placeholder="t('pages.agentManagement.connections.appSecretPlaceholder')" />
            </div>
            <NButton type="primary" block style="margin-top: 8px;" :loading="manualBinding" @click="handleManualBind">
              {{ t('pages.agentManagement.connections.bindNow') }}
            </NButton>
          </div>
        </div>
      </div>
    </NSpin>

    <template v-if="!feishuBot" #footer>
      <div v-if="!showManualInput" class="footer-toggle" @click="openManualInput">
        <span class="material-symbols-outlined">arrow_right</span>
        {{ t('pages.agentManagement.connections.hasAppId') }}
      </div>
      <div v-else class="footer-toggle" @click="showManualInput = false">
        <span class="material-symbols-outlined">arrow_left</span>
        {{ t('pages.agentManagement.connections.backToScan') }}
      </div>
    </template>
  </NModal>
</template>

<style scoped>
.bound-state {
  display: flex;
  align-items: flex-start;
  gap: 16px;
}

.bound-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: #3370ff;
  background: rgba(51, 112, 255, 0.1);
}

.bound-icon .material-symbols-outlined {
  font-size: 28px;
}

.bound-info {
  flex: 1;
  min-width: 0;
}

.bound-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.bound-name {
  font-size: 13px;
  color: var(--text-secondary);
}

.bound-time {
  margin: 4px 0 0;
  font-size: 12px;
  color: var(--text-tertiary, #999);
}

.bound-hint {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--text-secondary);
  line-height: 1.5;
}

.modal-hint {
  color: var(--text-secondary, #6b7280);
  font-size: 13px;
  line-height: 1.5;
}

.scan-refresh-btn {
  background-color: #f97316;
  border-color: #f97316;
  color: white;
  font-weight: 600;
}

.qr-panel {
  border: 1px solid var(--border-color, #e5e7eb);
  border-radius: 12px;
  padding: 20px;
}

.qr-wrap {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 220px;
  margin: 0 0 16px;
}

.qr-img {
  width: 220px;
  height: 220px;
  border-radius: 8px;
  border: 1px solid var(--border-color, #f3f4f6);
}

.qr-status {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: var(--text-secondary, #6b7280);
}

.manual-panel {
  border: 1px solid var(--border-color, #e5e7eb);
  border-radius: 12px;
  padding: 20px;
}

.manual-title {
  font-weight: 600;
  font-size: 15px;
  margin-bottom: 16px;
}

.manual-fields {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.manual-label {
  font-size: 13px;
  margin-bottom: 4px;
  color: var(--text-secondary);
}

.footer-toggle {
  font-size: 13px;
  color: var(--text-secondary, #6b7280);
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
}

.footer-toggle .material-symbols-outlined {
  font-size: 16px;
}
</style>
