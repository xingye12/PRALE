<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NBreadcrumb, NBreadcrumbItem, NSpace } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import ConnectionStatus from '@/components/common/ConnectionStatus.vue'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()
const { t } = useI18n()

const breadcrumbs = computed(() => {
  if (route.name === 'PluginStore') return []

  const items: { label: string; name?: string }[] = []
  for (const record of route.matched) {
    if (record.meta?.hideInBreadcrumb) continue
    const titleKey = record.meta?.titleKey as string | undefined
    const fallbackTitle = record.meta?.title as string | undefined
    const label = titleKey ? t(titleKey) : (fallbackTitle || '')
    if (label) {
      items.push({ label, name: record.name as string | undefined })
    }
  }
  // 兜底：过滤后为空则保留当前路由标题（防止首页面包屑完全空白）
  if (items.length === 0 && route.meta?.titleKey) {
    items.push({
      label: t(route.meta.titleKey as string),
      name: route.name as string | undefined,
    })
  }
  return items
})

</script>

<template>
  <div class="header-container">
    <div class="header-left">
      <NBreadcrumb class="custom-breadcrumb">
        <NBreadcrumbItem
          v-for="(item, index) in breadcrumbs"
          :key="index"
          @click="item.name ? router.push({ name: item.name }) : undefined"
        >
          {{ item.label }}
        </NBreadcrumbItem>
      </NBreadcrumb>
    </div>

    <div class="header-right">
      <NSpace :size="12" align="center">
        <ConnectionStatus v-if="authStore.isAdmin" />

      </NSpace>
    </div>
  </div>

</template>

<style scoped>
.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100%;
  min-width: 0;
}

.custom-breadcrumb {
  font-family: 'Manrope', sans-serif;
  font-weight: 600;
  font-size: 14px;
  min-width: 0;
}

:deep(.n-breadcrumb .n-breadcrumb-item .n-breadcrumb-item__link) {
  color: var(--on-surface-variant);
}

:deep(.n-breadcrumb .n-breadcrumb-item:last-child .n-breadcrumb-item__link) {
  color: var(--on-surface);
  font-weight: 800;
}
</style>
