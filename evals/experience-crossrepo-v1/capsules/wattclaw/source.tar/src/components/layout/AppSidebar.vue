<script setup lang="ts">
import { computed, ref, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NTooltip } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { routes } from '@/router/routes'
import { useAuthStore } from '@/stores/auth'
import { useWattClawCollaborationStore } from '@/stores/wattclaw-collaboration'
import { useWorkspaceStore } from '@/stores/workspace'
import { useWebSocketStore } from '@/stores/websocket'
import { useNotificationStore } from '@/stores/notification'
import WorkspaceSidebar from '@/views/workspace/WorkspaceSidebar.vue'
import UserMenuDropdown from '@/components/layout/UserMenuDropdown.vue'

const props = defineProps<{
  collapsed: boolean
}>()

const emit = defineEmits<{
  (e: 'toggle-collapsed'): void
}>()

const route = useRoute()
const router = useRouter()
const { t } = useI18n()
const authStore = useAuthStore()
const collaborationStore = useWattClawCollaborationStore()
const workspaceStore = useWorkspaceStore()
const wsStore = useWebSocketStore()
const notificationStore = useNotificationStore()

const showNotifPanel = ref(false)
const embeddedWorkspaceSidebarRef = ref<InstanceType<typeof WorkspaceSidebar> | null>(null)

onMounted(async () => {
  notificationStore.fetchUnreadCount()
  try {
    await workspaceStore.loadAgents()
  } catch (error) {
    console.error('[AppSidebar] Loading agents failed:', error)
  }
  void collaborationStore.loadSavedProjectsMeta()
})

// SSE: 监听实时通知
let sseCleanup: (() => void) | null = null
onMounted(() => {
  sseCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const e = evt as { type?: string; event?: string }
    if (e.type === 'notification') {
      notificationStore.fetchUnreadCount()
      if (showNotifPanel.value) notificationStore.fetchNotifications()
    }
    if (e.type === 'event' && e.event === 'wattclaw.team.projects.changed') {
      void collaborationStore.loadSavedProjectsMeta()
    }
  })
})
onUnmounted(() => { sseCleanup?.() })

const materialIconMap: Record<string, string> = {
  GridOutline: 'space_dashboard',
  ChatbubblesOutline: 'forum',
  BookOutline: 'database',
  CalendarOutline: 'event_repeat',
  SparklesOutline: 'hub',
  ExtensionPuzzleOutline: 'extension',
  CogOutline: 'settings',
  PulseOutline: 'insights',
  FolderOpenOutline: 'folder_open',
  SearchOutline: 'search',
  DocumentTextOutline: 'description',
  ImageOutline: 'image',
  CodeSlashOutline: 'code',
  AlbumsOutline: 'library_books',
  ChevronDownOutline: 'expand_more',
  ChevronForwardOutline: 'chevron_right',
  FolderOutline: 'folder_open',
  PeopleOutline: 'groups',
  BusinessOutline: 'corporate_fare',
  StorefrontOutline: 'storefront',
  ConstructOutline: 'construction',
  ArchiveOutline: 'inventory_2',
  SmartToyOutline: 'smart_toy',
  RocketOutline: 'rocket_launch',
  ChatOutline: 'chat',
}

interface MenuItem {
  key: string
  label: string
  iconName: string
  hasBadge: boolean
}

const menuItems = computed<MenuItem[]>(() => {
  const mainRoute = routes.find((r) => r.path === '/')
  if (!mainRoute?.children) return []

  return mainRoute.children
    .filter((child) => !child.meta?.hidden)
    .filter((child) => !child.meta?.requiresAdmin || authStore.isAdmin)
    .map((child) => ({
      key: child.name as string,
      label: child.meta?.titleKey ? t(child.meta.titleKey as string) : (child.meta?.title as string),
      iconName: materialIconMap[child.meta?.icon as string] || 'question_mark',
      hasBadge: (child.name as string) === 'Workspace' && workspaceStore.hasSidebarNotification,
    }))
})

const activeKey = computed(() => {
  for (const matched of route.matched) {
    if (matched.name && !matched.meta?.hidden) {
      return matched.name as string
    }
  }
  return route.name as string
})

function handleSelect(key: string) {
  router.push({ name: key })
}

function toggleWorkspaceSearch() {
  embeddedWorkspaceSidebarRef.value?.toggleSearch()
}

function toggleNotifPanel() {
  showNotifPanel.value = !showNotifPanel.value
  if (showNotifPanel.value) notificationStore.fetchNotifications()
}

function handleNotifClick(id: string) {
  notificationStore.markRead(id)
}

async function handleMarkAllRead() {
  await notificationStore.markAllRead()
  notificationStore.fetchNotifications()
}

function formatTime(ts: number) {
  const d = new Date(ts)
  const now = new Date()
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  return d.toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' }) + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
}

</script>

<template>
  <div
    class="sidebar-container"
    :class="{
      'sidebar-container--wide': !props.collapsed,
      'sidebar-container--collapsed': props.collapsed,
      'sidebar-container--workspace': !props.collapsed,
    }"
  >
    <div v-if="!props.collapsed" class="sidebar-logo-section">
      <img src="/logo2.png" alt="WattClaw" class="logo-image" />
    </div>

    <div class="sidebar-menu-wrapper" :class="{ 'sidebar-menu-wrapper--admin': authStore.isAdmin }">
      <div
        v-for="item in menuItems"
        :key="item.key"
        class="menu-item"
        :class="{ 'menu-item--active': activeKey === item.key }"
        :title="props.collapsed ? item.label : undefined"
        @click="handleSelect(item.key)"
      >
        <span class="menu-icon material-symbols-outlined">{{ item.iconName }}</span>
        <span class="menu-label">{{ item.label }}</span>
        <span v-if="item.hasBadge" class="notification-badge"></span>
      </div>
    </div>

    <div v-if="!props.collapsed" class="workspace-section-header">
      <span class="workspace-section-title">{{ t('pages.workspace.sidebar.myTasks') }}</span>
      <button
        type="button"
        class="workspace-search-button"
        :title="t('pages.workspace.sidebar.search')"
        @click="toggleWorkspaceSearch"
      >
        <span class="material-symbols-outlined">search</span>
      </button>
    </div>

    <WorkspaceSidebar
      v-if="!props.collapsed"
      ref="embeddedWorkspaceSidebarRef"
      class="embedded-workspace-sidebar"
    />

    <div class="sidebar-bottom-menu">
      <NTooltip trigger="hover" placement="top">
        <template #trigger>
          <button type="button" class="bottom-menu-item sidebar-collapse-button" @click="emit('toggle-collapsed')">
            <span class="bottom-menu-icon material-symbols-outlined">
              {{ props.collapsed ? 'left_panel_open' : 'left_panel_close' }}
            </span>
          </button>
        </template>
        {{ props.collapsed ? t('common.openSidebar') : t('common.collapseSidebar') }}
      </NTooltip>

      <div class="bottom-menu-spacer"></div>

      <NTooltip trigger="hover" placement="top">
        <template #trigger>
          <div
            class="bottom-menu-item bottom-menu-item--notification"
            @click="toggleNotifPanel"
          >
            <span class="bottom-menu-icon material-symbols-outlined">notifications</span>
            <span v-if="notificationStore.unreadCount > 0" class="bottom-unread-dot"></span>
          </div>
        </template>
        {{ t('routes.notifications') }}
      </NTooltip>

      <UserMenuDropdown placement="top-start">
        <NTooltip trigger="hover" placement="top">
          <template #trigger>
            <div class="bottom-menu-item bottom-menu-item--account">
              <span class="bottom-menu-icon material-symbols-outlined">account_circle</span>
            </div>
          </template>
          {{ t('common.personalMenu') }}
        </NTooltip>
      </UserMenuDropdown>
    </div>

    <!-- 通知面板：固定在页面左下角 -->
    <Teleport to="body">
      <div v-if="showNotifPanel" class="notif-overlay" @click.self="showNotifPanel = false">
        <div class="notif-panel" :class="{ 'notif-panel--wide': !props.collapsed }">
          <div class="notif-panel-header">
            <span class="notif-panel-title">{{ t('routes.notifications') }}</span>
            <button
              v-if="notificationStore.unreadCount > 0"
              class="notif-mark-all"
              @click="handleMarkAllRead"
            >{{ t('pages.notifications.markAllRead') }}</button>
          </div>
          <div class="notif-panel-body">
            <div v-if="notificationStore.notifications.length === 0" class="notif-empty">
              {{ t('pages.notifications.empty') }}
            </div>
            <div
              v-for="item in notificationStore.notifications"
              :key="item.id"
              class="notif-item"
              :class="{ 'notif-item--unread': !item.isRead }"
              @click="handleNotifClick(item.id)"
            >
              <span v-if="!item.isRead" class="notif-item-dot"></span>
              <div class="notif-item-content">
                <div class="notif-item-title">{{ item.title }}</div>
                <div v-if="item.content" class="notif-item-text">{{ item.content }}</div>
                <div class="notif-item-time">{{ formatTime(item.createdAt) }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<style scoped>
.sidebar-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background: var(--bg-sidebar);
  border-right: none;
}

.sidebar-container--wide {
  height: 100vh;
  min-height: 0;
}

.sidebar-container--collapsed {
  height: 100vh;
  min-height: 0;
}

.sidebar-container--collapsed .sidebar-logo-section {
  justify-content: center;
  padding: 14px 8px 10px;
}

.sidebar-container--collapsed .menu-item {
  width: 56px;
  height: 48px;
}

.sidebar-container--collapsed .menu-label {
  display: none;
}

.sidebar-container--collapsed .sidebar-collapse-button {
  order: 1;
}

.sidebar-container--collapsed .bottom-menu-spacer {
  display: none;
}

.sidebar-container--wide .sidebar-logo-section {
  justify-content: flex-start;
  padding: 14px 20px 10px;
}

.sidebar-collapse-button {
  padding: 0;
  border: 0;
  background: transparent;
}

.sidebar-collapse-button:hover {
  background: var(--bg-hover);
  color: var(--primary);
}

.sidebar-collapse-button .material-symbols-outlined {
  font-size: 21px;
}

.sidebar-container--wide .sidebar-menu-wrapper {
  flex: 1 1 auto;
  align-items: stretch;
  gap: 2px;
  padding: 0 10px 10px;
  overflow-y: auto;
  overflow-x: hidden;
}

.sidebar-container--workspace .sidebar-menu-wrapper {
  flex: 0 0 auto;
  max-height: 36vh;
}

.sidebar-container--wide .sidebar-menu-wrapper--admin {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-content: start;
  gap: 4px;
}

.sidebar-container--wide .menu-item {
  flex-direction: row;
  justify-content: flex-start;
  width: 100%;
  height: 44px;
  padding: 0 14px;
  gap: 10px;
  box-sizing: border-box;
}

.sidebar-container--wide .menu-icon {
  font-size: 24px;
}

.sidebar-container--wide .menu-label {
  max-width: none;
  font-size: 13px;
  text-align: left;
}

.sidebar-container--wide .sidebar-menu-wrapper--admin .menu-item {
  padding: 0 10px;
  gap: 7px;
}

.sidebar-container--wide .sidebar-menu-wrapper--admin .menu-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}

.workspace-section-header {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 2px 10px 0;
  padding: 12px 12px 10px;
  border-radius: 10px 10px 0 0;
  background: var(--bg-surface);
}

.workspace-section-title {
  color: var(--text);
  font-size: 16px;
  font-weight: 700;
}

.workspace-search-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 5px 7px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  transition: background-color .15s, color .15s;
}

.workspace-search-button:hover {
  background: var(--bg-hover);
  color: var(--text);
}

.workspace-search-button .material-symbols-outlined {
  font-size: 20px;
}

.embedded-workspace-sidebar {
  min-height: 0;
  flex: 1 1 auto;
  margin: 0 10px;
  border-radius: 0 0 12px 12px;
  background: var(--bg-surface);
  overflow: hidden;
}

.sidebar-container--wide .sidebar-bottom-menu {
  position: static;
  flex-direction: row;
  justify-content: flex-start;
  gap: 4px;
  padding: 8px 12px 12px;
}

.bottom-menu-spacer {
  min-width: 4px;
  flex: 1;
}

.sidebar-container--wide .bottom-menu-item:hover {
  transform: translateY(-2px);
}

.sidebar-container--wide .bottom-menu-item--active::before {
  left: 8px;
  right: 8px;
  top: auto;
  bottom: -4px;
  width: auto;
  height: 3px;
  border-radius: 4px 4px 0 0;
}

.sidebar-logo-section {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px 8px;
}

.logo-image {
  width: 30px;
  max-width: 100%;
  object-fit: contain;
}

.sidebar-menu-wrapper {
  flex: 1 1 auto;
  min-height: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  overflow-y: auto;
  overflow-x: hidden;
}

.sidebar-bottom-menu {
  position: sticky;
  bottom: 0;
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 10px 0 16px;
  background: var(--bg-sidebar);
  border-top: 1px solid var(--outline-variant);
  z-index: 1;
}

.menu-item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 68px;
  height: 56px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  color: var(--text-secondary, #6b7280);
  gap: 2px;
}

.menu-item:hover {
  background: var(--surface-container-highest);
  color: var(--text);
}

.menu-item--active {
  color: var(--primary);
  background: linear-gradient(to right, rgba(67, 91, 168, 0.1), transparent);
}

.menu-item--active::after {
  content: "";
  position: absolute;
  right: 0;
  top: 15%;
  height: 70%;
  width: 3px;
  background: var(--primary);
  border-radius: 4px 0 0 4px;
}

.bottom-menu-item {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 36px;
  border-radius: 10px;
  cursor: pointer;
  color: var(--text-secondary, #6b7280);
  transition: all 0.2s ease;
}

.bottom-menu-item:hover {
  color: var(--primary);
  transform: translateX(2px);
}

.bottom-menu-item--active {
  color: var(--primary);
}

.bottom-menu-item--active::before {
  content: "";
  position: absolute;
  left: -8px;
  top: 8px;
  bottom: 8px;
  width: 3px;
  border-radius: 0 4px 4px 0;
  background: var(--primary);
}

.bottom-menu-icon {
  font-size: 22px;
  line-height: 1;
}

.menu-icon {
  font-size: 22px;
  line-height: 1;
}

.menu-label {
  font-size: 11px;
  line-height: 1.2;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 64px;
}

.notification-badge {
  position: absolute;
  top: 6px;
  right: 10px;
  width: 8px;
  height: 8px;
  background: #f44336;
  border-radius: 50%;
  border: 1.5px solid var(--bg-card, #fff);
}

.bottom-unread-dot {
  position: absolute;
  top: 4px;
  right: 6px;
  width: 8px;
  height: 8px;
  background: #f44336;
  border-radius: 50%;
  border: 1.5px solid var(--bg-sidebar);
}

.notif-overlay {
  position: fixed;
  inset: 0;
  z-index: 2000;
}

.notif-panel {
  position: fixed;
  left: 88px;
  bottom: 12px;
  width: 360px;
  max-height: 460px;
  background: var(--bg-card, #fff);
  border: none;
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.10), 0 2px 8px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  z-index: 2001;
  overflow: hidden;
}

.notif-panel--wide {
  left: 288px;
}

.notif-panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 18px 12px;
}

.notif-panel-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--on-surface);
}

.notif-mark-all {
  background: none;
  border: none;
  font-size: 12px;
  color: var(--primary);
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 6px;
}

.notif-mark-all:hover {
  background: rgba(67, 91, 168, 0.08);
}

.notif-panel-body {
  flex: 1;
  overflow-y: auto;
  padding: 0 6px 8px;
}

.notif-empty {
  text-align: center;
  padding: 40px 16px;
  color: var(--text-secondary, #6b7280);
  font-size: 13px;
}

.notif-item {
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  cursor: pointer;
  border-radius: 10px;
  transition: background 0.15s;
  margin: 2px 2px;
}

.notif-item:hover {
  background: var(--surface-container-highest);
}

.notif-item--unread {
  background: rgba(67, 91, 168, 0.04);
}

.notif-item-dot {
  flex-shrink: 0;
  width: 8px;
  height: 8px;
  margin-top: 6px;
  background: #f44336;
  border-radius: 50%;
}

.notif-item-content {
  flex: 1;
  min-width: 0;
}

.notif-item-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--on-surface);
  line-height: 1.4;
}

.notif-item-text {
  font-size: 13px;
  color: var(--text-secondary, #6b7280);
  line-height: 1.4;
  margin-top: 2px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.notif-item-time {
  font-size: 12px;
  color: var(--text-secondary, #6b7280);
  opacity: 0.7;
  margin-top: 4px;
}
</style>
