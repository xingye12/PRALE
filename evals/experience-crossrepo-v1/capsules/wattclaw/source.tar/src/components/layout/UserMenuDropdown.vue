<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NButton, NDropdown, NForm, NFormItem, NInput, NModal, useMessage } from 'naive-ui'
import QRCode from 'qrcode'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import { useWebSocketStore } from '@/stores/websocket'
import { useWorkspaceStore } from '@/stores/workspace'
import { useSessionStore } from '@/stores/session'
import { useChatStore } from '@/stores/chat'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useTheme } from '@/composables/useTheme'
import FeishuBindModal from '@/components/feishu/FeishuBindModal.vue'

withDefaults(defineProps<{
  placement?: 'bottom-end' | 'top-start'
}>(), {
  placement: 'bottom-end',
})

const router = useRouter()
const { t } = useI18n()
const message = useMessage()
const authStore = useAuthStore()
const wsStore = useWebSocketStore()
const workspaceStore = useWorkspaceStore()
const sessionStore = useSessionStore()
const chatStore = useChatStore()
const agentTeamStore = useAgentTeamStore()
const { isDark, toggle: toggleTheme } = useTheme()
const showPasswordModal = ref(false)
const showBotModal = ref(false)
const showQrDialog = ref(false)
const qrDataUrl = ref('')
const communityUrl = 'https://applink.feishu.cn/client/chat/chatter/add_by_link?link_token=79ck7fb2-c38c-47de-88c6-3d0f071a5172&qr_code=true'
const passwordLoading = ref(false)
const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
})

const options = computed(() => {
  const items: Array<{ label: string; key: string; disabled?: boolean; type?: string }> = [
    { label: authStore.currentUser?.display_name || authStore.currentUser?.username || '', key: 'info', disabled: true },
    { label: '', type: 'divider', key: 'd1' },
  ]
  if (authStore.isAdmin) items.push({ label: t('routes.settings'), key: 'settings' })
  items.push({ label: t('routes.dashboard'), key: 'dashboard' })
  items.push({ label: t('components.feishuBind.menuEntry'), key: 'myBot' })
  items.push({ label: isDark.value ? t('common.switchToLight') : t('common.switchToDark'), key: 'theme' })
  items.push({ label: t('routes.feedback'), key: 'feedback' })
  items.push({ label: t('routes.communityGroup'), key: 'communityGroup' })
  items.push({ label: '', type: 'divider', key: 'd2' })
  items.push({ label: t('common.changePassword'), key: 'changePassword' })
  items.push({ label: t('common.logout'), key: 'logout' })
  return items
})

function openChangePassword() {
  passwordForm.value = { currentPassword: '', newPassword: '', confirmPassword: '' }
  showPasswordModal.value = true
}

async function changePassword() {
  if (!passwordForm.value.currentPassword || !passwordForm.value.newPassword || !passwordForm.value.confirmPassword) {
    message.warning(t('pages.changePassword.passwordTooShort'))
    return
  }
  if (passwordForm.value.newPassword.length < 6) {
    message.warning(t('pages.changePassword.passwordTooShort'))
    return
  }
  if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
    message.warning(t('pages.changePassword.passwordMismatch'))
    return
  }
  passwordLoading.value = true
  const error = await authStore.changePassword(passwordForm.value.currentPassword, passwordForm.value.newPassword)
  passwordLoading.value = false
  if (error) {
    message.error(t(error))
    return
  }
  await authStore.checkAuth()
  message.success(t('pages.changePassword.success'))
  showPasswordModal.value = false
}

async function logout() {
  wsStore.disconnect()
  workspaceStore.reset()
  sessionStore.reset()
  chatStore.reset()
  agentTeamStore.reset()
  sessionStorage.setItem('feishu_logout', '1')
  await authStore.logout()
  router.push({ name: 'Login' })
}

async function openCommunityDialog() {
  showQrDialog.value = true
  if (qrDataUrl.value) return
  try {
    qrDataUrl.value = await QRCode.toDataURL(communityUrl, { width: 240, margin: 2, color: { dark: '#1a1a2e' } })
  } catch (error) {
    console.error('[UserMenuDropdown] QR code generation failed:', error)
  }
}

function handleSelect(key: string) {
  if (key === 'logout') void logout()
  else if (key === 'settings') void router.push({ name: 'Settings' })
  else if (key === 'dashboard') void router.push({ name: 'Dashboard' })
  else if (key === 'myBot') showBotModal.value = true
  else if (key === 'theme') toggleTheme()
  else if (key === 'feedback') void router.push({ name: 'Feedback' })
  else if (key === 'communityGroup') void openCommunityDialog()
  else if (key === 'changePassword') openChangePassword()
}
</script>

<template>
  <NDropdown :options="options" :placement="placement" trigger="click" @select="handleSelect">
    <slot></slot>
  </NDropdown>

  <FeishuBindModal v-model:show="showBotModal" />

  <NModal v-model:show="showPasswordModal" preset="card" :title="t('common.changePassword')" style="max-width: 400px;">
    <NForm @submit.prevent="changePassword">
      <NFormItem :label="t('pages.changePassword.currentPassword')">
        <NInput v-model:value="passwordForm.currentPassword" type="password" show-password-on="click" :placeholder="t('pages.changePassword.currentPasswordPlaceholder')" />
      </NFormItem>
      <NFormItem :label="t('pages.changePassword.newPassword')">
        <NInput v-model:value="passwordForm.newPassword" type="password" show-password-on="click" :placeholder="t('pages.changePassword.newPasswordPlaceholder')" />
      </NFormItem>
      <NFormItem :label="t('pages.changePassword.confirmPassword')">
        <NInput v-model:value="passwordForm.confirmPassword" type="password" show-password-on="click" :placeholder="t('pages.changePassword.confirmPasswordPlaceholder')" @keyup.enter="changePassword" />
      </NFormItem>
      <NButton type="primary" block :loading="passwordLoading" @click="changePassword">
        {{ t('pages.changePassword.submit') }}
      </NButton>
    </NForm>
  </NModal>

  <NModal v-model:show="showQrDialog" preset="card" :show-icon="false" style="width: 320px;" :bordered="true">
    <div class="qr-dialog-body">
      <img v-if="qrDataUrl" :src="qrDataUrl" alt="QR Code" class="qr-image" />
      <p class="qr-title">{{ t('sidebar.qrDialogTitle') }}</p>
      <p class="qr-subtitle">{{ t('sidebar.qrDialogSubtitle') }}</p>
      <p class="qr-link-hint">
        {{ t('sidebar.qrLinkPrefix') }}<a :href="communityUrl" target="_blank" rel="noopener" class="qr-link">{{ t('sidebar.qrLinkText') }}</a>
      </p>
    </div>
  </NModal>
</template>

<style scoped>
.qr-dialog-body {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 8px 0 4px;
}

.qr-image {
  width: 240px;
  height: 240px;
  border-radius: 12px;
}

.qr-title {
  margin: 16px 0 4px;
  font-size: 16px;
  font-weight: 600;
  color: var(--on-surface);
}

.qr-subtitle {
  margin: 0;
  font-size: 13px;
  color: var(--text-secondary);
}

.qr-link-hint {
  margin: 12px 0 0;
  font-size: 12px;
  color: var(--text-secondary);
}

.qr-link {
  color: var(--primary);
  text-decoration: none;
}

.qr-link:hover {
  text-decoration: underline;
}
</style>
