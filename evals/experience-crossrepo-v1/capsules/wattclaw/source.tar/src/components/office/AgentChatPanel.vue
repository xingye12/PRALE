<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, watch } from 'vue'
import {
  NAlert,
  NButton,
  NCard,
  NCollapse,
  NCollapseItem,
  NEmpty,
  NForm,
  NFormItem,
  NInput,
  NModal,
  NPopconfirm,
  NScrollbar,
  NSpace,
  NSpin,
  NSwitch,
  NTag,
  NText,
  NTooltip,
  useMessage,
} from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useOfficeStore } from '@/stores/office'
import { useChatStore } from '@/stores/chat'
import { useWebSocketStore } from '@/stores/websocket'
import { useConfigStore } from '@/stores/config'
import { useSkillStore } from '@/stores/skill'
import { useSessionStore } from '@/stores/session'
import { useAuthStore } from '@/stores/auth'
import { formatDate, formatRelativeTime, truncate } from '@/utils/format'
import { renderSimpleMarkdown } from '@/utils/markdown'
import type { ChatMessage } from '@/api/types'
import {
  asRecord, asString, asText, asNumber,
  stripCodeFence, decodeEscapedJsonText, looksLikeJsonString,
  unwrapJsonValue, parseSingleJsonValue, splitLeadingJsonValue,
  parseJsonItems, parseThinkingSignature, parseToolValidationError,
  parseStructuredMessage, parseToolResultMessage, parseRawContent,
  isThinkingOnlyStructuredMessage,
  buildImageUrl, normalizeMediaPath, extractImageFromText,
  looksLikeMarkdown, renderPlainText, escapeHtml,
} from '@/views/chat/chat-message-utils'
import type {
  ToolCallItemView, ThinkingItemView, ToolResultItemView,
  ToolValidationErrorItemView, ImageItemView, StructuredMessageView,
  RenderMessage,
} from '@/views/chat/chat-message-utils'
import {
  QUICK_REPLY_STORAGE_KEY,
  loadQuickReplies as loadQuickRepliesUtil,
  persistQuickReplies as persistQuickRepliesUtil,
  resetQuickReplyForm as resetQuickReplyFormUtil,
  createQuickReply, updateQuickReply, deleteQuickReply,
  insertQuickReplyToDraft, copyWorkspaceDir,
} from '@/views/chat/chat-quick-reply-utils'
import type { QuickReplyItem, QuickReplyForm } from '@/views/chat/chat-quick-reply-utils'
import {
  splitModelRef, collectConfiguredModelRefs,
  extractProviderModelIds, collectConfiguredModelRefsFromProviders,
  filterConfiguredModels,
} from '@/views/chat/chat-token-utils'
import type { ConfiguredModelOption } from '@/views/chat/chat-token-utils'

const props = withDefaults(
  defineProps<{
    title?: string
  }>(),
  {
    title: '',
  }
)

const message = useMessage()
const { t, locale } = useI18n()
const officeStore = useOfficeStore()
const chatStore = useChatStore()
const wsStore = useWebSocketStore()
const configStore = useConfigStore()
const skillStore = useSkillStore()
const sessionStore = useSessionStore()
const authStore = useAuthStore()

const draft = ref('')
const scrollRef = ref<InstanceType<typeof NScrollbar> | null>(null)
const expandedScrollRef = ref<InstanceType<typeof NScrollbar> | null>(null)
const showExpandedModal = ref(false)
const autoFollowBottom = ref(true)
const aborting = ref(false)
const nowMs = ref(Date.now())
let nowTimer: ReturnType<typeof setInterval> | null = null

const quickReplySearch = ref('')
const showQuickReplyModal = ref(false)
const quickReplyModalMode = ref<'create' | 'edit'>('create')
const editingQuickReplyId = ref('')
const quickReplyForm = reactive({
  title: '',
  content: '',
})


const quickReplies = ref<QuickReplyItem[]>([])

function formatTokenCount(value: number): string {
  return new Intl.NumberFormat(locale.value, { maximumFractionDigits: 0 }).format(Math.max(0, value))
}

const sessionTokenMetricTags = computed(() => {
  const tokenUsage = selectedSession.value?.tokenUsage
  if (!tokenUsage) return []
  const total = tokenUsage.totalInput + tokenUsage.totalOutput
  const tags = [
    { key: 'total', label: t('pages.chat.tokens.total'), value: formatTokenCount(total), highlight: true },
    { key: 'input', label: t('pages.chat.tokens.input'), value: formatTokenCount(tokenUsage.totalInput), highlight: false },
    { key: 'output', label: t('pages.chat.tokens.output'), value: formatTokenCount(tokenUsage.totalOutput), highlight: false },
  ]
  if (tokenUsage.cacheRead != null) {
    tags.push({ key: 'cacheRead', label: t('pages.chat.tokens.cacheRead'), value: formatTokenCount(tokenUsage.cacheRead), highlight: false })
  }
  if (tokenUsage.cacheWrite != null) {
    tags.push({ key: 'cacheWrite', label: t('pages.chat.tokens.cacheWrite'), value: formatTokenCount(tokenUsage.cacheWrite), highlight: false })
  }
  return tags
})

const sessionTokenStatusText = computed(() => t('pages.chat.tokens.unavailable'))

const selectedAgent = computed(() => officeStore.selectedAgent)
const selectedSession = computed(() => officeStore.selectedSession)
const selectedSessionKey = computed(() => officeStore.selectedSessionKey)
const executionInProgress = computed(() => officeStore.executionInProgress)
const activeTasks = computed(() => officeStore.activeTasks)

const panelTitle = computed(() => props.title || t('pages.office.chat.title'))

const expandedToolCalls = ref(new Set<string>())
const expandedToolResults = ref(new Set<string>())
const showAgentDetails = ref(false)
const eventCleanups: Array<() => void> = []













const configuredModelOptions = computed<ConfiguredModelOption[]>(() => {
  const refs = new Set<string>()
  const defaultsRaw = asRecord(configStore.config?.agents?.defaults)
  const defaultsModelRaw = asRecord(defaultsRaw?.model)
  const allowlistedRefs = new Set<string>()

  collectConfiguredModelRefs(configStore.config?.models?.primary, refs)
  collectConfiguredModelRefs(configStore.config?.models?.fallback, refs)
  collectConfiguredModelRefs(defaultsRaw?.models, refs)
  collectConfiguredModelRefs(defaultsRaw?.models, allowlistedRefs)
  collectConfiguredModelRefs(defaultsModelRaw?.primary, refs)
  collectConfiguredModelRefs(defaultsModelRaw?.fallback, refs)
  collectConfiguredModelRefs(defaultsModelRaw?.fallbacks, refs)
  collectConfiguredModelRefsFromProviders(configStore.config?.models?.providers, refs)

  const finalRefs = new Set<string>()
  if (allowlistedRefs.size > 0) {
    for (const ref of refs) {
      if (allowlistedRefs.has(ref)) {
        finalRefs.add(ref)
      }
    }
    for (const ref of allowlistedRefs) {
      finalRefs.add(ref)
    }
  } else {
    for (const ref of refs) {
      finalRefs.add(ref)
    }
  }

  return Array.from(finalRefs)
    .sort((a, b) => a.localeCompare(b))
    .map((ref) => splitModelRef(ref))
    .filter((item): item is ConfiguredModelOption => !!item)
})



async function handleDraftKeydown(e: KeyboardEvent) {
  const isEnter = e.key === 'Enter'
  const canSend = !e.shiftKey && !e.isComposing

  if ((e.metaKey || e.ctrlKey) && isEnter) {
    e.preventDefault()
    await handleSend()
    return
  }

  if (isEnter && canSend) {
    e.preventDefault()
    await handleSend()
  }
}

const filteredQuickReplies = computed(() => {
  const query = quickReplySearch.value.trim().toLowerCase()
  const list = [...quickReplies.value].sort((a, b) => b.updatedAt - a.updatedAt)
  if (!query) return list
  return list.filter((item) =>
    [item.title, item.content].some((field) => field.toLowerCase().includes(query))
  )
})

const workspaceRoot = computed(() => configStore.config?.agents?.defaults?.workspace || '~/.openclaw/workspace')
const workspaceQuickReplyDir = computed(() => {
  const root = workspaceRoot.value.endsWith('/') ? workspaceRoot.value.slice(0, -1) : workspaceRoot.value
  return `${root}/prompts/common-replies`
})



function openCreateQuickReply() {
  quickReplyModalMode.value = 'create'
  editingQuickReplyId.value = ''
  resetQuickReplyFormUtil(quickReplyForm)
  showQuickReplyModal.value = true
}

function openEditQuickReply(item: { id: string; title: string; content: string }) {
  quickReplyModalMode.value = 'edit'
  editingQuickReplyId.value = item.id
  quickReplyForm.title = item.title
  quickReplyForm.content = item.content
  showQuickReplyModal.value = true
}

function handleDeleteQuickReply(id: string) {
  quickReplies.value = deleteQuickReply(id, quickReplies.value)
  persistQuickRepliesUtil(quickReplies.value)
  message.success(t('pages.chat.quickReplies.messages.deleted'))
}

function handleInsertQuickReply(item: { title: string; content: string }) {
  draft.value = insertQuickReplyToDraft(item.content, draft.value)
  message.success(t('pages.chat.quickReplies.messages.inserted', { title: item.title }))
}

async function handleSendQuickReply(item: { content: string }) {
  draft.value = item.content
  await handleSend()
}

function handleSaveQuickReply() {
  const title = quickReplyForm.title.trim()
  const content = quickReplyForm.content.trim()
  if (!title) {
    message.warning(t('pages.chat.quickReplies.messages.titleRequired'))
    return
  }
  if (!content) {
    message.warning(t('pages.chat.quickReplies.messages.contentRequired'))
    return
  }

  if (quickReplyModalMode.value === 'edit' && editingQuickReplyId.value) {
    quickReplies.value = updateQuickReply(editingQuickReplyId.value, title, content, quickReplies.value)
    message.success(t('pages.chat.quickReplies.messages.updated'))
  } else {
    const result = createQuickReply(title, content, quickReplies.value)
    quickReplies.value = result.items
    message.success(t('pages.chat.quickReplies.messages.created'))
  }

  persistQuickRepliesUtil(quickReplies.value)
  showQuickReplyModal.value = false
}

async function handleCopyWorkspaceDir() {
  const ok = await copyWorkspaceDir(workspaceQuickReplyDir.value)
  if (ok) {
    message.success(t('pages.chat.quickReplies.messages.dirCopied'))
  } else {
    message.warning(t('pages.chat.quickReplies.messages.dirCopyFailed'))
  }
}



const BOTTOM_GAP = 32
let pendingForceScroll = false
let pendingScroll = false
let destroyed = false

function toggleToolCallExpand(key: string) {
  const set = expandedToolCalls.value
  if (set.has(key)) {
    set.delete(key)
  } else {
    set.add(key)
  }
  expandedToolCalls.value = new Set(set)
}

function toggleToolResultExpand(key: string) {
  const set = expandedToolResults.value
  if (set.has(key)) {
    set.delete(key)
  } else {
    set.add(key)
  }
  expandedToolResults.value = new Set(set)
}

function getMessageContent(entry: RenderMessage): string {
  if (entry.structured) {
    return entry.structured.plainTexts.join('\n')
  }
  return entry.item.content || ''
}

async function copyMessageContent(entry: RenderMessage) {
  const content = getMessageContent(entry)
  try {
    await navigator.clipboard.writeText(content)
    message.success(t('common.copied'))
  } catch {
    message.error(t('common.copyFailed'))
  }
}

async function copyToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text)
    message.success(t('common.copied'))
  } catch {
    message.error(t('common.copyFailed'))
  }
}

const imagePreviewUrl = ref<string | null>(null)
const showImagePreviewModal = ref(false)

function openImagePreview(url: string) {
  imagePreviewUrl.value = url
  showImagePreviewModal.value = true
}

function closeImagePreview() {
  showImagePreviewModal.value = false
  imagePreviewUrl.value = null
}





























const messageList = computed(() => chatStore.messages)

const visibleMessageEntries = computed<RenderMessage[]>(() => {
  const list = messageList.value
  const rendered: RenderMessage[] = []

  for (let idx = 0; idx < list.length; idx += 1) {
    const item = list[idx]
    if (!item) continue
    
    if (item.role === 'tool') {
      const structured = parseToolResultMessage(item)
      if (structured) {
        rendered.push({
          key: item.id || `tool-${idx}`,
          item,
          structured,
        })
      }
      continue
    }
    
    if (item.rawContent && Array.isArray(item.rawContent)) {
      const structured = parseRawContent(item.rawContent)
      if (structured && (structured.toolCalls.length > 0 || structured.thinkings.length > 0 || structured.toolResults.length > 0 || structured.plainTexts.length > 0)) {
        rendered.push({
          key: item.id || `${item.role}-${idx}`,
          item,
          structured,
        })
        continue
      }
    }
    
    const structured = parseStructuredMessage(item.content)
    if (isThinkingOnlyStructuredMessage(structured)) continue
    rendered.push({
      key: item.id || `${item.role}-${idx}`,
      item,
      structured,
    })
  }

  return rendered
})

const currentAgentId = computed(() => {
  const sessionKey = chatStore.sessionKey
  if (!sessionKey) return 'default'
  const match = sessionKey.match(/^agent:([^:]+):/)
  if (match && match[1]) {
    return match[1]
  }
  return 'default'
})

const currentAgentStatus = computed(() => {
  return chatStore.getOrCreateAgentStatus(currentAgentId.value)
})

const agentBusy = computed(() => {
  const phase = currentAgentStatus.value.phase
  return (
    phase === 'sending' ||
    phase === 'waiting' ||
    phase === 'thinking' ||
    phase === 'tool' ||
    phase === 'replying' ||
    phase === 'aborting'
  )
})

const currentToolProgress = computed(() => {
  return chatStore.toolProgress.get(currentAgentId.value) || null
})

const agentBusyToolName = computed(() => {
  if (!agentBusy.value) return ''

  const toolProgress = currentToolProgress.value
  if (toolProgress && toolProgress.phase !== 'result' && toolProgress.name.trim()) {
    return toolProgress.name.trim()
  }

  const phase = currentAgentStatus.value.phase
  if (phase === 'replying' || phase === 'aborting') return ''

  const runId = currentAgentStatus.value.runId
  const list = visibleMessageEntries.value
  let startIndex = 0
  if (runId) {
    const idx = list.findIndex((entry) => entry.item.id === runId)
    if (idx >= 0) startIndex = idx + 1
  }

  for (let i = list.length - 1; i >= startIndex; i -= 1) {
    const entry = list[i]
    if (!entry) continue
    const item = entry.item
    if (item.role !== 'assistant') continue
    const structured = entry.structured
    if (!structured) return ''

    if (structured.toolCalls.length === 0) return ''
    if (structured.toolResults.length >= structured.toolCalls.length) {
      return ''
    }

    const lastToolCall = structured.toolCalls[structured.toolCalls.length - 1]
    if (!lastToolCall?.name) return ''
    const normalized = lastToolCall.name.trim()
    return normalized
  }

  return ''
})

const agentStatusTagType = computed<'default' | 'success' | 'warning' | 'info' | 'error'>(() => {
  if (agentBusyToolName.value) return 'warning'
  const phase = currentAgentStatus.value.phase
  if (phase === 'replying' || phase === 'sending' || phase === 'waiting' || phase === 'thinking') return 'info'
  if (phase === 'tool' || phase === 'aborting' || phase === 'aborted') return 'warning'
  if (phase === 'done') return 'success'
  if (phase === 'error') return 'error'
  return 'default'
})

const agentStatusText = computed(() => {
  if (agentBusyToolName.value) return t('pages.chat.agentStatus.toolCall', { name: agentBusyToolName.value })
  const status = currentAgentStatus.value
  if (status.phase === 'sending') return t('pages.chat.agentStatus.sending')
  if (status.phase === 'waiting') return t('pages.chat.agentStatus.waiting')
  if (status.phase === 'thinking') return status.detail ? status.detail : t('pages.chat.agentStatus.thinking')
  if (status.phase === 'tool') {
    return status.detail
      ? t('pages.chat.agentStatus.toolCall', { name: status.detail })
      : t('pages.chat.agentStatus.toolRunning')
  }
  if (status.phase === 'replying') return t('pages.chat.agentStatus.replying')
  if (status.phase === 'aborting') return t('pages.chat.agentStatus.aborting')
  if (status.phase === 'done') return t('pages.chat.agentStatus.done')
  if (status.phase === 'aborted') return t('pages.chat.agentStatus.aborted')
  if (status.phase === 'error') {
    return status.detail
      ? t('pages.chat.agentStatus.errorWithDetail', { detail: status.detail })
      : t('pages.chat.agentStatus.error')
  }
  return t('pages.chat.agentStatus.idle')
})

const hasAgentDetails = computed(() => {
  if (agentBusy.value) return true
  const agentSteps = chatStore.agentSteps.get(currentAgentId.value)
  if (agentSteps && agentSteps.length > 0) return true
  if (currentToolProgress.value) return true
  return false
})

const toolElapsedMs = computed(() => {
  const progress = currentToolProgress.value
  if (!progress) return 0
  const endAt = progress.phase === 'result' ? progress.updatedAtMs : nowMs.value
  return endAt - progress.startedAtMs
})

function formatClock(ts: number): string {
  if (!Number.isFinite(ts) || ts <= 0) return '--:--:--'
  return new Date(ts).toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  })
}

function formatDurationMs(ms: number): string {
  const safe = Math.max(0, Math.floor(ms))
  const totalSec = Math.floor(safe / 1000)
  const min = Math.floor(totalSec / 60)
  const sec = totalSec % 60
  if (min <= 0) return `${sec}s`
  return `${min}m${String(sec).padStart(2, '0')}s`
}

async function handleAbort() {
  if (aborting.value) return
  if (!agentBusy.value) return

  aborting.value = true
  try {
    await chatStore.abortActiveRun()
    message.info(t('pages.chat.messages.abortRequested'))
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error)
    message.error(t('pages.chat.messages.abortFailed', { reason }))
  } finally {
    aborting.value = false
  }
}



function renderChatMarkdown(content: string, role?: ChatMessage['role']): string {
  const text = content || ''
  if (!looksLikeMarkdown(text)) {
    return renderPlainText(text)
  }
  const autoNestList = role === 'assistant' || role === 'tool' || role === 'system'
  return renderSimpleMarkdown(text, { autoNestList })
}

function roleType(role: string): 'default' | 'success' | 'info' | 'warning' {
  if (role === 'user') return 'info'
  if (role === 'assistant') return 'success'
  if (role === 'tool') return 'warning'
  return 'default'
}

function roleLabel(role: string): string {
  if (role === 'user') return t('pages.chat.roles.user')
  if (role === 'assistant') return t('pages.chat.roles.assistant')
  if (role === 'tool') return t('pages.chat.roles.tool')
  if (role === 'system') return t('pages.chat.roles.system')
  return role
}

function isNearBottom(scrollbar: InstanceType<typeof NScrollbar> | null): boolean {
  if (!scrollbar) return true
  const el = scrollbar.$el as HTMLElement | undefined
  if (!el) return true
  const containerEl = el.querySelector('.n-scrollbar-container') as HTMLElement | null
  if (!containerEl) return true
  const distance = containerEl.scrollHeight - containerEl.scrollTop - containerEl.clientHeight
  return distance <= BOTTOM_GAP
}

const TOP_THRESHOLD = 50
function isNearTop(scrollbar: InstanceType<typeof NScrollbar> | null): boolean {
  if (!scrollbar) return false
  const el = scrollbar.$el as HTMLElement | undefined
  if (!el) return false
  const containerEl = el.querySelector('.n-scrollbar-container') as HTMLElement | null
  if (!containerEl) return false
  return containerEl.scrollTop <= TOP_THRESHOLD
}

function handleTranscriptScroll() {
  autoFollowBottom.value = isNearBottom(scrollRef.value)
  // Load older messages when scrolled to top
  if (isNearTop(scrollRef.value) && chatStore.hasMore && !chatStore.loadingOlder) {
    const scrollbar = scrollRef.value
    const prevScrollHeight = scrollbar?.$el
      ?.querySelector('.n-scrollbar-container')?.scrollHeight ?? 0
    chatStore.loadOlderMessages().then(() => {
      // Preserve scroll position after prepending older messages
      nextTick(() => {
        const container = scrollbar?.$el?.querySelector('.n-scrollbar-container') as HTMLElement | null
        if (container) {
          container.scrollTop = container.scrollHeight - prevScrollHeight
        }
      })
    })
  }
}

function handleExpandedScroll() {
  autoFollowBottom.value = isNearBottom(expandedScrollRef.value)
}

function scrollToBottom(options?: { force?: boolean; expanded?: boolean }) {
  const scrollbar = options?.expanded ? expandedScrollRef.value : scrollRef.value
  if (!scrollbar) return

  const force = options?.force ?? false
  if (!force && !autoFollowBottom.value) return

  nextTick(() => {
    scrollbar.scrollTo({ top: Number.MAX_SAFE_INTEGER })
  })
}

function requestScrollToBottom(options?: { force?: boolean; expanded?: boolean }) {
  const force = options?.force ?? false
  if (!force && !autoFollowBottom.value) return
  if (force) pendingForceScroll = true
  if (pendingScroll) return

  pendingScroll = true
  const schedule =
    typeof queueMicrotask === 'function' ? queueMicrotask : (fn: () => void) => Promise.resolve().then(fn)
  schedule(() => {
    pendingScroll = false
    if (destroyed) return
    const forceNow = pendingForceScroll
    pendingForceScroll = false
    scrollToBottom({ force: forceNow, expanded: options?.expanded })
  })
}

function cancelPendingScroll() {
  destroyed = true
  pendingForceScroll = false
  pendingScroll = false
}

async function handleSend() {
  const content = draft.value.trim()
  if (!content) return
  if (agentBusy.value) return

  try {
    const sessionKey = selectedSessionKey.value || (selectedAgent.value ? `${selectedAgent.value.id}:main` : 'main')
    chatStore.setSessionKey(sessionKey)
    await chatStore.sendMessage(content)
    void sessionStore.refreshSessionTokenUsage(sessionKey)
    draft.value = ''
    await nextTick()
    autoFollowBottom.value = true
    requestScrollToBottom({ force: true })
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error)
    message.error(reason)
  }
}

function openExpandedModal() {
  showExpandedModal.value = true
  nextTick(() => {
    if (expandedScrollRef.value) {
      expandedScrollRef.value.scrollTo({ top: Number.MAX_SAFE_INTEGER })
    }
  })
}

function closeExpandedModal() {
  showExpandedModal.value = false
}

const messageSignature = computed(() => {
  const list = visibleMessageEntries.value
  const last = list.length > 0 ? list[list.length - 1]?.item : null
  const lastContentLength = last?.content ? last.content.length : 0
  return `${list.length}|${last?.id || ''}|${last?.role || ''}|${last?.timestamp || ''}|${lastContentLength}`
})

watch(
  messageSignature,
  async (next, prev) => {
    if (next === prev) return
    requestScrollToBottom()
    requestScrollToBottom({ expanded: true })
  },
  { flush: 'post' }
)

onMounted(async () => {
  nowTimer = setInterval(() => {
    nowMs.value = Date.now()
  }, 1000)

  quickReplies.value = loadQuickRepliesUtil()

  eventCleanups.push(
    wsStore.subscribe('event', (evt: unknown) => {
      const data = evt as { event?: string; payload?: unknown }
      const eventName = data.event || ''
      if (
        eventName === 'chat' ||
        eventName.startsWith('chat.') ||
        eventName === 'agent' ||
        eventName.startsWith('agent.') ||
        eventName.startsWith('tool.') ||
        eventName.startsWith('model.')
      ) {
        const name = eventName.toLowerCase()
        const isStreamingEvent =
          name.includes('stream') ||
          name.includes('delta') ||
          name.includes('chunk') ||
          name.includes('partial')
        chatStore.handleAgentStatusEvent(eventName, data.payload)
        chatStore.handleRealtimeEvent(data.payload, {
          refreshHistory: false,
          streaming: isStreamingEvent,
        })
      }
    })
  )

  const sessionKey = selectedSessionKey.value || (selectedAgent.value ? `${selectedAgent.value.id}:main` : null)
  if (sessionKey) {
    chatStore.setSessionKey(sessionKey)
    await chatStore.fetchHistory(sessionKey)
    await nextTick()
    autoFollowBottom.value = true
    requestScrollToBottom({ force: true })
    requestScrollToBottom({ force: true, expanded: true })
  }
})

onUnmounted(() => {
  eventCleanups.forEach((cleanup) => cleanup())
  chatStore.clearTimers()
  cancelPendingScroll()
  if (nowTimer) {
    clearInterval(nowTimer)
    nowTimer = null
  }
})

watch(selectedSessionKey, async (newSessionKey) => {
  if (newSessionKey) {
    chatStore.setSessionKey(newSessionKey)
    await chatStore.fetchHistory(newSessionKey)
    await nextTick()
    autoFollowBottom.value = true
    requestScrollToBottom({ force: true })
    requestScrollToBottom({ force: true, expanded: true })
  }
})
</script>

<template>
  <NCard :title="panelTitle" size="small" embedded class="chat-panel-card">
    <template #header-extra>
      <NSpace :size="8" align="center">
        <div v-if="sessionTokenMetricTags.length" class="chat-token-metrics">
          <NTag
            v-for="metric in sessionTokenMetricTags"
            :key="metric.key"
            size="small"
            :bordered="false"
            round
            class="chat-token-chip"
            :class="{ 'chat-token-chip--total': metric.highlight }"
          >
            <span class="chat-token-chip__label">{{ metric.label }}</span>
            <span class="chat-token-chip__value">{{ metric.value }}</span>
          </NTag>
        </div>
        <NTag v-else-if="selectedSessionKey" size="small" :bordered="false" round class="chat-token-chip chat-token-chip--loading">
          {{ sessionTokenStatusText }}
        </NTag>
        <NTag v-if="executionInProgress" size="small" type="info" :bordered="false" round class="glass-effect">
          <template #icon>
            <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
          </template>
          {{ t('pages.office.chat.executing') }}
        </NTag>
        <NTooltip v-if="selectedSession">
          <template #trigger>
            <NTag size="small" :bordered="false" round class="session-tag">
              <span class="session-tag__text">
                {{ selectedAgent?.name || 'Agent' }} / {{ selectedSession.label || selectedSession.key.slice(0, 16) }}
              </span>
            </NTag>
          </template>
          {{ t('pages.office.chat.chattingWith') }}: {{ selectedAgent?.name }} - {{ selectedSession.label || selectedSession.key }}
        </NTooltip>
        <NTooltip>
          <template #trigger>
            <NSwitch v-model:value="autoFollowBottom" size="small" />
          </template>
          {{ t('pages.chat.preferences.autoFollow') }}
        </NTooltip>
        <NButton size="tiny" quaternary class="glass-effect" @click="openExpandedModal">
          <template #icon>
            <span class="material-symbols-outlined">fullscreen</span>
          </template>
        </NButton>
      </NSpace>
    </template>

    <div class="chat-panel">
      <div v-if="!selectedSessionKey" class="chat-empty">
        <NEmpty :description="t('pages.office.chat.selectSession')" />
      </div>

      <template v-else>
        <div v-if="activeTasks.length > 0" class="active-tasks-bar glass-effect">
          <NSpace :size="8" align="center">
            <span class="material-symbols-outlined" style="color: #2080f0; font-size: 16px;">schedule</span>
            <NText depth="3" style="font-size: 12px;">
              {{ t('pages.office.chat.activeTasks', { count: activeTasks.length }) }}
            </NText>
          </NSpace>
        </div>

        <NScrollbar ref="scrollRef" class="chat-messages" @scroll="handleTranscriptScroll">
          <div v-if="visibleMessageEntries.length === 0" class="chat-empty">
            <NEmpty :description="t('pages.office.chat.noMessages')" />
          </div>
          <div v-else class="message-list">
            <div
              v-for="entry in visibleMessageEntries"
              :key="entry.key"
              class="chat-bubble"
              :class="`is-${entry.item.role}`"
            >
              <NSpace justify="space-between" align="center" class="chat-bubble-meta" :size="8">
                <NSpace align="center" :size="6">
                  <NTag size="small" :type="roleType(entry.item.role)" :bordered="false" round>
                    {{ roleLabel(entry.item.role) }}
                  </NTag>
                  <NText v-if="entry.item.name" depth="3" style="font-size: 12px;">
                    {{ entry.item.name }}
                  </NText>
                </NSpace>
                <NText v-if="entry.item.timestamp" depth="3" style="font-size: 12px;">
                  {{ formatDate(entry.item.timestamp) }}
                </NText>
              </NSpace>

              <div v-if="entry.structured" class="structured-message-list">
                <div v-if="entry.structured.toolCalls.length" class="tool-call-list">
                  <div
                    v-for="(tool, toolIndex) in entry.structured.toolCalls"
                    :key="`${entry.key}-tool-${toolIndex}`"
                    class="tool-call-card"
                  >
                    <NSpace align="center" justify="space-between">
                      <NSpace align="center" :size="6">
                        <NTag size="small" type="warning" :bordered="false" round>{{ t('pages.chat.structured.toolCall') }}</NTag>
                        <NText strong>{{ tool.name }}</NText>
                      </NSpace>
                      <NSpace align="center" :size="8">
                        <NText v-if="tool.timeout" depth="3" style="font-size: 12px;">
                          {{ t('pages.chat.structured.timeout', { seconds: tool.timeout }) }}
                        </NText>
                        <NButton
                          v-if="tool.argumentsJson"
                          size="tiny"
                          text
                          @click="toggleToolCallExpand(`${entry.key}-tool-${toolIndex}`)"
                        >
                          {{ expandedToolCalls.has(`${entry.key}-tool-${toolIndex}`) ? t('pages.chat.structured.hideArgs') : t('pages.chat.structured.viewArgs') }}
                        </NButton>
                      </NSpace>
                    </NSpace>

                    <div v-if="tool.command || tool.workdir" class="tool-call-meta">
                      <code v-if="tool.command" class="tool-call-meta__code">{{ tool.command }}</code>
                      <code v-if="tool.workdir" class="tool-call-meta__code">{{ tool.workdir }}</code>
                    </div>

                    <div v-if="tool.argumentsJson && expandedToolCalls.has(`${entry.key}-tool-${toolIndex}`)" class="tool-call-args">
                      <pre class="tool-call-args__content">{{ tool.argumentsJson }}</pre>
                    </div>

                    <details v-if="tool.partialJson" class="tool-call-details">
                      <summary>{{ t('pages.chat.structured.viewPartialJson') }}</summary>
                      <pre>{{ tool.partialJson }}</pre>
                    </details>
                  </div>
                </div>

                <div v-if="entry.structured.toolResults.length" class="tool-result-list">
                  <div
                    v-for="(result, resultIndex) in entry.structured.toolResults"
                    :key="`${entry.key}-tool-result-${resultIndex}`"
                    class="tool-result-card"
                  >
                    <NSpace align="center" justify="space-between">
                      <NSpace align="center" :size="6">
                        <NTag size="small" type="success" :bordered="false" round>{{ t('pages.chat.structured.toolResult') }}</NTag>
                        <NText strong>{{ result.name || 'unknown' }}</NText>
                      </NSpace>
                      <NSpace align="center" :size="8">
                        <NText v-if="result.status" depth="3" style="font-size: 12px;">
                          {{ result.status }}
                        </NText>
                        <NButton
                          size="tiny"
                          text
                          @click="toggleToolResultExpand(`${entry.key}-result-${resultIndex}`)"
                        >
                          {{ expandedToolResults.has(`${entry.key}-result-${resultIndex}`) ? t('pages.chat.structured.hideArgs') : t('pages.chat.structured.viewArgs') }}
                        </NButton>
                      </NSpace>
                    </NSpace>

                    <div v-if="expandedToolResults.has(`${entry.key}-result-${resultIndex}`)" class="tool-call-grid">
                      <span class="tool-call-label">{{ t('pages.chat.structured.callId') }}</span>
                      <div class="tool-call-value-wrapper">
                        <code>{{ result.id || '-' }}</code>
                        <NTooltip>
                          <template #trigger>
                            <NButton quaternary size="tiny" class="tool-value-copy-btn" @click="copyToClipboard(result.id || '-')">
                              <template #icon>
                              <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                              </template>
                            </NButton>
                          </template>
                          {{ t('common.copy') }}
                        </NTooltip>
                      </div>
                      <span class="tool-call-label">{{ t('pages.chat.structured.content') }}</span>
                      <div class="tool-call-value-wrapper tool-result-content-wrapper">
                        <pre class="tool-result-content">{{ result.content }}</pre>
                        <NTooltip>
                          <template #trigger>
                            <NButton quaternary size="tiny" class="tool-value-copy-btn" @click="copyToClipboard(result.content)">
                              <template #icon>
                                <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                              </template>
                            </NButton>
                          </template>
                          {{ t('common.copy') }}
                        </NTooltip>
                      </div>
                    </div>
                  </div>
                </div>

                <div v-if="entry.structured.validationErrors.length" class="validation-error-list">
                  <div
                    v-for="(validation, validationIndex) in entry.structured.validationErrors"
                    :key="`${entry.key}-validation-${validationIndex}`"
                    class="validation-error-card"
                  >
                    <NSpace align="center" justify="space-between">
                      <NSpace align="center" :size="6">
                        <NTag size="small" type="warning" :bordered="false" round>{{ t('pages.chat.structured.validationFailed') }}</NTag>
                        <NText strong>{{ validation.toolName }}</NText>
                      </NSpace>
                      <NText depth="3" style="font-size: 12px;">
                        {{ t('pages.chat.structured.issuesCount', { count: validation.issues.length }) }}
                      </NText>
                    </NSpace>

                    <div class="tool-call-grid">
                      <span class="tool-call-label">{{ t('pages.chat.structured.issues') }}</span>
                      <div class="validation-issues">
                        <div v-if="validation.issues.length === 0">-</div>
                        <div v-for="(issue, issueIndex) in validation.issues" :key="issueIndex">
                          - {{ issue }}
                        </div>
                      </div>
                    </div>

                    <details v-if="validation.argumentsText" class="tool-call-details">
                      <summary>{{ t('pages.chat.structured.viewArgs') }}</summary>
                      <pre>{{ validation.argumentsText }}</pre>
                    </details>
                  </div>
                </div>

                <div v-if="entry.structured.plainTexts.length" class="chat-bubble-content-wrapper">
                  <div
                    class="chat-bubble-content structured-plain-text chat-markdown"
                    v-html="renderChatMarkdown(entry.structured.plainTexts.join('\n'), entry.item.role)"
                  ></div>
                  <div class="chat-content-copy-btn">
                    <NTooltip>
                      <template #trigger>
                        <NButton quaternary size="tiny" @click="copyMessageContent(entry)">
                          <template #icon>
                            <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                          </template>
                        </NButton>
                      </template>
                      {{ t('common.copy') }}
                    </NTooltip>
                  </div>
                </div>

                <div v-if="entry.structured.images.length" class="chat-images-container">
                  <div
                    v-for="(img, imgIndex) in entry.structured.images"
                    :key="`${entry.key}-img-${imgIndex}`"
                    class="chat-image-wrapper"
                  >
                    <img
                      v-if="img.url"
                      :src="img.url"
                      class="chat-image"
                      loading="lazy"
                      @click="openImagePreview(img.url)"
                    />
                    <span v-else class="chat-image-placeholder">{{ t('pages.chat.image.unavailable') }}</span>
                  </div>
                </div>
              </div>

              <div v-else class="chat-bubble-content-wrapper">
                <div
                  class="chat-bubble-content chat-markdown"
                  v-html="renderChatMarkdown(entry.item.content, entry.item.role)"
                ></div>
                <div class="chat-content-copy-btn">
                  <NTooltip>
                    <template #trigger>
                      <NButton quaternary size="tiny" @click="copyMessageContent(entry)">
                        <template #icon>
                          <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                        </template>
                      </NButton>
                    </template>
                    {{ t('common.copy') }}
                  </NTooltip>
                </div>
              </div>
            </div>
          </div>
        </NScrollbar>

        <NCollapse class="chat-quick-collapse">
          <NCollapseItem :title="t('pages.chat.quickReplies.title')" name="quick-replies">
            <template #header-extra>
              <NButton size="tiny" type="primary" secondary @click.stop="openCreateQuickReply">{{ t('pages.chat.quickReplies.add') }}</NButton>
            </template>
            <NInput
              v-model:value="quickReplySearch"
              size="small"
              :placeholder="t('pages.chat.quickReplies.searchPlaceholder')"
            />

            <div v-if="filteredQuickReplies.length" class="chat-quick-list">
              <div v-for="item in filteredQuickReplies" :key="item.id" class="chat-quick-item">
                <NSpace justify="space-between" align="start" :wrap="false">
                  <div style="min-width: 0; flex: 1;">
                    <NText strong style="font-size: 12px;">{{ item.title }}</NText>
                    <NText depth="3" style="display: block; font-size: 11px; margin-top: 2px;">
                      {{ truncate(item.content, 60) }}
                    </NText>
                  </div>
                  <NSpace :size="2">
                    <NButton size="tiny" text @click="handleInsertQuickReply(item)">{{ t('pages.chat.quickReplies.insert') }}</NButton>
                    <NButton size="tiny" text type="primary" @click="handleSendQuickReply(item)">{{ t('pages.chat.actions.send') }}</NButton>
                    <NButton size="tiny" text @click="openEditQuickReply(item)">{{ t('common.edit') }}</NButton>
                    <NPopconfirm
                      :positive-text="t('common.delete')"
                      :negative-text="t('common.cancel')"
                      @positive-click="handleDeleteQuickReply(item.id)"
                    >
                      <template #trigger>
                        <NButton size="tiny" text type="error">{{ t('common.delete') }}</NButton>
                      </template>
                      {{ t('pages.chat.quickReplies.confirmDelete') }}
                    </NPopconfirm>
                  </NSpace>
                </NSpace>
              </div>
            </div>
            <NEmpty v-else :description="t('pages.chat.quickReplies.empty')" style="padding: 10px 0 6px;" size="small" />
          </NCollapseItem>
        </NCollapse>

        <div class="chat-input">
          <NInput
            v-model:value="draft"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4 }"
            :placeholder="t('pages.office.chat.inputPlaceholder')"
            @keydown="handleDraftKeydown"
          />

          <div class="chat-compose-status-line">
            <NTag
              size="small"
              :type="agentStatusTagType"
              :bordered="false"
              round
              class="chat-agent-status-tag"
            >
              {{ agentStatusText }}
            </NTag>
            <NButton
              v-if="hasAgentDetails"
              size="tiny"
              text
              @click="showAgentDetails = !showAgentDetails"
            >
              {{ showAgentDetails ? t('pages.chat.agentDetails.hide') : t('pages.chat.agentDetails.show') }}
            </NButton>
          </div>

          <div v-if="showAgentDetails && hasAgentDetails" class="chat-agent-details">
            <NSpace vertical :size="6">
              <NText depth="3" style="font-size: 12px;">
                {{ t('pages.chat.agentDetails.phaseDuration', { duration: formatDurationMs(nowMs - currentAgentStatus.sinceMs) }) }}
              </NText>

              <div v-if="chatStore.agentSteps.get(currentAgentId)?.length" class="chat-agent-steps">
                <div v-for="(step, index) in chatStore.agentSteps.get(currentAgentId)" :key="`step-${step.ts}-${index}`" class="chat-agent-step">
                  <span class="chat-agent-step__time">{{ formatClock(step.ts) }}</span>
                  <span class="chat-agent-step__label">{{ step.label }}</span>
                </div>
              </div>

              <div v-if="currentToolProgress" class="chat-tool-progress">
                <div class="chat-tool-progress__title">
                  <span>{{ t('pages.chat.agentDetails.tool', { name: currentToolProgress.name }) }}</span>
                  <span v-if="currentToolProgress.meta" class="chat-tool-progress__meta">{{ currentToolProgress.meta }}</span>
                </div>
                <div class="chat-tool-progress__kv">
                  <span class="chat-tool-progress__k">{{ t('pages.chat.structured.callId') }}</span>
                  <code class="chat-tool-progress__v">{{ currentToolProgress.toolCallId }}</code>
                  <span class="chat-tool-progress__k">{{ t('pages.chat.agentDetails.phase') }}</span>
                  <code class="chat-tool-progress__v">{{ currentToolProgress.phase }}</code>
                  <span class="chat-tool-progress__k">{{ t('pages.chat.agentDetails.elapsed') }}</span>
                  <code class="chat-tool-progress__v">
                    {{ formatDurationMs(toolElapsedMs) }}
                  </code>
                </div>

                <details v-if="currentToolProgress.argsPreview" class="tool-call-details">
                  <summary>{{ t('pages.chat.structured.viewArgs') }}</summary>
                  <pre>{{ currentToolProgress.argsPreview }}</pre>
                </details>

                <details v-if="currentToolProgress.partialPreview" class="tool-call-details">
                  <summary>{{ t('pages.chat.agentDetails.viewPartialResult') }}</summary>
                  <pre>{{ currentToolProgress.partialPreview }}</pre>
                </details>

                <details v-if="currentToolProgress.resultPreview" class="tool-call-details">
                  <summary>{{ t('pages.chat.agentDetails.viewResult') }}</summary>
                  <pre>{{ currentToolProgress.resultPreview }}</pre>
                </details>
              </div>
            </NSpace>
          </div>

          <div class="chat-actions">
            <NButton
              v-if="agentBusy"
              size="small"
              type="warning"
              secondary
              :loading="aborting"
              :disabled="aborting"
              class="glass-effect"
              @click="handleAbort"
            >
              <template #icon><span class="material-symbols-outlined">stop_circle</span></template>
              {{ t('pages.chat.actions.stop') }}
            </NButton>
            <NButton size="small" type="primary" :loading="agentBusy" :disabled="agentBusy || !draft.trim()" class="glass-effect" @click="handleSend">
              <template #icon><span class="material-symbols-outlined">send</span></template>
              {{ t('pages.office.chat.send') }}
            </NButton>
          </div>
        </div>
      </template>
    </div>
  </NCard>

  <NModal
    v-model:show="showExpandedModal"
    preset="card"
    :title="t('pages.office.chat.expandedTitle')"
    :style="{ width: '90vw', maxWidth: '1400px', height: '85vh' }"
    :mask-closable="true"
    class="expanded-chat-modal"
  >
    <template #header-extra>
      <NButton size="small" quaternary class="glass-effect" @click="closeExpandedModal">
        <template #icon>
          <span class="material-symbols-outlined">fullscreen_exit</span>
        </template>
      </NButton>
    </template>

    <div class="expanded-chat-content">
      <div v-if="!selectedSessionKey" class="chat-empty">
        <NEmpty :description="t('pages.office.chat.selectSession')" />
      </div>

      <template v-else>
        <NScrollbar ref="expandedScrollRef" class="expanded-chat-messages" @scroll="handleExpandedScroll">
          <div v-if="visibleMessageEntries.length === 0" class="chat-empty">
            <NEmpty :description="t('pages.office.chat.noMessages')" />
          </div>
          <div v-else class="message-list expanded">
            <div
              v-for="entry in visibleMessageEntries"
              :key="entry.key"
              class="chat-bubble"
              :class="`is-${entry.item.role}`"
            >
              <NSpace justify="space-between" align="center" class="chat-bubble-meta" :size="8">
                <NSpace align="center" :size="6">
                  <NTag size="small" :type="roleType(entry.item.role)" :bordered="false" round>
                    {{ roleLabel(entry.item.role) }}
                  </NTag>
                  <NText v-if="entry.item.name" depth="3" style="font-size: 12px;">
                    {{ entry.item.name }}
                  </NText>
                </NSpace>
                <NText v-if="entry.item.timestamp" depth="3" style="font-size: 12px;">
                  {{ formatDate(entry.item.timestamp) }}
                </NText>
              </NSpace>

              <div v-if="entry.structured" class="structured-message-list">
                <div v-if="entry.structured.toolCalls.length" class="tool-call-list">
                  <div
                    v-for="(tool, toolIndex) in entry.structured.toolCalls"
                    :key="`${entry.key}-tool-${toolIndex}`"
                    class="tool-call-card"
                  >
                    <NSpace align="center" justify="space-between">
                      <NSpace align="center" :size="6">
                        <NTag size="small" type="warning" :bordered="false" round>{{ t('pages.chat.structured.toolCall') }}</NTag>
                        <NText strong>{{ tool.name }}</NText>
                      </NSpace>
                      <NSpace align="center" :size="8">
                        <NText v-if="tool.timeout" depth="3" style="font-size: 12px;">
                          {{ t('pages.chat.structured.timeout', { seconds: tool.timeout }) }}
                        </NText>
                        <NButton
                          v-if="tool.argumentsJson"
                          size="tiny"
                          text
                          @click="toggleToolCallExpand(`${entry.key}-tool-${toolIndex}`)"
                        >
                          {{ expandedToolCalls.has(`${entry.key}-tool-${toolIndex}`) ? t('pages.chat.structured.hideArgs') : t('pages.chat.structured.viewArgs') }}
                        </NButton>
                      </NSpace>
                    </NSpace>

                    <div v-if="tool.command || tool.workdir" class="tool-call-meta">
                      <code v-if="tool.command" class="tool-call-meta__code">{{ tool.command }}</code>
                      <code v-if="tool.workdir" class="tool-call-meta__code">{{ tool.workdir }}</code>
                    </div>

                    <div v-if="tool.argumentsJson && expandedToolCalls.has(`${entry.key}-tool-${toolIndex}`)" class="tool-call-args">
                      <pre class="tool-call-args__content">{{ tool.argumentsJson }}</pre>
                    </div>
                  </div>
                </div>

                <div v-if="entry.structured.toolResults.length" class="tool-result-list">
                  <div
                    v-for="(result, resultIndex) in entry.structured.toolResults"
                    :key="`${entry.key}-tool-result-${resultIndex}`"
                    class="tool-result-card"
                  >
                    <NSpace align="center" justify="space-between">
                      <NSpace align="center" :size="6">
                        <NTag size="small" type="success" :bordered="false" round>{{ t('pages.chat.structured.toolResult') }}</NTag>
                        <NText strong>{{ result.name || 'unknown' }}</NText>
                      </NSpace>
                      <NSpace align="center" :size="8">
                        <NText v-if="result.status" depth="3" style="font-size: 12px;">
                          {{ result.status }}
                        </NText>
                        <NButton
                          size="tiny"
                          text
                          @click="toggleToolResultExpand(`${entry.key}-result-${resultIndex}`)"
                        >
                          {{ expandedToolResults.has(`${entry.key}-result-${resultIndex}`) ? t('pages.chat.structured.hideArgs') : t('pages.chat.structured.viewArgs') }}
                        </NButton>
                      </NSpace>
                    </NSpace>

                    <div v-if="expandedToolResults.has(`${entry.key}-result-${resultIndex}`)" class="tool-call-grid">
                      <span class="tool-call-label">{{ t('pages.chat.structured.callId') }}</span>
                      <div class="tool-call-value-wrapper">
                        <code>{{ result.id || '-' }}</code>
                        <NTooltip>
                          <template #trigger>
                            <NButton quaternary size="tiny" class="tool-value-copy-btn" @click="copyToClipboard(result.id || '-')">
                              <template #icon>
                                <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                              </template>
                            </NButton>
                          </template>
                          {{ t('common.copy') }}
                        </NTooltip>
                      </div>
                      <span class="tool-call-label">{{ t('pages.chat.structured.content') }}</span>
                      <div class="tool-call-value-wrapper tool-result-content-wrapper">
                        <pre class="tool-result-content">{{ result.content }}</pre>
                        <NTooltip>
                          <template #trigger>
                            <NButton quaternary size="tiny" class="tool-value-copy-btn" @click="copyToClipboard(result.content)">
                              <template #icon>
                                <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                              </template>
                            </NButton>
                          </template>
                          {{ t('common.copy') }}
                        </NTooltip>
                      </div>
                    </div>
                  </div>
                </div>

                <div v-if="entry.structured.plainTexts.length" class="chat-bubble-content-wrapper">
                  <div
                    class="chat-bubble-content structured-plain-text chat-markdown"
                    v-html="renderChatMarkdown(entry.structured.plainTexts.join('\n'), entry.item.role)"
                  ></div>
                  <div class="chat-content-copy-btn">
                    <NTooltip>
                      <template #trigger>
                        <NButton quaternary size="tiny" @click="copyMessageContent(entry)">
                          <template #icon>
                            <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                          </template>
                        </NButton>
                      </template>
                      {{ t('common.copy') }}
                    </NTooltip>
                  </div>
                </div>

                <div v-if="entry.structured.images.length" class="chat-images-container">
                  <div
                    v-for="(img, imgIndex) in entry.structured.images"
                    :key="`${entry.key}-img-${imgIndex}`"
                    class="chat-image-wrapper"
                  >
                    <img
                      v-if="img.url"
                      :src="img.url"
                      class="chat-image"
                      loading="lazy"
                      @click="openImagePreview(img.url)"
                    />
                    <span v-else class="chat-image-placeholder">{{ t('pages.chat.image.unavailable') }}</span>
                  </div>
                </div>
              </div>

              <div v-else class="chat-bubble-content-wrapper">
                <div
                  class="chat-bubble-content chat-markdown"
                  v-html="renderChatMarkdown(entry.item.content, entry.item.role)"
                ></div>
                <div class="chat-content-copy-btn">
                  <NTooltip>
                    <template #trigger>
                      <NButton quaternary size="tiny" @click="copyMessageContent(entry)">
                        <template #icon>
                          <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
                        </template>
                      </NButton>
                    </template>
                    {{ t('common.copy') }}
                  </NTooltip>
                </div>
              </div>
            </div>
          </div>
        </NScrollbar>

        <div class="chat-input expanded">
          <NInput
            v-model:value="draft"
            type="textarea"
            :autosize="{ minRows: 3, maxRows: 6 }"
            :placeholder="t('pages.office.chat.inputPlaceholder')"
            @keydown="handleDraftKeydown"
          />

          <div class="chat-compose-status-line">
            <NTag
              size="small"
              :type="agentStatusTagType"
              :bordered="false"
              round
              class="chat-agent-status-tag"
            >
              {{ agentStatusText }}
            </NTag>
            <NButton
              v-if="hasAgentDetails"
              size="tiny"
              text
              @click="showAgentDetails = !showAgentDetails"
            >
              {{ showAgentDetails ? t('pages.chat.agentDetails.hide') : t('pages.chat.agentDetails.show') }}
            </NButton>
          </div>

          <div v-if="showAgentDetails && hasAgentDetails" class="chat-agent-details">
            <NSpace vertical :size="6">
              <NText depth="3" style="font-size: 12px;">
                {{ t('pages.chat.agentDetails.phaseDuration', { duration: formatDurationMs(nowMs - currentAgentStatus.sinceMs) }) }}
              </NText>

              <div v-if="chatStore.agentSteps.get(currentAgentId)?.length" class="chat-agent-steps">
                <div v-for="(step, index) in chatStore.agentSteps.get(currentAgentId)" :key="`step-${step.ts}-${index}`" class="chat-agent-step">
                  <span class="chat-agent-step__time">{{ formatClock(step.ts) }}</span>
                  <span class="chat-agent-step__label">{{ step.label }}</span>
                </div>
              </div>

              <div v-if="currentToolProgress" class="chat-tool-progress">
                <div class="chat-tool-progress__title">
                  <span>{{ t('pages.chat.agentDetails.tool', { name: currentToolProgress.name }) }}</span>
                </div>
                <div class="chat-tool-progress__kv">
                  <span class="chat-tool-progress__k">{{ t('pages.chat.structured.callId') }}</span>
                  <code class="chat-tool-progress__v">{{ currentToolProgress.toolCallId }}</code>
                  <span class="chat-tool-progress__k">{{ t('pages.chat.agentDetails.phase') }}</span>
                  <code class="chat-tool-progress__v">{{ currentToolProgress.phase }}</code>
                  <span class="chat-tool-progress__k">{{ t('pages.chat.agentDetails.elapsed') }}</span>
                  <code class="chat-tool-progress__v">{{ formatDurationMs(toolElapsedMs) }}</code>
                </div>

                <details v-if="currentToolProgress.argsPreview" class="tool-call-details">
                  <summary>{{ t('pages.chat.structured.viewArgs') }}</summary>
                  <pre>{{ currentToolProgress.argsPreview }}</pre>
                </details>

                <details v-if="currentToolProgress.resultPreview" class="tool-call-details">
                  <summary>{{ t('pages.chat.agentDetails.viewResult') }}</summary>
                  <pre>{{ currentToolProgress.resultPreview }}</pre>
                </details>
              </div>
            </NSpace>
          </div>

          <div class="chat-actions">
            <NButton
              v-if="agentBusy"
              size="small"
              type="warning"
              secondary
              :loading="aborting"
              :disabled="aborting"
              class="glass-effect"
              @click="handleAbort"
            >
              <template #icon><span class="material-symbols-outlined">stop_circle</span></template>
              {{ t('pages.chat.actions.stop') }}
            </NButton>
            <NButton size="small" type="primary" :loading="agentBusy" :disabled="agentBusy || !draft.trim()" class="glass-effect" @click="handleSend">
              <template #icon><span class="material-symbols-outlined">send</span></template>
              {{ t('pages.office.chat.send') }}
            </NButton>
          </div>
        </div>
      </template>
    </div>
  </NModal>

  <NModal
    v-model:show="showQuickReplyModal"
    preset="card"
    :title="quickReplyModalMode === 'edit'
      ? t('pages.chat.quickReplies.modal.editTitle')
      : t('pages.chat.quickReplies.modal.createTitle')"
    style="width: 500px; max-width: calc(100vw - 28px);"
  >
    <NForm label-placement="left" label-width="72">
      <NFormItem :label="t('pages.chat.quickReplies.modal.title')" required>
        <NInput v-model:value="quickReplyForm.title" :placeholder="t('pages.chat.quickReplies.modal.titlePlaceholder')" />
      </NFormItem>
      <NFormItem :label="t('pages.chat.quickReplies.modal.content')" required>
        <NInput
          v-model:value="quickReplyForm.content"
          type="textarea"
          :autosize="{ minRows: 4, maxRows: 10 }"
          :placeholder="t('pages.chat.quickReplies.modal.contentPlaceholder')"
        />
      </NFormItem>
    </NForm>
    <template #footer>
      <NSpace justify="end">
        <NButton @click="showQuickReplyModal = false">{{ t('common.cancel') }}</NButton>
        <NButton type="primary" @click="handleSaveQuickReply">
          {{ quickReplyModalMode === 'edit'
            ? t('pages.chat.quickReplies.modal.saveChanges')
            : t('pages.chat.quickReplies.add') }}
        </NButton>
      </NSpace>
    </template>
  </NModal>

  <NModal
    v-model:show="showImagePreviewModal"
    preset="card"
    :title="t('pages.chat.image.preview')"
    style="width: 90vw; max-width: 1200px;"
    :mask-closable="true"
    @update:show="(val: boolean) => { if (!val) closeImagePreview() }"
  >
    <div v-if="imagePreviewUrl" class="image-preview-container">
      <img :src="imagePreviewUrl" class="image-preview-full" />
    </div>
  </NModal>
</template>

<style scoped>
@import './AgentChatPanel.css';
</style>
