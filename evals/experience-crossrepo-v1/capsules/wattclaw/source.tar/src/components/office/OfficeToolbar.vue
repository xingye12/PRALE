<script setup lang="ts">
import { NButton, NText, NSpace } from 'naive-ui'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

defineProps<{
  activeCount: number
  totalAgents: number
  totalTokens: number
}>()

const emit = defineEmits<{
  'create-agent': []
  'refresh': []
  'permission-control': []
}>()

function formatTokens(tokens: number): string {
  if (tokens >= 1000000) {
    return `${(tokens / 1000000).toFixed(1)}M`
  }
  if (tokens >= 1000) {
    return `${(tokens / 1000).toFixed(1)}K`
  }
  return String(tokens)
}
</script>

<template>
  <div class="office-toolbar glass-effect">
    <div class="toolbar-left">
      <div class="toolbar-title">
        <span class="material-symbols-outlined" style="font-size: 20px;">group</span>
        <span>{{ t('pages.myworld.myEmployees') }}</span>
      </div>
    </div>
    
    <div class="toolbar-center">
      <div class="stat-badge glass-effect">
        <span class="material-symbols-outlined" style="font-size: 14px; color: #f59e0b;">bolt</span>
        <span class="stat-value">{{ activeCount }}</span>
        <span class="stat-label">{{ t('pages.myworld.working') }}</span>
      </div>
      
      <div class="stat-badge glass-effect">
        <span class="material-symbols-outlined" style="font-size: 14px; color: #60a5fa;">group</span>
        <span class="stat-value">{{ totalAgents }}</span>
        <span class="stat-label">{{ t('pages.myworld.totalEmployees') }}</span>
      </div>
      
      <div class="stat-badge glass-effect">
        <span class="material-symbols-outlined" style="font-size: 14px; color: #10b981;">leaderboard</span>
        <span class="stat-value">{{ formatTokens(totalTokens) }}</span>
        <span class="stat-label">Token</span>
      </div>
    </div>
    
    <div class="toolbar-right">
      <NButton quaternary size="small" class="glass-effect" @click="emit('create-agent')">
        <template #icon>
          <span class="material-symbols-outlined">add</span>
        </template>
        {{ t('pages.myworld.addEmployee') }}
      </NButton>
      
      <NButton quaternary size="small" class="glass-effect" @click="emit('permission-control')">
        <template #icon>
          <span class="material-symbols-outlined">extension</span>
        </template>
        {{ t('pages.myworld.permissionControl') }}
      </NButton>
      
      <NButton quaternary size="small" class="glass-effect" @click="emit('refresh')">
        <template #icon>
          <span class="material-symbols-outlined">refresh</span>
        </template>
        {{ t('pages.myworld.refresh') }}
      </NButton>
    </div>
  </div>
</template>

<style scoped>
.office-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: rgba(0, 0, 0, 0.3);
  border-bottom: 1px solid var(--border-color, #333);
}

.toolbar-left {
  display: flex;
  align-items: center;
}

.toolbar-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: #fff;
}

.toolbar-center {
  display: flex;
  gap: 20px;
}

.stat-badge {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 12px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
}

.stat-value {
  font-size: 14px;
  font-weight: 600;
  color: #fff;
}

.stat-label {
  font-size: 11px;
  color: #999;
}

.toolbar-right {
  display: flex;
  gap: 8px;
}
</style>
