import { pinyin } from 'pinyin-pro'
import { buildUserMdWithWorkspaceRules } from '@/config/agent-templates'
import { AgentTeamApiError, useAgentTeamStore } from '@/stores/agent-team'
import { useAuthStore } from '@/stores/auth'
import { useWebSocketStore } from '@/stores/websocket'
import { isImageAvatar } from '@/utils/agent-avatar'

export interface CreateAgentParams {
  name: string
  avatar: string
  description: string
  category: string
  templateId: string
  soulMd: string
  agentsMd: string
  identityMd: string
  userMd: string
  workStyle?: string
  model?: string
}

export interface CreateAgentResult {
  agentId: string
  gatewayAgentId: string
  workspacePath: string
}

export const AGENT_TEAM_LIMIT_REACHED = 'AGENT_TEAM_LIMIT_REACHED'

export function isAgentTeamLimitError(error: unknown): boolean {
  return error instanceof AgentTeamApiError && error.code === AGENT_TEAM_LIMIT_REACHED
}

function sanitizeWorkspaceSegment(value: string, fallback: string): string {
  const sanitized = value
    .trim()
    .replace(/[\\/:*?"<>|\x00-\x1F]/g, '-')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
  return sanitized || fallback
}

function formatWorkspaceTimestamp(date = new Date()): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('')
}

function buildWorkspacePath(params: {
  userDisplayName: string
  userName: string
  agentName: string
}): string {
  const displayName = sanitizeWorkspaceSegment(params.userDisplayName, 'user')
  const userName = sanitizeWorkspaceSegment(params.userName, 'user')
  const workspaceFolder = `${displayName}-${userName}`
  const workspaceAgent = sanitizeWorkspaceSegment(params.agentName, 'agent')
  const workspaceTime = formatWorkspaceTimestamp()
  const workspaceName = `${displayName}的${workspaceAgent}-${workspaceTime}`
  return `/home/wattman/.wattclaw/${workspaceFolder}/${workspaceName}`
}

export function generateSemanticAgentId(
  agentName: string,
  userDisplayName?: string
): string {
  const sanitize = (input: string): string => {
    let normalized = input.replace(/的/g, '-')

    const segments = normalized.split('-').filter(Boolean)
    const pinyinSegments = segments.map((seg) =>
      pinyin(seg.trim(), { toneType: 'none', type: 'string', separator: '' })
    )
    normalized = pinyinSegments.join('-')

    return (
      normalized
        .toLowerCase()
        .replace(/[^a-z0-9-]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
    )
  }

  const agentSlug = sanitize(agentName)
  const userSlug = userDisplayName ? sanitize(userDisplayName) : ''

  if (userSlug) {
    return `${userSlug}-${agentSlug}-${Date.now()}`
  }

  // 降级策略：无用户名时保持两段式（兼容旧数据格式语义）
  return `${agentSlug}-${Date.now()}`
}

export function resolveDefaultModel(config: Record<string, unknown>): string {
  const models = config.models as Record<string, unknown> | undefined
  const agents = config.agents as Record<string, unknown> | undefined
  const defaults = agents?.defaults as Record<string, unknown> | undefined
  const modelDefaults = defaults?.model as Record<string, unknown> | undefined

  return (models?.primary as string) ||
    (modelDefaults?.primary as string) ||
    ''
}

const TOOLS_MD_TEMPLATE = `# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- SSH hosts and aliases
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

\`\`\`markdown


### SSH

- home-server → 192.168.1.100, user: admin
\`\`\`

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

## Cron 定时任务默认行为

- 创建定时任务时，默认 \`sessionTarget\` 为 \`"current"\`（即当前会话）
- 即：所有 cron job 默认投递到触发创建的那个聊天会话
- 如需投递到其他会话或 isolated session，会在任务描述中特别说明

## Feishu 定时任务

在 Feishu 渠道创建定时任务时，Cron 任务必须使用 \`sessionTarget: "current"\`，确保提醒消息投送到创建任务的当前对话（私聊或群聊）中，而不是新建独立会话。

示例：

\`\`\`json
{
  "sessionTarget": "current",
  "delivery": { "mode": "announce" }
}
\`\`\`
`

const MEMORY_MD_TEMPLATE = `# MEMORY.md — 用户偏好记录

## 已知习惯

- 需要对入站文件（路径含 /media/inbound/）立即移动到 workspace uploads/ 目录

## 互动偏好

- 定时任务使用 Asia/Shanghai 时区
- 定时任务默认投递到当前会话（sessionTarget: "current"）
`

export function useAgentCreation() {
  const wsStore = useWebSocketStore()
  const authStore = useAuthStore()
  const store = useAgentTeamStore()

  async function createAgent(
    params: CreateAgentParams,
    onProgress?: (progress: number, stage: string) => void
  ): Promise<CreateAgentResult> {
    const report = (progress: number, stage: string) => {
      onProgress?.(progress, stage)
    }

    const user = authStore.currentUser
    const displayName = user?.display_name || user?.username || ''
    const userName = user?.username || ''

    const workspacePath = buildWorkspacePath({
      userDisplayName: displayName,
      userName,
      agentName: params.name,
    })

    const limitState = await store.checkCreateLimit()
    if (!limitState.canCreate) {
      throw new AgentTeamApiError('每个用户最多可以创建 10 个数字员工', 409, AGENT_TEAM_LIMIT_REACHED)
    }

    report(20, '创建中...')

    const config = await wsStore.rpc.getConfig()
    const defaultModel = resolveDefaultModel(config as Record<string, unknown>)
    // 用户显式选择的模型优先（移动端/网页端模型选择器），否则回退系统默认
    const effectiveModel = params.model || defaultModel
    const agentSlug = generateSemanticAgentId(params.name, displayName)
    const avatarIsImage = isImageAvatar(params.avatar)

    const createResult = await wsStore.rpc.createAgent({
      name: agentSlug,
      workspace: workspacePath,
      ...(effectiveModel ? { model: effectiveModel } : {}),
      ...(!avatarIsImage ? { emoji: params.avatar } : {}),
    })
    const gatewayAgentId = createResult.agentId || createResult.name || agentSlug

    const mergedUserMd = buildUserMdWithWorkspaceRules(params.userMd, workspacePath)

    const FILE_HANDLING_RULES = `## 文件处理铁律（最高优先级）

### 规则 1：入站文件强制移动策略

**触发条件**：当用户通过任何渠道（飞书、Discord、Telegram、Web等）上传文件，且源文件路径包含 \`/media/inbound/\` 时。

**强制执行的动作（不可违反）**：

1. **禁止** 在 \`/media/inbound/\` 目录下直接读取或处理文件内容
2. **必须** 无论用户有没有发消息，只要有文件上传，立即使用 \`mv\` 命令将文件移动到当前 Agent 工作区的 \`uploads/\` 目录
3. **禁止** 使用 \`cp\` 命令复制文件（不能保留副本在 \`/media/inbound/\`）
4. **禁止** 先将文件移动到任何临时目录（如 \`/tmp\`、\`/var/tmp\`、\`/dev/shm\` 等）

**正确做法示例**：
\`\`\`bash
# 假设当前工作区为 /home/wattman/.wattclaw/张三-13000000000/张三的代码助手-20260508154352/
mv /home/wattclaw/.openclaw/media/inbound/user_upload_12345.pdf /home/wattman/.wattclaw/张三-13000000000/张三的代码助手-20260508154352/uploads/
\`\`\``

    const agentsMdContent = params.agentsMd?.trim()
      ? FILE_HANDLING_RULES + '\n\n' + params.agentsMd.trim()
      : FILE_HANDLING_RULES

    const mdFiles: Array<[string, string]> = [
      ['SOUL.md', params.soulMd],
      ['AGENTS.md', agentsMdContent],
      ['IDENTITY.md', params.identityMd],
      ['USER.md', mergedUserMd],
      ['TOOLS.md', TOOLS_MD_TEMPLATE],
      ['MEMORY.md', MEMORY_MD_TEMPLATE],
    ].filter(([, content]) => content) as Array<[string, string]>

    const progressMap: Record<string, number> = {
      'SOUL.md': 35,
      'AGENTS.md': 50,
      'IDENTITY.md': 65,
      'USER.md': 80,
      'TOOLS.md': 90,
      'MEMORY.md': 95,
    }

    const stageMap: Record<string, string> = {
      'SOUL.md': '配置资源',
      'AGENTS.md': '初始化知识库',
      'IDENTITY.md': '初始化知识库',
      'USER.md': '下载资源',
      'TOOLS.md': '初始化知识库',
      'MEMORY.md': '初始化知识库',
    }

    for (const [name, content] of mdFiles) {
      report(progressMap[name] ?? 50, stageMap[name] ?? '初始化知识库')
      await wsStore.rpc.setAgentFile(gatewayAgentId, name, content)
    }

    const token = authStore.getToken()
    if (token) {
      fetch('/api/agent-team/complete-bootstrap', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ workspacePath }),
      }).catch(() => { /* fire-and-forget */ })
    }

    let dbAgent: { id: string }
    try {
      dbAgent = await store.createAgent({
        name: params.name,
        avatar: params.avatar,
        description: params.description,
        category: params.category,
        templateId: params.templateId,
        gatewayAgentId,
        model: effectiveModel,
        workspace: workspacePath,
      })
    } catch (dbErr) {
      try {
        await wsStore.rpc.deleteAgent(gatewayAgentId)
      } catch {
        // best-effort rollback
      }
      throw dbErr
    }

    report(100, '完成')

    return {
      agentId: dbAgent.id,
      gatewayAgentId,
      workspacePath,
    }
  }

  return { createAgent }
}
