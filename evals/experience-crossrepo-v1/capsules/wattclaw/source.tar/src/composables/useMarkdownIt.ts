import { ref } from 'vue'
import { getMarkdownIt } from '@/utils/render-markdown'

const md = ref(getMarkdownIt())

export function useMarkdownIt() {
  return { md }
}