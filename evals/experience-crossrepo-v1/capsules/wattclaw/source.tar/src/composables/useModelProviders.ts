// src/composables/useModelProviders.ts
import { ref, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useModelStore } from '@/stores/model'
import { useWebSocketStore } from '@/stores/websocket'

export interface ModelOption {
  id: string
  modelId: string
  label: string
  providerId: string
  remark: string
  description: string
}

const PROVIDER_PRIORITY: Record<string, number> = {
  minimax: 1,
  deepseek: 2,
  gpt: 3,
  claude: 4,
  zai: 5,
  ollama: 6,
  xiaomi: 7,
}

function getProviderPriority(providerId: string): number {
  return PROVIDER_PRIORITY[providerId] ?? Infinity
}

const providers = ref<any[]>([])
const loaded = ref(false)
let healthSubscriptionBound = false

// in-flight 去重(共享数据层纵深防御):同 tick 多实例并发首次加载时
// (如数字员工页多卡片),合并为单次请求共享结果。布尔 loaded 守卫防不住
// “并发首次”——异步翻转前所有调用方都读到 false。invalidate() 用 force 绕过。
let inflight: Promise<void> | null = null

async function fetchProviders(force = false): Promise<void> {
  if (!force && (loaded.value || inflight)) return inflight ?? Promise.resolve()
  inflight = (async () => {
    try {
      const authStore = useAuthStore()
      const token = authStore.getToken()
      if (!token) return
      const res = await fetch('/api/model-providers', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      })
      const data = await res.json()
      if (data.ok && Array.isArray(data.providers)) {
        providers.value = data.providers.map((p: any) => ({
          ...p,
          config: typeof p.config === 'string' ? JSON.parse(p.config) : p.config,
        }))
      }
      loaded.value = true
    } catch {
      loaded.value = true
    } finally {
      inflight = null
    }
  })()
  return inflight
}

function parseProviderDescriptionMeta(description: unknown): Record<string, { remark?: string; description?: string }> {
  if (typeof description !== 'string' || !description.trim()) return {}
  try {
    const parsed = JSON.parse(description)
    const modelMeta = parsed?.modelMeta
    if (!modelMeta || typeof modelMeta !== 'object' || Array.isArray(modelMeta)) return {}
    return modelMeta as Record<string, { remark?: string; description?: string }>
  } catch {
    return {}
  }
}

function extractModelsFromConfig(config: any): Array<{ id: string; name?: string; remark?: string }> {
  if (!config) return []
  const candidates: unknown[] = [config.models, config.modelIds, config.availableModels, config.whitelist]
  const results: Array<{ id: string; name?: string; remark?: string }> = []

  for (const candidate of candidates) {
    if (!candidate) continue
    if (Array.isArray(candidate)) {
      for (const item of candidate) {
        if (typeof item === 'string') {
          results.push({ id: item })
        } else if (item && typeof item === 'object' && 'id' in item) {
          const obj = item as Record<string, unknown>
          results.push({
            id: String(obj.id),
            name: obj.name ? String(obj.name) : undefined,
            remark: obj.remark ? String(obj.remark) : undefined,
          })
        }
      }
      break
    } else if (typeof candidate === 'object') {
      for (const [key, value] of Object.entries(candidate as Record<string, unknown>)) {
        if (value && typeof value === 'object' && 'id' in (value as Record<string, unknown>)) {
          const obj = value as Record<string, unknown>
          results.push({
            id: String(obj.id),
            name: obj.name ? String(obj.name) : undefined,
            remark: obj.remark ? String(obj.remark) : undefined,
          })
        } else {
          results.push({ id: key })
        }
      }
      break
    }
  }

  return results
}

const modelList = computed<ModelOption[]>(() => {
  const seen = new Set<string>()
  const result: ModelOption[] = []

  for (const provider of providers.value) {
    const config = provider.config || {}
    const models = extractModelsFromConfig(config)
    const descriptionMeta = parseProviderDescriptionMeta(provider.description)
    for (const m of models) {
      const modelRef = `${provider.providerId}/${m.id}`
      if (seen.has(modelRef)) continue
      seen.add(modelRef)
      const meta = descriptionMeta[m.id] || {}
      result.push({
        id: modelRef,
        modelId: m.id,
        label: m.name || m.id,
        providerId: provider.providerId,
        remark: (meta.remark || m.remark || provider.remark || '').toString(),
        description: (meta.description || '').toString(),
      })
    }
  }

  return result.sort((a, b) => {
    const pa = getProviderPriority(a.providerId)
    const pb = getProviderPriority(b.providerId)
    if (pa !== pb) return pa - pb
    return a.label.localeCompare(b.label)
  })
})

function getModelRemark(modelId: string): string {
  return modelList.value.find((m) => m.id === modelId || m.modelId === modelId)?.remark || ''
}

function getModelDescription(modelId: string): string {
  return modelList.value.find((m) => m.id === modelId || m.modelId === modelId)?.description || ''
}

function getModelOption(modelId: string): ModelOption | undefined {
  return modelList.value.find((m) => m.id === modelId || m.modelId === modelId)
}

function invalidate() {
  fetchProviders(true)
}

function ensureModelHealthSubscription() {
  if (healthSubscriptionBound) return
  healthSubscriptionBound = true
  const websocketStore = useWebSocketStore()
  websocketStore.subscribe('modelHealth', () => {
    fetchProviders(true)
    useModelStore().fetchModels()
  })
}

export function useModelProviders() {
  ensureModelHealthSubscription()

  return {
    providers,
    modelList,
    loaded,
    fetchProviders,
    invalidate,
    getModelRemark,
    getModelDescription,
    getModelOption,
  }
}
