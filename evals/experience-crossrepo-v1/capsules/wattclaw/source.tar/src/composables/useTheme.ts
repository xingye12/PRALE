import { computed } from 'vue'
import { darkTheme } from 'naive-ui'
import type { GlobalThemeOverrides } from 'naive-ui'
import { useThemeStore } from '@/stores/theme'

export function useTheme() {
  const themeStore = useThemeStore()

  const isDark = computed(() => themeStore.mode === 'dark')

  const themeOverrides: GlobalThemeOverrides = {
    common: {
      primaryColor: '#435ba8',
      primaryColorHover: '#536dbd',
      primaryColorPressed: '#364e9b',
      primaryColorSuppl: '#93aafe',
      borderRadius: '12px',
      borderRadiusSmall: '8px',
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontFamilyMono: "'JetBrains Mono', monospace",
    },
    Card: {
      borderRadius: '24px',
      borderWidth: '0px',
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
      color: 'var(--surface-container-lowest)',
    },
    Button: {
      borderRadiusMedium: '12px',
      borderRadiusLarge: '16px',
      borderRadiusSmall: '8px',
      fontWeight: '600',
    },
    Input: {
      borderRadius: '12px',
      color: 'var(--surface-container-low)',
      border: '1px solid var(--outline-variant)',
    },
    Menu: {
      borderRadius: '12px',
      itemIconColor: 'var(--on-surface-variant)',
      itemTextColor: 'var(--on-surface-variant)',
      itemIconColorHover: 'var(--primary)',
      itemTextColorHover: 'var(--primary)',
      itemColorActive: 'transparent',
      itemTextColorActive: 'var(--primary)',
      itemIconColorActive: 'var(--primary)',
    },
    Breadcrumb: {
      fontSize: '14px',
      itemTextColor: 'var(--on-surface-variant)',
      itemTextColorHover: 'var(--primary)',
      itemTextColorPressed: 'var(--primary-dim)',
    }
  }

  const naiveTheme = computed(() =>
    themeStore.mode === 'dark' ? darkTheme : null
  )

  return {
    theme: naiveTheme,
    themeOverrides,
    mode: computed(() => themeStore.mode),
    isDark,
    toggle: themeStore.toggle,
  }
}
