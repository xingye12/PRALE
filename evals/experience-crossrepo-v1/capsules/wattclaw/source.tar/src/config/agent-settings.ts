export type AgentSettingFileName = 'SOUL.md' | 'AGENTS.md' | 'IDENTITY.md' | 'USER.md' | 'TOOLS.md' | 'MEMORY.md'
export type AgentSettingField = 'soulMd' | 'agentsMd' | 'identityMd' | 'userMd' | 'toolsMd' | 'memoryMd'

export interface AgentSettingFile {
  file: AgentSettingFileName
  field: AgentSettingField
  label: string
  desc: string
}

/** 设定文件映射（网页端 SettingsTab + 移动端共用，单一权威）。label/desc 为业务固定中文文案。 */
export const AGENT_SETTING_FILES: AgentSettingFile[] = [
  { file: 'SOUL.md',     field: 'soulMd',     label: '行为准则', desc: '定义核心行为规范、安全边界和不可逾越的底线' },
  { file: 'AGENTS.md',   field: 'agentsMd',   label: '工作流程', desc: '定义工作流程、协作方式和工具使用规则' },
  { file: 'IDENTITY.md', field: 'identityMd', label: '身份档案', desc: '定义身份信息、专业领域、技能特长和沟通风格' },
  { file: 'USER.md',     field: 'userMd',     label: '用户档案', desc: '记录用户的信息偏好、使用习惯和个性化需求' },
  { file: 'TOOLS.md',    field: 'toolsMd',    label: '工具说明', desc: '记录本地工具、技能调用方式和可用能力说明' },
  { file: 'MEMORY.md',   field: 'memoryMd',   label: '记忆档案', desc: '记录长期记忆、关键偏好和持续积累的上下文' },
]

/** 按文件名快速查表（替代网页端原 FILE_LABELS 的 Record 查找）。 */
export const AGENT_SETTING_BY_FILE: Record<string, AgentSettingFile> = Object.fromEntries(
  AGENT_SETTING_FILES.map((f) => [f.file, f]),
)
