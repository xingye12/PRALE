import { createI18n } from 'vue-i18n'
import zhCN from './messages/zh-CN'

export const i18n = createI18n({
  legacy: false,
  globalInjection: true,
  locale: 'zh-CN',
  fallbackLocale: 'zh-CN',
  missing(_locale, key) {
    console.warn(`[i18n Warn] Missing key: "${key}"`)
    return key
  },
  messages: {
    'zh-CN': zhCN,
  },
})
