export type AppLocale = 'zh-CN'

export function getPreferredLocale(): AppLocale {
  return 'zh-CN'
}

export const LOCALE_STORAGE_KEY = 'openclaw_locale'
