export function getActiveLocale(): 'zh-CN' {
  return 'zh-CN'
}

export function byLocale(zhCN: string, _enUS: string): string {
  return zhCN
}
