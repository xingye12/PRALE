<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { NLayout, NLayoutSider, NLayoutContent } from 'naive-ui'
import AppSidebar from '@/components/layout/AppSidebar.vue'
import { useWebSocketStore } from '@/stores/websocket'
import { useWorkspaceStore } from '@/stores/workspace'
import { extractSessionKey, isLifecycleEndEvent } from '@/utils/event-helpers'

const route = useRoute()
const wsStore = useWebSocketStore()
const workspaceStore = useWorkspaceStore()
const sidebarCollapsed = ref(false)
let notificationCleanup: (() => void) | null = null

onMounted(() => {
  wsStore.connect()

  notificationCleanup = wsStore.subscribe('event', (evt: unknown) => {
    const rpcEvent = evt as { event: string; payload: unknown }
    const payload = rpcEvent.payload as Record<string, unknown>
    const sessionKey = extractSessionKey(payload)
    const isWorkspaceRoute = route.name === 'Workspace'
    if (sessionKey || isWorkspaceRoute) {
      workspaceStore.handleEvent(rpcEvent.event, rpcEvent.payload)
    }
    if (isLifecycleEndEvent(rpcEvent.event, payload)) {
      if (sessionKey === workspaceStore.activeSessionKey) {
        workspaceStore.handleNotification(sessionKey, isWorkspaceRoute)
      }
    }
  })
})

onUnmounted(() => {
  notificationCleanup?.()
  wsStore.disconnect()
})
</script>

<template>
  <NLayout has-sider position="absolute" class="app-layout-root">
    <NLayoutSider
      class="app-layout-sider"
      :class="{ 'app-layout-sider--wide': !sidebarCollapsed }"
      bordered
      :width="280"
      :collapsed-width="72"
      :collapsed="sidebarCollapsed"
      :show-trigger="false"
      collapse-mode="width"
      sider-placement="left"
      :native-scrollbar="true"
    >
      <AppSidebar
        :collapsed="sidebarCollapsed"
        @toggle-collapsed="sidebarCollapsed = !sidebarCollapsed"
      />
    </NLayoutSider>

    <NLayout class="app-layout-main">
      <NLayoutContent
        class="app-layout-content"
        :native-scrollbar="false"
      >
        <div class="page-container">
          <RouterView v-slot="{ Component }">
            <transition name="fade" mode="out-in">
              <component :is="Component" />
            </transition>
          </RouterView>
        </div>
      </NLayoutContent>
    </NLayout>
  </NLayout>
</template>

<style scoped>
.app-layout-root {
  inset: 0;
  height: 100vh;
  overflow: hidden;
}

.app-layout-main {
  height: 100vh;
  overflow: hidden;
}

:deep(.app-layout-sider .n-layout-sider-scroll-container) {
  height: 100vh !important;
  overflow-y: auto !important;
}

:deep(.app-layout-sider) {
  background: var(--bg-sidebar) !important;
  border-right: 1px solid rgba(0,0,0,.06) !important;
}

:deep(.app-layout-sider--wide .n-layout-sider-scroll-container) {
  overflow: hidden !important;
}

:deep(.app-layout-sider .n-layout-sider__border) {
  background: transparent !important;
}

:deep(.app-layout-sider .n-layout-toggle-button) {
  background: var(--bg-sidebar) !important;
  border-color: transparent !important;
}

:deep(.app-layout-sider .n-layout-toggle-button:hover) {
  background: var(--bg-hover) !important;
}

[data-theme='dark'] :deep(.app-layout-sider) {
  border-right-color: rgba(255,255,255,.08) !important;
}

.app-layout-content {
  height: 100vh !important;
  overflow: hidden !important;
  position: relative;
  background: var(--surface-container) !important;
}

:deep(.app-layout-content .n-layout-scroll-container) {
  height: 100% !important;
  max-height: 100% !important;
  overflow: hidden !important;
  position: relative;
}

.page-container {
  position: absolute;
  inset: 8px;
  overflow: hidden;
  padding: 24px;
  border: 1px solid var(--border2);
  border-radius: 16px;
  background: var(--bg-card);
  box-shadow: var(--shadow-sm);
  box-sizing: border-box;
}
</style>
