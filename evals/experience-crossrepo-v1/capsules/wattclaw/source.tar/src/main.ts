import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import { i18n } from '@/i18n'
import { avatarFallbackDirective } from '@/utils/agent-avatar'
import './assets/styles/main.css'
import '@/mobile/styles/mobile.css'
import 'katex/dist/katex.min.css'
import 'highlight.js/styles/github.css'

/* 非阻塞字体加载状态探针：注册 Promise 回调后立即释放执行栈，绝不阻塞 Vue 初始化 */
if (typeof document !== 'undefined' && document.fonts) {
  const materialSymbolsFont = '24px "Material Symbols Outlined"'
  const showIconsWhenFontIsReady = (fontFaces: FontFace[]) => {
    if (fontFaces.length > 0 && document.fonts.check(materialSymbolsFont, 'chat')) {
      document.documentElement.classList.add('fonts-loaded')
    }
  }

  const loadMaterialSymbols = () => document.fonts.load(materialSymbolsFont, 'chat')

  void loadMaterialSymbols()
    .then(showIconsWhenFontIsReady)
    .catch(() => {})

  document.fonts.ready
    .then(loadMaterialSymbols)
    .then(showIconsWhenFontIsReady)
    .catch(() => {})
} else if (typeof document !== 'undefined') {
  document.documentElement.classList.add('fonts-loaded')
}

const app = createApp(App)
app.use(createPinia())
app.use(i18n)
app.use(router)
app.directive('avatar-fallback', avatarFallbackDirective)
app.mount('#app')
