<script setup lang="ts">
import { ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'

const props = defineProps<{
  visible: boolean
  title: string
  value: string
}>()
const emit = defineEmits<{
  (e: 'save', value: string): void
  (e: 'cancel'): void
}>()

const { t } = useI18n()
const draft = ref(props.value)

// 每次打开覆盖层时，用最新 value 重置草稿，避免上次编辑残留
watch(
  () => props.visible,
  (v) => {
    if (v) draft.value = props.value
  },
)
</script>

<template>
  <Transition name="overlay">
    <div v-if="visible" class="overlay">
      <header class="overlay-bar">
        <button class="bar-btn" @click="emit('cancel')">{{ t('pages.mobile.agents.cancel') }}</button>
        <span class="bar-title">{{ title }}</span>
        <button class="bar-btn primary" @click="emit('save', draft)">
          {{ t('pages.mobile.agents.save') }}
        </button>
      </header>
      <div class="overlay-body">
        <textarea
          v-model="draft"
          class="overlay-editor"
          :placeholder="t('pages.mobile.agents.editPlaceholder')"
          autocomplete="off"
        />
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  z-index: 2000;
  display: flex;
  flex-direction: column;
  background: var(--m-bg-page);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}
.overlay-bar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: calc(12px + env(safe-area-inset-top)) 16px 12px;
  border-bottom: 1px solid var(--m-border);
  background: var(--m-bg-card);
}
.bar-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--m-text-primary);
}
.bar-btn {
  min-width: 48px;
  padding: 7px 14px;
  border: none;
  border-radius: var(--m-radius-md);
  background: transparent;
  color: var(--m-text-secondary);
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.bar-btn.primary {
  background: var(--m-bubble-user-bg);
  color: #fff;
}
.bar-btn:active { opacity: 0.7; }
.overlay-body {
  flex: 1;
  min-height: 0;
  padding: 12px;
  display: flex;
}
.overlay-editor {
  flex: 1;
  width: 100%;
  margin: 0;
  padding: 16px;
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  color: var(--m-text-primary);
  font-family: 'SF Mono', 'JetBrains Mono', 'Menlo', monospace;
  font-size: 13px;
  line-height: 1.7;
  resize: none;
  outline: none;
}
.overlay-enter-active,
.overlay-leave-active {
  transition: transform 0.28s cubic-bezier(0.22, 0.61, 0.36, 1), opacity 0.28s ease;
}
.overlay-enter-from,
.overlay-leave-to {
  transform: translateY(100%);
  opacity: 0;
}
@media (prefers-reduced-motion: reduce) {
  .overlay-enter-active,
  .overlay-leave-active { transition: none; }
}
</style>
