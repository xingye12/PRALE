<script setup lang="ts">
import { ref } from 'vue'
import { NDrawer, NDrawerContent, NEmpty } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { MobileModelOption } from '@/mobile/composables/useMobileModelSelect'

/**
 * 移动端模型选择器（UI 单一权威）。
 * 数据层 useMobileModelSelect 由父组件持有（避免重复 ensureLoaded 惊群），
 * 本组件纯受控：展示当前选中 pill + 点击展开 NDrawer 选项列表。
 * 供 MobileAgentCreateSheet / MobileAgentEditPage 复用。
 */
const props = defineProps<{
  options: MobileModelOption[]
  activeModelRef: string
  activeLabel: string
  activeIcon?: string
}>()
const emit = defineEmits<{ (e: 'select', modelRef: string): void }>()

const { t } = useI18n()
const showSheet = ref(false)

function isActive(opt: MobileModelOption): boolean {
  return opt.modelRef === props.activeModelRef || opt.modelId === props.activeModelRef
}
function pick(modelRef: string) {
  emit('select', modelRef)
  showSheet.value = false
}

function isUnavailableRemark(remark?: string): boolean {
  return remark?.trim() === '暂不可用'
}
</script>

<template>
  <div class="model-picker">
    <button class="model-pill" type="button" @click="showSheet = true">
      <img v-if="activeIcon" :src="activeIcon" class="model-pill__icon" alt="">
      <span v-else class="model-pill__dot" />
      <span class="model-pill__label">{{ activeLabel || t('pages.mobile.chat.defaultModel') }}</span>
      <span class="model-pill__arrow">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6" /></svg>
      </span>
    </button>

    <NDrawer v-model:show="showSheet" placement="bottom" height="64%">
      <NDrawerContent :title="t('pages.mobile.chat.switchModel')" closable>
        <div class="model-sheet">
          <div v-if="options.length > 0" class="model-sheet__count">
            {{ t('pages.mobile.chat.modelCount', { n: options.length }) }}
          </div>
          <NEmpty v-if="options.length === 0" :description="t('pages.mobile.chat.noModels')" />
          <button
            v-for="opt in options"
            :key="opt.modelRef"
            class="model-card"
            :class="{ 'is-selected': isActive(opt) }"
            type="button"
            @click="pick(opt.modelRef)"
          >
            <span v-if="isActive(opt)" class="model-card__bar" />
            <div class="model-card__head">
              <img v-if="opt.iconUrl" :src="opt.iconUrl" class="model-card__icon" alt="">
              <span class="model-card__main">{{ opt.label }}</span>
            </div>
            <span v-if="opt.description" class="model-card__desc">{{ opt.description }}</span>
            <span
              v-if="opt.remark || opt.provider || opt.isDefault"
              class="model-card__chips"
            >
              <span v-if="opt.isDefault" class="model-chip model-chip--default">⭐ {{ t('pages.mobile.chat.defaultBadge') }}</span>
              <span v-if="opt.remark" class="model-chip model-chip--remark" :class="{ 'model-chip--unavailable': isUnavailableRemark(opt.remark) }">{{ opt.remark }}</span>
              <span v-if="opt.provider" class="model-chip model-chip--provider">{{ opt.provider }}</span>
            </span>
          </button>
        </div>
      </NDrawerContent>
    </NDrawer>
  </div>
</template>

<style scoped>
.model-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  padding: 9px 14px 9px 11px;
  border: 1px solid color-mix(in srgb, var(--m-primary) 22%, var(--m-border));
  border-radius: 999px;
  background: var(--m-bg-card);
  color: var(--m-text-secondary);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.1);
  -webkit-tap-highlight-color: transparent;
}
.model-pill__icon { width: 16px; height: 16px; border-radius: 50%; object-fit: cover; flex-shrink: 0; }
.model-pill__dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: linear-gradient(135deg, var(--m-primary), var(--m-accent));
  flex-shrink: 0;
}
.model-pill__label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.model-pill__arrow { display: grid; place-items: center; flex-shrink: 0; color: var(--m-primary); }
.model-pill__arrow svg { width: 13px; height: 13px; }

.model-sheet { display: flex; flex-direction: column; gap: 10px; padding: 4px 2px 8px; }
.model-sheet__count { padding: 0 4px 4px; color: var(--m-text-hint); font-size: 12px; }
.model-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 5px;
  width: 100%;
  padding: 14px 16px;
  border: 1px solid color-mix(in srgb, var(--m-border) 72%, transparent);
  border-radius: var(--m-radius-lg);
  background: color-mix(in srgb, var(--m-bg-card) 96%, transparent);
  box-shadow: var(--m-shadow-card);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  color: var(--m-text-primary);
  text-align: left;
  overflow: hidden;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.model-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}
.model-card:active { transform: scale(0.985); }
.model-card.is-selected {
  border-color: var(--m-primary);
  box-shadow: 0 14px 36px rgba(37, 99, 235, 0.2);
}
.model-card__bar {
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--m-primary), var(--m-accent)); z-index: 1;
}
.model-card__head { position: relative; display: flex; align-items: center; gap: 8px; min-width: 0; }
.model-card__icon { width: 22px; height: 22px; border-radius: 50%; object-fit: cover; flex-shrink: 0; }
.model-card__main {
  position: relative; min-width: 0; font-size: 15px; font-weight: 700;
  letter-spacing: -0.01em; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.model-card__desc {
  position: relative; color: var(--m-text-secondary); font-size: 12.5px; line-height: 1.5;
  display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.model-card__chips { position: relative; display: flex; flex-wrap: wrap; gap: 6px; margin-top: 3px; }
.model-chip { display: inline-flex; align-items: center; padding: 2px 9px; border-radius: 999px; font-size: 11px; font-weight: 600; }
.model-chip--default, .model-chip--remark { background: var(--m-primary-light); color: var(--m-primary-strong); }
.model-chip--unavailable {
  background: color-mix(in srgb, #ef4444 14%, transparent);
  color: #ef4444;
}
.model-chip--provider { background: color-mix(in srgb, var(--m-text-hint) 14%, transparent); color: var(--m-text-hint); }
</style>
