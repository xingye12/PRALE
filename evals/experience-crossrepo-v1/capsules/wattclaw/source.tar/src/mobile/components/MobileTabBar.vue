<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'

const route = useRoute()
const router = useRouter()
const { t } = useI18n()

interface TabItem {
  key: string
  icon: string
  labelKey: string
  path: string
}

const tabs: TabItem[] = [
  { key: 'conversations', icon: 'forum', labelKey: 'pages.mobile.tab.chat', path: '/m/conversations' },
  { key: 'agents', icon: 'support_agent', labelKey: 'pages.mobile.tab.agents', path: '/m/agents' },
  { key: 'files', icon: 'folder', labelKey: 'pages.mobile.tab.files', path: '/m/files' },
  { key: 'profile', icon: 'person', labelKey: 'pages.mobile.tab.profile', path: '/m/profile' },
]

const activeTab = computed(() => {
  if (route.path.startsWith('/m/conversations') || route.path.startsWith('/m/chat')) return 'conversations'
  if (route.path.startsWith('/m/agents')) return 'agents'
  if (route.path.startsWith('/m/files')) return 'files'
  if (route.path.startsWith('/m/profile')) return 'profile'
  return ''
})

function switchTab(tab: TabItem) {
  if (route.path !== tab.path) {
    router.push(tab.path)
  }
}

// —— 点击水波涟漪反馈(从触点扩散)——
interface Ripple {
  id: number
  x: number
  y: number
  size: number
}

const ripplesByKey = ref<Record<string, Ripple[]>>({})
let rippleSeq = 0
const RIPPLE_DURATION = 650

function spawnRipple(event: PointerEvent, key: string) {
  const el = event.currentTarget as HTMLElement
  const rect = el.getBoundingClientRect()
  const size = Math.max(rect.width, rect.height) * 1.25
  const ripple: Ripple = {
    id: ++rippleSeq,
    x: event.clientX - rect.left - size / 2,
    y: event.clientY - rect.top - size / 2,
    size,
  }
  ripplesByKey.value = {
    ...ripplesByKey.value,
    [key]: [...(ripplesByKey.value[key] ?? []), ripple],
  }
  window.setTimeout(() => {
    ripplesByKey.value = {
      ...ripplesByKey.value,
      [key]: (ripplesByKey.value[key] ?? []).filter(r => r.id !== ripple.id),
    }
  }, RIPPLE_DURATION)
}
</script>

<template>
  <div class="mobile-tab-bar">
    <button
      v-for="tab in tabs"
      :key="tab.key"
      class="tab-item"
      :class="{ active: activeTab === tab.key }"
      :aria-label="t(tab.labelKey)"
      @pointerdown="spawnRipple($event, tab.key)"
      @click="switchTab(tab)"
    >
      <span
        v-for="r in ripplesByKey[tab.key] ?? []"
        :key="r.id"
        class="tab-ripple"
        :style="{ left: `${r.x}px`, top: `${r.y}px`, width: `${r.size}px`, height: `${r.size}px` }"
      />
      <span class="tab-icon material-symbols-outlined">{{ tab.icon }}</span>
      <span class="tab-label">{{ t(tab.labelKey) }}</span>
    </button>
  </div>
</template>

<style scoped>
.mobile-tab-bar {
  display: flex;
  background: var(--m-tab-bar-bg);
  border-top: 1px solid var(--m-border);
  padding: 6px 10px calc(6px + env(safe-area-inset-bottom));
  position: relative;
  z-index: 100;
  backdrop-filter: blur(18px);
  box-shadow: 0 -10px 30px rgba(15, 23, 42, 0.08);
}

.tab-item {
  flex: 1;
  min-height: 48px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  padding: 6px 0;
  background: transparent;
  border: none;
  border-radius: 16px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  color: var(--m-tab-bar-inactive);
  transition: color 0.2s, background 0.2s, box-shadow 0.15s;
  -webkit-tap-highlight-color: transparent;
}

.tab-item.active {
  color: var(--m-tab-bar-active);
}

/* 按下瞬间底色变灰(叠加,不覆盖 active 主题色) */
.tab-item:active {
  box-shadow: inset 0 0 0 9999px rgba(100, 116, 139, 0.12);
}

/* 点击点扩散的水波涟漪 */
.tab-ripple {
  position: absolute;
  border-radius: 50%;
  background: rgba(100, 116, 139, 0.28);
  transform: scale(0);
  animation: tab-ripple-expand 0.6s cubic-bezier(0.4, 0, 0.2, 1) forwards;
  pointer-events: none;
  z-index: 0;
}

@keyframes tab-ripple-expand {
  to {
    transform: scale(1);
    opacity: 0;
  }
}

.tab-icon {
  position: relative;
  z-index: 1;
  font-size: 22px;
  line-height: 1;
  font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
}

.tab-label {
  position: relative;
  z-index: 1;
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
}
</style>
