import { ref, computed } from 'vue'
import { useModelStore } from '@/stores/model'
import { useConfigStore } from '@/stores/config'
import { buildConfiguredModelRefs, resolveDefaultModelRef } from '@/views/chat/chat-token-utils'
import type { ConfiguredModelOption } from '@/views/chat/chat-token-utils'
import { getIconUrl } from '@/utils/icon-map'

/**
 * 移动端模型选择数据层（单一权威）。
 * 统一 modelOptions / 默认模型 / 选中态 / label / icon 计算，
 * 供 MobileAgentEditPage（create 选模型）等场景复用。
 * MobileChatPage 暂未迁移（零回归，留作后续统一技术债）。
 */
export interface MobileModelOption {
  modelRef: string
  modelId: string
  label: string
  description?: string
  provider?: string
  remark?: string
  iconUrl?: string
  isDefault: boolean
}

export function useMobileModelSelect() {
  const modelStore = useModelStore()
  const configStore = useConfigStore()

  /** 用户显式选中；空则回退默认模型 */
  const selectedModel = ref('')

  const configuredModels = computed<ConfiguredModelOption[]>(() =>
    buildConfiguredModelRefs(configStore.config, 0),
  )

  const defaultModelRef = computed(() =>
    resolveDefaultModelRef(configStore.config, configuredModels.value),
  )

  const modelOptions = computed<MobileModelOption[]>(() =>
    configuredModels.value.map((item) => {
      const info = modelStore.models.find(
        (m) =>
          m.id === item.modelRef ||
          m.id === item.modelId ||
          (!!m.provider && `${m.provider}/${m.id}` === item.modelRef),
      )
      return {
        modelRef: item.modelRef,
        modelId: item.modelId,
        label: info?.label || item.displayName,
        description: info?.description,
        provider: info?.provider || item.providerId,
        remark: item.remark,
        iconUrl: getIconUrl(item.providerId),
        isDefault:
          item.modelRef === defaultModelRef.value || item.modelId === defaultModelRef.value,
      }
    }),
  )

  /** 当前生效模型：选中优先，否则默认 */
  const activeModel = computed(() => selectedModel.value || defaultModelRef.value)

  const activeModelOption = computed(() =>
    modelOptions.value.find(
      (item) => item.modelRef === activeModel.value || item.modelId === activeModel.value,
    ),
  )

  const activeModelLabel = computed(() => activeModelOption.value?.label || activeModel.value)

  const activeModelIcon = computed(() => activeModelOption.value?.iconUrl)

  function selectModel(modelRef: string) {
    selectedModel.value = modelRef
  }

  function isModelActive(model: MobileModelOption): boolean {
    return activeModel.value === model.modelRef || activeModel.value === model.modelId
  }

  /** 拉取模型列表 + 配置，并把选中态初始化为默认模型 */
  async function ensureLoaded() {
    await Promise.all([modelStore.fetchModels(), configStore.fetchConfig()])
    if (!selectedModel.value) {
      selectedModel.value = defaultModelRef.value
    }
  }

  return {
    selectedModel,
    modelOptions,
    defaultModelRef,
    activeModel,
    activeModelLabel,
    activeModelIcon,
    selectModel,
    isModelActive,
    ensureLoaded,
  }
}
