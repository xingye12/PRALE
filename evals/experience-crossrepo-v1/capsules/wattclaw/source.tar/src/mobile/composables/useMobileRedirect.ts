// src/mobile/composables/useMobileRedirect.ts
import type { Router } from 'vue-router'

const MOBILE_UA_REGEX = /iPhone|Android|Mobile/i

const PC_TO_MOBILE_MAP: Record<string, string> = {
  '/': '/m/conversations',
  '/chat': '/m/conversations',
  '/agent-team': '/m/agents',
  '/sessions': '/m/conversations',
}

const EXCLUDED_PREFIXES = [
  '/system', '/settings',
  '/files', '/backup', '/user-management', '/m/',
]

export function isMobileUA(): boolean {
  return MOBILE_UA_REGEX.test(navigator.userAgent)
}

export function shouldRedirectToMobile(path: string): string | null {
  if (!isMobileUA()) return null
  for (const prefix of EXCLUDED_PREFIXES) {
    if (path.startsWith(prefix)) return null
  }
  return PC_TO_MOBILE_MAP[path] || null
}

export function setupMobileRedirect(router: Router) {
  router.beforeEach((to, _from, next) => {
    const redirect = shouldRedirectToMobile(to.path)
    if (redirect) {
      next(redirect)
    } else {
      next()
    }
  })
}
