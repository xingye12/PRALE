import { ref, shallowRef, onUnmounted } from 'vue'
import { downsampleTo16k, resolveDragZone, type DragZone } from './voice-utils'
export type { DragZone } from './voice-utils'

export type VoiceStatus =
  | 'idle' | 'requesting' | 'connecting'
  | 'listening' | 'stopping'
  | 'permission-denied' | 'unsupported' | 'error' | 'service-unavailable'

export type FinishMode = 'send' | 'keep' | 'cancel'
export interface FinishResult { mode: FinishMode; text: string }

const SPEECH_WS_PATH = '/api/speech/xfyun'
const WORKLET_URL = '/voice-pcm-processor.js'
const BATCH_SAMPLE_TARGET = 3200   // ~72ms @44.1k
const STOP_TIMEOUT_MS = 800
const MAX_RECORD_MS = 60_000
const END_DELAY_MS = 150   // 松手后等 worklet 最后尾音帧 flush 再 send('end')，避免漏最后说的话
const ERROR_RESET_MS = 2000

// 模块级能力缓存（inflight 去重，多实例共享，避免惊群）
let featureInflight: Promise<boolean> | null = null
let featureCache: boolean | null = null
async function loadVoiceSttEnabled(): Promise<boolean> {
  if (featureCache !== null) return featureCache
  if (featureInflight) return featureInflight
  featureInflight = (async () => {
    try {
      const token = localStorage.getItem('auth_token')
      const resp = await fetch('/api/config', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      const data = await resp.json()
      featureCache = Boolean(data?.features?.voiceStt)
    } catch {
      featureCache = false
    } finally {
      featureInflight = null
    }
    return featureCache
  })()
  return featureInflight
}

function isBrowserSupported(): boolean {
  // audioWorklet 是 BaseAudioContext.prototype 上的 getter,直接访问
  // AudioContext.prototype.audioWorklet(this 非实例)会抛 Illegal invocation;
  // 用 'in' 检查存在性,不触发 getter
  return (
    typeof navigator !== 'undefined' &&
    !!navigator.mediaDevices?.getUserMedia &&
    typeof AudioContext !== 'undefined' &&
    'audioWorklet' in AudioContext.prototype
  )
}

export function useMobileVoiceInput() {
  const status = ref<VoiceStatus>('idle')
  const voiceMode = ref(false)
  const volume = ref(0)
  const duration = ref(0)
  const draftText = ref('')
  const dragZone = ref<DragZone | null>(null)
  const enabled = ref(false)

  // 会话级资源：voiceMode 期间常驻。首次 start 建立（ensureSession），
  // 退出语音模式 / unmount 释放（releaseSession）。复用可避免每次按住说话都
  // getUserMedia（权限弹窗）+ AudioContext 冷启动 + worklet 下载 —— 治 bug3/4/5。
  const audioCtx = shallowRef<AudioContext | null>(null)
  const mediaStream = shallowRef<MediaStream | null>(null)
  const workletNode = shallowRef<AudioWorkletNode | null>(null)
  const analyser = shallowRef<AnalyserNode | null>(null)
  const source = shallowRef<MediaStreamAudioSourceNode | null>(null)
  let sessionActive = false

  // 单次录音态：每次 start 重置，finish/cancel 清除（resetRecording，不释放会话）
  const socket = shallowRef<WebSocket | null>(null)
  const batchParts = shallowRef<Float32Array[]>([])

  let cancelled = false
  let finalReceived = false
  let stopTimer: ReturnType<typeof setTimeout> | null = null
  let stopCheck: ReturnType<typeof setInterval> | null = null
  let maxTimer: ReturnType<typeof setTimeout> | null = null
  let errorResetTimer: ReturnType<typeof setTimeout> | null = null
  let rafId: number | null = null
  let durationTimer: ReturnType<typeof setInterval> | null = null
  let recordStartTs = 0

  function clearRecordingTimers() {
    if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
    if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
    if (maxTimer) { clearTimeout(maxTimer); maxTimer = null }
    if (durationTimer) { clearInterval(durationTimer); durationTimer = null }
    if (rafId) { cancelAnimationFrame(rafId); rafId = null }
  }

  // 清单次录音态：关 WS + 清定时器 + 重置拖拽/音量/时长，保留会话音频图
  function resetRecording() {
    clearRecordingTimers()
    try { socket.value?.close() } catch { /* noop */ }
    socket.value = null
    batchParts.value = []
    dragZone.value = null
    volume.value = 0
    duration.value = 0
  }

  // 全会话释放：退出语音模式 / unmount 时释放麦克风与音频图
  function releaseSession() {
    resetRecording()
    if (errorResetTimer) { clearTimeout(errorResetTimer); errorResetTimer = null }
    try { workletNode.value?.disconnect() } catch { /* noop */ }
    try { analyser.value?.disconnect() } catch { /* noop */ }
    try { source.value?.disconnect() } catch { /* noop */ }
    try { mediaStream.value?.getTracks().forEach((t) => t.stop()) } catch { /* noop */ }
    try { audioCtx.value?.close() } catch { /* noop */ }
    audioCtx.value = null
    mediaStream.value = null
    workletNode.value = null
    analyser.value = null
    source.value = null
    sessionActive = false
  }

  function setErrorStatus(s: VoiceStatus) {
    resetRecording()
    status.value = s
    errorResetTimer = setTimeout(() => {
      if (['permission-denied', 'unsupported', 'error', 'service-unavailable'].includes(status.value)) {
        status.value = 'idle'
      }
    }, ERROR_RESET_MS)
  }

  function isSupported() {
    return enabled.value && isBrowserSupported()
  }

  async function ensureEnabled() {
    if (featureCache === null) {
      enabled.value = await loadVoiceSttEnabled()
    } else {
      enabled.value = featureCache
    }
  }
  void ensureEnabled()

  function toggleVoiceMode() {
    voiceMode.value = !voiceMode.value
    if (!voiceMode.value) {
      // 退出语音模式：中止进行中的录音 + 全会话释放（释放麦克风，红点灭）
      cancelled = true
      releaseSession()
      status.value = 'idle'
    }
  }

  function setDragZone(zone: DragZone | null) {
    dragZone.value = zone
  }

  function onPcmFrame(frame: Float32Array, sampleRate: number) {
    // listening/stopping 都采集；stopping 期间收 worklet 松手后到达的最后尾音帧（不再丢）
    if (status.value !== 'listening' && status.value !== 'stopping') return
    batchParts.value.push(frame)
    let total = 0
    for (const p of batchParts.value) total += p.length
    // stopping 时不满批也 flush，尽快把最后音频发给后端
    if (total >= BATCH_SAMPLE_TARGET || status.value === 'stopping') {
      flushBatch(sampleRate)
    }
  }

  // 合并并发送当前残留批次（满批或收尾时调用）：downsample 到 16k 后发 WS
  function flushBatch(sampleRate: number) {
    if (batchParts.value.length === 0) return
    const parts = batchParts.value
    batchParts.value = []
    let total = 0
    for (const p of parts) total += p.length
    const merged = new Float32Array(total)
    let off = 0
    for (const p of parts) { merged.set(p, off); off += p.length }
    const pcm = downsampleTo16k(merged, sampleRate)
    const ws = socket.value
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(pcm.buffer.slice(pcm.byteOffset, pcm.byteOffset + pcm.byteLength))
    }
  }

  function onSocketMessage(ev: MessageEvent) {
    let payload: { type?: string; text?: string; isFinal?: boolean; message?: string }
    try {
      payload = JSON.parse(typeof ev.data === 'string' ? ev.data : '')
    } catch {
      return
    }
    if (payload.type === 'error') {
      setErrorStatus('service-unavailable')
      return
    }
    if (payload.type === 'result' && typeof payload.text === 'string') {
      draftText.value = payload.text // 覆盖式（后端已 pgs 合并）
      if (payload.isFinal) finalReceived = true
    }
  }

  function startDurationAndVolume() {
    const an = analyser.value
    if (!an) return
    const data = new Uint8Array(an.frequencyBinCount)
    const tick = () => {
      if (status.value !== 'listening' || !analyser.value) return
      analyser.value.getByteFrequencyData(data)
      let sum = 0
      for (let i = 0; i < data.length; i++) sum += data[i] ?? 0
      volume.value = Math.min(1, sum / data.length / 128)
      rafId = requestAnimationFrame(tick)
    }
    rafId = requestAnimationFrame(tick)
    durationTimer = setInterval(() => {
      if (status.value === 'listening') {
        duration.value = Math.floor((Date.now() - recordStartTs) / 1000)
      }
    }, 250)
  }

  // 首次建立会话级音频图：AudioContext + getUserMedia + worklet module + analyser + 连线。
  // 成功后 sessionActive=true，后续 start 直接复用，不再触发权限弹窗 / 冷启动。
  async function ensureSession(): Promise<boolean> {
    status.value = 'requesting'
    let ctx: AudioContext
    try {
      ctx = new AudioContext()
      audioCtx.value = ctx
      if (ctx.state === 'suspended') await ctx.resume()
    } catch {
      releaseSession()
      setErrorStatus('unsupported')
      return false
    }

    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (e) {
      const err = e as DOMException
      releaseSession()
      if (err.name === 'NotAllowedError') setErrorStatus('permission-denied')
      else if (err.name === 'NotFoundError') setErrorStatus('unsupported')
      else setErrorStatus('error')
      return false
    }
    if (cancelled) { // 建立期间用户已松手取消
      releaseSession()
      status.value = 'idle'
      return false
    }
    mediaStream.value = stream

    try {
      await ctx.audioWorklet.addModule(WORKLET_URL)
    } catch {
      releaseSession()
      setErrorStatus('error')
      return false
    }
    if (cancelled) {
      releaseSession()
      status.value = 'idle'
      return false
    }

    const node = new AudioWorkletNode(ctx, 'voice-pcm-processor')
    const an = ctx.createAnalyser()
    an.fftSize = 256
    const src = ctx.createMediaStreamSource(stream)
    src.connect(node)
    src.connect(an)
    node.connect(ctx.destination) // iOS 保 process 触发；processor 不写 outputs 静音
    workletNode.value = node
    analyser.value = an
    source.value = src
    node.port.onmessage = (ev: MessageEvent) => onPcmFrame(ev.data as Float32Array, ctx.sampleRate)

    sessionActive = true
    return true
  }

  async function start() {
    // 残留 error 类态：清单次录音态回 idle（保留会话资源），避免阻断下一次录音
    const cur = status.value
    if (cur !== 'idle' && cur !== 'requesting' && cur !== 'connecting' && cur !== 'listening') {
      if (errorResetTimer) { clearTimeout(errorResetTimer); errorResetTimer = null }
      resetRecording()
      status.value = 'idle'
    }
    if (status.value !== 'idle') return // 并发防护

    // 重置单次录音态
    draftText.value = ''
    dragZone.value = null
    cancelled = false
    finalReceived = false
    recordStartTs = Date.now()
    batchParts.value = []

    // 会话资源未就绪 → 首次建立（getUserMedia 权限弹窗 + 冷启动，会话内仅此一次）
    if (!sessionActive) {
      const ok = await ensureSession()
      if (!ok) return // 建立失败已 setError，或 cancelled 已回 idle
      if (cancelled) { resetRecording(); status.value = 'idle'; return }
    }

    // 会话就绪 → 新建轻量 WS 进 listening（无 getUserMedia，毫秒级，治 bug3/4/5）
    status.value = 'connecting'
    const token = localStorage.getItem('auth_token') || ''
    const url = `${SPEECH_WS_PATH}?token=${encodeURIComponent(token)}`
    let ws: WebSocket
    try {
      ws = new WebSocket(url)
      ws.binaryType = 'arraybuffer'
    } catch {
      setErrorStatus('service-unavailable')
      return
    }
    socket.value = ws
    ws.onopen = () => {
      if (cancelled || !socket.value) return
      status.value = 'listening'
      startDurationAndVolume()
      maxTimer = setTimeout(() => {
        // M4: 超时保守 cancel（不误发）
        setErrorStatus('error')
      }, MAX_RECORD_MS)
    }
    ws.onmessage = (ev: MessageEvent) => onSocketMessage(ev)
    ws.onerror = () => {
      if (status.value === 'connecting' || status.value === 'listening') {
        setErrorStatus('service-unavailable')
      }
    }
    ws.onclose = (ev: CloseEvent) => {
      if (status.value === 'stopping' && finalReceived) return // 正常收尾
      if (!ev.wasClean && status.value !== 'idle' && status.value !== 'stopping') {
        setErrorStatus('service-unavailable')
      }
    }
  }

  function finish(): Promise<FinishResult | null> {
    return new Promise((resolve) => {
      // 非 listening（含建立中被取消）：中止 + 清录音态，保留会话
      if (status.value !== 'listening') {
        cancelled = true // 中止进行中的 ensureSession
        resetRecording()
        status.value = 'idle'
        resolve(null)
        return
      }
      const zone = dragZone.value
      // cancel: 立即终止，不等转写收尾，清录音态保留会话
      if (zone === 'cancel') {
        resetRecording()
        status.value = 'idle'
        resolve({ mode: 'cancel', text: '' })
        return
      }
      status.value = 'stopping'
      if (maxTimer) { clearTimeout(maxTimer); maxTimer = null }
      if (rafId) { cancelAnimationFrame(rafId); rafId = null }
      const ws = socket.value
      const sr = audioCtx.value?.sampleRate || 48000
      flushBatch(sr) // 立即发当前残留批次（松手瞬间已采到的音频）
      // 延迟 send('end')：让 stopping 期间 worklet 松手后最后几帧经 onPcmFrame→flushBatch 先发出，
      // 再通知后端音频结束，避免漏掉最后说的话
      let endTimer: ReturnType<typeof setTimeout> | null = setTimeout(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          try { ws.send('end') } catch { /* noop */ }
        }
      }, END_DELAY_MS)

      stopTimer = setTimeout(() => {
        finalReceived = true
        finalize()
      }, STOP_TIMEOUT_MS)
      stopCheck = setInterval(() => {
        const s = socket.value
        if (finalReceived || !s || s.readyState >= WebSocket.CLOSING) {
          if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
          if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
          finalize()
        }
      }, 50)

      function finalize() {
        if (endTimer) { clearTimeout(endTimer); endTimer = null }
        if (stopTimer) { clearTimeout(stopTimer); stopTimer = null }
        if (stopCheck) { clearInterval(stopCheck); stopCheck = null }
        const mode: FinishMode = zone === 'cancel' ? 'cancel' : zone === 'text' ? 'keep' : 'send'
        resetRecording() // 清录音态（关 WS），保留会话资源供下次复用
        status.value = 'idle'
        // 用最新 draftText（含 final 最终结果），而非松手瞬间的快照
        resolve({ mode, text: mode === 'cancel' ? '' : draftText.value })
      }
    })
  }

  function cancel() {
    cancelled = true
    resetRecording()
    status.value = 'idle'
  }

  onUnmounted(() => {
    cancelled = true
    releaseSession()
  })

  return {
    status,
    voiceMode,
    volume,
    duration,
    draftText,
    dragZone,
    enabled,
    analyser,
    isSupported,
    toggleVoiceMode,
    start,
    setDragZone,
    finish,
    cancel,
    resolveDragZone,
  }
}
