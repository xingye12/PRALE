// src/mobile/composables/useVisualViewportResize.ts
import { ref, onMounted, onBeforeUnmount } from 'vue'

export function useVisualViewportResize() {
  const viewportHeight = ref(window.visualViewport?.height ?? window.innerHeight)

  function onResize() {
    if (window.visualViewport) {
      viewportHeight.value = window.visualViewport.height
    }
  }

  onMounted(() => {
    window.visualViewport?.addEventListener('resize', onResize)
  })

  onBeforeUnmount(() => {
    window.visualViewport?.removeEventListener('resize', onResize)
  })

  return { viewportHeight }
}
