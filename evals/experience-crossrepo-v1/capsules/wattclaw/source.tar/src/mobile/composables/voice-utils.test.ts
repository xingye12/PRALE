import { describe, it, expect } from 'vitest'
import { downsampleTo16k, resolveDragZone } from './voice-utils'

describe('resolveDragZone', () => {
  const T = 44
  it('未明显上滑 → send', () => {
    expect(resolveDragZone(0, 0, T)).toBe('send')
    expect(resolveDragZone(0, -10, T)).toBe('send')
  })
  it('左上 → cancel', () => {
    expect(resolveDragZone(-80, -80, T)).toBe('cancel')
  })
  it('右上 → text', () => {
    expect(resolveDragZone(80, -80, T)).toBe('text')
  })
  it('上滑但未偏左右 → send', () => {
    expect(resolveDragZone(0, -100, T)).toBe('send')
  })
  it('左右滑但未上滑 → send', () => {
    expect(resolveDragZone(-100, 0, T)).toBe('send')
    expect(resolveDragZone(100, 0, T)).toBe('send')
  })
  it('位移不足阈值 → send', () => {
    expect(resolveDragZone(-30, -30, T)).toBe('send')
  })
})

describe('downsampleTo16k', () => {
  it('44100 → 16000 下采样长度正确（0.1s）', () => {
    const input = new Float32Array(4410) // 0.1s @44.1k
    const out = downsampleTo16k(input, 44100)
    expect(out.length).toBe(1600) // 0.1s @16k
    expect(out).toBeInstanceOf(Int16Array)
  })
  it('已是 16k → 直接转 Int16', () => {
    const input = new Float32Array([0, 0.5, 1, -1])
    const out = downsampleTo16k(input, 16000)
    expect(out.length).toBe(4)
    expect(out[0]).toBe(0)
    expect(out[2]).toBeGreaterThan(32000) // 1.0 → ~32767
    expect(out[3]).toBeLessThan(-32000) // -1.0 → ~-32767
  })
  it('clamps 超界样本', () => {
    const input = new Float32Array([2, -2]) // 超界
    const out = downsampleTo16k(input, 16000)
    expect(out[0]).toBeLessThanOrEqual(32767)
    expect(out[1]).toBeGreaterThanOrEqual(-32768)
  })
})
