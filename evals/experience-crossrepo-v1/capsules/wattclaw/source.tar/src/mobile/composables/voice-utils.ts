export type DragZone = 'send' | 'text' | 'cancel'

/**
 * 由手指相对按下点的位移向量判定手势区（微信式）。
 * dx, dy: touchmove 相对 touchstart 的位移（px，dy 负=上滑）。
 * 左上 = cancel，右上 = text，其余（含未明显上滑）= send。
 */
export function resolveDragZone(dx: number, dy: number, threshold: number): DragZone {
  if (dy >= -threshold) return 'send'
  if (dx <= -threshold) return 'cancel'
  if (dx >= threshold) return 'text'
  return 'send'
}

/** Float32 → Int16 单样本转换（clamps 到 [-1,1]） */
function float32ToInt16Sample(sample: number): number {
  const clamped = Math.max(-1, Math.min(1, sample))
  return clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff
}

/**
 * 线性插值下采样到 16kHz + Float32→Int16 PCM。
 * input 是攒批后的整段（非单 128 帧），inputSampleRate 取自 audioContext.sampleRate。
 */
export function downsampleTo16k(input: Float32Array, inputSampleRate: number): Int16Array {
  if (inputSampleRate === 16000) {
    const out = new Int16Array(input.length)
    for (let i = 0; i < input.length; i++) out[i] = float32ToInt16Sample(input[i] ?? 0)
    return out
  }
  const ratio = inputSampleRate / 16000
  const outLen = Math.max(0, Math.floor(input.length / ratio))
  const out = new Int16Array(outLen)
  for (let i = 0; i < outLen; i++) {
    const srcIdx = i * ratio
    const lo = Math.floor(srcIdx)
    const hi = Math.min(lo + 1, input.length - 1)
    const frac = srcIdx - lo
    const sample = (input[lo] ?? 0) * (1 - frac) + (input[hi] ?? 0) * frac
    out[i] = float32ToInt16Sample(sample)
  }
  return out
}
