<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useWebSocketStore } from '@/stores/websocket'
import { useAgentTeamStore } from '@/stores/agent-team'
import MobileTabBar from '@/mobile/components/MobileTabBar.vue'

const route = useRoute()
const wsStore = useWebSocketStore()
const agentTeamStore = useAgentTeamStore()
const tabViewKey = computed(() => route.path.split('/').slice(0, 3).join('/'))

// 对齐网页端 DefaultLayout：进入移动端主框架即建立 SSE 实时通道
// 连接常驻整个移动会话，tab 切换/卸载不断连；登出由 MobileProfilePage.handleLogout 显式 disconnect
onMounted(() => {
  wsStore.ensureConnected()
  // 热门模板 Top3 应用级预载:进移动端即拉取常驻,员工市场页同步消费,消除切页空白
  void agentTeamStore.ensureHotTemplates(3)
})
</script>

<template>
  <div class="mobile-tab-layout">
    <div class="content-area">
      <router-view v-slot="{ Component }">
        <keep-alive>
          <component :is="Component" :key="tabViewKey" />
        </keep-alive>
      </router-view>
    </div>
    <MobileTabBar />
  </div>
</template>

<style scoped>
.mobile-tab-layout {
  display: flex;
  flex-direction: column;
  height: 100vh;
  height: 100dvh;
  background: var(--m-bg-page);
}

.content-area {
  position: relative;
  isolation: isolate;
  contain: layout paint;
  flex: 1;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top);
}
</style>
