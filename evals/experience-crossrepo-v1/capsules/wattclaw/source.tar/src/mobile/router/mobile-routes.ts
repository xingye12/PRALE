import type { RouteRecordRaw } from 'vue-router'

export const mobileRoutes: RouteRecordRaw[] = [
  {
    path: '/m/login',
    name: 'MobileLogin',
    component: () => import('@/mobile/views/login/MobileLoginPage.vue'),
    meta: { public: true },
  },
  {
    path: '/m',
    component: () => import('@/mobile/layout/MobileTabLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: '', redirect: '/m/conversations' },
      {
        path: 'conversations',
        name: 'MobileConversations',
        component: () => import('@/mobile/views/chat/MobileConversationsPage.vue'),
      },
      {
        path: 'agents',
        name: 'MobileAgents',
        component: () => import('@/mobile/views/agents/MobileAgentPage.vue'),
      },
      {
        path: 'files',
        name: 'MobileFiles',
        component: () => import('@/mobile/views/files/MobileFilesPage.vue'),
      },
      {
        path: 'profile',
        name: 'MobileProfile',
        component: () => import('@/mobile/views/profile/MobileProfilePage.vue'),
      },
    ],
  },
  // Full-screen sub-pages (no Tab Bar)
  // Route order: create must come before :id
  {
    path: '/m/chat/:sessionKey?',
    name: 'MobileChat',
    component: () => import('@/mobile/views/chat/MobileChatPage.vue'),
    meta: { requiresAuth: true },
    props: true,
  },
  {
    path: '/m/agents/create',
    name: 'MobileAgentCreate',
    component: () => import('@/mobile/views/agents/MobileAgentEditPage.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/m/agents/:id',
    name: 'MobileAgentDetail',
    component: () => import('@/mobile/views/agents/MobileAgentDetailPage.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/m/agents/:id/edit',
    name: 'MobileAgentEdit',
    component: () => import('@/mobile/views/agents/MobileAgentEditPage.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/m/profile/info',
    name: 'MobileProfileInfo',
    component: () => import('@/mobile/views/profile/MobileProfileInfoPage.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/m/profile/feedback',
    name: 'MobileProfileFeedback',
    component: () => import('@/mobile/views/profile/MobileProfileFeedbackPage.vue'),
    meta: { requiresAuth: true },
  },
]
