/**
 * 数字员工分类强调色（移动端共享）。
 * 按 AgentTemplate.category（中文分类名）映射到柔和色相，
 * 用于卡片顶部色条、头像背景、详情 hero 光晕，给每个员工视觉个性。
 * 未知分类回退主色。
 */

export interface CategoryAccent {
  /** 卡片顶部细色条渐变 */
  bar: string
  /** 详情 hero 径向光晕 */
  glow: string
  /** 头像背景渐变叠加 */
  avatarTint: string
}

function hexAlpha(hex: string, alpha: number): string {
  const h = hex.replace('#', '')
  const r = parseInt(h.slice(0, 2), 16)
  const g = parseInt(h.slice(2, 4), 16)
  const b = parseInt(h.slice(4, 6), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function fromHex(base: string): CategoryAccent {
  return {
    bar: `linear-gradient(90deg, ${base}, ${hexAlpha(base, 0)})`,
    glow: `radial-gradient(circle at 50% 0%, ${hexAlpha(base, 0.32)}, transparent 62%)`,
    avatarTint: `linear-gradient(135deg, ${hexAlpha(base, 0.22)}, ${hexAlpha(base, 0.05)})`,
  }
}

const ACCENTS: Record<string, CategoryAccent> = {
  '编程开发': fromHex('#6366f1'),
  '内容创作': fromHex('#d946ef'),
  '办公效率': fromHex('#0ea5e9'),
  '数据分析': fromHex('#10b981'),
  '市场营销': fromHex('#f97316'),
  '客户服务': fromHex('#38bdf8'),
  '人力资源': fromHex('#f59e0b'),
  '产品设计': fromHex('#8b5cf6'),
  '项目管理': fromHex('#3b82f6'),
  '法律合规': fromHex('#64748b'),
  '财务税务': fromHex('#ca8a04'),
  '招投标': fromHex('#14b8a6'),
}

const DEFAULT_ACCENT: CategoryAccent = fromHex('#2563eb')

export function categoryAccent(category: string): CategoryAccent {
  return ACCENTS[category] || DEFAULT_ACCENT
}
