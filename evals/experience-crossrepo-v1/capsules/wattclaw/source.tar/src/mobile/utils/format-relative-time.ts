import { sessionEffectiveTs } from '@/utils/session-time'

export function formatRelativeTime(
  dateStr: string | number,
  t: (key: string) => string,
): string {
  if (!dateStr) return ''
  const ts = sessionEffectiveTs({ lastActivity: dateStr })
  if (!ts) return ''
  const diff = Date.now() - ts
  if (diff < 0) return ''
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return t('pages.mobile.chat.justNow')
  if (minutes < 60) return `${minutes}${t('pages.mobile.chat.minutesAgo')}`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}${t('pages.mobile.chat.hoursAgo')}`
  const days = Math.floor(hours / 24)
  return `${days}${t('pages.mobile.chat.daysAgo')}`
}
