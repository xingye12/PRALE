<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { AgentTeamMember } from '@/api/types/agent-team'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { useModelProviders } from '@/composables/useModelProviders'
import { getIconUrl } from '@/utils/icon-map'
import { categoryAccent } from '@/mobile/utils/category-accent'

const props = defineProps<{ agent: AgentTeamMember }>()
const { t } = useI18n()

const displayAvatar = computed(() => resolveAgentAvatar(props.agent.templateId, props.agent.avatar || '🤖'))
const avatarIsImage = computed(() => isImageAvatar(displayAvatar.value))

const accent = computed(() => categoryAccent(props.agent.category))

const companionDays = computed(() => {
  if (!props.agent.createdAt) return 0
  return Math.max(0, Math.floor((Date.now() - props.agent.createdAt) / 86400000))
})

const { getModelOption } = useModelProviders()
const modelIconUrl = computed(() => {
  const m = props.agent.model
  if (!m) return undefined
  const pid = getModelOption(m)?.providerId
  if (!pid) return undefined
  return getIconUrl(pid)
})
</script>

<template>
  <article class="agent-card">
    <span class="accent-bar" :style="{ background: accent.bar }" aria-hidden="true" />
    <div class="card-body">
      <span
        class="avatar"
        :class="{ image: avatarIsImage }"
        :style="!avatarIsImage ? { background: accent.avatarTint } : undefined"
      >
        <img
          v-if="avatarIsImage"
          v-avatar-fallback
          :src="displayAvatar"
          :alt="agent.name"
          class="avatar-img"
        >
        <span v-else class="avatar-emoji">{{ displayAvatar }}</span>
      </span>

      <div class="info">
        <div class="name-row">
          <span class="name">{{ agent.name }}</span>
          <span
            class="status"
            :class="{ active: agent.status === 'active' }"
            :aria-label="agent.status"
          />
        </div>
        <p class="desc">{{ agent.description }}</p>
        <div class="meta">
          <span v-if="agent.model" class="model-pill">
            <img v-if="modelIconUrl" :src="modelIconUrl" class="model-icon" alt="">
            <span class="model-name">{{ agent.model }}</span>
          </span>
          <span class="companion">{{ companionDays }} {{ t('pages.agentTeam.card.days') }}</span>
        </div>
      </div>
    </div>
  </article>
</template>

<style scoped>
.agent-card {
  position: relative;
  display: flex;
  flex-direction: column;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-lg);
  box-shadow: var(--m-shadow-card);
  overflow: hidden;
  backdrop-filter: blur(14px);
}

.accent-bar {
  display: block;
  height: 3px;
  width: 100%;
}

.card-body {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 14px;
}

.avatar {
  position: relative;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 56px;
  height: 56px;
  border-radius: 18px;
  color: var(--m-primary);
  font-size: 30px;
  line-height: 1;
  flex-shrink: 0;
  overflow: hidden;
  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.08);
}

.avatar.image { background: #fff; }
.avatar-emoji { line-height: 1; }
.avatar-img { width: 100%; height: 100%; object-fit: cover; }

.info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.name-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.name {
  font-size: 16px;
  font-weight: 700;
  color: var(--m-text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.status {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #cbd5e1;
  flex-shrink: 0;
}

.status.active {
  background: #22c55e;
  animation: pulse-status 2s infinite;
}

@keyframes pulse-status {
  0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.45); }
  70% { box-shadow: 0 0 0 7px rgba(34, 197, 94, 0); }
  100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
}

.desc {
  margin: 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--m-text-hint);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 4px;
  flex-wrap: wrap;
}

.model-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  max-width: 60%;
  padding: 3px 9px;
  background: var(--m-bg-input);
  border-radius: 999px;
  font-size: 11px;
  color: var(--m-text-secondary);
}

.model-icon {
  width: 13px;
  height: 13px;
  object-fit: contain;
  flex-shrink: 0;
}

.model-name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.companion {
  margin-left: auto;
  font-size: 11px;
  color: var(--m-text-hint);
  white-space: nowrap;
}

@media (prefers-reduced-motion: reduce) {
  .status.active { animation: none; }
}
</style>
