<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { categoryAccent } from '@/mobile/utils/category-accent'

const props = defineProps<{ template: AgentTemplate; hot?: boolean }>()
const emit = defineEmits<{ (e: 'create', template: AgentTemplate): void }>()

const { t } = useI18n()

const avatar = computed(() => resolveAgentAvatar(props.template.id, props.template.avatar || '🤖'))
const isImage = computed(() => isImageAvatar(avatar.value))
const accent = computed(() => categoryAccent(props.template.category || ''))
</script>

<template>
  <div class="mcard">
    <span class="mcard-glow" :style="{ background: accent.glow }" />
    <span class="mcard-accent" :style="{ background: accent.bar }" />
    <span v-if="hot" class="mcard-hot">{{ t('pages.mobile.agents.hot') }}</span>

    <div class="mcard-top">
      <span
        class="mcard-avatar"
        :class="{ image: isImage }"
        :style="!isImage ? { background: accent.avatarTint } : undefined"
      >
        <img v-if="isImage" v-avatar-fallback :src="avatar" :alt="template.name" class="mcard-avatar-img">
        <span v-else>{{ avatar }}</span>
      </span>
      <button
        class="mcard-add"
        :aria-label="t('pages.mobile.agents.create')"
        @click.stop="emit('create', template)"
      >
        <svg viewBox="0 0 24 24" class="ic"><path d="M12 5v14M5 12h14" /></svg>
      </button>
    </div>

    <h3 class="mcard-name">{{ template.name }}</h3>
    <p class="mcard-desc">{{ template.description || template.tagline }}</p>
  </div>
</template>

<style scoped>
.mcard {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 14px 12px 12px;
  background: var(--m-bg-input);
  border: 1px solid var(--m-border);
  border-radius: 16px;
  overflow: hidden;
  box-shadow: var(--m-shadow-soft);
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.18s ease, box-shadow 0.18s ease;
}
.mcard:active { transform: scale(0.97); }

.mcard-glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: 0.55;
}
.mcard-accent {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
}
.mcard-hot {
  position: absolute;
  top: 10px; left: 10px;
  padding: 2px 8px;
  background: linear-gradient(135deg, #f97316, #ef4444);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  border-radius: 999px;
  letter-spacing: 0.02em;
  box-shadow: 0 2px 6px rgba(239, 68, 68, 0.35);
}

.mcard-top {
  position: relative;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 10px;
}
.mcard-avatar {
  display: grid;
  place-items: center;
  width: 44px; height: 44px;
  border-radius: 14px;
  color: var(--m-primary);
  font-size: 22px;
  line-height: 1;
  overflow: hidden;
  box-shadow: 0 6px 14px rgba(15, 23, 42, 0.1);
}
.mcard-avatar.image { background: #fff; }
.mcard-avatar-img { width: 100%; height: 100%; object-fit: cover; }

.mcard-add {
  display: grid;
  place-items: center;
  width: 30px; height: 30px;
  border-radius: 50%;
  border: none;
  background: var(--m-primary);
  color: #fff;
  cursor: pointer;
  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.35);
  transition: transform 0.18s ease;
}
.mcard-add:active { transform: scale(0.88) rotate(90deg); }
.mcard-add .ic { width: 16px; height: 16px; }

.mcard-name {
  margin: 0 0 4px;
  font-size: 14px;
  font-weight: 700;
  color: var(--m-text-primary);
  line-height: 1.3;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mcard-desc {
  margin: 0;
  font-size: 11.5px;
  line-height: 1.45;
  color: var(--m-text-secondary);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.ic {
  fill: none;
  stroke: currentColor;
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
</style>
