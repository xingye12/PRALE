<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { NDrawer, NDrawerContent } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { categoryAccent } from '@/mobile/utils/category-accent'
import { useAgentCreation, isAgentTeamLimitError } from '@/composables/useAgentCreation'
import { useMobileModelSelect } from '@/mobile/composables/useMobileModelSelect'
import MobileModelPicker from '@/mobile/components/MobileModelPicker.vue'

const props = defineProps<{ show: boolean; template: AgentTemplate | null }>()
const emit = defineEmits<{
  (e: 'update:show', v: boolean): void
  (e: 'created'): void
}>()

const { t } = useI18n()
const { createAgent } = useAgentCreation()
const model = useMobileModelSelect()

type Phase = 'form' | 'creating' | 'done' | 'error'
const phase = ref<Phase>('form')
const name = ref('')
const errorMsg = ref('')
const progress = ref(0)
const stage = ref('')

// 抽屉高度:固定百分比(naive-ui bottom 抽屉不支持 auto,会塌缩只剩标题)
// 表单/报错/创建中 52% 紧凑显示,按钮紧跟内容无中间留白;完成态 46%
const drawerHeight = computed(() => {
  if (phase.value === 'done') return '46%'
  return '52%'
})

// 表体最小高:撑满抽屉内容区,使创建中进度环/完成对勾垂直居中,表单态按钮紧跟内容
const sheetMinHeight = computed(() => {
  if (phase.value === 'done') return 'calc(46vh - 56px)'
  return 'calc(52vh - 56px)'
})

const accent = computed(() => categoryAccent(props.template?.category || ''))
const avatar = computed(() =>
  props.template ? resolveAgentAvatar(props.template.id, props.template.avatar || '🤖') : '',
)
const isImage = computed(() => isImageAvatar(avatar.value))

// 打开时重置 + 预填模板名 + 加载模型默认
watch(
  () => props.show,
  async (v) => {
    if (v && props.template) {
      phase.value = 'form'
      name.value = props.template.name
      progress.value = 0
      stage.value = ''
      errorMsg.value = ''
      await model.ensureLoaded()
    }
  },
)

function close() {
  emit('update:show', false)
}

async function submit() {
  if (!props.template || !name.value.trim() || phase.value === 'creating') return
  const tpl = props.template
  phase.value = 'creating'
  progress.value = 0
  stage.value = t('pages.mobile.agents.createStarting')
  errorMsg.value = ''
  try {
    await createAgent(
      {
        name: name.value.trim(),
        avatar: tpl.avatar,
        description: tpl.description,
        category: tpl.category,
        templateId: tpl.id,
        soulMd: tpl.soulMd,
        agentsMd: tpl.agentsMd,
        identityMd: tpl.identityMd,
        userMd: tpl.userMd,
        model: model.activeModel.value || undefined,
      },
      (p, s) => {
        progress.value = p
        stage.value = s
      },
    )
    phase.value = 'done'
    setTimeout(() => {
      emit('created')
      close()
    }, 700)
  } catch (err) {
    if (isAgentTeamLimitError(err)) {
      errorMsg.value = t('pages.mobile.agents.limitReached')
    } else {
      errorMsg.value = err instanceof Error ? err.message : String(err)
    }
    phase.value = 'error'
  }
}
</script>

<template>
  <NDrawer
    :show="show"
    placement="bottom"
    :height="drawerHeight"
    :auto-focus="false"
    :mask-closable="phase !== 'creating'"
    :close-on-esc="phase !== 'creating'"
    @update:show="emit('update:show', $event)"
  >
    <NDrawerContent :native-scrollbar="false" body-content-style="padding: 0;">
      <template #header>
        <span class="sheet-title">{{ t('pages.mobile.agents.createTitle') }}</span>
      </template>

      <div class="sheet-body" :style="{ minHeight: sheetMinHeight }">
        <!-- 模板预填卡(只读) -->
        <div v-if="template" class="tpl-preview">
          <span class="tpl-glow" :style="{ background: accent.glow }" />
          <span class="tpl-accent" :style="{ background: accent.bar }" />
          <span
            class="tpl-avatar"
            :class="{ image: isImage }"
            :style="!isImage ? { background: accent.avatarTint } : undefined"
          >
            <img v-if="isImage" v-avatar-fallback :src="avatar" :alt="template.name" class="tpl-avatar-img">
            <span v-else>{{ avatar }}</span>
          </span>
          <div class="tpl-meta">
            <h3 class="tpl-name">{{ template.name }}</h3>
            <p class="tpl-desc">{{ template.description || template.tagline }}</p>
          </div>
        </div>

        <!-- 表单态 -->
        <template v-if="phase === 'form' || phase === 'error'">
          <label class="field-label">{{ t('pages.mobile.agents.createNameLabel') }}</label>
          <input
            v-model="name"
            class="name-input"
            :placeholder="t('pages.mobile.agents.createNamePlaceholder')"
            maxlength="30"
          >

          <label class="field-label">{{ t('pages.mobile.agents.createModelLabel') }}</label>
          <div class="model-field">
            <MobileModelPicker
              :options="model.modelOptions.value"
              :active-model-ref="model.activeModel.value"
              :active-label="model.activeModelLabel.value"
              :active-icon="model.activeModelIcon.value"
              @select="model.selectModel"
            />
          </div>

          <p v-if="phase === 'error'" class="error-msg">{{ errorMsg }}</p>

          <button class="submit-btn" :disabled="!name.trim()" @click="submit">
            {{ phase === 'error' ? t('pages.mobile.agents.retry') : t('pages.mobile.agents.confirmCreate') }}
          </button>
        </template>

        <!-- 创建中 -->
        <div v-else-if="phase === 'creating'" class="progress-wrap">
          <div class="progress-ring">
            <svg viewBox="0 0 100 100" class="ring-svg">
              <circle class="ring-bg" cx="50" cy="50" r="44" />
              <circle
                class="ring-fg"
                cx="50" cy="50" r="44"
                :stroke-dasharray="276.46"
                :stroke-dashoffset="276.46 * (1 - progress / 100)"
              />
            </svg>
            <span class="progress-pct">{{ progress }}%</span>
          </div>
          <p class="progress-stage">{{ stage }}</p>
          <p class="progress-hint">{{ t('pages.mobile.agents.creatingHint') }}</p>
        </div>

        <!-- 完成 -->
        <div v-else class="done-wrap">
          <div class="done-check">
            <svg viewBox="0 0 24 24"><path d="M5 12l4 4 10-10" /></svg>
          </div>
          <p class="done-text">{{ t('pages.mobile.agents.createDone') }}</p>
        </div>
      </div>
    </NDrawerContent>
  </NDrawer>
</template>

<style scoped>
.sheet-title {
  font-size: 16px;
  font-weight: 700;
  color: var(--m-text-primary);
}
.sheet-body {
  display: flex;
  flex-direction: column;
  padding: 4px 16px calc(20px + env(safe-area-inset-bottom));
}

/* 模板预览 */
.tpl-preview {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px;
  margin-bottom: 18px;
  border: 1px solid var(--m-border);
  border-radius: 16px;
  background: var(--m-bg-input);
  box-shadow: var(--m-shadow-soft);
  overflow: hidden;
}
.tpl-glow { position: absolute; inset: 0; pointer-events: none; opacity: 0.5; }
.tpl-accent { position: absolute; top: 0; left: 0; right: 0; height: 3px; }
.tpl-avatar {
  position: relative;
  display: grid; place-items: center;
  width: 44px; height: 44px;
  border-radius: 14px;
  color: var(--m-primary); font-size: 22px; line-height: 1;
  overflow: hidden; box-shadow: 0 6px 14px rgba(15,23,42,0.1);
}
.tpl-avatar.image { background: #fff; }
.tpl-avatar-img { width: 100%; height: 100%; object-fit: cover; }
.tpl-meta { position: relative; flex: 1; min-width: 0; }
.tpl-name {
  margin: 0 0 2px; font-size: 14px; font-weight: 700;
  color: var(--m-text-primary);
}
.tpl-desc {
  margin: 0; font-size: 11.5px; color: var(--m-text-secondary);
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}

/* 表单 */
.field-label {
  display: block;
  margin: 0 0 8px;
  font-size: 12px; font-weight: 600;
  color: var(--m-text-hint);
}
.name-input {
  width: 100%;
  padding: 12px 14px;
  margin-bottom: 18px;
  border: 1.5px solid var(--m-border);
  border-radius: 12px;
  background: var(--m-bg-input);
  color: var(--m-text-primary);
  font-size: 15px;
  outline: none;
  transition: border-color 0.18s ease, box-shadow 0.18s ease;
}
.name-input:focus {
  border-color: var(--m-primary);
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.model-field {
  margin-bottom: 18px;
}

.error-msg {
  margin: 0 0 12px;
  padding: 10px 12px;
  border-radius: 10px;
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
  font-size: 13px;
  line-height: 1.4;
}

.submit-btn {
  width: 100%;
  padding: 14px;
  border: none;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--m-primary), #7c3aed);
  color: #fff;
  font-size: 15px; font-weight: 700;
  cursor: pointer;
  box-shadow: 0 6px 16px rgba(37, 99, 235, 0.3);
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease, opacity 0.15s ease;
}
.submit-btn:active { transform: scale(0.98); }
.submit-btn:disabled { opacity: 0.5; }

/* 创建中 */
.progress-wrap {
  flex: 1;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 24px 0 12px;
}
.progress-ring {
  position: relative;
  width: 96px; height: 96px;
  margin-bottom: 18px;
}
.ring-svg {
  width: 100%; height: 100%;
  transform: rotate(-90deg);
}
.ring-bg {
  fill: none;
  stroke: var(--m-border);
  stroke-width: 8;
}
.ring-fg {
  fill: none;
  stroke: var(--m-primary);
  stroke-width: 8;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.4s ease;
}
.progress-pct {
  position: absolute;
  inset: 0;
  display: grid; place-items: center;
  font-size: 22px; font-weight: 800;
  color: var(--m-primary);
}
.progress-stage {
  margin: 0 0 4px;
  font-size: 15px; font-weight: 600;
  color: var(--m-text-primary);
}
.progress-hint {
  margin: 0;
  font-size: 12px;
  color: var(--m-text-hint);
}

/* 完成 */
.done-wrap {
  flex: 1;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 36px 0 16px;
}
.done-check {
  display: grid; place-items: center;
  width: 64px; height: 64px;
  margin-bottom: 14px;
  border-radius: 50%;
  background: linear-gradient(135deg, #10b981, #059669);
  box-shadow: 0 8px 20px rgba(16, 185, 129, 0.35);
  animation: pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.done-check svg {
  width: 32px; height: 32px;
  fill: none; stroke: #fff;
  stroke-width: 3; stroke-linecap: round; stroke-linejoin: round;
}
.done-text {
  margin: 0;
  font-size: 16px; font-weight: 700;
  color: var(--m-text-primary);
}
@keyframes pop {
  from { transform: scale(0.4); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
</style>
