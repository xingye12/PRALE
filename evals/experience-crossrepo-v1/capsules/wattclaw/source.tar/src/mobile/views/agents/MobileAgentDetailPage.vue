<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NDropdown, useDialog, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useSessionStore } from '@/stores/session'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { useModelProviders } from '@/composables/useModelProviders'
import { getIconUrl } from '@/utils/icon-map'
import { getTemplateById } from '@/config/agent-templates'
import { extractPureTitle } from '@/utils/session-title'
import { formatRelativeTime } from '@/mobile/utils/format-relative-time'
import { categoryAccent } from '@/mobile/utils/category-accent'

const route = useRoute()
const router = useRouter()
const { t } = useI18n()
const agentTeamStore = useAgentTeamStore()
const sessionStore = useSessionStore()

const agentId = computed(() => route.params.id as string)
const agent = computed(() => agentTeamStore.currentAgent)
const loading = ref(true)
const dialog = useDialog()
const message = useMessage()

const displayAvatar = computed(() =>
  resolveAgentAvatar(agent.value?.templateId, agent.value?.avatar || '🤖'),
)
const avatarIsImage = computed(() => isImageAvatar(displayAvatar.value))
const accent = computed(() => categoryAccent(agent.value?.category || ''))

const tpl = computed(() => {
  const tid = agent.value?.templateId
  return tid ? getTemplateById(tid) : undefined
})
const tagline = computed(() => tpl.value?.tagline || agent.value?.description || '')
const prompts = computed(() => (tpl.value?.prompts || []).slice(0, 3))

const companionDays = computed(() => {
  if (!agent.value?.createdAt) return 0
  return Math.max(0, Math.floor((Date.now() - agent.value.createdAt) / 86400000))
})

const { getModelOption, loaded, fetchProviders } = useModelProviders()
const modelIconUrl = computed(() => {
  const m = agent.value?.model
  if (!m) return undefined
  const pid = getModelOption(m)?.providerId
  if (!pid) return undefined
  return getIconUrl(pid)
})

const agentSessions = computed(() => {
  if (!agentId.value) return []
  return sessionStore.sessions
    .filter(s => s.agentId === agentId.value)
    .sort((a, b) => (b.lastActivity || '').localeCompare(a.lastActivity || ''))
})

const dropdownOptions = computed(() => [
  { label: t('pages.mobile.agents.edit'), key: 'edit' },
  { label: t('pages.mobile.agents.delete'), key: 'delete' },
])

function handleMenu(key: string) {
  if (key === 'edit') router.push(`/m/agents/${agentId.value}/edit`)
  else if (key === 'delete') requestDelete()
}

function requestDelete() {
  dialog.warning({
    title: t('pages.mobile.agents.delete'),
    content: t('pages.mobile.agents.deleteConfirm'),
    positiveText: t('pages.mobile.agents.delete'),
    negativeText: t('pages.mobile.profile.cancel'),
    onPositiveClick: async () => {
      await agentTeamStore.deleteAgent(agentId.value)
      message.success(t('pages.mobile.agents.deletedTip'))
      router.push({ path: '/m/agents', query: { tab: 'manage' } })
    },
  })
}

function formatTitle(session: { displayTitle?: string; label?: string }): string {
  const raw = extractPureTitle(session.displayTitle || session.label || '').trim()
  if (!raw) return t('pages.mobile.chat.newConversation')
  return raw.length > 32 ? raw.slice(0, 32) + '...' : raw
}

function goToChat() {
  // 有历史进最近会话，无历史进新对话欢迎屏
  if (agentSessions.value.length > 0) {
    router.push(`/m/chat/${agentSessions.value[0]!.key}`)
  } else {
    router.push({ path: '/m/chat', query: { agentId: agentId.value } })
  }
}

function handleBack() {
  if (history.length > 1) router.back()
  else router.push('/m/agents')
}

function startNewChat(prompt?: string) {
  const query: Record<string, string> = { agentId: agentId.value }
  if (prompt) query.prompt = prompt
  router.push({ path: '/m/chat', query })
}

onMounted(async () => {
  try {
    await Promise.all([
      agentTeamStore.fetchAgent(agentId.value),
      sessionStore.fetchSessions(),
    ])
    if (!loaded.value) void fetchProviders()
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="mobile-page detail-page">
    <!-- Top bar -->
    <header class="topbar">
      <button class="icon-btn" :aria-label="t('pages.mobile.chat.back')" @click="handleBack">
        <span class="back-arrow">‹</span>
      </button>
      <div class="topbar-title">{{ agent?.name || t('pages.mobile.agents.detail') }}</div>
      <NDropdown
        v-if="agent"
        :options="dropdownOptions"
        trigger="click"
        placement="bottom-end"
        :flip="false"
        @select="handleMenu"
      >
        <button class="icon-btn" aria-label="more">
          <svg width="20" height="20" viewBox="0 0 16 16" fill="currentColor">
            <circle cx="8" cy="3" r="1.6" />
            <circle cx="8" cy="8" r="1.6" />
            <circle cx="8" cy="13" r="1.6" />
          </svg>
        </button>
      </NDropdown>
      <div v-else class="icon-btn-placeholder" />
    </header>

    <!-- Loading -->
    <div v-if="loading" class="state-block">
      <span>{{ t('pages.mobile.chat.loadingHistory') }}</span>
    </div>

    <!-- Not found -->
    <div v-else-if="!agent" class="state-block">
      <span>{{ t('pages.mobile.chat.noAgents') }}</span>
    </div>

    <!-- Content -->
    <div v-else class="detail-scroll">
      <!-- Hero -->
      <section class="hero">
        <div class="hero-glow" :style="{ background: accent.glow }" aria-hidden="true" />
        <span
          class="hero-avatar"
          :class="{ image: avatarIsImage }"
          :style="!avatarIsImage ? { background: accent.avatarTint } : undefined"
        >
          <img
            v-if="avatarIsImage"
            v-avatar-fallback
            :src="displayAvatar"
            :alt="agent.name"
            class="hero-avatar-img"
          >
          <span v-else>{{ displayAvatar }}</span>
        </span>
        <h1 class="hero-name">{{ agent.name }}</h1>
        <div class="hero-status">
          <span class="status-dot" :class="{ active: agent.status === 'active' }" />
          <span>{{ t('pages.mobile.agents.statusOnline') }}</span>
        </div>
        <p v-if="tagline" class="hero-tagline">{{ tagline }}</p>
      </section>

      <!-- Meta pills -->
      <section class="meta-row">
        <span v-if="agent.model" class="meta-pill">
          <img v-if="modelIconUrl" :src="modelIconUrl" class="meta-icon" alt="">
          <span class="meta-text">{{ agent.model }}</span>
        </span>
        <span v-if="agent.category" class="meta-pill">
          <span class="meta-text">{{ agent.category }}</span>
        </span>
        <span class="meta-pill meta-pill-stat">
          <span class="meta-stat-num">{{ companionDays }}</span>
          <span class="meta-stat-unit">{{ t('pages.agentTeam.card.days') }}</span>
        </span>
      </section>

      <!-- Try ask -->
      <section v-if="prompts.length > 0" class="section">
        <h2 class="section-title">{{ t('pages.mobile.agents.tryAsk') }}</h2>
        <div class="prompt-chips">
          <button
            v-for="(p, i) in prompts"
            :key="i"
            class="prompt-chip"
            @click="startNewChat(p)"
          >{{ p }}</button>
        </div>
      </section>

      <!-- Recent sessions -->
      <section class="section">
        <h2 class="section-title">{{ t('pages.mobile.agents.recentSessions') }}</h2>
        <div v-if="agentSessions.length === 0" class="no-sessions">
          {{ t('pages.mobile.agents.noSessions') }}
        </div>
        <div v-else class="session-list">
          <button
            v-for="s in agentSessions.slice(0, 8)"
            :key="s.key"
            class="session-item"
            @click="router.push(`/m/chat/${s.key}`)"
          >
            <span class="session-title">{{ formatTitle(s) }}</span>
            <span class="session-time">{{ formatRelativeTime(s.lastActivity, (k) => t(k)) }}</span>
          </button>
        </div>
      </section>
    </div>

    <!-- Sticky CTA -->
    <div v-if="agent && !loading" class="cta-bar">
      <button class="cta-btn" @click="goToChat">
        <span class="cta-icon">💬</span>
        <span>{{ t('pages.mobile.agents.goToChat') }}</span>
      </button>
    </div>

  </div>
</template>

<style scoped>
.detail-page {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  min-height: 100dvh;
}

.topbar {
  flex-shrink: 0;
  position: sticky;
  top: 0;
  z-index: 10;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  padding-top: calc(12px + env(safe-area-inset-top));
  background: var(--m-tab-bar-bg);
  backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--m-border);
}

.icon-btn {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  background: none;
  border: none;
  color: var(--m-text-primary);
  cursor: pointer;
  border-radius: 50%;
  -webkit-tap-highlight-color: transparent;
}

.back-arrow {
  font-size: 30px;
  line-height: 1;
  display: block;
  transform: translateY(-3px);
}

.icon-btn-placeholder {
  width: 34px;
  height: 34px;
  flex-shrink: 0;
}

.topbar-title {
  flex: 1;
  font-size: 17px;
  font-weight: 700;
  color: var(--m-text-primary);
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.state-block {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--m-text-hint);
  font-size: 14px;
}

.detail-scroll {
  flex: 1;
  overflow-y: auto;
  padding-bottom: 110px;
  -webkit-overflow-scrolling: touch;
}

/* Hero */
.hero {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 32px 24px 24px;
  overflow: hidden;
}

.hero-glow {
  position: absolute;
  top: -50px;
  left: 50%;
  transform: translateX(-50%);
  width: 280px;
  height: 220px;
  pointer-events: none;
  z-index: 0;
}

.hero-avatar {
  position: relative;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 96px;
  height: 96px;
  border-radius: 30px;
  color: var(--m-primary);
  font-size: 50px;
  line-height: 1;
  overflow: hidden;
  box-shadow: var(--m-shadow-soft);
  animation: hero-in 0.5s ease;
}

.hero-avatar.image { background: #fff; }
.hero-avatar-img { width: 100%; height: 100%; object-fit: cover; }

.hero-name {
  position: relative;
  z-index: 1;
  margin: 14px 0 0;
  font-size: 22px;
  font-weight: 800;
  color: var(--m-text-primary);
  letter-spacing: -0.01em;
}

.hero-status {
  position: relative;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin-top: 6px;
  font-size: 12px;
  color: var(--m-text-hint);
}

.status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #cbd5e1;
}

.status-dot.active {
  background: #22c55e;
  animation: pulse-status 2s infinite;
}

.hero-tagline {
  position: relative;
  z-index: 1;
  margin: 12px 0 0;
  font-size: 14px;
  line-height: 1.6;
  color: var(--m-text-secondary);
  max-width: 300px;
}

@keyframes hero-in {
  from { opacity: 0; transform: scale(0.9); }
  to { opacity: 1; transform: scale(1); }
}

@keyframes pulse-status {
  0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.5); }
  70% { box-shadow: 0 0 0 6px rgba(34, 197, 94, 0); }
  100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
}

/* Meta pills */
.meta-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 0 16px;
}

.meta-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 6px 12px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: 999px;
  font-size: 12px;
  color: var(--m-text-secondary);
}

.meta-icon { width: 14px; height: 14px; object-fit: contain; }
.meta-text { white-space: nowrap; }

.meta-pill-stat {
  margin-left: auto;
  gap: 3px;
}

.meta-stat-num { font-size: 14px; font-weight: 700; color: var(--m-text-primary); }
.meta-stat-unit { font-size: 11px; color: var(--m-text-hint); }

/* Sections */
.section {
  padding: 24px 16px 0;
}

.section-title {
  margin: 0 0 12px;
  font-size: 14px;
  font-weight: 700;
  color: var(--m-text-primary);
}

.prompt-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.prompt-chip {
  padding: 9px 14px;
  background: var(--m-bg-input);
  border: 1px solid var(--m-border);
  border-radius: 999px;
  font-size: 13px;
  color: var(--m-text-secondary);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease;
  max-width: 100%;
}

.prompt-chip:active { transform: scale(0.96); }

.no-sessions {
  padding: 20px 16px;
  text-align: center;
  font-size: 13px;
  color: var(--m-text-hint);
  background: var(--m-bg-card);
  border: 1px dashed var(--m-border);
  border-radius: var(--m-radius-md);
}

.session-list {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid var(--m-divider);
  border-radius: var(--m-radius-md);
  background: var(--m-bg-card);
}

.session-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  min-height: 48px;
  padding: 12px 14px;
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--m-divider);
  cursor: pointer;
  text-align: left;
  -webkit-tap-highlight-color: transparent;
}

.session-item:last-child { border-bottom: none; }
.session-item:active { background: var(--m-bg-input); }

.session-title {
  font-size: 14px;
  color: var(--m-text-primary);
  flex: 1;
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.session-time {
  font-size: 12px;
  color: var(--m-text-hint);
  flex-shrink: 0;
}

/* Sticky CTA */
.cta-bar {
  position: sticky;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 12px 16px calc(12px + env(safe-area-inset-bottom));
  background: linear-gradient(to top, var(--m-bg-page) 55%, transparent);
  backdrop-filter: blur(8px);
}

.cta-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  padding: 15px;
  background: var(--m-bubble-user-bg);
  color: #fff;
  border: none;
  border-radius: var(--m-radius-md);
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  box-shadow: var(--m-shadow-soft);
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease;
}

.cta-btn:active { transform: scale(0.98); }
.cta-icon { font-size: 18px; }

@media (prefers-reduced-motion: reduce) {
  .hero-avatar,
  .status-dot.active { animation: none; }
}
</style>
