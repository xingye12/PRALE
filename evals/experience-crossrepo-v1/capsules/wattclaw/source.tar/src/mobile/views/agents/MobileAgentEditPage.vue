<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useMessage } from 'naive-ui'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useWebSocketStore } from '@/stores/websocket'
import { useAuthStore } from '@/stores/auth'
import { useAgentCreation } from '@/composables/useAgentCreation'
import { useMobileModelSelect } from '@/mobile/composables/useMobileModelSelect'
import { getTemplateById } from '@/config/agent-templates'
import type { AgentTemplate } from '@/api/types/agent-team'
import { apiPath } from '@/utils/api-path'
import { categoryAccent } from '@/mobile/utils/category-accent'
import MobileTemplatePicker from './MobileTemplatePicker.vue'
import MobileSettingSection from './MobileSettingSection.vue'
import MobileModelPicker from '@/mobile/components/MobileModelPicker.vue'

const route = useRoute()
const router = useRouter()
const { t } = useI18n()
const message = useMessage()
const agentTeamStore = useAgentTeamStore()
const wsStore = useWebSocketStore()
const authStore = useAuthStore()
const { createAgent: createAgentViaGateway } = useAgentCreation()
const {
  modelOptions,
  activeModel,
  activeModelLabel,
  activeModelIcon,
  selectModel,
  ensureLoaded: ensureModelsLoaded,
} = useMobileModelSelect()

const isEdit = computed(() => route.name === 'MobileAgentEdit')
const agentId = computed(() => route.params.id as string)
const loading = ref(false)
const submitting = ref(false)
const error = ref('')

const selectedTemplateId = ref('')
const name = ref('')
const description = ref('')
const model = ref('')

/** 设定文件内容：edit 态由 Gateway 读取；create 态由 settingSource 改用 createFiles computed */
const settingFiles = ref<Record<string, string>>({})
/** edit 态：设定文件从 Gateway 加载失败标记（顶部错误条提示） */
const settingLoadError = ref(false)

const selectedTemplate = computed((): AgentTemplate | undefined => {
  return getTemplateById(selectedTemplateId.value)
})

/** create 态：模板自带的 4 文件内容随选中模板变化（响应式只读预览） */
const createFiles = computed<Record<string, string>>(() => {
  const tpl = selectedTemplate.value
  if (!tpl) return { 'SOUL.md': '', 'AGENTS.md': '', 'IDENTITY.md': '', 'USER.md': '' }
  return {
    'SOUL.md': tpl.soulMd || '',
    'AGENTS.md': tpl.agentsMd || '',
    'IDENTITY.md': tpl.identityMd || '',
    'USER.md': tpl.userMd || '',
  }
})

/** 设定区绑定：create 用模板预填，edit 用 Gateway 读取结果 */
const settingSource = computed<Record<string, string>>(() =>
  isEdit.value ? settingFiles.value : createFiles.value,
)

/** Hero 光晕强调色：编辑态取员工分类，创建态取选中模板分类，否则主色。 */
const heroAccent = computed(() => {
  if (isEdit.value) {
    const extra = agentTeamStore.currentAgent as Record<string, unknown> | undefined
    return categoryAccent((extra?.category as string) || '')
  }
  return categoryAccent(selectedTemplate.value?.category || '')
})

function onTemplateSelect(template: AgentTemplate) {
  selectedTemplateId.value = template.id
  name.value = name.value || template.name
  description.value = description.value || template.description
}

/** 编辑态：从 Gateway 读取 4 个设定文件 */
async function loadSettingFiles() {
  const id = agentId.value
  if (!id) return
  const token = authStore.getToken()
  try {
    const res = await fetch(apiPath(`/api/agent-team/${id}/files`), {
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    })
    const data = res.ok ? await res.json().catch(() => null) : null
    if (data?.ok && data.files) {
      settingFiles.value = { ...(data.files as Record<string, string>) }
      settingLoadError.value = false
    } else {
      // HTTP 错误或后端 data.ok=false：标记失败，顶部错误条提示
      settingLoadError.value = true
    }
  } catch (err) {
    // 不静默吞错：记录 + 顶部错误条提示，不阻塞页面（设定区降级为空内容）
    console.error('[MobileAgentEdit] load setting files failed:', err)
    settingLoadError.value = true
  }
}

/** 编辑态：保存单个设定文件到 Gateway */
async function onSettingEdit(payload: { file: string; content: string }) {
  const id = agentId.value
  if (!id) return
  try {
    await wsStore.rpc.setAgentFile(id, payload.file, payload.content)
    // 本地刷新，避免再次请求
    settingFiles.value = { ...settingFiles.value, [payload.file]: payload.content }
  } catch (err) {
    error.value = err instanceof Error ? err.message : String(err)
  }
}

onMounted(async () => {
  if (isEdit.value) {
    loading.value = true
    try {
      await agentTeamStore.fetchAgent(agentId.value)
      const agent = agentTeamStore.currentAgent
      if (agent) {
        name.value = agent.name || ''
        description.value = agent.description || ''
        model.value = agent.model || ''
        const extra = agent as Record<string, unknown>
        selectedTemplateId.value = (extra.templateId as string) || ''
      }
      await loadSettingFiles()
      // 编辑态：加载模型列表 + 选中员工当前 model（供下拉显示）
      await ensureModelsLoaded()
      if (model.value) selectModel(model.value)
    } finally {
      loading.value = false
    }
  } else {
    // 创建态：预拉模型列表 + 配置，初始化选中默认模型
    void ensureModelsLoaded()
  }
})

async function handleSubmit() {
  if (!name.value.trim()) return
  submitting.value = true
  try {
    error.value = ''
    if (isEdit.value) {
      const updates: Record<string, unknown> = {
        name: name.value,
        description: description.value,
        model: activeModel.value || model.value,
      }
      if (selectedTemplateId.value) updates.templateId = selectedTemplateId.value
      await agentTeamStore.updateAgent(agentId.value, updates)
    } else {
      // 走 useAgentCreation 权威流程：Gateway 建agent → 写4设定文件 → complete-bootstrap → 本地 store.createAgent(带 gatewayAgentId)
      // 修复 "gatewayAgentId is required"：原直接调 store.createAgent 漏了 Gateway 建agent 前置步骤
      // 设定经 useAgentCreation 内 setAgentFile 写入（创建态设定随之生效，不再是空设定）
      const files = createFiles.value
      await createAgentViaGateway({
        name: name.value,
        avatar: selectedTemplate.value?.avatar || '🤖',
        description: description.value,
        category: selectedTemplate.value?.category || '',
        templateId: selectedTemplateId.value,
        soulMd: files['SOUL.md'] || '',
        agentsMd: files['AGENTS.md'] || '',
        identityMd: files['IDENTITY.md'] || '',
        userMd: files['USER.md'] || '',
        model: activeModel.value || undefined,
      })
    }
    if (isEdit.value) {
      // 编辑：留在当前页 + 提示保存成功（创建仍跳回列表）
      message.success(t('pages.mobile.agents.savedTip'))
    } else {
      router.push('/m/agents')
    }
  } catch (err) {
    error.value = err instanceof Error ? err.message : String(err)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="mobile-page edit-page">
    <!-- Hero -->
    <header class="hero">
      <div class="hero-glow" :style="{ background: heroAccent.glow }" aria-hidden="true" />
      <h1 class="hero-title">{{ isEdit ? t('pages.mobile.agents.editTitle') : t('pages.mobile.agents.createTitle') }}</h1>
      <p class="hero-sub">{{ isEdit ? t('pages.mobile.agents.editSubtitle') : t('pages.mobile.agents.createSubtitle') }}</p>
    </header>

    <!-- Loading -->
    <div v-if="loading" class="state-block">{{ t('pages.mobile.chat.loadingHistory') }}</div>

    <template v-else>
      <!-- Error -->
      <div v-if="error" class="error-card">
        <span class="error-bar" />
        <span>{{ error }}</span>
      </div>

      <!-- Form -->
      <div class="form-scroll">
        <!-- Template selection (create mode only) -->
        <section v-if="!isEdit" class="sec" style="animation-delay: 40ms">
          <div class="sec-head">
            <span class="sec-bar" :style="{ background: heroAccent.bar }" />
            <h2>{{ t('pages.mobile.agents.selectTemplate') }}</h2>
            <span class="sec-hint">{{ t('pages.mobile.agents.templateHint') }}</span>
          </div>
          <MobileTemplatePicker
            :selected-id="selectedTemplateId"
            @select="onTemplateSelect"
          />
        </section>

        <!-- Basic info -->
        <section class="sec" :style="{ animationDelay: isEdit ? '40ms' : '90ms' }">
          <div class="sec-head">
            <span class="sec-bar" :style="{ background: heroAccent.bar }" />
            <h2>{{ t('pages.mobile.agents.basicInfo') }}</h2>
          </div>

          <div class="field">
            <label class="field-label">
              {{ t('pages.mobile.agents.namePlaceholder') }}
              <span class="req">*</span>
            </label>
            <div class="input-wrap">
              <svg viewBox="0 0 24 24" class="input-ic"><circle cx="12" cy="8" r="3.5" /><path d="M5 20c0-3.5 3.5-5.5 7-5.5s7 2 7 5.5" /></svg>
              <input v-model="name" class="field-input" :placeholder="t('pages.mobile.agents.namePlaceholder')" />
            </div>
          </div>

          <div class="field">
            <label class="field-label">{{ t('pages.mobile.agents.descPlaceholder') }}</label>
            <textarea v-model="description" class="field-textarea" rows="3" :placeholder="t('pages.mobile.agents.descPlaceholder')" />
          </div>

          <div class="field last">
            <label class="field-label">{{ t('pages.mobile.agents.modelLabel') }}</label>
            <!-- 创建/编辑态统一：下拉式模型选择器（单一权威） -->
            <MobileModelPicker
              :options="modelOptions"
              :active-model-ref="activeModel"
              :active-label="activeModelLabel"
              :active-icon="activeModelIcon"
              @select="selectModel"
            />
          </div>
        </section>

        <!-- Setting section -->
        <section class="sec" :style="{ animationDelay: isEdit ? '90ms' : '140ms' }">
          <div class="sec-head">
            <span class="sec-bar" :style="{ background: heroAccent.bar }" />
            <h2>{{ t('pages.mobile.agents.setting') }}</h2>
            <span v-if="!isEdit" class="sec-hint">{{ t('pages.mobile.agents.templateHint') }}</span>
          </div>
          <MobileSettingSection
            :mode="isEdit ? 'edit' : 'create'"
            :files="settingSource"
            :load-error="settingLoadError"
            @edit="onSettingEdit"
          />
        </section>
      </div>

      <!-- Submit -->
      <footer class="submit-bar">
        <button
          class="submit-btn"
          :disabled="submitting || !name.trim()"
          @click="handleSubmit"
        >
          <span v-if="submitting" class="spinner" aria-hidden="true" />
          {{ isEdit ? t('pages.mobile.agents.submitSave') : t('pages.mobile.agents.submitCreate') }}
        </button>
      </footer>

    </template>
  </div>
</template>

<style scoped>
.edit-page {
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  min-height: 100dvh;
  background: var(--m-bg-page);
  overflow: hidden;
}

/* ---------- Hero ---------- */
.hero {
  position: relative;
  flex-shrink: 0;
  padding: calc(16px + env(safe-area-inset-top)) 20px 22px;
  overflow: hidden;
}
.hero-glow {
  position: absolute;
  top: -130px;
  left: 50%;
  transform: translateX(-50%);
  width: 400px;
  height: 300px;
  filter: blur(40px);
  opacity: 0.85;
  pointer-events: none;
  z-index: 0;
}
.hero-title {
  position: relative;
  z-index: 1;
  margin: 14px 0 0;
  font-size: 26px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.2;
  color: var(--m-text-primary);
}
.hero-sub {
  position: relative;
  z-index: 1;
  margin: 6px 0 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--m-text-hint);
}

/* ---------- States ---------- */
.state-block {
  flex: 1;
  display: grid;
  place-items: center;
  color: var(--m-text-hint);
  font-size: 14px;
}
.error-card {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 12px 16px 0;
  padding: 12px 14px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-md);
  box-shadow: var(--m-shadow-card);
  color: var(--m-danger);
  font-size: 13px;
}
.error-bar {
  width: 3px;
  align-self: stretch;
  border-radius: 999px;
  background: var(--m-danger);
}

/* ---------- Form scroll ---------- */
.form-scroll {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 16px 16px 24px;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

/* ---------- Section glass cards ---------- */
.sec {
  opacity: 0;
  animation: fade-in-up 0.45s cubic-bezier(0.22, 0.61, 0.36, 1) forwards;
  padding: 16px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-lg);
  box-shadow: var(--m-shadow-card);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}
.sec-head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
}
.sec-bar {
  width: 3px;
  height: 15px;
  border-radius: 999px;
  flex-shrink: 0;
}
.sec-head h2 {
  margin: 0;
  font-size: 15px;
  font-weight: 700;
  color: var(--m-text-primary);
}
.sec-hint {
  margin-left: auto;
  font-size: 11px;
  color: var(--m-text-hint);
}

/* ---------- Fields ---------- */
.field { margin-bottom: 14px; }
.field.last { margin-bottom: 0; }
.field-label {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 7px;
  font-size: 13px;
  font-weight: 600;
  color: var(--m-text-secondary);
}
.req { color: var(--m-danger); font-weight: 700; }
.input-wrap {
  position: relative;
  display: flex;
  align-items: center;
}
.input-ic {
  position: absolute;
  left: 12px;
  width: 18px;
  height: 18px;
  color: var(--m-text-hint);
  pointer-events: none;
  z-index: 1;
  transition: color 0.18s ease;
}
.input-wrap:focus-within .input-ic { color: var(--m-primary); }
.field-input {
  width: 100%;
  padding: 12px 14px 12px 38px;
  background: var(--m-bg-input);
  border: 1.5px solid var(--m-border);
  border-radius: var(--m-radius-md);
  color: var(--m-text-primary);
  font-size: 15px;
  font-family: inherit;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.field-textarea {
  width: 100%;
  padding: 12px 14px;
  background: var(--m-bg-input);
  border: 1.5px solid var(--m-border);
  border-radius: var(--m-radius-md);
  color: var(--m-text-primary);
  font-size: 14px;
  line-height: 1.6;
  font-family: inherit;
  outline: none;
  resize: vertical;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.field-input:focus,
.field-textarea:focus {
  border-color: var(--m-primary);
  box-shadow: 0 0 0 4px var(--m-primary-light);
}

/* ---------- Submit bar ---------- */
.submit-bar {
  flex-shrink: 0;
  padding: 12px 16px calc(14px + env(safe-area-inset-bottom));
  background: var(--m-tab-bar-bg);
  border-top: 1px solid var(--m-border);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
}
.submit-btn {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  height: 52px;
  border: none;
  border-radius: var(--m-radius-md);
  background: var(--m-bubble-user-bg);
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 0.01em;
  cursor: pointer;
  box-shadow: var(--m-shadow-soft);
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.18s ease, box-shadow 0.18s ease, opacity 0.18s ease;
}
.submit-btn:active { transform: scale(0.985); }
.submit-btn:disabled {
  opacity: 0.5;
  box-shadow: none;
  cursor: not-allowed;
}
.spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}

/* ---------- Shared ---------- */
.ic {
  width: 20px;
  height: 20px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

@keyframes fade-in-up {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes spin { to { transform: rotate(360deg); } }

/* 模型选择器样式已迁移至 MobileModelPicker 组件（单一权威） */

@media (prefers-reduced-motion: reduce) {
  .sec { animation: none; opacity: 1; }
  .submit-btn:active { transform: none; }
}
</style>
