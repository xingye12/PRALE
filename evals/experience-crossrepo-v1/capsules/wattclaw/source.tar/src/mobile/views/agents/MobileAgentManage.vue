<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NSpin } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useModelProviders } from '@/composables/useModelProviders'
import AgentCard from '@/mobile/views/agents/AgentCard.vue'

const router = useRouter()
const emit = defineEmits<{ (e: 'goMarket'): void }>()
const { t } = useI18n()
const agentTeamStore = useAgentTeamStore()
// 共享只读数据(provider 列表)在管理视图加载一次,卡片纯消费
const { fetchProviders } = useModelProviders()

const loading = ref(true)
const agents = computed(() => agentTeamStore.agentList)

onMounted(async () => {
  void fetchProviders()
  await agentTeamStore.fetchAgents()
  loading.value = false
})
</script>

<template>
  <div class="manage-view">
    <div class="manage-header">
      <span class="manage-count">
        {{ t('pages.mobile.agents.manageCount', { n: agents.length }) }}
      </span>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="loading-state">
      <NSpin size="medium" />
    </div>

    <!-- Empty -->
    <div v-else-if="agents.length === 0" class="empty-state">
      <p class="empty-text">{{ t('pages.mobile.agents.noAgents') }}</p>
      <button class="empty-btn" @click="emit('goMarket')">
        {{ t('pages.mobile.agents.manageEmptyAction') }}
      </button>
    </div>

    <!-- Single-column list -->
    <div v-else class="agent-list">
      <button
        v-for="(agent, idx) in agents"
        :key="agent.id"
        class="agent-item"
        :style="{ animationDelay: `${Math.min(idx, 8) * 50}ms` }"
        @click="router.push(`/m/agents/${agent.id}`)"
      >
        <AgentCard :agent="agent" />
      </button>
    </div>
  </div>
</template>

<style scoped>
.manage-view {
  padding: 0;
}

.manage-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 0 14px;
}

.manage-count {
  font-size: 13px;
  font-weight: 500;
  color: var(--m-text-hint);
}

.loading-state {
  display: flex;
  justify-content: center;
  padding: 80px 0;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 80px 24px;
  color: var(--m-text-hint);
  text-align: center;
}

.empty-text {
  margin: 0 0 16px;
  font-size: 14px;
}

.empty-btn {
  padding: 10px 24px;
  background: var(--m-primary);
  color: #fff;
  border: none;
  border-radius: var(--m-radius-md);
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.agent-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.agent-item {
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  text-align: left;
  -webkit-tap-highlight-color: transparent;
  opacity: 0;
  animation: fade-in-up 0.4s ease forwards;
}

.agent-item :deep(.agent-card) {
  transition: transform 0.15s ease;
}

.agent-item:active :deep(.agent-card) {
  transform: scale(0.985);
}

@keyframes fade-in-up {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .agent-item {
    animation: none;
    opacity: 1;
  }
}
</style>
