<script setup lang="ts">
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  CATEGORY_CONFIGS,
  FEATURED_TEMPLATE_IDS,
  getAllCategories,
  getAllTemplates,
} from '@/config/agent-templates'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { categoryAccent } from '@/mobile/utils/category-accent'
import { useAgentTeamStore } from '@/stores/agent-team'
import MarketTemplateCard from './MarketTemplateCard.vue'

const emit = defineEmits<{ (e: 'create', template: AgentTemplate): void }>()
const { t } = useI18n()

const agentTeamStore = useAgentTeamStore()
// 热门 Top3:应用级常驻(MobileTabLayout 进入移动端即加载),页面同步读,无切页空白
const hot = computed(() => agentTeamStore.hotTemplates)

const activeCategory = ref('featured')
const templates = ref<AgentTemplate[]>(getAllTemplates())

// 分类逻辑与网页端 AgentMarketPage 完全一致(单一权威,保证两端分类同步)
const categories = computed(() => {
  const builtIns = CATEGORY_CONFIGS.map((config) => ({ id: config.id, name: t(config.key) }))
  const dynamic = getAllCategories().map((c) => ({ id: c.id, name: c.name }))
  const result: Array<{ id: string; name: string }> = [...builtIns, ...dynamic]
  const firstId = result[0]?.id
  if (firstId) result[0] = { id: firstId, name: t('common.featured') }
  return result
})

const filteredTemplates = computed(() => {
  let list = templates.value.length ? templates.value : getAllTemplates()
  if (activeCategory.value === 'featured') {
    list = list.filter((tmpl) => FEATURED_TEMPLATE_IDS.has(tmpl.id))
  } else if (activeCategory.value !== 'all') {
    list = list.filter(
      (tmpl) => tmpl.category === categories.value.find((c) => c.id === activeCategory.value)?.name,
    )
  }
  return list
})

function avatarOf(tpl: AgentTemplate) {
  return resolveAgentAvatar(tpl.id, tpl.avatar || '🤖')
}
function accentOf(category: string) {
  return categoryAccent(category || '')
}
</script>

<template>
  <div class="market-view">
    <!-- 推荐位:热门 Top3 竖排榜单(左大号排名独立列,清晰不被挡) -->
    <section v-if="hot.length" class="recommend fade-up" style="--d: 60ms">
      <button
        v-for="(tpl, idx) in hot"
        :key="tpl.id"
        class="rank-card"
        @click="emit('create', tpl)"
      >
        <span class="rank-glow" :style="{ background: accentOf(tpl.category).glow }" />
        <span class="rank-num" :class="`rank-${idx + 1}`">{{ idx + 1 }}</span>
        <span
          class="rank-avatar"
          :class="{ image: isImageAvatar(avatarOf(tpl)) }"
          :style="!isImageAvatar(avatarOf(tpl)) ? { background: accentOf(tpl.category).avatarTint } : undefined"
        >
          <img v-if="isImageAvatar(avatarOf(tpl))" v-avatar-fallback :src="avatarOf(tpl)" :alt="tpl.name" class="rank-avatar-img">
          <span v-else>{{ avatarOf(tpl) }}</span>
        </span>
        <div class="rank-meta">
          <span class="rank-hot">🔥 {{ t('pages.mobile.agents.hot') }}</span>
          <h3 class="rank-name">{{ tpl.name }}</h3>
          <p class="rank-desc">{{ tpl.tagline || tpl.description }}</p>
        </div>
        <span class="rank-add">
          <svg viewBox="0 0 24 24" class="ic"><path d="M12 5v14M5 12h14" /></svg>
        </span>
      </button>
    </section>

    <!-- 分类条:横向滑动(与网页端一致) -->
    <div class="cat-bar fade-up" style="--d: 120ms">
      <button
        v-for="cat in categories"
        :key="cat.id"
        class="cat-chip"
        :class="{ active: activeCategory === cat.id }"
        @click="activeCategory = cat.id"
      >
        {{ cat.name }}
      </button>
    </div>

    <!-- 模板网格:2 列 -->
    <div v-if="filteredTemplates.length" class="tpl-grid fade-up" style="--d: 180ms">
      <MarketTemplateCard
        v-for="tpl in filteredTemplates"
        :key="tpl.id"
        :template="tpl"
        @create="emit('create', $event)"
      />
    </div>
    <p v-else class="grid-empty">{{ t('pages.mobile.agents.noTemplates') }}</p>
  </div>
</template>

<style scoped>
.market-view {
  padding: 0;
}

/* ===== 推荐位:竖排榜单(每行一张,左侧大号排名独立列) ===== */
.recommend {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 0 0 14px;
}
.rank-card {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border: 1px solid var(--m-border);
  border-radius: 16px;
  background: var(--m-bg-input);
  box-shadow: var(--m-shadow-soft);
  text-align: left;
  cursor: pointer;
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.18s ease;
}
.rank-card:active {
  transform: scale(0.98);
}
.rank-glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: 0.5;
}
/* 左侧大号排名:独立列,绝不与头像重叠 → 排名永不被挡 */
.rank-num {
  position: relative;
  flex: 0 0 auto;
  width: 30px;
  text-align: center;
  font-size: 26px;
  font-weight: 800;
  font-style: italic;
  line-height: 1;
  color: #ef4444;
  font-family: 'Georgia', 'Times New Roman', serif;
}
.rank-num.rank-1 {
  color: #f59e0b;
}
.rank-num.rank-2 {
  color: #94a3b8;
}
.rank-num.rank-3 {
  color: #b45309;
}
.rank-avatar {
  position: relative;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  border-radius: 14px;
  color: var(--m-primary);
  font-size: 22px;
  line-height: 1;
  overflow: hidden;
  box-shadow: 0 6px 14px rgba(15, 23, 42, 0.12);
}
.rank-avatar.image {
  background: #fff;
}
.rank-avatar-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.rank-meta {
  position: relative;
  flex: 1 1 auto;
  min-width: 0;
}
.rank-hot {
  font-size: 10px;
  font-weight: 700;
  color: #ef4444;
}
.rank-name {
  margin: 2px 0;
  font-size: 14px;
  font-weight: 700;
  color: var(--m-text-primary);
  line-height: 1.3;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.rank-desc {
  margin: 0;
  font-size: 11.5px;
  line-height: 1.4;
  color: var(--m-text-secondary);
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.rank-add {
  position: relative;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--m-primary);
  color: #fff;
  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.35);
}
.rank-add .ic {
  width: 16px;
  height: 16px;
}

/* ===== 分类条 ===== */
.cat-bar {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  padding: 4px 16px 14px;
  margin: 0 -16px;
  scrollbar-width: none;
}
.cat-bar::-webkit-scrollbar {
  display: none;
}
.cat-chip {
  flex: 0 0 auto;
  padding: 7px 16px;
  border: 1.5px solid var(--m-border);
  border-radius: 999px;
  background: var(--m-bg-input);
  color: var(--m-text-secondary);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  -webkit-tap-highlight-color: transparent;
  transition: all 0.18s ease;
}
.cat-chip.active {
  border-color: var(--m-primary);
  color: #fff;
  background: var(--m-primary);
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
}

/* ===== 模板网格 ===== */
.tpl-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}
.grid-empty {
  text-align: center;
  padding: 60px 0;
  color: var(--m-text-hint);
  font-size: 14px;
}

.ic {
  fill: none;
  stroke: currentColor;
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* ===== 入场动画（与其他移动端 tab 页统一） ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.55s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .fade-up { animation: none; opacity: 1; }
}
</style>
