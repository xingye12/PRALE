<script setup lang="ts">
import { ref } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import type { AgentTemplate } from '@/api/types'
import { useAgentTeamStore } from '@/stores/agent-team'
import MobileAgentMarket from './MobileAgentMarket.vue'
import MobileAgentManage from './MobileAgentManage.vue'
import MobileAgentCreateSheet from './MobileAgentCreateSheet.vue'

const { t } = useI18n()
const agentTeamStore = useAgentTeamStore()

// 默认进入员工市场（发现优先）；员工管理为当前 MobileAgentManage（原列表）
// 删除等操作后通过 query.tab=manage 落回员工管理
const route = useRoute()
const tab = ref<'market' | 'manage'>(route.query.tab === 'manage' ? 'manage' : 'market')
const createShow = ref(false)
const createTemplate = ref<AgentTemplate | null>(null)

function openCreate(template: AgentTemplate) {
  createTemplate.value = template
  createShow.value = true
}

// 创建成功：关闭弹窗 → 刷新管理列表 → 切到员工管理查看新建员工
async function onCreated() {
  createShow.value = false
  await agentTeamStore.fetchAgents()
  tab.value = 'manage'
}
</script>

<template>
  <div class="mobile-page agents-page">
    <!-- 顶部双 Tab -->
    <div class="tab-bar fade-up" style="--d: 0ms">
      <button class="tab" :class="{ active: tab === 'market' }" @click="tab = 'market'">
        {{ t('pages.mobile.agents.tabMarket') }}
      </button>
      <button class="tab" :class="{ active: tab === 'manage' }" @click="tab = 'manage'">
        {{ t('pages.mobile.agents.tabManage') }}
      </button>
      <span class="tab-indicator" :class="tab" />
    </div>

    <!-- 内容区 -->
    <div class="tab-content">
      <MobileAgentMarket v-if="tab === 'market'" @create="openCreate" />
      <MobileAgentManage v-else @go-market="tab = 'market'" />
    </div>

    <!-- 创建弹窗（模板预填 + 创建中进度） -->
    <MobileAgentCreateSheet
      v-model:show="createShow"
      :template="createTemplate"
      @created="onCreated"
    />
  </div>
</template>

<style scoped>
.agents-page {
  padding: 0 16px calc(20px + env(safe-area-inset-bottom));
}

.tab-bar {
  position: relative;
  display: flex;
  padding: 14px 0 12px;
  margin-bottom: 4px;
}
.tab {
  position: relative;
  flex: 1;
  padding: 6px 0;
  background: none;
  border: none;
  color: var(--m-text-hint);
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: color 0.22s ease;
  z-index: 1;
}
.tab.active {
  color: var(--m-text-primary);
}
.tab-indicator {
  position: absolute;
  bottom: 8px;
  left: 0;
  width: 50%;
  height: 2.5px;
  transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1);
}
.tab-indicator.manage {
  transform: translateX(100%);
}
.tab-indicator::after {
  content: '';
  display: block;
  width: 28px;
  height: 2.5px;
  margin: 0 auto;
  border-radius: 2px;
  background: linear-gradient(90deg, var(--m-primary), #7c3aed);
}

.tab-content {
  min-height: 200px;
}

/* ===== 入场动画（与其他移动端 tab 页统一） ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.55s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .fade-up { animation: none; opacity: 1; }
}
</style>
