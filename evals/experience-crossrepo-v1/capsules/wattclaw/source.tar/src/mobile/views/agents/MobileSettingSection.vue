<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { renderMarkdown } from '@/utils/render-markdown'
import { AGENT_SETTING_FILES, AGENT_SETTING_BY_FILE } from '@/config/agent-settings'
import MobileMarkdownEditorOverlay from '@/mobile/components/MobileMarkdownEditorOverlay.vue'

const props = defineProps<{
  /** create=只读预览（无编辑按钮）；edit=可预览可编辑 */
  mode: 'create' | 'edit'
  /** key=文件名(SOUL.md...)，value=内容。create 态来自模板预填，edit 态来自 Gateway */
  files: Record<string, string>
  /** edit 态：设定文件加载失败时为 true，顶部显示错误条 */
  loadError?: boolean
}>()
const emit = defineEmits<{
  (e: 'edit', payload: { file: string; content: string }): void
}>()

const { t } = useI18n()
/** 当前展开的文件名（空=全部折叠） */
const expanded = ref<string>('')
/** 正在编辑的文件（非空则覆盖层可见） */
const editing = ref<{ file: string; content: string } | null>(null)

function toggle(file: string) {
  expanded.value = expanded.value === file ? '' : file
}
function startEdit(file: string) {
  editing.value = { file, content: props.files[file] || '' }
}
function onSave(content: string) {
  if (editing.value) emit('edit', { file: editing.value.file, content })
  editing.value = null
}
function onCancel() {
  editing.value = null
}
const editingTitle = computed(() =>
  editing.value ? AGENT_SETTING_BY_FILE[editing.value.file]?.label || editing.value.file : '',
)
const visibleSettings = computed(() =>
  AGENT_SETTING_FILES.filter((s) => props.mode === 'edit' || Object.prototype.hasOwnProperty.call(props.files, s.file)),
)
</script>

<template>
  <div class="setting-list">
    <p v-if="loadError" class="set-load-error">{{ t('pages.mobile.agents.loadFailedHint') }}</p>
    <div
      v-for="s in visibleSettings"
      :key="s.file"
      class="set-card"
      :class="{ expanded: expanded === s.file }"
    >
      <button class="set-head" @click="toggle(s.file)">
        <span class="set-icon">{{ s.label.charAt(0) }}</span>
        <span class="set-meta">
          <span class="set-label">{{ s.label }}</span>
          <span class="set-desc">{{ s.desc }}</span>
        </span>
        <svg
          class="set-arrow"
          :class="{ rotated: expanded === s.file }"
          viewBox="0 0 24 24"
        ><path d="M6 9l6 6 6-6" /></svg>
      </button>

      <div v-if="expanded === s.file" class="set-body">
        <!-- 操作条置顶：编辑按钮无需滚到底 -->
        <div v-if="mode === 'edit'" class="set-action">
          <button class="set-edit-btn" @click="startEdit(s.file)">
            <svg viewBox="0 0 24 24" class="ic"><path d="M4 20h4l10-10-4-4L4 16v4z" /></svg>
            {{ t('pages.mobile.agents.editAction') }}
          </button>
        </div>
        <div class="set-preview" v-html="renderMarkdown(files[s.file] || '')" />
        <p v-if="mode !== 'edit'" class="set-readonly-hint">{{ t('pages.mobile.agents.createReadonlyHint') }}</p>
      </div>
    </div>

    <MobileMarkdownEditorOverlay
      :visible="!!editing"
      :title="editingTitle"
      :value="editing?.content || ''"
      @save="onSave"
      @cancel="onCancel"
    />
  </div>
</template>

<style scoped>
.setting-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.set-card {
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-md);
  background: var(--m-bg-input);
  overflow: hidden;
  transition: border-color 0.18s ease;
}
.set-card.expanded { border-color: var(--m-primary); }
.set-head {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border: none;
  background: transparent;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.set-icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  flex-shrink: 0;
  border-radius: 10px;
  background: var(--m-primary-light);
  color: var(--m-primary);
  font-size: 14px;
  font-weight: 700;
}
.set-meta {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.set-label {
  font-size: 14px;
  font-weight: 600;
  color: var(--m-text-primary);
}
.set-desc {
  font-size: 11px;
  line-height: 1.4;
  color: var(--m-text-hint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.set-arrow {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  color: var(--m-text-hint);
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: transform 0.2s ease;
}
.set-arrow.rotated { transform: rotate(180deg); }

.set-body {
  padding: 0 14px 14px;
  border-top: 1px dashed var(--m-border);
  min-width: 0;
}
/* 操作条：置顶，编辑按钮无需滚到底 */
.set-action {
  display: flex;
  justify-content: flex-end;
  padding: 10px 0 4px;
}
.set-preview {
  margin-top: 8px;
  padding: 10px 12px;
  font-size: 13px;
  line-height: 1.7;
  color: var(--m-text-primary);
  word-break: break-word;
  overflow-wrap: anywhere;
  background: var(--m-bg-secondary, rgba(0,0,0,0.03));
  border-radius: 10px;
  min-width: 0;
  max-width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.set-preview :deep(h1),
.set-preview :deep(h2),
.set-preview :deep(h3) { margin: 10px 0 6px; font-weight: 700; }
.set-preview :deep(ul) { padding-left: 18px; margin: 6px 0; }
/* 代码块：内部横向滚动，绝不撑破屏幕宽度（修横向溢出） */
.set-preview :deep(pre) {
  max-width: 100%;
  overflow-x: auto;
  margin: 8px 0;
  padding: 10px 12px;
  background: var(--m-bg-secondary, rgba(0,0,0,0.06));
  border-radius: 8px;
  font-size: 12px;
}
.set-preview :deep(pre) code { background: none; padding: 0; }
.set-preview :deep(:not(pre) > code) {
  background: var(--m-bg-secondary, rgba(0,0,0,0.05));
  padding: 1px 5px;
  border-radius: 4px;
  font-family: 'SF Mono', monospace;
  font-size: 12px;
}
.set-edit-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 16px;
  border: none;
  border-radius: 999px;
  background: var(--m-primary);
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 10px rgba(37, 99, 235, 0.25);
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease;
}
.set-edit-btn:active { transform: scale(0.96); }
.set-edit-btn .ic { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
.set-readonly-hint {
  margin: 8px 0 0;
  font-size: 11px;
  color: var(--m-text-hint);
}
.set-load-error {
  margin: 0 0 4px;
  padding: 8px 12px;
  border-radius: var(--m-radius-md);
  background: rgba(239, 68, 68, 0.08);
  color: #ef4444;
  font-size: 12px;
  line-height: 1.5;
}
</style>
