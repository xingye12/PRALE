<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { getAllTemplates, FEATURED_TEMPLATE_IDS } from '@/config/agent-templates'
import type { AgentTemplate } from '@/api/types'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { categoryAccent } from '@/mobile/utils/category-accent'

defineProps<{ selectedId: string }>()
const emit = defineEmits<{
  (e: 'select', template: AgentTemplate): void
}>()

const { t } = useI18n()
const tab = ref<'featured' | 'all'>('featured')
const templates = computed(() => getAllTemplates())

const filtered = computed(() =>
  tab.value === 'featured'
    ? templates.value.filter((tpl) => FEATURED_TEMPLATE_IDS.has(tpl.id))
    : templates.value,
)

function avatarOf(tpl: AgentTemplate): string {
  return resolveAgentAvatar(tpl.id, tpl.avatar || '🤖')
}
function accentOf(category: string) {
  return categoryAccent(category || '')
}
</script>

<template>
  <div class="picker">
    <div class="tabs">
      <button
        class="tab"
        :class="{ active: tab === 'featured' }"
        @click="tab = 'featured'"
      >
        {{ t('common.featured') }}
      </button>
      <button
        class="tab"
        :class="{ active: tab === 'all' }"
        @click="tab = 'all'"
      >
        {{ t('common.all') }}
      </button>
    </div>

    <div class="tpl-grid">
      <button
        v-for="tpl in filtered"
        :key="tpl.id"
        class="tpl"
        :class="{ selected: selectedId === tpl.id }"
        @click="emit('select', tpl)"
      >
        <span class="tpl-accent" :style="{ background: accentOf(tpl.category).bar }" />
        <span
          class="tpl-avatar"
          :class="{ image: isImageAvatar(avatarOf(tpl)) }"
          :style="!isImageAvatar(avatarOf(tpl)) ? { background: accentOf(tpl.category).avatarTint } : undefined"
        >
          <img
            v-if="isImageAvatar(avatarOf(tpl))"
            v-avatar-fallback
            :src="avatarOf(tpl)"
            :alt="tpl.name"
            class="tpl-avatar-img"
          >
          <span v-else>{{ avatarOf(tpl) }}</span>
        </span>
        <span class="tpl-name">{{ tpl.name }}</span>
        <span class="tpl-check" aria-hidden="true">
          <svg viewBox="0 0 24 24" class="ic"><path d="M5 12l4 4 10-10" /></svg>
        </span>
      </button>
    </div>
  </div>
</template>

<style scoped>
.tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}
.tab {
  padding: 6px 16px;
  border: 1.5px solid var(--m-border);
  border-radius: 999px;
  background: var(--m-bg-input);
  color: var(--m-text-secondary);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: all 0.18s ease;
}
.tab.active {
  border-color: var(--m-primary);
  color: var(--m-primary);
  background: var(--m-primary-light);
}

.tpl-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}
.tpl {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 12px 4px 9px;
  background: var(--m-bg-input);
  border: 1.5px solid var(--m-border);
  border-radius: var(--m-radius-md);
  cursor: pointer;
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
}
.tpl:active { transform: scale(0.95); }
.tpl-accent {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2.5px;
}
.tpl-avatar {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 14px;
  color: var(--m-primary);
  font-size: 22px;
  line-height: 1;
  overflow: hidden;
  box-shadow: 0 6px 14px rgba(15, 23, 42, 0.08);
}
.tpl-avatar.image { background: #fff; }
.tpl-avatar-img { width: 100%; height: 100%; object-fit: cover; }
.tpl-name {
  font-size: 11px;
  font-weight: 500;
  color: var(--m-text-secondary);
  text-align: center;
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tpl-check {
  position: absolute;
  top: 6px; right: 6px;
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--m-primary);
  color: #fff;
  opacity: 0;
  transform: scale(0.4);
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.tpl-check .ic { width: 11px; height: 11px; }
.tpl.selected {
  border-color: var(--m-primary);
  background: var(--m-primary-light);
  box-shadow: var(--m-shadow-soft);
}
.tpl.selected .tpl-check { opacity: 1; transform: scale(1); }
.tpl.selected .tpl-name { color: var(--m-primary); font-weight: 600; }

.ic {
  width: 20px;
  height: 20px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
</style>
