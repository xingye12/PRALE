<script setup lang="ts">
import { computed, ref } from 'vue'
import { useChatStore } from '@/stores/chat'
import { useI18n } from 'vue-i18n'

const props = defineProps<{ agentId: string }>()
const chatStore = useChatStore()
const { t } = useI18n()

const expanded = ref(false)

const status = computed(() => chatStore.agentStatuses.get(props.agentId) || null)
const steps = computed(() => chatStore.agentSteps.get(props.agentId) || [])
const tool = computed(() => chatStore.toolProgress.get(props.agentId) || null)

const visible = computed(() => {
  const phase = status.value?.phase
  if (!phase) return false
  return !['idle', 'done', 'aborted', 'error'].includes(phase)
})

const currentLabel = computed(() => {
  const last = steps.value[steps.value.length - 1]
  return last?.label || t('pages.mobile.chat.thinking')
})
</script>

<template>
  <div v-if="visible" class="agent-status-block">
    <div class="status-line">
      <span class="status-dot" :class="status?.phase" />
      <span class="status-label">{{ currentLabel }}</span>
    </div>

    <div v-if="tool" class="tool-block">
      <button class="tool-header" type="button" @click="expanded = !expanded">
        <span class="tool-icon">🔧</span>
        <span class="tool-name">{{ tool.name }}</span>
        <span class="tool-arrow">{{ expanded ? '▾' : '▸' }}</span>
      </button>
      <div v-if="expanded" class="tool-detail">
        <div v-if="tool.argsPreview" class="tool-section">
          <div class="tool-section-label">{{ t('pages.mobile.chat.toolArgs') }}</div>
          <pre class="tool-pre">{{ tool.argsPreview }}</pre>
        </div>
        <div v-if="tool.resultPreview" class="tool-section">
          <div class="tool-section-label">{{ t('pages.mobile.chat.toolResult') }}</div>
          <pre class="tool-pre" :class="{ error: tool.isError }">{{ tool.resultPreview }}</pre>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.agent-status-block {
  align-self: flex-start;
  max-width: 88%;
  padding: 8px 12px;
  border-radius: 16px;
  background: color-mix(in srgb, var(--m-bg-input) 86%, transparent);
  border: 1px solid color-mix(in srgb, var(--m-border) 58%, transparent);
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.status-line {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--m-text-hint);
  flex-shrink: 0;
  animation: status-pulse 1.4s ease-in-out infinite;
}

.status-dot.tool { background: var(--m-primary); }
.status-dot.repeating { background: #10b981; }
.status-dot.error { background: var(--m-danger); animation: none; }

.status-label {
  font-size: 13px;
  color: var(--m-text-secondary);
  line-height: 1.4;
}

.tool-block {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.tool-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 0;
  background: transparent;
  border: none;
  color: var(--m-text-primary);
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}

.tool-name {
  flex: 1;
  min-width: 0;
  font-weight: 600;
}

.tool-arrow {
  color: var(--m-text-hint);
  font-size: 11px;
}

.tool-detail {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-top: 2px;
}

.tool-section-label {
  font-size: 11px;
  color: var(--m-text-hint);
  margin-bottom: 2px;
}

.tool-pre {
  margin: 0;
  padding: 6px 8px;
  max-height: 180px;
  overflow: auto;
  background: rgba(0, 0, 0, 0.04);
  border-radius: 8px;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  font-size: 11px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
}

.tool-pre.error {
  background: rgba(255, 77, 79, 0.08);
  color: var(--m-danger);
}

@keyframes status-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}
</style>
