<script setup lang="ts">
import { ref, computed, nextTick, onMounted, onUnmounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import type { ChatAttachment } from '@/api/types/chat-contract'
import { useMobileVoiceInput } from '@/mobile/composables/useMobileVoiceInput'
import VoiceRecordingPanel from './VoiceRecordingPanel.vue'

interface Props {
  sending: boolean
  busy?: boolean
  prefillText?: string
  modelLabel?: string
  modelIcon?: string
}

interface PendingAttachment {
  id: string
  name: string
  attachment: ChatAttachment
}

const props = defineProps<Props>()
const emit = defineEmits<{ send: [text: string, attachments?: ChatAttachment[]]; abort: []; openModelSheet: [] }>()
const { t } = useI18n()
const router = useRouter()

const voice = useMobileVoiceInput()
const {
  status: voiceStatus,
  voiceMode,
  enabled: voiceEnabled,
  volume: voiceVolume,
  duration: voiceDuration,
  draftText: voiceDraftText,
  dragZone: voiceDragZone,
  analyser: voiceAnalyser,
} = voice
const showVoiceOverlay = computed(() => voiceStatus.value !== 'idle')

const DRAG_THRESHOLD = 44 // 进入左上/右上手势区的最小位移(px)
let voiceStartX = 0
let voiceStartY = 0

function appendInput(text: string) {
  const cur = inputText.value
  if (!cur) {
    inputText.value = text
  } else {
    inputText.value = `${cur.replace(/\s+$/, '')} ${text}`
  }
}

function onVoiceTouchStart(e: TouchEvent) {
  e.preventDefault()
  const t = e.touches[0]
  if (t) { voiceStartX = t.clientX; voiceStartY = t.clientY }
  void voice.start()
  window.addEventListener('touchmove', onVoiceTouchMove, { passive: false })
  window.addEventListener('touchend', onVoiceTouchEnd)
  window.addEventListener('touchcancel', onVoiceTouchCancel)
}

function onVoiceTouchMove(e: TouchEvent) {
  e.preventDefault()
  const t = e.touches[0]
  if (!t) return
  const dx = t.clientX - voiceStartX
  const dy = t.clientY - voiceStartY
  voice.setDragZone(voice.resolveDragZone(dx, dy, DRAG_THRESHOLD))
}

async function onVoiceTouchEnd() {
  removeVoiceListeners()
  const r = await voice.finish()
  if (!r || r.mode === 'cancel') return
  if (!r.text.trim()) return // H5 空转写不发
  appendInput(r.text)
  if (r.mode === 'send') {
    handleSend()
  } else {
    // 转文字(keep):切回文本模式,输入框显示识别文字供核对/编辑
    voiceMode.value = false
  }
}

function onVoiceTouchCancel() {
  removeVoiceListeners()
  voice.cancel()
}

function removeVoiceListeners() {
  window.removeEventListener('touchmove', onVoiceTouchMove)
  window.removeEventListener('touchend', onVoiceTouchEnd)
  window.removeEventListener('touchcancel', onVoiceTouchCancel)
}

const inputText = ref('')
const textareaRef = ref<HTMLTextAreaElement | null>(null)

// textarea 自适应高度：单行起，超宽自动换行变高，封顶 120px 后内部滚动（对齐微信）
function autoResizeTextarea() {
  const el = textareaRef.value
  if (!el) return
  el.style.height = 'auto'
  const h = Math.min(el.scrollHeight, 120)
  el.style.height = `${h}px`
}
watch(inputText, () => { void nextTick(autoResizeTextarea) })
// 语音→文本切换：textarea 重新挂载，按当前 inputText 重算高度
watch(voiceMode, (v) => { if (!v) void nextTick(autoResizeTextarea) })

watch(
  () => props.prefillText,
  (v) => {
    if (v) inputText.value = v
  },
  { immediate: true },
)

const fileInput = ref<HTMLInputElement | null>(null)
const pendingAttachments = ref<PendingAttachment[]>([])

const showExtMenu = ref(false)
const webSearchEnabled = ref(false)
const triggerRef = ref<HTMLElement | null>(null)
const menuRef = ref<HTMLElement | null>(null)

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(reader.error || new Error('Failed to read file'))
    reader.readAsDataURL(file)
  })
}

function stripDataUrlPrefix(dataUrl: string): string {
  const commaIndex = dataUrl.indexOf(',')
  return commaIndex >= 0 ? dataUrl.slice(commaIndex + 1) : dataUrl
}

async function handleFileChange(event: Event) {
  const input = event.target as HTMLInputElement
  const files = Array.from(input.files || [])
  if (files.length === 0) return

  const nextAttachments = await Promise.all(
    files.map(async (file) => {
      const dataUrl = await readFileAsDataUrl(file)
      return {
        id: `${file.name}-${file.size}-${file.lastModified}`,
        name: file.name,
        attachment: {
          type: file.type.startsWith('image/') ? 'image' : 'file',
          mimeType: file.type || 'application/octet-stream',
          fileName: file.name,
          content: stripDataUrlPrefix(dataUrl),
        },
      }
    }),
  )

  pendingAttachments.value = [...pendingAttachments.value, ...nextAttachments]
  input.value = ''
}

function removeAttachment(id: string) {
  pendingAttachments.value = pendingAttachments.value.filter((item) => item.id !== id)
}

function handleSend() {
  const text = inputText.value.trim()
  const attachments = pendingAttachments.value.map((item) => item.attachment)
  if (!text && attachments.length === 0) return
  const payload = webSearchEnabled.value && text ? `【联网搜索】${text}` : text
  emit('send', payload, attachments.length > 0 ? attachments : undefined)
  inputText.value = ''
  pendingAttachments.value = []
}

function handleKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    handleSend()
  }
}

function toggleExtMenu() {
  showExtMenu.value = !showExtMenu.value
}

function openCollaborationMode() {
  showExtMenu.value = false
  void router.push({ name: 'WattClawCollaboration' })
}

function closeExtMenu() {
  showExtMenu.value = false
}

function toggleWebSearch() {
  webSearchEnabled.value = !webSearchEnabled.value
}

function onPickAttachment() {
  closeExtMenu()
  void nextTick(() => fileInput.value?.click())
}

function onDocumentClick(e: MouseEvent) {
  if (!showExtMenu.value) return
  const target = e.target as Node | null
  if (!target) return
  if (menuRef.value?.contains(target)) return
  if (triggerRef.value?.contains(target)) return
  closeExtMenu()
}

function onDocumentKeydown(e: KeyboardEvent) {
  if (e.key === 'Escape' && showExtMenu.value) {
    closeExtMenu()
  }
}

onMounted(() => {
  document.addEventListener('click', onDocumentClick, true)
  document.addEventListener('keydown', onDocumentKeydown)
})

onUnmounted(() => {
  document.removeEventListener('click', onDocumentClick, true)
  document.removeEventListener('keydown', onDocumentKeydown)
  removeVoiceListeners()
})
</script>

<template>
  <div class="chat-input-bar">
    <div v-if="pendingAttachments.length" class="attachment-row">
      <button
        v-for="item in pendingAttachments"
        :key="item.id"
        class="attachment-chip"
        type="button"
        @click="removeAttachment(item.id)"
      >
        <span class="attachment-icon">📎</span>
        <span class="attachment-name">{{ item.name }}</span>
        <span class="attachment-remove">×</span>
      </button>
    </div>

    <div v-if="modelLabel" class="model-row">
      <button class="model-pill" type="button" @click="emit('openModelSheet')">
        <img v-if="modelIcon" :src="modelIcon" class="model-pill__icon" alt="">
        <span v-else class="model-pill__dot"></span>
        <span class="model-pill__label">{{ modelLabel }}</span>
        <span class="model-pill__arrow">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
        </span>
      </button>
    </div>

    <div class="input-pill-wrapper">
      <div class="left-actions-group">
        <button
          v-if="voiceEnabled"
          type="button"
          class="icon-btn"
          :aria-label="voiceMode ? t('pages.mobile.chat.keyboardToggle') : t('pages.mobile.chat.voiceToggle')"
          :disabled="sending"
          @click="voice.toggleVoiceMode()"
        >
          <svg v-if="!voiceMode" viewBox="0 0 24 24"><path d="M5 12h.01"/><path d="M10 8a6 6 0 0 1 0 8"/><path d="M15 4a12 12 0 0 1 0 16"/></svg>
          <svg v-else viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2" ry="2"/><path d="M6 8h.01"/><path d="M10 8h.01"/><path d="M14 8h.01"/><path d="M18 8h.01"/><path d="M6 12h.01"/><path d="M10 12h.01"/><path d="M14 12h.01"/><path d="M18 12h.01"/><path d="M10 16h4"/></svg>
        </button>
        <button
          ref="triggerRef"
          type="button"
          class="icon-btn"
          :class="{ active: showExtMenu || webSearchEnabled }"
          :aria-label="t('pages.mobile.chat.extensions')"
          :disabled="sending"
          @click="toggleExtMenu"
        >
          <span v-if="webSearchEnabled" class="ext-badge" />
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v8"/><path d="M8 12h8"/></svg>
        </button>
      </div>

      <div class="center-input-slot">
        <textarea
          v-if="!voiceMode"
          ref="textareaRef"
          v-model="inputText"
          class="text-input-mode"
          :placeholder="t('pages.mobile.chat.inputPlaceholder')"
          :disabled="sending"
          rows="1"
          @keydown="handleKeydown"
        />
        <template v-else>
          <div
            class="voice-record-mode"
            :class="{ 'is-recording': showVoiceOverlay }"
            @touchstart="onVoiceTouchStart"
          >
            {{ showVoiceOverlay ? t('pages.mobile.chat.releaseToSend') : t('pages.mobile.chat.holdToSpeak') }}
          </div>
          <VoiceRecordingPanel
            v-if="showVoiceOverlay"
            :status="voiceStatus"
            :volume="voiceVolume"
            :duration="voiceDuration"
            :draft-text="voiceDraftText"
            :drag-zone="voiceDragZone"
            :analyser="voiceAnalyser"
          />
        </template>
      </div>

      <button
        type="button"
        class="send-btn-circle"
        :disabled="!busy && !inputText.trim() && pendingAttachments.length === 0"
        @click="busy ? emit('abort') : handleSend()"
      >
        <svg v-if="!busy" viewBox="0 0 24 24"><path d="M12 2L3 20l9-3 9 3z"/></svg>
        <svg v-else viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
      </button>

      <input
        ref="fileInput"
        class="file-input"
        type="file"
        multiple
        @change="handleFileChange"
      >

      <div v-if="showExtMenu" ref="menuRef" class="ext-menu" @click.stop>
        <button class="ext-item" type="button" @click="onPickAttachment">
          <span class="ext-item-icon">📎</span>
          <span class="ext-item-label">{{ t('pages.mobile.chat.chooseFile') }}</span>
        </button>
        <button class="ext-item" type="button" @click="toggleWebSearch">
          <span class="ext-item-icon">🌐</span>
          <span class="ext-item-label">{{ t('pages.mobile.chat.webSearch') }}</span>
          <span class="ext-switch" :class="{ on: webSearchEnabled }">
            <span class="ext-switch-knob" />
          </span>
        </button>
        <button class="ext-item disabled" type="button" disabled @click.stop>
          <span class="ext-item-icon">📚</span>
          <span class="ext-item-label">{{ t('pages.mobile.chat.knowledgeBase') }}</span>
          <span class="ext-item-tag">{{ t('pages.mobile.chat.comingSoon') }}</span>
        </button>
        <button class="ext-item" type="button" @click="openCollaborationMode">
          <span class="ext-item-icon">🤝</span>
          <span class="ext-item-label">{{ t('pages.mobile.chat.collaborationMode') }}</span>
        </button>
      </div>
    </div>

    <div class="footer-hint">
      <svg class="footer-hint__icon" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 3l1.7 5.0L18.7 10l-5.0 1.7L12 16.7l-1.7-5.0L5.3 10l5.0-1.7L12 3z" fill="currentColor" />
      </svg>
      <span>{{ t('pages.mobile.chat.aiDisclaimer') }}</span>
    </div>
  </div>
</template>

<style scoped>
.chat-input-bar {
  flex-shrink: 0;
  width: 100%;
  box-sizing: border-box;
  padding: 10px 16px;
  padding-bottom: env(safe-area-inset-bottom, 30px);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.attachment-row {
  width: 100%;
  display: flex;
  gap: 8px;
  overflow-x: auto;
  padding: 0 2px;
}

.attachment-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 180px;
  padding: 6px 10px;
  border: 1px solid var(--m-border);
  border-radius: 999px;
  background: var(--m-bg-card);
  color: var(--m-text-secondary);
  font-size: 12px;
  white-space: nowrap;
}

.attachment-name {
  overflow: hidden;
  text-overflow: ellipsis;
}

.attachment-remove {
  color: var(--m-text-hint);
  font-weight: 700;
}

.model-row {
  width: 100%;
  display: flex;
  padding: 0 2px;
}
.model-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 200px;
  padding: 5px 12px 5px 9px;
  border: 1px solid color-mix(in srgb, var(--m-primary) 22%, var(--m-border));
  border-radius: 999px;
  background: var(--m-bg-card);
  color: var(--m-text-secondary);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.1);
  -webkit-tap-highlight-color: transparent;
}
.model-pill__icon {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
}
.model-pill__dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: linear-gradient(135deg, var(--m-primary), var(--m-accent));
  flex-shrink: 0;
}
.model-pill__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.model-pill__arrow {
  display: grid; place-items: center;
  flex-shrink: 0;
  color: var(--m-primary);
}
.model-pill__arrow svg { width: 13px; height: 13px; }

/* === 封版核心胶囊输入栏 (1:1 照搬 test.html 几何,颜色映射 CSS 变量保持暗色兼容) === */
.input-pill-wrapper {
  position: relative;
  width: 100%;
  background-color: var(--m-bg-elevated);
  border: 1px solid var(--m-border);
  border-radius: 24px;
  display: flex;
  align-items: center;
  padding: 6px 8px 6px 14px;
  box-sizing: border-box;
  gap: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
}

.left-actions-group {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.icon-btn {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  border: none;
  background: transparent;
  color: var(--m-text-secondary);
  cursor: pointer;
  transition: opacity 0.2s, color 0.2s;
  -webkit-tap-highlight-color: transparent;
}
.icon-btn:disabled { opacity: 0.4; }
.icon-btn:active { opacity: 0.5; }
.icon-btn svg {
  width: 22px;
  height: 22px;
  stroke: currentColor;
  stroke-width: 2;
  fill: none;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.icon-btn.active {
  color: var(--m-primary);
}

.ext-badge {
  position: absolute;
  top: 1px;
  right: 1px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #22c55e;
  border: 1.5px solid var(--m-bg-elevated);
}

.center-input-slot {
  flex-grow: 1;
  min-height: 36px;
  display: flex;
  align-items: center;
  position: relative;
}

.text-input-mode {
  width: 100%;
  max-height: 120px;
  background: transparent;
  border: none;
  padding: 0;
  color: var(--m-text-primary);
  font-size: 16px;
  line-height: 1.5;
  outline: none;
  box-sizing: border-box;
  resize: none;
  font-family: inherit;
  -webkit-appearance: none;
  appearance: none;
}
.text-input-mode::placeholder { color: var(--m-text-hint); }
.text-input-mode:disabled { opacity: 0.6; }
.text-input-mode:focus,
.text-input-mode:focus-visible {
  outline: none;
  box-shadow: none;
}

.voice-record-mode {
  width: 100%;
  min-height: 36px;
  background: var(--m-bg-input);
  border-radius: 18px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--m-text-secondary);
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  user-select: none;
  transition: background 0.2s, color 0.2s;
  -webkit-tap-highlight-color: transparent;
  -webkit-appearance: none;
  appearance: none;
}
.voice-record-mode:active { background: var(--m-border); }
.voice-record-mode.is-recording {
  background: color-mix(in srgb, var(--m-primary) 14%, transparent);
  color: var(--m-primary);
  font-weight: 600;
}

.send-btn-circle {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
  background: var(--m-primary);
  border: none;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #ffffff;
  cursor: pointer;
  transition: transform 0.1s, background 0.2s, opacity 0.2s;
  -webkit-tap-highlight-color: transparent;
}
.send-btn-circle:disabled { opacity: 0.4; }
.send-btn-circle:active { transform: scale(0.95); background: color-mix(in srgb, var(--m-primary) 85%, #000); }
.send-btn-circle svg {
  width: 14px;
  height: 14px;
  fill: currentColor;
  stroke: none;
}

.file-input {
  display: none;
}

.ext-menu {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 8px;
  min-width: 200px;
  padding: 4px;
  border-radius: 14px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  z-index: 20;
  animation: ext-menu-in 0.12s ease-out;
}

@keyframes ext-menu-in {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.ext-item {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 9px 10px;
  border: none;
  border-radius: 10px;
  background: transparent;
  color: var(--m-text-primary);
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}

.ext-item:active {
  background: var(--m-bg-input);
}

.ext-item.disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.ext-item-icon {
  flex-shrink: 0;
  font-size: 16px;
  line-height: 1;
}

.ext-item-label {
  flex: 1;
  min-width: 0;
}

.ext-item-tag {
  flex-shrink: 0;
  padding: 2px 6px;
  border-radius: 6px;
  background: var(--m-bg-input);
  color: var(--m-text-hint);
  font-size: 10px;
}

.ext-switch {
  position: relative;
  flex-shrink: 0;
  width: 32px;
  height: 18px;
  border-radius: 999px;
  background: var(--m-border);
  transition: background 0.15s;
}

.ext-switch.on {
  background: var(--m-primary);
}

.ext-switch-knob {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  transition: transform 0.15s;
}

.ext-switch.on .ext-switch-knob {
  transform: translateX(14px);
}

.footer-hint {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  font-size: 11px;
  color: var(--m-text-hint);
}

.footer-hint__icon {
  width: 11px;
  height: 11px;
  flex-shrink: 0;
  color: color-mix(in srgb, var(--m-primary) 55%, transparent);
}
</style>
