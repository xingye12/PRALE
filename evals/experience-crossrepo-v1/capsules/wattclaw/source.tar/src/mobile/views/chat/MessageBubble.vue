<script setup lang="ts">
import { computed } from 'vue'
import { renderMarkdown } from '@/utils/render-markdown'
import { isImageAvatar } from '@/utils/agent-avatar'
import { parseMessageContent } from '@/utils/chat-feature-prefix'
import MobileStructuredContent from './MobileStructuredContent.vue'
import type { ChatMessageContent } from '@/api/types'

interface Props {
  role: 'user' | 'assistant' | 'tool' | 'system'
  content: string
  avatar?: string
  rawContent?: ChatMessageContent[] | null
}

const props = defineProps<Props>()
const avatarIsImage = computed(() => isImageAvatar(props.avatar))
const isAssistant = computed(() => props.role === 'assistant')
const hasStructured = computed(
  () => Array.isArray(props.rawContent) && props.rawContent.length > 0
)
const renderedHtml = computed(() =>
  isAssistant.value ? renderMarkdown(props.content) : ''
)
const parsed = computed(() => parseMessageContent(props.content))
</script>

<template>
  <div class="message-bubble" :class="[`bubble-${role}`]">
    <span v-if="role === 'assistant' && avatar" class="bubble-avatar" :class="{ image: avatarIsImage }">
      <img
        v-if="avatarIsImage"
        v-avatar-fallback
        :src="avatar"
        alt="assistant"
        class="bubble-avatar-img"
      >
      <span v-else>{{ avatar }}</span>
    </span>
    <div class="bubble-content">
      <template v-if="isAssistant">
        <MobileStructuredContent v-if="hasStructured" :raw-content="rawContent!" />
        <div v-else class="bubble-text markdown-body" v-html="renderedHtml" />
      </template>
      <div v-else class="bubble-text">
        <span v-if="parsed.webSearch" class="feature-icon" title="联网搜索">🌐</span>
        <span v-if="parsed.webSearch" class="feature-text">{{ parsed.text }}</span>
        <template v-else>{{ content }}</template>
      </div>
    </div>
  </div>
</template>

<style scoped>
.message-bubble {
  display: flex;
  gap: 8px;
  max-width: 88%;
}

.bubble-user {
  align-self: flex-end;
  flex-direction: row-reverse;
  max-width: 82%;
}

.bubble-assistant {
  align-self: flex-start;
}

.bubble-system,
.bubble-tool {
  align-self: center;
  max-width: 92%;
}

.bubble-avatar {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 12px;
  background: var(--m-avatar-bg);
  color: var(--m-primary);
  font-size: 18px;
  line-height: 1;
  flex-shrink: 0;
  margin-top: 3px;
  overflow: hidden;
  box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
}

.bubble-avatar.image { background: #fff; }
.bubble-avatar-img { width: 100%; height: 100%; object-fit: cover; }

.bubble-content {
  padding: 11px 14px;
  border-radius: 20px;
  word-break: break-word;
  overflow-wrap: break-word;
  box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
}

.bubble-user .bubble-content {
  background: var(--m-bubble-user-bg);
  color: var(--m-bubble-user-text);
  border-bottom-right-radius: 7px;
}

.bubble-assistant .bubble-content {
  background: var(--m-bubble-ai-bg);
  color: var(--m-bubble-ai-text);
  border: 1px solid color-mix(in srgb, var(--m-border) 58%, transparent);
  border-bottom-left-radius: 7px;
  box-shadow: 0 8px 24px rgba(37, 99, 235, 0.08);
}

.bubble-system .bubble-content,
.bubble-tool .bubble-content {
  background: color-mix(in srgb, var(--m-bg-input) 86%, transparent);
  color: var(--m-text-hint);
  font-size: 12px;
  text-align: center;
  box-shadow: none;
}

.bubble-text {
  white-space: pre-wrap;
  font-size: 14px;
  line-height: 1.62;
}

.feature-icon {
  display: inline-block;
  margin-right: 5px;
  font-size: 14px;
  line-height: 1;
  vertical-align: -1px;
  opacity: 0.9;
}

.bubble-text :deep(pre) {
  background: rgba(0, 0, 0, 0.05);
  padding: 8px;
  border-radius: 10px;
  overflow-x: auto;
  margin: 6px 0;
  font-size: 12px;
}

.bubble-user .bubble-text :deep(pre) {
  background: rgba(255, 255, 255, 0.15);
}

.bubble-text :deep(code) {
  font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  font-size: 12px;
}

.bubble-text :deep(strong) {
  font-weight: 600;
}

.bubble-assistant .bubble-text {
  white-space: normal;
}

.bubble-text.markdown-body :deep(p) {
  margin: 0 0 8px;
}

.bubble-text.markdown-body :deep(p:last-child) {
  margin-bottom: 0;
}

.bubble-text.markdown-body :deep(h1),
.bubble-text.markdown-body :deep(h2),
.bubble-text.markdown-body :deep(h3),
.bubble-text.markdown-body :deep(h4) {
  margin: 10px 0 6px;
  font-weight: 700;
  line-height: 1.35;
}

.bubble-text.markdown-body :deep(h1) { font-size: 17px; }
.bubble-text.markdown-body :deep(h2) { font-size: 16px; }
.bubble-text.markdown-body :deep(h3) { font-size: 15px; }
.bubble-text.markdown-body :deep(h4) { font-size: 14px; }

.bubble-text.markdown-body :deep(ul),
.bubble-text.markdown-body :deep(ol) {
  margin: 4px 0 8px;
  padding-left: 20px;
}

.bubble-text.markdown-body :deep(li) {
  margin: 2px 0;
}

.bubble-text.markdown-body :deep(blockquote) {
  margin: 6px 0;
  padding: 4px 10px;
  border-left: 3px solid var(--m-border);
  color: var(--m-text-hint);
}

.bubble-text.markdown-body :deep(a) {
  color: var(--m-primary);
  word-break: break-all;
}

.bubble-text.markdown-body :deep(table) {
  border-collapse: collapse;
  margin: 6px 0;
  font-size: 12px;
}

.bubble-text.markdown-body :deep(th),
.bubble-text.markdown-body :deep(td) {
  border: 1px solid var(--m-border);
  padding: 4px 8px;
}
</style>
