<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { NButton, NDrawer, NDrawerContent, NEmpty, NSpin } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useChatStore } from '@/stores/chat'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useAuthStore } from '@/stores/auth'
import { useModelStore } from '@/stores/model'
import { useConfigStore } from '@/stores/config'
import { useSessionStore } from '@/stores/session'
import { useWebSocketStore } from '@/stores/websocket'
import WelcomeScreen from '@/mobile/views/chat/WelcomeScreen.vue'
import ChatInputBar from '@/mobile/views/chat/ChatInputBar.vue'
import MessageBubble from '@/mobile/views/chat/MessageBubble.vue'
import AgentStatusBlock from '@/mobile/views/chat/AgentStatusBlock.vue'
import { resolveAgentAvatar } from '@/utils/agent-avatar'
import type { ChatAttachment } from '@/api/types/chat-contract'
import { buildConfiguredModelRefs, resolveDefaultModelRef } from '@/views/chat/chat-token-utils'
import type { ConfiguredModelOption } from '@/views/chat/chat-token-utils'
import { getIconUrl } from '@/utils/icon-map'

const route = useRoute()
const router = useRouter()
const chatStore = useChatStore()
const agentTeamStore = useAgentTeamStore()
const authStore = useAuthStore()
const modelStore = useModelStore()
const configStore = useConfigStore()
const sessionStore = useSessionStore()
const wsStore = useWebSocketStore()
const { t } = useI18n()

const props = defineProps<{ sessionKey?: string }>()

const messagesContainer = ref<HTMLElement | null>(null)
const creating = ref(false)
const error = ref('')
const showModelSheet = ref(false)
const selectedModel = ref('')
const modelRemarksVersion = ref(0)
const modelEventCleanups: Array<() => void> = []

interface MobileModelOption {
  modelRef: string
  modelId: string
  label: string
  description?: string
  provider?: string
  remark?: string
  iconUrl?: string
  isDefault: boolean
  congested: boolean
}

function refreshLocalModelRemarks() {
  modelRemarksVersion.value += 1
}

function isUnavailableRemark(remark?: string): boolean {
  return remark?.trim() === '暂不可用'
}

const hasMessages = computed(() => chatStore.messages.length > 0)

const currentAgentId = computed(() => {
  const q = route.query.agentId
  if (typeof q === 'string' && q.trim()) return q.trim()
  const match = (chatStore.sessionKey || '').match(/^agent:([^:]+):/)
  return match?.[1] || ''
})

const currentAgent = computed(() => {
  if (!currentAgentId.value) return null
  return agentTeamStore.agentList.find(a => a.id === currentAgentId.value) || null
})

const agentBusy = computed(() => {
  const id = currentAgentId.value
  if (!id) return false
  const phase = chatStore.getOrCreateAgentStatus(id).phase
  return phase === 'sending' || phase === 'waiting' || phase === 'thinking' || phase === 'tool' || phase === 'replying' || phase === 'aborting'
})
const currentAgentAvatar = computed(() => resolveAgentAvatar(currentAgent.value?.templateId, currentAgent.value?.avatar || '🤖'))

const currentSession = computed(() =>
  sessionStore.sessions.find((session) => session.key === chatStore.sessionKey) || null,
)

const configuredModels = computed<ConfiguredModelOption[]>(() =>
  buildConfiguredModelRefs(configStore.config, modelRemarksVersion.value),
)

const defaultModelRef = computed(() =>
  resolveDefaultModelRef(configStore.config, configuredModels.value),
)

const modelOptions = computed<MobileModelOption[]>(() =>
  configuredModels.value.map((item) => {
    const info = modelStore.models.find((m) =>
      m.id === item.modelRef ||
      m.id === item.modelId ||
      (!!m.provider && `${m.provider}/${m.id}` === item.modelRef),
    )
    return {
      modelRef: item.modelRef,
      modelId: item.modelId,
      label: info?.label || item.displayName,
      description: info?.description,
      provider: info?.provider || item.providerId,
      remark: item.remark,
      iconUrl: getIconUrl(item.providerId),
      isDefault:
        item.modelRef === defaultModelRef.value || item.modelId === defaultModelRef.value,
      congested:
        modelStore.isModelCongested(item.modelRef) ||
        modelStore.isModelCongested(item.modelId),
    }
  }),
)

const activeModel = computed(() =>
  selectedModel.value || currentSession.value?.model || defaultModelRef.value,
)

const activeModelLabel = computed(() => {
  if (!activeModel.value) return t('pages.mobile.chat.defaultModel')
  const option = modelOptions.value.find((item) =>
    item.modelRef === activeModel.value || item.modelId === activeModel.value,
  )
  return option?.label || activeModel.value
})

const activeModelIcon = computed(() => {
  if (!activeModel.value) return undefined
  const option = modelOptions.value.find((item) =>
    item.modelRef === activeModel.value || item.modelId === activeModel.value,
  )
  return option?.iconUrl
})

function selectModel(modelRef: string) {
  selectedModel.value = modelRef
  showModelSheet.value = false
}

function isModelActive(model: MobileModelOption): boolean {
  return activeModel.value === model.modelRef || activeModel.value === model.modelId
}

// Route param → chat store
watch(
  () => props.sessionKey,
  async (key) => {
    if (!key) return
    // createNewSession 已 setSessionKey；route 同步触发的 watch 在 key 未变时跳过重复 setSessionKey，
    // 否则其 resetAgentStatus(idle) 会异步覆盖 sendMessage 刚设的 sending/thinking phase，思考 UI 不显示
    if (key !== chatStore.sessionKey) {
      chatStore.setSessionKey(key)
    }
    await Promise.all([
      chatStore.fetchHistory(key),
      sessionStore.fetchSessions(),
    ])
    selectedModel.value = currentSession.value?.model || defaultModelRef.value
    scrollToBottom()
  },
  { immediate: true },
)

// 会话延迟创建：新对话入口(/m/chat?agentId=xxx)不在此建 session，
// 改为在 handleSend 首条消息时才 createNewSession，避免空会话残留
onMounted(async () => {
  // 全屏聊天页可能在 MobileTabLayout 之外（深链直进），ensureConnected 幂等兜底 SSE 连接
  wsStore.ensureConnected()
  void agentTeamStore.fetchAgents()
  void modelStore.fetchModels()
  void configStore.fetchConfig()
  chatStore.subscribeRealtimeEvents()
  modelEventCleanups.push(
    wsStore.subscribe('event:model.congestion', (raw) => {
      const payload = raw as { isCongested?: boolean; model?: string } | null
      if (payload?.isCongested && payload.model) {
        modelStore.markCongested(payload.model)
      }
    }),
  )
  modelEventCleanups.push(
    wsStore.subscribe('event:model.congestion.snapshot', (raw) => {
      const payload = raw as Array<{ model: string; count: number; isCongested: boolean }> | null
      if (Array.isArray(payload)) {
        modelStore.markCongestedBatch(payload)
      }
    }),
  )
  window.addEventListener('focus', refreshLocalModelRemarks)
  window.addEventListener('storage', refreshLocalModelRemarks)
})

onUnmounted(() => {
  chatStore.unsubscribeRealtimeEvents()
  modelEventCleanups.forEach((fn) => fn())
  modelEventCleanups.length = 0
  window.removeEventListener('focus', refreshLocalModelRemarks)
  window.removeEventListener('storage', refreshLocalModelRemarks)
})

// 键盘弹出时同步可视区高度,避免输入栏被软键盘遮挡(飞书/iOS webview 对 dvh 响应不可靠)
const syncAppVh = () => {
  const vv = window.visualViewport
  if (vv) document.documentElement.style.setProperty('--app-vh', `${vv.height}px`)
}
onMounted(() => {
  syncAppVh()
  window.visualViewport?.addEventListener('resize', syncAppVh)
  window.visualViewport?.addEventListener('scroll', syncAppVh)
})
onUnmounted(() => {
  window.visualViewport?.removeEventListener('resize', syncAppVh)
  window.visualViewport?.removeEventListener('scroll', syncAppVh)
})

async function createNewSession(agentId: string) {
  creating.value = true
  error.value = ''
  const uuid = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
  const newKey = `agent:${agentId}:${uuid}`

  try {
    const token = authStore.getToken()
    const resp = await fetch('/api/user/sessions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        sessionKey: newKey,
        agentId,
        label: '',
        channel: 'webchat',
      }),
    })

    const data = await resp.json().catch(() => null)
    if (!resp.ok || !data?.ok) {
      throw new Error(data?.error || data?.message || 'Failed to create session')
    }

    chatStore.setSessionKey(newKey)
    router.replace(`/m/chat/${newKey}`)
  } catch (err) {
    error.value = err instanceof Error ? err.message : t('pages.mobile.chat.sendFailed')
  } finally {
    creating.value = false
  }
}

async function handleSend(text: string, attachments?: ChatAttachment[]) {
  try {
    error.value = ''
    // 首条消息延迟建会话：来自新对话入口(/m/chat?agentId=xxx)且尚无 session 时才创建
    if (!chatStore.sessionKey && typeof route.query.agentId === 'string') {
      await createNewSession(route.query.agentId)
      if (!chatStore.sessionKey) return // 创建失败，error 已由 createNewSession 设置
    }
    await chatStore.sendMessage(text, activeModel.value, attachments)
    await nextTick()
    scrollToBottom()
  } catch (err) {
    error.value = err instanceof Error ? err.message : t('pages.mobile.chat.sendFailed')
  }
}

async function handleAbort() {
  try {
    await chatStore.abortActiveRun()
  } catch (err) {
    error.value = err instanceof Error ? err.message : t('pages.mobile.chat.sendFailed')
  }
}

function handleBack() {
  chatStore.reset()
  if (history.length > 1) {
    router.back()
  } else {
    router.push('/m/conversations')
  }
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// Auto-scroll on new messages
watch(
  () => chatStore.messages.length,
  () => scrollToBottom(),
)
</script>

<template>
  <div class="mobile-page chat-page">
    <!-- Top bar -->
    <div class="chat-topbar">
      <button class="back-btn" :aria-label="t('pages.mobile.chat.back')" @click="handleBack">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="m15 6-6 6 6 6" />
        </svg>
      </button>
      <div class="chat-title-block">
        <div class="chat-title">{{ currentAgent?.name || '' }}</div>
      </div>
      <div class="topbar-spacer" />
    </div>

    <!-- Error banner -->
    <div v-if="error" class="chat-error">{{ error }}</div>

    <!-- Creating session -->
    <div v-if="creating" class="chat-loading">
      <NSpin size="medium" />
    </div>

    <!-- Welcome screen (no messages) -->
    <div
      v-else-if="!hasMessages && currentAgent"
      class="chat-body"
    >
      <WelcomeScreen
        :agent-name="currentAgent.name"
        :agent-avatar="currentAgentAvatar"
        :agent-description="currentAgent.description"
        @send="handleSend"
      />
    </div>

    <!-- Message list -->
    <div
      v-else
      ref="messagesContainer"
      class="chat-body chat-messages"
    >
      <div v-if="chatStore.loading" class="messages-loading">
        <NSpin size="small" />
      </div>
      <MessageBubble
        v-for="msg in chatStore.messages"
        :key="msg.id"
        :role="msg.role"
        :content="msg.content"
        :raw-content="msg.rawContent"
        :avatar="msg.role === 'assistant' ? currentAgentAvatar : ''"
      />
      <AgentStatusBlock v-if="currentAgentId" :agent-id="currentAgentId" />
    </div>

    <!-- Input bar -->
    <ChatInputBar
      :sending="chatStore.sending"
      :busy="agentBusy"
      :prefill-text="typeof route.query.prompt === 'string' ? route.query.prompt : ''"
      :model-label="activeModelLabel"
      :model-icon="activeModelIcon"
      @send="handleSend"
      @abort="handleAbort"
      @open-model-sheet="showModelSheet = true"
    />

    <NDrawer v-model:show="showModelSheet" placement="bottom" height="64%">
      <NDrawerContent :title="t('pages.mobile.chat.switchModel')" closable>
        <div class="model-sheet">
          <div v-if="modelOptions.length > 0" class="model-sheet__count">
            {{ t('pages.mobile.chat.modelCount', { n: modelOptions.length }) }}
          </div>
          <NSpin v-if="modelStore.loading" size="small" />
          <NEmpty v-else-if="modelOptions.length === 0" :description="t('pages.mobile.chat.noModels')" />
          <template v-else>
            <button
              v-for="(model, index) in modelOptions"
              :key="model.modelRef"
              class="model-card fade-up"
              :class="{ 'is-selected': isModelActive(model) }"
              :style="{ '--d': `${index * 55}ms` }"
              type="button"
              @click="selectModel(model.modelRef)"
            >
              <span v-if="isModelActive(model)" class="model-card__bar" />
              <div class="model-card__head">
                <img v-if="model.iconUrl" :src="model.iconUrl" class="model-card__icon" alt="">
                <span class="model-card__main">{{ model.label }}</span>
              </div>
              <span v-if="model.description" class="model-card__desc">{{ model.description }}</span>
              <span
                v-if="model.remark || model.provider || model.isDefault || model.congested"
                class="model-card__chips"
              >
                <span v-if="model.isDefault" class="model-chip model-chip--default">⭐ {{ t('pages.mobile.chat.defaultBadge') }}</span>
                <span v-if="model.remark" class="model-chip model-chip--remark" :class="{ 'model-chip--unavailable': isUnavailableRemark(model.remark) }">{{ model.remark }}</span>
                <span v-if="model.provider" class="model-chip model-chip--provider">{{ model.provider }}</span>
                <span v-if="model.congested" class="model-chip model-chip--congested">{{ t('pages.mobile.chat.modelCongested') }}</span>
              </span>
            </button>
          </template>
        </div>
      </NDrawerContent>
    </NDrawer>
  </div>
</template>

<style scoped>
.chat-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  height: var(--app-vh, 100dvh);
  background:
    linear-gradient(180deg, rgba(255, 255, 255, 0.2), transparent 24%),
    var(--m-bg-page);
}

.chat-topbar {
  flex-shrink: 0;
  display: grid;
  grid-template-columns: 44px minmax(0, 1fr) 44px;
  align-items: center;
  padding: 8px 12px 10px;
  padding-top: calc(8px + env(safe-area-inset-top));
  background: color-mix(in srgb, var(--m-tab-bar-bg) 92%, transparent);
  border-bottom: 1px solid var(--m-divider);
  backdrop-filter: blur(18px);
}

.back-btn {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  background: var(--m-bg-input);
  border: none;
  border-radius: 50%;
  color: var(--m-text-primary);
  cursor: pointer;
  box-shadow: var(--m-shadow-soft);
  transition: transform 0.15s ease;
  -webkit-tap-highlight-color: transparent;
}
.back-btn:active { transform: scale(0.92); }
.back-btn svg {
  width: 22px;
  height: 22px;
}

.chat-title-block {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 0;
  gap: 4px;
}

.chat-title {
  max-width: 100%;
  font-size: 16px;
  font-weight: 800;
  letter-spacing: -0.01em;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.topbar-spacer {
  min-width: 44px;
}

.chat-error {
  flex-shrink: 0;
  background: #FFF2F0;
  border-bottom: 1px solid #FFCCC7;
  color: var(--m-danger);
  padding: 8px 16px;
  font-size: 13px;
}

.chat-loading {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.chat-body {
  flex: 1;
  overflow-y: auto;
  overscroll-behavior: contain;
}

.chat-messages {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px 14px 18px;
}

.messages-loading {
  display: flex;
  justify-content: center;
  padding: 16px;
}

.model-sheet {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 4px 2px 8px;
}

.model-sheet__count {
  padding: 0 4px 4px;
  color: var(--m-text-hint);
  font-size: 12px;
}

.model-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 5px;
  width: 100%;
  padding: 14px 16px;
  border: 1px solid color-mix(in srgb, var(--m-border) 72%, transparent);
  border-radius: var(--m-radius-lg);
  background: color-mix(in srgb, var(--m-bg-card) 96%, transparent);
  box-shadow: var(--m-shadow-card);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  color: var(--m-text-primary);
  text-align: left;
  overflow: hidden;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}

.model-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}

.model-card:active {
  transform: scale(0.985);
}

.model-card.is-selected {
  border-color: var(--m-primary);
  box-shadow: 0 14px 36px rgba(37, 99, 235, 0.2);
}

.model-card__bar {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--m-primary), var(--m-accent));
  z-index: 1;
}

.model-card__head {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.model-card__icon {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
}

.model-card__main {
  position: relative;
  min-width: 0;
  font-size: 15px;
  font-weight: 700;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.model-card__desc {
  position: relative;
  color: var(--m-text-secondary);
  font-size: 12.5px;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.model-card__chips {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 3px;
}

.model-chip {
  display: inline-flex;
  align-items: center;
  padding: 2px 9px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
}

.model-chip--default,
.model-chip--remark {
  background: var(--m-primary-light);
  color: var(--m-primary-strong);
}

.model-chip--provider {
  background: color-mix(in srgb, var(--m-text-hint) 14%, transparent);
  color: var(--m-text-hint);
}

.model-chip--congested {
  background: color-mix(in srgb, var(--m-accent) 18%, transparent);
  color: var(--m-accent);
}

.model-chip--unavailable {
  background: color-mix(in srgb, #ef4444 14%, transparent);
  color: #ef4444;
}

.fade-up {
  opacity: 0;
  animation: fade-up 0.5s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}

@keyframes fade-up {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .fade-up { animation: none; opacity: 1; }
}
</style>
