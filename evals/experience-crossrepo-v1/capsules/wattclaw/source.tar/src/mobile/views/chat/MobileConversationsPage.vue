<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import { NSpin } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAgentTeamStore } from '@/stores/agent-team'
import { useSessionStore } from '@/stores/session'
import { useAuthStore } from '@/stores/auth'
import { isImageAvatar, resolveAgentAvatar } from '@/utils/agent-avatar'
import { extractPureTitle } from '@/utils/session-title'
import { sessionEffectiveTs } from '@/utils/session-time'
import { formatRelativeTime } from '@/mobile/utils/format-relative-time'
import { categoryAccent } from '@/mobile/utils/category-accent'

const router = useRouter()
const { t } = useI18n()
const agentTeamStore = useAgentTeamStore()
const sessionStore = useSessionStore()
const authStore = useAuthStore()

const userId = computed(() => authStore.currentUser?.id ?? '')
const expandedAgentIds = ref<Set<string>>(new Set())
const loading = ref(true)
const error = ref('')

// 员工按“其会话最近活动时间”降序排列（语义对齐网页端 WorkspaceSidebar）。
// Map 预聚合：一次遍历所有会话建 agentId → 最近活动戳，排序时 O(1) 查表。
const sortedAgents = computed(() => {
  const agents = agentTeamStore.agentList
  if (!agents.length) return agents
  const latestByAgent = new Map<string, number>()
  for (const s of sessionStore.sessions) {
    if (!s.agentId) continue
    const ts = sessionEffectiveTs(s)
    if (ts > (latestByAgent.get(s.agentId) ?? 0)) {
      latestByAgent.set(s.agentId, ts)
    }
  }
  return [...agents].sort((a, b) => {
    const ta = latestByAgent.get(a.id) ?? 0
    const tb = latestByAgent.get(b.id) ?? 0
    return tb - ta
  })
})

function sessionsForAgent(agentId: string) {
  return sessionStore.sessions
    .filter(s => s.agentId === agentId)
    .sort((a, b) => sessionEffectiveTs(b) - sessionEffectiveTs(a))
}

function getStorageKey(): string {
  return `mobile_expanded_agent_id_${userId.value}`
}

function loadExpandedState() {
  const saved = localStorage.getItem(getStorageKey())
  if (!saved) return
  let savedIds: string[] = []
  try {
    const parsed = JSON.parse(saved) as unknown
    savedIds = Array.isArray(parsed) ? parsed.filter((id): id is string => typeof id === 'string') : []
  } catch {
    savedIds = [saved]
  }
  const validIds = new Set(sortedAgents.value.map(agent => agent.id))
  expandedAgentIds.value = new Set(savedIds.filter(id => validIds.has(id)))
}

function toggleAgent(agentId: string) {
  const next = new Set(expandedAgentIds.value)
  if (next.has(agentId)) next.delete(agentId)
  else next.add(agentId)
  expandedAgentIds.value = next
  if (next.size === 0) {
    localStorage.removeItem(getStorageKey())
  } else {
    localStorage.setItem(getStorageKey(), JSON.stringify([...next]))
  }
}

function startNewChat(agentId: string) {
  router.push({ path: '/m/chat', query: { agentId } })
}

function openSession(sessionKey: string) {
  router.push(`/m/chat/${sessionKey}`)
}

function truncate(text: string, max: number): string {
  return text.length > max ? text.slice(0, max) + '...' : text
}

function formatSessionTitle(session: { displayTitle?: string; label?: string }): string {
  const raw = extractPureTitle(session.displayTitle || session.label || '')
  const title = raw.trim()
  if (!title) return t('pages.mobile.chat.newConversation')
  return truncate(title, 32)
}

function agentAvatar(agent: { templateId?: string; avatar?: string }): string {
  return resolveAgentAvatar(agent.templateId, agent.avatar || '🤖')
}

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    await Promise.all([
      agentTeamStore.fetchAgents(),
      sessionStore.fetchSessions(),
    ])
    loadExpandedState()
  } catch (err) {
    error.value = err instanceof Error ? err.message : String(err)
  } finally {
    loading.value = false
  }
}

function onVisibilityChange() {
  if (document.visibilityState === 'visible' && !loading.value) {
    agentTeamStore.fetchAgents()
    sessionStore.fetchSessions()
  }
}

onMounted(async () => {
  await loadData()
  document.addEventListener('visibilitychange', onVisibilityChange)
})

onBeforeUnmount(() => {
  document.removeEventListener('visibilitychange', onVisibilityChange)
})
</script>

<template>
  <div class="mobile-page conversations-page">
    <!-- 品牌签名：右上角浮层 -->
    <div class="conv-brand fade-up" style="--d: 0ms">
      <img src="/favicon.png" alt="" class="conv-brand__mark">
      <span class="conv-brand__text">WattClaw</span>
    </div>

    <!-- Skeleton -->
    <div v-if="loading" class="skeleton-list">
      <div v-for="i in 3" :key="i" class="skeleton-item">
        <div class="skeleton-avatar" />
        <div class="skeleton-text">
          <div class="skeleton-line skeleton-line-title" />
          <div class="skeleton-line skeleton-line-desc" />
        </div>
      </div>
    </div>

    <!-- Error state -->
    <div v-else-if="error" class="error-state">
      <p>{{ error }}</p>
      <button class="empty-btn" @click="loadData">{{ t('pages.mobile.chat.retry') }}</button>
    </div>

    <!-- Empty state -->
    <div v-else-if="sortedAgents.length === 0" class="empty-state">
      <p>{{ t('pages.mobile.chat.noAgents') }}</p>
      <button class="empty-btn" @click="router.push('/m/agents/create')">
        {{ t('pages.mobile.chat.goCreate') }}
      </button>
    </div>

    <!-- Hero -->
    <div v-else class="agent-list">
      <header class="conv-hero">
        <h1 class="conv-hero__title fade-up" style="--d: 0ms">{{ t('pages.mobile.chat.heroTitle') }}</h1>
        <p class="conv-hero__subtitle fade-up" style="--d: 80ms">{{ t('pages.mobile.chat.heroSubtitle') }}</p>
      </header>

      <!-- Agent accordion list -->
      <div
        v-for="(agent, i) in sortedAgents"
        :key="agent.id"
        class="agent-section fade-up"
        :style="{ '--d': `${140 + i * 70}ms` }"
      >
        <span class="accent-bar" :style="{ background: categoryAccent(agent.category).bar }"></span>
        <button
          class="agent-header"
          :class="{ expanded: expandedAgentIds.has(agent.id) }"
          @click="toggleAgent(agent.id)"
        >
          <span
            class="agent-avatar"
            :class="{ image: isImageAvatar(agentAvatar(agent)) }"
            :style="!isImageAvatar(agentAvatar(agent)) ? { background: categoryAccent(agent.category).avatarTint } : undefined"
          >
            <img
              v-if="isImageAvatar(agentAvatar(agent))"
              v-avatar-fallback
              :src="agentAvatar(agent)"
              :alt="agent.name"
              class="agent-avatar-img"
            >
            <span v-else>{{ agentAvatar(agent) }}</span>
          </span>
          <div class="agent-info">
            <div class="agent-name">{{ agent.name }}</div>
            <div class="agent-desc">{{ agent.description }}</div>
          </div>
          <span v-if="expandedAgentIds.has(agent.id)" class="expand-arrow">▼</span>
        </button>

        <div v-if="expandedAgentIds.has(agent.id)" class="agent-expanded">
          <button class="new-chat-btn" @click="startNewChat(agent.id)">
            <svg class="new-chat-btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            <span>{{ t('pages.mobile.chat.newChat') }}</span>
          </button>
          <NSpin v-if="sessionStore.loading" size="small" />
          <div v-else-if="sessionsForAgent(agent.id).length > 0" class="session-list">
            <button
              v-for="session in sessionsForAgent(agent.id)"
              :key="session.key"
              class="session-item"
              @click="openSession(session.key)"
            >
              <span class="session-item__icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
              </span>
              <span class="session-item__title">{{ formatSessionTitle(session) }}</span>
              <span class="session-item__time">{{ formatRelativeTime(session.lastActivity, (k) => t(k)) }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.conversations-page {
  position: relative;
  padding: 12px 0 env(safe-area-inset-bottom);
}

.skeleton-list { padding: 16px; }
.skeleton-item {
  display: flex; align-items: center; gap: 12px;
  padding: 16px 0; border-bottom: 1px solid var(--m-divider);
}
.skeleton-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  background: var(--m-divider); animation: pulse 1.5s ease-in-out infinite;
}
.skeleton-text { flex: 1; }
.skeleton-line {
  height: 12px; border-radius: 6px; background: var(--m-divider);
  animation: pulse 1.5s ease-in-out infinite;
}
.skeleton-line-title { width: 40%; margin-bottom: 8px; }
.skeleton-line-desc { width: 70%; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

.empty-state {
  display: flex; flex-direction: column; align-items: center;
  justify-content: center; padding: 80px 24px; color: var(--m-text-hint);
}

.error-state {
  display: flex; flex-direction: column; align-items: center;
  justify-content: center; padding: 80px 24px; color: var(--m-danger);
}
.empty-btn {
  margin-top: 16px; padding: 8px 24px; background: var(--m-primary);
  color: #fff; border: none; border-radius: var(--m-radius-md);
  font-size: 14px; cursor: pointer;
}

.agent-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.agent-section {
  position: relative;
  margin: 0 14px;
  background: color-mix(in srgb, var(--m-bg-card) 96%, transparent);
  border: 1px solid color-mix(in srgb, var(--m-border) 72%, transparent);
  border-radius: 24px;
  box-shadow: 0 14px 36px rgba(15, 23, 42, 0.07);
  overflow: hidden;
  /* 不用 backdrop-filter:N 个卡片首屏并发挂载 + fade-up 动画时，移动端合成线程饱和，
     click 命中测试延迟致 tab 点不动；且 var(--m-bg-card) 96% 不透明，毛玻璃几乎无视觉收益 */
}
.agent-section::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}
.accent-bar {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  z-index: 1;
}
.agent-header {
  display: flex; align-items: center; gap: 12px; width: 100%;
  min-height: 76px;
  padding: 14px; background: transparent; border: none; cursor: pointer;
  text-align: left; -webkit-tap-highlight-color: transparent;
}
.agent-header:active { background: var(--m-bg-input); }
.agent-avatar {
  display: grid; place-items: center; width: 50px; height: 50px;
  border-radius: 18px; background: var(--m-avatar-bg); color: var(--m-primary);
  font-size: 26px; line-height: 1; flex-shrink: 0; overflow: hidden;
  box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
}
.agent-avatar.image { background: #fff; }
.agent-avatar-img { width: 100%; height: 100%; object-fit: cover; }
.agent-info { flex: 1; min-width: 0; }
.agent-name { font-size: 16px; font-weight: 750; color: var(--m-text-primary); }
.agent-desc {
  margin-top: 2px;
  font-size: 13px; color: var(--m-text-hint);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.expand-arrow { font-size: 11px; color: var(--m-text-hint); flex-shrink: 0; }

.agent-expanded {
  padding: 0 14px 14px; display: flex; flex-direction: column; gap: 12px;
}

/* 新对话按钮 */
.new-chat-btn {
  display: flex; align-items: center; justify-content: center; gap: 7px;
  width: 100%; padding: 10px; background: var(--m-bubble-user-bg);
  color: #fff; border: none; border-radius: var(--m-radius-md);
  font-size: 14px; font-weight: 650; cursor: pointer;
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.14);
  transition: transform 0.15s ease;
  -webkit-tap-highlight-color: transparent;
}
.new-chat-btn:active { transform: scale(0.98); }
.new-chat-btn__icon { width: 15px; height: 15px; }

/* 历史会话列表：卡片化 */
.session-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.session-item {
  position: relative;
  display: flex; align-items: center; gap: 10px;
  padding: 11px 12px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-divider);
  border-radius: var(--m-radius-md);
  cursor: pointer; text-align: left;
  box-shadow: 0 6px 16px rgba(15, 23, 42, 0.05);
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease, background 0.18s ease;
}
.session-item::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}
.session-item:active { transform: scale(0.98); background: var(--m-primary-light); }
.session-item__icon {
  position: relative;
  display: grid; place-items: center;
  width: 30px; height: 30px; flex-shrink: 0;
  border-radius: 9px;
  background: var(--m-avatar-bg);
  color: var(--m-primary);
}
.session-item__icon svg { width: 16px; height: 16px; }
.session-item__title {
  position: relative;
  flex: 1; min-width: 0;
  font-size: 14px; color: var(--m-text-primary);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.session-item__time {
  position: relative;
  flex-shrink: 0;
  font-size: 11px; color: var(--m-text-hint);
  padding: 2px 7px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--m-bg-input) 80%, transparent);
}

/* ===== Hero ===== */
.conv-hero {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 8px 18px 14px;
}
.conv-hero__title {
  margin: 0;
  font-size: 30px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.1;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.conv-hero__subtitle {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--m-text-hint);
}
.conv-brand {
  position: absolute;
  top: calc(10px + env(safe-area-inset-top));
  right: 16px;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 7px;
  opacity: 0.78;
}
.conv-brand__mark {
  width: 20px;
  height: 20px;
  border-radius: 6px;
  object-fit: cover;
}
.conv-brand__text {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--m-text-secondary);
}

/* ===== 入场动画 ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.55s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .fade-up { animation: none; opacity: 1; }
}
</style>
