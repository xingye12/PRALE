<script setup lang="ts">
import { ref } from 'vue'

interface Props {
  src: string
}

defineProps<Props>()
const showFull = ref(false)
</script>

<template>
  <div class="image-preview">
    <img :src="src" class="preview-thumb" @click="showFull = true" />
    <div v-if="showFull" class="preview-overlay" @click="showFull = false">
      <img :src="src" class="preview-full" />
    </div>
  </div>
</template>

<style scoped>
.preview-thumb {
  max-width: 200px;
  max-height: 150px;
  border-radius: var(--m-radius-sm);
  cursor: pointer;
  object-fit: cover;
}

.preview-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.preview-full {
  max-width: 100vw;
  max-height: 100vh;
  object-fit: contain;
}
</style>
