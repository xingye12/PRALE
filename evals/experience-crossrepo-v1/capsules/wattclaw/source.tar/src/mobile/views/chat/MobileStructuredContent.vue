<script setup lang="ts">
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { renderMarkdown } from '@/utils/render-markdown'
import { parseRawContent } from '@/views/chat/chat-message-utils'
import type { ChatMessageContent } from '@/api/types'

interface Props {
  rawContent: ChatMessageContent[]
}
const props = defineProps<Props>()
const { t } = useI18n()

const view = computed(() => parseRawContent(props.rawContent))

const expandedThinking = ref(false)
const expandedTools = ref<Record<number, boolean>>({})
function toggleThinking() {
  expandedThinking.value = !expandedThinking.value
}
function toggleTool(idx: number) {
  expandedTools.value = { ...expandedTools.value, [idx]: !expandedTools.value[idx] }
}

function resultOf(callId: string | undefined) {
  return view.value?.toolResults.find((r) => (callId ? r.id === callId : false)) ?? null
}

const bodyHtml = computed(() => {
  const text = view.value?.plainTexts?.join('\n\n') ?? ''
  return text ? renderMarkdown(text) : ''
})

// 防御：过滤掉 buildImageUrl 返回 undefined 的图片，避免 <img src=""> 触发对当前页 URL 的请求
const images = computed(() => view.value?.images.filter((img) => Boolean(img.url)) ?? [])
</script>

<template>
  <div v-if="view" class="msc">
    <!-- 思考过程（默认折叠） -->
    <div v-if="view.thinkings.length" class="msc-block">
      <button class="msc-head" type="button" @click="toggleThinking">
        <span class="msc-icon">💭</span>
        <span class="msc-head-label">{{ t('pages.mobile.chat.thinkingProcess') }}</span>
        <span class="msc-caret">{{ expandedThinking ? '▾' : '▸' }}</span>
      </button>
      <div v-if="expandedThinking" class="msc-thinking-body">
        <div v-for="(th, i) in view.thinkings" :key="`th-${i}`">{{ th.text }}</div>
      </div>
    </div>

    <!-- 工具调用（每项一行，点击展开参数 + 结果） -->
    <div v-if="view.toolCalls.length" class="msc-tools">
      <div
        v-for="(call, idx) in view.toolCalls"
        :key="call.id || `call-${idx}`"
        class="msc-tool"
      >
        <button class="msc-tool-head" type="button" @click="toggleTool(idx)">
          <span class="msc-icon">🔧</span>
          <span class="msc-tool-name">{{ call.name }}</span>
          <span
            class="msc-tool-status"
            :class="{ 'is-error': resultOf(call.id)?.status === 'error' }"
          >{{ resultOf(call.id) ? '✓' : '…' }}</span>
          <span class="msc-caret">{{ expandedTools[idx] ? '▾' : '▸' }}</span>
        </button>
        <div v-if="expandedTools[idx]" class="msc-tool-body">
          <pre v-if="call.argumentsJson" class="msc-pre">{{ call.argumentsJson }}</pre>
          <div
            v-for="res in view.toolResults.filter((r) => call.id && r.id === call.id)"
            :key="res.id"
            class="msc-tool-result"
            :class="{ 'is-error': res.status === 'error' }"
          >
            <div class="msc-result-label">{{ t('pages.mobile.chat.toolResultLabel') }}</div>
            <pre class="msc-pre">{{ res.content }}</pre>
          </div>
        </div>
      </div>
    </div>

    <!-- 正文 -->
    <div v-if="bodyHtml" class="msc-text markdown-body" v-html="bodyHtml" />

    <!-- 图片 -->
    <div v-if="images.length" class="msc-images">
      <img
        v-for="(img, i) in images"
        :key="`img-${i}`"
        :src="img.url"
        class="msc-image"
      >
    </div>
  </div>
</template>

<style scoped>
.msc { display: flex; flex-direction: column; gap: 6px; }

.msc-block {
  border: 1px solid color-mix(in srgb, var(--m-border) 60%, transparent);
  border-radius: 12px;
  background: color-mix(in srgb, var(--m-bg-input) 50%, transparent);
  overflow: hidden;
}

.msc-head,
.msc-tool-head {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding: 7px 10px;
  background: transparent;
  border: none;
  color: var(--m-text-hint);
  font-size: 13px;
  text-align: left;
  cursor: pointer;
}
.msc-head:hover,
.msc-tool-head:hover { color: var(--m-primary); }

.msc-icon { font-size: 13px; flex-shrink: 0; }
.msc-head-label { font-weight: 600; }
.msc-tool-name { font-weight: 600; color: var(--m-text-primary); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.msc-tool-status { font-size: 12px; color: var(--m-primary); }
.msc-tool-status.is-error { color: var(--m-danger, #ef4444); }
.msc-caret { margin-left: auto; font-size: 11px; }

.msc-thinking-body {
  padding: 8px 10px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--m-text-hint);
  white-space: pre-wrap;
  border-top: 1px solid color-mix(in srgb, var(--m-border) 50%, transparent);
}

.msc-tools { display: flex; flex-direction: column; gap: 4px; }
.msc-tool { border: 1px solid color-mix(in srgb, var(--m-border) 50%, transparent); border-radius: 10px; overflow: hidden; background: color-mix(in srgb, var(--m-bg-input) 40%, transparent); }
.msc-tool-body { padding: 8px 10px; border-top: 1px solid color-mix(in srgb, var(--m-border) 40%, transparent); }

.msc-result-label { font-size: 11px; color: var(--m-text-hint); margin-bottom: 4px; }
.msc-tool-result.is-error .msc-pre { color: var(--m-danger, #ef4444); }

.msc-pre {
  margin: 0;
  padding: 6px 8px;
  background: rgba(0, 0, 0, 0.05);
  border-radius: 8px;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  font-size: 11px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 200px;
  overflow-y: auto;
}

.msc-text { font-size: 14px; line-height: 1.62; }
.msc-text :deep(p) { margin: 0 0 8px; }
.msc-text :deep(p:last-child) { margin-bottom: 0; }

.msc-images { display: flex; flex-wrap: wrap; gap: 6px; }
.msc-image { max-width: 160px; max-height: 160px; border-radius: 10px; object-fit: cover; }
</style>
