<script setup lang="ts">
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const toolInputLabel = computed(() => t('pages.mobile.chat.toolInput'))
const toolOutputLabel = computed(() => t('pages.mobile.chat.toolOutput'))

interface Props {
  toolName: string
  args?: string
  result?: string
  status: 'running' | 'completed' | 'error'
}

defineProps<Props>()
const expanded = ref(false)
</script>

<template>
  <div class="tool-call-card" :class="[`status-${status}`]">
    <button class="tool-header" @click="expanded = !expanded">
      <span class="tool-status-dot" />
      <span class="tool-name">{{ toolName }}</span>
      <span class="tool-expand">{{ expanded ? '▼' : '▶' }}</span>
    </button>
    <div v-if="expanded" class="tool-body">
      <div v-if="args" class="tool-section">
        <div class="tool-label">{{ toolInputLabel }}</div>
        <pre class="tool-code">{{ args }}</pre>
      </div>
      <div v-if="result" class="tool-section">
        <div class="tool-label">{{ toolOutputLabel }}</div>
        <pre class="tool-code">{{ result }}</pre>
      </div>
    </div>
  </div>
</template>

<style scoped>
.tool-call-card {
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-sm);
  overflow: hidden;
  margin: 4px 0;
}

.status-running { border-left: 3px solid var(--m-primary); }
.status-completed { border-left: 3px solid #52c41a; }
.status-error { border-left: 3px solid var(--m-danger); }

.tool-header {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 8px 12px;
  background: none;
  border: none;
  cursor: pointer;
  text-align: left;
  -webkit-tap-highlight-color: transparent;
}

.tool-status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
}

.status-running .tool-status-dot { background: var(--m-primary); }
.status-completed .tool-status-dot { background: #52c41a; }
.status-error .tool-status-dot { background: var(--m-danger); }

.tool-name {
  flex: 1;
  font-size: 13px;
  font-weight: 500;
  color: var(--m-text-primary);
  font-family: 'SF Mono', Monaco, monospace;
}

.tool-expand {
  font-size: 10px;
  color: var(--m-text-hint);
}

.tool-body {
  border-top: 1px solid var(--m-divider);
  padding: 8px 12px;
}

.tool-section {
  margin-bottom: 8px;
}

.tool-section:last-child {
  margin-bottom: 0;
}

.tool-label {
  font-size: 11px;
  color: var(--m-text-hint);
  margin-bottom: 4px;
}

.tool-code {
  font-size: 12px;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  color: var(--m-text-secondary);
  background: var(--m-bg-input);
  padding: 8px;
  border-radius: 6px;
  margin: 0;
  white-space: pre-wrap;
  word-break: break-all;
  max-height: 200px;
  overflow-y: auto;
}
</style>
