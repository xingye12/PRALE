<script setup lang="ts">
import { ref, watch, onUnmounted, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { VoiceStatus, DragZone } from '@/mobile/composables/useMobileVoiceInput'

interface Props {
  status: VoiceStatus
  volume: number
  duration: number
  draftText: string
  dragZone: DragZone | null
  analyser: AnalyserNode | null
}

const props = defineProps<Props>()
const { t } = useI18n()

const canvasRef = ref<HTMLCanvasElement | null>(null)
let rafId: number | null = null

function fmtDuration(sec: number): string {
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

const isListening = computed(() => props.status === 'listening')
const isStopping = computed(() => props.status === 'stopping')
const isError = computed(() =>
  ['permission-denied', 'unsupported', 'error', 'service-unavailable'].includes(props.status),
)
const isCancel = computed(() => props.dragZone === 'cancel')
const isText = computed(() => props.dragZone === 'text')
const isNormal = computed(() => !isCancel.value && !isText.value && !isError.value && !isStopping.value)

function errorText(): string {
  switch (props.status) {
    case 'permission-denied': return t('pages.mobile.chat.voicePermissionDenied')
    case 'unsupported': return t('pages.mobile.chat.voiceNoMic')
    case 'error': return t('pages.mobile.chat.voiceTimeout')
    case 'service-unavailable': return t('pages.mobile.chat.voiceUnavailable')
    default: return ''
  }
}

const hint = computed(() => {
  if (isStopping.value) return t('pages.mobile.chat.transcribing')
  if (props.status === 'requesting') return t('pages.mobile.chat.requestingMic')
  if (props.status === 'connecting') return t('pages.mobile.chat.connectingVoice')
  if (isCancel.value) return t('pages.mobile.chat.releaseToCancel')
  if (isText.value) return t('pages.mobile.chat.releaseToText')
  if (isError.value) return errorText()
  return t('pages.mobile.chat.releaseToSend')
})

// cancel / text 态底部文案隐藏（气泡 + 操作按钮 label 已承载状态文案，避免重复）
const hideFooter = computed(() => isCancel.value || isText.value)

function drawWave() {
  const canvas = canvasRef.value
  const an = props.analyser
  if (!canvas || !an || !isListening.value || !isNormal.value) {
    if (rafId) { cancelAnimationFrame(rafId); rafId = null }
    return
  }
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const data = new Uint8Array(an.frequencyBinCount)
  an.getByteFrequencyData(data)
  const w = canvas.width
  const h = canvas.height
  ctx.clearRect(0, 0, w, h)
  ctx.fillStyle = 'rgba(255,255,255,0.95)'
  const bars = 14
  const step = Math.floor(data.length / bars)
  const barW = w / bars
  for (let i = 0; i < bars; i++) {
    const v = (data[i * step] ?? 0) / 255
    const barH = Math.max(3, v * h)
    const x = i * barW + 2
    const bw = barW - 4
    const y = (h - barH) / 2
    ctx.beginPath()
    const r = Math.min(bw / 2, 2)
    ctx.moveTo(x + r, y)
    ctx.arcTo(x + bw, y, x + bw, y + barH, r)
    ctx.arcTo(x + bw, y + barH, x, y + barH, r)
    ctx.arcTo(x, y + barH, x, y, r)
    ctx.arcTo(x, y, x + bw, y, r)
    ctx.closePath()
    ctx.fill()
  }
  rafId = requestAnimationFrame(drawWave)
}

watch(
  () => [props.status, props.dragZone, props.analyser] as const,
  ([s]) => {
    if (s === 'listening' && isNormal.value && props.analyser) {
      if (rafId) cancelAnimationFrame(rafId)
      rafId = requestAnimationFrame(drawWave)
    }
  },
)

onUnmounted(() => {
  if (rafId) cancelAnimationFrame(rafId)
})
</script>

<template>
  <Teleport to="body">
    <div class="voice-overlay">
      <!-- 动态反馈气泡区（绿/红气泡 + 底部 tail 箭头朝下） -->
      <div class="bubble-container">
        <div
          class="voice-bubble"
          :class="{ 'cancel-state': isCancel, 'transcribe-state': isText, 'error-state': isError }"
        >
          <!-- 取消态：× -->
          <svg v-if="isCancel" class="bubble-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
          <!-- 错误区：! -->
          <svg v-else-if="isError" class="bubble-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
            <circle cx="12" cy="12" r="9" />
            <path d="M12 8v5M12 16h.01" />
          </svg>
          <!-- 转文字态：识别文字 -->
          <span v-else-if="isText" class="bubble-text">{{ draftText || t('pages.mobile.chat.releaseToText') }}</span>
          <!-- 转文字处理中：spinner -->
          <svg v-else-if="isStopping" class="bubble-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round">
            <path d="M12 3a9 9 0 1 0 9 9" />
          </svg>
          <!-- 默认态：声波 + 时长（listening）/ 准备中 spinner（requesting/connecting，避免气泡空白） -->
          <template v-else>
            <canvas v-if="isListening" ref="canvasRef" class="bubble-wave" width="120" height="32" />
            <span v-if="isListening" class="bubble-dur">{{ fmtDuration(duration) }}</span>
            <svg v-else class="bubble-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round">
              <path d="M12 3a9 9 0 1 0 9 9" />
            </svg>
          </template>
        </div>
        <div class="bubble-tail"></div>
      </div>

      <!-- 悬浮操作区（取消 / 转文字，激活放大变色 + label 滑入） -->
      <div v-if="isListening" class="floating-actions">
        <div class="action-btn left" :class="{ active: isCancel }">
          <div class="icon-circle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </div>
          <div class="action-label">{{ t('pages.mobile.chat.releaseToCancel') }}</div>
        </div>
        <div class="action-btn right" :class="{ active: isText }">
          <div class="icon-circle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
              <path d="M14 3v5h5M9 13h6M9 17h4" />
            </svg>
          </div>
          <div class="action-label">{{ t('pages.mobile.chat.voiceToText') }}</div>
        </div>
      </div>

      <!-- 底部灰色安全区（贴底微弧，纯文案锚点） -->
      <div class="bottom-gray-zone" :class="{ 'hide-text': hideFooter }">
        <div class="center-footer-text">{{ hint }}</div>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
/* 1. 全局交互暗场 */
.voice-overlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(0, 0, 0, 0.5);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  pointer-events: none;
  animation: overlay-in 0.2s ease;
}
@keyframes overlay-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* 2. 动态反馈气泡区 */
.bubble-container {
  position: absolute;
  bottom: 320px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
}
.voice-bubble {
  min-width: 96px;
  min-height: 52px;
  padding: 14px 28px;
  border-radius: 12px;
  background: #07c160;
  color: #fff;
  font-weight: bold;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
  transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
}
.bubble-tail {
  width: 0;
  height: 0;
  margin-top: -1px;
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  border-top: 10px solid #07c160;
  transition: border-top-color 0.2s ease;
}
.voice-bubble.cancel-state,
.voice-bubble.error-state {
  background: #fa5151;
}
.voice-bubble.cancel-state {
  transform: scale(1.05);
}
.voice-bubble.cancel-state + .bubble-tail,
.voice-bubble.error-state + .bubble-tail {
  border-top-color: #fa5151;
}
.voice-bubble.transcribe-state {
  background: #07c160;
  transform: scale(1.05);
}
.voice-bubble.transcribe-state + .bubble-tail {
  border-top-color: #07c160;
}

.bubble-glyph { width: 30px; height: 30px; }
.bubble-spinner { width: 30px; height: 30px; animation: spin 0.9s linear infinite; }
.bubble-wave { width: 90px; height: 26px; display: block; }
.bubble-dur { font-variant-numeric: tabular-nums; }
.bubble-text {
  max-width: 56vw;
  font-size: 15px;
  font-weight: 600;
  line-height: 1.4;
  word-break: break-word;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* 3. 悬浮操作区 */
.floating-actions {
  position: absolute;
  bottom: 120px;
  width: 100%;
  box-sizing: border-box;
  padding: 0 50px;
  display: flex;
  justify-content: space-between;
}
.action-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}
.icon-circle {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.2);
  display: flex;
  justify-content: center;
  align-items: center;
  color: #fff;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}
.icon-circle svg { width: 30px; height: 30px; }
.action-label {
  margin-top: 12px;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  opacity: 0;
  transform: translateY(10px);
  transition: all 0.3s ease;
}
.action-btn.left.active .icon-circle {
  transform: scale(1.3);
  background: #fa5151;
}
.action-btn.left.active .action-label {
  opacity: 1;
  transform: translateY(0);
}
.action-btn.right.active .icon-circle {
  transform: scale(1.3);
  background: #07c160;
}
.action-btn.right.active .action-label {
  opacity: 1;
  transform: translateY(0);
}

/* 4. 底部灰色安全区 */
.bottom-gray-zone {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 100px;
  background: #2c2c2c;
  border-top-left-radius: 50% 20px;
  border-top-right-radius: 50% 20px;
  display: flex;
  justify-content: center;
  padding-top: 25px;
  box-sizing: border-box;
  transition: opacity 0.2s;
}
.center-footer-text {
  color: #999;
  font-size: 14px;
  font-weight: 500;
  transition: opacity 0.2s;
}
.bottom-gray-zone.hide-text .center-footer-text {
  opacity: 0;
}
</style>
