<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { isImageAvatar } from '@/utils/agent-avatar'

interface Props {
  agentName: string
  agentAvatar: string
  agentDescription?: string
  suggestedQuestions?: string[]
}

const props = defineProps<Props>()
const emit = defineEmits<{ send: [text: string] }>()
const { t } = useI18n()
const avatarIsImage = computed(() => isImageAvatar(props.agentAvatar))

const defaultQuestions = [
  t('pages.mobile.chat.suggestedQuestion1'),
  t('pages.mobile.chat.suggestedQuestion2'),
  t('pages.mobile.chat.suggestedQuestion3'),
]
</script>

<template>
  <div class="welcome-screen">
    <!-- 光环头像：halo 呼吸 + ring 旋转 + core 主体 -->
    <div class="avatar-orb fade-up" style="--d: 0ms">
      <span class="avatar-orb__halo" aria-hidden="true"></span>
      <span class="avatar-orb__ring" aria-hidden="true"></span>
      <span class="avatar-orb__core">
        <img
          v-if="avatarIsImage"
          v-avatar-fallback
          :src="agentAvatar"
          :alt="agentName"
          class="avatar-orb__img"
        >
        <span v-else class="avatar-orb__emoji">{{ agentAvatar || '🤖' }}</span>
      </span>
    </div>

    <div class="welcome-title fade-up" style="--d: 110ms">
      {{ t('pages.mobile.chat.welcome', { name: agentName }) }}
    </div>
    <div v-if="agentDescription" class="welcome-desc fade-up" style="--d: 190ms">
      {{ agentDescription }}
    </div>

    <div class="welcome-questions fade-up" style="--d: 270ms">
      <button
        v-for="(q, i) in (suggestedQuestions || defaultQuestions)"
        :key="i"
        class="question-btn"
        @click="emit('send', q)"
      >
        {{ q }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.welcome-screen {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100%;
  padding: 40px 24px;
  text-align: center;
}

/* ===== 光环头像（复用「我的」页 Aurora orb 语言，缩小适配欢迎屏）===== */
.avatar-orb {
  position: relative;
  width: 116px;
  height: 116px;
  margin-bottom: 22px;
}
.avatar-orb__halo {
  position: absolute;
  inset: -18px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(37, 99, 235, 0.3), transparent 68%);
  filter: blur(8px);
  animation: orb-pulse 3.8s ease-in-out infinite;
}
.avatar-orb__ring {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    var(--m-primary),
    var(--m-accent),
    var(--m-primary-strong),
    var(--m-accent),
    var(--m-primary)
  );
  -webkit-mask: radial-gradient(circle at center, transparent 0 48px, #000 49px);
  mask: radial-gradient(circle at center, transparent 0 48px, #000 49px);
  animation: orb-spin 7s linear infinite;
}
.avatar-orb__core {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 96px;
  height: 96px;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  background: var(--m-avatar-bg);
  box-shadow: var(--m-shadow-soft), inset 0 0 0 1px rgba(255, 255, 255, 0.5);
  overflow: hidden;
  display: grid;
  place-items: center;
}
.avatar-orb__img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.avatar-orb__emoji {
  font-size: 44px;
  line-height: 1;
}

/* ===== 渐变标题 ===== */
.welcome-title {
  font-size: 22px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.2;
  margin-bottom: 8px;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.welcome-desc {
  font-size: 13px;
  line-height: 1.55;
  color: var(--m-text-hint);
  max-width: 280px;
  margin-bottom: 26px;
}

/* ===== 卡片化推荐问题 ===== */
.welcome-questions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
  max-width: 320px;
}

.question-btn {
  position: relative;
  padding: 13px 16px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  border-radius: var(--m-radius-lg);
  color: var(--m-text-primary);
  font-size: 14px;
  font-weight: 500;
  text-align: left;
  cursor: pointer;
  box-shadow: var(--m-shadow-soft);
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease, background 0.18s ease;
}

.question-btn::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}

.question-btn:active {
  transform: scale(0.98);
  background: var(--m-primary-light);
}

/* ===== 入场动画 ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}

@keyframes orb-spin {
  to { transform: rotate(360deg); }
}
@keyframes orb-pulse {
  0%, 100% { opacity: 0.55; transform: scale(0.95); }
  50% { opacity: 1; transform: scale(1.05); }
}
@keyframes fade-up {
  from { opacity: 0; transform: translateY(14px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .avatar-orb__halo,
  .avatar-orb__ring { animation: none; }
  .fade-up { animation: none; opacity: 1; }
}
</style>
