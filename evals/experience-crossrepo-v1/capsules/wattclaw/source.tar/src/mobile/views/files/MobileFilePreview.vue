<script setup lang="ts">
import { computed, nextTick, onUnmounted, ref, watch } from 'vue'
import { NButton, NDrawer, NDrawerContent, NSpin } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import hljs from 'highlight.js/lib/core'
import javascript from 'highlight.js/lib/languages/javascript'
import typescript from 'highlight.js/lib/languages/typescript'
import xml from 'highlight.js/lib/languages/xml'
import css from 'highlight.js/lib/languages/css'
import json from 'highlight.js/lib/languages/json'
import python from 'highlight.js/lib/languages/python'
import java from 'highlight.js/lib/languages/java'
import go from 'highlight.js/lib/languages/go'
import rust from 'highlight.js/lib/languages/rust'
import shell from 'highlight.js/lib/languages/shell'
import yaml from 'highlight.js/lib/languages/yaml'
import sql from 'highlight.js/lib/languages/sql'
import markdownLang from 'highlight.js/lib/languages/markdown'
import type { LanguageFn } from 'highlight.js'
import 'highlight.js/styles/github-dark.css'
import PdfViewer from '@/components/common/PdfViewer.vue'
import { useAuthStore } from '@/stores/auth'
import { apiPath } from '@/utils/api-path'
import { renderMarkdown } from '@/utils/render-markdown'
import { base64ToArrayBuffer, base64ToBlob } from '@/utils/file-blob'
import { getPreviewKind, isBinaryPreview, toHljsLanguage, type PreviewKind } from '@/utils/preview-kind'
import type { FileEntry } from '@/utils/file-classify'

// 按需注册 highlight.js 语言（模块加载时一次性，ESM 缓存保证仅注册一次）
const HLJS_LANGUAGES: Record<string, LanguageFn> = {
  javascript,
  typescript,
  xml,
  css,
  json,
  python,
  java,
  go,
  rust,
  shell,
  yaml,
  sql,
  markdown: markdownLang,
}
Object.entries(HLJS_LANGUAGES).forEach(([name, lang]) => hljs.registerLanguage(name, lang))

const props = defineProps<{
  file: FileEntry | null
  visible: boolean
}>()
const emit = defineEmits<{
  (e: 'update:visible', value: boolean): void
  (e: 'download', file: FileEntry): void
}>()

const { t } = useI18n()
const authStore = useAuthStore()

const loading = ref(false)
const errorMsg = ref('')
const textContent = ref('')
const imageDataUrl = ref<string | null>(null)
const pdfUrl = ref<string | null>(null)
const htmlTab = ref<'render' | 'source'>('render')
const codeRef = ref<HTMLElement | null>(null)
// docx 渲染进 sandbox iframe（allow-same-origin 让父可写 contentDocument，无 allow-scripts → 脚本不执行）
const docxIframe = ref<HTMLIFrameElement | null>(null)
// 电子表格：sheet 名 → 二维行数据（一次性解析所有 sheet，切换零延迟）
const sheetData = ref<Map<string, string[][]>>(new Map())
const activeSheet = ref('')

const kind = computed<PreviewKind>(() =>
  props.file ? getPreviewKind(props.file.extension || '') : 'unsupported',
)

const renderedMarkdown = computed(() =>
  kind.value === 'markdown' ? renderMarkdown(textContent.value) : '',
)

const sheetNames = computed(() => Array.from(sheetData.value.keys()))
const tableRows = computed(() => sheetData.value.get(activeSheet.value) || [])

function authHeaders(): Record<string, string> {
  const token =
    (authStore.getToken as unknown as (() => string) | undefined)?.() ||
    (authStore as unknown as { token?: string }).token
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function resetState() {
  textContent.value = ''
  imageDataUrl.value = null
  if (pdfUrl.value) {
    URL.revokeObjectURL(pdfUrl.value)
    pdfUrl.value = null
  }
  errorMsg.value = ''
  htmlTab.value = 'render'
  sheetData.value = new Map()
  activeSheet.value = ''
}

async function loadContent() {
  const f = props.file
  if (!f) return
  resetState()
  if (kind.value === 'unsupported') return
  loading.value = true
  try {
    const binary = isBinaryPreview(kind.value) ? '&binary=true' : ''
    const url = apiPath(
      `/api/files/get?path=${encodeURIComponent(f.path)}&workspace=${encodeURIComponent(f.workspace)}${binary}`,
    )
    const res = await fetch(url, { headers: authHeaders() })
    const data = (await res.json()) as {
      ok?: boolean
      content?: string
      file?: { content?: string }
      error?: { message?: string }
    }
    if (!res.ok || !data.ok) throw new Error(data.error?.message || `HTTP ${res.status}`)
    const content = data.content || data.file?.content || ''
    if (!content) {
      errorMsg.value = t('pages.mobile.files.preview.empty')
      return
    }
    if (kind.value === 'image') {
      const ext = (f.extension || 'png').toLowerCase()
      imageDataUrl.value = `data:image/${ext};base64,${content}`
    } else if (kind.value === 'pdf') {
      pdfUrl.value = URL.createObjectURL(base64ToBlob(content, 'application/pdf'))
    } else if (kind.value === 'docx') {
      // 渲染进 sandbox iframe：allow-same-origin 让父文档可访问 contentDocument 渲染 docx；
      // 不带 allow-scripts → iframe 内 script 标签与 javascript: 链接均不执行，彻底隔离 XSS。
      // 容器用独立 v-if（不被 loading 门控），nextTick 确保 iframe 已 mount。
      await nextTick()
      const iframe = docxIframe.value
      const doc = iframe?.contentDocument
      if (!iframe || !doc) throw new Error('DOCX preview init failed')
      doc.open()
      doc.write(
        '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
          '<style>html,body{margin:0;padding:0;background:#fff;}' +
          'body{overflow-x:auto;padding:8px;-webkit-overflow-scrolling:touch;}' +
          '.docx-wrapper{background:transparent;padding:0;}' +
          '.docx-preview-document{max-width:100%;margin:0 auto;box-sizing:border-box;}' +
          'img,table{max-width:100%;}</style></head><body></body></html>',
      )
      doc.close()
      // 动态 import：docx-preview 较大，仅在预览 docx 时加载，隔离到独立 chunk
      const { renderAsync } = await import('docx-preview')
      await renderAsync(base64ToArrayBuffer(content), doc.body, doc.head, {
        className: 'docx-preview-document',
        inWrapper: true,
        breakPages: true,
      })
    } else if (kind.value === 'spreadsheet' || kind.value === 'csv') {
      // 动态 import：xlsx ~500KB，仅在预览表格时加载
      const XLSX = await import('xlsx')
      const wb =
        kind.value === 'csv'
          ? XLSX.read(content, { type: 'string' })
          : XLSX.read(base64ToArrayBuffer(content), { type: 'array', cellDates: true })
      const rowsMap = new Map<string, string[][]>()
      for (const name of wb.SheetNames) {
        const sheet = wb.Sheets[name]
        rowsMap.set(
          name,
          sheet
            ? XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1, raw: false, defval: '' })
            : [],
        )
      }
      sheetData.value = rowsMap
      activeSheet.value = wb.SheetNames[0] || ''
    } else {
      textContent.value = content
      if (kind.value === 'code') {
        await nextTick()
        highlightCode()
      }
    }
  } catch (e) {
    errorMsg.value = e instanceof Error ? e.message : t('pages.mobile.files.preview.loadFailed')
  } finally {
    loading.value = false
  }
}

function highlightCode() {
  const el = codeRef.value
  if (!el) return
  // 重置高亮标记，允许同一元素重新高亮（切换文件时）
  el.removeAttribute('data-highlighted')
  el.className = ''
  const lang = props.file ? toHljsLanguage(props.file.extension || '') : ''
  if (lang && hljs.getLanguage(lang)) el.className = `language-${lang}`
  try {
    hljs.highlightElement(el)
  } catch {
    // 高亮失败不阻断文本展示
  }
}

function close() {
  emit('update:visible', false)
}

function download() {
  if (props.file) emit('download', props.file)
}

watch(
  () => props.visible,
  (v) => {
    if (v && props.file) loadContent()
    else if (!v) resetState()
  },
)

watch(
  () => props.file?.id,
  (id) => {
    if (id && props.visible) loadContent()
  },
)

onUnmounted(() => {
  if (pdfUrl.value) URL.revokeObjectURL(pdfUrl.value)
})
</script>

<template>
  <NDrawer
    :show="visible"
    placement="right"
    :width="'100%'"
    :auto-focus="false"
    @update:show="(v: boolean) => emit('update:visible', v)"
  >
    <NDrawerContent :native-scrollbar="false" :closable="false" body-content-style="padding:0;">
      <div class="preview">
        <header class="preview__bar">
          <button class="preview__icon-btn" type="button" :aria-label="t('pages.mobile.files.preview.close')" @click="close">
            <span class="material-symbols-outlined">arrow_back</span>
          </button>
          <div class="preview__title" :title="file?.name">{{ file?.name }}</div>

          <div v-if="kind === 'html'" class="preview__tabs">
            <button
              type="button"
              class="tab"
              :class="{ 'tab--active': htmlTab === 'render' }"
              @click="htmlTab = 'render'"
            >{{ t('pages.mobile.files.preview.render') }}</button>
            <button
              type="button"
              class="tab"
              :class="{ 'tab--active': htmlTab === 'source' }"
              @click="htmlTab = 'source'"
            >{{ t('pages.mobile.files.preview.source') }}</button>
          </div>
          <button
            v-else
            class="preview__icon-btn"
            type="button"
            :aria-label="t('pages.mobile.files.preview.download')"
            @click="download"
          >
            <span class="material-symbols-outlined">download</span>
          </button>
        </header>

        <!--
          内容层：各 kind 用独立 v-if（非 loading 门控），保证 docx 容器在 loadContent 执行时已在 DOM。
          loading/error 作为绝对定位覆盖层叠在其上，避免容器时序问题。
        -->
        <div class="preview__body">
          <div v-if="kind === 'image' && imageDataUrl" class="preview__media">
            <img :src="imageDataUrl" :alt="file?.name" />
          </div>

          <div v-else-if="kind === 'pdf' && pdfUrl" class="preview__pdf">
            <PdfViewer :url="pdfUrl" />
          </div>

          <iframe
            v-else-if="kind === 'docx'"
            ref="docxIframe"
            class="preview__docx-frame"
            sandbox="allow-same-origin"
          />

          <div v-else-if="kind === 'spreadsheet' || kind === 'csv'" class="preview__sheet">
            <div v-if="sheetNames.length > 1" class="sheet__tabs">
              <button
                v-for="name in sheetNames"
                :key="name"
                type="button"
                class="sheet__tab"
                :class="{ 'sheet__tab--active': name === activeSheet }"
                @click="activeSheet = name"
              >{{ name }}</button>
            </div>
            <div class="sheet__table-wrap">
              <table v-if="tableRows.length" class="sheet__table">
                <thead>
                  <tr>
                    <th class="row-num">#</th>
                    <th v-for="(h, i) in tableRows[0]" :key="i">{{ h }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(row, r) in tableRows.slice(1)" :key="r">
                    <td class="row-num">{{ r + 1 }}</td>
                    <td v-for="(cell, c) in row" :key="c">{{ cell }}</td>
                  </tr>
                </tbody>
              </table>
              <div v-else class="sheet__empty">{{ t('pages.mobile.files.preview.empty') }}</div>
            </div>
          </div>

          <iframe
            v-else-if="kind === 'html' && htmlTab === 'render'"
            class="preview__iframe"
            :srcdoc="textContent"
            sandbox="allow-scripts"
          />

          <pre v-else-if="kind === 'html' && htmlTab === 'source'" class="preview__source">{{ textContent }}</pre>

          <div
            v-else-if="kind === 'markdown'"
            class="preview__markdown markdown-body"
            v-html="renderedMarkdown"
          />

          <pre v-else-if="kind === 'code'" class="preview__code"><code ref="codeRef">{{ textContent }}</code></pre>

          <pre v-else-if="kind === 'text'" class="preview__text">{{ textContent }}</pre>

          <div v-else-if="kind === 'unsupported'" class="preview__state preview__unsupported">
            <span class="material-symbols-outlined preview__unsupported-icon">draft</span>
            <p class="preview__unsupported-text">{{ t('pages.mobile.files.preview.unsupported') }}</p>
            <NButton type="primary" @click="download">{{ t('pages.mobile.files.preview.download') }}</NButton>
          </div>

          <!-- 覆盖层 -->
          <div v-if="loading" class="preview__overlay">
            <NSpin size="medium" />
          </div>
          <div v-else-if="errorMsg" class="preview__overlay preview__overlay--error">{{ errorMsg }}</div>
        </div>
      </div>
    </NDrawerContent>
  </NDrawer>
</template>

<style scoped>
.preview {
  display: flex;
  flex-direction: column;
  height: 100vh;
  height: 100dvh;
  background: var(--m-bg-page, var(--m-bg-card));
}

/* 顶部栏 */
.preview__bar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: calc(env(safe-area-inset-top) + 10px) 12px 10px;
  background: var(--m-bg-card);
  border-bottom: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-soft);
}
.preview__icon-btn {
  flex-shrink: 0;
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  border: 0;
  background: transparent;
  color: var(--m-text-primary);
  cursor: pointer;
  transition: background 0.16s ease;
  -webkit-tap-highlight-color: transparent;
}
.preview__icon-btn:active {
  background: var(--m-primary-light);
}
.preview__icon-btn .material-symbols-outlined {
  font-size: 22px;
}
.preview__title {
  flex: 1;
  min-width: 0;
  font-size: 15px;
  font-weight: 700;
  color: var(--m-text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* HTML 渲染/源码切换 */
.preview__tabs {
  flex-shrink: 0;
  display: flex;
  gap: 2px;
  padding: 3px;
  border-radius: 12px;
  background: var(--m-bg-input, var(--m-avatar-bg));
}
.tab {
  padding: 6px 14px;
  border: 0;
  border-radius: 9px;
  background: transparent;
  color: var(--m-text-hint);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.tab--active {
  background: var(--m-bg-card);
  color: var(--m-primary);
  box-shadow: var(--m-shadow-soft);
}

/* 内容区 */
.preview__body {
  flex: 1;
  min-height: 0;
  overflow: auto;
  position: relative;
  -webkit-overflow-scrolling: touch;
}

/* loading / error 覆盖层（绝对定位，不抢占内容流） */
.preview__overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  background: var(--m-bg-page, var(--m-bg-card));
  z-index: 3;
  -webkit-backdrop-filter: blur(2px);
  backdrop-filter: blur(2px);
}
.preview__overlay--error {
  color: var(--m-danger);
  text-align: center;
  white-space: pre-wrap;
  word-break: break-word;
  font-size: 14px;
  line-height: 1.6;
}

.preview__state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  min-height: 100%;
  padding: 48px 24px;
  text-align: center;
  color: var(--m-text-hint);
}

/* 图片 */
.preview__media {
  display: flex;
  align-items: flex-start;
  justify-content: center;
  min-height: 100%;
  padding: 16px;
  background: var(--m-bg-page, #000);
}
.preview__media img {
  max-width: 100%;
  height: auto;
  border-radius: 12px;
  box-shadow: var(--m-shadow-card);
}

/* PDF（让 PdfViewer 填满，覆盖其默认 70vh） */
.preview__pdf {
  height: 100%;
  min-height: 0;
}
.preview__pdf :deep(.pdf-viewer) {
  height: 100%;
  min-height: 0;
  border: 0;
  border-radius: 0;
  background: var(--m-bg-page, #525659);
}
.preview__pdf :deep(.pdf-container) {
  padding: 8px;
}

/* Word（渲染进 sandbox iframe，docx-preview 受控排版 + 脚本隔离；样式在 iframe 内 document 注入） */
.preview__docx-frame {
  display: block;
  width: 100%;
  height: 100%;
  min-height: 100dvh;
  border: 0;
  background: #fff;
}

/* 电子表格 / CSV */
.preview__sheet {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  background: var(--m-bg-card);
}
.sheet__tabs {
  flex-shrink: 0;
  display: flex;
  gap: 6px;
  padding: 8px 12px;
  overflow-x: auto;
  background: var(--m-bg-card);
  border-bottom: 1px solid var(--m-border);
  -webkit-overflow-scrolling: touch;
}
.sheet__tab {
  flex-shrink: 0;
  padding: 6px 14px;
  border: 0;
  border-radius: 8px;
  background: var(--m-avatar-bg);
  color: var(--m-text-hint);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.16s ease;
  -webkit-tap-highlight-color: transparent;
}
.sheet__tab--active {
  background: var(--m-primary);
  color: #fff;
}
.sheet__table-wrap {
  flex: 1;
  overflow: auto;
  -webkit-overflow-scrolling: touch;
}
.sheet__table {
  border-collapse: collapse;
  font-size: 12.5px;
  white-space: nowrap;
}
.sheet__table th,
.sheet__table td {
  padding: 7px 11px;
  border: 1px solid var(--m-border);
  text-align: left;
  color: var(--m-text-primary);
}
.sheet__table th {
  background: var(--m-avatar-bg);
  font-weight: 700;
  position: sticky;
  top: 0;
  z-index: 1;
}
.sheet__table .row-num {
  color: var(--m-text-hint);
  text-align: right;
  background: var(--m-bg-card);
  position: sticky;
  left: 0;
  z-index: 1;
  font-variant-numeric: tabular-nums;
}
.sheet__empty {
  padding: 48px 24px;
  text-align: center;
  color: var(--m-text-hint);
  font-size: 14px;
}

/* HTML iframe */
.preview__iframe {
  display: block;
  width: 100%;
  height: 100%;
  min-height: 100dvh;
  border: 0;
  background: #fff;
}

/* 源码 / 文本 / 代码 */
.preview__source,
.preview__text,
.preview__code {
  margin: 0;
  padding: 14px 16px calc(48px + env(safe-area-inset-bottom));
  font-family: 'SF Mono', 'JetBrains Mono', 'Cascadia Code', Menlo, Consolas, monospace;
  font-size: 12.5px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
  color: var(--m-text-primary);
  background: var(--m-bg-card);
}
.preview__code {
  white-space: pre;
  overflow-x: auto;
  background: #0d1117;
}
.preview__code code {
  font-family: inherit;
  background: transparent;
  padding: 0;
}

/* Markdown */
.preview__markdown {
  padding: 16px 18px calc(48px + env(safe-area-inset-bottom));
  font-size: 14.5px;
  line-height: 1.75;
  color: var(--m-text-primary);
  word-break: break-word;
}
.preview__markdown :deep(h1),
.preview__markdown :deep(h2),
.preview__markdown :deep(h3),
.preview__markdown :deep(h4),
.preview__markdown :deep(h5),
.preview__markdown :deep(h6) {
  margin: 1.4em 0 0.6em;
  font-weight: 700;
  line-height: 1.3;
}
.preview__markdown :deep(h1) { font-size: 1.5em; }
.preview__markdown :deep(h2) { font-size: 1.3em; }
.preview__markdown :deep(h3) { font-size: 1.15em; }
.preview__markdown :deep(p) { margin: 0.7em 0; }
.preview__markdown :deep(a) { color: var(--m-primary); text-decoration: none; }
.preview__markdown :deep(a:active) { text-decoration: underline; }
.preview__markdown :deep(ul),
.preview__markdown :deep(ol) { margin: 0.7em 0; padding-left: 1.5em; }
.preview__markdown :deep(li) { margin: 0.3em 0; }
.preview__markdown :deep(blockquote) {
  margin: 0.9em 0;
  padding: 0.2em 0.9em;
  border-left: 3px solid var(--m-primary);
  background: var(--m-primary-light);
  border-radius: 0 8px 8px 0;
  color: var(--m-text-secondary, var(--m-text-primary));
}
.preview__markdown :deep(code) {
  padding: 0.15em 0.4em;
  border-radius: 5px;
  font-family: 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  font-size: 0.88em;
  background: var(--m-avatar-bg);
}
.preview__markdown :deep(pre) {
  margin: 0.9em 0;
  padding: 12px 14px;
  border-radius: 10px;
  overflow-x: auto;
  background: #0d1117;
}
.preview__markdown :deep(pre code) {
  padding: 0;
  background: transparent;
  color: inherit;
}
.preview__markdown :deep(img) { max-width: 100%; border-radius: 8px; }
.preview__markdown :deep(table) {
  width: 100%;
  margin: 0.9em 0;
  border-collapse: collapse;
  font-size: 0.92em;
}
.preview__markdown :deep(th),
.preview__markdown :deep(td) {
  padding: 8px 10px;
  border: 1px solid var(--m-border);
  text-align: left;
}
.preview__markdown :deep(th) { background: var(--m-avatar-bg); font-weight: 700; }
.preview__markdown :deep(hr) {
  margin: 1.4em 0;
  border: 0;
  border-top: 1px solid var(--m-border);
}

/* 不支持格式 */
.preview__unsupported-icon {
  font-size: 56px;
  color: var(--m-text-hint);
}
.preview__unsupported-text {
  margin: 0;
  font-size: 14px;
  color: var(--m-text-hint);
}
</style>
