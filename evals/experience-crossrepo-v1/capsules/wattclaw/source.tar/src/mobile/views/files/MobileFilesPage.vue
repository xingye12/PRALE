<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { NDrawer, NDrawerContent, NModal, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { Icon } from '@iconify/vue'
import { useWorkspaceStore } from '@/stores/workspace'
import { useAuthStore } from '@/stores/auth'
import { apiPath } from '@/utils/api-path'
import { getFileMeta } from '@/utils/file-icons'
import { resolveAgentAvatar, isImageAvatar } from '@/utils/agent-avatar'
import {
  classifyFile,
  createFileNodeId,
  findNodeByPath,
  flattenFiles,
  formatSize,
  listDirLevel,
  normalizeEntries,
  splitPathSegments,
  type AgentFileTree,
  type FileEntry,
  type FileTypeFilter,
} from '@/utils/file-classify'
import { base64ToBlob } from '@/utils/file-blob'
import EmptyState from '@/components/common/EmptyState.vue'
import MobileFilePreview from './MobileFilePreview.vue'

const { t } = useI18n()
const message = useMessage()
const workspaceStore = useWorkspaceStore()
const authStore = useAuthStore()

interface BatchAgentInfo {
  workspace: string
  name: string
  files: Array<Record<string, unknown>>
}
interface WorkspaceAgentLike {
  agentId: string
  name?: string
  ownerName?: string
  avatar?: string
  templateId?: string
  identity?: { name?: string; avatarUrl?: string; avatar?: string; emoji?: string; templateId?: string }
}

const agentTrees = ref<AgentFileTree[]>([])
const loading = ref(false)
const errorMsg = ref('')

const currentType = ref<FileTypeFilter>('all')
const currentAgentId = ref<string>('')
const currentPath = ref<string>('')

const showTypeDrawer = ref(false)
const showAgentDrawer = ref(false)
const showActionSheet = ref(false)
const targetFile = ref<FileEntry | null>(null)
const showDeleteConfirm = ref(false)
const deleting = ref(false)

const previewVisible = ref(false)
const previewFile = ref<FileEntry | null>(null)

const categoryDefs = computed(() => [
  { type: 'all' as const, label: t('pages.fileManager.types.all'), icon: 'folder_open' },
  { type: 'doc' as const, label: t('pages.fileManager.types.doc'), icon: 'description' },
  { type: 'sheet' as const, label: t('pages.fileManager.types.sheet'), icon: 'table_chart' },
  { type: 'image' as const, label: t('pages.fileManager.types.image'), icon: 'image' },
  { type: 'code' as const, label: t('pages.fileManager.types.code'), icon: 'code' },
  { type: 'ppt' as const, label: t('pages.fileManager.types.ppt'), icon: 'slideshow' },
  { type: 'pdf' as const, label: t('pages.fileManager.types.pdf'), icon: 'picture_as_pdf' },
  { type: 'other' as const, label: t('pages.fileManager.types.other'), icon: 'more_horiz' },
])

interface AgentOption {
  agentId: string
  name: string
  avatar: string
  templateId?: string
}

// 数字员工下拉与文件 batch-list 的 agentId 同源（workspaceStore），保证筛选值匹配
const agentOptions = computed<AgentOption[]>(() =>
  workspaceStore.agents.map((agent) => {
    const a = agent as unknown as WorkspaceAgentLike
    const name = a.identity?.name || a.name || a.agentId
    const avatar = a.identity?.avatarUrl || a.identity?.avatar || a.avatar || a.identity?.emoji || '🤖'
    return { agentId: a.agentId, name, avatar, templateId: a.templateId || a.identity?.templateId }
  }),
)

// 当前选中员工的文件树(单员工模式)
const currentTree = computed<AgentFileTree | undefined>(() =>
  agentTrees.value.find((t) => t.agentId === currentAgentId.value),
)

// 当前路径下一层:子目录 + 文件(目录在前;目录按名,文件按 modifiedAt 降序)
const currentLevel = computed<{ dirs: FileEntry[]; files: FileEntry[] }>(() => {
  const tree = currentTree.value
  if (!tree) return { dirs: [], files: [] }
  return listDirLevel(tree.root, currentPath.value)
})

const currentDirs = computed(() => {
  const dirs = currentLevel.value.dirs
  const type = currentType.value
  if (type === 'all') return dirs
  // 选定类型后,只保留自身或子孙目录含该类型文件的文件夹(避免点进去是空的)
  return dirs.filter((dir) => flattenFiles(dir.children || []).some((f) => classifyFile(f) === type))
})

// 类型筛选作用于当前层文件(单员工模式)
const visibleFiles = computed(() => {
  const type = currentType.value
  const files = currentLevel.value.files
  return type === 'all' ? files : files.filter((f) => classifyFile(f) === type)
})

// 类型计数:单员工基于该员工整棵树的所有文件(含子目录);全部模式基于所有员工全部文件
const typeCounts = computed<Record<FileTypeFilter, number>>(() => {
  const counts: Record<FileTypeFilter, number> = { all: 0, doc: 0, sheet: 0, image: 0, code: 0, ppt: 0, pdf: 0, other: 0 }
  const base = currentAgentId.value
    ? flattenFiles(currentTree.value?.root.children || [])
    : agentTrees.value.flatMap((t) => flattenFiles(t.root.children || []))
  for (const f of base) {
    counts.all++
    counts[classifyFile(f)]++
  }
  return counts
})

// 全部文件总数(hero 计数)
const totalCount = computed(() =>
  agentTrees.value.reduce((sum, t) => sum + flattenFiles(t.root.children || []).length, 0),
)

// 全部模式员工条目:按当前类型筛选,仅含该类型有文件的员工,附该类型文件数角标
const agentOptionsWithCount = computed<{ agentId: string; name: string; avatar: string; templateId?: string; count: number }[]>(() => {
  const type = currentType.value
  return agentOptions.value
    .map((opt) => {
      const tree = agentTrees.value.find((t) => t.agentId === opt.agentId)
      const files = tree ? flattenFiles(tree.root.children || []) : []
      const count = type === 'all' ? files.length : files.filter((f) => classifyFile(f) === type).length
      return { ...opt, count }
    })
    .filter((opt) => opt.count > 0)
})

const currentTypeIcon = computed(() => categoryDefs.value.find((c) => c.type === currentType.value)?.icon || 'folder_open')
const currentTypeLabel = computed(() => categoryDefs.value.find((c) => c.type === currentType.value)?.label || t('pages.fileManager.types.all'))
const currentAgentLabel = computed(() => {
  if (!currentAgentId.value) return t('pages.mobile.files.allAgents')
  return agentOptions.value.find((a) => a.agentId === currentAgentId.value)?.name || t('pages.mobile.files.allAgents')
})
const currentAgentOption = computed(() =>
  currentAgentId.value ? agentOptions.value.find((a) => a.agentId === currentAgentId.value) : undefined,
)

// 面包屑:全部模式 [全部];单员工 [员工名, ...路径段](每段带累积 path 供点击跳转)
const breadcrumb = computed<{ label: string; path: string; isAgent?: boolean; isAll?: boolean }[]>(() => {
  if (!currentAgentId.value) {
    return [{ label: t('pages.mobile.files.allAgents'), path: '', isAll: true }]
  }
  const segs: { label: string; path: string; isAgent?: boolean }[] = [
    { label: currentAgentLabel.value, path: '', isAgent: true },
  ]
  let acc = ''
  for (const seg of splitPathSegments(currentPath.value)) {
    acc = acc ? `${acc}/${seg}` : seg
    segs.push({ label: seg, path: acc })
  }
  return segs
})

function authHeaders(): Record<string, string> {
  const token = (authStore.getToken as unknown as (() => string) | undefined)?.() || (authStore as unknown as { token?: string }).token
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function fetchJson(url: string): Promise<unknown> {
  const res = await fetch(apiPath(url), { headers: authHeaders() })
  const data = (await res.json()) as { ok?: boolean; error?: { message?: string } }
  if (!res.ok || !data.ok) throw new Error(data.error?.message || `HTTP ${res.status}`)
  return data
}

async function loadFiles() {
  loading.value = true
  errorMsg.value = ''
  try {
    if (workspaceStore.agents.length === 0) await workspaceStore.loadAgents()
    const data = (await fetchJson('/api/files/batch-list')) as { agents: Record<string, BatchAgentInfo> }
    const trees: AgentFileTree[] = []
    for (const [agentId, info] of Object.entries(data.agents || {})) {
      const agent = workspaceStore.agents.find((a) => a.agentId === agentId) as unknown as WorkspaceAgentLike | undefined
      const agentName = info.name || agent?.name || agentId
      const ownerUserName = agent?.ownerName || ''
      const children = normalizeEntries(
        info.files || [],
        { agentId, name: agentName, ownerUserName },
        info.workspace,
        t('pages.fileManager.unknownFile'),
      )
      trees.push({
        agentId,
        agentName,
        workspace: info.workspace,
        root: {
          id: createFileNodeId(agentId, info.workspace, '/'),
          name: agentName,
          path: '',
          type: 'directory',
          isDirectory: true,
          agentId,
          agentName,
          ownerUserName,
          workspace: info.workspace,
          children,
        },
      })
    }
    agentTrees.value = trees
    // 默认显示全部数字员工;仅当之前选中的员工在新树已不存在时回退全部
    if (currentAgentId.value && !trees.some((t) => t.agentId === currentAgentId.value)) {
      currentAgentId.value = ''
    }
    // currentPath 在新树仍存在→保持(删文件后重载留在原目录);不存在→回根
    const activeTree = trees.find((t) => t.agentId === currentAgentId.value)
    if (activeTree && currentPath.value && !findNodeByPath(activeTree.root, currentPath.value)) {
      currentPath.value = ''
    }
  } catch (e) {
    errorMsg.value = e instanceof Error ? e.message : t('pages.mobile.files.loadFailed')
    agentTrees.value = []
  } finally {
    loading.value = false
  }
}

function fileIcon(name: string): string {
  return `vscode-icons:${getFileMeta(name).icon}`
}

function openAction(file: FileEntry) {
  targetFile.value = file
  showActionSheet.value = true
}

function askDelete() {
  showActionSheet.value = false
  showDeleteConfirm.value = true
}

async function confirmDelete() {
  const f = targetFile.value
  if (!f) return
  deleting.value = true
  try {
    const res = await fetch(apiPath('/api/files/delete'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ path: f.path, workspace: f.workspace }),
    })
    const data = (await res.json()) as { ok?: boolean }
    if (!res.ok || !data.ok) throw new Error('failed')
    showDeleteConfirm.value = false
    message.success(t('pages.mobile.files.deleteSuccess'))
    await loadFiles()
  } catch {
    message.error(t('pages.mobile.files.deleteFailed'))
  } finally {
    deleting.value = false
  }
}

function openPreview(file: FileEntry) {
  previewFile.value = file
  previewVisible.value = true
}

// 统一走 binary=true：后端对任意文件返回 base64，前端解码为 Blob 后下载，
// 修正旧实现把二进制文件的 base64 字符串当文本写入的问题。
async function downloadFile(f: FileEntry) {
  try {
    const res = await fetch(
      apiPath(`/api/files/get?path=${encodeURIComponent(f.path)}&workspace=${encodeURIComponent(f.workspace)}&binary=true`),
      { headers: authHeaders() },
    )
    const data = (await res.json()) as { ok?: boolean; content?: string; error?: { message?: string } }
    if (!res.ok || !data.ok) throw new Error(data.error?.message || 'failed')
    const content = data.content || ''
    if (!content) {
      message.warning(t('pages.mobile.files.noContent'))
      return
    }
    const blob = base64ToBlob(content, 'application/octet-stream')
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = f.name
    a.click()
    URL.revokeObjectURL(url)
  } catch {
    message.error(t('pages.mobile.files.downloadFailed'))
  }
}

function handlePreviewDownload(file: FileEntry) {
  downloadFile(file)
}

async function downloadTarget() {
  const f = targetFile.value
  if (!f) return
  showActionSheet.value = false
  await downloadFile(f)
}

function formatTime(iso?: string): string {
  if (!iso) return '-'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function pickType(type: FileTypeFilter) {
  currentType.value = type
  showTypeDrawer.value = false
}
function pickAgent(agentId: string) {
  currentAgentId.value = agentId
  currentPath.value = ''
  showAgentDrawer.value = false
}
function agentDisplayAvatar(opt: AgentOption): string {
  return resolveAgentAvatar(opt.templateId, opt.avatar || '🤖')
}
// 进入子目录
function enterDir(dir: FileEntry) {
  currentPath.value = dir.path
}
// 面包屑点击跳到指定累积 path(''=该员工根)
function goToPath(path: string) {
  currentPath.value = path
}
// 返回上一层
function goUp() {
  const segs = splitPathSegments(currentPath.value)
  segs.pop()
  currentPath.value = segs.join('/')
}
// 进入某员工的文件树(全部模式员工条目点击)
function enterAgent(agentId: string) {
  currentAgentId.value = agentId
  currentPath.value = ''
}
// 返回全部员工列表
function backToAll() {
  currentAgentId.value = ''
  currentPath.value = ''
}

onMounted(loadFiles)
</script>

<template>
  <div class="mobile-page files-page">
    <div class="files-canvas">
      <!-- Hero -->
      <header class="hero fade-up" style="--d: 0ms">
        <h1 class="hero__title">{{ t('pages.mobile.files.title') }}</h1>
        <p class="hero__sub">{{ t('pages.mobile.files.countLabel', { n: totalCount }) }}</p>
      </header>

      <!-- 筛选栏：文件类型 + 数字员工（并排胶囊） -->
      <div class="filters fade-up" style="--d: 90ms">
        <button class="filter-pill" type="button" @click="showTypeDrawer = true">
          <span class="material-symbols-outlined filter-pill__icon">{{ currentTypeIcon }}</span>
          <span class="filter-pill__label">{{ currentTypeLabel }}</span>
          <span class="material-symbols-outlined filter-pill__caret">expand_more</span>
        </button>
        <button class="filter-pill" type="button" @click="showAgentDrawer = true">
          <img
            v-if="currentAgentOption && isImageAvatar(agentDisplayAvatar(currentAgentOption))"
            v-avatar-fallback
            :src="agentDisplayAvatar(currentAgentOption)"
            class="filter-pill__avatar"
            alt=""
          />
          <span
            v-else-if="currentAgentOption"
            class="filter-pill__avatar filter-pill__avatar--emoji"
          >{{ agentDisplayAvatar(currentAgentOption) }}</span>
          <span v-else class="material-symbols-outlined filter-pill__icon">smart_toy</span>
          <span class="filter-pill__label">{{ currentAgentLabel }}</span>
          <span class="material-symbols-outlined filter-pill__caret">expand_more</span>
        </button>
      </div>

      <!-- 面包屑(单员工模式) -->
      <nav v-if="currentAgentId" class="breadcrumb fade-up" style="--d: 120ms">
        <button class="material-symbols-outlined breadcrumb__back" type="button" @click="currentPath ? goUp() : backToAll()">chevron_left</button>
        <ol class="breadcrumb__list">
          <li v-for="(seg, idx) in breadcrumb" :key="idx" class="breadcrumb__item">
            <button
              type="button"
              class="breadcrumb__seg"
              :class="{ 'breadcrumb__seg--active': idx === breadcrumb.length - 1 }"
              @click="goToPath(seg.path)"
            >{{ seg.label }}</button>
            <span v-if="idx < breadcrumb.length - 1" class="material-symbols-outlined breadcrumb__sep">chevron_right</span>
          </li>
        </ol>
      </nav>

      <!-- 列表 -->
      <section class="list fade-up" style="--d: 160ms">
        <div v-if="loading" class="state-hint">{{ t('pages.mobile.files.loading') }}</div>
        <div v-else-if="errorMsg" class="state-hint state-hint--error">{{ errorMsg }}</div>

        <!-- 全部模式:员工条目列表 -->
        <EmptyState v-else-if="!currentAgentId && agentTrees.length === 0" :description="t('pages.mobile.files.empty')" />
        <ul v-else-if="!currentAgentId" class="file-list">
          <li
            v-for="(opt, i) in agentOptionsWithCount"
            :key="opt.agentId"
            class="agent-row fade-up"
            :style="{ '--d': `${Math.min(i, 10) * 35}ms` }"
            @click="enterAgent(opt.agentId)"
          >
            <img
              v-if="isImageAvatar(agentDisplayAvatar(opt))"
              v-avatar-fallback
              :src="agentDisplayAvatar(opt)"
              class="agent-row__avatar"
              alt=""
            />
            <span v-else class="agent-row__avatar agent-row__avatar--emoji">{{ agentDisplayAvatar(opt) }}</span>
            <div class="agent-row__body">
              <div class="agent-row__name">{{ opt.name }}</div>
              <div class="agent-row__meta">{{ t('pages.mobile.files.fileCount', { n: opt.count }) }}</div>
            </div>
            <span class="material-symbols-outlined agent-row__caret">chevron_right</span>
          </li>
        </ul>

        <!-- 单员工模式:目录 + 文件 -->
        <EmptyState
          v-else-if="currentDirs.length === 0 && visibleFiles.length === 0"
          :description="t('pages.mobile.files.empty')"
        />
        <ul v-else class="file-list">
          <li
            v-for="dir in currentDirs"
            :key="dir.id"
            class="file-item"
            @click="enterDir(dir)"
          >
            <span class="material-symbols-outlined file-item__icon file-item__icon--dir">folder</span>
            <div class="file-item__body">
              <div class="file-item__name">{{ dir.name }}</div>
            </div>
            <span class="material-symbols-outlined file-item__more">chevron_right</span>
          </li>
          <li
            v-for="(f, i) in visibleFiles"
            :key="f.id"
            class="file-item fade-up"
            :style="{ '--d': `${Math.min(i, 10) * 35}ms` }"
            @click="openPreview(f)"
          >
            <Icon :icon="fileIcon(f.name)" class="file-item__icon" />
            <div class="file-item__body">
              <div class="file-item__name">{{ f.name }}</div>
              <div class="file-item__meta">
                {{ formatTime(f.modifiedAt) }} · {{ formatSize(f.size) }}
              </div>
            </div>
            <span class="file-item__more material-symbols-outlined" @click.stop="openAction(f)">more_vert</span>
          </li>
        </ul>
      </section>
    </div>

    <!-- 文件类型选择 -->
    <NDrawer v-model:show="showTypeDrawer" placement="bottom" :auto-focus="false">
      <NDrawerContent :native-scrollbar="false" :closable="false" body-content-style="padding: 0;">
        <div class="sheet">
          <div class="sheet__handle" />
          <div class="sheet__title">{{ t('pages.mobile.files.selectType') }}</div>
          <ul class="sheet__list">
            <li
              v-for="c in categoryDefs"
              :key="c.type"
              class="sheet__item"
              :class="{ 'sheet__item--active': c.type === currentType }"
              @click="pickType(c.type)"
            >
              <span class="material-symbols-outlined sheet__item-icon">{{ c.icon }}</span>
              <span class="sheet__item-label">{{ c.label }}</span>
              <span class="sheet__item-count">{{ typeCounts[c.type] }}</span>
              <span v-if="c.type === currentType" class="material-symbols-outlined sheet__item-check">check</span>
            </li>
          </ul>
        </div>
      </NDrawerContent>
    </NDrawer>

    <!-- 数字员工选择（只显头像 + 名称） -->
    <NDrawer v-model:show="showAgentDrawer" placement="bottom" :auto-focus="false">
      <NDrawerContent :native-scrollbar="false" :closable="false" body-content-style="padding: 0;">
        <div class="sheet">
          <div class="sheet__handle" />
          <div class="sheet__title">{{ t('pages.mobile.files.selectAgent') }}</div>
          <ul class="sheet__list">
            <li
              class="sheet__item"
              :class="{ 'sheet__item--active': currentAgentId === '' }"
              @click="pickAgent('')"
            >
              <span class="agent-avatar agent-avatar--all material-symbols-outlined">groups</span>
              <span class="sheet__item-label">{{ t('pages.mobile.files.allAgents') }}</span>
              <span v-if="currentAgentId === ''" class="material-symbols-outlined sheet__item-check">check</span>
            </li>
            <li
              v-for="opt in agentOptions"
              :key="opt.agentId"
              class="sheet__item"
              :class="{ 'sheet__item--active': currentAgentId === opt.agentId }"
              @click="pickAgent(opt.agentId)"
            >
              <img
                v-if="isImageAvatar(agentDisplayAvatar(opt))"
                v-avatar-fallback
                :src="agentDisplayAvatar(opt)"
                class="agent-avatar"
                alt=""
              />
              <span v-else class="agent-avatar agent-avatar--emoji">{{ agentDisplayAvatar(opt) }}</span>
              <span class="sheet__item-label">{{ opt.name }}</span>
              <span v-if="currentAgentId === opt.agentId" class="material-symbols-outlined sheet__item-check">check</span>
            </li>
          </ul>
        </div>
      </NDrawerContent>
    </NDrawer>

    <!-- 文件操作 Action Sheet -->
    <NDrawer v-model:show="showActionSheet" placement="bottom" :auto-focus="false">
      <NDrawerContent :native-scrollbar="false" :closable="false" body-content-style="padding: 0;">
        <div class="sheet">
          <div class="sheet__handle" />
          <div v-if="targetFile" class="sheet__target">{{ targetFile.name }}</div>
          <ul class="sheet__list">
            <li class="sheet__item" @click="downloadTarget">
              <span class="material-symbols-outlined sheet__item-icon">download</span>
              <span class="sheet__item-label">{{ t('pages.mobile.files.download') }}</span>
            </li>
            <li class="sheet__item sheet__item--danger" @click="askDelete">
              <span class="material-symbols-outlined sheet__item-icon">delete</span>
              <span class="sheet__item-label">{{ t('pages.mobile.files.delete') }}</span>
            </li>
          </ul>
        </div>
      </NDrawerContent>
    </NDrawer>

    <!-- 删除二次确认 -->
    <NModal
      v-model:show="showDeleteConfirm"
      preset="dialog"
      :title="t('pages.mobile.files.deleteConfirmTitle')"
      :content="targetFile ? t('pages.mobile.files.deleteConfirmText', { name: targetFile.name }) : ''"
      :positive-text="t('pages.mobile.files.delete')"
      :negative-text="t('pages.mobile.files.cancel')"
      type="warning"
      :positive-button-props="{ type: 'error', loading: deleting }"
      :mask-closable="!deleting"
      @positive-click="confirmDelete"
    />

    <MobileFilePreview
      v-model:visible="previewVisible"
      :file="previewFile"
      @download="handlePreviewDownload"
    />
  </div>
</template>

<style scoped>
.files-page {
  min-height: 100%;
}
.files-canvas {
  max-width: 480px;
  margin: 0 auto;
  padding: 0 16px calc(112px + env(safe-area-inset-bottom));
}

/* Hero */
.hero {
  padding: 24px 4px 18px;
}
.hero__title {
  margin: 0;
  font-size: 26px;
  font-weight: 800;
  letter-spacing: -0.02em;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.hero__sub {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--m-text-hint);
}

/* 筛选栏 */
.filters {
  display: flex;
  gap: 10px;
  margin-bottom: 14px;
}
.filter-pill {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  padding: 10px 12px;
  border-radius: 14px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-soft);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
  color: var(--m-text-primary);
  font: inherit;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.12s ease, box-shadow 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.filter-pill:active {
  transform: scale(0.97);
}
.filter-pill__icon {
  font-size: 18px;
  color: var(--m-primary);
  flex-shrink: 0;
}
.filter-pill__avatar {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
  background: var(--m-avatar-bg);
}
.filter-pill__avatar--emoji {
  display: grid;
  place-items: center;
  font-size: 13px;
  line-height: 1;
}
.filter-pill__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.filter-pill__caret {
  font-size: 18px;
  color: var(--m-text-hint);
  flex-shrink: 0;
}

/* 列表 */
.list {
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-card);
  overflow: hidden;
}
.file-list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.file-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-top: 1px solid var(--m-divider);
  cursor: pointer;
  transition: background 0.16s ease;
}
.file-item:first-child {
  border-top: 0;
}
.file-item:active {
  background: var(--m-primary-light);
}
.file-item__icon {
  flex-shrink: 0;
  font-size: 30px;
}
.file-item__body {
  flex: 1;
  min-width: 0;
}
.file-item__name {
  font-size: 14px;
  font-weight: 600;
  color: var(--m-text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.file-item__meta {
  margin-top: 3px;
  font-size: 11.5px;
  color: var(--m-text-hint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.file-item__more {
  flex-shrink: 0;
  font-size: 20px;
  color: var(--m-text-hint);
}

/* 状态 */
.state-hint {
  padding: 48px 16px;
  text-align: center;
  font-size: 13px;
  color: var(--m-text-hint);
}
.state-hint--error {
  color: var(--m-danger);
}

/* 底部 Sheet（NDrawer 内容） */
.sheet {
  padding: 8px 4px calc(12px + env(safe-area-inset-bottom));
}
.sheet__handle {
  width: 36px;
  height: 4px;
  margin: 6px auto 10px;
  border-radius: 2px;
  background: var(--m-divider);
}
.sheet__title {
  padding: 4px 16px 10px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--m-text-hint);
}
.sheet__target {
  padding: 4px 16px 10px;
  font-size: 14px;
  font-weight: 700;
  color: var(--m-text-primary);
  word-break: break-all;
}
.sheet__list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.sheet__item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 16px;
  cursor: pointer;
  transition: background 0.16s ease;
}
.sheet__item:active {
  background: var(--m-primary-light);
}
.sheet__item--active {
  color: var(--m-primary);
}
.sheet__item-icon {
  font-size: 22px;
  color: var(--m-primary);
  flex-shrink: 0;
}
.sheet__item-label {
  flex: 1;
  font-size: 15px;
  font-weight: 600;
  color: var(--m-text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sheet__item-count {
  font-size: 12px;
  color: var(--m-text-hint);
  background: var(--m-avatar-bg);
  padding: 2px 8px;
  border-radius: 10px;
}
.sheet__item-check {
  font-size: 20px;
  color: var(--m-primary);
  flex-shrink: 0;
}
.sheet__item--danger .sheet__item-icon,
.sheet__item--danger .sheet__item-label {
  color: var(--m-danger);
}

/* 数字员工头像（选择器内） */
.agent-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  font-size: 18px;
  background: var(--m-avatar-bg);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.4);
}
.agent-avatar--all {
  color: var(--m-primary);
  font-size: 20px;
}
.agent-avatar--emoji {
  line-height: 1;
}

/* 入场动画 */
.fade-up {
  opacity: 0;
  animation: fade-up 0.55s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@media (prefers-reduced-motion: reduce) {
  .fade-up {
    animation: none;
    opacity: 1;
  }
}

/* 面包屑 */
.breadcrumb {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 12px;
  padding: 6px 10px;
  border-radius: 12px;
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-soft);
}
.breadcrumb__back {
  flex-shrink: 0;
  font-size: 22px;
  color: var(--m-text-hint);
  background: none;
  border: none;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.breadcrumb__list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  align-items: center;
  gap: 2px;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.breadcrumb__list::-webkit-scrollbar {
  display: none;
}
.breadcrumb__item {
  display: flex;
  align-items: center;
  gap: 2px;
  flex-shrink: 0;
}
.breadcrumb__seg {
  background: none;
  border: none;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
  color: var(--m-text-hint);
  padding: 4px 6px;
  border-radius: 8px;
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.breadcrumb__seg--active {
  color: var(--m-text-primary);
}
.breadcrumb__sep {
  font-size: 18px;
  color: var(--m-text-hint);
  flex-shrink: 0;
}

/* 全部模式员工条目 */
.agent-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-top: 1px solid var(--m-divider);
  cursor: pointer;
  transition: background 0.16s ease;
}
.agent-row:first-child {
  border-top: 0;
}
.agent-row:active {
  background: var(--m-primary-light);
}
.agent-row__avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
  background: var(--m-avatar-bg);
}
.agent-row__avatar--emoji {
  display: grid;
  place-items: center;
  font-size: 22px;
  line-height: 1;
}
.agent-row__body {
  flex: 1;
  min-width: 0;
}
.agent-row__name {
  font-size: 15px;
  font-weight: 600;
  color: var(--m-text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.agent-row__meta {
  margin-top: 3px;
  font-size: 11.5px;
  color: var(--m-text-hint);
}
.agent-row__caret {
  flex-shrink: 0;
  font-size: 20px;
  color: var(--m-text-hint);
}

/* 目录项 */
.file-item__icon--dir {
  color: var(--m-primary);
}
</style>
