<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { NInput, NButton } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import type { FeishuAuthorizeResponse } from '@/api/types/feishu-auth'
import { apiPath } from '@/utils/api-path'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const { t } = useI18n()

const username = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')
const feishuConfig = ref<{ enabled: boolean }>({ enabled: false })
const feishuLoading = ref(false)

/** Detect Feishu/Lark in-app browser by User-Agent */
function isFeishuInAppBrowser(): boolean {
  return /Feishu|Lark/i.test(navigator.userAgent)
}

onMounted(async () => {
  // 拉取飞书登录配置
  try {
    const res = await fetch(apiPath('/api/auth/feishu/config'))
    if (res.ok) feishuConfig.value = await res.json()
  } catch {}

  // 飞书内置浏览器 + 已启用 + 非刚登出 → 自动发起飞书 OAuth
  if (
    feishuConfig.value.enabled &&
    isFeishuInAppBrowser() &&
    !sessionStorage.getItem('feishu_logout')
  ) {
    handleFeishuLogin()
  }
})

async function handleFeishuLogin() {
  feishuLoading.value = true
  error.value = ''
  // 标记来源移动端，供回调页 FeishuCallback 决定跳转目标 /m
  sessionStorage.setItem('feishu_mobile', '1')
  try {
    const res = await fetch(apiPath('/api/auth/feishu/authorize'))
    const data: FeishuAuthorizeResponse = await res.json()
    if (data.url) {
      window.location.href = data.url
    } else {
      error.value = t('pages.login.feishuAuthFailed')
      feishuLoading.value = false
    }
  } catch {
    error.value = t('pages.login.feishuServiceUnavailable')
    feishuLoading.value = false
  }
}

async function handleLogin() {
  if (!username.value || !password.value) {
    error.value = t('pages.mobile.login.credentialsRequired')
    return
  }
  loading.value = true
  error.value = ''

  const success = await authStore.login(username.value, password.value)
  if (success) {
    const raw = (route.query.redirect as string) || '/m/conversations'
    const safe = raw.startsWith('/') && !raw.startsWith('//') ? raw : '/m/conversations'
    router.push(safe)
  } else {
    error.value = authStore.error || t('pages.mobile.login.invalidCredentials')
    loading.value = false
  }
}

function handleKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter') handleLogin()
}
</script>

<template>
  <div class="mobile-page login-page">
    <div class="login-canvas">
      <!-- 光环 logo：halo 呼吸 + ring 旋转 + core 承载 favicon -->
      <div class="logo-orb fade-up" style="--d: 0ms">
        <span class="logo-orb__halo" aria-hidden="true"></span>
        <span class="logo-orb__ring" aria-hidden="true"></span>
        <span class="logo-orb__core">
          <img src="/favicon.png" alt="" class="logo-orb__img" />
        </span>
      </div>

      <h1 class="login-title fade-up" style="--d: 110ms">WattClaw</h1>
      <p class="login-subtitle fade-up" style="--d: 190ms">{{ t('pages.mobile.login.subtitle') }}</p>

      <!-- 毛玻璃表单卡 -->
      <div class="login-card fade-up" style="--d: 280ms">
        <div v-if="error" class="login-error">{{ error }}</div>

        <div class="field">
          <NInput
            v-model:value="username"
            :placeholder="t('pages.mobile.login.usernamePlaceholder')"
            :input-props="{ autocomplete: 'username' }"
            size="large"
            @keydown="handleKeydown"
          >
            <template #prefix>
              <span class="field__icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </span>
            </template>
          </NInput>
        </div>

        <div class="field">
          <NInput
            v-model:value="password"
            type="password"
            show-password-on="click"
            :placeholder="t('pages.mobile.login.passwordPlaceholder')"
            :input-props="{ autocomplete: 'current-password' }"
            size="large"
            @keydown="handleKeydown"
          >
            <template #prefix>
              <span class="field__icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
              </span>
            </template>
          </NInput>
        </div>

        <NButton
          type="primary"
          block
          size="large"
          :loading="loading"
          :disabled="loading"
          class="login-btn"
          @click="handleLogin"
        >
          {{ t('pages.mobile.login.submit') }}
        </NButton>

        <!-- 飞书登录：仅配置启用时显示 -->
        <template v-if="feishuConfig.enabled">
          <div class="login-divider fade-up" style="--d: 360ms">
            <span class="login-divider__line"></span>
            <span class="login-divider__text">{{ t('pages.login.orDivider') }}</span>
            <span class="login-divider__line"></span>
          </div>

          <NButton
            block
            size="large"
            :loading="feishuLoading"
            :disabled="feishuLoading || loading"
            class="feishu-btn fade-up"
            style="--d: 440ms"
            @click="handleFeishuLogin"
          >
            <span class="feishu-logo" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 21l21-9L2 3v7l15 2-15 2v7z" />
              </svg>
            </span>
            {{ t('pages.login.feishuLogin') }}
          </NButton>
        </template>
      </div>

    </div>
  </div>
</template>

<style scoped>
/* 仅做布局，背景极光由 .mobile-page 提供 */
.login-page {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: env(safe-area-inset-top) 24px calc(28px + env(safe-area-inset-bottom));
}

.login-canvas {
  width: 100%;
  max-width: 360px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* ===== 光环 logo（复用 Aurora orb 语言）===== */
.logo-orb {
  position: relative;
  width: 116px;
  height: 116px;
  margin-bottom: 22px;
}
.logo-orb__halo {
  position: absolute;
  inset: -18px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(37, 99, 235, 0.3), transparent 68%);
  filter: blur(8px);
  animation: orb-pulse 3.8s ease-in-out infinite;
}
.logo-orb__ring {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    var(--m-primary),
    var(--m-accent),
    var(--m-primary-strong),
    var(--m-accent),
    var(--m-primary)
  );
  -webkit-mask: radial-gradient(circle at center, transparent 0 48px, #000 49px);
  mask: radial-gradient(circle at center, transparent 0 48px, #000 49px);
  animation: orb-spin 7s linear infinite;
}
.logo-orb__core {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 96px;
  height: 96px;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  background: var(--m-avatar-bg);
  box-shadow: var(--m-shadow-soft), inset 0 0 0 1px rgba(255, 255, 255, 0.5);
  overflow: hidden;
  display: grid;
  place-items: center;
  padding: 16px;
}
.logo-orb__img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}

/* ===== 渐变标题 ===== */
.login-title {
  margin: 0 0 6px;
  font-size: 30px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.15;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.login-subtitle {
  margin: 0 0 32px;
  font-size: 14px;
  color: var(--m-text-hint);
}

/* ===== 毛玻璃表单卡 ===== */
.login-card {
  position: relative;
  width: 100%;
  display: flex;
  flex-direction: column;
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-card);
  padding: 8px 16px 20px;
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
  overflow: hidden;
}
.login-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: var(--m-card-glow);
  pointer-events: none;
}

/* 错误提示 */
.login-error {
  position: relative;
  background: rgba(220, 38, 38, 0.1);
  border: 1px solid rgba(220, 38, 38, 0.25);
  color: var(--m-danger);
  padding: 9px 12px;
  border-radius: var(--m-radius-sm);
  font-size: 13px;
  margin: 8px 0 4px;
}

/* 输入框 field：去框、底分割线、融入卡片 */
.field {
  position: relative;
  border-bottom: 1px solid var(--m-divider);
  transition: border-color 0.22s ease;
}
.field :deep(.n-input) {
  background: transparent !important;
}
.field :deep(.n-input .n-input__border),
.field :deep(.n-input .n-input__state-border) {
  display: none !important;
}
.field :deep(.n-input-wrapper) {
  padding: 13px 4px;
  background: transparent !important;
}
.field:focus-within {
  border-bottom-color: var(--m-primary);
}
.field :deep(.n-input__input-el) {
  font-size: 16px !important; /* 防 iOS 缩放 */
}
.field__icon {
  display: inline-flex;
  color: var(--m-text-hint);
  transition: color 0.18s ease;
}
.field__icon svg {
  width: 20px;
  height: 20px;
}
.field :deep(.n-input--focus) .field__icon {
  color: var(--m-primary);
}

/* 渐变主按钮 */
.login-btn {
  height: 50px;
  margin-top: 14px;
  border: none !important;
  border-radius: var(--m-radius-md);
  background: linear-gradient(135deg, var(--m-primary) 0%, var(--m-accent) 100%) !important;
  box-shadow: var(--m-shadow-soft);
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 0.04em;
  transition: transform 0.15s ease, filter 0.18s ease;
}
.login-btn :deep(.n-button__content) {
  color: #fff;
  font-weight: 700;
}
.login-btn:active {
  transform: scale(0.98);
  filter: brightness(0.95);
}

/* 「或」分隔线 */
.login-divider {
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 18px 0 14px;
}
.login-divider__line {
  flex: 1;
  height: 1px;
  background: var(--m-divider);
}
.login-divider__text {
  font-size: 12px;
  color: var(--m-text-hint);
  letter-spacing: 0.02em;
}

/* 飞书登录：secondary 描边按钮，弱于主渐变按钮，毛玻璃同源 */
.feishu-btn {
  height: 50px;
  border: 1px solid var(--m-border) !important;
  border-radius: var(--m-radius-md);
  background: transparent !important;
  font-size: 15px;
  font-weight: 600;
  transition: border-color 0.18s ease, background 0.18s ease;
}
.feishu-btn :deep(.n-button__content) {
  color: var(--m-text);
  font-weight: 600;
  gap: 8px;
}
.feishu-btn:active {
  border-color: #3370ff !important;
  background: rgba(51, 112, 255, 0.06) !important;
}
.feishu-logo {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: #3370ff;
  color: #fff;
  box-shadow: 0 2px 6px rgba(51, 112, 255, 0.35);
}
.feishu-logo svg {
  width: 13px;
  height: 13px;
}

/* ===== 入场动画 ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes orb-spin {
  to { transform: rotate(360deg); }
}
@keyframes orb-pulse {
  0%, 100% { opacity: 0.55; transform: scale(0.95); }
  50% { opacity: 1; transform: scale(1.05); }
}
@keyframes fade-up {
  from { opacity: 0; transform: translateY(14px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  .logo-orb__halo,
  .logo-orb__ring { animation: none; }
  .fade-up { animation: none; opacity: 1; }
}
</style>
