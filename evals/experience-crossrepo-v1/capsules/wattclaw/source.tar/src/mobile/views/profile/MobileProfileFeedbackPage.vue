<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NInput, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useFeedbackStore } from '@/stores/feedback'

interface FeedbackImageItem {
  file: File
  preview: string
}

const MAX_LEN = 2000
const MAX_IMAGES = 9

const router = useRouter()
const message = useMessage()
const feedbackStore = useFeedbackStore()
const { t } = useI18n()

const description = ref('')
const imageFiles = ref<FeedbackImageItem[]>([])
const submitting = ref(false)
const fileInputRef = ref<HTMLInputElement | null>(null)

const charCount = computed(() => description.value.length)
const nearLimit = computed(() => charCount.value > MAX_LEN * 0.9)

function openFilePicker() {
  fileInputRef.value?.click()
}

function handleFileSelect(e: Event) {
  const input = e.target as HTMLInputElement
  if (input.files) addFiles(Array.from(input.files))
  input.value = ''
}

function addFiles(files: File[]) {
  const accepted: FeedbackImageItem[] = []
  for (const file of files) {
    if (!file.type.startsWith('image/')) continue
    if (imageFiles.value.length + accepted.length >= MAX_IMAGES) break
    accepted.push({ file, preview: URL.createObjectURL(file) })
  }
  if (accepted.length) {
    imageFiles.value = [...imageFiles.value, ...accepted]
  }
}

function removeImage(index: number) {
  const item = imageFiles.value[index]
  if (!item) return
  if (item.preview) URL.revokeObjectURL(item.preview)
  imageFiles.value = imageFiles.value.filter((_, i) => i !== index)
}

// 字数硬截断
function onInput(v: string) {
  description.value = v.length > MAX_LEN ? v.slice(0, MAX_LEN) : v
}

function resetForm() {
  description.value = ''
  for (const item of imageFiles.value) {
    if (item.preview) URL.revokeObjectURL(item.preview)
  }
  imageFiles.value = []
}

async function handleSubmit() {
  const desc = description.value.trim()
  if (!desc) {
    message.warning(t('pages.feedback.descriptionRequired'))
    return
  }

  submitting.value = true
  try {
    const uploadedFilenames: string[] = []
    for (const item of imageFiles.value) {
      const result = await feedbackStore.uploadImage(item.file)
      if (result.ok && result.filename) {
        uploadedFilenames.push(result.filename)
      } else {
        message.error(t('pages.feedback.uploadFailed'))
        return
      }
    }

    const res = await feedbackStore.createIssue(desc, uploadedFilenames)
    if (res.ok) {
      message.success(t('pages.feedback.submitSuccess'))
      resetForm()
    } else {
      message.error(res.error?.message || t('pages.feedback.submitFailed'))
    }
  } catch {
    message.error(t('pages.feedback.submitFailed'))
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="mobile-page subpage">
    <header class="subpage__bar">
      <button class="subpage__back" type="button" :aria-label="t('pages.mobile.profile.back')" @click="router.back()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="m15 18-6-6 6-6" />
        </svg>
      </button>
      <span class="subpage__title">{{ t('pages.mobile.profile.feedbackTitle') }}</span>
    </header>

    <div class="fb-canvas">
      <!-- 引导头 -->
      <section class="fb-hero fade-up" style="--d: 0ms">
        <div class="fb-hero__icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
          </svg>
        </div>
        <div class="fb-hero__body">
          <h2 class="fb-hero__title">{{ t('pages.mobile.profile.feedbackTitle') }}</h2>
          <p class="fb-hero__desc">{{ t('pages.feedback.subtitle') }}</p>
        </div>
      </section>

      <!-- 反馈卡片 -->
      <div class="fb-card fade-up" style="--d: 90ms">
        <!-- 问题描述 -->
        <div class="fb-field">
          <div class="fb-field__head">
            <span class="fb-field__name">
              {{ t('pages.feedback.description') }}<i class="fb-field__req">*</i>
            </span>
            <span class="fb-field__count" :class="{ 'is-warn': nearLimit }">{{ charCount }}/{{ MAX_LEN }}</span>
          </div>
          <NInput
            :value="description"
            class="fb-textarea"
            type="textarea"
            :placeholder="t('pages.feedback.descriptionPlaceholder')"
            :autosize="{ minRows: 5, maxRows: 12 }"
            @update:value="onInput"
          />
        </div>

        <div class="fb-sep" aria-hidden="true"></div>

        <!-- 截图附件 -->
        <div class="fb-field">
          <div class="fb-field__head">
            <span class="fb-field__name">{{ t('pages.feedback.screenshots') }}</span>
            <span class="fb-field__count">{{ imageFiles.length }}/{{ MAX_IMAGES }}</span>
          </div>
          <input
            ref="fileInputRef"
            type="file"
            accept="image/*"
            multiple
            class="fb-hidden-input"
            @change="handleFileSelect"
          />
          <div class="fb-grid">
            <div v-for="(item, index) in imageFiles" :key="index" class="fb-thumb">
              <img :src="item.preview" alt="" />
              <button class="fb-thumb__del" type="button" :aria-label="t('pages.mobile.profile.removeImage')" @click="removeImage(index)">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
            <button
              v-if="imageFiles.length < MAX_IMAGES"
              class="fb-add"
              type="button"
              :aria-label="t('pages.mobile.profile.addImage')"
              @click="openFilePicker"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                <path d="M12 5v14M5 12h14" />
              </svg>
            </button>
          </div>
          <p class="fb-hint">{{ t('pages.mobile.profile.imageHint', { n: MAX_IMAGES }) }}</p>
        </div>
      </div>
    </div>

    <!-- 底部提交 -->
    <footer class="fb-footer">
      <button class="fb-submit" type="button" :disabled="submitting" @click="handleSubmit">
        <svg v-if="submitting" class="fb-submit__spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
          <path d="M21 12a9 9 0 1 1-6.219-8.56" />
        </svg>
        <span>{{ t('pages.mobile.profile.feedbackSubmit') }}</span>
      </button>
    </footer>
  </div>
</template>

<style scoped>
.subpage {
  display: flex;
  flex-direction: column;
  /* 全屏子页挂在 App.vue 顶层 RouterView,中间套 naive Provider(auto 高度 div),
     min-height:100% 百分比链会断裂塌缩→底部露白;改锚视口保证渐变铺满到底 */
  min-height: 100vh;
  min-height: 100dvh;
}

/* 顶栏 */
.subpage__bar {
  position: sticky;
  top: 0;
  z-index: 10;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: calc(env(safe-area-inset-top) + 10px) 12px 10px;
  background: var(--m-bg-card);
  border-bottom: 1px solid var(--m-divider);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
}
.subpage__back {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  border: 0;
  background: transparent;
  color: var(--m-text-primary);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.subpage__back:active {
  background: var(--m-primary-light);
}
.subpage__back svg {
  width: 22px;
  height: 22px;
}
.subpage__title {
  font-size: 16px;
  font-weight: 700;
  color: var(--m-text-primary);
}

.fb-canvas {
  flex: 1;
  max-width: 480px;
  width: 100%;
  margin: 0 auto;
  padding: 6px 16px 0;
}

/* 引导头 */
.fb-hero {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 20px 4px 22px;
}
.fb-hero__icon {
  flex-shrink: 0;
  display: grid;
  place-items: center;
  width: 52px;
  height: 52px;
  border-radius: 16px;
  color: #fff;
  background: linear-gradient(135deg, var(--m-primary) 0%, var(--m-accent) 100%);
  box-shadow: var(--m-shadow-soft);
}
.fb-hero__icon svg {
  width: 26px;
  height: 26px;
}
.fb-hero__body {
  min-width: 0;
}
.fb-hero__title {
  margin: 0;
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -0.01em;
  line-height: 1.25;
  color: var(--m-text-primary);
}
.fb-hero__desc {
  margin: 4px 0 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--m-text-hint);
}

/* 反馈卡片 */
.fb-card {
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-card);
  backdrop-filter: blur(20px) saturate(140%);
  -webkit-backdrop-filter: blur(20px) saturate(140%);
  padding: 18px 16px;
}

.fb-field__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}
.fb-field__name {
  font-size: 14px;
  font-weight: 600;
  color: var(--m-text-primary);
}
.fb-field__req {
  font-style: normal;
  color: var(--m-danger);
  margin-left: 3px;
}
.fb-field__count {
  font-size: 12px;
  font-weight: 500;
  color: var(--m-text-hint);
  font-variant-numeric: tabular-nums;
}
.fb-field__count.is-warn {
  color: var(--m-danger);
}

/* naive-ui NInput 视觉对齐卡片：字号 16px（移动端可读 + 防 iOS 缩放，全局 media query 兜底） */
.fb-textarea :deep(.n-input) {
  --n-border-radius: 14px !important;
}
.fb-textarea :deep(.n-input__textarea-el) {
  font-size: 16px;
  line-height: 1.6;
  color: var(--m-text-primary);
}

.fb-sep {
  height: 1px;
  background: var(--m-divider);
  margin: 18px 0;
}

.fb-hidden-input {
  display: none;
}

.fb-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.fb-thumb {
  position: relative;
  width: 74px;
  height: 74px;
  border-radius: 14px;
  overflow: hidden;
  border: 1px solid var(--m-border);
  background: var(--m-avatar-bg);
}
.fb-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.fb-thumb__del {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.55);
  border: 0;
  color: #fff;
  display: grid;
  place-items: center;
  padding: 0;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.fb-thumb__del svg {
  width: 12px;
  height: 12px;
}
.fb-add {
  width: 74px;
  height: 74px;
  border-radius: 14px;
  border: 1.5px dashed var(--m-border);
  background: transparent;
  color: var(--m-text-hint);
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: border-color 0.18s ease, color 0.18s ease, background 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.fb-add:active {
  border-color: var(--m-primary);
  color: var(--m-primary);
  background: var(--m-primary-light);
}
.fb-add svg {
  width: 22px;
  height: 22px;
}
.fb-hint {
  margin: 10px 0 0;
  font-size: 12px;
  color: var(--m-text-hint);
}

/* 底部提交 */
.fb-footer {
  padding: 14px 16px calc(18px + env(safe-area-inset-bottom));
}
.fb-submit {
  width: 100%;
  height: 50px;
  border: 0;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, var(--m-primary) 0%, var(--m-accent) 100%);
  box-shadow: 0 12px 24px rgba(37, 99, 235, 0.28);
  cursor: pointer;
  transition: transform 0.12s ease, box-shadow 0.12s ease, opacity 0.12s ease;
  -webkit-tap-highlight-color: transparent;
}
.fb-submit:active {
  transform: translateY(1px);
  box-shadow: 0 6px 14px rgba(37, 99, 235, 0.22);
}
.fb-submit:disabled {
  opacity: 0.55;
  cursor: not-allowed;
  box-shadow: none;
}
.fb-submit__spin {
  width: 18px;
  height: 18px;
  animation: fb-spin 0.8s linear infinite;
}
@keyframes fb-spin {
  to {
    transform: rotate(360deg);
  }
}

.fade-up {
  opacity: 0;
  animation: fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from {
    opacity: 0;
    transform: translateY(14px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
