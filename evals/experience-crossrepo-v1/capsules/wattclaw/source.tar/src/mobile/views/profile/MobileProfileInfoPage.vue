<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NButton, NModal, NInput, useMessage } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'
import { useWebSocketStore } from '@/stores/websocket'

const router = useRouter()
const authStore = useAuthStore()
const wsStore = useWebSocketStore()
const { t } = useI18n()
const message = useMessage()

const user = computed(() => authStore.currentUser)
const displayName = computed(() => user.value?.display_name || user.value?.username || '')
const username = computed(() => user.value?.username || '')
const avatarSrc = computed(() => user.value?.avatar || '/favicon.png')

// 头像加载失败兜底回 favicon（avatar 字段可能为相对路径或失效 URL）
function onAvatarError(e: Event) {
  const img = e.target as HTMLImageElement
  if (img.src.endsWith('/favicon.png')) return
  img.src = '/favicon.png'
}

// 修改密码
const showPasswordModal = ref(false)
const currentPwd = ref('')
const newPwd = ref('')
const confirmPwd = ref('')
const changingPwd = ref(false)

function openPasswordModal() {
  currentPwd.value = ''
  newPwd.value = ''
  confirmPwd.value = ''
  showPasswordModal.value = true
}

async function handleChangePassword() {
  if (!currentPwd.value || !newPwd.value || !confirmPwd.value) {
    message.warning(t('pages.mobile.profile.fieldsRequired'))
    return
  }
  if (newPwd.value !== confirmPwd.value) {
    message.warning(t('pages.mobile.profile.passwordMismatch'))
    return
  }
  changingPwd.value = true
  const errKey = await authStore.changePassword(currentPwd.value, newPwd.value)
  changingPwd.value = false
  if (errKey) {
    message.error(t(errKey))
    return
  }
  message.success(t('pages.mobile.profile.changePasswordSuccess'))
  showPasswordModal.value = false
}

// 退出登录（逻辑从原主页原样迁移：飞书标记 + 断 WS + bfcache 隐藏 body）
const showLogoutConfirm = ref(false)
async function handleLogout() {
  showLogoutConfirm.value = false
  sessionStorage.setItem('feishu_logout', '1')
  wsStore.disconnect()
  await authStore.logout()
  document.body.style.display = 'none'
  window.location.replace(router.resolve('/m/login').href)
}
</script>

<template>
  <div class="mobile-page subpage">
    <!-- 顶栏 -->
    <header class="subpage__bar">
      <button class="subpage__back" type="button" :aria-label="t('pages.mobile.profile.back')" @click="router.back()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="m15 18-6-6 6-6" />
        </svg>
      </button>
      <span class="subpage__title">{{ t('pages.mobile.profile.infoTitle') }}</span>
    </header>

    <div class="info-canvas">
      <!-- 身份展示 -->
      <section class="identity fade-up" style="--d: 0ms">
        <div class="identity__avatar">
          <img :src="avatarSrc" alt="" @error="onAvatarError" />
        </div>
        <h1 class="identity__name">{{ displayName }}</h1>
        <p v-if="displayName !== username" class="identity__sub">@{{ username }}</p>
      </section>

      <!-- 底部安全动作区 -->
      <section class="security fade-up" style="--d: 110ms">
        <div class="security__title">{{ t('pages.mobile.profile.securityTitle') }}</div>

        <button class="action-row" type="button" @click="openPasswordModal">
          <span class="action-row__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </span>
          <span class="action-row__label">{{ t('pages.mobile.profile.changePassword') }}</span>
          <span class="action-row__chevron">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 6 6 6-6 6" />
            </svg>
          </span>
        </button>

        <button class="action-row action-row--danger" type="button" @click="showLogoutConfirm = true">
          <span class="action-row__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <path d="m16 17 5-5-5-5" />
              <path d="M21 12H9" />
            </svg>
          </span>
          <span class="action-row__label">{{ t('pages.mobile.profile.logout') }}</span>
          <span class="action-row__chevron">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 6 6 6-6 6" />
            </svg>
          </span>
        </button>
      </section>
    </div>

    <!-- 退出确认 -->
    <NModal
      v-model:show="showLogoutConfirm"
      preset="dialog"
      :title="t('pages.mobile.profile.logoutConfirmTitle')"
      :content="t('pages.mobile.profile.logoutConfirmContent')"
      :positive-text="t('pages.mobile.profile.logoutConfirmOk')"
      :negative-text="t('pages.mobile.profile.cancel')"
      type="warning"
      :positive-button-props="{ type: 'error' }"
      @positive-click="handleLogout"
    />

    <!-- 修改密码 -->
    <NModal
      v-model:show="showPasswordModal"
      preset="card"
      :title="t('pages.mobile.profile.changePassword')"
      :bordered="false"
      :close-on-esc="!changingPwd"
      :mask-closable="!changingPwd"
      :style="{ width: '88%', maxWidth: '420px' }"
    >
      <div class="pwd-form">
        <NInput
          v-model:value="currentPwd"
          type="password"
          show-password-on="click"
          :placeholder="t('pages.mobile.profile.currentPassword')"
          :disabled="changingPwd"
        />
        <NInput
          v-model:value="newPwd"
          type="password"
          show-password-on="click"
          :placeholder="t('pages.mobile.profile.newPassword')"
          :disabled="changingPwd"
        />
        <NInput
          v-model:value="confirmPwd"
          type="password"
          show-password-on="click"
          :placeholder="t('pages.mobile.profile.confirmPassword')"
          :disabled="changingPwd"
        />
      </div>
      <template #footer>
        <div class="pwd-actions">
          <NButton :disabled="changingPwd" @click="showPasswordModal = false">
            {{ t('pages.mobile.profile.cancel') }}
          </NButton>
          <NButton type="primary" :loading="changingPwd" @click="handleChangePassword">
            {{ t('pages.mobile.profile.submit') }}
          </NButton>
        </div>
      </template>
    </NModal>
  </div>
</template>

<style scoped>
.subpage {
  display: flex;
  flex-direction: column;
  /* 全屏子页挂在 App.vue 顶层 RouterView,中间套 naive Provider(auto 高度 div),
     min-height:100% 百分比链会断裂塌缩→底部露白;改锚视口保证渐变铺满到底 */
  min-height: 100vh;
  min-height: 100dvh;
}

/* 顶栏 */
.subpage__bar {
  position: sticky;
  top: 0;
  z-index: 10;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: calc(env(safe-area-inset-top) + 10px) 12px 10px;
  background: var(--m-bg-card);
  border-bottom: 1px solid var(--m-divider);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
}
.subpage__back {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  border: 0;
  background: transparent;
  color: var(--m-text-primary);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.subpage__back:active {
  background: var(--m-primary-light);
}
.subpage__back svg {
  width: 22px;
  height: 22px;
}
.subpage__title {
  font-size: 16px;
  font-weight: 700;
  color: var(--m-text-primary);
}

.info-canvas {
  max-width: 480px;
  width: 100%;
  margin: 0 auto;
  padding: 0 22px calc(40px + env(safe-area-inset-bottom));
}

/* 身份展示 */
.identity {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 36px 0 24px;
  text-align: center;
}
.identity__avatar {
  width: 96px;
  height: 96px;
  border-radius: 50%;
  overflow: hidden;
  background: var(--m-avatar-bg);
  box-shadow: var(--m-shadow-soft), inset 0 0 0 1px rgba(255, 255, 255, 0.5);
  margin-bottom: 16px;
}
.identity__avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.identity__name {
  margin: 0;
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.2;
  background: linear-gradient(120deg, var(--m-primary-strong) 0%, var(--m-accent) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.identity__sub {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--m-text-hint);
}

/* 安全动作区 */
.security {
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-card);
  padding: 0 14px 6px;
  overflow: hidden;
}
.security__title {
  padding: 16px 8px 10px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--m-text-hint);
}

/* 列表行（与主页一致） */
.action-row {
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 13px 8px;
  background: transparent;
  border: 0;
  border-top: 1px solid var(--m-divider);
  cursor: pointer;
  color: var(--m-text-primary);
  font: inherit;
  transition: background 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.action-row:active {
  background: var(--m-primary-light);
}
.action-row__icon {
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--m-avatar-bg);
  color: var(--m-primary);
  flex-shrink: 0;
}
.action-row__icon svg {
  width: 20px;
  height: 20px;
}
.action-row__label {
  flex: 1;
  text-align: left;
  font-size: 15px;
  font-weight: 600;
}
.action-row__chevron {
  display: grid;
  place-items: center;
  color: var(--m-text-hint);
}
.action-row__chevron svg {
  width: 16px;
  height: 16px;
}
.action-row--danger .action-row__icon {
  color: var(--m-danger);
  background: rgba(220, 38, 38, 0.08);
}
.action-row--danger .action-row__label {
  color: var(--m-danger);
}
.action-row--danger:active {
  background: rgba(220, 38, 38, 0.1);
}

/* 入场 */
.fade-up {
  opacity: 0;
  animation: fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from {
    opacity: 0;
    transform: translateY(14px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>

<!-- 改密弹窗 teleport 到 body，scoped 失效，故用全局样式 -->
<style>
.pwd-form {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 2px 0;
}
.pwd-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>
