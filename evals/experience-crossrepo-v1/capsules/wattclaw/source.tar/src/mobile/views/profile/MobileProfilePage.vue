<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { NModal } from 'naive-ui'
import { useI18n } from 'vue-i18n'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()
const { t } = useI18n()

const user = computed(() => authStore.currentUser)
const displayName = computed(() => user.value?.display_name || user.value?.username || '')

// 关于弹窗（版本信息卡片）
const APP_VERSION = '1.0.0'
const showAbout = ref(false)

function goInfo() {
  router.push('/m/profile/info')
}
function goFeedback() {
  router.push('/m/profile/feedback')
}
</script>

<template>
  <div class="mobile-page profile-page">
    <div class="profile-canvas">
      <!-- Header：Logo + 用户名 紧凑横排 -->
      <header class="profile-header fade-up" style="--d: 0ms">
        <div class="profile-header__logo">
          <img src="/favicon.png" alt="" />
        </div>
        <div class="profile-header__text">
          <h1 class="profile-header__name">{{ displayName }}</h1>
          <p class="profile-header__brand">{{ t('pages.mobile.profile.brand') }}</p>
        </div>
      </header>

      <!-- 功能列表组 -->
      <nav class="list-group fade-up" style="--d: 110ms">
        <button class="action-row" type="button" @click="goInfo">
          <span class="action-row__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 21a8 8 0 0 1 16 0" />
            </svg>
          </span>
          <span class="action-row__label">{{ t('pages.mobile.profile.personalInfo') }}</span>
          <span class="action-row__chevron">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 6 6 6-6 6" />
            </svg>
          </span>
        </button>

        <button class="action-row" type="button" @click="goFeedback">
          <span class="action-row__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="9" />
              <path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .8-1 1.7v.5" />
              <circle cx="12" cy="17" r="0.6" fill="currentColor" stroke="none" />
            </svg>
          </span>
          <span class="action-row__label">{{ t('pages.mobile.profile.helpFeedback') }}</span>
          <span class="action-row__chevron">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 6 6 6-6 6" />
            </svg>
          </span>
        </button>

        <button class="action-row" type="button" @click="showAbout = true">
          <span class="action-row__icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 11v5" />
              <circle cx="12" cy="7.6" r="0.6" fill="currentColor" stroke="none" />
            </svg>
          </span>
          <span class="action-row__label">{{ t('pages.mobile.profile.about') }}</span>
          <span class="action-row__chevron">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m9 6 6 6-6 6" />
            </svg>
          </span>
        </button>
      </nav>
    </div>

    <!-- 关于弹窗 -->
    <NModal
      v-model:show="showAbout"
      preset="card"
      :bordered="false"
      :style="{ width: '84%', maxWidth: '380px' }"
    >
      <div class="about">
        <div class="about__logo">
          <img src="/favicon.png" alt="" />
        </div>
        <h2 class="about__name">{{ t('pages.mobile.profile.brand') }}</h2>
        <p class="about__version">{{ t('pages.mobile.profile.aboutVersion') }} {{ APP_VERSION }}</p>
        <p class="about__desc">{{ t('pages.mobile.profile.aboutDesc') }}</p>
      </div>
    </NModal>
  </div>
</template>

<style scoped>
.profile-page {
  min-height: 100%;
}

.profile-canvas {
  max-width: 480px;
  margin: 0 auto;
  padding: 0 22px calc(112px + env(safe-area-inset-bottom));
  display: flex;
  flex-direction: column;
}

/* ===== Header：Logo + 名字 ===== */
.profile-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 56px 0 36px;
}
.profile-header__logo {
  flex-shrink: 0;
  width: 60px;
  height: 60px;
  border-radius: 16px;
  overflow: hidden;
  background: var(--m-avatar-bg);
  box-shadow: var(--m-shadow-soft), inset 0 0 0 1px rgba(255, 255, 255, 0.5);
}
.profile-header__logo img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}
.profile-header__text {
  min-width: 0;
}
.profile-header__name {
  margin: 0;
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.2;
  color: var(--m-text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.profile-header__brand {
  margin: 4px 0 0;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.08em;
  color: var(--m-text-hint);
}

/* ===== 功能列表组 ===== */
.list-group {
  border-radius: var(--m-radius-lg);
  background: var(--m-bg-card);
  border: 1px solid var(--m-border);
  box-shadow: var(--m-shadow-card);
  padding: 0 14px;
  overflow: hidden;
}

.action-row {
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px 8px;
  background: transparent;
  border: 0;
  border-top: 1px solid var(--m-divider);
  cursor: pointer;
  color: var(--m-text-primary);
  font: inherit;
  transition: background 0.18s ease;
  -webkit-tap-highlight-color: transparent;
}
.action-row:first-child {
  border-top: 0;
}
.action-row:active {
  background: var(--m-primary-light);
}
.action-row__icon {
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--m-avatar-bg);
  color: var(--m-primary);
  flex-shrink: 0;
}
.action-row__icon svg {
  width: 20px;
  height: 20px;
}
.action-row__label {
  flex: 1;
  text-align: left;
  font-size: 15px;
  font-weight: 600;
}
.action-row__chevron {
  display: grid;
  place-items: center;
  color: var(--m-text-hint);
}
.action-row__chevron svg {
  width: 16px;
  height: 16px;
}

/* ===== 入场动画 ===== */
.fade-up {
  opacity: 0;
  animation: fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  animation-delay: var(--d, 0ms);
}
@keyframes fade-up {
  from {
    opacity: 0;
    transform: translateY(14px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>

<!-- 关于弹窗 teleport 到 body，scoped 失效，故用全局样式 -->
<style>
.about {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 8px 4px 4px;
}
.about__logo {
  width: 72px;
  height: 72px;
  border-radius: 18px;
  overflow: hidden;
  background: var(--m-avatar-bg);
  margin-bottom: 14px;
}
.about__logo img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.about__name {
  margin: 0;
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -0.01em;
  color: var(--m-text-primary);
}
.about__version {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--m-text-hint);
}
.about__desc {
  margin: 14px 0 0;
  font-size: 14px;
  line-height: 1.6;
  color: var(--m-text-secondary, var(--m-text-primary));
}
</style>
