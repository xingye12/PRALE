import { createRouter, createWebHistory } from 'vue-router'
import { routes } from './routes'
import { useAuthStore } from '@/stores/auth'
import { setupMobileRedirect } from '@/mobile/composables/useMobileRedirect'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

setupMobileRedirect(router)

router.beforeEach(async (to, _from, next) => {
  const authStore = useAuthStore()

  // Mobile routes: redirect unauthenticated to /m/login
  if (to.path.startsWith('/m/')) {
    if (to.path !== '/m/login' && !authStore.isAuthenticated) {
      next({ path: '/m/login', query: { redirect: to.fullPath } })
      return
    }
    if (to.path === '/m/login' && authStore.isAuthenticated) {
      next('/m/conversations')
      return
    }
  }

  if (to.meta.public) {
    if (to.name === 'Login' && authStore.isAuthenticated) {
      const valid = await authStore.checkAuth()
      if (valid) {
        const redirect = typeof to.query.redirect === 'string' ? to.query.redirect : '/'
        next(redirect)
        return
      }
    }
    next()
    return
  }

  if (!authStore.isAuthenticated) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  const valid = await authStore.checkAuth()
  if (!valid) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  if (to.meta.requiresAdmin && !authStore.isAdmin) {
    next({ name: 'Dashboard' })
    return
  }

  next()
})

export default router
