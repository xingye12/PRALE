import type { RouteRecordRaw } from 'vue-router'
import AgentTeamPage from '@/views/agent-team/AgentTeamPage.vue'
import AgentMarketPage from '@/views/agent-market/AgentMarketPage.vue'
import AgentManagementPage from '@/views/agent-management/AgentManagementPage.vue'
import { mobileRoutes } from '@/mobile/router/mobile-routes'

export const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { titleKey: 'routes.login', public: true },
  },
  {
    path: '/auth/feishu/callback',
    name: 'FeishuCallback',
    component: () => import('@/views/auth/FeishuCallback.vue'),
    meta: { titleKey: 'routes.login', public: true },
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/AboutPage.vue'),
    meta: { titleKey: 'routes.about', public: true },
  },
  {
    path: '/',
    component: () => import('@/layouts/DefaultLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        name: 'Workspace',
        component: () => import('@/views/workspace/WorkspacePage.vue'),
        meta: { titleKey: 'routes.workspace', icon: 'ChatOutline', hideInBreadcrumb: true },
      },
      {
        path: 'collaboration',
        name: 'WattClawCollaboration',
        component: () => import('@/views/wattclaw-collaboration/WattClawCollaborationPage.vue'),
        meta: { titleKey: 'routes.wattClawCollaboration', hidden: true },
      },
      {
        path: 'agent-team',
        name: 'AgentTeam',
        component: AgentTeamPage,
        meta: { titleKey: 'routes.agentTeam', icon: 'SmartToyOutline' },
        children: [
          {
            path: '',
            redirect: '/agent-team/market',
          },
          {
            path: 'market',
            name: 'AgentMarket',
            component: AgentMarketPage,
            meta: { hidden: true },
          },
          {
            path: 'management',
            name: 'AgentManagement',
            component: AgentManagementPage,
            meta: { hidden: true },
          },
          {
            path: 'management/:id',
            name: 'AgentManagementDetail',
            component: AgentManagementPage,
            meta: { hidden: true },
          },
        ],
      },
      {
        path: 'agent-market',
        redirect: { name: 'AgentMarket' },
        meta: { hidden: true },
      },
      {
        path: 'agent-management',
        redirect: { name: 'AgentManagement' },
        meta: { hidden: true },
      },
      {
        path: 'agent-management/:id',
        redirect: (to) => ({ name: 'AgentManagementDetail', params: { id: to.params.id } }),
        meta: { hidden: true },
      },
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/Dashboard.vue'),
        meta: { titleKey: 'routes.dashboard', icon: 'GridOutline', hidden: true },
      },
      {
        path: 'sessions',
        name: 'Sessions',
        component: () => import('@/views/sessions/SessionsPage.vue'),
        meta: { titleKey: 'routes.sessions', icon: 'ChatbubblesOutline', requiresAdmin: true },
      },
      {
        path: 'sessions/:key',
        name: 'SessionDetail',
        component: () => import('@/views/sessions/SessionDetailPage.vue'),
        meta: { titleKey: 'routes.sessionDetail', hidden: true },
      },
      {
        path: 'models',
        name: 'Models',
        component: () => import('@/views/models/ModelsPage.vue'),
        meta: { titleKey: 'routes.models', icon: 'SparklesOutline', requiresAdmin: true },
      },
      {
        path: 'memory',
        name: 'Memory',
        component: () => import('@/views/memory/MemoryPage.vue'),
        meta: { titleKey: 'routes.memory', icon: 'BookOutline', requiresAdmin: true },
      },
      {
        path: 'cron',
        name: 'Cron',
        component: () => import('@/views/cron/CronPage.vue'),
        meta: { titleKey: 'routes.cron', icon: 'CalendarOutline' },
      },
      {
        path: 'skills',
        name: 'Skills',
        component: () => import('@/views/skills/SkillsPage.vue'),
        meta: { titleKey: 'routes.skills', icon: 'ExtensionPuzzleOutline', requiresAdmin: true },
      },
      {
        path: 'skill-store',
        name: 'SkillStore',
        component: () => import('@/views/skill-store/SkillStorePage.vue'),
        meta: { titleKey: 'routes.skillStore', icon: 'StorefrontOutline' },
      },
      {
        path: 'plugin-store',
        name: 'PluginStore',
        component: () => import('@/views/plugin-store/PluginStorePage.vue'),
        meta: { titleKey: 'routes.pluginStore', icon: 'ExtensionPuzzleOutline' },
      },
      {
        path: 'tools',
        redirect: { name: 'Skills' },
        meta: { hidden: true },
      },
      {
        path: 'system',
        name: 'System',
        component: () => import('@/views/system/SystemPage.vue'),
        meta: { titleKey: 'routes.system', icon: 'PulseOutline', requiresAdmin: true },
      },
      {
        path: 'files',
        name: 'Files',
        component: () => import('@/views/files/FilesPage.vue'),
        meta: { titleKey: 'routes.files', icon: 'FolderOutline', requiresAdmin: true, hidden: true },
      },
      {
        path: 'file-manager',
        name: 'FileManager',
        component: () => import('@/views/files/FileManagerPage.vue'),
        meta: { titleKey: 'routes.fileManager', icon: 'FolderOpenOutline' },
      },
      {
        path: 'agents',
        name: 'Agents',
        component: () => import('@/views/agents/AgentsPage.vue'),
        meta: { titleKey: 'routes.agents', icon: 'PeopleOutline', requiresAdmin: true },
      },
      {
        path: 'agents-team/:id',
        redirect: (to) => ({ name: 'AgentManagementDetail', params: { id: to.params.id } }),
        meta: { hidden: true },
      },
      {
        path: 'office',
        name: 'Office',
        component: () => import('@/views/office/OfficePage.vue'),
        meta: { titleKey: 'routes.office', icon: 'ConstructOutline', requiresAdmin: true },
      },
      {
        path: 'backup',
        name: 'Backup',
        component: () => import('@/views/backup/BackupPage.vue'),
        meta: { titleKey: 'routes.backup', icon: 'ArchiveOutline', requiresAdmin: true },
      },
      {
        path: 'monitor',
        name: 'Monitor',
        component: () => import('@/views/monitor/MonitorPage.vue'),
        meta: { titleKey: 'routes.monitor', icon: 'PulseOutline', hidden: true },
      },
      {
        path: 'settings',
        name: 'Settings',
        component: () => import('@/views/settings/SettingsPage.vue'),
        meta: { titleKey: 'routes.settings', icon: 'CogOutline', requiresAdmin: true },
      },
      {
        path: 'users',
        name: 'UserManagement',
        component: () => import('@/views/admin/UserManagementPage.vue'),
        meta: { titleKey: 'routes.userManagement', icon: 'PeopleOutline', requiresAdmin: true },
      },
      {
        path: 'tenant-management',
        name: 'TenantManagement',
        component: () => import('@/views/tenant-management/TenantManagementPage.vue'),
        meta: { titleKey: 'routes.tenantManagement', icon: 'BusinessOutline', requiresAdmin: true },
      },
      {
        path: 'notification-manage',
        name: 'NotificationManage',
        component: () => import('@/views/admin/NotificationManagePage.vue'),
        meta: { titleKey: 'routes.notificationManage', icon: 'ChatOutline', requiresAdmin: true },
      },
      {
        path: 'about',
        redirect: { name: 'About' },
        meta: { hidden: true },
      },
    ],
  },
  {
    path: '/feedback',
    name: 'Feedback',
    component: () => import('@/views/feedback/FeedbackPage.vue'),
    meta: { titleKey: 'routes.feedback', requiresAuth: true },
  },
  {
    path: '/feedback/list',
    name: 'FeedbackList',
    component: () => import('@/views/feedback/FeedbackListPage.vue'),
    meta: { requiresAuth: true },
  },
  ...mobileRoutes,
]
