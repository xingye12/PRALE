import { ref } from 'vue'
import { defineStore } from 'pinia'
import { useAuthStore } from './auth'
import type { AgentTeamMember, AgentTemplate } from '@/api/types'
import { getTemplateById } from '@/config/agent-templates'
import { isImageAvatar } from '@/utils/agent-avatar'

export class AgentTeamApiError extends Error {
  code?: string
  status: number

  constructor(message: string, status: number, code?: string) {
    super(message)
    this.name = 'AgentTeamApiError'
    this.status = status
    this.code = code
  }
}

export const useAgentTeamStore = defineStore('agent-team', () => {
  const agentList = ref<AgentTeamMember[]>([])
  const currentAgent = ref<AgentTeamMember | null>(null)
  const loading = ref(false)
  const agentStats = ref<Record<string, { messages: number; tasks: number }>>({})
  // 热门模板 Top3:应用级常驻,进入移动端主框架时一次性加载,页面同步消费,无切页空白
  const hotTemplates = ref<AgentTemplate[]>([])
  const hotLoaded = ref(false)

  async function apiCall(path: string, options?: RequestInit) {
    const authStore = useAuthStore()
    const token = authStore.getToken()
    if (!token) throw new Error('Not authenticated')
    const res = await fetch(`/api/agent-team${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options?.headers,
      },
    })
    const data = await res.json()
    if (!data.ok) {
      const errorMessage = typeof data.error === 'string' ? data.error : 'Request failed'
      const errorCode = typeof data.code === 'string' ? data.code : undefined
      throw new AgentTeamApiError(errorMessage, res.status, errorCode)
    }
    return data
  }

  function mapAgent(raw: any): AgentTeamMember {
    const identity = raw.identity || {}
    const avatarUrl = raw.avatarUrl || raw.avatar_url || identity.avatarUrl || identity.avatar_url || ''
    const avatar = raw.avatar || identity.avatar || ''
    const emoji = raw.emoji || raw.avatar_emoji || identity.emoji || ''
    const imageAvatar = isImageAvatar(avatarUrl) ? avatarUrl : (isImageAvatar(avatar) ? avatar : '')
    return {
      id: raw.gateway_agent_id || raw.id,
      workspace: raw.workspace || undefined,
      name: raw.name || '',
      description: raw.description || '',
      avatar: imageAvatar || avatar,
      avatarUrl: imageAvatar,
      emoji,
      model: raw.model ? raw.model.split('/').pop()! : '',
      category: raw.category || '',
      templateId: raw.template_id || raw.templateId || '',
      status: raw.status || 'active',
      createdBy: raw.user_id || '',
      createdAt: raw.created_at || 0,
      updatedAt: raw.updated_at || 0,
      lastActiveAt: raw.last_active_at || raw.updated_at || 0,
      ownerName: raw.owner_name || '',
    }
  }

  async function fetchAgents() {
    loading.value = true
    try {
      const data = await apiCall('/list')
      agentList.value = (data.list || []).map(mapAgent)
      // 拉取用量统计，失败降级不阻塞列表渲染
      void fetchStats()
    } finally {
      loading.value = false
    }
  }

  async function fetchStats() {
    try {
      const data = await apiCall('/stats')
      agentStats.value = (data.stats || {}) as Record<string, { messages: number; tasks: number }>
    } catch {
      // 降级：保持空对象，UI 显示 '-'
    }
  }

  function statsOf(id: string): { messages: number; tasks: number } | undefined {
    return agentStats.value[id]
  }

  async function fetchAgent(id: string) {
    loading.value = true
    try {
      const data = await apiCall(`/${id}`)
      currentAgent.value = data.agent ? mapAgent(data.agent) : null
    } finally {
      loading.value = false
    }
  }

  async function checkCreateLimit(): Promise<{
    limit: number
    count: number
    remaining: number
    canCreate: boolean
  }> {
    const data = await apiCall('/create-limit')
    return {
      limit: Number(data.limit || 0),
      count: Number(data.count || 0),
      remaining: Number(data.remaining || 0),
      canCreate: Boolean(data.canCreate),
    }
  }

  async function createAgent(agentData: any): Promise<AgentTeamMember> {
    const data = await apiCall('/create', {
      method: 'POST',
      body: JSON.stringify(agentData),
    })
    const newAgent = mapAgent(data.agent)
    agentList.value = [newAgent, ...agentList.value]
    return newAgent
  }

  async function updateAgent(id: string, updates: any): Promise<AgentTeamMember> {
    const data = await apiCall(`/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    })
    const updated = mapAgent(data.agent)
    if (currentAgent.value?.id === id) {
      currentAgent.value = updated
    }
    agentList.value = agentList.value.map((a) => (a.id === id ? updated : a))
    return updated
  }

  async function deleteAgent(id: string) {
    await apiCall(`/${id}`, { method: 'DELETE' })
    agentList.value = agentList.value.filter((a) => a.id !== id)
    if (currentAgent.value?.id === id) {
      currentAgent.value = null
    }
  }

  // 热门模板应用级幂等加载:已成功加载过则直接返回(常驻复用),否则拉取并映射完整模板;
  // 失败不标记已加载以允许下次重试。无 featured 回退——数据在路上时 Top3 区不显示,诚实降级。
  async function ensureHotTemplates(limit = 3): Promise<AgentTemplate[]> {
    if (hotLoaded.value) return hotTemplates.value
    try {
      const data = await apiCall(`/hot-templates?limit=${limit}`)
      const list = (data.list || []) as Array<{ templateId: string; count: number }>
      hotTemplates.value = list
        .map((entry) => getTemplateById(entry.templateId))
        .filter((tpl): tpl is AgentTemplate => Boolean(tpl))
      hotLoaded.value = true
    } catch {
      // 失败:保持空,下次进入重试
    }
    return hotTemplates.value
  }

  function reset() {
    agentList.value = []
    currentAgent.value = null
    loading.value = false
    hotTemplates.value = []
    hotLoaded.value = false
  }

  return {
    agentList,
    currentAgent,
    agentStats,
    loading,
    hotTemplates,
    fetchAgents,
    fetchAgent,
    fetchStats,
    statsOf,
    checkCreateLimit,
    createAgent,
    updateAgent,
    deleteAgent,
    ensureHotTemplates,
    reset,
  }
})
