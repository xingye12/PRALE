import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { apiPath } from '@/utils/api-path'
import type { User } from '@/api/types'

const AUTH_TOKEN_KEY = 'auth_token'
const AUTH_USER_KEY = 'auth_user'

export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(localStorage.getItem(AUTH_TOKEN_KEY))
  const authEnabled = ref(true)
  const loading = ref(false)
  const error = ref<string | null>(null)
  const currentUser = ref<User | null>(null)

  const isAuthenticated = computed(() => !!token.value)
  const isAdmin = computed(() => currentUser.value?.role === 'admin')

  function setToken(newToken: string | null) {
    token.value = newToken
    if (newToken) {
      localStorage.setItem(AUTH_TOKEN_KEY, newToken)
    } else {
      localStorage.removeItem(AUTH_TOKEN_KEY)
    }
  }

  function setCurrentUser(user: User | null) {
    currentUser.value = user
    if (user) {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user))
    } else {
      localStorage.removeItem(AUTH_USER_KEY)
    }
  }

  function restoreUser() {
    try {
      const stored = localStorage.getItem(AUTH_USER_KEY)
      if (stored) {
        currentUser.value = JSON.parse(stored)
      }
    } catch {
      currentUser.value = null
    }
  }

  restoreUser()

  async function checkAuthConfig() {
    try {
      const response = await fetch(apiPath('/api/auth/config'))
      const data = await response.json()
      authEnabled.value = data.enabled
      return data.enabled
    } catch {
      authEnabled.value = false
      return false
    }
  }

  async function checkAuth(): Promise<boolean> {
    if (!token.value) return false

    try {
      const response = await fetch(apiPath('/api/auth/check'), {
        headers: {
          'Authorization': `Bearer ${token.value}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        if (data.user) {
          setCurrentUser(data.user)
        }
        return true
      } else {
        setToken(null)
        setCurrentUser(null)
        return false
      }
    } catch {
      return false
    }
  }

  async function login(username: string, password: string): Promise<boolean> {
    loading.value = true
    error.value = null

    try {
      const response = await fetch(apiPath('/api/auth/login'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        if (data.token) {
          setToken(data.token)
        }
        if (data.user) {
          setCurrentUser(data.user)
        }
        loading.value = false
        return true
      } else {
        error.value = data.error || 'Login failed'
        loading.value = false
        return false
      }
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Network error'
      loading.value = false
      return false
    }
  }

  async function register(params: { username: string; password: string; displayName?: string; email?: string }): Promise<boolean> {
    loading.value = true
    error.value = null

    try {
      const response = await fetch(apiPath('/api/auth/register'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        if (data.token) {
          setToken(data.token)
        }
        if (data.user) {
          setCurrentUser(data.user)
        }
        loading.value = false
        return true
      } else {
        error.value = data.error || 'Registration failed'
        loading.value = false
        return false
      }
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Network error'
      loading.value = false
      return false
    }
  }

  async function logout() {
    try {
      if (token.value) {
        await fetch(apiPath('/api/auth/logout'), {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token.value}`,
          },
        })
      }
    } catch {
      // ignore
    }
    setToken(null)
    setCurrentUser(null)
  }

  async function updateProfile(updates: { displayName?: string; email?: string; avatar?: string }): Promise<boolean> {
    try {
      const response = await fetch(apiPath('/api/auth/profile'), {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token.value}`,
        },
        body: JSON.stringify(updates),
      })
      const data = await response.json()
      if (data.ok && data.user) {
        setCurrentUser(data.user)
        return true
      }
      return false
    } catch {
      return false
    }
  }

  async function changePassword(currentPassword: string, newPassword: string): Promise<string | null> {
    try {
      const response = await fetch(apiPath('/api/auth/password'), {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token.value}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      })
      const data = await response.json()
      if (data.ok) return null
      if (data.error?.includes('incorrect')) return 'pages.changePassword.wrongPassword'
      if (data.error?.includes('6 characters')) return 'pages.changePassword.passwordTooShort'
      return 'pages.changePassword.networkError'
    } catch {
      return 'pages.changePassword.networkError'
    }
  }

  async function feishuLogin(code: string, state: string): Promise<boolean> {
    loading.value = true
    error.value = null

    try {
      const response = await fetch(apiPath('/api/auth/feishu/callback'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, state }),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        if (data.token) setToken(data.token)
        if (data.user) setCurrentUser(data.user)
        loading.value = false
        return true
      } else {
        error.value = data.error || '飞书登录失败'
        loading.value = false
        return false
      }
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Network error'
      loading.value = false
      return false
    }
  }

  function getToken(): string | null {
    return token.value
  }

  return {
    token,
    authEnabled,
    loading,
    error,
    currentUser,
    isAuthenticated,
    isAdmin,
    checkAuthConfig,
    checkAuth,
    login,
    register,
    logout,
    updateProfile,
    changePassword,
    feishuLogin,
    getToken,
  }
})
